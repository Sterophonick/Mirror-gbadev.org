
<!DOCTYPE html>
<HTML>
<HEAD>
	<TITLE>Gameboy Advance Development</TITLE>
	<STYLE TYPE='text/css'>
		<!--
		a.menu:link     { font: 14pt verdana; color: #000000; text-decoration: none; }
		a.menu:visited     { font: 14pt verdana; color: #000000; text-decoration: none; }
		a.menu:visited:hover     { font: 14pt verdana; color: #000000; text-decoration: none; }
		a:link          { font: bold 10pt verdana; color: #3333FF; text-decoration: none; }
		a:visited       { font: bold 10pt verdana; color: #3333FF; text-decoration: none; }
		a:visited:hover { font: bold 10pt verdana; color: #3333FF; text-decoration: none; }
		// -->
	</STYLE>
	<LINK HREF='http://rss.gbadev.org/feed.php' REL='alternate' TITLE='GBADEV.ORG RSS' TYPE='application/rss+xml'>
	<META HTTP-EQUIV='Content-Type' CONTENT='text/html; charset=iso-8859-1'>
	<META HTTP-EQUIV='Content-Style-Type' CONTENT='text/css'>
</HEAD>

<BODY BGCOLOR='#FFFFFF' TEXT='#000000'>

<TABLE BORDER='0' CELLSPACING='5' CELLPADDING='0' WIDTH='800'>
	<TR>
		<TD WIDTH='160'></TD>
		<TD ALIGN='CENTER' BGCOLOR='#FFFFFF'><IMG SRC='gbadev.png' WIDTH='600' HEIGHT='54' ALT='logo'></TD>
		<TD WIDTH='200'></TD>
	</TR>
	<TR>
		<TD VALIGN='TOP' WIDTH='170' BGCOLOR='#FFFFFF'>
		<TABLE WIDTH='165' STYLE='BORDER: 1px solid black;' CELLSPACING='0' CELLPADDING='2'>
<TR>
	<TD ALIGN='LEFT' BGCOLOR='#0099FF' STYLE='BORDER-RIGHT: hidden; BORDER-BOTTOM: 1px solid black; BORDER-LEFT: hidden;'>
	<FONT FACE='verdana' SIZE='2'><B>Menu</B></FONT><BR></TD>
</TR>
<TR>
	<TD ALIGN='LEFT' BGCOLOR='#CDCDCD'>
	<FONT FACE='verdana'>
	<A HREF='index.php' CLASS='menu'>Main</A><BR>
	<A HREF='about.php' CLASS='menu'>About</A><BR>
	<A HREF='search.php' CLASS='menu'>Search</A><BR>
	<A HREF='submit.php' CLASS='menu'>Submit News</A><BR>
	<A HREF='archive.php' CLASS='menu'>News Archive</A><BR>
	<A HREF='http://forum.gbadev.org' CLASS='menu'>Forum</A><BR>
	<A HREF='contact.php' CLASS='menu'>Contact Us</A><BR>
	<br>
	<A HREF='tools.php' CLASS='menu'>Tools</A><BR>
	<A HREF='demos.php' CLASS='menu'>Games/Demos</A><BR>
	<A HREF='sources.php' CLASS='menu'>Sourcecode</A><BR>
	<A HREF='docs.php' CLASS='menu'>Documentation</A><BR>
	<A HREF='hardware.php' CLASS='menu'>Hardware</A><BR>
	<A HREF='developers.php' CLASS='menu'>Developers</A><BR>
	</FONT></TD>
</TR>
</TABLE></TD>
		<TD VALIGN='TOP' WIDTH='600' BGCOLOR='#FFFFFF'>
		<TABLE WIDTH='600' STYLE='BORDER: 1px solid black;' CELLSPACING='0' CELLPADDING='2'>
		<TR>
			<TD ALIGN='LEFT' BGCOLOR='#0099FF' STYLE='BORDER-RIGHT: hidden; BORDER-BOTTOM: 1px solid black; BORDER-LEFT: hidden;'>
			<FONT FACE='verdana' SIZE='2'><B>Sourcecode</B></FONT><BR></TD>
		</TR>
		<TR>
			<TD ALIGN='LEFT' BGCOLOR='#CDCDCD'>
			<FONT FACE='verdana' SIZE='2'>Sourcecode...
			<BR></TD>
		</TR>
		</TABLE></TD>
		<TD VALIGN='TOP' WIDTH='190' BGCOLOR='#FFFFFF'>
		<TABLE WIDTH='190' STYLE='BORDER: 1px solid black;' CELLSPACING='0' CELLPADDING='2'>
<TR>
	<TD ALIGN='LEFT' BGCOLOR='#0099FF' STYLE='BORDER-RIGHT: hidden; BORDER-BOTTOM: 1px solid black; BORDER-LEFT: hidden;'>
	<FONT FACE='verdana' SIZE='2'><B>Top Games</B></FONT><BR></TD>
</TR>
<TR>
<TD ALIGN='LEFT' BGCOLOR='#CDCDCD'>

<IMG SRC='http://gbadev.org/demos/2004Mbit_logo.png' WIDTH='184' HEIGHT='123' ALT=''><BR>1. <A HREF='demos.php?showinfo=1271'>2004Mbit Compo Game</A><BR>2. <A HREF='demos.php?showinfo=434'>Xmen V StreetFighter J Edition</A><BR>3. <A HREF='demos.php?showinfo=1279'>Another World GBA v2.1</A><BR>4. <A HREF='demos.php?showinfo=1353'>MarioBreak!</A><BR>5. <A HREF='demos.php?showinfo=1354'>FF4 Advance- The Return of Golbez</A><BR></FONT></TD>
</TR>
</TABLE>		<BR>
		<TABLE WIDTH='190' STYLE='BORDER: 1px solid black;' CELLSPACING='0' CELLPADDING='2'>
<TR>
	<TD ALIGN='LEFT' BGCOLOR='#0099FF' STYLE='BORDER-RIGHT: hidden; BORDER-BOTTOM: 1px solid black; BORDER-LEFT: hidden;'>
	<FONT FACE='verdana' SIZE='2'><B>Top Demos</B></FONT><BR></TD>
</TR>
<TR>
<TD ALIGN='LEFT' BGCOLOR='#CDCDCD'>

<IMG SRC='http://gbadev.org/demos/SmashBrosAdvance.png' WIDTH='184' HEIGHT='123' ALT=''><BR>1. <A HREF='demos.php?showinfo=1275'>Smash Bros. Advance</A><BR>2. <A HREF='demos.php?showinfo=472'>Half Life</A><BR>3. <A HREF='demos.php?showinfo=1332'>Jespa3D Engine ver 1.39</A><BR>4. <A HREF='demos.php?showinfo=1276'>BulletGBA 5.0</A><BR>5. <A HREF='demos.php?showinfo=1329'>Final Fantasy 4th World Cup won by Italy</A><BR></FONT></TD>
</TR>
</TABLE>		<BR>
		<TABLE WIDTH='190' STYLE='BORDER: 1px solid black;' CELLSPACING='0' CELLPADDING='2'>
<TR>
	<TD ALIGN='LEFT' BGCOLOR='#0099FF' STYLE='BORDER-RIGHT: hidden; BORDER-BOTTOM: 1px solid black; BORDER-LEFT: hidden;'>
	<FONT FACE='verdana' SIZE='2'><B>Search</B></FONT><BR></TD>
</TR>
<TR>
	<TD ALIGN='CENTER' VALIGN='CENTER' BGCOLOR='#CDCDCD'>
	<FORM METHOD='POST' ACTION='search.php'>
	<INPUT TYPE='hidden' NAME='search_section' VALUE='All'>
	<INPUT TYPE='text' NAME='search_input' MAXLENGTH='30' SIZE='14'>
	<INPUT TYPE='submit' VALUE='Search'></FORM>
	</FONT></TD>
</TR>
</TABLE>		<br>
		<TABLE WIDTH='190' STYLE='BORDER: 1px solid black;' CELLSPACING='0' CELLPADDING='2'>
<TR>
	<TD ALIGN='LEFT' BGCOLOR='#0099FF' STYLE='BORDER-RIGHT: hidden; BORDER-BOTTOM: 1px solid black; BORDER-LEFT: hidden;'>
	<FONT FACE='verdana' SIZE='2'><B>GBADEV.ORG Stats</B></FONT><BR></TD>
</TR>
<TR>
<TD ALIGN='LEFT' BGCOLOR='#CDCDCD'>


<B>Visitors:</B><BR>
<B>Days Online:</B> 6784<BR>

<B>Articles:</B> 550<BR><B>Games:</B> 388<BR><B>Demos:</B> 237<BR><B>Tools:</B> 176<BR>
</FONT></TD>
</TR>
</TABLE>		<br>
		<TABLE WIDTH='190' STYLE='BORDER: 1px solid black;' CELLSPACING='0' CELLPADDING='2'>
<TR>
	<TD ALIGN='LEFT' BGCOLOR='#0099FF' STYLE='BORDER-RIGHT: hidden; BORDER-BOTTOM: 1px solid black; BORDER-LEFT: hidden;'>
	<FONT FACE='verdana' SIZE='2'><B>Forum Stats</B></FONT><BR></TD>
</TR>
<TR>
	<TD ALIGN='LEFT' BGCOLOR='#CDCDCD'>
<B>Top Posters:</B><BR>

1. <A HREF='http://forum.gbadev.org/profile.php?mode=viewprofile&u=180'>tepples</A> (12198)<BR>2. <A HREF='http://forum.gbadev.org/profile.php?mode=viewprofile&u=146'>sgeos</A> (2421)<BR>3. <A HREF='http://forum.gbadev.org/profile.php?mode=viewprofile&u=5846'>HyperHacker</A> (2404)<BR>4. <A HREF='http://forum.gbadev.org/profile.php?mode=viewprofile&u=1120'>sajiimori</A> (2226)<BR>5. <A HREF='http://forum.gbadev.org/profile.php?mode=viewprofile&u=2686'>keldon</A> (2158)<BR><BR><B>Members:</B> 11811<BR><B>Articles:</B> 175447<BR>
</FONT></TD>
</TR>
</TABLE></TD>
	</TR>
</TABLE>
</FONT>
</BODY>
</HTML>