
<!DOCTYPE html>
<HTML>
<HEAD>
	<TITLE>Gameboy Advance Development</TITLE>
	<STYLE TYPE='text/css'>
		<!--
		a.menu:link     { font: 14pt verdana; color: #000000; text-decoration: none; }
		a.menu:visited     { font: 14pt verdana; color: #000000; text-decoration: none; }
		a.menu:visited:hover     { font: 14pt verdana; color: #000000; text-decoration: none; }
		a:link          { font: bold 10pt verdana; color: #3333FF; text-decoration: none; }
		a:visited       { font: bold 10pt verdana; color: #3333FF; text-decoration: none; }
		a:visited:hover { font: bold 10pt verdana; color: #3333FF; text-decoration: none; }
		// -->
	</STYLE>
	<LINK HREF='http://rss.gbadev.org/feed.php' REL='alternate' TITLE='GBADEV.ORG RSS' TYPE='application/rss+xml'>
	<META HTTP-EQUIV='Content-Type' CONTENT='text/html; charset=iso-8859-1'>
	<META HTTP-EQUIV='Content-Style-Type' CONTENT='text/css'>
</HEAD>

<BODY BGCOLOR='#FFFFFF' TEXT='#000000'>

<TABLE BORDER='0' CELLSPACING='5' CELLPADDING='0' WIDTH='800'>
	<TR>
		<TD WIDTH='160'></TD>
		<TD ALIGN='CENTER' BGCOLOR='#FFFFFF'><IMG SRC='gbadev.png' WIDTH='600' HEIGHT='54' ALT='logo'></TD>
		<TD WIDTH='200'></TD>
	</TR>
	<TR>
		<TD VALIGN='TOP' WIDTH='170' BGCOLOR='#FFFFFF'>
		<TABLE WIDTH='165' STYLE='BORDER: 1px solid black;' CELLSPACING='0' CELLPADDING='2'>
<TR>
	<TD ALIGN='LEFT' BGCOLOR='#0099FF' STYLE='BORDER-RIGHT: hidden; BORDER-BOTTOM: 1px solid black; BORDER-LEFT: hidden;'>
	<FONT FACE='verdana' SIZE='2'><B>Menu</B></FONT><BR></TD>
</TR>
<TR>
	<TD ALIGN='LEFT' BGCOLOR='#CDCDCD'>
	<FONT FACE='verdana'>
	<A HREF='index.php' CLASS='menu'>Main</A><BR>
	<A HREF='about.php' CLASS='menu'>About</A><BR>
	<A HREF='search.php' CLASS='menu'>Search</A><BR>
	<A HREF='submit.php' CLASS='menu'>Submit News</A><BR>
	<A HREF='archive.php' CLASS='menu'>News Archive</A><BR>
	<A HREF='http://forum.gbadev.org' CLASS='menu'>Forum</A><BR>
	<A HREF='contact.php' CLASS='menu'>Contact Us</A><BR>
	<br>
	<A HREF='tools.php' CLASS='menu'>Tools</A><BR>
	<A HREF='demos.php' CLASS='menu'>Games/Demos</A><BR>
	<A HREF='sources.php' CLASS='menu'>Sourcecode</A><BR>
	<A HREF='docs.php' CLASS='menu'>Documentation</A><BR>
	<A HREF='hardware.php' CLASS='menu'>Hardware</A><BR>
	<A HREF='developers.php' CLASS='menu'>Developers</A><BR>
	</FONT></TD>
</TR>
</TABLE></TD>
		<TD VALIGN='TOP' WIDTH='600' BGCOLOR='#FFFFFF'>
		<TABLE WIDTH='600' STYLE='BORDER: 1px solid black;' CELLSPACING='0' CELLPADDING='2'>
		<TR>
			<TD ALIGN='LEFT' BGCOLOR='#0099FF' STYLE='BORDER-RIGHT: hidden; BORDER-BOTTOM: 1px solid black; BORDER-LEFT: hidden;'>
			<FONT FACE='verdana' SIZE='2'><B>Developers</B></FONT></TD>
		</TR>
		<TR>
			<TD ALIGN='LEFT' BGCOLOR='#CDCDCD'>
			<FONT FACE='verdana' SIZE='2'>

The following developers have contributed with material on this site...<BR><BR><A HREF='?author=540'>3DSage</A><BR><A HREF='?author=446'>A.V. Ebbesen</A><BR><A HREF='?author=3'>Aaron Rogers</A><BR><A HREF='?author=4'>Aaron Shadis</A><BR><A HREF='?author=412'>Adam Holmes</A><BR><A HREF='?author=247'>Adam Tierney</A><BR><A HREF='?author=5'>Adler / HardNULL</A><BR><A HREF='?author=342'>AgentQ</A><BR><A HREF='?author=404'>Akolade</A><BR><A HREF='?author=447'>Alberto Demichelis</A><BR><A HREF='?author=371'>alek</A><BR><A HREF='?author=250'>Aleksi Eeben</A><BR><A HREF='?author=251'>Alexander Babichev</A><BR><A HREF='?author=343'>Alexander Dimitriadis</A><BR><A HREF='?author=252'>Alexander Gebers</A><BR><A HREF='?author=8'>Alexander Markley</A><BR><A HREF='?author=442'>Alienchild</A><BR><A HREF='?author=400'>Allen Ussher</A><BR><A HREF='?author=9'>AmPz</A><BR><A HREF='?author=253'>Amy</A><BR><A HREF='?author=254'>Anarko</A><BR><A HREF='?author=503'>Ancor productions</A><BR><A HREF='?author=510'>Anders Hansson</A><BR><A HREF='?author=255'>Andre Perrot</A><BR><A HREF='?author=372'>Andreas Timmermann</A><BR><A HREF='?author=256'>Andrew</A><BR><A HREF='?author=477'>Andrew Best</A><BR><A HREF='?author=10'>Andrew Cox</A><BR><A HREF='?author=391'>Andrew Holbrook</A><BR><A HREF='?author=11'>Andrew May</A><BR><A HREF='?author=12'>Andrew P. Bilyk</A><BR><A HREF='?author=13'>Andrew Walker</A><BR><A HREF='?author=257'>anli</A><BR><A HREF='?author=395'>anonymous</A><BR><A HREF='?author=258'>Arcadian</A><BR><A HREF='?author=14'>Arjan Bakker</A><BR><A HREF='?author=444'>ARM</A><BR><A HREF='?author=15'>Arrow</A><BR><A HREF='?author=520'>ArugulaZ</A><BR><A HREF='?author=16'>Athlan Bertil</A><BR><A HREF='?author=495'>Avelino Herrera Morales</A><BR><A HREF='?author=416'>Ayden Wolf</A><BR><A HREF='?author=17'>Azazello</A><BR><A HREF='?author=536'>Bahnhof</A><BR><A HREF='?author=18'>BarfHappy</A><BR><A HREF='?author=356'>Bastian Pflieger</A><BR><A HREF='?author=345'>Batblaster</A><BR><A HREF='?author=445'>BeLogic</A><BR><A HREF='?author=19'>Ben Rhoades</A><BR><A HREF='?author=361'>BennyMarrou</A><BR><A HREF='?author=20'>Bersek01</A><BR><A HREF='?author=21'>Bertil H</A><BR><A HREF='?author=22'>Bitfox</A><BR><A HREF='?author=23'>blaow blaow</A><BR><A HREF='?author=528'>Bootlegger</A><BR><A HREF='?author=25'>Brendan Sechter</A><BR><A HREF='?author=448'>Brian Sowers</A><BR><A HREF='?author=27'>Bruno Vedder</A><BR><A HREF='?author=259'>buZz</A><BR><A HREF='?author=530'>byuu</A><BR><A HREF='?author=28'>C. Brandon Patterson</A><BR><A HREF='?author=379'>Cappeca</A><BR><A HREF='?author=509'>Carsten Paproth</A><BR><A HREF='?author=449'>Cearn</A><BR><A HREF='?author=427'>Celeryface</A><BR><A HREF='?author=29'>Charles Doty</A><BR><A HREF='?author=30'>Choopan Rattanapoka</A><BR><A HREF='?author=407'>Chris Adams</A><BR><A HREF='?author=31'>Chris Berry</A><BR><A HREF='?author=500'>Chris Eastwood</A><BR><A HREF='?author=32'>Chris Lord</A><BR><A HREF='?author=452'>Chris Strickland</A><BR><A HREF='?author=260'>Christer Andersson</A><BR><A HREF='?author=33'>Christophe Kohler</A><BR><A HREF='?author=34'>Chud575</A><BR><A HREF='?author=35'>cliff anderson</A><BR><A HREF='?author=368'>Clive</A><BR><A HREF='?author=36'>CODE-RED</A><BR><A HREF='?author=37'>Colin Brown</A><BR><A HREF='?author=38'>ConsoleCoder</A><BR><A HREF='?author=39'>CoolMan</A><BR><A HREF='?author=243'>Costis</A><BR><A HREF='?author=41'>Craig</A><BR><A HREF='?author=261'>Credo</A><BR><A HREF='?author=42'>ct2</A><BR><A HREF='?author=538'>CUE</A><BR><A HREF='?author=43'>cYgOr</A><BR><A HREF='?author=262'>DadyCool</A><BR><A HREF='?author=511'>Dag Ågren</A><BR><A HREF='?author=390'>dagamer34</A><BR><A HREF='?author=44'>Damian Yerrick</A><BR><A HREF='?author=46'>Damien Marshall</A><BR><A HREF='?author=47'>Damir & Pson of 8Arms</A><BR><A HREF='?author=49'>Daniel Collier</A><BR><A HREF='?author=50'>Daniel Crowley - Wilson</A><BR><A HREF='?author=436'>Daniel Fowler</A><BR><A HREF='?author=51'>Daniel McBride</A><BR><A HREF='?author=263'>Daniel Papenburg</A><BR><A HREF='?author=52'>Daniel Prati</A><BR><A HREF='?author=501'>Daniel Rauchenberger</A><BR><A HREF='?author=264'>danzig</A><BR><A HREF='?author=53'>Dario</A><BR><A HREF='?author=265'>DarkFader</A><BR><A HREF='?author=363'>DarkPhantom</A><BR><A HREF='?author=54'>dark_cloud</A><BR><A HREF='?author=55'>Darrell Blake</A><BR><A HREF='?author=266'>Darren</A><BR><A HREF='?author=267'>Dave Etherton</A><BR><A HREF='?author=56'>Dave Mejia</A><BR><A HREF='?author=57'>Dave Thomas</A><BR><A HREF='?author=366'>David Doucet</A><BR><A HREF='?author=362'>David Rorex</A><BR><A HREF='?author=364'>David Sharp</A><BR><A HREF='?author=268'>Deadsoul</A><BR><A HREF='?author=359'>Debray Matthieu</A><BR><A HREF='?author=59'>Decay</A><BR><A HREF='?author=269'>Decept</A><BR><A HREF='?author=270'>deixu</A><BR><A HREF='?author=406'>Dennis Ranke</A><BR><A HREF='?author=246'>Derek Evans</A><BR><A HREF='?author=271'>Derek P</A><BR><A HREF='?author=272'>Devon H</A><BR><A HREF='?author=61'>Devon Hsiao</A><BR><A HREF='?author=62'>DevPsx</A><BR><A HREF='?author=512'>DHG Games</A><BR><A HREF='?author=63'>diabolik</A><BR><A HREF='?author=64'>Digital Inline</A><BR><A HREF='?author=65'>dizassembla</A><BR><A HREF='?author=531'>djedditt</A><BR><A HREF='?author=453'>Djinn/WD</A><BR><A HREF='?author=274'>dj_fishstix</A><BR><A HREF='?author=66'>Don Peeke-Vout</A><BR><A HREF='?author=420'>Donnie Russell II</A><BR><A HREF='?author=67'>dooby</A><BR><A HREF='?author=68'>Dovoto</A><BR><A HREF='?author=69'>Drew Medina</A><BR><A HREF='?author=275'>Droid</A><BR><A HREF='?author=389'>DuoDreamr</A><BR><A HREF='?author=522'>DW817</A><BR><A HREF='?author=451'>EasyBuy2000</A><BR><A HREF='?author=486'>Echidna</A><BR><A HREF='?author=70'>ector^mdl</A><BR><A HREF='?author=71'>Edmund Wong</A><BR><A HREF='?author=450'>EFA</A><BR><A HREF='?author=276'>Eloist</A><BR><A HREF='?author=532'>endrift</A><BR><A HREF='?author=72'>Enfis the Paladin</A><BR><A HREF='?author=277'>Epaedu</A><BR><A HREF='?author=73'>Epitech Console DevLab</A><BR><A HREF='?author=278'>Erik Gillespie</A><BR><A HREF='?author=74'>Erik Rounds</A><BR><A HREF='?author=392'>Espagnol Pascal</A><BR><A HREF='?author=75'>Etage97</A><BR><A HREF='?author=377'>Ethos</A><BR><A HREF='?author=374'>etu etu</A><BR><A HREF='?author=546'>exelotl</A><BR><A HREF='?author=76'>exoticorn</A><BR><A HREF='?author=410'>EY</A><BR><A HREF='?author=279'>EZ-Flash</A><BR><A HREF='?author=454'>f(Dark Angel)</A><BR><A HREF='?author=525'>Fabian Vallon</A><BR><A HREF='?author=281'>Fad</A><BR><A HREF='?author=77'>fatgraham</A><BR><A HREF='?author=408'>Federico Severi</A><BR><A HREF='?author=282'>FireFly</A><BR><A HREF='?author=78'>fjsantos</A><BR><A HREF='?author=418'>fjsantos & Sergio</A><BR><A HREF='?author=455'>fl0w</A><BR><A HREF='?author=283'>Flash2Advance</A><BR><A HREF='?author=79'>Flavor</A><BR><A HREF='?author=539'>Flush</A><BR><A HREF='?author=284'>foolsgold</A><BR><A HREF='?author=285'>Forgotten</A><BR><A HREF='?author=80'>Foxy</A><BR><A HREF='?author=529'>Francesco Lombardi</A><BR><A HREF='?author=383'>Francesco Napolitano</A><BR><A HREF='?author=456'>Francis Hart</A><BR><A HREF='?author=397'>François Pessaux</A><BR><A HREF='?author=81'>Frederic</A><BR><A HREF='?author=485'>Frederic Cambus</A><BR><A HREF='?author=82'>FreeLancer Games</A><BR><A HREF='?author=83'>Frenetic</A><BR><A HREF='?author=84'>G.S./Yakuza</A><BR><A HREF='?author=434'>gauauu</A><BR><A HREF='?author=457'>gbaguy</A><BR><A HREF='?author=458'>gbajunkie</A><BR><A HREF='?author=479'>GBATools</A><BR><A HREF='?author=527'>genecyst</A><BR><A HREF='?author=382'>Gener Gabasa</A><BR><A HREF='?author=85'>gersen</A><BR><A HREF='?author=459'>GNUARM</A><BR><A HREF='?author=429'>Goldohulk</A><BR><A HREF='?author=86'>GreenGianT</A><BR><A HREF='?author=507'>Griever308</A><BR><A HREF='?author=87'>Grumpy Cat</A><BR><A HREF='?author=88'>Headspin</A><BR><A HREF='?author=89'>Hector Z & Yolanda C</A><BR><A HREF='?author=90'>Hoebot</A><BR><A HREF='?author=286'>HpJcHobbes</A><BR><A HREF='?author=378'>Hu YingHao (Eric)</A><BR><A HREF='?author=414'>Hugh Lowry</A><BR><A HREF='?author=384'>Hugo Smits</A><BR><A HREF='?author=288'>humasect</A><BR><A HREF='?author=91'>Iki</A><BR><A HREF='?author=92'>In-cubus</A><BR><A HREF='?author=93'>Insider of Defect</A><BR><A HREF='?author=94'>ioojk</A><BR><A HREF='?author=425'>IRbaboon</A><BR><A HREF='?author=291'>Isaac Rounds</A><BR><A HREF='?author=95'>Ivan</A><BR><A HREF='?author=460'>JabberWoc</A><BR><A HREF='?author=411'>Jake Reardon</A><BR><A HREF='?author=241'>James Daniels</A><BR><A HREF='?author=504'>Jamie Woodhouse</A><BR><A HREF='?author=493'>Jason Cecil</A><BR><A HREF='?author=293'>Jason Fuerstenberg</A><BR><A HREF='?author=426'>Jason Perry</A><BR><A HREF='?author=294'>Jason Wilkins</A><BR><A HREF='?author=96'>Javi</A><BR><A HREF='?author=97'>Jawn Stewart</A><BR><A HREF='?author=98'>JayC</A><BR><A HREF='?author=99'>jean-franois deverge</A><BR><A HREF='?author=100'>Jeff D</A><BR><A HREF='?author=295'>Jeff F</A><BR><A HREF='?author=101'>Jeff Katz</A><BR><A HREF='?author=102'>Jeff Massung</A><BR><A HREF='?author=2'>Jenswa</A><BR><A HREF='?author=480'>Jespa</A><BR><A HREF='?author=104'>JetSet</A><BR><A HREF='?author=105'>Jim Bagley</A><BR><A HREF='?author=110'>Jlio Csar</A><BR><A HREF='?author=296'>Joat</A><BR><A HREF='?author=461'>JoeyBell</A><BR><A HREF='?author=396'>John Copic</A><BR><A HREF='?author=524'>John Kotas</A><BR><A HREF='?author=297'>John Marco Panettiere</A><BR><A HREF='?author=516'>John Reder</A><BR><A HREF='?author=430'>John Sensebe</A><BR><A HREF='?author=107'>John Ward</A><BR><A HREF='?author=346'>johnny_north</A><BR><A HREF='?author=298'>JointJunkie</A><BR><A HREF='?author=415'>Jonah 8^]</A><BR><A HREF='?author=437'>Jonathan Raymond</A><BR><A HREF='?author=108'>JonH</A><BR><A HREF='?author=109'>Jos Monzn Melan</A><BR><A HREF='?author=496'>Joseph J Nesbella</A><BR><A HREF='?author=299'>Josh G</A><BR><A HREF='?author=300'>Josh Noble</A><BR><A HREF='?author=545'>Juan Martinez</A><BR><A HREF='?author=301'>Juan Pablo Ugarte</A><BR><A HREF='?author=419'>Julian Henn</A><BR><A HREF='?author=523'>JulianB / Jim</A><BR><A HREF='?author=302'>Julien 'Gollum' Frelat</A><BR><A HREF='?author=505'>Julien Lallev</A><BR><A HREF='?author=111'>Jum</A><BR><A HREF='?author=462'>Jylam</A><BR><A HREF='?author=112'>Ka0S</A><BR><A HREF='?author=113'>Kak The GGG & Russell Hoy</A><BR><A HREF='?author=303'>karma</A><BR><A HREF='?author=114'>Katie Holmes</A><BR><A HREF='?author=514'>Kay Hornig</A><BR><A HREF='?author=463'>Kay/Aphasia</A><BR><A HREF='?author=498'>Keith Epstein</A><BR><A HREF='?author=304'>Kervin</A><BR><A HREF='?author=305'>Kevin Weatherman</A><BR><A HREF='?author=438'>Kinski</A><BR><A HREF='?author=115'>Kojote</A><BR><A HREF='?author=394'>KrAkKeN</A><BR><A HREF='?author=387'>krom</A><BR><A HREF='?author=116'>Krzysk</A><BR><A HREF='?author=117'>Kuba</A><BR><A HREF='?author=118'>Kurt Dekker</A><BR><A HREF='?author=344'>kustom</A><BR><A HREF='?author=119'>Kyle Kienapfel</A><BR><A HREF='?author=120'>kyp4</A><BR><A HREF='?author=121'>l8night</A><BR><A HREF='?author=494'>Lars Friend</A><BR><A HREF='?author=506'>Lasse Öörni</A><BR><A HREF='?author=122'>Leigh Dyer</A><BR><A HREF='?author=123'>Leonard</A><BR><A HREF='?author=435'>Lewis Revill</A><BR><A HREF='?author=125'>limaCAT</A><BR><A HREF='?author=537'>Limp Ninja</A><BR><A HREF='?author=307'>Linus Tan</A><BR><A HREF='?author=126'>Lord Graga</A><BR><A HREF='?author=515'>lsl</A><BR><A HREF='?author=308'>Lucian Darie</A><BR><A HREF='?author=127'>Luigi Fumero and Paolo C</A><BR><A HREF='?author=388'>luna_s</A><BR><A HREF='?author=128'>Lupin</A><BR><A HREF='?author=439'>Maato</A><BR><A HREF='?author=358'>MadBob</A><BR><A HREF='?author=129'>MakSW</A><BR><A HREF='?author=130'>Manulon</A><BR><A HREF='?author=309'>maq</A><BR><A HREF='?author=310'>Marat Fayzullin</A><BR><A HREF='?author=535'>marcelo</A><BR><A HREF='?author=311'>Marco</A><BR><A HREF='?author=312'>Marcus Linkert</A><BR><A HREF='?author=131'>Mark H</A><BR><A HREF='?author=132'>Mark Pereira</A><BR><A HREF='?author=313'>Markus</A><BR><A HREF='?author=133'>Marsu</A><BR><A HREF='?author=464'>Martin Korth</A><BR><A HREF='?author=134'>Martin W</A><BR><A HREF='?author=136'>Mateus</A><BR><A HREF='?author=137'>Mathieu</A><BR><A HREF='?author=423'>Matt Current</A><BR><A HREF='?author=465'>Matt D</A><BR><A HREF='?author=314'>Matt Griffith</A><BR><A HREF='?author=376'>Matt McNicol</A><BR><A HREF='?author=315'>Matt Tighe</A><BR><A HREF='?author=422'>Matthew Carr</A><BR><A HREF='?author=138'>Matthew Eanor</A><BR><A HREF='?author=139'>Matthew Gummo</A><BR><A HREF='?author=140'>Matthew Partridge</A><BR><A HREF='?author=141'>Matthew Scales</A><BR><A HREF='?author=357'>Maxime KAISER</A><BR><A HREF='?author=142'>McGeezer</A><BR><A HREF='?author=143'>McValdemar</A><BR><A HREF='?author=144'>Mic</A><BR><A HREF='?author=145'>Michael EL-BAKI</A><BR><A HREF='?author=146'>Michael H.</A><BR><A HREF='?author=147'>Michael Iedema</A><BR><A HREF='?author=242'>Michael Shamgar</A><BR><A HREF='?author=481'>Mick Waites</A><BR><A HREF='?author=385'>Mikaus</A><BR><A HREF='?author=149'>Mike Hawkins</A><BR><A HREF='?author=150'>Mike Sheard</A><BR><A HREF='?author=151'>Mike W</A><BR><A HREF='?author=432'>mikegba</A><BR><A HREF='?author=152'>Milhouse</A><BR><A HREF='?author=466'>mista supah porno aveckno</A><BR><A HREF='?author=153'>moah</A><BR><A HREF='?author=154'>mononoque El Grillo</A><BR><A HREF='?author=316'>Mr.Spiv</A><BR><A HREF='?author=155'>MrMr[iCE]</A><BR><A HREF='?author=317'>MumblyJoe</A><BR><A HREF='?author=156'>Mystik Edge</A><BR><A HREF='?author=318'>Nafdahli</A><BR><A HREF='?author=508'>nagam</A><BR><A HREF='?author=399'>Neil Kemp</A><BR><A HREF='?author=398'>Neil McConnell</A><BR><A HREF='?author=157'>neon</A><BR><A HREF='?author=158'>Nescio 2k2</A><BR><A HREF='?author=159'>Nexcio & Gang</A><BR><A HREF='?author=488'>Nicholas Scheltema</A><BR><A HREF='?author=409'>Nick Green</A><BR><A HREF='?author=319'>Nick Vellios</A><BR><A HREF='?author=160'>Nicky Hunt</A><BR><A HREF='?author=161'>Nicolas Beck</A><BR><A HREF='?author=421'>Nicolas Robert</A><BR><A HREF='?author=162'>Nils Widmer</A><BR><A HREF='?author=163'>Nitch</A><BR><A HREF='?author=164'>NoahFex & ARMAsm</A><BR><A HREF='?author=320'>Nocturnal Entertainment</A><BR><A HREF='?author=165'>Nokturn</A><BR><A HREF='?author=381'>Nrx</A><BR><A HREF='?author=424'>Nurdogan</A><BR><A HREF='?author=249'>OneManBand</A><BR><A HREF='?author=168'>Opus</A><BR><A HREF='?author=355'>OrR</A><BR><A HREF='?author=169'>Oscar BraindeaD</A><BR><A HREF='?author=476'>Oyvind Johansen</A><BR><A HREF='?author=170'>Panit Wechasil</A><BR><A HREF='?author=171'>Para Syte</A><BR><A HREF='?author=172'>Parallax Sisters</A><BR><A HREF='?author=487'>Pastek</A><BR><A HREF='?author=173'>Paul Lay</A><BR><A HREF='?author=350'>Paul Timson</A><BR><A HREF='?author=174'>Peebrain</A><BR><A HREF='?author=321'>Peitschi</A><BR><A HREF='?author=468'>Pete</A><BR><A HREF='?author=322'>Pete Elmore</A><BR><A HREF='?author=393'>Pete Gunter</A><BR><A HREF='?author=177'>Peter Horsman</A><BR><A HREF='?author=469'>Peter Y. K. Cheung</A><BR><A HREF='?author=178'>Petes Flatmate</A><BR><A HREF='?author=179'>ph0x</A><BR><A HREF='?author=323'>Phelios</A><BR><A HREF='?author=348'>Phil Stroffolino</A><BR><A HREF='?author=180'>Philippe Guillaud</A><BR><A HREF='?author=491'>PhoenixJ</A><BR><A HREF='?author=499'>pikilipita</A><BR><A HREF='?author=533'>pitcrawler</A><BR><A HREF='?author=324'>pointbat</A><BR><A HREF='?author=181'>Predator</A><BR><A HREF='?author=182'>Premandrake</A><BR><A HREF='?author=183'>pulstar</A><BR><A HREF='?author=417'>Puzzle Dungeon Advance Group</A><BR><A HREF='?author=184'>Quinton Roberts</A><BR><A HREF='?author=542'>quisseh</A><BR><A HREF='?author=470'>Rafael Baptista</A><BR><A HREF='?author=185'>Raistlin</A><BR><A HREF='?author=471'>re-Eject</A><BR><A HREF='?author=526'>revolution</A><BR><A HREF='?author=186'>Rey Ishido</A><BR><A HREF='?author=187'>Richard Heasman</A><BR><A HREF='?author=325'>Richard Mitton</A><BR><A HREF='?author=188'>Richard van der Brugge</A><BR><A HREF='?author=472'>Richard Weeks</A><BR><A HREF='?author=189'>Rinen</A><BR><A HREF='?author=351'>Rob</A><BR><A HREF='?author=190'>Rob Blanding</A><BR><A HREF='?author=191'>Robert Parnell</A><BR><A HREF='?author=192'>Roberto Bernardinello</A><BR><A HREF='?author=360'>Robin Gravel</A><BR><A HREF='?author=193'>Romain G</A><BR><A HREF='?author=440'>Rory</A><BR><A HREF='?author=194'>Royale00</A><BR><A HREF='?author=513'>Ruben Nunez / AikenToAki</A><BR><A HREF='?author=195'>Russ Prince</A><BR><A HREF='?author=196'>SAIKOU</A><BR><A HREF='?author=197'>Sammy Fatnassi</A><BR><A HREF='?author=198'>Samuel Adolfsson</A><BR><A HREF='?author=370'>sanric</A><BR><A HREF='?author=199'>SatanicFreak</A><BR><A HREF='?author=543'>sBeam</A><BR><A HREF='?author=200'>Scania Mob/Entertainment</A><BR><A HREF='?author=482'>Schultz, die Zahlberhaft</A><BR><A HREF='?author=349'>Scott Lininger</A><BR><A HREF='?author=326'>sealFin</A><BR><A HREF='?author=403'>Sean James</A><BR><A HREF='?author=365'>Sean Norman</A><BR><A HREF='?author=201'>Sean Reid</A><BR><A HREF='?author=327'>Sector0</A><BR><A HREF='?author=202'>Sergej Kravcenko</A><BR><A HREF='?author=203'>sgstair</A><BR><A HREF='?author=204'>shad 0an</A><BR><A HREF='?author=502'>Shadowsoft Games</A><BR><A HREF='?author=205'>Shaun Southern</A><BR><A HREF='?author=206'>Shen Mansell</A><BR><A HREF='?author=386'>SimonB</A><BR><A HREF='?author=207'>SlasherX</A><BR><A HREF='?author=292'>slip</A><BR><A HREF='?author=208'>SplamSID</A><BR><A HREF='?author=519'>Spot / Up Rough / Triad</A><BR><A HREF='?author=473'>ssss</A><BR><A HREF='?author=544'>Sterophonick</A><BR><A HREF='?author=483'>stween</A><BR><A HREF='?author=209'>Subice</A><BR><A HREF='?author=534'>sverx</A><BR><A HREF='?author=328'>sweetlicks</A><BR><A HREF='?author=329'>Sylvain Rochette</A><BR><A HREF='?author=210'>Synchronizer</A><BR><A HREF='?author=211'>Taiyou</A><BR><A HREF='?author=490'>Takayama Fumihiko</A><BR><A HREF='?author=212'>tangl_99</A><BR><A HREF='?author=213'>Team Dadako</A><BR><A HREF='?author=214'>team revolution</A><BR><A HREF='?author=215'>TeleKawaru</A><BR><A HREF='?author=330'>Test Breakdown</A><BR><A HREF='?author=216'>The Black Frog</A><BR><A HREF='?author=217'>The Fallen team</A><BR><A HREF='?author=218'>The Letter M</A><BR><A HREF='?author=433'>thegamefreak0134</A><BR><A HREF='?author=331'>Thierry Costa</A><BR><A HREF='?author=219'>Thomas Carton</A><BR><A HREF='?author=332'>Thomas Happ</A><BR><A HREF='?author=428'>Thomas Hopper</A><BR><A HREF='?author=474'>Tim</A><BR><A HREF='?author=220'>Tim Cowley</A><BR><A HREF='?author=333'>Tim Trzepacz</A><BR><A HREF='?author=475'>Tinara and Tony C</A><BR><A HREF='?author=380'>Toby Jaffey</A><BR><A HREF='?author=431'>Todd Jeffreys</A><BR><A HREF='?author=334'>Tom St Denis</A><BR><A HREF='?author=401'>Tomer Shalev</A><BR><A HREF='?author=375'>tony cai</A><BR><A HREF='?author=335'>Tony Savon</A><BR><A HREF='?author=221'>Torlus</A><BR><A HREF='?author=478'>Touchstone</A><BR><A HREF='?author=336'>trapflag</A><BR><A HREF='?author=405'>Trey Arthur</A><BR><A HREF='?author=337'>tubooboo</A><BR><A HREF='?author=484'>TwoHeaded Software</A><BR><A HREF='?author=222'>Ujn Hunter</A><BR><A HREF='?author=354'>umount</A><BR><A HREF='?author=223'>unique</A><BR><A HREF='?author=224'>Uze</A><BR><A HREF='?author=240'>Version/Majic12</A><BR><A HREF='?author=225'>Vinazzani Domenico</A><BR><A HREF='?author=226'>Vince Dickinson</A><BR><A HREF='?author=227'>Vishwa Nath</A><BR><A HREF='?author=338'>Visoly</A><BR><A HREF='?author=228'>Vivid Design</A><BR><A HREF='?author=229'>Vortex</A><BR><A HREF='?author=230'>Vova & Serge</A><BR><A HREF='?author=231'>Warder1</A><BR><A HREF='?author=339'>Warp</A><BR><A HREF='?author=232'>Wayne Keenan</A><BR><A HREF='?author=233'>Weezerman</A><BR><A HREF='?author=369'>Werner Mendizabal</A><BR><A HREF='?author=340'>WhatZdat D. Pimp</A><BR><A HREF='?author=353'>WHowe</A><BR><A HREF='?author=367'>Will Thomas</A><BR><A HREF='?author=492'>wintermute</A><BR><A HREF='?author=402'>xFlasH</A><BR><A HREF='?author=341'>XG-Flash</A><BR><A HREF='?author=441'>Xjuan</A><BR><A HREF='?author=234'>XTeam Software Solution</A><BR><A HREF='?author=352'>yanos</A><BR><A HREF='?author=235'>Yarin</A><BR><A HREF='?author=236'>yaustar</A><BR><A HREF='?author=237'>Yiri T. Kohl</A><BR><A HREF='?author=238'>Yoshi(taka)</A><BR><A HREF='?author=497'>Zachery Delafosse</A><BR><A HREF='?author=347'>Zapf Bandit</A><BR><A HREF='?author=373'>Zelion</A><BR><A HREF='?author=239'>ZoneGN</A><BR><A HREF='?author=248'>_Nessie_</A><BR>
<BR></TD>
</TR>
</TABLE></TD>
<TD VALIGN='TOP' WIDTH='190' BGCOLOR='#FFFFFF'>
	<TABLE WIDTH='190' STYLE='BORDER: 1px solid black;' CELLSPACING='0' CELLPADDING='2'>
<TR>
	<TD ALIGN='LEFT' BGCOLOR='#0099FF' STYLE='BORDER-RIGHT: hidden; BORDER-BOTTOM: 1px solid black; BORDER-LEFT: hidden;'>
	<FONT FACE='verdana' SIZE='2'><B>Top Games</B></FONT><BR></TD>
</TR>
<TR>
<TD ALIGN='LEFT' BGCOLOR='#CDCDCD'>

<IMG SRC='http://gbadev.org/demos/2004Mbit_logo.png' WIDTH='184' HEIGHT='123' ALT=''><BR>1. <A HREF='demos.php?showinfo=1271'>2004Mbit Compo Game</A><BR>2. <A HREF='demos.php?showinfo=434'>Xmen V StreetFighter J Edition</A><BR>3. <A HREF='demos.php?showinfo=1279'>Another World GBA v2.1</A><BR>4. <A HREF='demos.php?showinfo=1353'>MarioBreak!</A><BR>5. <A HREF='demos.php?showinfo=1354'>FF4 Advance- The Return of Golbez</A><BR></FONT></TD>
</TR>
</TABLE>	<br>
	<TABLE WIDTH='190' STYLE='BORDER: 1px solid black;' CELLSPACING='0' CELLPADDING='2'>
<TR>
	<TD ALIGN='LEFT' BGCOLOR='#0099FF' STYLE='BORDER-RIGHT: hidden; BORDER-BOTTOM: 1px solid black; BORDER-LEFT: hidden;'>
	<FONT FACE='verdana' SIZE='2'><B>Top Demos</B></FONT><BR></TD>
</TR>
<TR>
<TD ALIGN='LEFT' BGCOLOR='#CDCDCD'>

<IMG SRC='http://gbadev.org/demos/SmashBrosAdvance.png' WIDTH='184' HEIGHT='123' ALT=''><BR>1. <A HREF='demos.php?showinfo=1275'>Smash Bros. Advance</A><BR>2. <A HREF='demos.php?showinfo=472'>Half Life</A><BR>3. <A HREF='demos.php?showinfo=1332'>Jespa3D Engine ver 1.39</A><BR>4. <A HREF='demos.php?showinfo=1276'>BulletGBA 5.0</A><BR>5. <A HREF='demos.php?showinfo=1329'>Final Fantasy 4th World Cup won by Italy</A><BR></FONT></TD>
</TR>
</TABLE>	<br>
	<TABLE WIDTH='190' STYLE='BORDER: 1px solid black;' CELLSPACING='0' CELLPADDING='2'>
<TR>
	<TD ALIGN='LEFT' BGCOLOR='#0099FF' STYLE='BORDER-RIGHT: hidden; BORDER-BOTTOM: 1px solid black; BORDER-LEFT: hidden;'>
	<FONT FACE='verdana' SIZE='2'><B>Search</B></FONT><BR></TD>
</TR>
<TR>
	<TD ALIGN='CENTER' VALIGN='CENTER' BGCOLOR='#CDCDCD'>
	<FORM METHOD='POST' ACTION='search.php'>
	<INPUT TYPE='hidden' NAME='search_section' VALUE='All'>
	<INPUT TYPE='text' NAME='search_input' MAXLENGTH='30' SIZE='14'>
	<INPUT TYPE='submit' VALUE='Search'></FORM>
	</FONT></TD>
</TR>
</TABLE>	<br>
	<TABLE WIDTH='190' STYLE='BORDER: 1px solid black;' CELLSPACING='0' CELLPADDING='2'>
<TR>
	<TD ALIGN='LEFT' BGCOLOR='#0099FF' STYLE='BORDER-RIGHT: hidden; BORDER-BOTTOM: 1px solid black; BORDER-LEFT: hidden;'>
	<FONT FACE='verdana' SIZE='2'><B>GBADEV.ORG Stats</B></FONT><BR></TD>
</TR>
<TR>
<TD ALIGN='LEFT' BGCOLOR='#CDCDCD'>


<B>Visitors:</B><BR>
<B>Days Online:</B> 6784<BR>

<B>Articles:</B> 550<BR><B>Games:</B> 388<BR><B>Demos:</B> 237<BR><B>Tools:</B> 176<BR>
</FONT></TD>
</TR>
</TABLE>	<br>
	<TABLE WIDTH='190' STYLE='BORDER: 1px solid black;' CELLSPACING='0' CELLPADDING='2'>
<TR>
	<TD ALIGN='LEFT' BGCOLOR='#0099FF' STYLE='BORDER-RIGHT: hidden; BORDER-BOTTOM: 1px solid black; BORDER-LEFT: hidden;'>
	<FONT FACE='verdana' SIZE='2'><B>Forum Stats</B></FONT><BR></TD>
</TR>
<TR>
	<TD ALIGN='LEFT' BGCOLOR='#CDCDCD'>
<B>Top Posters:</B><BR>

1. <A HREF='http://forum.gbadev.org/profile.php?mode=viewprofile&u=180'>tepples</A> (12198)<BR>2. <A HREF='http://forum.gbadev.org/profile.php?mode=viewprofile&u=146'>sgeos</A> (2421)<BR>3. <A HREF='http://forum.gbadev.org/profile.php?mode=viewprofile&u=5846'>HyperHacker</A> (2404)<BR>4. <A HREF='http://forum.gbadev.org/profile.php?mode=viewprofile&u=1120'>sajiimori</A> (2226)<BR>5. <A HREF='http://forum.gbadev.org/profile.php?mode=viewprofile&u=2686'>keldon</A> (2158)<BR><BR><B>Members:</B> 11811<BR><B>Articles:</B> 175447<BR>
</FONT></TD>
</TR>
</TABLE></TD>
</TR>
</TABLE>
</FONT>
</BODY>
</HTML>