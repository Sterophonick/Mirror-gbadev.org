First, this code first shows how to replicate a 
program across a link cable. The connected gameboy 
doesn't require a flash cart. (This part of the
code isn't mine... I got it from a demo somewhere
on gbadev.org.)

Second, it demonstrates how to exchange arbitrary 
C STRUCTs between the two gameboys for "real-time" 
exchange during a game.

The code is C and hopefully easy to follow. It doesn't
require the use of interrupts. Feel free to do
with it as you please. 

These functions are pretty new, and I've only been
able to test them on two GBAs at a time (I wish I owned 
four... ;) Also, the system doesn't do any error or drop
checking, so if the link cable gets unplugged you'll have
to start all over.
 
Many thanks to the Down to You website and Jeff's 
multiboot demo (formerly at www.devrs.com/gba) for 
getting me started.

- Scott Lininger
scott[at]scottlininger.com