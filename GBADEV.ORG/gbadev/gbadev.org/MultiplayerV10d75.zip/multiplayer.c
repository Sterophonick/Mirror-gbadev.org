//---------------------------------------------------------
//    FILE: multiplayer.c
// VERSION: 1.0 Updated 1/15/2004
//  AUTHOR: Scott Lininger (the Multiboot Replication 
//          and TTY code are not mine... only the multiplayer)
//          more at www.thingker.com/gba
//---------------------------------------------------------

#include "pin8gba.h"
#include "agbtty.h"

// the following line tells devkitadv to compile as a 
// multiboot (i.e. load the program into EWRAM instead of
// running off the cart
MULTIBOOT

// some friendlier button definitions
#define PADLEFT		!(JOY & JOY_LEFT)
#define PADRIGHT	!(JOY & JOY_RIGHT)
#define PADUP		!(JOY & JOY_UP)
#define PADDOWN		!(JOY & JOY_DOWN)
#define BUTTONA		!(JOY & JOY_A)
#define BUTTONB		!(JOY & JOY_B)



//---------------------------------------------------------
// MULTIBOOT REPLICATION FUNCTIONS (not mine... I haven't 
//     figured them out completely just yet.)
//---------------------------------------------------------

const volatile unsigned char mb_logo[] =
{
 46,0,0,234,36,255,174,81,105,154,162,33,61,132,130,10,
 132,228,9,173,17,36,139,152,192,129,127,33,163,82,190,25,
 147,9,206,32,16,70,74,74,248,39,49,236,88,199,232,51,
 130,227,206,191,133,244,223,148,206,75,9,193,148,86,138,192,
 19,114,167,252,159,132,77,115,163,202,154,97,88,151,163,39,
 252,3,152,118,35,29,199,97,3,4,174,86,191,56,132,0,
 64,167,14,253,255,82,254,3,111,149,48,241,151,251,192,133,
 96,214,128,37,169,99,190,3,1,78,56,226,249,162,52,255,
 187,62,3,68,120,0,144,203,136,17,58,148,101,192,124,99,
 135,240,60,175,214,37,228,139,56,10,172,114,33,212,248,7,
 0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,48,49,150,0,0,0,0,0,
 0,0,0,0,0,240,0,0
};

typedef struct {
	u32 reserve1[5];      //
	u8 hs_data;           // 20 ($14) Needed by BIOS
	u8 reserve2;          // 21 ($15)
	u16 reserve3;         // 22 ($16)
	u8 pc;                // 24 ($18) Needed by BIOS
	u8 cd[3];             // 25 ($19)
	u8 palette;           // 28 ($1c) Needed by BIOS - Palette flash while load
	u8 reserve4;          // 29 ($1d) rb
	u8 cb;                // 30 ($1e) Needed by BIOS
	u8 reserve5;          // 31 ($1f)
	u8 *startp;           // 32 ($20) Needed by BIOS
	u8 *endp;             // 36 ($24) Needed by BIOS
	u8 *reserve6;         // 40 ($28)
	u8 *reserve7[3];      // 44 ($2c)
	u32 reserve8[4];      // 56 ($38)
	u8 reserve9;          // 72 ($48)
	u8 reserve10;         // 73 ($49)
	u8 reserve11;         // 74 ($4a)
	u8 reserve12;         // 75 ($4b)
} MBStruct;

MBStruct mp;

static u16 mb_xfer(u16 send) {
	u16 recv;
	SIODATA = send;
	SIOCNT = SIO_MP115200 | SIO_ACTIVE;
	while(SIOCNT & SIO_ACTIVE) { }
	recv = SIOMPRECV[1];
	return recv;
}

unsigned int mb_find_gba(void) {
	u16 i;

	/* get master GBA ready for MP mode */
	SIOPAR = 0;

	/* wait for slaves to enter multiboot */
	do {
	  i = mb_xfer(0x6202);
	} while ((i & 0xff00) != 0x7200);

	return mb_xfer(0x6100);
}


unsigned int mb_send_rom(unsigned char *Client, unsigned int length)
{
	u16 i;
	u8 palette;
	u16 key;

	/* Send the header */
	mb_xfer((mb_logo[1] << 8) + mb_logo[0]);
	mb_xfer((mb_logo[3] << 8) + mb_logo[2]);
	for(i=2; i<96; i++)
	  mb_xfer((mb_logo[i*2+1] << 8) + mb_logo[i*2]);

	i = mb_xfer(0x6202);

	/* Send information about the program */
	mp.cb = 2;
	mp.pc = 0xd1;
	mp.startp = (u8 *)&Client[0xc0];
	length -= 0xc0;  /* size of program excluding header */
	length = (length + 15) & ~15; /* 16 byte units */
	if (length < 0x1c0) length = 0x1c0;
	mp.endp = (u8 *)&Client[0xc0] + length;

	palette = 0xc1;
	mp.palette = palette;

	i = mb_xfer(0x6300+palette);
	i = mb_xfer(0x6300+palette);

	mp.cd[0] = i;
	mp.cd[1] = 0xff;
	mp.cd[2] = 0xff;

	key = (0x11 + (i & 0xff) + 0xff + 0xff) & 0xff;
	mp.hs_data = key;

	i = mb_xfer(0x6400 | (key & 0xff));

	/* Execute BIOS routine to transfer program to slave unit */
	asm volatile (
	  " ldr r0,=mp\n"
	  " mov r1,#1\n"
	  " swi 0x25\n"  /* for ARM change to 0x00250000 */
	  ::: "r0","r1","r2","r8","r9","r10","r11","r12"
	);
	/* result left in r0 (I hope): 0 success, nonzero failure */
	return 0;
}



void printHex(unsigned int x) {
	unsigned int bit = 16;
	const char digits[] = "0123456789ABCDEF";

	do {
	  bit -= 4;
	  agbtty_putc(digits[(x >> bit) & 0x0f]);
	} while(bit > 0);
}


//-----------------------------------------------------------
// MULTIPLAYER VARIABLES & FUNCTIONS
//
// The following 4 global structs allow each gameboy on the 
// link cable to share information. You can alter these
// to contain whatever you like. In your game program, each
// gameboy should only make changes to its own stuct.
//
// Within each game loop, every gameboy simply calls 
// ExchangeStucts() and the contents are swapped.
//
// Please note that right now these functions do not
// check for dropped connections, so your game will 
// freeze if one of the players drops off. :(
//-----------------------------------------------------------

struct multiPlayerData0 { // controlled by player 0
	u16 x;
	u16 y;
	u8 APressed;
	u8 BPressed;
} mpData0;

struct multiPlayerData1 { // controlled by player 1
	u16 x;
	u16 y;
	u16 pressTotal;
} mpData1;

struct multiPlayerData2 { // controlled by player 2
	u16 whatever;
	u8 arbitrary;
} mpData2;

struct multiPlayerData3 { // controlled by player 3
	u16 etcetera;
} mpData3;



void ExchangePackets(u16 outPacket) {

	u16 myPlayerNumber = EWRAM[0xc5];
	if (myPlayerNumber == 0) {							// IF WE'RE THE MASTER
		while(SIOCNT & SIO_ACTIVE) { }					// wait until the bus is not active
		SIODATA = outPacket;							// post our data
		SIOCNT = SIO_MP115200 | SIO_ACTIVE | SIO_IRQ;	// initiate the transfer

	} else {											// IF NOT THE MASTER
		SIODATA = outPacket;							// just post our data
		while(!(SIOCNT & SIO_ACTIVE)) { }				// then wait until the bus becomes active
	}
	while(SIOCNT & SIO_ACTIVE) { }						// wait until it's done
	SIODATA = outPacket;								// repost our packet, in case of timing problems
}


void ExchangeStructs(int totalPlayers) {

	u16 sender,receiver,totalResponses,totalPackets,inPacketNumber,currentPacketNumber,inPacket;
	u8* targetStruct;
	u8 inData;
	u16 outPacket = 0xFFFF; // 0xFFFF is the "null" code for the IO Bus
	u16 myPlayerNumber = EWRAM[0xc5];

	// loop through all the players so they can update everyone's copy of their mpData Struct
	for (sender=0; sender<totalPlayers; sender++ ) {

		// figure out which mpData struct we're targeting and get its size
		if (sender==0) { 
			totalPackets = sizeof(mpData0);
			targetStruct = (u8*)&mpData0;
		} else if (sender==1) { 
			totalPackets = sizeof(mpData1);
			targetStruct = (u8*)&mpData1;
		} else if (sender==2) { 
			totalPackets = sizeof(mpData2);
			targetStruct = (u8*)&mpData2;
		} else { 
			totalPackets = sizeof(mpData3);
			targetStruct = (u8*)&mpData3;
		}

		// get ready to send or receive
		currentPacketNumber = 0;
		

		if (myPlayerNumber == sender) { // if we are the sender


			while (currentPacketNumber < totalPackets) { // iterate across our mpData and send it a byte at a time

				// encode the packet: the 1st 8 bits contain the packetNumber, and 9-16 contain the data
				outPacket = (currentPacketNumber<<8) + *(targetStruct+currentPacketNumber);

				
				totalResponses = 0;		// wait for everyone to say they are ready by posting the packet back to you
				while (totalResponses < totalPlayers) {
					
					totalResponses = 0;
					ExchangePackets(outPacket);

					for (receiver=0; receiver<totalPlayers; receiver++ ) {
						
						inPacket = SIOMPRECV[receiver];
						if (inPacket == outPacket) {
							totalResponses++;
						} 
					}	
				}
				
				// move on to the next packet
				currentPacketNumber++;
			}	

		} else { // we are a receiver


			while (currentPacketNumber < totalPackets) {
	
				ExchangePackets(outPacket);
				inPacket = SIOMPRECV[sender];
				inPacketNumber = (inPacket >> 8);
				inData = (u8)inPacket;

				// if it's the next packet we need, then grab it
				if (inPacketNumber == currentPacketNumber) {

					// grab our data
					*(targetStruct+inPacketNumber) = inData;
					
					// then let the sender know that we got it
					outPacket = inPacket;				
					
					currentPacketNumber++;
				
				} 
			
			}
			// send our packets out one last time to make sure the
			// master got our final confirmation
			ExchangePackets(outPacket);
		}
	}
}


//-----------------------------------------------------------
// MAIN FUNCTION
//-----------------------------------------------------------

int main(void) {

	// initialize the agbTTY for console printing	
	agbtty_init();
	agbtty_init_cursor();
	LCDMODE = 0 | LCDMODE_BG0 | LCDMODE_SPR;
	PALRAM[  0] = RGB(31,31,0);
	PALRAM[  1] = RGB( 0, 0, 0);
	PALRAM[257] = RGB(16,16, 0);

	
	int myPlayerNumber = EWRAM[0xc5];	// grab my player number (0 for master, 1-3 for slave)
	int totalPlayers = 2;				// the multiboot replication only works for one other GBA

	agbtty_puts("\n YOU ARE PLAYER #");
	agbtty_putc(myPlayerNumber | '0');

	if(myPlayerNumber == 0) { // if master
	  
	  agbtty_puts("\n\n Attach the slave via link\n cable, and Press A when you\n are ready to proceed.\n");
	  agbtty_puts("\n\n (Make sure the purple end\n of the cable is attached to\n the master gameboy.)\n\n");
	  while(!BUTTONA) { }  // wait for press

	  agbtty_puts(" Turn on slave GBA while\n pressing SELECT+START\n\n");
	  mb_find_gba();

	  /* become the master, with other players as slaves */
	  EWRAM[0xc4] = 0;
	  EWRAM[0xc5] = 0;

	  agbtty_puts(" Slave found...Sending ROM...\n\n");
	  
	  // IMPORTANT: make sure the size (2nd parameter) is at least as large as your ROM
	  mb_send_rom((unsigned char *)EWRAM, 17000);

	}
	
	// clear the screen
	agbtty_cls();

	
	// example game loop
	while(1) {

		if (myPlayerNumber==0) {
			
			if (PADRIGHT) mpData0.x++;
			if (PADLEFT) mpData0.x--;
			if (PADUP) mpData0.y--;
			if (PADDOWN) mpData0.y++;
			mpData0.APressed = BUTTONA;
			mpData0.BPressed = BUTTONB;

		} else {
			if (PADRIGHT) mpData1.x++;
			if (PADLEFT) mpData1.x--;
			if (PADUP) mpData1.y--;
			if (PADDOWN) mpData1.y++;
			if (BUTTONA || BUTTONB) {
				while (BUTTONA || BUTTONB) {} // wait for them to release button
				mpData1.pressTotal++;
			}
		}

		// all gameboys must call this once per loop
		ExchangeStructs(totalPlayers);

		agbtty_gotoxy(1, 1);
		agbtty_puts("\n YOU ARE PLAYER #"); agbtty_putc(myPlayerNumber | '0');
		agbtty_puts("\n ----------------------------");
		agbtty_puts("\n Push some buttons to see the\n data change!\n\n");
		agbtty_puts("\n mpData0.x = "); printHex(mpData0.x);
		agbtty_puts("\n mpData0.y = "); printHex(mpData0.y);
		agbtty_puts("\n mpData0.APressed = "); printHex(mpData0.APressed);
		agbtty_puts("\n mpData0.BPressed = "); printHex(mpData0.BPressed);
		agbtty_puts("\n ");
		agbtty_puts("\n mpData1.x = "); printHex(mpData1.x);
		agbtty_puts("\n mpData1.y = "); printHex(mpData1.y);
		agbtty_puts("\n mpData1.pressTotal = "); printHex(mpData1.pressTotal);


	}

}



