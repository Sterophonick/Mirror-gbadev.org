// WolfARMstein - the GBA raycasting demo
// Mic, 2001
// stabmaster_@hotmail.com | come.to/progzone
//
// Original Euphoria version be Hollow Horse Software (?)
// Even more original QBasic version by Peter Cooper (?)
//
// I basically translated the code to C, added some ugly linear shading, etc.
// Note that this program renders the world in a pretty sloppy way, 
// resulting in glitches between walls and stuff like that.
// 
// All key-input code was derived from Nokturn's key demo.
//



#include <stdlib.h>
#include <math.h>
#include "gbal.h"

#define KEYREG   *(u16 *)0x04000130


extern u16 main_pal, intro_pal1, intro_pal2;
extern u8 intro_pic1, intro_pic2, smallfont;



float sine[360],cosine[360];

float xb,yb;
float Px,Py, oldPx,oldPy;
float Bx,By;
int sa,temp;
int T, x,xTemp;
int xpos,ypos;
int dd,l,k,pix;


  u8 world[600] =
   "191919191991991199119919199199"\
   "900000000070007000011050000001"\
   "100000000070007104110500005009"\
   "900100500057077000110500003001"\
   "100004000070507011050000030009"\
   "903000000040707011050000002041"\
   "100007800040002001105000000009"\
   "905008700070007001105000066001"\
   "100000000000000011050000040009"\
   "108888800001105000000000070009"\
   "108800080005500110500000070009"\
   "108000080005500011050000000009"\
   "108000080005500110500000433009"\
   "108070000000001105000000000509"\
   "108000000000440001105000000509"\
   "108000560011050000000000230509"\
   "100000200000003200110500000609"\
   "100033300000000441105000886009"\
   "100000000001105000000008800009"\
   "919191991191191991919191919111";

u16 work_pal[256];



void CheckKeys()
{

  if (! (KEYREG & 16)) 
  {
    // Turn right
    sa += 4;
    // Reset key-bit
    KEYREG |= 16;
  }
  if (! (KEYREG & 32))
  {
    // Turn left
    sa = ((sa+356) % 360);
    KEYREG |= 32;
  }
  
  T = (T+sa)>>1;
  xTemp = (T % 360);

  if (! (KEYREG & 64))
  {
     // Up..
     oldPx = Px;
     oldPy = Py;
     Px += sine[xTemp];
     Py += cosine[xTemp];
     // Is there a wall in the way ?
     if (*(&world[0] + ((int)(Py/10)*30) + (int)(Px/10)) - '0')
     {
        Px = oldPx;
        Py = oldPy;
     }
     KEYREG |= 64;
  }
  if (! (KEYREG & 128))
  {
     // ..down
     oldPx = Px;
     oldPy = Py;
     Px -= sine[xTemp];
     Py -= cosine[xTemp];
     if (*(&world[0] + ((int)(Py/10)*30) + (int)(Px/10)) - '0')
     {
        Px = oldPx;
        Py = oldPy;
     }
    KEYREG |= 128;
  }
  
}



void draw_box(int x1, int y1, int x2, int y2, u8 col)
{
  __asm
  {
    mov r2,BACK

    mov r0,y1

    mov r1,#240
    mul r1,r0,r1
    mov r0,x1
    add r0,r0,r1
    add r0,r0,r2

    mov r2,x2
    mov r1,x1
    sub r2,r2,r1
    add r2,r2,#1

    mov r1,y2
    mov r3,y1
    sub r1,r1,r3
    add r1,r1,#1

    mov r3,#240
    sub r3,r3,r2

    mov r4,col
    mov r5,r4,lsl #8
    orr r4,r4,r5
    mov r5,r4,lsl #16
    orr r4,r4,r5

    boxYloop:
      mov r5,r2
      mov r6,r5,lsr #2
      and r5,r5,#3
      boxXloop:
        str r4,[r0],#4
        subs r6,r6,#1
      bne boxXloop
      orrs r5,r5,r5
      beq noTail
      boxTail:
        strb r4,[r0],#1
        subs r5,r5,#1
      bne boxTail
      noTail:
      add r0,r0,r3
      subs r1,r1,#1
    bne boxYloop
  }
} 



void fade_in(u16 *src_pal, u16* trgt_pal)
{
u16 r1,g1,b1;
u16 r2,g2,b2;
u16 sc,tc;
int i;
  for (i=0; i<256; i++)
  {
    sc = src_pal[i];
    tc = trgt_pal[i];
    r1 = (sc&31); r2 = (tc&31); if (r1<r2) r1++;

    sc >>=5; tc >>= 5;
    g1 = (sc&31); g2 = (tc&31); if (g1<g2) g1++;

    sc >>= 5; tc >>= 5;
    b1 = (sc&31); b2 = (tc&31); if (b1<b2) b1++;

    src_pal[i] = ((b1<<10)|(g1<<5)|r1);
  }
}



void delay(int num)
{
    __asm
   {
    mov r0, #0x4000006
    mov r2,num
    delay_loop:
      wait_once:
        ldrh r1,[r0]
        cmp r1,#160
      bne wait_once
      subs r2,r2,#1
    bne delay_loop
   }
}




int GBA_main()
{
float f;
int i,t;


  for (f=0; f<360; f+=1)
  {
    sine[(int)f] = (float)(2.0f*sin(f*3.1415926f/180.0f));
    cosine[(int)f] = (float)(2.0f*cos(f*3.1415926f/180.0f));
  }



  gbalSetMode(_240x160x1x256_);
  gbalSetFont(&smallfont);
  gbalDisable(GBAL_DMA_CLEAR);


  //############ <Intro> ############
  delay(1200);
  gbalSetPalette(BACKGROUND, &work_pal[0], 256);
  srccopy8(90,65, 64,20, &intro_pic1);
  gbalTextOut(94,100, 33, "Gives You");
  gbalSwapBuffers();
  for (i=0;i<32;i++)
  {
    fade_in(&work_pal[0], &intro_pal1);
    delay(50);
    gbalSetPalette(BACKGROUND, &work_pal[0], 256);
  }
  delay(1100);
  gbalSetColor(BACKGROUND, 33, ((30<<10)|(28<<5)|28));
  delay(5000);

  gbalSwapBuffers();
  gbalClearBuffer(0);


  gbalSetPalette(BACKGROUND, &intro_pal2, 256);
  srccopy8(0,0, 240,160, &intro_pic2);
  gbalTextOut(78,110, 96, "Press B button");

  gbalSwapBuffers();

  // Wait for B-button to be pressed. 
  // (the compiler tried to be smart so I had to use this ugly code)
  __asm
  {
   mov r0,#0x04000130
   wait_for_B:
     ldrh r1,[r0]
     and r1,r1,2
     cmp r1,#0
   bne wait_for_B
  } 
  KEYREG |= 2;

  gbalSwapBuffers();
  gbalSetPalette(BACKGROUND, &main_pal, 256);
  //############ </Intro> ############
  

  //############ <Main> #############
  Px = 29.0f;
  Py = 19.0f;
  sa = 0;

  while (1)
  {
    for (i=0; i<19200; i+=4)
    {
     // Set upper half of screen to color 150 (light blue)
     *(u32 *)(BACK+i) = 2526451350;

     // Set lower half of screen to color 205 (light brown)
     *(u32 *)(BACK+19200+i) = 3452816845;
    }


  // Use 60 degrees FOV
  T = sa+60;

  for (t=sa; t<T; t++)
  {
    xTemp = (t % 360);
    xb = (sine[xTemp] / 2.0f);
    yb = (cosine[xTemp] / 2.0f);
    Bx = Px;
    By = Py;
    l = 0;
    k = 0;

    // Repeat until an intersection is found
    while (!k)
    {
      Bx += xb;
      By += yb;
      l++;
      k = (int)(*(&world[0] + ((int)(By/10.0f)*30) + (int)(Bx/10.0f)) - '0');
    }

    // Calculate the height of the cell
    dd = 1000/l;
    if (dd>79) dd = 79;
    if (dd<-79) dd = -79;

    // Calculate the color based on the distance
    pix = (l*15)/100;
    if (pix>15) pix = 15;

    x = (t-sa)<<2;
    draw_box(x,79-dd, x+3,80+dd, (u8)((k<<4)-pix));
  }

    gbalSwapBuffers();
    CheckKeys();
  }
  //############ </Main> #############

  return 0;
}

       





