Fake Plasma Demo

(c) 2002 by The Night Howler


Well, this is my first demo for the Game Boy Advance... I know nowadays nobody
does that anymore, because "C++ r00l3Z", etc., but this weekend I was in a 
good mood and I decided to code something in Thumb Assembler. Well, I learnt
many things doing so (and I'm afraid I still have much more to learn...)

But now for the serious stuff.

This demo is a Fake Plasma demo, which is 444 bytes long. It is Fake because
the plasma pattern is not dynamically moving during the demo and the whole
stuff is a trick of shifting palette values... But it's interesting because
it is very short, even if the ASM code is not really optimized. Gee... A compo
of 512-byte sized GBA demos would be great ! One megabyte is really too big
for me ^_^

After you'll have watched it for about 20 secs., you may tell yourself "gee,
that thing is butt slow" ! Well, you're right. So I included 2 versions of the
demo : one synced at 60 fps, and the other at 30 fps. I prefer the second one
because the effect is more "organic" :)

Tell me what you think about it !

Best regards,

The Night Howler


P.S. : Sorry for the lame English writing style I have... I try to do my best, but that's not my mother tongue !
