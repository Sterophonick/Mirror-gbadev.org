			u8* scr = (u8*)VideoBuffer;
			
			for(y = (SCREEN_HEIGHT + slice_height) / 2; y < SCREEN_HEIGHT; y++)
			{
				/* calculate distance to floor */
				//s32 floor_dist = (64/*(SCREEN_HEIGHT/2)*/ * PROJECTION_DISTANCE) / (2*(y - (SCREEN_HEIGHT/2)));
				s32 floor_dist = floor_dist_table[y - (SCREEN_HEIGHT/2)];
				s32 floor_x, floor_y;
			
				TRACE("floor dist: %d ", floor_dist);
				
				floor_dist = floor_dist * one_over_cos_b;
				
				TRACE("adjusted floor dist: %d ", FIXED_TO_INT(floor_dist));
				
				/* work out position of intersection */
				floor_x = px + ((floor_dist * cos_a) >> 16);
				floor_y = py - ((floor_dist * sin_a) >> 16);
				
				floor_x = floor_x - ((floor_x >> 6) << 6);
				floor_y = floor_y - ((floor_y >> 6) << 6);
				
				TRACE("fx: %d, fy: %d\n", floor_x, floor_y);
				
				scr[(y*240) + i*2] = walltextures_Bitmap[(64*64*3) + ((floor_y) * 64) + (floor_x)];
			}

