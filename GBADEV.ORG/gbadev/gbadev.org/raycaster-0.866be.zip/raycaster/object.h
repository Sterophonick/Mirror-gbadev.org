
typedef struct
{
	s32 x, y;
	const u8* tex;
} texobject;
