#ifndef __interrupt_h
#define __interrupt_h

#include "gba.h"

extern void (*IntrTable[14])(void);

void interrupt_dummy(void) CODE_IN_IWRAM;
void interrupt_key(void) CODE_IN_IWRAM;
void interrupt_init(void) CODE_IN_IWRAM;

#endif	// __interrupt_h
