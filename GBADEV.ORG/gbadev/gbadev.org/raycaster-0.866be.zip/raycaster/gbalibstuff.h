// Bank stuff.
void gba_initbank(void);
void gba_swapbank(void);
void gba_setdbank(byte n);
void gba_setwbank(byte b);
void gba_vsync(void);


