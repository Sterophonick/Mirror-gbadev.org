#include <math.h> 	
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <malloc.h>

#include "gba.h"       
#include "dispcnt.h"
#include "keypad.h"
#include "interrupt.h"

#include "trig.h"
#include "config.h"
#include "object.h"

#define FIXED(x) ((int)((x) * 256))
#define FIXED_TO_INT(x) ((x)  >> 8)

void print(char *s);

void objs_draw(s32 px, s32 py, s32 angle, s32* dist_buf);
