s32 gba_sin(s32 angle);
s32 gba_cos(s32 angle);
s32 gba_tan(s32 angle);
s32 gba_one_over_sin(s32 angle);
s32 gba_one_over_cos(s32 angle);
s32 gba_one_over_tan(s32 angle);
s32 gba_atan(s32 y, s32 x);

s32 angle_diff(s32 a1, s32 a2);
s32 angle_normalise(s32 a);

u32 pythag(s32 dx, s32 dy) CODE_IN_IWRAM;
