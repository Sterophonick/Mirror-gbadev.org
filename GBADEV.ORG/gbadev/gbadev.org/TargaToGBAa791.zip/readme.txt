Despite the name of the application its is actually capable to convert several fileformats.
It convert TARGA, PNG, JPEG, BMP, TIFF and LBM files into .h files that you can include to your gba application.
You can also choose between the palette based mode4 or mode3/mode5 for 15bit bitmapped mode.

Happy converting :)

/maq - maq777@hotmail.com


Usage: TargaToGBA.exe [mode3|mode4|mode5] [picture.bmp] [picture.h]
