//---------------------------------------------------//
//         Little AGB Library by Nokturn             //
//            Version for: Fields of Battle          //
//                                                   //
//    First Version: 29. Nov. 2000                   //
//    Last  Version: 21. Apr. 2001                   //
//---------------------------------------------------//

 // Defines first

#define AGBRULEZ 1          // Define some morale. What would a demo without morale be? ;) 

#define PI 3.141592654

 // Here go the BITXX Macros to spare me some typing later and make the code more readable

#define BIT00 1
#define BIT01 2
#define BIT02 4
#define BIT03 8
#define BIT04 16
#define BIT05 32
#define BIT06 64
#define BIT07 128
#define BIT08 256
#define BIT09 512
#define BIT10 1024
#define BIT11 2048
#define BIT12 4096
#define BIT13 8192
#define BIT14 16384
#define BIT15 32768

#define KEY_A      BIT00 
#define KEY_B      BIT01
#define KEY_SELECT BIT02
#define KEY_START  BIT03
#define KEY_RIGHT  BIT04
#define KEY_LEFT   BIT05
#define KEY_UP     BIT06
#define KEY_DOWN   BIT07
#define KEY_R      BIT08
#define KEY_L      BIT09

#define CHAR(x) 64*x

 // Some "new" types. A must-be.

typedef unsigned char u8;
typedef unsigned short u16;
typedef unsigned long u32;

typedef signed char s8;
typedef signed short s16;
typedef signed long s32;


 // Registers

#define DISPCNT    *( u32 * )0x04000000
#define VCOUNT     *( u16 * )0x04000006
#define DISPSTAT   *( u16 * )0x04000004
#define P1         *( u16 * )0x04000130

#define BG0CNT     *( u16 * )0x04000008
#define BG1CNT     *( u16 * )0x0400000A
#define BG2CNT     *( u16 * )0x0400000C
#define BG3CNT     *( u16 * )0x0400000E

#define TM0D       *( u16 * )0x04000100
#define TM0CNT     *( u16 * )0x04000102

#define COLEV      *( u16 * )0x04000052
#define COLY       *( u16 * )0x04000054
#define BLDMOD     *( u16 * )0x04000050

#define MOSAIC     *( u16 * )0x0400004C

#define BG0HOFS    *( u16 * )0x04000010
#define BG0VOFS    *( u16 * )0x04000012
#define BG1HOFS    *( u16 * )0x04000014
#define BG1VOFS    *( u16 * )0x04000016
#define BG2HOFS    *( u16 * )0x04000018
#define BG2VOFS    *( u16 * )0x0400001A
#define BG3HOFS    *( u16 * )0x0400001C
#define BG3VOFS    *( u16 * )0x0400001E



 // GFX Specific

#define PALBG      *( u16 * )0x05000000
#define PALOBJ     *( u16 * )0x05000200

#define OBJDATA    *( u32 * )0x06010000
#define OAM        *( u16 * )0x07000000




#define BGC00      *( u32 * )0x06000000
#define BGC01      *( u32 * )0x06004000
#define BGC02      *( u32 * )0x06008000
#define BGC03      *( u32 * )0x0600C000

#define BGS07      *( u16 * )0x06003800
#define BGS15      *( u16 * )0x06007800
#define BGS23      *( u16 * )0x0600B800
#define BGS31      *( u16 * )0x0600F800



u32 *BgC0 = &BGC00; // Pointers to data blocks. Read the AGBDevTut-2.txt file for an explanation
u32 *BgC1 = &BGC01;
u32 *BgC2 = &BGC02;
u32 *BgC3 = &BGC03;

u16 *BgS7 = &BGS07;


// Now some pointers which we can use in the code

u16 *PaletteBG     = &PALBG;
u16 *PaletteOBJ    = &PALOBJ;
u32 *ObjectData    = &OBJDATA;
u16 *Oam           = &OAM;
u16 *Timer0Data    = &TM0D;

u16 i,j,k;   // Counter values

// Function that returns a RGB color in 15bit format 

u16 RRGBColor( u8 R, u8 G, u8 B )          // Uses u8 because it only needs 5 bits. Int is waste of speed.
 { 
  return ((R)|(G<<5)|(B<<10));
 }

 // Function to wait for Vertical Sync. I took Eloist's ASM Version

void WaitForVSync()
{
  __asm
   {
    mov 	r0, #0x4000006
    scanline_wait:
     ldrh	r1, [r0]
     cmp	r1, #160
    bne 	scanline_wait
   }
}




// Copies an 8x8 sprite from a file
 void Copy8x8( u32 x, u32 y, u32 wholex, u32 *Src, u32 *Dest )
 {
	 u8 k, l;
	 for( k = 0; k < 8; k++ )
		 for( l = 0; l < 2; l++ )
		 {
			 Dest[((k<<1)+l)]=Src[(k+(y<<3))*(wholex<<1)+l+(x<<1)];
		 }
 }


 // A function to assign and copy a BG to char/screening Data... 
 // Parameters: xsize = horizontal size of image / 8
 //             ysize = vertical   size of image / 8
 //             Screening = Pointer to your screening start
 //             Data = Pointer to VRAM bg data
 //             Y/XFill = How many fills: if = 1, then it's not repeated e.g. to fill a 256*256 with a 32*32 you write XFill = YFill = 8
 //             BmpData: Pointer to raw file ( 256 colors )
 //             CharNum = First characer number of the bg screen, usefull if you want to put 2 bgs into one block
 //             XOffset, YOffset = Offsets ( *8 ) are added to the tiles - e.g. to copy to the lower half of the screen
 // Note: If you don't copy into the whole bg, remember that the bg is first filled with your first 8x8 tile in the image - it is not transparent
 void CopyAndAssignBg( u8 xsize, u8 ysize, u16 *Screening, u32 *Data, u8 XFill, u8 YFill, u32 *BmpData, u16 CharNum, u8 XOffset, u8 YOffset )
 {
	 u8 k, l;

	 for( i = 0; i < ysize; i++ )
		 for( j = 0; j < xsize; j++ )
			 Copy8x8( j, i, xsize, BmpData, Data+((i<<4)*xsize+(j<<4)) );

		 for( i = 0; i < 1024; i++ ) Screening[i]=0+CharNum;
	 
	 for( i = 0; i < ysize; i++ )
		 for( j = 0; j < xsize; j++ )
			 for( k = 0; k < YFill; k++ )
				 for( l = 0; l < XFill; l++ )
					 Screening[((i+YOffset+xsize*k)<<5)+(j+XOffset+xsize*l)]=i*xsize+j+CharNum;
 }




// Copies 32bit data

void Copy32( u32 HowMuch, u32 *Src, u32 *Dest )
{
 u32 i;
 for( i = 0; i < HowMuch; i++ ) Dest[i] = Src[i];
}

// A stupid function that waits a certain number of VSyncs... well, it tries to ;)

void Wait( u32 HowManyVSyncs )
{
	u8 i,j;
	u32 Waiter;
	for( Waiter = 0; Waiter < HowManyVSyncs; Waiter++ )
	{
		WaitForVSync();
		for( i = 0; i < 100; i++ ) j = i*32/3; // Do something stupid
	}
}

// These are mosaic functions. aWait is the frames to wait between a mosaic. Try out EnMosaic( 1 ) to EnMosaic( 10 )

void EnMosaic( u32 aWait )
{
	s8 MosaicSize;
	for( MosaicSize = 0; MosaicSize < 16; MosaicSize++ )
	{
		MOSAIC = (MosaicSize)|( MosaicSize<<4)|(MosaicSize<<8)|(MosaicSize<<12); 
		Wait( aWait );
	}
}

void DeMosaic( u32 aWait )
{
	s8 MosaicSize;
	for( MosaicSize = 15; MosaicSize >= 0; MosaicSize-- )
	{
		MOSAIC = (MosaicSize)|( MosaicSize<<4)|(MosaicSize<<8)|(MosaicSize<<12); 
		Wait( aWait );
	}
}


// Loads a palette from a file converted by convpal.exe by me: First argument is a pointer to a palette and second, the 
// palette you want to write to
void LoadPalette( u8 *aPal, u16 *addrPal )
{
	u16 i,j=0;
	for( i = 0; i < 768; i+=3 )
	{		
		addrPal[j] = RRGBColor( aPal[i], aPal[i+1], aPal[i+2] );
		j++;
	}
}

void ClearOAM() // Sets all objects out of screen = clear
{
	for( i = 0; i < 128;i++ )
	{
		Oam[(i<<2)+0] = 161 | BIT13;
		Oam[(i<<2)+1] = 241;
		Oam[(i<<2)+2] = 0;
		Oam[(i<<2)+3] = 0;
	}
}



// Next function is very FoB specific: it fades partially out ( change Pahse < 10 to Phase < 16 for complete fade )
// It also doesn't fade OBJs. To fade objs, add BIT05 to the BLDMOD below
void FadeOut( u32 aWait ) // Not completely
{
	s8 Phase;
	BLDMOD = 0 | BIT00 | BIT01 | BIT02 | BIT03 | BIT07 | BIT06 | BIT05;
	for( Phase = 0; Phase < 10; Phase++ )
	{
		COLY = Phase;
		Wait( aWait );
	}
}

// The same as above, but reverse Change 10 to 16 for complete fade and add BIT05 to the BLDMOD write for OBJ fade

void FadeIn( u32 aWait )
{
	s8 Phase;
	BLDMOD = 0 | BIT00 | BIT01 | BIT02 | BIT03 | BIT07 | BIT06 | BIT05;
	for( Phase = 0; Phase < 10; Phase++ )
	{
		COLY = 10-Phase;
		Wait( aWait );
	}
}

// Copies 32x32 data from image to ObjectData. Image should be 32*X where X is at least 32
 void Copy32x32( u32 *src, u32 *dest )
 {
	 for( i = 0; i < 4; i++ )
		 for( j = 0; j < 4; j++ )
			 Copy8x8( j, i, 4, src, dest+((i<<6)+(j<<4)) );
 }

// And as a bonus the same, only with 16x16 tiles
 void Copy16x16( u32 *src, u32 *dest )
 {
	 Copy8x8( 0, 0, 2, src, dest+0 );
	 Copy8x8( 1, 0, 2, src, dest+16 );
	 Copy8x8( 0, 1, 2, src, dest+32 );
	 Copy8x8( 1, 1, 2, src, dest+48 );
 }
