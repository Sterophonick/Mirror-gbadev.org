//---------------------------------------------------//
//             Fields of Battle Header               //
//               by Nokturn    Nokturn@agbdev.net    //
//                                                   //
//    First Version: 20. Apr. 2001                   //
//    Last  Version: 21. Apr. 2001                   //
//---------------------------------------------------//

// Defines
// Figure types:

#define FIG_1Player 1        // The player is controlled by the keys, the monsters by AI of course
#define FIG_2Player 2        // The second player
#define FIG_LittlePlant  3   // An evil plant thing...
#define FIG_LittleDevil  4   // An round little devil with horns


 // Directions for functions like Monster_Move( ... )

#define UP 1
#define DOWN 2
#define LEFT 3
#define RIGHT 4

// File import

 extern u8  pal_bg;
 extern u8  pal_obj;
 extern u8  map_map1;
 extern u32 gfx_tiles;
 extern u32 gfx_sprites;
 extern u32 gfx_clouds;
 extern u32 gfx_cloudshadows;
 extern u32 gfx_fighters;
 extern u32 gfx_water;


// The main struct for players & monster

 typedef struct Figure   // Figure stands for players and monsters
 {
	 u8 Type;              // What type of figure is this? See defines for figure types
	 u8 Frame;             // Frame 1 or 2 display - used for animation
	 s8 HP, MaxHP;                // Hitpoints ;) It's an RPG after all 
	 u8 X, Y, MapX, MapY;  // X and Y are screencoords, MapX & MapY are grid coords ( on what tile the figure is )
	 u8 AICounter;               // A little AI internal variable
	 u8 AIDir;             // Dir of movement

 } Figure;


// Variables we will use in the game:

 u8 Map[30][20];  // This is the game map which we will fill up from a file...
 u8 CMap[30][20]; // Collision map. Stores 22 when it's an empty field, or the monster number
 Figure Monsters[22]; // The player is nr. 0, player 2 is number 1. The others really are monsters :)
 u8 Game_MonstersAlive = 0; // Guess what that is ;)

 // Pointers to the Screening and Data areas which I layed out for this game

 u32 *BG0Data       = &BGC00;
 u16 *BG0Screening  = &BGS07;

 u32 *BG1Data       = &BGC01;
 u16 *BG1Screening  = &BGS15;

 u32 *BG2Data       = &BGC03;
 u16 *BG2Screening  = &BGS31;

 u32 *BG3Data       = &BGC02;
 u16 *BG3Screening  = &BGS23;


 // Clouds movement - used for BG offsets later

 u16 CloudsOffX=0, CloudsOffY=0;

 // Coefficients for Color Special Effect Register-Variables. The REGISTERS are WRITE only so we have to keep the value in a var.
 // Note: I noticed that reading is not needed in this game, but it's a good example nonetheless

 u16 VarCOLEV = 0;

 // Function declarations

void Video_SetupGfx( void );    // Set gfx mode ( mode 0 ), setup bgs, load all gfx etc.       
void Video_RenderMap( void );   // Writes the tiles specified in array Map[30][20]  to background 0
void Video_DisplayMonsters( void ); // Writes all monsters inclusive reflections into the OAM
void Video_MoveBackgrounds( void ); // Scrolls all BGs 
void Video_DisplayMonsterHearts( u8, u8 ); // Game_Combat(...) internal function to write hearts to OAM

void Input_ProcessKeys( void ); // Gets keys of both players and executes movement

void Game_LoadMap( u8 * );  // Copies a map file ( map1.map ) into the Map[30][20] array
void Game_ResetMonsters( void );
void Game_ResetPlayers( void ); // Inits player states
void Game_ResetCollisionMap( void ); // Clears CMap[30][20] array: Writes 22 into every u8
void Game_MonsterAI( void );      // Executes the very simple monster AI
void Game_MonsterGenerators( void ); // Executes monster generators "AI"
void Game_MonsterAdd( u8, u8, u8, u8 ); // Makes a new monster - executed by monster generators
void Game_MonsterUpdates( void ); // Updates frames and HP of all monsters
void Game_MonsterMove( u8, u8 );  // Moves monster on the map, including collision detecion with the map and
                                  // and out-of-screen preventing
void Game_CheckForCollisions( void ); // Checks if players 1 or 2 has a collision, very simple one
void Game_Combat( u8, u8 );      // Combat mode between a player and another monster