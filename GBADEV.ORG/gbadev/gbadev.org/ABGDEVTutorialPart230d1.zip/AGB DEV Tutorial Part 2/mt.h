// This is the ``Mersenne Twister'' random number generator MT19937, which
// generates pseudorandom integers uniformly distributed in 0..(2^32 - 1)
// starting from any odd seed in 0..(2^32 - 1).  This version is a recode
// by Rafael Baptista, based on a recode by Shawn Cokus 
// (Cokus@math.washington.edu) on March 8, 1998 of a version by
// Takuji Nishimura (who had suggestions from Topher Cooper and Marc Rieffel in
// July-August 1997).
//
// According to the URL 
// (and paraphrasing a bit in places), the Mersenne Twister is ``designed
// with consideration of the flaws of various existing generators,'' has
// a period of 2^19937 - 1, gives a sequence that is 623-dimensionally
// equidistributed, and ``has passed many stringent tests, including the
// die-hard test of G. Marsaglia and the load test of P. Hellekalek and
// S. Wegenkittl.''  It is efficient in memory usage (typically using 2506
// to 5012 bytes of static data, depending on data type sizes, and the code
// is quite short as well).  It generates random numbers in batches of 624
// at a time, so the caching and pipelining of modern systems is exploited.
// It is also divide- and mod-free.
//
//
// The code as Shawn received it included the following notice:
//
//   Copyright (C) 1997 Makoto Matsumoto and Takuji Nishimura.  When
//   you use this, send an e-mail to  with
//   an appropriate reference to your work.
//
// It would be nice to CC:  when you write.
//

#define N              (624)                 // length of state vector
#define M              (397)                 // a period parameter
#define K              (0x9908B0DFU)         // a magic constant
#define hiBit(u)       ((u) & 0x80000000U)   // mask all but highest   bit of u
#define loBit(u)       ((u) & 0x00000001U)   // mask all but lowest    bit of u
#define loBits(u)      ((u) & 0x7FFFFFFFU)   // mask     the highest   bit of u
#define mixBits(u, v)  (hiBit(u)|loBits(v))  // move hi bit of u to hi bit of v

u32   state[N+1]; // state vector + 1 extra to not violate ANSI C
u32*  next;       // next random value is computed from here
s32   left;       // can *next++ this many times before reloading

int do_regen;

void seedMT( u32 seed )
{
   u32 x = (seed | 0x1 ) & 0xFFFFFFFF;
   u32* s = state;
   u32 j = N;
   left = 0;
   *s++ = x;
   
   while ( --j )
   {
      x *= 69069;
      *s = ( x & 0xFFFFFFFF );
      s++;
   }

   do_regen = 1;
}

u32 reloadMT()
{
   u32* p0 = state;
   u32* p2 = state + 2;
   u32* pM = state + M;
   u32 s0;
   u32 s1;
   int j;
   
   // if this is the first time through seed the algorithm.
   if ( left < -1 ) seedMT( 4357U );
   
   left = N-1;
   next = &(state[1]);
   
   for( s0 = state[0], s1 = state[1], j = ( N-M+1 ); --j; s0 = s1, s1 = *p2++ )
      *p0++ = ( *pM++ ^ (mixBits(s0, s1) >> 1) ^ (loBit(s1) ? K : 0));
   
   for( pM = state, j = M; --j; s0 = s1, s1 = *p2++ )
      *p0++ = ( *pM++ ^ ( mixBits(s0, s1) >> 1 ) ^ ( loBit(s1) ? K : 0 ));
   
   s1 = state[0];
   *p0 = ( *pM ^ ( mixBits( s0, s1 ) >> 1 ) ^ ( loBit( s1 ) ? K : 0 ));
   s1 ^= ( s1 >> 11 );
   s1 ^= ( s1 <<  7 ) & 0x9D2C5680U;
   s1 ^= ( s1 << 15 ) & 0xEFC60000U;
   return ( s1 ^ ( s1 >> 18 ));
}

u32 randomMT()
{
   u32 y;
   
   left--;
   if ( left < 0 ) 
   {
      if ( do_regen == 1 )
      {
         return( reloadMT() );
      } else {
         left = N-1;
         next = &(state[1]);
      }
   }
   
   y  = *next;
   next++;
   y ^= ( y >> 11 );
   y ^= ( y <<  7 ) & 0x9D2C5680;
   y ^= ( y << 15 ) & 0xEFC60000;
   y ^= ( y >> 18 );
   return y;
}


// Add by Nokturn:
 u16 Rand( u16 Range )
 {
	 return ((u16)randomMT() % Range);
 }


