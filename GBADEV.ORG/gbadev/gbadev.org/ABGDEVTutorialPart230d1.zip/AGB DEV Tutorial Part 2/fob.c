//---------------------------------------------------//
//     ( AGB ) Fields of Battle by Nokturn           //
//                                                   //
//    First Version: 20. Apr. 2001                   //
//    Last  Version: 20. Apr. 2001                   //
//    View readme for more info                      //
//---------------------------------------------------//

#include "AGBLib.h" // All the basic functions - a little library
#include "mt.h"     // Mersenne Twister Random Number Algorythm
#include "fob.h"    // Fields of Battle include: Declarations of variables and functions and macros/defines

 void Video_SetupGfx() // Init gfx modes & backgrounds and load gfx
 {
	 DISPCNT = 0; // Set the video mode to mode 0: Tile mode

	 DISPCNT |= BIT06; // 2 Dimensional mapping for sprite data

	 // Setup the BG0: The playing area

	 BG0CNT  = 0 | BIT01;        // Size = 256*256 , Character base block = 0, Second Priority
	 BG0CNT |= BIT07;    // Colormode = 256 colors * 1 palette
	 BG0CNT |= ( 7<<8 ); // Screen base block = 7
	 BG0CNT |= BIT06;    

	 // Setup background 1: The clouds

	 BG1CNT  = 1<<2;        // Size = 256*256 , Character base block = 0, First Priority
	 BG1CNT |= BIT07;    // Colormode = 256 colors * 1 palette
	 BG1CNT |= ( 15<<8 ); // Screen base block = 15
	 BG1CNT |= BIT06;    

	 // Setup background 2: The cloud shadows

	 BG2CNT  = 3<<2 | BIT00;        // Size = 256*256 , Character base block = 0, Third Priority
	 BG2CNT |= BIT07;    // Colormode = 256 colors * 1 palette
	 BG2CNT |= ( 31<<8 ); // Screen base block = 15
	 BG2CNT |= BIT06;    

	 // Setup background 3: The water

	 BG3CNT  = 2<<2 | BIT01 | BIT00;        // Size = 256*256 , Character base block = 0, Third Priority
	 BG3CNT |= BIT07;    // Colormode = 256 colors * 1 palette
	 BG3CNT |= ( 23<<8 ); // Screen base block = 15
	 BG3CNT |= BIT06;    

	 MOSAIC = 0;         // Set the mosaic size to normal

	 Copy32( 320, &gfx_tiles, BG0Data ); // Copy all tiles into the Data area for BG 0

	 Copy32( 160, &gfx_sprites, ObjectData ); // Copies little sprites into ObjectData

	 LoadPalette( &pal_bg, PaletteBG ); // Loads the background palette
	 LoadPalette( &pal_obj, PaletteOBJ ); // And the sprite palette


	 // Copies the clouds into the bg 1 data area: Repeats the 64x64 clouds 4 times H and V so it 
	 // is copied into the whole 256x256 area and we can easily scroll the background
	 CopyAndAssignBg( 8, 8, BG1Screening, BG1Data, 4, 4, &gfx_clouds, 0, 0, 0 );
	 
	 // Copies the shadows of the clouds into the bg 2 data area: Repeats the 64x64 gfx 4 
	 // times H and V so it is copied into the whole 256x256 area and we can easily scroll the
	 // background
	 CopyAndAssignBg( 8, 8, BG2Screening, BG2Data, 4, 4, &gfx_cloudshadows, 0, 0, 0 );

	 // Copies the water into the bg 3 data area: Repeats the 64x64 file 4 times H and V so it 
	 // is copied into the whole 256x256 area and we can easily scroll the background
	 CopyAndAssignBg( 8, 8, BG3Screening, BG3Data, 4, 4, &gfx_water, 0, 0, 0 );

	 BLDMOD = BIT02 | BIT06 | BIT08 | BIT10 | BIT11 | BIT12; // Enable alpha blending between clouds and sprites + map
	 VarCOLEV = 10 | ( 6 << 8 );       //  The first number is the clouds shadow alpha, the second the alpha of the clouds, map, sprites and water
	 COLEV = VarCOLEV; // Write the alpha values to the write only register COLEV

	 ClearOAM(); // "disable" all sprites so we won't have any dump on the screen unless we rewrite the OAM
 }

 void Video_RenderMap() // Function to write the map into the bg 0 buffer
 {
  for( i = 0; i < 20; i++ )
   for( j = 0; j < 30; j++ )
   {
    BG0Screening[i*32 + j]=Map[j][i]; // Write the map to the BGscreening, it's quite simple
   }
 }

 void Game_LoadMap( u8 *a_mapfile ) // Load a map from a file into Map[30][20]
 {
  for( i = 0; i < 20; i++ )
   for( j = 0; j < 30; j++ )
   {
    Map[j][i] = a_mapfile[i*30 + j];
   }
 }

 void Game_ResetMonsters() // Sets all monster values to standart
 {
	 for( i = 0; i < 22; i++ )
	 {	 
		 Monsters[i].Frame = 0;
		 Monsters[i].HP = 0;       // Most important value here: if( HP <= 0 ) it means, that the monster is dead
		                           // and thus don't execute AI, coldet, moving, HP increase etc.
		 Monsters[i].Type = 1;
		 Monsters[i].AICounter = 0; 
		 Monsters[i].AIDir = 0; // Stand still
	 }
	 Game_MonstersAlive = 0; // As long as this value is < 20, monster generators "produce" new monsters
 }

 void Game_ResetPlayers()
 {
	 // Reset Player 1
	 Monsters[0].Frame=0;
	 Monsters[0].HP = Monsters[0].MaxHP = 20;
	 Monsters[0].Type = 1;
	 Monsters[0].X = 32;  // MapX = (X+4) / 8
	 Monsters[0].Y = 32;  
	 Monsters[0].MapX = (32+4)/8;
	 Monsters[0].MapY = (32+4)/8;
	 CMap[ Monsters[0].MapX ][ Monsters[0].MapY ] = 0; // Collision map set

	 // Reset Player 2
	 Monsters[1].Frame=0;
	 Monsters[1].HP = Monsters[1].MaxHP = 20;
	 Monsters[1].Type = 2;
	 Monsters[1].X = 32;  // MapX = (X+4) / 8
	 Monsters[1].Y = 96;  
	 Monsters[1].MapX = (32+4)/8;
	 Monsters[1].MapY = (96+4)/8;
	 CMap[ Monsters[1].MapX ][ Monsters[1].MapY ] = 1; // Set the collision map right
 }

 void Video_DisplayMonsters()
 {
	 for( i = 0; i < 22; i++ ) // For all monsters:
	 {
		 if( Monsters[i].HP > 0 ) // If the monster is alive, display the sprite
		 {
			 // Write the sprite display to OAM
			 Oam[(i<<3)+0] = Monsters[i].Y | BIT13; // BIT13 means: Use 256 color palette, not 16 � la 16 colors
			 Oam[(i<<3)+1] = Monsters[i].X;         
			 Oam[(i<<3)+2] = (((Monsters[i].Type-1)<<1) + Monsters[i].Frame)<<1 | BIT11; // BIT10 means 2nd Priority: Hide under the clouds and cloud shadows

			 // Reflection of the sprites
			 Oam[(i<<3)+4] = Monsters[i].Y+8 | BIT13 | BIT10; // BIT10 means: semi-transparent object
			 Oam[(i<<3)+5] = Monsters[i].X | BIT13; // BIT13 means here: Flip vertically          
			 Oam[(i<<3)+6] = (((Monsters[i].Type-1)<<1) + Monsters[i].Frame)<<1 | BIT11 | BIT10; // BIT10 | BIT11 means 4nd, last, Priority: Hide under everything execpt 
			                                                                                     // under bg with priority 4: The water
		 }
		 else // Monster is dead or inactive, display out of screen
		 {
			 Oam[(i<<3)+0] = 161 | BIT13;  // BIT13 is not needed here but I'll keep it for order
			 Oam[(i<<3)+1] = 241;         
			 Oam[(i<<3)+2] = 0;
		 }
	 }
 }

 void Game_MonsterUpdates() // Update the frames to make an animation
 {
	 for( i = 0; i < 22; i++ )
	 {
		 if( Monsters[i].Frame == 0 ) Monsters[i].Frame = 1;   // Change frames between 1 and 0
		 else
			 Monsters[i].Frame = 0;

		 if( Monsters[i].HP > 0 )  // Refill HP if it's less than max HP and the monster is still alive
		 {
			 if( Monsters[i].HP < Monsters[i].MaxHP ) Monsters[i].HP++;
		 }
			 else // The monster has <= 0 HP: Substract one from the monsters alive variable to show
				  // the monster generators that they have to breed one monster
				 Game_MonstersAlive--;
		 
	 }
 }

 void Input_ProcessKeys()
 {
	 if( !( P1 & KEY_UP    ) ) Game_MonsterMove( 0, UP    );
	 if( !( P1 & KEY_DOWN  ) ) Game_MonsterMove( 0, DOWN  );
	 if( !( P1 & KEY_LEFT  ) ) Game_MonsterMove( 0, LEFT  );
	 if( !( P1 & KEY_RIGHT ) ) Game_MonsterMove( 0, RIGHT );

	 if( !( P1 & KEY_A     ) ) Game_MonsterMove( 1, UP    );
	 if( !( P1 & KEY_B     ) ) Game_MonsterMove( 1, DOWN  );
	 if( !( P1 & KEY_L     ) ) Game_MonsterMove( 1, LEFT  );
	 if( !( P1 & KEY_R     ) ) Game_MonsterMove( 1, RIGHT );

     CMap[ Monsters[0].MapX ][ Monsters[0].MapY ] = 0; // Set collision data for the players. See the txt file for more info
     CMap[ Monsters[1].MapX ][ Monsters[1].MapY ] = 1;
 }

 void Game_MonsterMove( u8 a_Monster, u8 a_Dir )
 {
	 if( a_Dir == UP )
	 {
		 if( Monsters[a_Monster].Y > 0 ) // Make sure the monster doesn't move out of the screen
		 {
			 if( Map[ (Monsters[a_Monster].X+4)/8 ][ (Monsters[a_Monster].Y)/8 ] == 0 ) 
				 // Collision detection: It could be done much, better, but 8x8 is really small and 
				 // some little errors won't matter that much. We have to keep in mind that we're doing 
				 // it 22 times in a frame after all!
				 Monsters[a_Monster].Y--;
		 }
	 }
	 if( a_Dir == DOWN )
	 {
		 if( Monsters[a_Monster].Y < 151 )
		 {
			 if( Map[ (Monsters[a_Monster].X+4)/8 ][ (Monsters[a_Monster].Y + 7)/8 ] == 0 ) 
				 Monsters[a_Monster].Y++;
		 }
	 }
	 if( a_Dir == LEFT )
	 {
		 if( Monsters[a_Monster].X > 0 )
		 {
			 if( Map[ (Monsters[a_Monster].X)/8 ][ (Monsters[a_Monster].Y+4)/8 ] == 0 ) 
				 Monsters[a_Monster].X--;
		 }
	 }
	 if( a_Dir == RIGHT )
	 {
		 if( Monsters[a_Monster].X < 231 )
		 {
			 if( Map[ (Monsters[a_Monster].X + 7)/8 ][ (Monsters[a_Monster].Y+4)/8 ] == 0 ) 
				 Monsters[a_Monster].X++;
		 }
	 }
	 Monsters[a_Monster].MapX = (Monsters[a_Monster].X+4)>>3; // Write the MapX and MapY: The map coordinates 
	 Monsters[a_Monster].MapY = (Monsters[a_Monster].Y+4)>>3;
	 CMap[ Monsters[a_Monster].MapX ][ Monsters[a_Monster].MapY ] = a_Monster; // Sets the collision data for monsters
 }

 void Video_MoveBackgrounds() // Scroll clouds so that it looks like as if they were moving :)
 {
	 BG1HOFS = CloudsOffX;  // Move Left
	 BG1VOFS = CloudsOffY;  // Move Down
	 BG2HOFS = CloudsOffX-10; // Shadow of the clouds shall be under the clouds
	 BG2VOFS = CloudsOffY-10;  
	 BG3HOFS = -CloudsOffX;   // Scroll the water in the opposite direction of the clouds
	 BG3VOFS = -CloudsOffY;  
	 CloudsOffX++; 
	 CloudsOffY--;
 }

 void Game_ResetCollisionMap() 
 {
	 for( i = 0; i < 20; i++ )
		 for( j = 0; j<30; j++ )
			 CMap[j][i]=22;
 }

 void Game_MonsterAdd( u8 M_Nr, u8 M_Type, u8 M_X, u8 M_Y ) // Add a new monster
 {
	 Monsters[M_Nr].HP = Monsters[M_Nr].MaxHP = 5+Rand(5); // 5 random extra HP: Max. 9, min 5 HP
	 Monsters[M_Nr].Type = M_Type;
	 Monsters[M_Nr].Frame = 0;
	 Monsters[M_Nr].X = M_X;
	 Monsters[M_Nr].Y = M_Y;
	 Monsters[M_Nr].MapX = (M_X+4)/8;
	 Monsters[M_Nr].MapY = (M_Y+4)/8;
	 Game_MonstersAlive++;
 }
 
 void Game_MonsterGenerators()
 {
	 // Monster generator 1 is on coordiates 23 | 3
	 // Number 2 is on 13 | 16
	 if( Game_MonstersAlive < 20 ) // If there are less monsters in the game than the max, produce a monster
	 {
		 for( i = 0; i < 20; i++ ) // Check which monster has HP < 0 ( which monster is dead and has to be resurrected
		 {
			 if( Monsters[i+2].HP <= 0 ) // i+2 because players are excluded of course
			 {
				 if( Rand(2) == 0 ) Game_MonsterAdd( i+2, Rand(2)+3, 22*8, 5*8 ); // Choose either monster generator 1 or 2
				 else
					 Game_MonsterAdd( i+2, Rand(2)+3, 13*8, 15*8 );

				 i = 20; // unelegant way to end the loop
			 }
		 }
	 }
 }

 void Game_MonsterAI()
 {
	 for( i = 0; i < 20; i++ )
	 {
		 if( Monsters[i+2].HP > 0 ) // Do AI only if it's alive :)
		 {
			 if( Monsters[i+2].AICounter >= 20 )  // If the counter exceeds or reaches 20, change the moving dir
			 {
				 Monsters[i+2].AICounter = 0;
				 Monsters[i+2].AIDir = Rand(4)+1; // Random moving direction
			 }
			 Monsters[i+2].AICounter++;
			 Game_MonsterMove( i+2, Monsters[i+2].AIDir ); // move the monster
		 }
	 }
 }

 void Game_CheckForCollisions()
 {
	 if( CMap[Monsters[0].MapX][Monsters[0].MapY] != 0 && Monsters[0].HP > 0 ) // If player 1 is alive & the collision tile which
		                                                                       // he's standing on isn't his own, perform a combat
	 {
		 FadeOut( 1 ); // Fade everything except for sprites
		 
		 while( Monsters[0].HP > 0 && Monsters[CMap[Monsters[0].MapX][Monsters[0].MapY]].HP > 0 ) // Do combat as long as one of the opponents isn't dead
		 Game_Combat( 0, CMap[Monsters[0].MapX][Monsters[0].MapY] );

		 Wait( 10 );
		 
		 FadeIn( 1 );
		 ClearOAM();

		 // Reassign alpha values
		 BLDMOD = BIT02 | BIT06 | BIT08 | BIT10 | BIT11 | BIT12; // Enable alpha blending between clouds and sprites + map
		 VarCOLEV = 10 | ( 6 << 8 );       //  The first number is the alpha of the map & sprites, the second ( unshifted ) is the cloud alpha
		 COLEV = VarCOLEV; // Write the alpha values to the write only register COLEV
	 }


     // The same for player 2
	 if( CMap[Monsters[1].MapX][Monsters[1].MapY] != 1 && Monsters[1].HP > 0 )
	 {
		 FadeOut( 1 );

		 while( Monsters[1].HP > 0 && Monsters[CMap[Monsters[1].MapX][Monsters[1].MapY]].HP > 0 ) 
		 Game_Combat( 1, CMap[Monsters[1].MapX][Monsters[1].MapY] );

		 Wait( 10 );

		 FadeIn( 1 );
		 ClearOAM();
		 BLDMOD = BIT02 | BIT06 | BIT08 | BIT10 | BIT11 | BIT12; // Enable alpha blending between clouds and sprites + map
		 VarCOLEV = 10 | ( 6 << 8 );       //  The first number is the alpha of the map & sprites, the second ( unshifted ) is the cloud alpha
		 COLEV = VarCOLEV; // Write the alpha values to the write only register COLEV
	 }
 }

 void Video_DisplayMonsterHearts( u8 dM1, u8 dM2 ) // A function called internally by Game_Combat(...)
 {
	 for( i = 0; i < Monsters[dM1].MaxHP; i++ ) // Draw black hearts for monster 1 which indicate maxHP
	 {
		Oam[192+0+(i<<2)] = (i<<3) | BIT13; // Y = from top to bottom; 
		Oam[192+1+(i<<2)] = 8; // X is at the left side of the screen
		Oam[192+2+(i<<2)] = 18; // 8x8 spritenr. * 2  
	 }

	 for( i = 0; i < Monsters[dM2].MaxHP; i++ ) // Same for monster 2
	 {
		Oam[272+0+(i<<2)] = (i<<3) | BIT13;
		Oam[272+1+(i<<2)] = 231; // Draw at the right side of the screen
		Oam[272+2+(i<<2)] = 18;
	 }

	 for( i = 0; i < Monsters[dM1].HP; i++ ) // Draw full hearts over the black ones
	 {
		Oam[192+0+(i<<2)] = (i<<3) | BIT13;
		Oam[192+1+(i<<2)] = 8;
		Oam[192+2+(i<<2)] = 16;
	 }

	 for( i = 0; i < Monsters[dM2].HP; i++ ) // Same for monster 2
	 {
		Oam[272+0+(i<<2)] = (i<<3) | BIT13;
		Oam[272+1+(i<<2)] = 231;
		Oam[272+2+(i<<2)] = 16;
	 }
 }

 void Game_Combat( u8 M1, u8 M2 ) // First monster number, second monster number. First one is always a player
 {
	 // Copy the player 32x32 image data into VRAM
	 Copy32x32( &gfx_fighters,     (ObjectData+160) );

	 // Copy any other monster data into ObjectData
	 if( Monsters[M2].Type == 1 ) Copy32x32( &gfx_fighters,     (ObjectData+160+256) );
	 if( Monsters[M2].Type == 2 ) Copy32x32( &gfx_fighters,     (ObjectData+160+256) );
	 if( Monsters[M2].Type == 3 ) Copy32x32( &gfx_fighters+256, (ObjectData+160+256) );
	 if( Monsters[M2].Type == 4 ) Copy32x32( &gfx_fighters+512, (ObjectData+160+256) );

	 WaitForVSync(); // ... to avoid tearing
	 // Display Monster 0
	 Oam[184+0] = 64 | BIT13; // BIT13 means: Use 256 color palette, not 16 � la 16 colors
	 Oam[184+1] = 64 | BIT15 | BIT12;  // BIT 15 means: 32x32. BIT12 means: Flip H
	 Oam[184+2] = 20; // 20 = 640 / 64 * 2

	 // Display Monster 1
	 Oam[188+0] = 64 | BIT13; // BIT13 means: Use 256 color palette, not 16 � la 16 colors
	 Oam[188+1] = 128 | BIT15; // BIT 15 means: 32x32. BIT12 means: Flip H        
	 Oam[188+2] = 20 + 32; 

	 Video_DisplayMonsterHearts( M1, M2 ); // Show the HP of the monsters before fight

	 Wait(10); // Wait a bit - should be set higher for real hardware
	 // WaitForVSync(); is built in in wait so we don't have to wait one more time

	 // Display the monster to be closer to each other - should look as if they fighted
	 Oam[184+0] = 64 | BIT13; // BIT13 means: Use 256 color palette, not 16 � la 16 colors
	 Oam[184+1] = 80 | BIT15 | BIT12;         
	 Oam[184+2] = 20; 

	 Oam[188+0] = 64 | BIT13; // BIT13 means: Use 256 color palette, not 16 � la 16 colors
	 Oam[188+1] = 112 | BIT15;         
	 Oam[188+2] = 20 + 32; 

	 // Decrease hitpoints of both monsters by 0 to 2 ( random number )
	 // If someone would continue coding this little RPG, he would instert damage coding routines
	 // based on levels, damage, strength, armor, weapon type, etc.
	 Monsters[M1].HP-=Rand(3);
	 Monsters[M2].HP-=Rand(3);

	 Video_DisplayMonsterHearts( M1, M2 ); // Display HP after one attack

	 Wait( 10 );
 }

 void AGBMain()
 {
	 u8 Frames=0; // Frame count - needed to do stuff "every X" frames or "at frame X"
	 TM0CNT = 0 | BIT07; // Enable timer 0 so we can use it to feed out rng ( Random Number Generator )

	 Video_SetupGfx();
	 
	 Game_LoadMap( &map_map1 );
	 Video_RenderMap();
	 Game_ResetMonsters();
	 Game_ResetPlayers();
	 Video_DisplayMonsters();
	 seedMT( *Timer0Data ); // Seeds the Mersenne Twister RNG with a timer 0 value


	 // Only after having loaded and setup the gfx, we can now enable them...

	 DISPCNT |= BIT08;   // Enable Background 0: The map
	 DISPCNT |= BIT09;   // Enable Background 1: The clouds
	 DISPCNT |= BIT10;   // Enable Background 2: The cloud shadows
	 DISPCNT |= BIT11;   // Enable Background 3: Water
	 DISPCNT |= BIT12;   // Enable OAM

	 while( AGBRULEZ ) // AGB forever :~)
	 {
		 Frames++;                            // Run the timer 60 times a second ( I hope to get that many fps )
		 if( Frames == 60 ) Frames = 0; 

		 if( Frames % 3 == 0 ) // Every 3rd frame - else it would all be too slow
		 {
			 Game_ResetCollisionMap();
			 Input_ProcessKeys(); // Every third frame. Travel speed: 20 pixels/second
			 Game_MonsterAI();
			 Game_MonsterGenerators();
			 Game_CheckForCollisions();
		 }

		 if( Frames == 0 || Frames == 30 ) Game_MonsterUpdates(); // Update 2 times a second ( 60 fps )

		 WaitForVSync(); // Wait a bit to avoid tearing

		 if( Frames % 4 == 0 ) Video_MoveBackgrounds(); // Every fourth frame. Clouds movement: 15 pixels/second
		 Video_DisplayMonsters(); // Display the monsters
	 }
 }