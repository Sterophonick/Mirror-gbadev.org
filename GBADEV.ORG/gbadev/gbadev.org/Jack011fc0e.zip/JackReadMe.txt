Jack! Tile and Sprite Ripper for GBA
From SoftEgg Entertainment - http://www.softegg.com
Programmed by Tim Trzepacz
Release 0.11
November 18th, 2001

Greetings GBA developers.

"Jack" is a new, hopefully useful, windows program for converting images into
tile and sprite data for the GameBoy Advance. It handles 16 and 256 color data,
and can convert a single bitmap of grid aligned sprite images into multiple 
sprites.

Using Jack is easy! 

1) Select "New" from the "File" menu and tell Jack how many colors and whether 
   you are ripping a map or sprites. 

2) Select "Rip" from the "File" menu and select a bitmap file. 

Repeat step 2 as necessary to get all of your tiles into RAM, then select "Save" 
from the "File" menu and select a seperate filename for your graphics data, 
palette data, and map data.

Currently, the program has the following limitations.

* Tilemaps are always saved as 64 x 64, in four seperate 32 x 32 maps.
* When ripping multiple images, new palettes always overwrite old palettes.
* When saving color palettes, 256 colors are always saved.
* Bitmaps must be 4 or 8 bits per pixel (16 or 256 colors).
* Bitmaps should be aligned to even tile sizes (width and height should be 
  multiples of 8). Other sizes won't cause errors, but the last line on the 
  right or bottom will be repeated to pad tiles out to 8 pixels, which may look 
  strange.
* Sprites are always allocated in 1D mode.
* 16 color sprites are not checked for color continuity between sprite tiles.
* The open option for reading sprite data back in is not yet implemented.
* When ripping multiple tilemaps, the map data will be overwritten by each 
  successive image because maps are always started at position 0,0. So when 
  ripping multiple maps into one tileset, remember to save your map between each 
  rip.

Sorry for all the limitations, but this IS version 0.1 . It's also free for 
non-commercial use, although donations would be greatly appreciated. Commercial 
users should contact me at timon@lanset.com for licensing details. Although the 
program is free, please don't distribute it, but rather link to the SoftEgg web 
site at http://www.softegg.com .

Thank you for using Jack.

-- Tim Trzepacz --

GameBoy Advance is undoubtedly copyright and/or trademark of Nintendo, but this software is not licensed, endorsed, or in any way associated with Nintendo. So there.


Version History:

0.1 	First Release
0.11	Built with imageMod library included so that people other than me can run it.
0.11	11-26-2001 version should do what the above one did for real.

