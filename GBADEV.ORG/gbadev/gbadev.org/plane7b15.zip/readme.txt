plane

a simple Game Boy Advanced game
by
tangl_99

This game was made as a trainning application.
There's nothing to introduce about it,becasuse there are already the same games on FC and PC,and they are both famous.
All you have to do is to get away from the attack of the shots.But there are 48 shots on the screen,so you must be very careful.
Be alive as long as possible!

I use the Arm Gcc as complier.The code was simple.
Kailed_1-2-3 was used to convert graphics.

And questions or comments should be directed to tangl_99 at
tangl_99@sohu.com
