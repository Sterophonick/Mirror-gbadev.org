/*******************************************************
*
*	SM3D Utility routine
*
********************************************************
*	SM3D
*
*	File type	:	Header
*	Author		:	Dario Deledda
*	Date		:	25/11/2000
*	Last update	:	25/11/2000
*	Version		:	0.9a
*
********************************************************/
#ifndef SM3DCOLOR
#define SM3DCOLOR

#include "../header/SM3DTypes.h"

#define	smRedMask		0x7c00
#define smGreenMask		0x03e0
#define smBlueMask		0x001f
#define	smRedShift		3
#define	smGreenShift	2
#define smBlueShift		7
#define	smColorUpLimit	0x00ff
#define	smColorDownLimit 0x0000

#define smColorClip8(in) ( (in > smColorUpLimit) ? smColorUpLimit : ((in < smColorDownLimit) ? in : smColorDownLimit))

#define	smBlue8to5(in)	(((in) << smBlueShift) & smBlueMask)
#define smGreen8to5(in)	(((in) << smGreenShift) & smGreenMask)
#define smRed8to5(in)	(((in) >> smRedShift) & smRedMask)

#define smBlue5to8(in)	(((in)& smBlueMask) >> smBlueShift)
#define smGreen5to8(in) (((in)& smGreenMask) >> smGreenShift) 
#define smRed5to8(in)	(((in)& smRedMask) << smRedShift)	

#define max_col		127
#define col_shc		8			// shift for the calculus
#define max_light	max_col			// valore massimo per la luce
#define col_sh		col_shc+3	// shift for ilumination managed at 24bit pp
#define col_tab		64			// use the 16bit table

class	smRGB16;
class	smRGB{
public:
	Int16	r,g,b,a;
	Int32  v,n;
	
	smRGB(Int16 ri=0, Int16 gi=0, Int16 bi=0){ r=ri,g=gi,b=bi;}
	smRGB operator=(smRGB16 op1);
	smRGB operator=(smRGB op1);
	void CutCol();
	void CutColU();
	
};

class	smRGB16{
public:
	UInt16	cl;
	
	smRGB16(UInt16 in=0){ cl=in; }

	smRGB16 operator+(smRGB16 op1);
	smRGB16 operator-(smRGB16 op1);
	smRGB16 operator*(smRGB16 op1);
	smRGB16 operator/(smRGB16 op1);
	
	smRGB16 operator+(Int16	op1);
	smRGB16 operator-(Int16	op1);
	smRGB16 operator*(Int16	op1);
	smRGB16 operator/(Int16	op1);

	smRGB16 operator+(Fl32	op1);
	smRGB16 operator-(Fl32	op1);
	smRGB16 operator*(Fl32	op1);
	smRGB16 operator/(Fl32	op1);
	
	smRGB16 operator=(smRGB op1);
	smRGB16 operator=(smRGB16 op1){cl=op1.cl; return *this;}
	smRGB16 operator=(Int16 op1);
	
};

#endif