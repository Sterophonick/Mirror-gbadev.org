/*******************************************************
*
*	SM3D Types
*
********************************************************
*	SM3D
*
*	File type	:	Header
*	Author		:	Dario Deledda
*	Date		:	25/11/2000
*	Last update	:	25/11/2000
*	Version		:	0.9a
*
********************************************************/
#ifndef SM3DTYPES
#define SM3DTYPES

#include "../header/SM3DGBA.h"

typedef char		Int8;		
typedef	short		Int16;
typedef	long		Int32;
typedef	long long	Int64;

typedef unsigned char		UInt8;
typedef unsigned short		UInt16;
typedef unsigned long		UInt32;
typedef unsigned long long	UInt64;

typedef	float		Fl32;
typedef	double		Fl64;

typedef	char		Byte;

typedef	UInt32*		Pnt;

typedef	short		SMErr;
	
#define	SM3DErr_NoErr			0	
#define SM3DErr_No_Clip_Rect	-1000
#define SM3DErr_Out_Of_Video	-1001
#define SM3DErr_No_Visible		-1002

#define	 	pi 		3.141592654			// PI greco
#define	 	pi2 	(pi*2)				// 2PI greco
#define		Ks_b	8					// Bit for shift in fixed point 8 default
#define		Ks_b1	(Ks_b<<1)			// Bit for shift a doppia prec. 16 default
#define		Ks_n1	(1<<Ks_b1)			// value of the shift in fixed point 16
#define		Ks_n	(1<<Ks_b)			// value of the shift in fixed point  8
#define		Ncmp	512					// Number of sample for an 360 degree angle

#endif