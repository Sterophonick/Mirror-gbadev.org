/*******************************************************
*
*	SM3D Camera definition
*
********************************************************
*	SM3D
*
*	File type	:	Header
*	Author		:	Dario Deledda
*	Date		:	25/11/2000
*	Last update	:	25/11/2000
*	Version		:	0.9a
*
********************************************************/
#ifndef SM3DCAMERA
#define SM3DCAMERA

#include "../header/SM3DTypes.h"
#include "../header/SM3DColor.h"
#include "../header/SM3DUtility.h"
#include "../header/SM3DPoint32.h"
#include "../header/SM3DTexture.h"

#define mfl (1<<24)		// z buffer depth
void init_Zbuffer(void);
void del_Zbuffer(void);
bool Cam_zb_clear(void);

void init_Light(void);	// lights
void del_Light(void);
SMErr calc_Light(const smPointC &pin,const smPointC &n,smRGB &ret);
void set_Light(UInt32 n,smPointC &in);
void set_NumLight(UInt32 n);


class smRender{
public:
	UInt8	ymax,ymin;					// ymin e ymax del poligono in spazio video
	UInt32	dist_sc;					// Distanza dallo schermo di proiezione
	Int32	mcx[smHWVwidth];			// Array di velocizazione texture
	Int32	mcy[smHWVheight];			// Array di velocizazione texture
	UInt16	pixp[smHWVheight];			// array per le scritture
	UInt16	pixpc;						// contatore per la scrittura di pixp
	UInt16	pix[smHWVheight];			// Indice dell' array	
	smRGB	px[smHWVheight][4];			// array

};

class smViewPort{
public:
	Int16	xclip,yclip;		//	Valori di clip orizontali e verticali
	Int16	xc_v,yc_v;			//	xc,yc meta' dimensione video visibile
	Int16	xclip_l,xclip_r;	//	rettangolo visualizzato a video
	Int16	yclip_u,yclip_b;	//	xclip_l,yclip_u sono le coordinate spigolo alto sinistra
								//	xclip_r la larghezza,yclip_b l' altezza
	Int16	xclip_cl,xclip_cr;	//	coordinate di cliping per la x
	Int16	yclip_cu,yclip_cb;	//	coordinate di cliping per la y
	smViewPort();				//	Default constructor
	SMErr SetView(Int16 xl,Int16 yu,Int16 xr,Int16 yb);
	SMErr SetViewCenter(Int16 xc,Int16 yc);
	SMErr SetViewRect(Int16 xl,Int16 yu,Int16 xr,Int16 yb);
};

class smCamera:public smPoint32, public smViewPort, public smRender{
public:
	smPoint32	ang;
	smBuffer	*buf;
	
	smCamera(Int32 xi,Int32 yi,Int32 zi,
					Int32 al=0,Int32 be=0,Int32 ga=0) { 
					x=xi; y=yi; z=zi; ang.x=al; ang.y=be; ang.z=ga;
					dist_sc=(((Fl32)smHWVwidth)/smHWVwidth)*256;
					ReinitDistSc();
					}
	
	void ReinitDistSc();
	smPoint32	TreToDued(register const smPoint32& punto_in,register SMErr& er);
	smPointC	Duef(register smPointC &punto_in,SMErr& er);
	void		insert2(register smRGB &x,register Int32 y);

	bool		Clip(register smPointC& p1,register smPointC& p2);
	SMErr 		smQuad(smPointC *pnt,UInt16 num,smTexture *texture,bool twoFace);
	SMErr		smTriangle(smPointC &p0i,smPointC &p1i,smPointC &p2i,smTexture *texture,bool twoFace);
	SMErr		CalcLightPoly(smPointC *inp, UInt16 num);
};

#endif