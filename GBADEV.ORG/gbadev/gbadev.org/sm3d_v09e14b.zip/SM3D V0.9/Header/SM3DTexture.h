/*******************************************************
*
*	SM3D Texture definition
*
********************************************************
*	SM3D
*
*	File type	:	Header
*	Author		:	Dario Deledda
*	Date		:	27/11/2000
*	Last update	:	27/11/2000
*	Version		:	0.9a
*
********************************************************/
#ifndef SM3DTEXTURE
#define SM3DTEXTURE

class smTexture{
public:
	void	*txt;			// puntatore alla texture
	bool	tsp;			// texture con trasparenza
	UInt16	dx;				// larghezza della singola texture	(multiplo di 2)
	UInt16	dy;				// altezza della singola texture 	(multiplo di 2)
	UInt16	lx;				// numero di texture sull' asse x
	UInt16	ly;				// numero di texture sull' asse y	
	UInt16	sh;				// shift per la coordinata y
};
#endif
