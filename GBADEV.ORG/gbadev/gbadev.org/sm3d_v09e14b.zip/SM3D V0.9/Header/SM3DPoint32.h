/*******************************************************
*
*	SM3D Point32 definiton
*
********************************************************
*	SM3D
*
*	File type	:	Header
*	Author		:	Dario Deledda
*	Date		:	25/11/2000
*	Last update	:	25/11/2000
*	Version		:	0.9a
*
********************************************************/
#ifndef SM3DPOINT32
#define SM3DPOINT32

#include "../source/SM3DPoint_Temp.cp"

typedef smPoint<Int32>	smPoint32;
#define smPointC smPoint32
#define smPointN smPoint32
/*
struct nc{
	Fl32	x,y;
	smRGB cl;
};
typedef smPoint<Int32,Int16> smPointC;

struct nc1:public nc{
	smPoint32 norm;
};
typedef smPoint<Int32,nc1> smPointN;
*/
#endif