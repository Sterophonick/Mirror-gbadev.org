/*******************************************************
*
*	SM3D Utility routine
*
********************************************************
*	SM3D
*
*	File type	:	Header
*	Author		:	Dario Deledda
*	Date		:	25/11/2000
*	Last update	:	25/11/2000
*	Version		:	0.9a
*
********************************************************/
#ifndef SM3DUTIL
#define SM3DUTIL

#include "../header/SM3DTypes.h"
#include "../header/SM3DColor.h"

#ifndef SM3DMAT
extern Int32	cosv[Ncmp],sinv[Ncmp];
extern Fl32		fcos[Ncmp],fsin[Ncmp];
extern Int8		col32[255+255+255];	
extern UInt16 col16r[32*5],col16g[32*5],col16b[32*5];

extern UInt32	*z_buf;			// puntatore al buffer per tutte le camere
extern UInt32	frame;			// conteggio dei frame stampati a video
extern UInt32	frame1;
#endif

void SM3DInit(void);
void SM3DShutDown(void);
void SM3DInitLight(void);
void SM3DInitMath(void);

Int32 RadToNcmp(Fl32 ang);
Int32 Ang(Int32 tmp);

class	smBuffer{
public:

	UInt32	mFrame;					// frame counter	
	Pnt		mBBuffer;					// Actual back buffer pointer
	Pnt		mFBuffer;					// Actual back buffer pointer

	smBuffer();
	~smBuffer();

	Pnt		GetBackBuffer();		// Get the back buffer pointer
	void	SetBackBuffer(Pnt in);	// Set the back buffer pointer
	Pnt		GetFrontBuffer();		// Get the front buffer pointer
	void	SetFrontBuffer(Pnt in);	// Set the front buffer pointer

	void	Cls(UInt16 buf=smBACK);		// Clear a buffer 0 is the back buffer
	void	Clear(UInt32 in=0);
	void	Swap(UInt16 sync=smBACK);	// Swap the buffer if sync=0 with sync else no

	void	smPutPixel(UInt8 x,UInt8 y,smRGB16 ci);
	void 	smLine(Int32 p1x, Int32 p1y, Int32 p2x, Int32 p2y, smRGB16 col);	
};

void 	smCls();
void 	smPutPixel(UInt8 x,UInt8 y,smRGB16 ci);

template<class X> void swap(X &a,X &b){
	register X tmp=a;
	a=b;
	b=tmp;
}

template<class X> X abs(X a){
	return ((a>=0) ? a : -a);
}

#endif

