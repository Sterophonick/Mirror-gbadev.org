/*******************************************************
*
*	SM3D HW dependent costant and function
*
********************************************************
*	SM3D
*
*	File type	:	Header
*	Author		:	Dario Deledda
*	Date		:	25/11/2000
*	Last update	:	25/11/2000
*	Version		:	0.9a
*
********************************************************/
#ifndef SM3DGBA
#define SM3DGBA

#define smHWVheight	128
#define smHWVwidth	160
#define smHWGB5_VOffs	160
#define smHWGB5_Buf1	0x6000000
#define smHWGB5_Buf2	0x600A000

#define	smFRONT		1
#define	smBACK		0
#endif