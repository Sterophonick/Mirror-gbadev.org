the prova.raw is the file that contain all the texure
the format is the following:
128*128 * 10 textures tiled in vertical
total resolution 128*1280 24 bit rgb not interlaced
you can load it in photoshop setting in raw load
x:128 y:1280 24 bit not interlaced

have fun

Dario