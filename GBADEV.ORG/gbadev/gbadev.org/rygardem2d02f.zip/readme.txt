Rygar (Legendary Warrior) sprite animation demo

Controls:
Left and right cursors to move Rygar
A key to make Rygar jump
Down cursor will make Rygar crouch.

Written by McGeezer
GFX from the Tecmo Coin-op (Ripped using MAME) 

Updates:
  Jan 24 2002
  Completed horizontal scrolling routines for forground and background.
  Wrote a convert map routine compatible with tume.

Things to do if I carry this on:
  - Incorporate Sprite to Map control so Rygar can fall down holes etc...
  - Find a decent way to swap out tiles during gameplay for extra GFX
  - Write a fast sprite collision routine
  - Find or build a program that will allow me to build formations
  - Possibly re-write the animation routine as it's bad and may not fit
    with other sprites.
  - Build levels
  - Add vertical scrolling
  - Learn more ARM assembler
  - Anthing else I think of I'll write later

Comments:

This is the first crack I've had at ARM assembler with the Game boy
advance so you hard core dev'rs out there will know by looking at
the assembler that it is very very messy and very unprofessional.

I will tidy the code up when I learn some more ARM tricks and when I run
out of CPU cycles I will optimize the code. 

Why Rygar though?

Well I love the game and I'd like nothing better than to be able
to play the game on my GBA (Tecmo is not releasing it!), hence I guess
it would be called [Legendary Warrior - Rygar Advance]

Feel free to use the assembler routines at your peril!

What next?
Who knows, I might attempt to convert the game - can't see why not.

Credits
Code: McGeezer (mcgeezer@sunderland-net.demon.co.uk)
GFX: From the Tecmo Coin-op (ripped using mame) I'm by no means an artist

Thanks to Markus for his good gfx2gba program, it really done the biz!

