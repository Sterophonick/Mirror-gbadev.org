SIX PACK MAN (GBA beta VERSION) 10th May 2006 

    This game is free for non-commercial use.  Copy it 
for your friends, give it to your enemies, feed it to 
your dog, let your impressionable children and senile 
relatives play it, just have fun.

    If you like this game, or loathe it, or anywhere in 
between and feel like letting us know, you can reach us
at lars@greasybastard.com (for programming issues) or
revjakenash@hotmail.com for music issues.  We both have
dull day jobs and would rather make games for a living
so if you want our help, contact us.  

    The game itself has been tested on several emulators,
as well as a real live Game Boy SP.  I have not tried it on
a DS yet, and I imagine the colors would be a little dark 
on an original GBA.

    It should work on pretty much any flash cartridge, or
even a realy masked ROM and requires only 4k of save space.
(less even, but that is the smallest save chip on standard
cartridges).  The game was written in C, and could probably
be optimized quite a bit more to save a little bit of 
battery life, but we decided it was better to just release 
it.

   Have Fun!

      -lars
