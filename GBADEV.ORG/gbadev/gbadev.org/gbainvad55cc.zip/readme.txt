AGB Spacies
Coded by Jim Bagley <JimBagley@Hotmail.com> http://www.pocketgames.20m.com

This game is Freeware, and is ok to distribute
as long as it's kept as is with this text file and a link to http://www.pocketgames.20m.com
