+------------------------------------------------+
                 OIL'S WELL v0.9
+------------------------------------------------+

    Original game conceived and programmed by:
  Thomas J. Mitchell (C)1983 Sierra On-Line Inc.

      Gameboy Advance version developed by:
   Yiri T. Kohl (C)2002 Shintarian Enterprises

+------------------------------------------------+

 On this game:

 This is a homebrew version of the 1983-classic
 Oil's Well; it contains all original 8 levels.
 Current version lacks the little bonus cans and
 bombs, though.

 To skip levels, press 'select'.

+------------------------------------------------+

 Important notes:

 - This version of Oil's Well was written using
   devkit-advance by the above mentioned excuse
   for a programmer; as a result, it runs waaay
   too fast on emulators; for the correct speed
   it should be run on the real thing.

 - If you do, though, be warned:  save-routines
   are far from optimal,  and if you have other
   games on the same flash-card,  you can count
   on it that your savegames will get overwrit-
   ten by my little gem here ;-)

+------------------------------------------------+

 If you feel like wrapping up the loose ends and
 making this as complete a version as possible,
 you can contact the author through:

         http://www.xs4all.nl/~shintaro

 In which case I'll dive into the huge mess that
 is my gba-development folder, and extract the
 latest sourcecode for you to work with.

+------------------------------------------------+

 As far as redistribution is concerned:

 The original copyrights are quite obviously
 Sierra's, and I don't mean to imply otherwise.
 From what I've understood, Sierra is not
 interested in exploitation of this title on
 the Gameboy Advance-platform. Therefore,
 consider this a hommage to the original
 Oil's Well, and feel free to keep a copy
 for yourself. Just don't try to make any
 money of it, and you should be fine ;-)

 I would also appreciate it if you'd leave this
 readme intact, so please spread this archive as
 you found it yourself.

 Thanks.

+------------------------------------------------+
  ( s h i n t a r i a n  e n t e r p r i s e s )
+------------------------------------------------+
