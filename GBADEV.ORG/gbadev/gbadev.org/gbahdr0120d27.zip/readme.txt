gbahdr v0.1.2 by anarko 2000.09.07

* start address was wrong also some field names are changed


gbahdr v0.1.1 by anarko 2000.09.06

* cleaned up code, last version was full of unused code.
* complement check added, not sure if algorithm is correct.

