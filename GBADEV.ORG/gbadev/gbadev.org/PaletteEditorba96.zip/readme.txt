Name: J's Palette Editor

Description: a GUI for editing and converting colour palettes
Inputs: Jasc Pal, MS Pal, ACT, GBAPal(raw palette data)

Outputs: Jasc PaintShop Pal(pal), MS Pal(pal), Adobe Colour Table(ACT), GBAPal(raw palette data),
        GBA c source code, PC c source code(c), Delphi unit(pas), JavaScript(js)...

How to use it?: Look in the acompanying html file.

Source Code: Delphi 4 source code is freely available upon request.

Contact: greijos@hotmail.com

Download Site: http://www.bmts.com/~gdonald/