
Space Invaders GBA


Big thanks to Sergej Kravcenko, for the use of his excellent GBA Mod Player (GBAPlayer)
(visit his site at www.codewaves.com)

Music is taken from Project X (Amiga, Team 17), and
written by/copyright to Alistair Brimble.

Game works on real hardware and all emulators tried (VGBA,VisualBoyAdvance,BoycottAdvance)

Any comments/questions/job offers in the Yorkshire area(!), please send me a mail - ward_john@btinternet.com

Enjoy!

John Ward (October 2001)

