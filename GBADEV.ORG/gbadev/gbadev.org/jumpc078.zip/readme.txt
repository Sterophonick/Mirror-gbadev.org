jump!
V1.0

simple game where character has to jump enemies and get points by doing so.
This is my first game ever on any platform so dont expect to much :P.
very messy source included.. feel free to do any modifications you want or use any of it if you manage
to get around it.
This is just the first version of the game.. i decided to release it cus is already playable. expect
a much better enhaced version in the future.
special thnks to Dovoto for his great tutorials and tools..  and to gbadev.org for all of their resources.

blaow