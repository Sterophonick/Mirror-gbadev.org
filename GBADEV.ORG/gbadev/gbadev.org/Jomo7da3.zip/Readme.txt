JOMO VERSION 1.0
����������������

BY SAIKOU
http://www.saikou.co.uk


ABOUT THE GAME
  Jomo is a puzzle game, similar in many ways to Sokoban, a classic game by Think Rabbit Software released some time ago in the 80's. It was also heavily inspired by an old Net Yaroze game called Pushy II, by R. Fred. W.
  It is my first ever gameboy advance game (indeed, my first game for any platform other than Windows), and all my learning about the GBA was done while I was coding this (which is why it took quite a while to make, and for why the code is awful :p)
  The object of the game is to push all the glowing orbs onto the 'X's. Sounds simple enough, but there are many factors which make it more difficult than you might think. Firstly, the orbs can only be pushed, and not pulled. You can also only push one at a time. Orbs under a crate will move one space when pushed, whereas orbs not underneath a crate will roll until they hit something. Finally, there are also 'Arrow' tiles, which force Jomo to move in the direction specified when stepped upon unless there is something in the way.
  I have decided not to release the source code for this version for two reasons: 1) The code is awful, unstructured and generally embarassing, and 2) If I released the code, other people may use snippets of my bad code, and I don't want to be responsible for spreading bad code/coding practices any further :) I will however release the source code to the next version once I have completed the rewrite.
  Also, I haven't been able to test the game on a real GBA as I don't have a flash cart yet (one day...), so if anyone does try, I'd be grateful if they'd let me know how it goes.

  
CONTROLS
  Intro          : A or B to advance to next frame, START to skip intro
  Main Menu      : UP or DOWN to change selected item, A or START to select
  Pick Level Menu: UP or DOWN to change the level to play, A or START to confirm, or B to return to the main menu
  Enter Password : UP, DOWN, LEFT or RIGHT to change highlighted letter, A to add it to the password, B to delete a letter, START to confirm
  In-game        : UP, DOWN, LEFT or RIGHT to move Jomo, START to pause
  Pause menu     : UP or DOWN to change selection, A to confirm, START or B to resume the game


PASSWORDS
  The game uses a password system to unlock the levels, but any level you unlock will also be saved to SRAM, so you won't have to re-enter the  passwords each time you play.
  There are a few secret passwords hidden in the game: HINT try entering anagrams of the main characters names.
  Also, all the level passwords are acceptable words in the UK version of Scrabble (though I admit some of them are very strange...), so you might be able to guess a few, or use some of the passwords in a game of Scrabble to surprise your opponent with a word they've never heard of :)
  If you're really desperate to get past a level you're stuck on, see the manual for some hints on the password for level 100 (though I recommend you play through the game properly first :))


STILL TO COME
  Though this version is 100% complete, I still plan on rewriting the code to make it better structured, and at the same time giving the game a facelift. I may also add some more secrets.
  I'm also planning a sequel to the game, but of a different genre (probably a platformer) :)


MORE INFORMATION
  For more information, please see the manual which should have been included in this distribution (if not, please visit http://www.saikou.co.uk/projects.php to download it).


THANKS GO TO
  subduck for introducing me to GBA programming
  R. Fred. W for the inspiration for the game
  Everyone who made the levels included in this game
  Berdon, OJ and subduck for testing and their input and support
  The original composers/trackers of the music used in the game
  The graphic artists at Hudson Soft for making the bomberman tiles, many of which I stole :D
  Everyone else in the world for any reason you can think of :p


CONTACT
  If you want to contact me for any reason, you can either e-mail me at: saikou@saikou.co.uk, or visit my site's contact page for a simple e-mail form you can use: http://www.saikou.co.uk/contact.php.
  I can also usually be found at http://www.subduck.com, so if you send me a PM on the board there, I'm bound to receive it.