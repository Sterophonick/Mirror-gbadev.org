Welcome to my GBA-Sample. Is is called wizard and has several features:
Parallax Scrolling, Sprite<->BG Collisiondetection & mapsize can be
of unlimited dimensions.

For other interesting stuff go to http://stud.fh-heilbronn.de/~adimitri

Regards,

Alex
