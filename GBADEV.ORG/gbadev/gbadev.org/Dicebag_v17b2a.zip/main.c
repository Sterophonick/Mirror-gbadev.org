/* Dicebag Version 1.0
   Created By: Sean James (aka Mindlord)
   Enjoy! */
#include <stdio.h>
#include <stdlib.h>
#include <mygba.h>
#include <string.h>
#include <hel.h>
#include "courier.raw.c" // The Font tiles
#include "myfont.pal.c"  // The Font Palette (unsused - here for example)
#include "myfont.map.c"  // The Font Map (It's blank, to clear the initial display)
#include "working_background.map.c" // The Background map (The pile of dice in the lower left corner
#include "working_background.raw.c" // The Background tiles
#include "working_background.pal.c" // The Palette used by the program
#include "dicebag_splash.pal.c" // Splash screen palette
#include "dicebag_splash.raw.c" // Splash screen data

// Enable Multiboot for link cables
MULTIBOOT

// Define some variables
static double SEED = 91648253;  // Random seed number
u8 newframe=0;                  // Frame switch
u8 frames=0;                    // Frame counter
u8 selectedline=1;              // Tracks which die type is selected
u8 key = 0;                     // Which key is pressed 1-10 (0 for none)
u8 keypressed=0;                // Is a key being actively pressed (binary)

// Initialize the dice array.
int dicearray[][8] = {{4,6,8,10,12,20,100,50},
                      {1,1,1,1,1,1,1,1},
                      {0,0,0,0,0,0,0,0}};

double random (void);           // return the next random number x: 0 <= x < 1
void  rand_seed (int);          // seed the generator
void Timer3Function(void);      // This timer causes the > to blink, and refreshes the display
void ProcessInput(void);        // Horsepower behind processing user input
void rolldice(int numdice, int dice, int modifier); // Horsepower behind rolling the dice (meat and potatoes here folks)
void seanlib_RebuildAll(void);  // redraws all of the main text on the screen
void seanlib_DrawText( int bg, int row, int col, char drawout[255] ); // Text handling routine (powerful stuff)
char *seanlib_CombineStr( char *str1, char *str2); // combines 2 strings of any length and returns the result
char *seanlib_BuildDice(int ndin, int dmin, int dxin); // builds a string out of the dice infomation
char *seanlib_MakeFill(int copies, char *instring); // makes a string of n copies of instring, useful for creating a blank screen.

void hblFunc() // updates the frame counter
{
    //signify new frame
	newframe=1;
	frames++;

    // Uncomment below to see the keypad monitoring in the upper right corner of the display.
    /*
    char *keyascii="";
    int size;
    size = sprintf(keyascii, "%d", key);
    seanlib_DrawText( 1, 0, 27, keyascii);
    size = sprintf(keyascii, "%d", keypressed);
    seanlib_DrawText( 1, 0, 29, keyascii);
    */
}

int main(void)
{
    // initialize HAMlib
    ham_Init();
    // The splash screen I use is 240x160x8 paletted.
    ham_SetBgMode(4);
    hel_Splash((void*)dicebag_splash_Bitmap,         // pBitmap
               (void*)dicebag_splash_Palette,        // pPalette
               SPLASH_TYPE_BLACK,               // SplashTypeIn
               SPLASH_TYPE_BLACK,               // SplashTypeOut
               6,                               // FadeInSpeed
               6,                               // FadeOutSpeed
               80,                              // WaitFrames
               16);                             // AfterWaitFrames

	// create pointers to the two backgrounds we use
    map_fragment_info_ptr mymap; // is the text display
	map_fragment_info_ptr background; // the background of course

    
     // set the new BGMode
    ham_SetBgMode(0);
    // init the Palettes for BG and Text
	ham_LoadBGPal(&working_background_Palette,sizeof(working_background_Palette));

	// load the Font
	ham_bg[1].ti = ham_InitTileSet(&myfont_Tiles,SIZEOF_16BIT(myfont_Tiles),1,1);
	// init an empty map
	ham_bg[1].mi = ham_InitMapEmptySet(3,0);

    // load the background tiles
    ham_bg[0].ti = ham_InitTileSet(&working_background_Tiles,SIZEOF_16BIT(working_background_Tiles),1,1);
	// init an empty map
	ham_bg[0].mi = ham_InitMapEmptySet(3,0);

	// make a reference to Font data in the ROM
	mymap = ham_InitMapFragment(&myfont_Map,30,20,0,0,30,20,0);
    //  make a reference to Background data in the ROM
    background = ham_InitMapFragment(&working_background_Map,12,16,0,0,12,16,0);
	// copy background map to BG0 at x=18 y=4
	ham_InsertMapFragment(background,0,18,4);
	
	// and get it on screen
	ham_InitBg(1,1,2,0);
	ham_InitBg(0,1,3,0);

    // start hblFunc every frame
    ham_StartIntHandler(INT_TYPE_VBL,&hblFunc);
    
    //Initialize Screen
    seanlib_DrawText(1,0,0,"GBA Dicebag");
    seanlib_RebuildAll();

    // Start the timer for the blinking cursor
    ham_StartIntHandler(INT_TYPE_TIM3,               // The Interrupts ID you want to start.
                       (void *)&Timer3Function);   // The adress of a function that should be called when the interrupt is fired
   // Selects the speed of timer3
   M_TIM3CNT_SPEED_SELECT_SET(1)
   // Enable IRQ for timer3
   M_TIM3CNT_IRQ_ENABLE
   // Start timer3
   M_TIM3CNT_TIMER_START

    // Main Loop Baby!
    while(1)
    {
		
        if(newframe)
		{
            keypressed=0; // reset the keypad, and then monitor for input
            if(F_CTRLINPUT_DOWN_PRESSED)
			{
		        key = 1;
		        keypressed=1;
            }
			if(F_CTRLINPUT_UP_PRESSED)
			{
                key = 2;
                keypressed=1;
			}
			
            if(F_CTRLINPUT_RIGHT_PRESSED)
			{
		        key = 3;
		        keypressed=1;
            }

			if(F_CTRLINPUT_LEFT_PRESSED) 
			{
                key = 4;
                keypressed=1;
			}
			if(F_CTRLINPUT_R_PRESSED)
            {
			     key = 5;
			     keypressed=1;
            }
            if(F_CTRLINPUT_L_PRESSED)
            {
                key = 6;
                keypressed=1;
            }
            if(F_CTRLINPUT_A_PRESSED)
            {
                key = 7;
                keypressed=1;
            }
            if(F_CTRLINPUT_START_PRESSED)
            {
			     key = 8;
			     keypressed=1;
            }
            if(F_CTRLINPUT_SELECT_PRESSED)
            {
                key = 9;
                keypressed=1;
            }
            if(F_CTRLINPUT_B_PRESSED)
            {
                key = 10;
                keypressed=1;
                // While B is being held Do this
                ham_SetBgXY (1,0,160);
                ham_SetBgXY (0,0,160);
            }
            if ((keypressed==0) && (key != 0)) // if a key was pressed and released do something
            {
                ProcessInput();
            }
        newframe=0;
		}
    }
}


void seanlib_DrawText( int bg, int row, int col, char drawout[255] )
{
    // declare variables:
    int wrap=0;     // the line wrap counter
    int colcount=0; // the column position counter
    int i=0;        // generic counter
    char thischar;  // the ascii equivalant of the current character in the string
    int size = strlen(drawout); // length of string to process
    int scale = (myfont_Size/8); // scale of the font myfont_Size is in courier.raw.c
    row=row*scale; // adjsut position of text for scale
    col=col*scale;
    for ( i=0; i < size; i++ ) { // start the loop
        thischar = drawout[i]; // get the current character from string
        switch (myfont_Size) {	// based on the size of the font do something
            case 8:
                ham_SetMapTile( bg , col + colcount,row + wrap, thischar-32); // just place the proper tile on the right square of the background
            break;
            case 16:
                ham_SetMapTile( bg , col + colcount,row + wrap, (thischar-32)*4); // upper left corner of the character
                ham_SetMapTile( bg , col + colcount+1,row + wrap, ((thischar-32)*4)+1); // upper right
                ham_SetMapTile( bg , col + colcount,row + wrap+1, ((thischar-32)*4)+2); // lower left
                ham_SetMapTile( bg , col + colcount+1,row + wrap+1, ((thischar-32)*4)+3); // lower right
            break;
        }
        if ( col+colcount >= 30-scale ) { // wrap to the next line if we have to
            col=0;
            colcount=-1;
            wrap=wrap+scale;
        }
        colcount=colcount+scale;
    }
}
char *seanlib_CombineStr( char *str1, char *str2) { // This function is a great example of calloc. Find out more in you freindly C book
  char *str3;
  str3 = (char *)calloc(strlen(str1) + strlen(str2) + 1, sizeof(char));
  strcpy(str3, str1);
  strcat(str3, str2);
  str1 = (char *)calloc(strlen(str3) + 1, sizeof(char));
  strcpy(str1, str3);
  free(str1);
  return str3;
}
void Timer3Function(void) // draw the cursor, and update the display as needed
{
   int i=0;
   if (frames%2) { // alternate blowing up cursors and refresing the display.
    for (i=1; i<9; i++) { // wipe out any cursors being displayed (sometimes there are 2 if the user hits a key at the right time (I just didn't feel like fixing it the right way)
        seanlib_DrawText(1,i,0," ");
    }
   } else { // draw the new cursor, and update that line
     seanlib_DrawText(1,selectedline,0,">");
     seanlib_DrawText(1,selectedline,1, seanlib_BuildDice(dicearray[1][selectedline-1], dicearray[2][selectedline-1], dicearray[0][selectedline-1]));

   }
}
char *seanlib_BuildDice(int ndin, int dmin, int dxin)
{
    char *str;
    int size;
    char nd[10];
    char dm[10];
    char dx[10];
    str= "";
    // convert the integers to strings
    size = sprintf(nd,"%d",ndin);
    size = sprintf(dm,"%d",dmin);
    size = sprintf(dx,"%d",dxin);

    // combine the strings together
    str = seanlib_CombineStr(nd,"D");
    str = seanlib_CombineStr(str,dx);
    str = seanlib_CombineStr(str,"+");
    return seanlib_CombineStr(str,dm);
}

void seanlib_RebuildAll(void){
    int i=0;
    for (i=1; i<9; i++) { // draws all of the dice data on the display.
        seanlib_DrawText(1,i,1, seanlib_BuildDice(dicearray[1][i-1], dicearray[2][i-1], dicearray[0][i-1]));
    }
}

void ProcessInput(void)
{
    switch (key) {
        case 1: // Pressed Down
           	if(selectedline<8){
                selectedline++;
            }
        break;
        case 2: // Pressed Up
          	if(selectedline>1){
                selectedline--;
            }
        break;
        case 3: // Pressed Right
            if (dicearray[1][selectedline-1]<99){
                dicearray[1][selectedline-1]++;
            }

        break;
        case 4: // Pressed Left
            if (dicearray[1][selectedline-1]>1){
                dicearray[1][selectedline-1]--;
            }
        break;
        case 5: // Pressed Right Shoulder
            if (dicearray[2][selectedline-1]<99){
                dicearray[2][selectedline-1]++;
            }
        break;
        case 6: // Pressed Left Shoulder
            if (dicearray[2][selectedline-1]>0){
                dicearray[2][selectedline-1]--;
            }
        break;
        case 7: // Pressed A
            rolldice (dicearray[1][selectedline-1], dicearray[0][selectedline-1],dicearray[2][selectedline-1]);
        break;
        case 8: // Pessed Start
              if (dicearray[0][7]<99) {
                   dicearray[0][7]++;
              }
        break;

        case 9: // Pressed Select
              if (dicearray[0][7]>1) {
                   dicearray[0][7]--;
              }
         break;
        case 10: // Released B
            ham_SetBgXY (1,0,0);
            ham_SetBgXY (0,0,0);
        break;
    }
    key=0;
}

// Borrowed this code so I'm not an expert on it.
void rolldice(int numdice, int dice, int modifier) {
    rand_seed(frames); // seed the random number generator witht the current frame count.
    int i=0; // generic coutner
    char *str = ""; // str for holding the final result
    char *inidice = "("; // holds each induvidual roll
    int size=0; // place holder for the sprintf result (I don't use it)
    int roll=0; // integer roll result
    // used to blank the second page
    char *filler="                                                                                                                                                                                                                                             ";
    // current roll result
    int thisroll=0;

    for (i=0; i < numdice; i++) { // loop based on the number of dice to be rolled
        thisroll = (int) ((double)rand() * (double)dice / (double)((double)RAND_MAX + 1))+1; // magic randomness
        roll = roll + (int) thisroll; // add it up
        str= ""; // initialize the string
        size = sprintf(str,"%d", (int) thisroll); //convert thisroll to a string
        inidice= seanlib_CombineStr(inidice,str); // combine it with inidice
        if (i != numdice-1) { // if this is not the last roll put a plus sign on it
            inidice = seanlib_CombineStr(inidice,"+");
        }
    }

    inidice= seanlib_CombineStr(inidice,")+"); // cap off the rolls with a closing pren and a plus
    size = sprintf(str,"%d",(int) modifier); // convert the modifier to astring
    inidice= seanlib_CombineStr(inidice,str); // add it to the end of inidice
    if (numdice<=30) { // if there weren't a whole booogaloo of dice; display the induvidual results on page 2
        seanlib_DrawText(1,10,0,filler); // clear the second page
        seanlib_DrawText(1,10,0,inidice); // print the induvidual dice resuits
    }
    roll=roll+modifier; // add the modifier to the final tally
    str= ""; // initialize the string
    size = sprintf(str,"%d",(int) roll); // convert the final tally to a string
    str= seanlib_CombineStr("Rolled: ",str); // make it pretty
    str= seanlib_CombineStr(str,"  ");
    seanlib_DrawText(1,9,0,str); // print it on the bottom line of page 1
    seanlib_DrawText(1,19,0,str); // print it on the bottom line of page 2
}


// not my code at all
double random ()
{
/* The following parameters are recommended settings based on research
   uncomment the one you want. */

 static double a = 1389796, m = 2147483647;
/* static double a = 950975,  m = 2147483647;  */
/* static double a = 3467255, m = 21474836472; */
/* static double a = 657618,  m = 4294967291;  */
/* static double a = 93167,   m = 4294967291;  */
/* static double a = 1345659, m = 4294967291;  */

   int q;

   SEED *= a;
   q = SEED / m;
   SEED -= q*m;
   return (SEED);
 }


// not my code at all
void rand_seed (int init)
{
    if (init != 0) SEED = init;
}

char *seanlib_MakeFill(int copies, char *instring) {
    int i=0;
    char *str="";
    for (i=0; i<copies; i++) {
        str = seanlib_CombineStr(str,instring);
    }
    return str;
}
