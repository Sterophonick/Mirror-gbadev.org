Dicebag version 1.0
Developed by Sean James (Aka. Mindlord)
Using the HAM development library with HEL extensions

Random Number Generation Code for GCC compilers borrowed from:
http://remus.rutgers.edu/~rhoads/Code/random_fl.c

---Purpose:
to create a simple dice rolling program.

---Usage:
The GBA keys perform the following actions
UP/DOWN - change the currently selected die type (4, 6, 8, 10, 12, 20, 100, n) sided.
LEFT/RIGHT - Decrement/Increment the number of times the selected die type should be rolled.
LEFT SHOULDER/RIGHT SHOULDER - Decrement/Increment the modifier that should be applied to 	the final result.
START/SELECT - Decrement/Increment the number of sides on the (n) sided die.
A - Rolls the selected die type and displays the final result
B - when held displays each induvidual die roll, as well as the final result.

---Points of interest:

An example of using an array to store data about the state of the dice.

Examples of how to use the HAM library to initialize background modes 0 and 4. 

Examples of interacting with a tiled map mode, and use of layered backgrounds. Text appears on bg layer 1, and the dice image appears on bg layer 0.

An example of the HEL library - specifically the hel_Splash function.

Monitoring user input in a controlled fashion to manipulate the dice variables.
	Specifically using a press/release action before processing input for most actions,
	and using a press and hold action for viewing roll details.


---There are several functions that are useful outside of the project:
	
The main loop shows how to make use of the GBA keypad in conjunction with ProcessInput().

void ProcessInput(void);
	demonstrates how to control user input for the purposes of menus.

void rolldice(int numdice, int dice, int modifier);
	demonstrates the use of random number generation.
	
void seanlib_DrawText( int bg, int row, int col, char drawout[255] );
	Is a relatively fast text output routine that can detect if the font is 8x8 pixels 	or 16x16 pixels and react accordingly.

char *seanlib_CombineStr( char *str1, char *str2);
	Is a quick and dirty string combining routine, since printf is slow.
	
char *seanlib_BuildDice(int ndin, int dmin, int dxin);
	demonstrates converting integers to strings and combining them in a useful way using 	seanlib_CombineStr.

