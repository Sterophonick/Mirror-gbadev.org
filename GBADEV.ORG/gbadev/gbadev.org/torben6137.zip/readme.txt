TORBEN'S MARVELLOUS ADVENTURE
-----------------------------
This game resembles the classical Pac-Man at first sight, but the
game play is quite different. You should help Torben, a chicken,
to the exit door in the left wall in each maze. In order to open
the door, you will have to carry a key through the maze. Since
the key is heavy (almost as big as Torben is!) you move much
slower when carrying the key.

This sounds simple, except for the fact that there are several
nasty foxes lurking around in the mazes, looking for a fat
chicken for their next meal...

The mazes are filled with food, and eating the food will increase
your strength. Carrying the key drains the strength much faster
than walking around does otherwise; also, when carrying the key
you can't eat!

With enough strength, you are powerful enough to "kill" the foxes
when colliding with them. This will decrease your strength a lot
though, so this should, if possible, be avoided since you don't
get any score for this (and the fox reappears from it's starting
location immediately upon this).

If your strength goes too low, you will become unconscious for a
while, and will most likely be an easy target for the wolves
unless you're lucky to wake up in time.

Every now and then, the foxes drop some bonus food on the level.
It can be a cake, an apple or - Torben's favourite - a hamburger!
Eating these will increase your strength quite a lot, so look out
for these!

Also to your help you have a "stop signal", which at the
beginning of the level is located in the upper left corner. It
doesn't do any good while you're carrying it around, but whenever
you set it down, it will become an obstacle for the foxes (but
not for you). You can not carry both the stop signal and the key
at the same time. Carrying the stop signal won't slow you down,
and you can eat at the same time as well.

You will start with two extra lives, and receive (unless you have
three extra lives) an extra life every third level (unless you
manage to warp the game, no more extra lives then!). If you die,
you will continue from the same position (the foxes will be
gone), and the game will start off immediately, so don't dawdle!

The wolves will become more, and hungrier!, the further into the
game you get. The game speed will also pick up quite a lot - it
starts of slowly, but if you manage to reach the last levels, you
are likely to be experiencing the fastest Pac-Man action-styled
game you've ever seen!!


Controls
--------
left/right/up/down  - Move Torben left/right/up/down
A/B                 - Pick up/Drop key or stop signal
A/B + l/r/u/d       - Run
Start               - Pause the game


Hints
-----
* Don't think Pac-Man! The goal of the game is not to eat all the
  food in each level, nor to kill the foxes. It's all about getting
  the key to the exit door on each level.

* Since you don't - unlike Pac-Man - walk automatically even when
  you're not holding down any key, it might take some time to walk
  around in the maze without getting "stuck" in the walls. To
  master the controls, try walking diagonally when entering
  corridors in the middle of a corridor.

* You only score when eating the seed on each level. You don't
  score when killing foxes, nor when eating the food they drop. You
  score more on higher levels.

* Since you start each maze with the same strength as you left
  the previous maze, try to enter each new level "fully loaded".

* If you are chased by the foxes it might help to run (A/B +
  keypad). You cannot carry anything when running, nor will you
  be able to eat, but it might very well save your life (for a while)

* The key to master the game is to master the stop signal. Try to
  carry it around as often as possible and put it on strategic
  positions. Note: it won't help to put it just outside the foxes
  lair! (that would be too easy...)

* If your fingers hurt, pause the game!


Credits
-------
Programming         Jimmy M�rdell
Graphics            Thanius
Sound               Erik Grahn-J�rlund
Original Concept    Dan Haggren

This game was created during a single weekend in February 2002.


Comments
--------
Please feel free to send comments, suggestions or whatever to
jimmy@yarin.se
