#ifndef _wavplay_h
#define _wavplay_h

#include "Agb.h"

#define WAV_L             0x01    // Play sample in left channel
#define WAV_R             0x02    // Play sample in right channel
#define WAV_LR            0x03    // Play sample in left & right channel
#define WAV_HALF          0x04    // Play sample at half volume
#define WAV_LOOP          0x08    // Loop sample

#define CH_A              0x01
#define CH_B              0x02
#define CH_AB             0x03

void wavInit(void);
void wavPlay(u32*, u32, u32);
void wavStop(u32);
void wavVBlank(void);

extern s32 wavCntA, wavCntB;
extern u32 wavLoopA, wavLoopB;
extern u32 *wavA, *wavB;
extern u32 wavStereo;

#endif