#include "main.h"
#include "intr.h"
#include "misc.h"
#include "wavplay.h"

/*------------------------------------------------------------------*/
/*                      Interrupt Table                             */
/*------------------------------------------------------------------*/

IntrFuncp IntrTable[14] = {
		VBlankIntr,     // V Blank interrupt
    HBlankIntr,     // H Blank interrupt
    VCounterIntr,   // V Counter interrupt
    IntrDummy,      // Timer 0 interrupt
    IntrDummy,      // Timer 1 interrupt
    IntrDummy,      // Timer 2 interrupt
    IntrDummy,      // Timer 3 interrupt
    IntrDummy,      // Serial communication interrupt
    IntrDummy,      // DMA 0 interrupt
    IntrDummy,      // DMA 1 interrupt
    IntrDummy,      // DMA 2 interrupt
    IntrDummy,      // DMA 3 interrupt
    IntrDummy,      // Key interrupt
    IntrDummy,      // Cassette interrupt
};

extern void intr_main(void);

IntrFuncp VBlankHandler,HBlankHandler,VCounterHandler;


/*==================================================================*/
/*                      Interrupt Routine                           */
/*==================================================================*/

/*------------------------------------------------------------------*/
/*                      V Blank Process                             */
/*------------------------------------------------------------------*/

#define RESET_BUTTON (A_BUTTON|B_BUTTON|START_BUTTON|SELECT_BUTTON)

void VBlankIntr(void)
{
	static u32 lastKeyCur=0;
	u32 cur;

	wavVBlank();
	
	CpuFastArrayCopy(OamBak,OAM);

	randSeed++;
	
	cur=(*(vu16*)REG_KEYINPUT^0xFFFF);
	keyTrg=cur&(cur^lastKeyCur);
	keyCur=lastKeyCur=cur;

	*(vu16*)REG_BG0HOFS=4;
	*(vu16*)REG_BG0VOFS=scrollY;

	if (VBlankHandler)
		VBlankHandler();

	if (((*(vu16*)REG_KEYINPUT^0xFFFF)&RESET_BUTTON)==RESET_BUTTON)
		SoftResetRom(RESET_REG_FLAG|RESET_REG_SOUND_FLAG);
	
  *(u16*)INTR_CHECK_BUF|=V_BLANK_INTR_FLAG;     // Set V Blank interrupt check    
}

/*------------------------------------------------------------------*/
/*                      H Blank Process                             */
/*------------------------------------------------------------------*/

void HBlankIntr(void)
{
	if (HBlankHandler)
		HBlankHandler();
  *(u16*)INTR_CHECK_BUF|=H_BLANK_INTR_FLAG;     // Set H Blank interrupt check    
}

/*------------------------------------------------------------------*/
/*                      VCounter Process                            */
/*------------------------------------------------------------------*/

void VCounterIntr(void)
{
	if (VCounterHandler)
		VCounterHandler();
	*(u16*)INTR_CHECK_BUF |= V_COUNT_INTR_FLAG;	
}


/*------------------------------------------------------------------*/
/*                      Interrupt Dummy Routine                     */
/*------------------------------------------------------------------*/

void IntrDummy(void)
{
}


/*==================================================================*/
/*                      Init interrupts                             */
/*==================================================================*/

void intrInit(void) {
	VBlankHandler=(IntrFuncp)0;
	HBlankHandler=(IntrFuncp)0;
	VCounterHandler=(IntrFuncp)0;
  *(vu32 *)INTR_VECTOR_BUF = (vu32 )intr_main;
}
