#include "main.h"
#include "misc.h"
#include "intr.h"
#include "wavplay.h"

#include "gfx/bggfx.c"
#include "gfx/sprites.c"
#include "gfx/torbenspr.c"
#include "gfx/text.c"
#include "gfx/title.c"

//#define IMMORTAL

#define BG0_SB 24
#define BG1_SB 25
#define BG2_SB 26

#define OBJ_TORBEN 0
#define OBJ_KEY 1
#define OBJ_STOP 2
#define OBJ_WOLF 3

#define MINSCROLLY -12
#define MAXSCROLLY 28
#define SPRXADJ 8
#define SPRYADJ 4

#define DOORY 109

#define MAX_OBJECTS 10
#define MAX_HEALTH (24*8)
#define DRAIN_TIME 48
#define FIRST_STAGE 0
#define NO_STAGES 17

#define BAR_INDEX 1 // Palette index to flash
#define FLASHRED_LIMIT 16
#define FLASHWHITE_LIMIT 128
#define WOLF_TIME 90

#define FOODDROP_MINTIME 20
#define FOODDROP_FREQ 96

#include "levels.c"
#include "demo.c"

#define SIREN_RAM   (EX_WRAM+0x1000)

extern const u32 _binary_wav_titlemel_bin_start[];
extern const u32 _binary_wav_eat1_bin_start[];
extern const u32 _binary_wav_eat2_bin_start[];
extern const u32 _binary_wav_eat3_bin_start[];
extern const u32 _binary_wav_siren_bin_start[];
extern const u32 _binary_wav_siren_bin_size[];
extern const u32 _binary_wav_stopfx_bin_start[];
extern const u32 _binary_wav_keyfx_bin_start[];
extern const u32 _binary_wav_die_bin_start[];

struct TObject
{
	s16 type; // 0 = Torben, 1 = Wolf, 2 = Key, 3 = Stop sign
	s16 x,y;
	s16 dir; // 0 = left, 1 = right, 2 = up, 3 = down
	u16 framecnt; // Increase one for every moving frame
	s16 frametype; // Torben only: 0 = not eating, 1 = eating
	s16 state; // 0 = don't exist
	s16 cnt; // General counter
	s16 color; // Wolf only: 0-4
	s16 carry; // If Torben: Carried object. Otherwise: True if carried by Torben
	s16 stophit; // Wolf only: Number of frames until wolf can be stopped by stop sign
} obj[MAX_OBJECTS];

OamData OamBak[128];

s8 walls[22][29],food[20][27];
u16 obj_pltt_bak[256];
s32 scrollY,score,hiscore,health,lives,stage,lvl,maxwolves,difficulty;

const u16 foodBar[31]={
	132,128,129,130,131,132,161,161,163,163,163,163,163,163,163,163,
	163,163,163,163,163,163,165,165,165,165,165,165,165,165,132};
const u16 scoreBar[31]={
	143,133,134,135,144,144,144,144,144,144,143,
	136,137,138,144,144,144,144,144,144,143,
	155,155,142,143,
	139,140,141,144,145,143};

void putTile(u32 x, u32 y, u32 tile, u32 sb)
{
	switch (sb) {
		case 0 : ((u16*)(VRAM+(BG0_SB<<11)))[(y<<5)+x]=tile; break;
		case 1 : ((u16*)(VRAM+(BG1_SB<<11)))[(y<<5)+x]=tile; break;
	}
}

void showScore(u32 sc, u32 x)
{
	u32 i;
	for(i=0;i<6;i++) {
		putTile(x+5-i,19,144+sc%10,1);
		sc=Div(sc,10);
	}
}

void updateScore(s32 add)
{
	score+=add;
	showScore(score,4);
}

void updateStage(s32 stage)
{
	stage++;
	putTile(28,19,144+Div(stage,10),1);
	putTile(29,19,144+stage%10,1);
}

void updateLives(s32 lives)
{
	u32 i;
	for(i=0;i<3;i++)
		putTile(21+i,19,i<lives?155:142,1);

}

u32 noBonus(s32 x, s32 y)
{
	if ((x<0) || (y<0) || (x>=27) || (y>=20))
		return 1;
	return food[y][x]<2;
}

void blend(u32 first, u32 last, u32 col, u32 intensity)
{
	u16 i,j,r1,g1,b1,r2,g2,b2;

	r2=col&31;
	g2=(col>>5)&31;
	b2=(col>>10);
	for(i=first;i<last;i++) {
		j=obj_pltt_bak[i];
		r1=j&31;
		g1=(j>>5)&31;
		b1=(j>>10);

		r1=(r2*intensity+r1*(32-intensity))>>5;
		g1=(g2*intensity+g1*(32-intensity))>>5;
		b1=(b2*intensity+b1*(32-intensity))>>5;

		((vu16*)OBJ_PLTT)[i]=r1|(g1<<5)|(b1<<10);
	}
}

void showText(u32 n)
{
	u32 i;

	CpuFastClear(0,VRAM+(BG2_SB<<11),2048);
	*(vu16*)REG_BG2CNT=BG_COLOR_16 | BG_SCREEN_SIZE_0 | BG_PRIORITY_1 |
		(BG2_SB << BG_SCREEN_BASE_SHIFT) | (2 << BG_CHAR_BASE_SHIFT);
	*(vu16*)REG_BG2HOFS=0;
	*(vu16*)REG_BG2VOFS=4;
	n*=96;
	for(i=0;i<96;i++)
		((u16*)(VRAM+(BG2_SB<<11)))[i+(9<<5)]=(i+n)|(8<<12);
	*(vu16*)REG_DISPCNT|=DISP_BG2_ON;
}

void removeText(void)
{
	*(vu16*)REG_DISPCNT&=~DISP_BG2_ON;
	CpuFastClear(0,VRAM+(BG2_SB<<11),2048);
}

void showTitlePic(void)
{
	s32 i,j;

	*(vu16*)REG_BG2CNT=0;
	*(vu16*)REG_DISPCNT=DISP_MODE_3;
	CpuFastArrayCopy(title_RawBitmap,VRAM);
	fadeInWhite(BLD_BG2);

	waitKeyDelay(300,AB_BUTTON);
	fadeOutWhite(BLD_BG2);
	*(vu16*)REG_DISPCNT=DISP_MODE_0;
	for(i=256-24;i>=0;i-=24) {
		VBlankIntrWait();
		j=i>>3;
		*(vu16*)PLTT=j|(j<<5)|(j<<10);
	}
}


u8 tile[3][8][8];

void updateFood(s32 hp)
{
	u32 i,t,x,y;
	for(i=0;i<24;i++) {
		if (i<2) t=160; else if (i<16) t=162; else t=164;
		if (hp>=(i<<3)+8)
			putTile(i+6,0,t+1,1);
		else if (hp<(i<<3))
			putTile(i+6,0,t,1);
		else {
			CpuCopy(VRAM+(t<<6),tile[0],64,32);
			CpuCopy(VRAM+((t+1)<<6),tile[1],64,32);
 			for(x=0;x<8;x++)
				for(y=0;y<8;y++)
					tile[2][y][x]=tile[hp>=(i<<3)+x][y][x];
			CpuCopy(tile[2],VRAM+(166<<6),64,32);
			putTile(i+6,0,166,1);
		}
	}
}

void initLevel(u32 no)
{
	u32 x,y;

	CpuFastClear(0,VRAM+(BG0_SB<<11),2048);
	CpuFastClear(0,VRAM+(BG1_SB<<11),2048);

	for(y=0;y<22;y++)
		for(x=0;x<29;x++)
			walls[y][x]=15;

	for(y=1;y<21;y++)
		for(x=1;x<28;x++) {
			food[y-1][x-1]=level[no][y-1][x-1]=='.';
			if (level[no][y-1][x-1]=='.') {
				walls[y-1][x-1]&=11;
				walls[y-1][x]&=9;
				walls[y-1][x+1]&=13;
				walls[y][x-1]&=3;
				walls[y][x]=0;
				walls[y][x+1]&=12;
				walls[y+1][x-1]&=7;
				walls[y+1][x]&=6;
				walls[y+1][x+1]&=14;
			}
		}
	for(y=0;y<22;y++)
		for(x=0;x<29;x++) {
			if ((y>0) && (y<21) && (x>0) && (x<28) && (level[no][y-1][x-1]=='.'))
				putTile(x+1,y,1,0);
			else
				putTile(x+1,y,16+walls[y][x],0);
		}

	for(y=0;y<22;y++) {
		putTile(0,y,28,0);
		putTile(30,y,19,0);
	}
	for(x=1;x<30;x++) {
		putTile(x,31,22,0);
		putTile(x,22,25,0);
	}
	putTile(0,31,20,0);
	putTile(30,31,18,0);
	putTile(0,22,24,0);
	putTile(30,22,17,0);

	for(y=0;y<4;y++)
		for(x=0;x<2;x++) {
			putTile(x,y+13,(y<<4)+x+32,0);
			putTile(29+x,y+13,(y<<4)+x+34,0);
		}

	for(x=0;x<31;x++) {
		putTile(x,0,foodBar[x],1);
		putTile(x,19,scoreBar[x],1);
	}

	updateScore(0);
	showScore(hiscore,14);
	updateFood(health);
	updateLives(lives);
	updateStage(stage);

	scrollY=MINSCROLLY;

	resetSprites();
	*(vu16*)REG_BG0CNT=BG_COLOR_256 | BG_SCREEN_SIZE_0 | BG_PRIORITY_3 | (BG0_SB << BG_SCREEN_BASE_SHIFT);
	*(vu16*)REG_BG1CNT=BG_COLOR_256 | BG_SCREEN_SIZE_0 | BG_PRIORITY_2 | (BG1_SB << BG_SCREEN_BASE_SHIFT);
	*(vu16*)REG_BG1HOFS=4;
	*(vu16*)REG_BG1VOFS=0;
	*(vu16*)REG_DISPCNT=DISP_MODE_0 | DISP_OBJ_ON | DISP_OBJ_CHAR_2D_MAP;

	CpuArrayClear(0,obj,16);

	obj[0].state=1;
	obj[0].type=OBJ_TORBEN;
	obj[0].x=26*8;
	obj[0].y=0;

	obj[0].dir=0;
	obj[0].frametype=0;
	obj[0].framecnt=0;
	obj[0].carry=0;

	obj[1].state=1;
	obj[1].type=OBJ_KEY;
	obj[1].x=26*8;
	obj[1].y=0;
	obj[1].carry=0;

	obj[2].state=1;
	obj[2].type=OBJ_STOP;
	obj[2].x=0;
	obj[2].y=0;
	obj[2].carry=0;
}

u32 validPosition(s32 x, s32 y)
{
	return
		food[(y+0)>>3][(x+0)>>3] &&
		food[(y+7)>>3][(x+0)>>3] &&
		food[(y+7)>>3][(x+7)>>3] &&
		food[(y+0)>>3][(x+7)>>3];
}

u32 updatePosition(u32 key, struct TObject *p)
{
	s32 x,y,ox,oy,done=0;

	ox=x=p->x;
	oy=y=p->y;
	if (key & U_KEY) { y--; p->dir=2; }
	if (key & D_KEY) { y++; p->dir=3; }
	if (y<0) y=0;
	if (y>19*8) y=19*8;
	if (validPosition(x,y)) p->y=y; else y=p->y;

	if (key & L_KEY) { x--; p->dir=0; }
	if (key & R_KEY) { x++; p->dir=1; }
	if ((y>=DOORY-4) && (y<=DOORY+4) && (x==-1) && (p->carry==OBJ_KEY))
		done=1;
	if (x<0) x=0;
	if (x>26*8) x=26*8;
	if (validPosition(x,y)) p->x=x; else x=p->x;

	return done?2:((x!=ox) || (y!=oy));
}

// mode = 0 => ordinary play
// mode = 1 => record keystrokes
// mode = 2 => play keystrokes

s32 playLevel(s32 mode, u8 *keys)
{
	s32 i=0,j,flag,maincnt=0,x,y,ox,oy,xt,yt,objno,flashcnt=0,speed,gamespeed,speedcnt;
	s32 draincnt=0,dead=0,uncon=0,done=0,door,stopMoved=0,agg=0,timecnt=0;
	s32 maxwolves,wolves,dechealth=0,newlevel=1,lvl,lastnewwolf,lastKeyCur=0,oldcur=0;
	s32 wolf[5];
	struct TObject *p;

	if (mode) // Make sure random seed is reset if demo mode!!
		randSeed=0;
	
	// Setup some level parameters
	lvl=stage+difficulty*NO_STAGES;
	wolf[0]=0; wolf[1]=0;
	switch (lvl) {
		case  0 : gamespeed=256; wolf[2]=40; wolf[3]=60; wolf[4]= 80; agg=140; break;
		case  1 : gamespeed=248; wolf[2]=30; wolf[3]=50; wolf[4]= 70; agg=130; break;
		case  2 : gamespeed=240; wolf[2]=20; wolf[3]=40; wolf[4]= 60; agg=120; break;
		case  3 : gamespeed=233; wolf[2]=10; wolf[3]=30; wolf[4]= 50; agg=110; break;
		case  4 : gamespeed=226; wolf[2]= 0; wolf[3]=20; wolf[4]= 40; agg=100; break;
		case  5 : gamespeed=219; wolf[2]= 0; wolf[3]=10; wolf[4]= 30; agg= 90; break;
		case  6 : gamespeed=213; wolf[2]= 0; wolf[3]= 0; wolf[4]= 25; agg= 80; break;
		case  7 : gamespeed=206; wolf[2]= 0; wolf[3]= 0; wolf[4]= 20; agg= 70; break;
		case  8 : gamespeed=200; wolf[2]= 0; wolf[3]= 0; wolf[4]= 15; agg= 60; break;
		case  9 : gamespeed=194; wolf[2]= 0; wolf[3]= 0; wolf[4]= 10; agg= 55; break;
		case 10 : gamespeed=188; wolf[2]= 0; wolf[3]= 0; wolf[4]=  0; agg= 50; break;
		case 11 : gamespeed=183; wolf[2]= 0; wolf[3]= 0; wolf[4]=  0; agg= 45; break;
		case 12 : gamespeed=177; wolf[2]= 0; wolf[3]= 0; wolf[4]=  0; agg= 40; break;
		case 13 : gamespeed=172; wolf[2]= 0; wolf[3]= 0; wolf[4]=  0; agg= 35; break;
		case 14 : gamespeed=167; wolf[2]= 0; wolf[3]= 0; wolf[4]=  0; agg= 35; break;
		case 15 : gamespeed=162; wolf[2]= 0; wolf[3]= 0; wolf[4]=  0; agg= 30; break;
		case 16 : gamespeed=157; wolf[2]= 0; wolf[3]= 0; wolf[4]=  0; agg= 30; break;
		default : gamespeed=152; wolf[2]= 0; wolf[3]= 0; wolf[4]=  0; agg= 25; break;
	}
	for(i=0;i<5;i++)
		wolf[i]*=60;
	agg*=60;
	wolves=maxwolves=0;
	lastnewwolf=0;
	speedcnt=256;

	while (1) {
		speedcnt+=gamespeed;
		if (speedcnt>=256) {
			VBlankIntrWait();
			if (mode) {
				if ((keyTrg & (AB_BUTTON | START_BUTTON)) && !newlevel) {
					removeText();
					return 1;
				}
				newlevel=0;
				if (mode==1)
					*keys++=keyCur&255;
				else
					keyCur=*keys++;				
				keyTrg=keyCur&(keyCur^oldcur);
				oldcur=keyCur;
			}				
			timecnt++;
			speedcnt-=256;
		} else
			keyTrg&=L_KEY|R_KEY|U_KEY|D_KEY;
		if (newlevel && !mode) // No movement until you've pressed START
			keyTrg=0;
		door=1;
		for(objno=0;objno<MAX_OBJECTS;objno++) {
			p=obj+objno;
			if (!p->state) {
				objRemove(objno);
				continue;
			}
			switch (p->type) {
				case OBJ_TORBEN : // Torben
					flag=0;
					ox=p->x;
					oy=p->y;

					if (uncon) {
						uncon+=3;
						health=4+(uncon>>6);
						if (health>20)
							uncon=0;
					}

					speed=((keyCur & AB_BUTTON) && !p->carry)?2:1;

					if (((p->carry!=OBJ_KEY) || (maincnt&1)) && !uncon && (keyCur&(L_KEY|R_KEY|U_KEY|D_KEY))) {
						for(i=0;i<speed;i++) {
							j=updatePosition(keyCur,p);
							if (j) {
								lastKeyCur=keyCur;
								if (j==2) {
									done=1;
									i=speed;
								}
							}
							else
								updatePosition(lastKeyCur,p);
						}
					}
					x=p->x;
					y=p->y;

					if ((x!=ox) || (y!=oy)) {
						flag=1;
						p->framecnt++;
						draincnt+=(p->carry==OBJ_KEY?8:1);
					}

					if (timecnt&1) {
				 		if (y-scrollY>80) scrollY++;
				 		if (y-scrollY<60) scrollY--;
				 	}
				 	if (y-scrollY>90) scrollY=y-90;
				 	if (y-scrollY<50) scrollY=y-50;
			 		if (scrollY<MINSCROLLY) scrollY=MINSCROLLY;
			 		if (scrollY>MAXSCROLLY) scrollY=MAXSCROLLY;

			 		if (flag) {
			 			xt=(x+4)>>3;
			 			yt=(y+4)>>3;
			 			if ((food[yt][xt]>0) && (p->carry!=OBJ_KEY) && (speed==1)) { // Eating
			 				switch (food[yt][xt]) {
			 					case 1 :
			 						updateScore(lvl+1);
                  wavPlay((u32*)_binary_wav_eat1_bin_start,CH_B,WAV_LR);
			 						health++;
			 						break;
			 					case 2 : // Hamburger
			 						health+=50;
                  wavPlay((u32*)_binary_wav_eat2_bin_start,CH_B,WAV_LR);
			 						break;
			 					case 3 : // Cake
			 						health+=16;
                  wavPlay((u32*)_binary_wav_eat2_bin_start,CH_B,WAV_LR);
			 						break;
			 					case 4 : // Apple
			 						health+=8;
                  wavPlay((u32*)_binary_wav_eat2_bin_start,CH_B,WAV_LR);
			 						break;
			 				}
				 			food[yt][xt]=-1;
			 				putTile(xt+2,yt+1,0,0);
			 				if (health>MAX_HEALTH)
			 					health=MAX_HEALTH;
			 				if (!p->frametype)
				 				p->framecnt=0;
			 				p->frametype=1;
			 				p->cnt=8;
			 			}
			 			if (p->frametype==1) {
				 			if (!--p->cnt)
			 					p->frametype=0;
			 			}
			 		}

					if ((keyTrg & AB_BUTTON) && !uncon) {
						if (p->carry) {
              switch (p->carry) {
                case 1 : wavPlay((u32*)_binary_wav_keyfx_bin_start,CH_B,WAV_LR); break;
                case 2 : wavPlay((u32*)_binary_wav_stopfx_bin_start,CH_B,WAV_LR); break;
              }
							obj[p->carry].carry=0;
							p->carry=0;
						} else {
							for(i=OBJ_STOP;(i>=OBJ_KEY) && !p->carry;i--)
								if ((abs(p->x-obj[i].x)<14) && (abs(p->y-obj[i].y)<14)) {
									obj[i].carry=1;
									p->carry=i;
								}
              switch (p->carry) {
                case 1 : wavPlay((u32*)_binary_wav_keyfx_bin_start,CH_B,WAV_LR); break;
                case 2 : wavPlay((u32*)_binary_wav_stopfx_bin_start,CH_B,WAV_LR); break;
              }
						}
					}
					if (draincnt>=DRAIN_TIME) {
						draincnt=0;
						health--;
						if (health<4)
							uncon=1;
					}
					switch (p->dir) {
						case 0 : i=0; break;
						case 1 : i=16; break;
						case 2 : i=64; break;
						case 3 : i=80; break;
					}
					i+=(p->frametype<<3)+(((p->framecnt>>1)&3)<<1);
					objPut16(2,p->x+SPRXADJ,p->y+SPRYADJ-scrollY,uncon?128:i,OAM_SIZE_16x16,-1,3,0,8);
					break;
				case OBJ_KEY : // Key
					if (p->carry) {
						p->x=obj[0].x;
						p->y=obj[0].y;
					}
					objPut(0,p->x+SPRXADJ,p->y+SPRYADJ-scrollY,(12<<6)+20,OAM_SIZE_16x16,-1,3,0);
					break;
				case OBJ_STOP : // Stop signal
					if (p->carry) {
						p->x=obj[0].x;
						p->y=obj[0].y;
						stopMoved=1;
					}
					objPut(1,p->x+SPRXADJ,p->y+SPRYADJ-scrollY,(12<<6)+16,OAM_SIZE_16x16,-1,3,0);
					break;
				case OBJ_WOLF : // Wolf
					if (p->x>26*8)
						door=0;
					else if (!(p->x&7) && !(p->y&7)) {
						// Choose direction
						xt=p->x>>3;
						yt=p->y>>3;
						j=15-(1<<(p->dir^1)); // Not opposite direction!
						if (!xt || !food[yt][xt-1]) j&=14;
						if (!yt || !food[yt-1][xt]) j&=11;
						if ((xt==26) || !food[yt][xt+1]) j&=13;
						if ((yt==19) || !food[yt+1][xt]) j&=7;
						if (!j) j=1<<(p->dir^1); // Safety precaution

						i=-1;
						if ((maincnt>agg) && (random(100)<maincnt-agg) && (p->color>=3)) {
							// Turn toward Torben if possible
							if ((p->x>obj[0].x+2) && (j&1)) i=0;
							if ((p->x<obj[0].x-2) && (j&2)) i=1;
							if ((p->y>obj[0].y+2) && (j&4)) i=2;
							if ((p->y<obj[0].y-2) && (j&8)) i=3;
						}
						if (i<0) {
							do {
								i=random(4);
							} while (!(j&(1<<i)));
						}

						p->dir=i;
						// Drop food?
						if (noBonus(xt,yt-1) && noBonus(xt,yt+1) && noBonus(xt-1,yt) && noBonus(xt+1,yt) && noBonus(xt,yt) && (p->cnt--<0) && !random(FOODDROP_FREQ)) {
							switch (random(5)) {
								case 0 : i=2; break;
								case 1 : case 2 : i=3; break;
								case 3 : case 4 : i=4; break;
							}
							food[yt][xt]=i;
							putTile(xt+2,yt+1,1+i,0);
							p->cnt=FOODDROP_MINTIME;
						}
					}
					p->framecnt++;
					switch (p->dir) {
						case 0 : p->x--; break;
						case 1 : p->x++; break;
						case 2 : p->y--; break;
						case 3 : p->y++; break;
					}
					if (!p->dir && (p->y==DOORY) && (p->x==26*8))
						p->dir=2+random(2);
					switch (p->color) {
						case 0 : i=256; break;
						case 1 : i=768; break;
						case 2 : i=512+16; break;
						case 3 : i=256+16; break;
						case 4 : i=512; break;
					}
					i+=(p->dir<<6)+(((p->framecnt>>1)&3)<<2);
					objPut(objno,p->x+SPRXADJ,p->y+SPRYADJ-scrollY,i,OAM_SIZE_16x16,-1,3,0);
					if (p->stophit)
						p->stophit--;
					// Check if collision with stop sign
					if ((abs(p->x-obj[OBJ_STOP].x)<12) && (abs(p->y-obj[OBJ_STOP].y)<12) && !obj[OBJ_STOP].carry && stopMoved && (p->x<=26*8) && !p->stophit) {
						p->stophit=32;
						p->dir^=1;
					}
					// Check if collision with Torben
					if ((abs(p->x-obj[OBJ_TORBEN].x)<14) && (abs(p->y-obj[OBJ_TORBEN].y)<14)) {
						if (health>=FLASHWHITE_LIMIT) {
							p->state=0;
							wolves--;
							wavPlay((u32*)_binary_wav_eat3_bin_start,CH_B,WAV_LR);
							dechealth+=24;
						} else
							dead=1;
					}
					break;
			}
		}

		if (dechealth) {
			health-=4;
			dechealth-=4;
		}

		updateFood(health);
		maincnt++;
		if ((health<FLASHRED_LIMIT) || (health>=FLASHWHITE_LIMIT)) {
			flashcnt=(flashcnt+2)&63;
			i=(flashcnt<32)?flashcnt:(63-flashcnt);
			if (health>=FLASHWHITE_LIMIT)
				i|=(i<<5)|(i<<10);
			((vu16*)PLTT)[BAR_INDEX]=i;
		} else {
			flashcnt=0;
			((vu16*)PLTT)[BAR_INDEX]=0;
		}

		for(y=1;y<4;y++)
			for(x=0;x<2;x++) {
				putTile(x,y+13,(y<<4)+x+32+(done?4:0),0);
				putTile(29+x,y+13,(y<<4)+x+34+(door?0:2),0);
			}

#ifdef IMMORTAL
		dead=0;
		if (keyTrg & START_BUTTON)
			dead=1;
		if (keyTrg & SELECT_BUTTON)
			done=1;
#else		
		if (keyTrg & START_BUTTON) { // Pause
			wavStop(CH_A);
			i=0;
			do {
				VBlankIntrWait();
				if (!i) showText(1);
				if (i==16) removeText();
				i=(i+1)&31;
			} while (!(keyTrg & START_BUTTON));
			removeText();
		}
#endif
		if (dead) {
			wavPlay((u32*)_binary_wav_die_bin_start,CH_A,WAV_LR);
			for(i=0;i<512+(lives?0:32);i+=4) {
				VBlankIntrWait();
				if ((i&63)<32) j=(i&31); else j=31-(i&31);
				blend(128,144,31,j);
				if (mode==2) {
					if ((++timecnt&31)==8)
						showText(2);
					else if ((timecnt&31)==24)
						removeText();
				}
			}
			dead=0;
			if (--lives<0)
				return 1;

			blend(128,144,31,0);
			updateLives(lives);
			for(objno=0;objno<MAX_OBJECTS;objno++) {
				p=obj+objno;
				if (p->type==OBJ_WOLF) {
					p->state=0;
					objRemove(objno);
				}
			}
			wolves=maxwolves=0;
			lastnewwolf=0;
			maincnt=0;
		}

		if (done && !uncon) {
			for(x=-2;x>=-20;x--) {
				VBlankIntrWait();
				i=(((p->framecnt>>1)&3)<<1);
				objPut16(2,x+SPRXADJ,DOORY+SPRYADJ-scrollY,i,OAM_SIZE_16x16,-1,3,0,8);
				objPut(0,x+SPRXADJ,DOORY+SPRYADJ-scrollY,(12<<6)+20,OAM_SIZE_16x16,-1,3,0);
				p->framecnt++;
			}
			return 0;
		}

		if ((maxwolves<5) && (maincnt>=wolf[maxwolves]))
			maxwolves++;

		if ((wolves<maxwolves) && (lastnewwolf>=WOLF_TIME)) {
			// New wolf!
			i=255;
			lastnewwolf=0;
			j=-1;
			for(objno=0;objno<MAX_OBJECTS;objno++) {
				if (obj[objno].state && (obj[objno].type==OBJ_WOLF))
					i-=(1<<obj[objno].color);
				if (!obj[objno].state && (j<0))
					j=objno;
			}
			p=obj+j;
			p->state=1;
			p->type=OBJ_WOLF;
			p->color=0;
			while (!(i&1)) {
				p->color++;
				i>>=1;
			}
			p->x=26*8+32;
			p->y=DOORY;
			p->dir=0;
			p->framecnt=0;
			p->cnt=-1;
			wolves++;
		}
		lastnewwolf++;

		if ((health<FLASHWHITE_LIMIT) && (wavCntA>=0))
      wavStop(CH_A);
    if ((health>=FLASHWHITE_LIMIT) && (wavCntA<0))
			wavPlay((u32*)SIREN_RAM,CH_A,WAV_LR|WAV_LOOP);

		if (mode==2) {
			if ((timecnt&31)==8)
				showText(2);
			else if ((timecnt&31)==24)
				removeText();
		}
			
		if (newlevel && !mode) {
			showText(1);
			wavPlay((u32*)_binary_wav_titlemel_bin_start,CH_A,WAV_LR);
			waitKey(START_BUTTON);
			removeText();
      wavStop(CH_A);
			newlevel=0;
		}
	}	
}

void menuPrint(u32 x, u32 y, char *str)
{
	char c;
	u32 i;
	while (*str) {
    c=*str;
    i=223;
    if ((c>='A') && (c<='Z')) i=192+(c-'A');
    if ((c>='0') && (c<='9')) i=224+(c-'0');
    if ((c>='!') && (c<='*')) i=240+(c-'!');
    if (c=='�') i=218;
    if (c=='�') i=219;
    if (c=='�') i=220;
    if (c=='.') i=221;
    if (c=='-') i=222;
    ((u16*)(VRAM+(BG2_SB<<11)))[(y<<5)+x++]=i;
    str++;
	}
}

void frame(u32 x1, u32 y1, u32 x2, u32 y2)
{
	s32 x,y,i;

	CpuFastClear(0,VRAM+(BG2_SB<<11),2048);
	*(vu16*)REG_BG2CNT=BG_COLOR_256 | BG_SCREEN_SIZE_0 | BG_PRIORITY_1 |
		(BG2_SB << BG_SCREEN_BASE_SHIFT);
	*(vu16*)REG_BG2HOFS=4;
	*(vu16*)REG_BG2VOFS=0;

	for(y=y1;y<=y2;y++)
  	for(x=x1;x<=x2;x++) {
      i=180;
      if (y==y1) i=177;
      if (x==x1) i=179;
      if (y==y2) i=183;
      if (x==x2) i=181;
      if ((y==y1) && (x==x1)) i=176;
      if ((y==y1) && (x==x2)) i=178;
      if ((y==y2) && (x==x1)) i=182;
      if ((y==y2) && (x==x2)) i=184;
      ((u16*)(VRAM+(BG2_SB<<11)))[(y<<5)+x]=i;
    }
}

u32 menu(void)
{
	s32 cur;

	frame(7,5,23,15);

	menuPrint(10,7,"START GAME");	
  menuPrint(10,9,"INSTRUCTIONS");
  menuPrint(10,11,"DEMO");
  menuPrint(10,13,"CREDITS");
  *(vu16*)REG_DISPCNT|=DISP_BG2_ON;

  cur=0;

 	while (1) {
		VBlankIntrWait();
    ((u16*)(VRAM+(BG2_SB<<11)))[(((cur<<1)+7)<<5)+8]=180;
		if (keyTrg & U_KEY) { cur--; wavPlay((u32*)_binary_wav_keyfx_bin_start,CH_B,WAV_LR); }
		if (keyTrg & D_KEY) { cur++; wavPlay((u32*)_binary_wav_keyfx_bin_start,CH_B,WAV_LR); }
		if (cur<0) cur=3;
		if (cur>3) cur=0;
		((u16*)(VRAM+(BG2_SB<<11)))[(((cur<<1)+7)<<5)+8]=255;
		if (keyTrg & (AB_BUTTON | START_BUTTON))
      break;
	}
  wavPlay((u32*)_binary_wav_stopfx_bin_start,CH_B,WAV_LR);
  *(vu16*)REG_DISPCNT&=~DISP_BG2_ON;
  CpuFastClear(0,VRAM+(BG2_SB<<11),2048);
	return cur;
}

void instructions(void)
{
	frame(0,4,30,17);
	*(vu16*)REG_BG2VOFS=4;
	menuPrint(1, 5,"GUIDE TORBEN TO THE EXIT DOOR");
  menuPrint(1, 6,"ON THE LEFT WHILE AVOIDING   ");
	menuPrint(1, 7,"THE HUNGRY FOXES. YOU HAVE TO");
	menuPrint(1, 8,"CARRY THE KEY TO THE DOOR TO ");
	menuPrint(1, 9,"OPEN IT. THIS WILL MAKE YOU  ");
	menuPrint(1,10,"HUNGRY SO YOU HAVE TO EAT A  ");
	menuPrint(1,11,"LOT. IF YOU HAVE EATEN ENOUGH");
	menuPrint(1,12,"YOU ARE ABLE TO KILL THE     ");
	menuPrint(1,13,"FOXES. TO YOUR HELP YOU ALSO ");
	menuPrint(1,14,"HAVE A STOP SIGN WHICH CAN BE");
	menuPrint(1,15,"USED AS AN OBSTACLE FOR THE  ");
	menuPrint(1,16,"FOXES IF PUT DOWN.           ");

	*(vu16*)REG_DISPCNT|=DISP_BG2_ON;
	waitKey(AB_BUTTON|START_BUTTON);

	wavPlay((u32*)_binary_wav_stopfx_bin_start,CH_B,WAV_LR);
  *(vu16*)REG_DISPCNT&=~DISP_BG2_ON;
  CpuFastClear(0,VRAM+(BG2_SB<<11),2048);
}

void credits(void)
{
	frame(4,4,26,16);
	menuPrint(5, 5,"PROGRAMMING");
  menuPrint(5, 6,"   JIMMY M�RDELL");

	menuPrint(5, 8,"GRAPHICS");
	menuPrint(5, 9,"   THANIUS");

	menuPrint(5,11,"SOUND");
	menuPrint(5,12,"   ERIK GRAHN-J�RLUND");

	menuPrint(5,14,"ORIGINAL CONCEPT");
	menuPrint(5,15,"   DAN HAGGREN");

	*(vu16*)REG_DISPCNT|=DISP_BG2_ON;
	waitKey(AB_BUTTON|START_BUTTON);

	wavPlay((u32*)_binary_wav_stopfx_bin_start,CH_B,WAV_LR);
  *(vu16*)REG_DISPCNT&=~DISP_BG2_ON;
  CpuFastClear(0,VRAM+(BG2_SB<<11),2048);
}

void initSiren(void)
{
	s32 i,cur,len;

	len=((u32)_binary_wav_siren_bin_size)-12; // Len of actual wav data

	CpuFastCopy(_binary_wav_siren_bin_start,SIREN_RAM,len+12);
	cur=SIREN_RAM+12;

	for(i=0;i<16;i++) {
		CpuFastCopy(_binary_wav_siren_bin_start+3,cur,len);
		cur+=len;
	}

	((u32*)SIREN_RAM)[1]=(((u32*)SIREN_RAM)[1])*i+i+(i>>1);
}

void AgbMain(void)
{
	s32 opt;

  CpuFastClear(0,VRAM,VRAM_SIZE);
  *(vu16*)PLTT=0x7FFF;
  CpuClear(0,PLTT+2,PLTT_SIZE-2,16);

	intrInit();
	*(vu16*)REG_IME   = 1;
  *(vu16*)REG_IE    = V_BLANK_INTR_FLAG | CASSETTE_INTR_FLAG;
  *(vu16*)REG_STAT  = STAT_V_BLANK_IF_ENABLE;
  *(vu16*)REG_DISPCNT = 0;

	*(vu16*)REG_WAITCNT=CST_PREFETCH_ENABLE | CST_ROM0_1ST_3WAIT | CST_ROM0_2ND_1WAIT;

	initSiren();
	wavInit();
#ifndef IMMORTAL
	showTitlePic();
#endif

	hiscore=0;

	while (1) {
		CpuFastArrayCopy(bggfx_Char,VRAM);
		CpuFastArrayCopy(bggfx_Palette,PLTT);
		CpuFastArrayCopy(text_Char,VRAM+0x8000);
		CpuFastArrayCopy(text_Palette,PLTT+(128*2));
		CpuFastArrayCopy(sprites_Char,OBJ_MODE0_VRAM+0x2000);
		CpuFastArrayCopy(sprites_Palette,OBJ_PLTT);
		CpuFastArrayCopy(torbenspr_Char,OBJ_MODE0_VRAM);
		CpuFastArrayCopy(torbenspr_Palette,OBJ_PLTT+(128*2));
		CpuCopy(OBJ_PLTT,obj_pltt_bak,512,16);

		score=0;
		health=32;
		lives=2;
		difficulty=0;
		stage=FIRST_STAGE;

    initLevel(stage);
		softFadeInBlack(BLD_BG0|BLD_BG1|BLD_OBJ);

		do {
      opt=menu();
			switch (opt) {
   			case 1 : instructions(); break;
   			case 2 :
   				playLevel(2,(u8*)demostrokes);
					softFadeOutBlack(BLD_BG0|BLD_BG1|BLD_OBJ);
					score=0;
					health=32;
					initLevel(stage);
					softFadeInBlack(BLD_BG0|BLD_BG1|BLD_OBJ);
					break;
				case 3 : credits(); break;
			}
    } while (opt>0);
    delay(20);

		while (lives>=0) {
			// Extra life on stage 04, 07, 10, 13, 16
			if (!difficulty && ((stage==3) || (stage==6) || (stage==9) || (stage==12) || (stage==15)) && (lives<3)) {
				lives++;
				updateLives(lives);
			}

			if (!playLevel(0,0)) {
				softFadeOutBlack(BLD_BG0|BLD_BG1|BLD_OBJ);
				stage++;
				if (stage>=NO_STAGES) {
					stage=FIRST_STAGE;
					difficulty++;
				}
        initLevel(stage);
				softFadeInBlack(BLD_BG0|BLD_BG1|BLD_OBJ);
			}
		}

		// Game over
		showText(0);
		waitKey(AB_BUTTON|START_BUTTON);
		removeText();
		softFadeOutBlack(BLD_BG0|BLD_BG1|BLD_OBJ);

		if (score>hiscore)
			hiscore=score;
	}
}
