#ifndef _MAIN_H
#define _MAIN_H

#include <Agb.h>
#include "intr.h"

extern OamData OamBak[128];
extern s32 scrollY;

#endif
