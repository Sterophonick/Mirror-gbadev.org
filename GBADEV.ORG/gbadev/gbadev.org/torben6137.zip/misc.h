#ifndef _MISC_H
#define _MISC_H

#define AB_BUTTON (A_BUTTON | B_BUTTON)

#define max(a,b) ((a)>(b)?(a):(b))
#define min(a,b) ((a)<(b)?(a):(b))

extern u16 keyTrg,keyCur;
extern u32 randSeed;

void resetSprites(void);
void objPut(u32,s32,s32,u32,u32,s32,u32,u32);
void objPut16(u32,s32,s32,u32,u32,s32,u32,u32,u32);
void objRemove(u32);
void waitKey(u32);
void waitKeyDelay(u32,u32);
void delay(u32);
u32 random(u32);

void fadeInWhite(u32);
void fadeOutWhite(u32);
void softFadeInBlack(u32);
void softFadeOutBlack(u32);

#endif
