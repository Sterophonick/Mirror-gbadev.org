#include "Agb.h"
#include "wavplay.h"

/*
   CPU performance:

    44khz stereo:   1.1%
    44khz mono:     0.5%
    32khz stereo:   0.8%
    32khz mono:     0.3%
    22khz stereo:   0.5%
    22khz mono:     0.2%

*/

s32 wavCntA, wavCntB;
u32 wavLoopA, wavLoopB;
u32 *wavA, *wavB;
u32 wavStereo;

#define CPU_HZ    16779931
#define WAV_OFS_FREQ     0
#define WAV_OFS_LEN      1
#define WAV_OFS_TYPE     2
#define WAV_OFS_DATA     3

#define ADJ -2

/*
	DmaSafeStop   Stop a repeating DMA safely using the guidelines in
	              the AGB Programming Manual, chapter 12.4
*/

void DmaSafeStop(u32 dmano)
{
	*(vu16*)(REG_DMA0CNT_H+(dmano*12))=0x8440;
	wavStereo=0;
	*(vu16*)(REG_DMA0CNT_H+(dmano*12))=0x0440;
}

/*
	wavInit    Call once at startup
*/

void wavInit(void)
{
	wavCntA=wavCntB=-1;
	wavLoopA=wavLoopB=wavStereo=0;
}

/*
  wavPlay    smp    - pointer to sample
             ch     - channel (CH_A, CH_B, CH_AB)
             flags  - flags (WAV_LOOP, WAV_HALF, WAV_L, WAV_R, WAV_LR)
*/

void wavPlay(u32 *smp, u32 ch, u32 flags)
{
	*(vu16*)REG_SOUNDCNT_X|=SOUND_DMG_ON;

	if (smp[WAV_OFS_TYPE]==2) {
		DmaSafeStop(1);
		DmaSafeStop(2);
		*(vu16*)REG_SOUNDCNT_H=(*(vu16*)REG_SOUNDCNT_H&0x00F3) | 0x1200 | (!(flags&WAV_HALF)?0x000C:0);
		DmaSound(1,smp+WAV_OFS_DATA,A);
		DmaSound(2,smp+WAV_OFS_DATA+(smp[WAV_OFS_LEN]>>2),B);
		*(vu16*)REG_TM0CNT_L=65536-CPU_HZ/smp[WAV_OFS_FREQ];
		*(vu16*)REG_TM0CNT_H=0x0080;
		wavCntA=60*smp[WAV_OFS_LEN]/smp[WAV_OFS_FREQ]-1;
		wavCntB=-1;
		wavLoopA=flags & WAV_LOOP;
		wavA=smp;
		wavStereo=1;
		return;
	}

	if (ch & CH_A) {
		if (wavStereo) DmaSafeStop(2);
		DmaSafeStop(1);		
		*(vu16*)REG_SOUNDCNT_H=(*(vu16*)REG_SOUNDCNT_H&0xF0FB) |
			((flags&WAV_LR)<<8) | (!(flags&WAV_HALF)?4:0);
		DmaSound(1,smp+WAV_OFS_DATA,A);
		*(vu16*)REG_TM0CNT_L=65536-CPU_HZ/smp[WAV_OFS_FREQ];
		*(vu16*)REG_TM0CNT_H=0x0080;
		wavCntA=60*smp[WAV_OFS_LEN]/smp[WAV_OFS_FREQ]+ADJ;
		wavLoopA=flags & WAV_LOOP;
		wavA=smp;
		wavStereo=0;
	}
	if (ch & CH_B) {
		if (wavStereo) DmaSafeStop(1);
		DmaSafeStop(2);		
		*(vu16*)REG_SOUNDCNT_H=(*(vu16*)REG_SOUNDCNT_H&0x0FF7) |
			(((flags&WAV_LR)|4)<<12) | (!(flags&WAV_HALF)?8:0);
		DmaSound(2,smp+WAV_OFS_DATA,B);
		*(vu16*)REG_TM1CNT_L=65536-CPU_HZ/smp[WAV_OFS_FREQ];
		*(vu16*)REG_TM1CNT_H=0x0080;
		wavCntB=60*smp[WAV_OFS_LEN]/smp[WAV_OFS_FREQ]+ADJ;
		wavLoopB=flags & WAV_LOOP;
		wavB=smp;
		wavStereo=0;
	}
}

/*
	wavStop    ch   - channel (CH_A, CH_B, CH_AB)
*/

void wavStop(u32 ch)
{
	if (wavStereo) {
		DmaSafeStop(1);
		DmaSafeStop(2);
		*(vu16*)REG_SOUNDCNT_H&=0x00F3;
		wavStereo=0;
		return;
	}
	if (ch & CH_A) {
		DmaSafeStop(1);
		*(vu16*)REG_SOUNDCNT_H&=0xF0FB;
    wavCntA=-1;
	}
	if (ch & CH_B) {
		DmaSafeStop(2);
		*(vu16*)REG_SOUNDCNT_H&=0x0FF7;
    wavCntB=-1;
	}
}

/*
	wavVBlank   Call once every 1/60th of a second
*/

void wavVBlank(void)
{
	if ((wavCntA>=0) && !wavCntA--) {
		if (wavLoopA) {
			if (wavStereo) {
				DmaSafeStop(1);
				DmaSafeStop(2);			
				DmaSound(1,wavA+WAV_OFS_DATA,A);
				DmaSound(2,wavA+WAV_OFS_DATA+(wavA[WAV_OFS_LEN]>>2),B);
			} else {
				DmaSafeStop(1);
				DmaSound(1,wavA+WAV_OFS_DATA,A);
			}
			wavCntA=60*wavA[1]/wavA[0]+ADJ;
		}
		else
			wavStop(CH_A);
	}
	if ((wavCntB>=0) && !wavCntB--) {
		if (wavLoopB) {
			DmaSafeStop(2);
			DmaSound(2,wavB+WAV_OFS_DATA,B);
			wavCntB=60*wavB[1]/wavB[0]+ADJ;
		}
		else
			wavStop(CH_B);
	}
}
