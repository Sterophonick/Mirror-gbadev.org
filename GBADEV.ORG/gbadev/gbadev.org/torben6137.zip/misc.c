#include "main.h"
#include "misc.h"
#include "intr.h"

/* Buffer used when doing a software palette fade */
#define SOFT_PAL_AREA   EX_WRAM    // Size 0x400

#define FADESPEED 24

vu16 keyTrg,keyCur;
u32 randSeed;

void resetSprites(void)
{
	CpuArrayClear(160,OamBak,32);
	VBlankIntrWait();
}

void objPut(u32 n, s32 x, s32 y, u32 tileno, u32 size, s32 affine, u32 pri, u32 mode)
{
	OamData *p=OamBak+n;

	*(u32*)p=size;
	if ((x<-64) || (x>256)) y=170;
	p->VPos=y;
	p->HPos=x;
	p->AffineMode=affine>=0;
	p->ColorMode=1;
	p->AffineParamNo_L=affine<0?0:affine;
	p->CharNo=tileno;
	p->Priority=pri;
	p->ObjMode=mode;
}

void objPut16(u32 n, s32 x, s32 y, u32 tileno, u32 size, s32 affine, u32 pri, u32 mode, u32 pal)
{
	OamData *p=OamBak+n;

	*(u32*)p=size;
	if ((x<-64) || (x>256)) y=170;
	p->VPos=y;
	p->HPos=x;
	p->AffineMode=affine>=0;
	p->ColorMode=0;
	p->AffineParamNo_L=affine<0?0:affine;
	p->CharNo=tileno;
	p->Priority=pri;
	p->ObjMode=mode;
	p->Pltt=pal;
}

void objRemove(u32 n)
{
	objPut(n,0,170,0,0,-1,0,0);
}

void waitKey(u32 mask)
{
	do {
		VBlankIntrWait();
	} while (!(mask&keyTrg));
}

void waitKeyDelay(u32 maxtime, u32 mask)
{
	u32 i,done=0;
	for(i=0;(i<maxtime) && !done;i++)  {
		VBlankIntrWait();
		done=mask&keyTrg;
	}
}

void delay(u32 t)
{
	for(;t>0;t--)
		VBlankIntrWait();
}

u32 random(u32 lim)
{
#ifdef NO_RANDOM
	return lim>>1;
#else	
	randSeed=(randSeed*31421+6927)&0xFFFF;
	return (randSeed*lim)>>16;
#endif	
}

void fadeInWhite(u32 mask)
{
	u32 i;

	VBlankIntrWait();
  *(vu16*)REG_BLDCNT=(mask&0x1F) | BLD_UP_MODE;
  *(vu16*)REG_BLDY=16;
  *(vu16*)REG_DISPCNT|=mask<<DISP_ON_SHIFT;

  for(i=0;i<=256;i+=FADESPEED) {
 		VBlankIntrWait();
  	*(vu16*)REG_BLDY=(256-i)>>4;
  }  
  *(vu16*)REG_BLDCNT=0;
  *(vu16*)REG_BLDY=0;
}

void fadeOutWhite(u32 mask)
{
	u32 i;

	VBlankIntrWait();
  *(vu16*)REG_BLDCNT=mask | BLD_UP_MODE;
  *(vu16*)REG_BLDY=0;

  for(i=0;i<=256;i+=FADESPEED) {
 		VBlankIntrWait();
  	*(vu16*)REG_BLDY=i>>4;
  }
  VBlankIntrWait();
  *(vu16*)REG_DISPCNT&=~(mask<<DISP_ON_SHIFT);
  *(vu16*)PLTT=0x7FFF;
  *(vu16*)REG_BLDCNT=0;
  *(vu16*)REG_BLDY=0;
  VBlankHandler=0;
}

void softFade(s32 i)
{
	u16 *p,*q;
	s32 j,col,r,g,b;
	
  p=(u16*)SOFT_PAL_AREA;
  q=(u16*)(SOFT_PAL_AREA+1024);
  for(j=0;j<512;j++) {
  	col=*p++;
  	r=((col&31)*i)>>8;
  	g=(((col>>5)&31)*i)>>8;
  	b=(((col>>10)&31)*i)>>8;
  	*q++=r|(g<<5)|(b<<10);
  }
 	VBlankIntrWait(); 	
  CpuFastCopy(SOFT_PAL_AREA+1024,PLTT,1024);
}

void softFadeInBlack(u32 mask)
{
	s32 i;

	VBlankIntrWait();
	CpuFastCopy(PLTT,SOFT_PAL_AREA,1024);
	CpuFastClear(0,PLTT,1024);

  *(vu16*)REG_DISPCNT|=mask<<DISP_ON_SHIFT;

  for(i=FADESPEED;i<=256;i+=FADESPEED)
  	softFade(i);
  softFade(256);
}


void softFadeOutBlack(u32 mask)
{
	s32 i;

	VBlankIntrWait();
	CpuFastCopy(PLTT,SOFT_PAL_AREA,1024);

  for(i=256-FADESPEED;i>=0;i-=FADESPEED)
  	softFade(i);
  softFade(0);

  CpuFastCopy(SOFT_PAL_AREA,PLTT,1024);
  *(vu16*)REG_DISPCNT&=~(mask<<DISP_ON_SHIFT);
  *(vu16*)PLTT=0;
  *(vu16*)REG_BLDCNT=0;
  VBlankHandler=0;
}
