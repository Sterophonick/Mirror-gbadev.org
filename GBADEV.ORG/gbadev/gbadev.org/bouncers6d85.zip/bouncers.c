//-----------------------------------------------------------------------------------------------
// Bouncers - Dec. 14, 2002
//
// Yay!  My first GBA program...so go easy on me...
//
// Randomly bouncing particles that leave fading trails behind them.
//	Uses simple fake "additive" rendering so the particle trails
//	interact with each other.  Code not particularly optimised.
//
// by: _Nessie_
//		Got a comment? jdischlr@concentric.net
//
// Compiled with GCC 3.2
//		by [ Richard Mitton - http://www.rmitton.com/ ]
//
// Runs under:
//		BoycottAdvance Version 0.2.6
//		Mappy VM 0.8b
//		??
//
// rand() function, from Gibby's Pacman demo
//
//-----------------------------------------------------------------------------------------------

#include <gba.h>

#define TO_RGB(r,g,b)		((r>>3) | ((g>>3)<<5) | ((b>>3)<<10))
#define NUM_PARTICLES		(16) 
#define COORDINATE_SHIFT	(8)

u16* VideoBuffer = (u16*)0x6000000;

// Particle structure...
typedef struct 
{
	int mAtX, mAtY;
	int mVelX, mVelY;
	int mGravity;
	int mRed, mGreen, mBlue;

} TParticle;

// Thanks to Gibby for a quick rand function, hope you don't mind. :)
//-----------------------------------------------------
int rand()
{
	static int work = 0xd371f947;

	work = work * 0x41c64e6d + 0x3039;
	return(( work >> 16) &0x7fff );
}

//-----------------------------------------------------
void InitializeParticle( TParticle *arrayElement )
{
	// Move to left, center of screen
	arrayElement->mAtX = 1 << COORDINATE_SHIFT;
	// Generate a number from -31 to 32...then add that to half the screen height ( vert. center )
	arrayElement->mAtY = ((LCD_HEIGHT >> 1 ) + (( rand() & 63) - 31 )) << COORDINATE_SHIFT;

	// Generate random velocity and gravity
	arrayElement->mVelX = (rand() & 255) + 210;	
	arrayElement->mVelY = (rand() & 1023) - 512; // some move up, some move down
	arrayElement->mGravity = (rand() & 31) + 5;	// always pulls down

	// Pick one of two different color schemes
	if ( rand() & 1 )
	{
		// color range should be 0-31, but we'll scale it down with a shift later
		arrayElement->mRed = (rand() & 127) + 128;
		arrayElement->mGreen = (rand() & 127) + 128;
		arrayElement->mBlue = 0;
	}
	else
	{
		arrayElement->mRed = (rand() & 127) + 128;
		arrayElement->mGreen = 0;
		arrayElement->mBlue = (rand() & 127) + 128;
	}
}

//-----------------------------------------------------
void InitializeParticleList( TParticle *array, int count )
{
	int i;

	for ( i = 0; i < count; i++ )
	{
		InitializeParticle( &array[i] );
	}
}

// Cheesy fade
//-----------------------------------------------------
void ChewBuffer()
{
	int x, y;
	int r, g, b;

	static sy = 0;

	u16 *mem;

	// fading out the whole buffer seemed nasty slow..update every 10th line in a given
	//	frame...next frame we'll increment the start slot by one.     Eventually we'll have
	//	faded out all lines in a given section, so we start over
	for ( y = sy; y < LCD_HEIGHT; y += 10 )
	{
		mem = &VideoBuffer[y * LCD_WIDTH];

		for ( x = 0; x < LCD_WIDTH; x++ )
		{
			// Get the pixel
			r = *mem & 31;
			g = (*mem >> 5) & 31;
			b = (*mem >> 10) & 31;

			// fade it if we can
			if ( r > 1 )
			{
				r -= 2;
			}
			if ( g > 1 )
			{
				g -= 2;
			}
			if ( b > 1 )
			{
				b -= 2;
			}

			// write it back out
			*mem = r | (g << 5) | (b << 10 ); 
			mem++;
		}
	}

	// do next scanline next frame
	sy++;
	if ( sy > 9 )
	{
		// wrap our vertical start spot back to the first scanline
		sy = 0;
	}
}

//-----------------------------------------------------
void DrawParticle( TParticle *arrayElement, int x, int y )
{
	u16 *mem;

	mem = &VideoBuffer[x + y * LCD_WIDTH];

	u16 col = TO_RGB( arrayElement->mRed,
						arrayElement->mGreen,
						arrayElement->mBlue );
	// draw main core
	*mem |= col;

	// draw some extra pixels on all sides to make "+" pattern
	if ( x > 0 )
	{
		*(mem - 1) |= col;
	}
	if ( x < LCD_WIDTH )
	{
		*(mem + 1) |=  col;
	}
	if ( y > 0 )
	{
		*(mem + LCD_WIDTH) |=  col;
	}
	if ( y < LCD_HEIGHT )
	{
		*(mem - LCD_WIDTH) |=  col;
	}
}

//-----------------------------------------------------
void UpdateParticles( TParticle *array, int count )
{
	int i;
	int realX, realY;

	TParticle *work;

	for ( i = 0; i < count; i++ )
	{
		work = &array[i];

		// Move me in a very framerate dependant way :)
		work->mAtX	+= work->mVelX;
		work->mAtY	+= work->mVelY;

		// Gravity changes the vertical velocity
		work->mVelY += work->mGravity;

		// shift back to our real coordinate system
		realX = (work->mAtX >> COORDINATE_SHIFT);
		realY = (work->mAtY >> COORDINATE_SHIFT);

		// Bounce me off the bounds of the LCD frame
		if ( realX <= 0 )
		{
			// Hit horz edge, bounce me
			work->mVelX = -work->mVelX;
			work->mAtX = 0;
		}
		else if ( realX >= LCD_WIDTH )
		{
			// Hit horz edge, bounce me
			work->mVelX = -work->mVelX;
			work->mAtX = LCD_WIDTH << COORDINATE_SHIFT;
		}

		// Bounce me off the bounds of the LCD frame
		if ( realY <= 0 )
		{
			// Hit vert edge, bounce me
			work->mVelY = -(work->mVelY * 0.8f);
			work->mAtY = 0;
		}
		else if ( realY >= LCD_HEIGHT )
		{
			// Hit vert edge, bounce me
			work->mVelY = -(work->mVelY * 0.8f);
			work->mAtY = LCD_HEIGHT << COORDINATE_SHIFT;
		}

		// Reduce my "energy" so trails will become fainter as time goes on
		if ( work->mRed > 0 )
		{
			work->mRed--;
		}
		if ( work->mGreen > 0 )
		{
			work->mGreen--;
		}
		if ( work->mBlue > 0 )
		{
			work->mBlue--;
		}

		// Dead?
		if ( work->mRed + work->mGreen + work->mBlue <= 0 )
		{
			// Particle is dead, revitalize it
			InitializeParticle( work );
		}
		else
		{
			DrawParticle( work, realX, realY );
		}
	}
}

//-----------------------------------------------------
void AgbMain(void)
{
	int x,y;//,r,g,b;
	u16 *gfx, col, oldcol;

	// local storage
	TParticle gParticleArray[NUM_PARTICLES];

	InitializeParticleList( gParticleArray, NUM_PARTICLES );

	// Set 240x160 16-bit mode.
	REG_DISPCNT = DC_MODE_3 | DC_ENABLE_BG2;

	// loop forever
	while( 1 ) 
	{
		UpdateParticles( gParticleArray, NUM_PARTICLES );
		ChewBuffer();
	}
}
