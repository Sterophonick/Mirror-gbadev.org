==========================
Bouncers - Dec. 14, 2002
==========================

Yay!  My first GBA program...so go easy on me...

Randomly bouncing particles that leave fading trails behind them.
Uses simple fake "additive" rendering so the particle trails interact with each other.  Code not particularly optimised.


==========================
Coding by: _Nessie_
	Got a comment? Mail me at: jdischlr@concentric.net
	( make sure to put _Nessie_ in the subject line or it'll get chucked with my spam, sorry )


==========================
Compiled with GCC 3.2
	by [ Richard Mitton - http://www.rmitton.com/ ]


==========================
Runs under these emulators:
	BoycottAdvance Version 0.2.6 -- [http://www.boycottadvance.com]
	Mappy VM 0.8b
	??