gfxFront
=============

Version 1.0.3.0 - Thursday, November 29, 2001
Works with gfx2gba Version 1.03

Introduction
============

gfxFront is a frontend utility for use with "gfx2gba" by Darren Sillett.

Questions about gfxFront should be sent to "Arcadian" <mbills@hotmail.com> or 
on ICQ- #7637348 - or catch me (atari_kid - someone stole my nick) on IRC #gbadev on efnet.

Distribution
============

These files (gfxFront.exe & this readme) may be distributed as-is. 
This readme file must always be included with the executable.

Install
=======

Extract all files to a directory.  Use Winzip - http://www.winzip.com. 

Notes
=====

* Any gfxFront bugs should be directed to mbills@hotmail.com

* GFX2GBA.exe MUST reside in the same directory as the image you want to convert
  (sorry - I will fix this in a later version).

* The commandline is for VIEWING PURPOSES only, changes made here affects nothing,
  you can however copy/paste...if need be.

* Please send any comments to: mbills@hotmail.com, I'd like to know what you think!

* See the readme file for gfx2gba for instructions on usage.


Changes
=======

1.0.3.0  -  (Thursday, November 29, 2001)

* Added palette options

* Now converts LongPathName to ShortPathName - so all directories should work.

* Added the "missing" -k option. This is for the const modifier.

* Made the commandline "read only".

* Added file filters when you click 'browse' (.bmp, .tga, .jpg, etc...) missing WBMP and KOALA
  if you know what the extensions are for these let me know and I'll add them in.


1.0.2.5  -  (Saturday November 24, 2001)  

* New 'user friendly' interface.

* Added a browse button.

* The commandline is viewable after you hit convert, so you can see what takes place.
  I made this for debugging purposes, and decided to keep it.. for now :).

* New icons, and about graphix...  made by me.

* Edit fields (Width and Sprite) only need to be numbers.. and Name only needs the name,
  the switches are automatically appended by the program.

1.0.2.0  - (Tuesday, November 20, 2001)

* Shortend the name. ;)

* Added 3 new commandline switches to comply with gfx2gba version 1.02. 

Warranty
========

This tool is provided for free but without warranty of any kind.

Credits
=======
Author: -+Arcadian+-

Special thanks to: (in no order btw): 
James R. Twine (Who went out of his way to help me and to give suggestions, thanks!! , Chris Losinger,
Rob Warner, Keebler on http://www.GameDev.net, and
of course Darren Sillett - http://www.gbacode.net/.

Thanks to SimonB - http://www.gbadev.org/ for informing me and sending the 1.02 update!

And all those I forgot to mention.

Copyright
=========

This software is (c)2001 -+Arcadian+- 
No changes must be made to this software without written permission
from -+Arcadian+-.  

If you find this program useful and wish to contribute 
(anything.. code, money, ideas..etc) please contact me.

Contact: mbills@hotmail.com
ICQ: 7637348
