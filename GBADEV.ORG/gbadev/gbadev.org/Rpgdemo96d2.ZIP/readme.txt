//////////////////////////////////
//////////////////////////////////
//   	    Readme.txt          //
//////////////////////////////////
By:
Royale00

info:
I started this demo after playing GOLDEN SUN which is a great rpg
game for GameBoy Advanced and I wanted to try to create a little demo.
Here it is!

tech:
This demo was developed using ARM SDT compiler with my own GBA lib (thanks to everyone
that has shared source code which was a great help with creating my own library).I will
release source code upon request because my GBA lib is confusing especially if your a novice programmer(when I figure out how to get C++ libs to work properly I will release library).Ohh yeah this demo should run on most emulators and hardware.

notes:
As you can see the collision detection needs a little work as of now it uses a 15x10 grid of
16x16 tiles.I want to eventually get it down to a 8x8 collision squares.Next demo will include text window which I am working on now.Also next demo will include more maps and npcs.

help wanted:
I am interested in making this a full freeware game in which case I can code the game myself
or with one other programmer(for music and little odds and ends) but I need someone who is good with creating ORIGINAL art as I cant draw too great and dont really like ripping sprites.More importantly I need someone to come up with a story line.Well if no one is interested I will continue to develop on my own.

email: 
Royale00@hotmail.com 