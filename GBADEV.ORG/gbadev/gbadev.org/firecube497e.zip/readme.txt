---------------------------------------------------------
                       Y A K U Z A 
	    Demo-Group

active Members: George Stark
Members h.c.:      Delta, Sigma, 
                              ToXiC Trancer
                              Scale , Oracle
---------------------------------------------------------
@About YAKUZA

Hi folks !

Diz is our first release since 1994 !! In this
year we released a short (ugly) Intro on the 
	    PARTY `94.
At this time we coded for x86 prozessors.

But �cause of leaving the school, getting
in touch with girls, party, alcohol and that 
stuff we lost the interest in coding. Hehe 
I guess some of you understand ...

But now .. years later .. just looking for
a new hobby .. and found the GBA !!!
Great machine, feels like coding for 80286
and int 13h .. :-))

@About "FireCube"

This is just my first attempt ...
.. pure @ARM-Asm ...

Mode 4 Demo: some vector rotation,
shading, fire algo, using Pictures,
Interpolation and so on ... probably
it contains some ugly and not optimized
code ...			G.S. 
-------------------------------------------------------