==========================================================
Triplay 1.0
Author : Sammy Fatnassi
Date   : November 29th 2002
==========================================================

=============================
Game Goal
=============================
The goal of the game is to make as many point as you can, by matching 2 cards 
togethers.

=============================
Game Rules
=============================
-You can only match 2 cards if they either have the same value, or have a value
 that follow each other.
-You can match together 2 cards on the board or a card on the board and a card
 on the deck of cards.
-For each match without using a card from the deck, you get a bonus, which is 
 increased by 100pts each time, until you take a card form the deck.
-When there's no possible match, you can get the next card on the deck by 
 pressing down twice(1st=select, 2d=confirmation), until you have a good card.

=============================
Points
=============================
-2 cards that follow each other :   400pts
-2 same cards                   :   800pts
-Bonus for not using deck       :   100pts more per turn given on matching card
-Bonus for a top row card       : 5,000pts
-Bonus time remaining           :   200pts per second
-Bonus cards remaning           : 1,000pts per card

=============================
Bonus Round
=============================
You can reach a bonus round when gaining 60,000pts in 2 rounds.

=============================
Controls of the game
=============================
Left/Right 	: Move the cursor
A		: Select the current card
B		: Cancel Selection
Up		: Select the top deck card
Down		: Throw away the top deck card(must press down twice for confimation)
Start		: Pause the game
Select	: Bring the help screen
R shoulder	: Skip to next round

=============================
Comments
=============================
You cna sent them at : sammyf22@hotmail.com