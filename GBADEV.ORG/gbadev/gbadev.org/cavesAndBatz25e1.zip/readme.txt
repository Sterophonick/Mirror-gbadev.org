  caves and batz for GBA

           by: blaow
           blaow2@yahoo.com
	   www.geocities.com/blaow2/


--info--

A platform game consisting of 6 stages and 2 boss levels, where you
are stickman the hero who must scape the deadly caves infested by bats.
coded in c++.

--Controls--


D-Pad                - Move Character
A Button             - jump
B Button             - fire
select		     - pause
start		     - unpause


--special thanks--
for background collision related stuff:
	
	niltsair for his explanations on background collisions
		

	Lord Graga for his platform game where i got most of	
                       the concepts for the game background
		       collisions.

for other stuff
	
	Dovoto for his cool map editor.


for everything else:

	To the ppl in the gbadev.org forums for sharing all
	that knowledge.
	
	and to gbadev.org for the great site it is.
	



-- to do list --
 
-do testing on real hardware
-add more levels
-do a lot of code optimization
-fix some bugs
-a sequel maybe?