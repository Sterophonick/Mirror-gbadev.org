//Attempt at a simple GBA Pong game
//by Mark Pereira
//Working:	Paddle: Displayed, Moves
//			Ball: Displayed, Moves
//			Collision Detection with Ball & Paddle
//			Ball Resetting after going off screen
//			CPU Paddle AI (holder AI : move with ball.y) Not Very Smart, but it works!
//			Ball bounces off boundaries
//			Background is drawn to screen
//
//Working on:	keeping a score (works for player one!)

#include "gba.h"
#include "dispcnt.h"
#include "background.h"
#include "ch4c.h"
#include "keypad.h"
#include "bg_tile.h"
#include "PongMap.c"
#include "paddle.h"
#include "cpu_paddle.h"
#include "ball.h"
#include "score.h"
#include "Cpu_Score.h"
#include "palette.h"

u16 y_zero = 0;
u16 y_bottom = (160 - 32);
u16 x_end = (240-16);
u16 x_start = 0;
int p_score = 0;
u16 c_score = 0;
u16 ball_max = 4;

//create an OAM variable and make it point to the address of OAM
u16* OAM = (u16*)0x7000000;

//create the array of sprites (128 is the maximum)
OAMEntry sprites[128];

//create the rotation and scaling array (overlaps the OAMEntry array memory)
pRotData rotData = (pRotData)sprites;

void MakeBKG();
void InitializeSprites();
void SetUp();
void WaitForVsync();
void CopyOAM();
void GetInput(void);
void MoveSprites(OAMEntry* sp, int x, int y);
void Ball_State();
void Cpu_AI();
void Ball_Reset(u16 x);
void Paddle_Reset();
void Game_Restart();
void Update_Player_Score(int x);
void Update_Cpu_Score(int x);

typedef struct
{
	u16 x;
	u16 y;
	u16 x_velo;
	u16 y_velo;
	u16 direction_x;
	u16 direction_y;
	u16 spriteFrame[10];	
	int activeFrame;
	u16 OAMSpriteNum;

}Sprite;

Sprite paddle;
Sprite cpu;	
Sprite ball;
Sprite player_score;
Sprite cpu_score;

//---------- Start of AgbMain() ----------//
int main()
{
	u16 loop;

	paddle.x = 10;
	cpu.x = x_end - 10;
	ball.x_velo = 3;
	
	Paddle_Reset();
	Ball_Reset(1);
	
	REG_BG0CNT = CHAR_BASE(1) | BG_MOSAIC_ENABLE | BG_COLOR_256;
	SetMode(MODE_0 | BG0_ENABLE | OBJ_ENABLE | OBJ_MAP_1D);

	for(loop = 0; loop < 256; loop++)
		OBJPaletteMem[loop] = Palette[loop];

	InitializeSprites();
	
	SetUp();
	MakeBKG();
	while(1)
	{
		CopyOAM();
		WaitForVsync();
		GetInput();
		Ball_State();
		Cpu_AI();
		MoveSprites(&sprites[paddle.OAMSpriteNum],paddle.x,paddle.y);
		MoveSprites(&sprites[cpu.OAMSpriteNum],cpu.x,cpu.y);
		MoveSprites(&sprites[ball.OAMSpriteNum],ball.x,ball.y);
		//Update_Score(p_score);
	}
}
//---------- End of Main() ------------//

//---------- Start of MakeBKG() -----------//
void MakeBKG()
{
 u16 loop;
 for(loop = 0; loop < 256; loop++)
	 BGPaletteMem[loop] = bg_tilePalette[loop];
 for(loop = 0; loop < bg_tile_WIDTH*bg_tile_HEIGHT/2; loop++)
	 BGTileMem[loop] = bg_tileData[loop];
 for(loop = 0; loop < 32*32; loop++)
	 VideoBuffer[loop] = PongMap[loop];
}
//---------- End of MakeBKG() ----------//

//---------- Start of InitializeSprites() ----------//
void InitializeSprites()
{
	u16 loop;
	
	for(loop = 0; loop < 128; loop++)
	{
		sprites[loop].attribute0 = 160;
		sprites[loop].attribute1 = 240;
	}

}
//---------- End of InitializeSprites() ----------//

//---------- Start of SetUp() ----------//
void SetUp()
{
	u16 loop;

	paddle.OAMSpriteNum = 0;
	
	sprites[paddle.OAMSpriteNum].attribute0 = COLOR_256 | WIDE | paddle.y;
	sprites[paddle.OAMSpriteNum].attribute1 = SIZE_32 | paddle.x;
	sprites[paddle.OAMSpriteNum].attribute2 = 0;

	for(loop = 0; loop < 256; loop++)
		OAMData[loop] = paddleData[loop];
	
	paddle.activeFrame = 0;
	paddle.spriteFrame[0] = 0;
	
	cpu.OAMSpriteNum = 1;
	
	sprites[cpu.OAMSpriteNum].attribute0 = COLOR_256 | WIDE | cpu.y;
	sprites[cpu.OAMSpriteNum].attribute1 = SIZE_32 | cpu.x;
	sprites[cpu.OAMSpriteNum].attribute2 = 16;

	for(loop = 256; loop < 512 ; loop++)
		OAMData[loop] = cpuData[loop-256];
	
	cpu.activeFrame = 0;
	cpu.spriteFrame[0] = 16;
	
	ball.OAMSpriteNum = 2;
	
	sprites[ball.OAMSpriteNum].attribute0 = COLOR_256 | SQUARE | ball.y;
	sprites[ball.OAMSpriteNum].attribute1 = SIZE_16 | ball.x;
	sprites[ball.OAMSpriteNum].attribute2 = 32;

	for(loop = 512; loop < 640 ; loop++)
		OAMData[loop] = ballData[loop-512];	

	ball.activeFrame = 0;
	ball.spriteFrame[0] = 32;

	player_score.x = 48;
	player_score.y = y_bottom - 8;

	player_score.OAMSpriteNum = 3;

	sprites[player_score.OAMSpriteNum].attribute0 = COLOR_256 | SQUARE | player_score.y;
	sprites[player_score.OAMSpriteNum].attribute1 = SIZE_16 | player_score.x;
	sprites[player_score.OAMSpriteNum].attribute2 = 40;

	for(loop = 640; loop < 1920; loop++)
		OAMData[loop] = scoreData[loop - 640];
	
	player_score.activeFrame = 0;
	player_score.spriteFrame[0] = 40;
	player_score.spriteFrame[1] = 48;
	player_score.spriteFrame[2] = 56;
	player_score.spriteFrame[3] = 64;
	player_score.spriteFrame[4] = 72;
	player_score.spriteFrame[5] = 80;
	player_score.spriteFrame[6] = 88;
	player_score.spriteFrame[7] = 96;
	player_score.spriteFrame[8] = 104;
	player_score.spriteFrame[9] = 112;

	cpu_score.x = x_end - 48;
	cpu_score.y = y_bottom- 8;

	cpu_score.OAMSpriteNum = 4;

	sprites[cpu_score.OAMSpriteNum].attribute0 = COLOR_256 | SQUARE | cpu_score.y;
	sprites[cpu_score.OAMSpriteNum].attribute1 = SIZE_16 | cpu_score.x;
	sprites[cpu_score.OAMSpriteNum].attribute2 = 120;

	for(loop = 1920; loop < 3200; loop++)
		OAMData[loop] = cpu_scoreData[loop - 1920];
	
	cpu_score.activeFrame = 0;
	cpu_score.spriteFrame[0] = 120;
	cpu_score.spriteFrame[1] = 128;
	cpu_score.spriteFrame[2] = 136;
	cpu_score.spriteFrame[3] = 144;
	cpu_score.spriteFrame[4] = 152;
	cpu_score.spriteFrame[5] = 160;
	cpu_score.spriteFrame[6] = 168;
	cpu_score.spriteFrame[7] = 176;
	cpu_score.spriteFrame[8] = 184;
	cpu_score.spriteFrame[9] = 192;
}
//---------- End of SetUp() ----------//

//---------- Start of WaitForVsync() ----------//
void WaitForVsync()
{
	while((volatile u16)REG_VCOUNT != 160){}
}
//---------- Emd of WaitForVsync() ----------//

//---------- Start of CopyOAM() ----------//
void CopyOAM()
{
	u16 loop;
	u16* temp;
	temp = (u16*)sprites;
	for(loop = 0; loop < 128*4; loop++)
		OAM[loop] = temp[loop];
}
//---------- End of CopyOAM() ----------//

//---------- Start of GetInput() ----------//
void GetInput(void)
{
	if(!(*KEYS & KEY_UP))
	{
		if(paddle.y > y_zero)
		{
			paddle.y-=5;
		}	
	}

	if(!(*KEYS & KEY_DOWN))
	{
		if(paddle.y < y_bottom)
		{	
			paddle.y+=5;
		}
	}
}
//---------- End of GetInput() ----------//

//---------- MoveSprites() -----------//
void MoveSprites(OAMEntry* sp, int x, int y)
{
	if(x < 0)
		x = 512 + x;
	if(y < 0)
		y = 256 + y;

	sp->attribute1 = sp->attribute1 & 0xFE00;
	sp->attribute1 = sp->attribute1 | x;

	sp->attribute0 = sp->attribute0 & 0xFF00;
	sp->attribute0 = sp->attribute0 | y;
}
//---------- End of MoveSprites() ----------//

//----------Start of Ball_State() ----------//
void Ball_State()
{	
	//Reset Ball state if ball goes past CPU
	if((ball.x+10) >= cpu.x)
	{
		Ball_Reset(ball.direction_x);
		p_score++;
		if(p_score == 10)
		{
			Game_Restart();
		}
		Update_Player_Score(p_score);
		Paddle_Reset();
		
	}
	
	//Reset Ball state if ball goes past Player
	if(ball.x <= paddle.x)
	{
		Ball_Reset(ball.direction_x);
		c_score++;
		if(c_score == 10)
		{
			Game_Restart();
		}
		Update_Cpu_Score(c_score);
		Paddle_Reset();
	}
	
	//bounce ball off the top of the screen
	if(ball.y <= 10)
		ball.y_velo = ball.y_velo - (2*ball.y_velo);
		
	//bounce ball off the bottom of the screen
	if((ball.y + 16) >= 150)
		ball.y_velo = ball.y_velo - (2*ball.y_velo);

	
	if((ball.x < x_end) && (ball.direction_x == 1))
	{
		ball.x+= ball.x_velo;
		ball.y+= ball.y_velo;
		if(ball.x == x_end)
			ball.direction_x = 0;
	}

	if((ball.x > x_start) && (ball.direction_x == 0))
	{
		ball.x-=ball.x_velo;
		ball.y+=ball.y_velo;
		if(ball.x == x_start)
			ball.direction_x = 1;
	}
	
	//Collision Detection with Player Paddle
	if((ball.x >= paddle.x && ball.x <= (paddle.x + 16)) && ((ball.y + 8) >= paddle.y && (ball.y - 8) <= (paddle.y + 32)))
		{
			ball.direction_x = 1;
			ball.y_velo = 0;
						
			if(!(*KEYS & KEY_DOWN))
				ball.y_velo+=1;
			
			if(!(*KEYS & KEY_UP))
				ball.y_velo -= 1;
		}
	
	//Collision Detection with CPU Paddle
	if(((ball.x + 16) == cpu.x) && ((ball.y+8) >= cpu.y && (ball.y - 8) <= (cpu.y + 32)))
		{
			ball.direction_x = 0;
		}
}
//----------End of Ball_State() ----------//

//----------Start of Cpu_AI() ----------//
void Cpu_AI()
{
	if((cpu.y + 16) < ball.y)
		cpu.y++;
	if((cpu.y - 16) > ball.y)
		cpu.y--;
}
//---------- End of Cpu_AI() ----------//

//---------- Start of Ball_Reset ----------//
void Ball_Reset(u16 x)
{
	ball.x = (x_end/2)-8;
	ball.y = (y_bottom/2)+8;
	ball.direction_x = x;
	ball.x_velo = 2;
	ball.y_velo = 0;
}
//---------- End of Ball_Reset ----------//

//---------- Start of Paddle_Reset() ----------//
void Paddle_Reset()
{
	cpu.y = y_bottom/2;
	//paddle.y = y_bottom/2;
}
//----------End of Paddle_Reset() ----------//

void Update_Player_Score(int x)
{
	sprites[player_score.OAMSpriteNum].attribute2 = player_score.spriteFrame[x];
}

void Update_Cpu_Score(int x)
{
	sprites[cpu_score.OAMSpriteNum].attribute2 = cpu_score.spriteFrame[x];
}

void Game_Restart()
{
	p_score = 0;
	c_score = 0;
	Ball_Reset(1);
	Paddle_Reset();
	Update_Cpu_Score(c_score);
	Update_Player_Score(p_score);
}