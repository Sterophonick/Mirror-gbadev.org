Greetz GBADev Community!

	This is a beta 1.2 release of Pong that I am messing around with to 
figure out game logic, and how I want to break my game down into separate parts. 
I built Pong.gba with the DevKitAdv, and with information I gathered from GBA 
Junkies, Down To You, and The Pern Project tutorials! I strongly suggest these 
as a start for anyone else aspiring to start GBA Programming as well as 
regularily visiting mine and yours favorite site, http://www.gbadev.org/!

Game Programming,
Testing,
Artwork,
Sound,
and Production by: Mark Pereira (Jesus_v2)

Thank you to everyone at #gbadev on EFNet for all their help!

Special Thanks to :
_subbie_
BigRedPmp (visit http://berzerk.pocketheaven.com/)
Dovoto (Visit http://www.thepernproject.com/)
maverick (Visit http://downtou.sapian.co.uk/)
GBAJunkie (Visit http://gbajunkie.co.uk/)
and sgstair

Greets to:
OneManBand (Author of Converter of Graphics, get it at http://www.onemanband.com/)
eloist (Author of gba.h)
Daikath
Xvoid6f
Unciaa
MrMr[iCE]
shen
and Costis 

Talk to fine peeps like these
@ #gbadev on EFNet!

Please share this game with as many others as you can.
Send any opinions, suggestions, complaints and anything else
related to the game to markpereira@look.ca! I will have a 
website up as soon as I can, keep checking in on:
http://www.webhome.idirect.com/~markpereira/

laters all!

-Mark Pereira
