-------------------------
Pong Demo
-------------------------

File:		pong.bin (didn't want to write other make.bat file)
Program:		Pong, 2 player with only one GBA
DemoNr:		03
Author:		Johan Jansen (Jenswa)
Contact:		awsnej@hotmail.com
Site:		http://www.geocities.com/flashsite_jrj/hooghaar (not about gba yet)
		It's my win-game which I would like to port to gba, that's why
		I started gba-coding, following several examples.

-----------------------------
About this bin-file:

This is my third working gba example,
A little struggle to get the sprites on.

It is created with a gcc compiler, DevKitAdvance, nice compiler guys.
Coded with c or c++ (I don't know, since that's new to me).

1p keys:
up and down

2p keys:
A and B

Source files included.

---------------
Features:

Two 16x32 sprites (red and blue paddles)
One 8x8 sprite (green ball)
Input function (moving red and blue paddles)
2 player support with one gba
Ball function (moves the ball around, thanks to Nokturn)

----------------
Thanks to:

Forgotten (VisualBoyAdvance)
Jason Wilkins (Dev-Kit Advance)
Eloist (gba.h)
GBAjunkie (tutorial, dovoto, dispcnt.h, sprite_info.h)
Dovoto (pcx2sprite, dispcnt.h, sprite_info.h) 
Noktrun (keypad.h)
GBADEV.org

----------------
Jenswa

