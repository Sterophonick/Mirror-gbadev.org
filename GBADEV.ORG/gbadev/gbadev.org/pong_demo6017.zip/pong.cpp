/////////////////////////////////////////////
//pong.cpp
//Pong demo (2player)
//Made by Jenswa
//follows c-code from gbajunkie (his workstyle) and Nokturn (c-code for pong) since i don't have any c experience.
////////////////////////////////////////////

#include "gba.h" //GBA register definitions
#include "keypad.h" //button registers
#include "dispcnt.h" //REG_DISPCNT register #defines
#include "sprite_info.h" //gbajunkies generic sprite header file
#include "palette.h"	 //sprite palette (256 colour windows bmp palette with only 16 colours)
#include "paddle_1.h" //paddle 1
#include "paddle_2.h" //paddle 2
#include "ball.h" //ball sprite


//create an OAM variable and make it point to the address of OAM
u16* OAM = (u16*)0x7000000;

//create the array of sprites (128 is the maximum)
OAMEntry sprites[128];

//create the rotation and scaling array (overlaps the OAMEntry array memory)
pRotData rotData = (pRotData)sprites;

//declare ypos and xpos (from all sprites)

s16 xpos = 4;	//paddle 1 x position
s16 ypos = 80;	// and y

s16 xpos2 = 218;	//paddle 2 x position
s16 ypos2 = 80;	// and y

s16 BallX = 120;	//ball position x
s16 BallY = 80;	//and y

s8  BallSX = 2;	//variable containing value '2'
s8  BallSY = 2;	//variable containing value '2'

//Copy sprite array to OAM
void CopyOAM()
{
	u16 loop;
	u16* temp;
	temp = (u16*)sprites;
	for(loop=0; loop < 128*4; loop++)
	{
		OAM[loop] = temp[loop];
	}
}

//A button was pressed at the gba
void GetInput()
{
	if(!(*KEYS & KEY_UP))                   //if the UP key is pressed
	{
        	if(ypos > 0)
        		ypos-=4;
	}
	if(!(*KEYS & KEY_DOWN))                 //if the DOWN key is pressed
	{
        	if(ypos < 128)
        		ypos+=4;
	}
	if(!(*KEYS & KEY_B))                 //if the B key is pressed
	{
        	if(ypos2 < 128)
        		ypos2+=4;
	}
	if(!(*KEYS & KEY_A))                 //if the A key is pressed
	{
        	if(ypos2 > 0)
        		ypos2-=4;
	}
}

//sprite move function
void MoveSprite(OAMEntry* sp, int x, int y)
{
	if(x < 0)			//if it is off the left correct
		x = 512 + x;
	if(y < 0)			//if off the top correct
		y = 256 + y;

	sp->attribute1 = sp->attribute1 & 0xFE00;  //clear the old x value
	sp->attribute1 = sp->attribute1 | x;

	sp->attribute0 = sp->attribute0 & 0xFF00;  //clear the old y value
	sp->attribute0 = sp->attribute0 | y;
}

//move the ball
void MoveBall()
{
	 BallX+= BallSX;
	 BallY+= BallSY;

	 if( BallY >= 152 ) BallSY = -2;
	 if( BallY <= 0 )   BallSY = 2;

	 if( BallX >= 232 ) BallSX = -2;
	 if( BallX <= 0 )   BallSX = 2;

	 if( BallX >= 4 && BallX <= 20 ) if( BallY <= (ypos+36) && BallY >= ypos-4 ) BallSX = 2;
	 if( (BallX) >= 220 && (BallX) <= 236 ) if( BallY <= (ypos2+36) && BallY >= ypos2-4 ) BallSX = -2;

}


// Set sprites off screen
void InitializeSprites()
{
	u16 loop;
	for (loop = 0; loop < 128; loop++)
	{
		sprites[loop].attribute0 = 160;	//y > 159
		sprites[loop].attribute1 = 240;	//x > 239
	}
}

//wait for the screen to stop drawing
void WaitForVsync()
{
	while((volatile u16)REG_VCOUNT != 160){}
}

int main()
{
	u16 loop;	//generic loop variable


	SetMode(MODE_1 | OBJ_ENABLE | OBJ_MAP_1D);

	for(loop = 0; loop < 256; loop++)		//load palette into memory
	OBJPaletteMem[loop] = palette[loop];


	InitializeSprites();

	sprites[0].attribute0 = COLOR_256 | SQUARE | BallY;
	sprites[0].attribute1 = SIZE_8 | BallX;
	sprites[0].attribute2 = 0;			//pointer to tile where sprite starts

for(loop = 0; loop < 32; loop++)		//load ball sprite
{
	OAMData[loop] = ballData[loop];
}

	sprites[1].attribute0 = COLOR_256 | WIDE | ypos;
	sprites[1].attribute1 = SIZE_32 | xpos;
	sprites[1].attribute2 = 2;			//pointer to tile where sprite starts

for(loop = 32; loop < 288; loop++)		//load paddle_1 sprite
{
	OAMData[loop] = paddle_1Data[loop-32];
}

	sprites[2].attribute0 = COLOR_256 | WIDE | ypos2;
	sprites[2].attribute1 = SIZE_32 | xpos2;
	sprites[2].attribute2 = 18;			//pointer to tile where sprite starts

for(loop = 288; loop < 544 ; loop++)		//load paddle_2 sprite
{
	OAMData[loop] = paddle_2Data[loop-288];
}


	while(1)		//main loop
	{
		GetInput();		//Checks for key presses
		MoveSprite(&sprites[0], BallX, BallY);	//moves ball around the screen
		MoveSprite(&sprites[1], xpos, ypos);	//moves paddle 1 around the screen
		MoveSprite(&sprites[2], xpos2, ypos2);	//moves paddle2 around the screen
		MoveBall();		//also for moving the ball
		WaitForVsync();		//waits for the screen to stop drawing
		CopyOAM();		//copies sprite array into memory
	}
}

