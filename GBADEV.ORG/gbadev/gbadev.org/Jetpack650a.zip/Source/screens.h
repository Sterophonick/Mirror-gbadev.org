/**********************************************\
*       ameOver.h                                   *
*          by dovotos pcx->gba program         *
/**********************************************/

#include "bitmap.h"

extern CBitmap scrGameOver;
extern CBitmap scrTitle;

