//**************************************************************************************************
//
// player.cpp
//
// Description: Prototype for the player class
//
// Created by: Pete Gunter 02/12/2003
//
//**************************************************************************************************

#if !defined(_PG_PLAYER)
#define _PG_PLAYER

#include "vector.h"
#include "gbaMath.h"

enum{ PLY_GROUND, PLY_AIR, PLY_DYING, PLY_GAMEOVER};
enum{ PLY_JETSDOWN, PLY_JETSBACK, PLY_JETSFORWARD };

#define _TURNSPEED 8 //0.0625


class CPlayer  
{
public:
	CPlayer();
	virtual ~CPlayer();

	//Accessors
	inline void setOAMEntries(tagOAMEntry* pOAMPack, tagOAMEntry* pOAMLegs, tagOAMEntry* pOAMThrustL, tagOAMEntry* pOAMThrustR, tagOAMEntry* pOAMShadow)
		{m_pOAMPack = pOAMPack; m_pOAMLegs=pOAMLegs;  m_pOAMThrustL=pOAMThrustL; m_pOAMThrustR=pOAMThrustR;  m_pOAMShadow=pOAMShadow;};

	inline FIXED getEyeHeight(void){return m_pos.getIndex(1) + (32<<8);}; //32 is added to get position of eyes rather that feet 
	inline FIXED getHeight(void){return m_pos.getIndex(1);};
	inline FIXED getX(void){return m_pos.getIndex(0);};
	inline FIXED getY(void){return m_pos.getIndex(1);};
	inline FIXED getZ(void){return m_pos.getIndex(2);};
	inline s16 getAngle(void){return m_angle>>8;};
	inline FIXED getXvelocity(void){return m_velocity.getIndex(0);};
	inline FIXED getYvelocity(void){return m_velocity.getIndex(1);};
	inline FIXED getZvelocity(void){return m_velocity.getIndex(2);};
	inline FIXED getRotVelocity(void){return m_rotVelocity;};
	inline FIXED getHealth(void){return m_health;};
	inline u16 getFuel(void){return m_fuel;};
	inline CVector3& getCamPos(void){return m_camPos;};
	inline u8 getState(void){return m_state;};

	//Control Functions
	inline void thrust(){ if(m_fuel>0) m_thrust = 1; }; //Thrust if has fuel
	void turnRight();
	void turnLeft();
	inline void tiltForward(){m_jets=PLY_JETSFORWARD;};
	inline void tiltBack(){m_jets=PLY_JETSBACK;};
	inline void tiltNone(){m_jets=PLY_JETSDOWN;};

	//Update, (called once every frame)
	void update();

	//Initialise (called at the start of each level
	void initialise();

	//Start dying


private:


	void updateSprite();	//Update the OAM entries for the sprite
	void updateCam();		//Update the camera position


	CVector3 m_pos;			//Players current position
	CVector3 m_velocity;	//Players current velocity :16 fixed point vect
	CVector3 m_camPos;		//Position of camera
	FIXED m_angle;			//Angle player is currently facing
	FIXED m_rotVelocity;	//Rotational velocity

	u16 m_health;			//Player's health
	u16 m_fuel;				//Player's fuel

	tagOAMEntry* m_pOAMPack;	//Pointer to OAM entry for jetpack
	tagOAMEntry* m_pOAMLegs;	//Pointer to OAM entry for legs
	tagOAMEntry* m_pOAMThrustL;	//Pointer to OAM entry for left thrust
	tagOAMEntry* m_pOAMThrustR;	//Pointer to OAM entry for right thrust
	tagOAMEntry* m_pOAMShadow;	//Pointer to OAM entry for right thrust

	u8 m_state;		//On ground or in air
	u8 m_jets;		//State of jets 0=down, 1=back, 2=forward
	u8 m_thrust;	//State of thrust 0=off 1=on
};

#endif // !defined(_PG_PLAYER)

