//**************************************************************************************************
//
// sprite.h
//
// Description: Header file for all the sprite information defined in sprites.cpp
//
// Created by: Pete Gunter 01/03/2004
//
//**************************************************************************************************

#include "gba.h"

#define _SPR_JETUP 0
#define _SPR_JETFORWARD 8
#define _SPR_JETBACK 16
#define _SPR_LEGSDOWN 24
#define _SPR_LEGSUP 28
#define _SPR_LEGSFORWARD 64
#define _SPR_LEGSBACK 68
#define _SPR_LEGSRIGHT 72
#define _SPR_BLASTFULL 76
#define _SPR_SHADOW 78
#define _SPR_BLASTEMPTY 108

extern const u16 bmpSpriteData[];
extern const u16 palSprite[];

