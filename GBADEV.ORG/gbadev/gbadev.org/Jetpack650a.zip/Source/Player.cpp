// Player.cpp: implementation of the CPlayer class.
//
//////////////////////////////////////////////////////////////////////

#include "Player.h"
#include "sprite.h"

#include "iwram.h"

extern u8 gTime;
extern FIXED gGravity;

u8 gTransFlag = 0;	//flag to state whether transparent sprites are drawn (Changed every frame)
u8 gThrustSprite = _SPR_BLASTFULL;

/**************************************************************************************************
CONSTRUCTION/DESTRUCTION
**************************************************************************************************/
CPlayer::CPlayer()
{

}

CPlayer::~CPlayer()
{

}

void CPlayer::initialise()
{
	m_angle = 0;
	m_rotVelocity = 0;
	m_pos = CVector3(0, 8<<8, 0);
	m_velocity = CVector3(0, 0, 0);
	m_state = PLY_AIR;
	m_health = 120;
	m_jets = PLY_JETSDOWN;
	m_fuel = 3600;	//60 secs worth of fuel (1 unit/sec)	
}

void CPlayer::update()
{
	//*** Apply thrust if thrusting
	if( m_thrust)
	{
		//Thrust factor is 42/625 (4404 in :16)
		switch(m_jets)
		{
		case ( PLY_JETSFORWARD ) :
			//Only if in air
			if(m_state == PLY_AIR)
			{
				m_velocity += CVector3(
					(-fixsin(m_angle)*0x44d)>>8,
					0x44d,
					(-fixcos(m_angle)*0x44d)>>8
				);
			}
			break;
		case ( PLY_JETSBACK ) :
			//Only if in air
			if(m_state == PLY_AIR)
			{
				m_velocity += CVector3(
					(-fixsin(m_angle)*-0x44d)>>8,
					0x44d,
					(-fixcos(m_angle)*-0x44d)>>8
				);
			}
			break;
		case ( PLY_JETSDOWN ) :
			m_velocity += CVector3(	0, 0x1134, 0  );//Upwards thrust of 2/45
			m_state = PLY_AIR;
			break;
		}

		m_fuel--; //Decrease fuel
	}
	
	//*** Update position if in air
	if( m_state == PLY_AIR )
	{
		//*** Rotational movement
		//Slow Rotational Velocity
		if(m_rotVelocity<-0x2468) m_rotVelocity += 0x2468; //32/225 in :16
			else if(m_rotVelocity>0x2468) m_rotVelocity -= 0x2468; //32/225 in :16
				else m_rotVelocity=0;

		//Update angle
		m_angle += (m_rotVelocity>>8); //Covert to :8

		//Clip to range 0-2048
		if(m_angle<0)
			m_angle += int2fix(2048);
		if(m_angle>=int2fix(2048))
			m_angle -= (2048<<8);

		//*** Linear Movement
		//Apply Acceleration due to gravity
		m_velocity -= CVector3(	0, gGravity, 0 );	// 2/45 p/u2 in 15:16

		//Update position
		m_pos += (m_velocity>>8); //Convert velocity from :16 to :8

		//Collide with ground
		if (m_pos.getIndex(Y) < 0)
		{
			//Ground player
			m_state = PLY_GROUND;

			//Damage health if rate of descent too high
			s16 yVel = getYvelocity()>>16;
			if( yVel<-2)
			{
				yVel += 3;
				yVel *= yVel; //Square to make damage increase exponetially

				if(yVel>=m_health) m_health = 0;
				else m_health-=yVel;

				//If dead, set Game Over
				if (m_health<=0) m_state = PLY_GAMEOVER;
			}

			//Halt players movement
			m_pos.setIndex(Y,0);
			m_velocity = CVector3(0,0,0);
			m_rotVelocity = 0;

			//If out of fuel, game over
			if(m_fuel==0) m_state=PLY_GAMEOVER;
		}
	}

	//Update the players sprite
	updateSprite();
	updateCam();

	//Thrust has been handled, so reset
	m_thrust = 0;

	//If time out, then game over
	if(gTime == 0) m_state=PLY_GAMEOVER;
}

void CPlayer::updateSprite()
{
	//Swap transpareny flag
	gTransFlag = gTransFlag?0:1;

	//*** Update players sprite components (Legs and Pack)
	// Legs
	if ((getHeight()>>8) < 10)
		m_pOAMLegs->attribute2 = _SPR_LEGSDOWN | PRIORITY(1);
	else	//Player in air
		if( m_rotVelocity < -4<<16 )
		{
			m_pOAMLegs->attribute2 = _SPR_LEGSRIGHT | PRIORITY(1);
			m_pOAMLegs->attribute1 &= 0xEFFF;			//Disable horizontal flip flag
		}
		else if(m_rotVelocity > 4<<16 )
		{
			m_pOAMLegs->attribute2 = _SPR_LEGSRIGHT | PRIORITY(1);
			m_pOAMLegs->attribute1 |= 0x1000;	//Enable horizontal flip flag
		}
		else
		{
			//If thrusting forward or backwards
			if(m_thrust)
			{
				if(m_jets == PLY_JETSBACK)
				{
					m_pOAMLegs->attribute2 = _SPR_LEGSBACK | PRIORITY(1);				
				}
				else if(m_jets == PLY_JETSFORWARD)
				{
					m_pOAMLegs->attribute2 = _SPR_LEGSFORWARD | PRIORITY(1);
				}
				else m_pOAMLegs->attribute2 = _SPR_LEGSUP | PRIORITY(1);
			}
			//Else normal legs up
			else m_pOAMLegs->attribute2 = _SPR_LEGSUP | PRIORITY(1);
		}

	//Jets
	switch(m_jets)
	{
		case PLY_JETSDOWN:
			m_pOAMPack->attribute2 = _SPR_JETUP | PRIORITY(1);
			break;
		case PLY_JETSBACK:
			m_pOAMPack->attribute2 = _SPR_JETBACK | PRIORITY(1);
			break;
		case PLY_JETSFORWARD:
			m_pOAMPack->attribute2 = _SPR_JETFORWARD | PRIORITY(1);
			break;
	}

	//Thrust
	if(m_thrust)
	{
		gThrustSprite = (gThrustSprite==_SPR_BLASTFULL)?_SPR_BLASTEMPTY:_SPR_BLASTFULL;
		switch(m_jets)
		{
			case PLY_JETSDOWN:
				m_pOAMThrustL->attribute0 = (COLOR_256 | SQUARE | 97);
				m_pOAMThrustL->attribute1 = (SIZE_8 | 102);
				m_pOAMThrustL->attribute2 = gThrustSprite | PRIORITY(1);
				m_pOAMThrustR->attribute0 = (COLOR_256 | SQUARE | 97);
				m_pOAMThrustR->attribute1 = (SIZE_8 | 130);
				m_pOAMThrustR->attribute2 = gThrustSprite | PRIORITY(1);
				break;
			case PLY_JETSBACK:
				m_pOAMThrustL->attribute0 = (COLOR_256 | SQUARE | 90);
				m_pOAMThrustL->attribute1 = (SIZE_8 | 104);
				m_pOAMThrustL->attribute2 = gThrustSprite | PRIORITY(1);
				m_pOAMThrustR->attribute0 = (COLOR_256 | SQUARE | 90);
				m_pOAMThrustR->attribute1 = (SIZE_8 | 128);
				m_pOAMThrustR->attribute2 = gThrustSprite | PRIORITY(1);
				break;
			case PLY_JETSFORWARD:
				m_pOAMThrustL->attribute0 = (COLOR_256 | SQUARE | 96);
				m_pOAMThrustL->attribute1 = (SIZE_8 | 100);
				m_pOAMThrustL->attribute2 = gThrustSprite;
				m_pOAMThrustR->attribute0 = (COLOR_256 | SQUARE | 96);
				m_pOAMThrustR->attribute1 = (SIZE_8 | 132);
				m_pOAMThrustR->attribute2 = gThrustSprite;
				break;
		}
	} else { //No thrust so disable thrust sprites
		m_pOAMThrustL->attribute0=0x0200;
		m_pOAMThrustR->attribute0=0x0200;
	}
	
	//Shadow
	u16 intHeight = getY()>>8;
	if( gTransFlag && (intHeight<18) )
	{
		//Enable sprite
		m_pOAMShadow->attribute0 = (COLOR_256 | WIDE | 103+(intHeight)*3 | MODE_TRANSPARENT);
		m_pOAMShadow->attribute1 = (SIZE_16 | 104);
		m_pOAMShadow->attribute2 = _SPR_SHADOW;
	}
	else
	{
		//Disable sprite
		m_pOAMShadow->attribute0=0x0200;
/*		m_pOAMShadow->attribute0 = 160;  //y to > 159
		m_pOAMShadow->attribute1 = 240;  //x to > 239
*/	}
}

void CPlayer::updateCam()
{
	m_camPos = m_pos + CVector3(
					(-fixsin(m_angle)*-50<<8)>>8,
					0x4000,							//64 in :8
					(-fixcos(m_angle)*-50<<8)>>8
				);
}

void CPlayer::turnLeft()
{
	
	if(m_rotVelocity<(0x88888))//128/15
		m_rotVelocity += 0x6666;//2/5
}
void CPlayer::turnRight()
{

	if(m_rotVelocity>-(0x88888))//128/15
		m_rotVelocity -= 0x6666;//2/5
}

