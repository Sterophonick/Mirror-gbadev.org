//**************************************************************************************************
//
// main.cpp
//
// Description: Program entry for the GBA
//
// Created by: Pete Gunter 30/11/2003
//
//**************************************************************************************************



#include "gba.h"
#include "gbaMath.h"

#include "iwram.h"

#include "player.h"			//Player class and sprite information
#include "map.h"			//Map data
#include "sprite.h"			//Sprite data
#include "screens.h"		//Screens data
#include "levels.h"			//Level data

//FUNCTION PROTOTYPES
void init(void);
void initSprites(void);
void initHUD(void);

void getInput(void);
void update(void);

void print(char *s);

void softReset(void);
void cleanAfterPogoshell(void);
void resetVideo(void);

void titleScreen(void);	//Show title screen

void displayScreen(CBitmap& bm);

void flip(void);

//GLOBALS
CPlayer gPlayer;						//Global instance of player information

OAMEntry sprites[128];					//Array of OAM objects
pRotData rotData = (pRotData)sprites;	//Array of OAM scaling and rotation values

u8 gTime;								//Time left
u8 gDebug;								//Flag to show debug information

u16* gBuffer;							//Pointer to the current buffer for doublebuffered modes
u16 gpalCopper[160];					//Pallete for copper bar effect

FIXED gGravity;							//Global value of acceleration due to gravity

int main(void)
{
	//Show the title screen
	displayScreen(scrTitle);

	//Initialise the map data
	init();
	level1.loadLvlIntoMemory();

	//Main loop
	while(!(gPlayer.getState()==PLY_GAMEOVER) && (KEYS & KEY_START) )//Keep updating 
	{
		while(REG_VCOUNT<160);//Make sure VWRITE is over so our game does run faster than 60 frames per second

		getInput();	//Recieve and proccess input
		update();	//Update world

		while(REG_VCOUNT!=0);//Wait for VWrite to start
	}//end while

	//Disable interupts
	REG_IME = 0;
	//Show Game Over Screen
	displayScreen(scrGameOver);

	//Clear the screen and enter an infinate loop
	REG_DISPCNT |= FORCE_BLANK;
	while(1);

}


void init(void)
{
	//Blank the screen
	REG_DISPCNT |= FORCE_BLANK;

	/* Enable Interupts */
	REG_IME = 0;											//Disable interupts
	REG_INTERUPT = (u32)interrupt;							//Point the interupt handler register to the function
	REG_DISPSTAT |= (DST_ENABLE_HBLANK | DST_ENABLE_VBLANK);//Enable HBLANK in REG_DISPSTAT
	REG_IE |= INT_HBLANK | INT_VBLANK | INT_TIMMER2;		//Enable HBLANK, VBLANK and TIMER2 IRQs in REG_IE
	REG_IME = 1;											//Enable interupts


	/* Screen Initialisation */
	// The Screen mode is set within the VBlank interupt on the first line
	//	to allow changing of modes for the horizon effect
	//HUD (Text)
	REG_BG0CNT = BG_COLOR256 | TEXTBG_SIZE_256x256 | (29 << SCREEN_SHIFT) |  ( 1<<CHAR_SHIFT) | 0;
	//Starfield (Text)
	REG_BG1CNT = BG_COLOR256 | TEXTBG_SIZE_256x256 | (30 << SCREEN_SHIFT) | WRAPAROUND | 2;
	//Ground (Rotation)
	REG_BG2CNT = BG_COLOR256 | ROTBG_SIZE_256x256 | (31 << SCREEN_SHIFT) | WRAPAROUND | 1;
	

	/* Load in the HUD tile data and initialise HUD background */
	//HUD tiles
	DMA_Copy(3,(void*)bmpHUDTiles,(void*)CharBaseBlock(1),4096,DMA_16NOW);
	initHUD();

	/* Initialise the sprites */
	initSprites();
	gPlayer.setOAMEntries(sprites+1, sprites+2, sprites+3, sprites+4, sprites+0);

	/* Initialise the game timer */
	//zero the timer
	REG_TM2D = 0;
	//Start the timer
	REG_TM2CNT = TIME_FREQUENCY_256 | TIME_ENABLE | TIME_IRQ_ENABLE; //Timer overflows every second
	//Set the amount of time for the level
	gTime = 120;

	gDebug = 0;	//Disable display of debug information

	/* Initialise the player object */
	gPlayer.initialise();

	/* Display the screen again now we're finished */
	REG_DISPCNT &= ~FORCE_BLANK;
}


// Set sprites to off screen
void initSprites(void)
{
	//Disable all sprites
	unsigned int loop;
	for(loop = 0; loop < 128; loop++)
	{
		sprites[loop].attribute0=0x0200;
	}

	//Load in sprite memory
	DMA_Copy(3,(void*)palSprite,(void*)OBJPaletteMem,128,DMA_32NOW);

	//Use DMA to copy sprite data to OAM
	REG_DMA3SAD = (u32)bmpSpriteData;
	REG_DMA3DAD = (u32)OAMData;
	REG_DMA3CNT = 32*32*8 | DMA_16NOW;

	//Initialise the players sprite (Incorporates 4 sprites)
	sprites[0].attribute0 = (COLOR_256 | WIDE | 106);
	sprites[0].attribute1 = (SIZE_16 | 105);
	sprites[0].attribute2 = _SPR_SHADOW;
	sprites[1].attribute0 = (COLOR_256 | WIDE | 80);
	sprites[1].attribute1 = (SIZE_32 | 104);
	sprites[1].attribute2 = _SPR_JETUP;
	sprites[2].attribute0 = (COLOR_256 | SQUARE | 96);
	sprites[2].attribute1 = (SIZE_16 | 112);
	sprites[2].attribute2 = _SPR_LEGSDOWN;
	sprites[3].attribute0 = (COLOR_256 | SQUARE | 160);
	sprites[3].attribute1 = (SIZE_8 | 240);
	sprites[3].attribute2 = _SPR_BLASTFULL;
	sprites[4].attribute0 = (COLOR_256 | SQUARE | 160);
	sprites[4].attribute1 = (SIZE_8 | 240);
	sprites[4].attribute2 = _SPR_BLASTFULL;
}


//Draw the HUD for the first time
void initHUD(void)
{
	u16* pMapData = (u16*)ScreenBaseBlock(29);

	//Clear the HUD map
	for(u8 x=0; x<32; x++)
	{
		for(u8 y=0; y<32; y++)
		{
			pMapData[x + y*32]=0;
		}
	}

	//* Draw bar
	//Draw top and bottom of life bar
	pMapData[33] = 106;
	pMapData[545] = 96;
	//Draw top and bottom of fuel bar
	pMapData[34] = 117;
	pMapData[546] = 107;

	//Write labels for counters
	printStr("Time:\n",19, 1);
	printStr("Height:\n",17, 2);

}

//Flip the buffers
void flip(void)
{
    if(REG_DISPCNT & BACKBUFFER) //back buffer is the current buffer so we need to switch it to the font buffer
    { 
        REG_DISPCNT &= ~BACKBUFFER; //flip active buffer to front buffer by clearing back buffer bit
        gBuffer = BackBuffer; //now we point our drawing buffer to the back buffer
    }
    else //front buffer is active so switch it to backbuffer
    { 
        REG_DISPCNT |= BACKBUFFER; //flip active buffer to back buffer by setting back buffer bit
        gBuffer = VideoBuffer; //now we point our drawing buffer to the front buffer
    }
}



void getInput(void)
{
	static u8 lvl=1;	//Stores level number, to prevent changing to a level it's already in

	/*Get keyboard input*/
	//Thrust
	if( !(KEYS & KEY_A) ) gPlayer.thrust();

	//Tilt jets
	if (!(KEYS & KEY_UP) ) gPlayer.tiltForward();
		else if (!(KEYS & KEY_DOWN) )	gPlayer.tiltBack();
			else gPlayer.tiltNone();

	//Angle
	if (!(KEYS & KEY_LEFT) )	gPlayer.turnLeft();
	if (!(KEYS & KEY_RIGHT) )	gPlayer.turnRight();

	//Show debug information
	if (!(KEYS & KEY_SELECT) ) gDebug = 1;

	//Show debug information
	if (!(KEYS & KEY_L) )
	{
		if(lvl==2)
		{
			level1.loadLvlIntoMemory();
			lvl = 1;
		}
	}
	if (!(KEYS & KEY_R) )
	{
		if(lvl==1)
		{
			level2.loadLvlIntoMemory();
			lvl = 2;
		}
	}

}


void update(void)
{
	//Update the player
	gPlayer.update();

}

//Display the given screen with a fade in and a fade out
void displayScreen(CBitmap& bm)
{
	u8 fadeVal = 31;	//Level of fade value (31=darkest)
	u8 state = 0;		//0 Fade in, 1 Wait for start, 2 Fade out, 3 exit

	//Set the transparency register (do this first so modeswitch is invisible)
	SetTransparency( BG2_TARGET1 | BLD_MODE(BLD_MODE_DARKEN) );
	SetFadeValue( fadeVal );

	//Set screen mode to Mode4 with bg2
	SetMode(MODE_4 | BG2_ENABLE );
	REG_BG2CNT=0;
	//Reset the affine transformations for background 2 to the identity matrix
	REG_BG2PA = 1<<8;
	REG_BG2PB = 0;
	REG_BG2PC = 0;
	REG_BG2PD = 1<<8;
	REG_BG2X = 0;
	REG_BG2Y = 0;

	//Disable interupts
	REG_IME = 0;
	//Disable the game timer
	REG_TM2CNT = 0;

	while(REG_VCOUNT<160);//Wait for VBlank before copying in palette information
	bm.copyInPalette();

	while(!(state==3))
	{
		switch(state)
		{
		case 0:
			fadeVal--;	//Decrease and set the fade value
			SetFadeValue(fadeVal);
			if(fadeVal==0) state=1;
			break;
		case 1:
			if(!(KEYS & KEY_START)) state=2;
			break;
		case 2:
			fadeVal++;	//Decrease and set the fade value
			SetFadeValue(fadeVal);
			if(fadeVal==31) state=3;
			break;
		}

		while(REG_VCOUNT<160);		//Wait for VBlank before copying in screen information

		flip();	//Flip the page
		bm.displayToScreen();

		while(REG_VCOUNT!=0);//Wait for VWrite to start
	}

	//Disable transparency
	SetTransparency(0);
}






// Print VBA debug line - From FAQ at http://vboy.emuhq.com
void print(char *s)
{
	asm volatile(
		"mov r0, %0;"
		"swi 0xff;"
		: // no ouput
		: "r" (s)
		: "r0");
}

//Sowtware reset bios call
void softReset(void) 
{ 
	asm volatile(
		"mov r0, #0x0;"
		"swi 1"
	); 
} 


//RegisterRAMReset() bios call
//	clears VRAM 
void cleanAfterPogoshell(void) 
{ 
	asm volatile(
		"mov r0, #0xFC;"
		"swi 1"
	); 
} 

void resetVideo(void) 
{ 
	asm volatile(
		"mov r0, #0x18;"
		"swi 1"
	); 
} 

