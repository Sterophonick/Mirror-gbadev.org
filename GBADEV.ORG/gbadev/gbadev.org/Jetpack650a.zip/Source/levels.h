//**************************************************************************************************
//
// levels.h
//
// Description: Header file prototyping all the level objects
//
// Created by: Pete Gunter 14/03/2004
//
//**************************************************************************************************


#include "gba.h"
#include "level.h"

/*** Levels ***/
extern CLevel level1;
extern CLevel level2;


/*** Level 1 information ***/
extern const u16 palLvl1palette[];
extern const u16 palLvl1Copper[];
extern const u16 bmpLvl1Tiles[];
extern const u8 mapLvl1Floor[];
extern const u8 mapLvl1Sky[];

/*** Level 2 Information ***/
extern const u16 palLvl2palette[];
extern const u16 palLvl2Copper[];
extern const u16 bmpLvl2Tiles[];
extern const u8 mapLvl2Floor[];
extern const u8 mapLvl2Sky[];

