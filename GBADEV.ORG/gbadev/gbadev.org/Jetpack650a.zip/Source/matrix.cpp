//**************************************************************************************************
//
// Matrix.h
//
// Description: Implementation of a transformation matrix. Contains CMatrix3 (a 3x3 matrix)
//					CMatrix2 (2x2 matrix)
//
// Created by: Pete Gunter 30/11/2003
//
//**************************************************************************************************


#include "matrix.h"

/**************************************************************************************************
CONSTRUCTION/DESTRUCTION
**************************************************************************************************/
CMatrix3::CMatrix3()
{
	//Loop through and initialise all to 0
	for (unsigned int x=0; x<3; x++)
	{
		for (unsigned int y=0; y<3; y++)
		{
			m_m[x][y]=0;
		}
	}
}

CMatrix3::~CMatrix3(){}	//No special requirements for destructor

/**************************************************************************************************
OVERLOADED OPERATORS
**************************************************************************************************/
//Assignment
CMatrix3& CMatrix3::operator = (const CMatrix3& matrix)
{
	//Loop through and copy all elements
	for (unsigned int x=0; x<3; x++)
	{
		for (unsigned int y=0; y<3; y++)
		{
			m_m[x][y]=matrix.getElement(x,y);
		}
	}

	return *this;
}

//Multiply by
CMatrix3& CMatrix3::operator *= (const CMatrix3& matrix)
{
	*this = *this * matrix;
	return *this;
}

//Transform a vector by a matrix
CVector3 operator * (const CVector3& v, const CMatrix3& m)
{
	/* Multiplies the referenced vector by the referenced matrix */
	unsigned int indexCounter, rowCounter;
	FIXED indexTotal;
	CVector3 vTemp;

	for ( indexCounter = 0; indexCounter < 3; indexCounter ++ )
	{
		indexTotal = 0;
		for ( rowCounter = 0; rowCounter < 3; rowCounter ++ )
		{
			indexTotal += ( v[rowCounter] * m.getElement(indexCounter,rowCounter) )>>8;
		}
		vTemp.setIndex(indexCounter, indexTotal);
	}

	return vTemp;
}

//Multiply a matrix by a matrix
CMatrix3 operator * (const CMatrix3& m1, const CMatrix3& m2)
{
	CMatrix3 temp = m1;		
	FIXED total;

	for (unsigned int y=0;y<3;y++)
	{
		for (unsigned int x=0;x<3;x++)
		{
			total = 0;
			for (unsigned int d=0;d<3;d++)
			{
				total += ( m1.getElement(d,y) * m2.getElement(x,d) )>>8; //f*f therefore <<8
			}
			temp.setElement(x, y, total);
		}
	}

	return temp;
}

/**************************************************************************************************
MEMBER FUNCTIONS
**************************************************************************************************/
//Clear the current matrix
CMatrix3& CMatrix3::clear(void)
{
	//Loop through and initialise all to 0
	for (unsigned int x=0; x<3; x++)
	{
		for (unsigned int y=0; y<3; y++)
		{
			m_m[x][y]=0;
		}
	}

	return *this;
}

//Set current matrix to the identity matrix
CMatrix3& CMatrix3::loadIdentity(void)
{
	//Loop through and initialise all to 0
	for (unsigned int x=0; x<3; x++)
	{
		for (unsigned int y=0; y<3; y++)
		{
			//1 if on diagonal, else 0
			if (x==y)
				m_m[x][y]=256;//1<<8
			else
				m_m[x][y]=0;
		}
	}

	return *this;
}

//Apply rotation matrix around the stated axis
CMatrix3& CMatrix3::rotation(FIXED angle, unsigned int axis)
{
	CMatrix3 temp=*this;

	switch(axis)
	{
		//X axis
		case X:
			loadIdentity();
			m_m[1][1] = fixcos(angle);
			m_m[2][1] = fixsin(angle);
			m_m[1][2] = -fixsin(angle);
			m_m[2][2] = fixcos(angle);	

			*this = temp * *this;
		break;

		//Y axis
		case Y:
			m_m[0][0] = fixcos(angle);
			m_m[2][0] = -fixsin(angle);
			m_m[0][2] = fixsin(angle);
			m_m[2][2] = fixcos(angle);

			*this = temp * *this;
		break;

		//Z axis
		case Z:
			m_m[0][0] = fixcos(angle);
			m_m[1][0] = fixsin(angle);
			m_m[0][1] = -fixsin(angle);
			m_m[1][1] = fixcos(angle);

			*this = temp * *this;
		break;

		default:
			break;
	}

	return *this;
}

//Apply a scaling matrix
CMatrix3& CMatrix3::localScaling(FIXED x, FIXED y, FIXED z)
{
	//Create temporary copy
	CMatrix3 temp=*this;

	//Set the scaling values
	temp.setElement(0, 0, x);
	temp.setElement(1, 1, y);
	temp.setElement(2, 2, z);

	//transform the matrix
	*this = temp * *this;

	return *this;
}

//Apply a reflection around the given axis
CMatrix3& CMatrix3::reflect(unsigned int axis)
{
	//Loop through each row
	for(unsigned int y=0; y<3; y++)
	{
		//Negate relevant axis
		m_m[axis][y] = -(m_m[axis][y]);
	}

	return *this;
}

//Create the transpose of the matrix
CMatrix3& CMatrix3::transpose(void)
{
	CMatrix3 temp = *this; //Temporary copy

	// Loop through elements
	for(unsigned int y=0; y<3; y++)
	{
		for (unsigned int x=y; x<3; x++)
		{
			m_m[x][y]=temp.getElement(y,x);
			m_m[y][x]=temp.getElement(x,y);
		}
	}

	return *this;
}

