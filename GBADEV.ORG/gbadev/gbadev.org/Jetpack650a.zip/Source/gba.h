// gba.h

#ifndef GBA_HEADER
#define GBA_HEADER

/**************************************************************************************************
Desc: Different memory area defines - Pete Gunter
		(thanks to Damian Yerrick)
Date: 18/11/2003
**************************************************************************************************/
#define CODE_IN_IWRAM __attribute__ ((section (".iwram"), long_call))


/*--------------typedefs-----------------------*/

typedef unsigned char u8;
typedef unsigned short u16;
typedef unsigned long u32;

typedef signed char s8;
typedef signed short s16;
typedef signed long s32;

typedef unsigned char byte;
typedef unsigned short hword;
typedef unsigned long word;

typedef volatile unsigned  char vu8;
typedef volatile unsigned  short vu16;
typedef volatile unsigned  long vu32;

typedef volatile signed char vs8;
typedef volatile signed short vs16;
typedef volatile signed long vs32;

typedef void (*fp)(void);  //a pointer to a void function

#define NULL 0


#define IN_EWRAM __attribute__ ((section (".ewram")))
#define IN_IWRAM __attribute__ ((section (".iwram")))


#define RGB16(r,g,b)  ((r)+(g<<5)+(b<<10))

#define FIXED s32
#define UFIXED u32

#define PI 3.14159
#define RADIAN(n) 		(((float)n)/(float)180*PI)

#define OAMMem  		((u32*)0x7000000)
#define VideoBuffer 	((u16*)0x6000000)
#define BackBuffer		((u16*)0x600A000)
#define OAMData			((u16*)0x6010000)
#define BGPaletteMem 	((u16*)0x5000000)
#define OBJPaletteMem 	((u16*)0x5000200)

#define REG_IFCHECKBUFF   *(vu16*)0x3007FF8
#define REG_INTERUPT   *(u32*)0x3007FFC
#define REG_DISPCNT    *(vu32*)0x4000000
#define REG_DISPCNT_L  *(vu16*)0x4000000
#define REG_DISPCNT_H  *(vu16*)0x4000002
#define REG_DISPSTAT   *(vu16*)0x4000004
#define REG_VCOUNT     *(vu16*)0x4000006
#define REG_BG0CNT     *(vu16*)0x4000008
#define REG_BG1CNT     *(vu16*)0x400000A
#define REG_BG2CNT     *(vu16*)0x400000C
#define REG_BG3CNT     *(vu16*)0x400000E
#define REG_BG0HOFS    *(vu16*)0x4000010
#define REG_BG0VOFS    *(vu16*)0x4000012
#define REG_BG1HOFS    *(vu16*)0x4000014
#define REG_BG1VOFS    *(vu16*)0x4000016
#define REG_BG2HOFS    *(vu16*)0x4000018
#define REG_BG2VOFS    *(vu16*)0x400001A
#define REG_BG3HOFS    *(vu16*)0x400001C
#define REG_BG3VOFS    *(vu16*)0x400001E
#define REG_BG2PA      *(vu16*)0x4000020
#define REG_BG2PB      *(vu16*)0x4000022
#define REG_BG2PC      *(vu16*)0x4000024
#define REG_BG2PD      *(vu16*)0x4000026
#define REG_BG2X       *(vu32*)0x4000028
#define REG_BG2X_L     *(vu16*)0x4000028
#define REG_BG2X_H     *(vu16*)0x400002A
#define REG_BG2Y       *(vu32*)0x400002C
#define REG_BG2Y_L     *(vu16*)0x400002C
#define REG_BG2Y_H     *(vu16*)0x400002E
#define REG_BG3PA      *(vu16*)0x4000030
#define REG_BG3PB      *(vu16*)0x4000032
#define REG_BG3PC      *(vu16*)0x4000034
#define REG_BG3PD      *(vu16*)0x4000036
#define REG_BG3X       *(vu32*)0x4000038
#define REG_BG3X_L     *(vu16*)0x4000038
#define REG_BG3X_H     *(vu16*)0x400003A
#define REG_BG3Y       *(vu32*)0x400003C
#define REG_BG3Y_L     *(vu16*)0x400003C
#define REG_BG3Y_H     *(vu16*)0x400003E
#define REG_WIN0H      *(vu16*)0x4000040
#define REG_WIN1H      *(vu16*)0x4000042
#define REG_WIN0V      *(vu16*)0x4000044
#define REG_WIN1V      *(vu16*)0x4000046
#define REG_WININ      *(vu16*)0x4000048
#define REG_WINOUT     *(vu16*)0x400004A
#define REG_MOSAIC     *(vu32*)0x400004C
#define REG_MOSAIC_L   *(vu32*)0x400004C
#define REG_MOSAIC_H   *(vu32*)0x400004E
#define REG_BLDMOD     *(vu16*)0x4000050
#define REG_COLV      *(vu16*)0x4000052
#define REG_COLY      *(vu16*)0x4000054
#define REG_SG10       *(vu32*)0x4000060
#define REG_SG10_L     *(vu16*)0x4000060
#define REG_SG10_H     *(vu16*)0x4000062
#define REG_SG11       *(vu16*)0x4000064
#define REG_SG20       *(vu16*)0x4000068
#define REG_SG21       *(vu16*)0x400006C
#define REG_SG30       *(vu32*)0x4000070
#define REG_SG30_L     *(vu16*)0x4000070
#define REG_SG30_H     *(vu16*)0x4000072
#define REG_SG31       *(vu16*)0x4000074
#define REG_SG40       *(vu16*)0x4000078
#define REG_SG41       *(vu16*)0x400007C
#define REG_SGCNT0     *(vu32*)0x4000080
#define REG_SGCNT0_L   *(vu16*)0x4000080
#define REG_SGCNT0_H   *(vu16*)0x4000082
#define REG_SGCNT1     *(vu16*)0x4000084
#define REG_SGBIAS     *(vu16*)0x4000088
#define REG_SGWR0      *(vu32*)0x4000090
#define REG_SGWR0_L    *(vu16*)0x4000090
#define REG_SGWR0_H    *(vu16*)0x4000092
#define REG_SGWR1      *(vu32*)0x4000094
#define REG_SGWR1_L    *(vu16*)0x4000094
#define REG_SGWR1_H    *(vu16*)0x4000096
#define REG_SGWR2      *(vu32*)0x4000098
#define REG_SGWR2_L    *(vu16*)0x4000098
#define REG_SGWR2_H    *(vu16*)0x400009A
#define REG_SGWR3      *(vu32*)0x400009C
#define REG_SGWR3_L    *(vu16*)0x400009C
#define REG_SGWR3_H    *(vu16*)0x400009E
#define REG_SGFIFOA    ((vu32*)0x40000A0)
#define REG_SGFIFOA_L  *(vu16*)0x40000A0
#define REG_SGFIFOA_H  *(vu16*)0x40000A2
#define REG_SGFIFOB    ((vu32*)0x40000A4)
#define REG_SGFIFOB_L  *(vu16*)0x40000A4
#define REG_SGFIFOB_H  *(vu16*)0x40000A6
#define REG_DMA0SAD     *(vu32*)0x40000B0
#define REG_DMA0SAD_L   *(vu16*)0x40000B0
#define REG_DMA0SAD_H   *(vu16*)0x40000B2
#define REG_DMA0DAD     *(vu32*)0x40000B4
#define REG_DMA0DAD_L   *(vu16*)0x40000B4
#define REG_DMA0DAD_H   *(vu16*)0x40000B6
#define REG_DMA0CNT     *(vu32*)0x40000B8
#define REG_DMA0CNT_L   *(vu16*)0x40000B8
#define REG_DMA0CNT_H   *(vu16*)0x40000BA
#define REG_DMA1SAD     *(vu32*)0x40000BC
#define REG_DMA1SAD_L   *(vu16*)0x40000BC
#define REG_DMA1SAD_H   *(vu16*)0x40000BE
#define REG_DMA1DAD     *(vu32*)0x40000C0
#define REG_DMA1DAD_L   *(vu16*)0x40000C0
#define REG_DMA1DAD_H   *(vu16*)0x40000C2
#define REG_DMA1CNT     *(vu32*)0x40000C4
#define REG_DMA1CNT_L   *(vu16*)0x40000C4
#define REG_DMA1CNT_H   *(vu16*)0x40000C6
#define REG_DMA2SAD     *(vu32*)0x40000C8
#define REG_DMA2SAD_L   *(vu16*)0x40000C8
#define REG_DMA2SAD_H   *(vu16*)0x40000CA
#define REG_DMA2DAD     *(vu32*)0x40000CC
#define REG_DMA2DAD_L   *(vu16*)0x40000CC
#define REG_DMA2DAD_H   *(vu16*)0x40000CE
#define REG_DMA2CNT     *(vu32*)0x40000D0
#define REG_DMA2CNT_L   *(vu16*)0x40000D0
#define REG_DMA2CNT_H   *(vu16*)0x40000D2
#define REG_DMA3SAD     *(vu32*)0x40000D4
#define REG_DMA3SAD_L   *(vu16*)0x40000D4
#define REG_DMA3SAD_H   *(vu16*)0x40000D6
#define REG_DMA3DAD     *(vu32*)0x40000D8
#define REG_DMA3DAD_L   *(vu16*)0x40000D8
#define REG_DMA3DAD_H   *(vu16*)0x40000DA
#define REG_DMA3CNT     *(vu32*)0x40000DC
#define REG_DMA3CNT_L   *(vu16*)0x40000DC
#define REG_DMA3CNT_H   *(vu16*)0x40000DE
#define REG_TM0D       *(vu16*)0x4000100
#define REG_TM0CNT     *(vu16*)0x4000102
#define REG_TM1D       *(vu16*)0x4000106
#define REG_TM2D       *(vu16*)0x4000108
#define REG_TM2CNT     *(vu16*)0x400010A
#define REG_TM3D       *(vu16*)0x400010C
#define REG_TM3CNT     *(vu16*)0x400010E
#define REG_SCD0       *(vu16*)0x4000120
#define REG_SCD1       *(vu16*)0x4000122
#define REG_SCD2       *(vu16*)0x4000124
#define REG_SCD3       *(vu16*)0x4000126
#define REG_SCCNT      *(vu32*)0x4000128
#define REG_SCCNT_L    *(vu16*)0x4000128
#define REG_SCCNT_H    *(vu16*)0x400012A
#define REG_P1         *(vu16*)0x4000130
#define REG_P1CNT      *(vu16*)0x4000132
#define REG_R          *(vu16*)0x4000134
#define REG_HS_CTRL    *(vu16*)0x4000140
#define REG_JOYRE      *(vu32*)0x4000150
#define REG_JOYRE_L    *(vu16*)0x4000150
#define REG_JOYRE_H    *(vu16*)0x4000152
#define REG_JOYTR      *(vu32*)0x4000154
#define REG_JOYTR_L    *(vu16*)0x4000154
#define REG_JOYTR_H    *(vu16*)0x4000156
#define REG_JSTAT      *(vu32*)0x4000158
#define REG_JSTAT_L    *(vu16*)0x4000158
#define REG_JSTAT_H    *(vu16*)0x400015A
#define REG_IE         *(vu16*)0x4000200
#define REG_IF         *(vu16*)0x4000202
#define REG_WSCNT      *(vu16*)0x4000204
#define REG_IME        *(vu16*)0x4000208
#define REG_PAUSE      *(vu16*)0x4000300

#define BIT(x) (1<<x)	//I added this for the OAM Manager class
#define BIT0 1
#define BIT1 (1<<1)
#define BIT2 (1<<2)
#define BIT3 (1<<3)
#define BIT4 (1<<4)
#define BIT5 (1<<5)
#define BIT6 (1<<6)
#define BIT7 (1<<7)
#define BIT8 (1<<8)
#define BIT9 (1<<9)
#define BIT10 (1<<10)
#define BIT11 (1<<11)
#define BIT12 (1<<12)
#define BIT13 (1<<13)
#define BIT14 (1<<14)
#define BIT15 (1<<15)
#define BIT16 (1<<16)
#define BIT17 (1<<17)
#define BIT18 (1<<18)
#define BIT19 (1<<19)
#define BIT20 (1<<20)
#define BIT21 (1<<21)
#define BIT22 (1<<22)
#define BIT23 (1<<23)
#define BIT24 (1<<24)
#define BIT25 (1<<25)
#define BIT26 (1<<26)
#define BIT27 (1<<27)
#define BIT28 (1<<28)
#define BIT29 (1<<29)
#define BIT30 (1<<30)
#define BIT31 (1<<31)


/*--------------------Mosaic Defines (Day 4)---------------------------*/
#define MOS_BG_HOR(n) (n)
#define MOS_BG_VER(n) (n<<4)
#define MOS_OBJ_HOR(n) (n<<8)
#define MOS_OBJ_VER(n) (n<<12)

#define SetMosaic(bh,bv,oh,ov) ((bh)+(bv<<4)+(oh<<8)+(ov<<12))

/*--------------------------------------------------------------------*/



/*---------------------------DMA Defines (Day 5)----------------------*/
//these defines let you control individual bit in the control register

#define DMA_ENABLE						0x80000000
#define DMA_INTERUPT_ENABLE				0x40000000
#define DMA_TIMEING_IMMEDIATE			0x00000000
#define DMA_TIMEING_VBLANK				0x10000000
#define DMA_TIMEING_HBLANK				0x20000000
#define DMA_TIMEING_SYNC_TO_DISPLAY		0x30000000
#define DMA_TIMEING_DSOUND				0x30000000
#define DMA_16							0x00000000
#define DMA_32							0x04000000
#define DMA_REPEATE						0x02000000
#define DMA_SOURCE_INCREMENT			0x00000000
#define DMA_SOURCE_DECREMENT			0x00800000
#define DMA_SOURCE_FIXED				0x01000000
#define DMA_DEST_INCREMENT				0x00000000
#define DMA_DEST_DECREMENT				0x00200000
#define DMA_DEST_FIXED					0x00400000
#define DMA_DEST_RELOAD					0x00600000

//these defines group common options to save typing. You may notice that I don�t have to include the option to increment the source and address register as that is the default.

#define DMA_32NOW      (DMA_ENABLE | DMA_TIMEING_IMMEDIATE |DMA_32) 
#define DMA_16NOW	   (DMA_ENABLE | DMA_TIMEING_IMMEDIATE |DMA_16) 

//Definition of DMA copy routine. Found in dma.c
void DMA_Copy(u8 channel, void* source, void* dest, u32 WordCount, u32 mode);
/*--------------------------------------------------------------------*/


/*---------Keys defines (day 3) -------------------------------------*/
#define KEY_A			1
#define KEY_B			2
#define KEY_SELECT		4
#define KEY_START		8
#define KEY_RIGHT		16
#define KEY_LEFT		32
#define KEY_UP			64
#define KEY_DOWN		128
#define KEY_R			256
#define KEY_L			512
#define KEYS  (*(volatile u32*)0x04000130)
/*-------------------------------------------------------------------*/


/*----------------Screen and Background defines (Day 1-2, 4) ---------------*/
///// REG_DISPCNT defines

#define MODE_0			0x0
#define MODE_1			0x1
#define MODE_2			0x2
#define MODE_3			0x3
#define MODE_4			0x4
#define MODE_5			0x5

#define BACKBUFFER		0x10
#define H_BLANK_OAM		0x20 

#define OBJ_MAP_2D		0x0
#define OBJ_MAP_1D		0x40

#define FORCE_BLANK		0x80

#define BG0_ENABLE		0x100
#define BG1_ENABLE		0x200 
#define BG2_ENABLE		0x400
#define BG3_ENABLE		0x800
#define OBJ_ENABLE		0x1000 

#define WIN1_ENABLE		0x2000 
#define WIN2_ENABLE		0x4000
#define WINOBJ_ENABLE	0x8000


///////SetMode Macro
#define SetMode(mode) REG_DISPCNT = (mode) 

///
///BGxCNT defines ///
#define BG_MOSAIC_ENABLE		0x40
#define BG_COLOR256				0x80
#define BG_COLOR16				0x0

#define CharBaseBlock(n)		(((n)*0x4000)+0x6000000)
#define ScreenBaseBlock(n)		(((n)*0x800)+0x6000000)

#define CHAR_SHIFT				2
#define SCREEN_SHIFT			8
#define TEXTBG_SIZE_256x256		0x0
#define TEXTBG_SIZE_256x512		0x8000
#define TEXTBG_SIZE_512x256		0x4000
#define TEXTBG_SIZE_512x512		0xC000

#define ROTBG_SIZE_128x128		0x0
#define ROTBG_SIZE_256x256		0x4000
#define ROTBG_SIZE_512x512		0x8000
#define ROTBG_SIZE_1024x1024	0xC000

#define WRAPAROUND              0x2000
/*--------------------------------------------------------------------*/


/*-------------------Sprites (Day 3)---------------------------------*/
//Atribute0 stuff
#define ROTATION_FLAG 		0x100
#define SIZE_DOUBLE			0x200
#define MODE_NORMAL     	0x0
#define MODE_TRANSPARENT	0x400
#define MODE_WINDOWED		0x800
#define MOSAIC				0x1000
#define COLOR_16			0x0000
#define COLOR_256			0x2000
#define SQUARE				0x0
#define TALL				0x8000
#define WIDE				0x4000
	
//Atribute1 stuff
#define ROTDATA(n)			((n) << 9)
#define HORIZONTAL_FLIP		0x1000
#define VERTICAL_FLIP		0x2000
#define SIZE_8				0x0
#define SIZE_16				0x4000
#define SIZE_32				0x8000
#define SIZE_64				0xC000

//atribute2 stuff

#define PRIORITY(n)			((n) << 10)
#define PALETTE(n)			((n) << 12)


/////structs/////

typedef struct tagOAMEntry
{
	u16 attribute0;
	u16 attribute1;
	u16 attribute2;
	u16 attribute3;
}OAMEntry,*pOAMEntry;

typedef struct tagRotData
{
		
	u16 filler1[3];
	u16 pa;

	u16 filler2[3];
	u16 pb;	
		
	u16 filler3[3];
	u16 pc;	

	u16 filler4[3];
	u16 pd;
}RotData,*pRotData;

/*-------------------Interupts (Day 5)---------------------------------*/
#define INT_VBLANK    		0x0001
#define INT_HBLANK			0x0002	
#define INT_VCOUNT			0x0004	
#define INT_TIMMER0			0x0008
#define INT_TIMMER1			0x0010
#define INT_TIMMER2			0x0020	
#define INT_TIMMER3			0x0040
#define INT_COMUNICATION	0x0080
#define INT_DMA0			0x0100
#define INT_DMA1			0x0200
#define INT_DMA2			0x0400
#define INT_DMA3			0x0800
#define INT_KEYBOARD		0x1000
#define INT_CART			0x2000
#define INT_ALL				0x4000

void CODE_IN_IWRAM interrupt(void);

/*--------------A random Number generator I stole from someone-----------*/
//commented out but feel free to put it in.

// extern "C" void r256init(void);
// extern "C" unsigned short r256(void);
//this is the random number generator Just put it in your code somewere 
//(rand.cpp mabey)
//Just call init to turn it on and mabey call it a few times while waiting for
//a keypress and it should be halfway random by the time you go to use it


/*
unsigned short r256table[256];
unsigned char r256index;

void r256init(void) {
	int i,j,msb;
	j=42424;
	for(i=0;i<256;i++){
		r256table[i]=(unsigned short)(j=j*65539);
	}
	msb=0x8000;
	j=0;
	for(i=0;i<16;i++) {
		j=i*5+3;
		r256table[j]|=msb;
		r256table[j+1]&=~msb;
		msb>>=1;
	}
}

unsigned short r256(void) {
	int r;
	r=r256table[(r256index+103)&255]^r256table[r256index];
	r256table[r256index++]=r;
	return r;
}	

/*---------------------------------------------------------------------*/

/************************************\
* Timers by dovoto *
\************************************/
#define TIME_FREQUENCY_SYSTEM 0x0
#define TIME_FREQUENCY_64 0x1
#define TIME_FREQUENCY_256 0x2
#define TIME_FREQUENCY_1024 0x3
#define TIME_OVERFLOW 0x4
#define TIME_ENABLE 0x80
#define TIME_IRQ_ENABLE 0x40


/**************************************************************************************************
Desc: Defines for display statistics - Pete Gunter
Date: 18/11/2003
**************************************************************************************************/
#define DST_VBLANK				0x0001		//Status of VBlank
#define DST_HBLANK				0x0002		//Status of HBlank
#define DST_VTRIGGER			0x0004		//Status of VTrigger
#define DST_ENABLE_VBLANK		0x0008		//Enables VBlank
#define DST_ENABLE_HBLANK		0x0010		//Enables HBlank
#define DST_ENABLE_VTRIGGER		0x0020		//Enables the trigger
#define DST_SET_VTRIGGER(n)		((n) << 8)	//Set's the trigger

/**************************************************************************************************
Desc: Defines for transparency effects - Pete Gunter
Date: 11/02/2004
**************************************************************************************************/

#define SetTransparency(mode)	REG_BLDMOD = mode
#define SetFadeValue(n)			REG_COLY = n
#define SetBlend(n1,n2)	REG_COLV = ( n1 | (n2<<8))

#define BG0_TARGET1			0x0001		//Target 1 BG0
#define BG1_TARGET1			0x0002		//Target  BG1
#define BG2_TARGET1			0x0004		//Target BG2
#define BG3_TARGET1			0x0008		//Target BG3
#define BACK_TARGET1		0x0010		//Background plane
#define OBJ_TARGET1			0x0020		//Objects

#define BG0_TARGET2			0x0100		//Target 2 BG0
#define BG1_TARGET2			0x0200		//Target BG1
#define BG2_TARGET2			0x0400		//Target BG2
#define BG3_TARGET2			0x2800		//Target BG3
#define BACK_TARGET2		0x1000		//Background plane
#define OBJ_TARGET2			0x2000		//Objects

#define BLD_MODE(n)			((n) << 6)
#define BLD_MODE_NONE		0
#define BLD_MODE_ALPHA		1
#define BLD_MODE_LIGHTEN	2
#define BLD_MODE_DARKEN		3

#endif //endif GBA_H


