//**************************************************************************************************
//
// iwram.h
//
// Description: Interface for functions held in iwram
//
// Created by: Pete Gunter 04/03/2004
//
//**************************************************************************************************

#include "gba.h"

//Function prototypes
void CODE_IN_IWRAM updateHUD(void);
void CODE_IN_IWRAM printSNum(s16 n, u16 x, u16 y);
void CODE_IN_IWRAM printUNum(u16 n, u16 x, u16 y);
void CODE_IN_IWRAM printStr(char* string, u16 x, u16 y);
void CODE_IN_IWRAM drawBar(u8 val, u8 bottomChar, u16 x, u16 y);
