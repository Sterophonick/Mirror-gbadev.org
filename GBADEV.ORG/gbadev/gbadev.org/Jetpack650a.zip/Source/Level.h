// Level.h: interface for the CLevel class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_LEVEL_H)
#define AFX_LEVEL_H

#include "gba.h"


class CLevel
{
public:
	CLevel();
	//Constructor with initialisation
	CLevel(	const u16* ppalBackground,
			const u16* pbmpMapTiles,
			const u8* pmapFloor,
			const u8* pmapSky,
			const u16* ppalCopper,
			FIXED gravity
		);

	virtual ~CLevel();

/*	void initialise(
				const u16* ppalBackground,
				const u16* pbmpMapTiles,
				const u8* pmapFloor,
				const u8* pmapSky,
				const u16* ppalCopper,
				const FIXED gravity
			);*/

	void loadLvlIntoMemory(void);

private: 
   const u16* m_ppalBackground;   //Pointer to levels pallette 
   const u16* m_pbmpMapTiles;      //Pointer to levels map tiles 
   const u8* m_pmapFloor;         //Pointer to levels floor map 
   const u8* m_pmapSky;         //Pointer to levels sky map 
   const u16* m_ppalCopper;      //Pointer to pallete used for copper bar effect 

   FIXED m_gravity;            //FIXED :16 value of acceleration due to gravity 

};

#endif // !defined(AFX_LEVEL_H__48470CEF_48B1_487F_95C2_6315ABA22A5E__INCLUDED_)
