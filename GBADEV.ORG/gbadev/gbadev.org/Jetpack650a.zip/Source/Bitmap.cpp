// Bitmap.cpp: implementation of the CBitmap class.
//
//////////////////////////////////////////////////////////////////////

#include "Bitmap.h"

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

CBitmap::CBitmap(const u16* pData, const u16* pPal, u16 w, u16 h)
{
	m_pData = pData;
	m_pPal = pPal;
	m_width = w;
	m_height = h;
}

CBitmap::~CBitmap()
{

}

void CBitmap::displayToScreen()
{
	//Copy into the Video momory
//	DMA_Copy(3,(void*)m_pData,(void*)gBuffer,19200,DMA_16NOW);//Each pixel is a byte, so copy (240*160)/2 16bit registers
	u16 i;
	for(i=0; i<19200; i++)
		((u16*)gBuffer)[i] = ((u16*)m_pData)[i];
}


void CBitmap::copyInPalette()
{
	//Copy palette memory
//	DMA_Copy(3,(void*)m_pPal,(void*)BGPaletteMem,256,DMA_16NOW);
	u8 p;
	for(p=0; p<128; p++)
		((u32*)BGPaletteMem)[p] = ((u32*)m_pPal)[p];
}
