//**************************************************************************************************
//
// Matrix.h
//
// Description: 
//
// Created by: Pete Gunter 30/11/2003
//
//		Rotations use an angle system from 0 to 2046:
//			90 degrees  = 512<<8
//			180 degrees = 1023<<8
//			360 degrees = 2046<<8
//
//**************************************************************************************************


#if !defined(_PG_MATRIX)
#define _PG_MATRIX

#include "vector.h"
#include "gbaMath.h"

/**************************************************************************************************
Desc: CMatrix3 class
Date: 30/11/2003
**************************************************************************************************/
class CMatrix3  
{
public:
/**************************************************************************************************
CONSTRUCTION/DESTRUCTION
**************************************************************************************************/
	CMatrix3();
	virtual ~CMatrix3();

/**************************************************************************************************
ACCESSORS
**************************************************************************************************/
	//Return the specified matrix element
	inline FIXED getElement(unsigned int x, unsigned int y) const {return m_m[x][y];};
	//Set the specied element
	inline void setElement(unsigned int x, unsigned int y, FIXED val){m_m[x][y] = val;};

/**************************************************************************************************
OVERLOADED OPERATORS
**************************************************************************************************/
	CMatrix3& operator = (const CMatrix3& matrix);		//Assignment
	CMatrix3& operator *= (const CMatrix3& matrix);		//Transform

	friend CVector3 operator * (const CVector3& v, const CMatrix3& m);	//Transform vector
	friend CMatrix3 operator * (const CMatrix3& m1, const CMatrix3& m2);	//Transform matrix

/**************************************************************************************************
MEMBER FUNCTIONS
**************************************************************************************************/
	CMatrix3& clear(void);										//Clear matrix
	CMatrix3& loadIdentity(void);								//Load identity matrix
	CMatrix3& rotation(FIXED angle, unsigned int axis);			//Rotate by given angle around referenced axis
	CMatrix3& localScaling(FIXED x, FIXED y, FIXED z);			//Apply scaling transformation
	CMatrix3& reflect(unsigned int axis);						//Apply reflection around given axis
	CMatrix3& transpose(void);									//Make matrix transpose

private:
/**************************************************************************************************
MEMBER VARIABLES
**************************************************************************************************/
	FIXED m_m[3][3];
};

#endif // !defined(_PG_MATRIX)
