#include "iwram.h"

#include "gbaMath.h"
#include "player.h"
#include "vector.h"
#include "map.h"


//External globals
extern CPlayer gPlayer;
extern s16 gTime;
extern OAMEntry sprites[128];
extern u8 gDebug;
extern u16 gpalCopper[160];


//Globals
FIXED tempC;
FIXED tempS;
u8 flashColour=0;

#define _P_MAP_DATA (u16*)ScreenBaseBlock(29)
#define CHAR(n) (n-32)

//Function prototypes
void CODE_IN_IWRAM copyOAM(void);
void CODE_IN_IWRAM update(void);
void CODE_IN_IWRAM getInput(void);

/* Interupt handler */
void CODE_IN_IWRAM interrupt(void)
{
	/* make a local copy of the interrupts that happened */
	u16 reg_if = REG_IF;

	/* disable interrupts */
	REG_IME = 0;

	if(reg_if & INT_VBLANK)
	{
		s16 angle = gPlayer.getAngle();
		
		//*** Initialise data for Mode 7
		// Lookup sin and cos of angle.
		tempC = fixcos16(angle);
		tempS = fixsin16(angle);

		///*** Initialise starfield
		// Set the mode to enable the sky layer
		SetMode(MODE_1 |  BG0_ENABLE | BG1_ENABLE | OBJ_ENABLE | OBJ_MAP_2D);
		// Change background 1's horizontal offeset to match players angle
		REG_BG1HOFS = -(angle>>2);// -(angle/4)

		//*** Update the HUD
		updateHUD();

		//*** Change colour 1 of the BG palette to the first colour in the sunset
		BGPaletteMem[0] = gpalCopper[0];

		//*** Change the flash colour
		flashColour++;
		if( flashColour == 6) flashColour = 0;
		BGPaletteMem[1] = palFlash[flashColour];

		//*** Copy the OAM data to memory
		copyOAM();
	}

	if(reg_if & INT_HBLANK)
	{

		//*** On 40th line, start Mode 7 drawing (Background 2)
		if (REG_VCOUNT == 40)
		{
			/* Begin drawing floor */
			SetMode(MODE_1 |  BG0_ENABLE | BG2_ENABLE | OBJ_ENABLE | OBJ_MAP_2D);
			/* Start blending fade in */
			SetTransparency( BG2_TARGET1 | BLD_MODE(2) );
		}

		//*** Update the transparency register for fog effect
		SetFadeValue( (REG_VCOUNT-40)>>3 );

		if (REG_VCOUNT >= 40)
		{
			CVector3& cam = gPlayer.getCamPos();

			//Calculate zoom = height/scanline
			FIXED zoom = fixdiv( gPlayer.getEyeHeight(), (REG_VCOUNT) );

			FIXED centerX = ( 120 * zoom );
			FIXED centerY = ( 160 * zoom );
			
			REG_BG2X = (
					(cam[X]<<8)	//24:8
				-	centerY*tempS		//16:16
				-	centerX*tempC		//16:16
			)>>16;


			REG_BG2Y = (
					(cam[Z]<<8)
				-	centerY*tempC
				+	centerX*tempS
			)>>16;

 			REG_BG2PA  = (tempC*zoom)  >>  16;  //cos&sin are LUTs that are .8 fixed numbers
			REG_BG2PB  = (tempS*zoom)  >>  16;  //zoom is also fixed
			REG_BG2PC  = (-tempS*zoom) >>  16;
			REG_BG2PD  = (tempC*zoom)  >>  16;
		}

		//Change colour 1 of the BG palette to the corresponding colour in the sunset
		BGPaletteMem[0] = gpalCopper[REG_VCOUNT];
	}

	if(reg_if & INT_TIMMER2)
	{
		gTime--;
	}

	/* acknowledge to BIOS, for IntrWait() */
	*(volatile unsigned short *)0x03fffff8 |= reg_if;
	/* acknowledge to hardware */
	REG_IF = reg_if;
	/* reenable interrupts */
	REG_IME = 1;
}

void CODE_IN_IWRAM updateHUD(void)
{
//*** Draw health bar
	u16* pMapData = _P_MAP_DATA;

//*** Draw health bar
	u16 intHealth = gPlayer.getHealth();
	drawBar(intHealth, 97, 1, 16); //Divide by 2 to get within range 0-120

//*** Draw fuel bar
	u16 intFuel = (gPlayer.getFuel() * intReciprocal[30])>>16;
	drawBar(intFuel, 108, 2, 16);

//*** Write time
	printSNum(gTime, 24, 1);

//*** Write height
	printSNum(gPlayer.getHeight()>>8, 24, 2);

	if( gDebug )
	{
		//Debug health
		printStr("h:     \n", 4, 1);
		printUNum(gPlayer.getHealth(), 6, 1);
		//Debug fuel
		printStr("f:     \n", 4, 2);
		printUNum(gPlayer.getFuel(), 6, 2);
		//Debug rotational velocity
		printStr("r:     \n", 4, 3);
		printSNum(gPlayer.getRotVelocity()>>16, 6, 3);

		printStr("-vel-  -pos-\n",6, 13);   
		//Debug x velocity
		printStr("x:            \n", 4, 14);
		printSNum(gPlayer.getXvelocity()>>16, 6, 14);
		//Debug y velocity
		printStr("y:            \n", 4, 15);
		printSNum(gPlayer.getYvelocity()>>16, 6, 15);
			//Debug y velocity
		printStr("z:            \n", 4, 16);
		printSNum(gPlayer.getZvelocity()>>16, 6, 16);

		//Debug x position
		printSNum(gPlayer.getX()>>8, 13, 14);
		//Debug y position
		printSNum(gPlayer.getY()>>8, 13, 15);
		//Debug y position
		printSNum(gPlayer.getZ()>>8, 13, 16);

		//Debug angle
		//Angle vel
		printStr("AV:       \n", 20, 14);
		printSNum(gPlayer.getRotVelocity()>>16, 24, 14);
		//Debug Angle
		printStr("A:        \n", 20, 15);
		printSNum(gPlayer.getAngle(), 24, 15);
		//Debug Sin
		printStr("Sin:      \n", 20, 16);
		printSNum(tempS, 24, 16);
		//Debug Cos
		printStr("Cos:      \n", 20, 17);
		printSNum(tempC, 24, 17);

		CVector3& camPos = gPlayer.getCamPos();
		printStr("Camera\n",20, 9);   
		//Debug cam xPos
		printStr("x:            \n", 20, 10);
		printSNum(camPos[X]>>8, 22, 10);
		//Debug cam yPos
		printStr("y:            \n", 20, 11);
		printSNum(camPos[Y]>>8, 22, 11);
			//Debug cam zPos
		printStr("z:            \n", 20, 12);
		printSNum(camPos[Z]>>8, 22, 12);
	};

}

void CODE_IN_IWRAM printSNum(s16 n, u16 x, u16 y)
{
	//  Method of binary to decimal conversion presented 
	//		at http://www.cs.uiowa.edu/~jones/bcd/decimal.html
	u16* pMapData = _P_MAP_DATA;
	s16 a, b, c, d;

	u16 line = y<<5;	// Number of line (y*32)

	//Put minus symbol if negative
	if (n < 0) {
	    pMapData[(x++)+line] = CHAR( '-' );
	    n = -n;
	}

	//Iterate back and forth through 5 digits
	for ( a = 0 - 1; n >= 0; n -= 10000 ) ++a;
	for ( b = 9 + 1; n <  0; n += 1000  ) --b;
	for ( c = 0 - 1; n >= 0; n -= 100   ) ++c;
	for ( d = 9 + 1; n <  0; n += 10    ) --d;

	//Output number
	pMapData[(x++)+line] = CHAR('0') + a;
	pMapData[(x++)+line] = CHAR('0') + b;
	pMapData[(x++)+line] = CHAR('0') + c;
	pMapData[(x++)+line] = CHAR('0') + d;
	pMapData[(x)+line] = CHAR('0') + n;
}

void CODE_IN_IWRAM printUNum(u16 n, u16 x, u16 y)
{
	//  Method of binary to decimal conversion presented 
	//		at http://www.cs.uiowa.edu/~jones/bcd/decimal.html
	u16* pMapData = _P_MAP_DATA;
	s16 a, b, c, d;
	s16 num=n;	//Need to copy as a signed number

	u16 line = y<<5;	// Number of line (y*32)

	//Iterate back and forth through 5 digits
	for ( a = 0 - 1; num >= 0; num -= 10000 ) ++a;
	for ( b = 9 + 1; num <  0; num += 1000  ) --b;
	for ( c = 0 - 1; num >= 0; num -= 100   ) ++c;
	for ( d = 9 + 1; num <  0; num += 10    ) --d;

	//Output number
	pMapData[(x++)+line] = CHAR('0') + a;
	pMapData[(x++)+line] = CHAR('0') + b;
	pMapData[(x++)+line] = CHAR('0') + c;
	pMapData[(x++)+line] = CHAR('0') + d;
	pMapData[(x)+line] = CHAR('0') + num;
}

//Print a newline terminated string
void CODE_IN_IWRAM printStr(char* string, u16 x, u16 y)
{
	u16* pMapData = _P_MAP_DATA;

	u8 curChar;

	u16 line = y<<5; //Height is y*32
	//Loop untill end of string
	do
	{
		curChar = *string++;			//Read character from string
		pMapData[(x++)+line] = CHAR(curChar);	//Write character to screen (-32 because font begins at space char)
		
		if(x>31) break;					//Break if gone past of end of screen
	} while( curChar != '\n');

}

//Draw a bar, where val is the height of the bar, bottomChar is the
//	character number of the bottom tile, and x and y are the position
//	of the empty tile
void CODE_IN_IWRAM drawBar(u8 val, u8 bottomChar, u16 x, u16 y)
{
	u16* pMapData = _P_MAP_DATA;

	//Work out full blocks and remainder
	u8 fullBlocks = val>>3;				//Number of full blocks = value/8
	u8 remainder = val-(fullBlocks<<3);	//Remainder = health-(fullBlocks*8)

	//Loop through blocks of bar
	u16 count=0;
	for(u8 h=y; h>1; h--)
	{
		count++;
		//Next line ('<<5'='*32')
		pMapData[x+(h<<5)] = (count<=fullBlocks) ? bottomChar+8:bottomChar;
	}

	//Set remainder block
	if(remainder)
		pMapData[x+((y-fullBlocks)<<5)]= bottomChar + remainder;
}

//Copy our sprite array to OAM
void CODE_IN_IWRAM copyOAM(void)
{
	REG_DMA3SAD = (u32)sprites;
	REG_DMA3DAD = (u32)OAMMem;
	//Copy the sprite data using DMA, on next VBLANK
	REG_DMA3CNT = 128*4 | DMA_TIMEING_VBLANK | DMA_ENABLE | DMA_16;
}

