//**************************************************************************************************
//
// vector3.h
//
// Description: Classes to hold vectors with 2 and 3 fixed point values. Fixed point numbers
//				have 8bit fractions.
//				Uses aggressive inlining for efficiency.
//
// Created by: Pete Gunter 28/11/2003
//
//**************************************************************************************************

#if !defined(_PG_VECTOR)
#define _PG_VECTOR


#include "gba.h"
#include <math.h>

enum{ X, Y, Z};

/**************************************************************************************************
Desc: CVector3 : x, y and z fixed point values
Date: 28/11/2003
**************************************************************************************************/
class CVector3  
{
public:
/**************************************************************************************************
CONSTRUCTION/DESTRUCTION
**************************************************************************************************/
	CVector3(FIXED x=0, FIXED y=0, FIXED z=0);	//With specified values
	CVector3(const CVector3& vect);			//Copy constructor
	virtual ~CVector3();

/**************************************************************************************************
OVERLOADED OPERATORS
**************************************************************************************************/
	CVector3& operator = (const CVector3& Vect);	//Assignment of another Vector
	FIXED operator [] (int index) const;
	CVector3& operator += (const CVector3& Vect);	// += operator
	CVector3& operator -= (const CVector3& Vect);	// -= operator
	CVector3& operator *= (FIXED t);				// *= operator
	CVector3& operator /= (FIXED t);				// /= operator

	friend CVector3 operator >> (const CVector3& vect, unsigned int shift);		// Bitwise shift right operator
	friend CVector3 operator << (const CVector3& vect, unsigned int shift);		// Bitwise shift left operator
	friend CVector3 operator+(const CVector3& v1, const CVector3& v2);
	friend CVector3 operator-(const CVector3& v1, const CVector3& v2);
	friend CVector3 operator*(FIXED t, const CVector3& v);
	friend CVector3 operator*(const CVector3& v, FIXED t);
	friend CVector3 operator/(const CVector3& v, FIXED t);

/**************************************************************************************************
ACCESSORS
**************************************************************************************************/
	inline FIXED getIndex(unsigned int index) const {return m_v[index];};
	inline void setIndex(unsigned int index, FIXED val){m_v[index] = val;};

	
	FIXED dotProduct(const CVector3 &vect);
	CVector3 crossProduct(const CVector3 &vect);

private:
	FIXED m_v[3];
};


/**************************************************************************************************
Desc: CVector2 : x and y fixed point values
Date: 28/11/2003
**************************************************************************************************/
class CVector2
{
public:
/**************************************************************************************************
CONSTRUCTION/DESTRUCTION
**************************************************************************************************/
	CVector2(FIXED x=0, FIXED y=0);	//With specified values
	CVector2(const CVector2& vect);	//Copy constructor
	virtual ~CVector2();

/**************************************************************************************************
OVERLOADED OPERATORS
**************************************************************************************************/
	CVector2& operator = (const CVector2& Vect);	//Assignment of another Vector
	FIXED operator [] (int index) const;
	CVector2& operator += (const CVector2& Vect);	// += operator
	CVector2& operator -= (const CVector2& Vect);	// -= operator
	CVector2& operator *= (FIXED t);				// *= operator
	CVector2& operator /= (FIXED t);				// /= operator

	friend CVector2 operator+(const CVector2& v1, const CVector2& v2);
	friend CVector2 operator-(const CVector2& v1, const CVector2& v2);
	friend CVector2 operator*(FIXED t, const CVector2& v);
	friend CVector2 operator*(const CVector2& v, FIXED t);
	friend CVector2 operator/(const CVector2& v, FIXED t);

/**************************************************************************************************
ACCESSORS
**************************************************************************************************/
	void setIndex(unsigned int index, FIXED val){m_v[index] = val;};
	
	FIXED dotProduct(const CVector2& vect);

private:
	FIXED m_v[2];
};





/**************************************************************************************************
Desc: CVector2 : Function definitions
Date: 28/11/2003
**************************************************************************************************/
/**************************************************************************************************
CONSTRUCTION/DESTRUCTION
**************************************************************************************************/
inline CVector2::CVector2(FIXED x, FIXED y)	//With specified values
{
	m_v[X] = x;
	m_v[Y] = y;
}

inline CVector2::CVector2(const CVector2& vect)	//Copy constructor
{
	m_v[X] = vect[X];
	m_v[Y] = vect[Y];
}

inline CVector2::~CVector2(){};					//Nothing special needed in destructor

/**************************************************************************************************
OVERLOADED OPERATORS
**************************************************************************************************/
inline CVector2& CVector2::operator = (const CVector2& vect)	//Assignment of another Vector
{
	m_v[X] = vect[X];
	m_v[Y] = vect[Y];

	return *this;
}
inline FIXED CVector2::operator [] (int index) const
{
	return m_v[index];
}
inline CVector2& CVector2::operator += (const CVector2& vect)	// += operator
{
	m_v[X] += vect[X];
	m_v[Y] += vect[Y];

	return *this;
}
inline CVector2& CVector2::operator -= (const CVector2& vect) // -= operator
{
	m_v[X] -= vect[X];
	m_v[Y] -= vect[Y];

	return *this;
}
inline CVector2& CVector2::operator *= (FIXED t)			// *= operator
{
	m_v[X] = (t * m_v[X])>>8; //bitshift right becase :8 * :8
	m_v[Y] = (t * m_v[Y])>>8; //"

	return *this;
}
inline CVector2& CVector2::operator /= (FIXED t)			// *= operator
{
	m_v[X] = (m_v[X]/t)<<8;	//bitshift left becase :8 / :8
	m_v[Y] = (m_v[Y]/t)<<8; //"

	return *this;
}

inline CVector2 operator+(const CVector2& v1, const CVector2& v2)
{
	CVector2 vect(v1);
	return vect += v2;
}
inline CVector2 operator-(const CVector2& v1, const CVector2& v2)
{
	CVector2 vect(v1);
	return vect -= v2;
}
inline CVector2 operator*(FIXED t, const CVector2& v)
{
	CVector2 vect(v);
	return vect *= t;
}
inline CVector2 operator*(const CVector2& v, FIXED t)
{
	CVector2 vect(v);
	return vect *= t;
}
inline CVector2 operator/(const CVector2& v, FIXED t)
{
	CVector2 vect(v);
	return vect /= t;
}

/**************************************************************************************************
ACCESSORS
**************************************************************************************************/
inline FIXED CVector2::dotProduct(const CVector2 &vect)
{
	return ( (m_v[X]*vect.m_v[X]) + (m_v[Y]*vect.m_v[Y]) )>>8;//(x:8)^2 so shift >>8
}



/**************************************************************************************************
Desc: CVector3 : Function definitions
Date: 28/11/2003
**************************************************************************************************/
/**************************************************************************************************
CONSTRUCTION/DESTRUCTION
**************************************************************************************************/
inline CVector3::CVector3(FIXED x, FIXED y, FIXED z)	//With specified values
{
	m_v[X] = x;
	m_v[Y] = y;
	m_v[Z] = z;
}

inline CVector3::CVector3(const CVector3& vect)	//Copy constructor
{
	m_v[X] = vect[X];
	m_v[Y] = vect[Y];
	m_v[Z] = vect[Z];
}

inline CVector3::~CVector3(){};						//Nothing special needed in destructor

/**************************************************************************************************
OVERLOADED OPERATORS
**************************************************************************************************/
inline CVector3& CVector3::operator = (const CVector3& vect)	//Assignment of another Vector
{
	m_v[X] = vect[X];
	m_v[Y] = vect[Y];
	m_v[Z] = vect[Z];

	return *this;
}
inline FIXED CVector3::operator [] (int index) const
{
	return m_v[index];
}
inline CVector3& CVector3::operator += (const CVector3& vect)	// += operator
{
	m_v[X] += vect[X];
	m_v[Y] += vect[Y];
	m_v[Z] += vect[Z];

	return *this;
}
inline CVector3& CVector3::operator -= (const CVector3& vect) // -= operator
{
	m_v[X] -= vect[X];
	m_v[Y] -= vect[Y];
	m_v[Z] -= vect[Z];

	return *this;
}
inline CVector3& CVector3::operator *= (FIXED t)			// *= operator
{
	m_v[X] = (t * m_v[X])>>8; //bitshift right becase :8 * :8
	m_v[Y] = (t * m_v[Y])>>8; //"
	m_v[Z] = (t * m_v[Z])>>8; //"

	return *this;
}
inline CVector3& CVector3::operator /= (FIXED t)			// *= operator
{
	m_v[X] = (m_v[X]/t)<<8;	//bitshift left becase :8 / :8
	m_v[Y] = (m_v[Y]/t)<<8; //"
	m_v[Z] = (m_v[Z]/t)<<8; //"

	return *this;
}


inline CVector3 operator >> (const CVector3& vect, unsigned int shift)		// Bitwise shift right operator
{
	CVector3 out;

	out.setIndex(X, vect.getIndex(X) >> shift);
	out.setIndex(Y, vect.getIndex(Y) >> shift);
	out.setIndex(Z, vect.getIndex(Z) >> shift);

	return out;
}
inline CVector3 operator << (const CVector3& vect, unsigned int shift)		// Bitwise shift left operator
{
	CVector3 out;

	out.setIndex(X, vect.getIndex(X) << shift);
	out.setIndex(Y, vect.getIndex(Y) << shift);
	out.setIndex(Z, vect.getIndex(Z) << shift);

	return out;
}

inline CVector3 operator+(const CVector3& v1, const CVector3& v2)
{
	CVector3 vect(v1);
	return vect += v2;
}
inline CVector3 operator-(const CVector3& v1, const CVector3& v2)
{
	CVector3 vect(v1);
	return vect -= v2;
}
inline CVector3 operator*(FIXED t, const CVector3& v)
{
	CVector3 vect(v);
	return vect *= t;
}
inline CVector3 operator*(const CVector3& v, FIXED t)
{
	CVector3 vect(v);
	return vect *= t;
}
inline CVector3 operator/(const CVector3& v, FIXED t)
{
	CVector3 vect(v);
	return vect /= t;
}

/**************************************************************************************************
ACCESSORS
**************************************************************************************************/
inline FIXED CVector3::dotProduct(const CVector3 &vect)
{
	return ( ( m_v[X]*vect.m_v[X]) + (m_v[Y]*vect.m_v[Y]) + (m_v[Z]*vect.m_v[Z]) )>>8;
}
inline CVector3 CVector3::crossProduct(const CVector3 &vect)
{
	FIXED a, b, c;

	a = ( (m_v[Y]*vect[Z]) - (vect[Y]*m_v[Z]) )>>8;
	b = -( (m_v[X]*vect[Z]) - (vect[X]*m_v[Z]) )>>8;
	c = ( (m_v[X]*vect[Y]) - (vect[X]*m_v[Y]) )>>8;

	return CVector3(
		a,
		b,
		c
	);
}
#endif // !defined(_PG_VECTOR)
