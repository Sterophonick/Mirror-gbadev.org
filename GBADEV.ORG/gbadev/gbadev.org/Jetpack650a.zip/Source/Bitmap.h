// Bitmap.h: interface for the CBitmap class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_BITMAP_H)
#define AFX_BITMAP_H

#include "gba.h"

//Globals
extern u16* gBuffer;

class CBitmap  
{
public:
	CBitmap(const u16* pData, const u16* pPal, u16 w, u16 h);
	virtual ~CBitmap();

	void displayToScreen(void);
	void copyInPalette(void);
private:
	const u16* m_pData;
	const u16* m_pPal;
	u16 m_width;
	u16 m_height;
};

#endif // !defined(AFX_BITMAP_H__90B69BAE_0189_489A_8BA5_F2556C7CF52D__INCLUDED_)
