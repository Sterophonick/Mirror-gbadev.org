//**************************************************************************************************
//
// map.h
//
// Description: Header file for all the map information defined in map.c
//
// Created by: Pete Gunter 01/03/2004
//
//**************************************************************************************************

#include "gba.h"


extern const u16 bmpHUDTiles[];
extern const u16 palFlash[6];
