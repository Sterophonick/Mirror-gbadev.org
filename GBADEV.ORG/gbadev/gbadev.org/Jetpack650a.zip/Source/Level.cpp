// Level.cpp: implementation of the CLevel class.
//
//////////////////////////////////////////////////////////////////////

#include "Level.h"

extern u16 gpalCopper[160];
extern FIXED gGravity;

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

CLevel::CLevel()
{
	m_ppalBackground = NULL;
	m_pbmpMapTiles =  NULL;
	m_pmapFloor =  NULL;
	m_pmapSky = NULL;
	m_ppalCopper =  NULL;
	m_gravity = 0;
}
CLevel::CLevel(	const u16* ppalBackground, const u16* pbmpMapTiles,	const u8* pmapFloor,
					const u8* pmapSky, const u16* ppalCopper, FIXED gravity)
{
	m_ppalBackground = ppalBackground;
	m_pbmpMapTiles = pbmpMapTiles;
	m_pmapFloor = pmapFloor;
	m_pmapSky = pmapSky;
	m_ppalCopper = ppalCopper;
	m_gravity = gravity;
}

CLevel::~CLevel()
{

}


/*void CLevel::initialise(	u16* ppalBackground, u16* pbmpMapTiles,	u8* pmapFloor,
					u8* pmapSky, u16* ppalCopper, FIXED gravity)
{
	m_ppalBackground = ppalBackground;
	m_pbmpMapTiles = pbmpMapTiles;
	m_pmapFloor = pmapFloor;
	m_pmapSky = pmapSky;
	m_ppalCopper = ppalCopper;
	m_gravity = gravity;
}*/


//Loads the map information into memory which includes:
//  Load level palletes (map and copper bar)
//	Level Tile Data (Char base block(0))
//	Bg 1 (Text) map data,  Sky (Screen Base Block(30))
//	Bg 2 (Rotation) map data, Floor (Screen Base Block(31))
//	Gravity, fixed :16 into gGrav;
// 
void CLevel::loadLvlIntoMemory(void)
{
	/* Force screen to go blank and disable interupts, making transfer
	invisible, and possibly speeding up VRAM (according to Cowbite) */
	REG_IME = 0;
	REG_DISPCNT |= FORCE_BLANK;



	/* Load in the palette data */
	u8 p;
	//Load in background pallete
//	DMA_Copy(3,(u16*)m_ppalBackground,(u16*)BGPaletteMem,128,DMA_32NOW);
	for(p=0; p<128; p++)
		((u32*)BGPaletteMem)[p] = ((u32*)m_ppalBackground)[p];

	//Load in the copper bar pallete
//	DMA_Copy(3,(u16*)m_ppalCopper,(u16*)gpalCopper,80,DMA_32NOW);
	for(p=0; p<80; p++)
		((u32*)gpalCopper)[p]=((u32*)m_ppalCopper)[p];

	/* Load in the tile data */
	//Level tiles
	//There are 256 tiles, each represented by 64 bytes.
	//DMA_Copy(3,(void*)m_pbmpMapTiles,(void*)CharBaseBlock(0),4096,DMA_32NOW);
	u16 t;
	for(t=0; t<4096*2; t++)
		((u16*)CharBaseBlock(0))[t]=((u16*)m_pbmpMapTiles)[t];


	/* Load in the text background data */
	//Temporary pointers to map data
	u16* bg1map =(u16*)ScreenBaseBlock(30);

	u8 x=0,y=0; //iterating vars
	for(y = 0; y < 32; y++) //loop through all 32x32 tiles
	{
		for(x = 0; x < 32; x++)
		{
			//*** BG 1 Sky
			//First tile (Hiword)
			bg1map[x + y*32] = m_pmapSky[x + y*32];
		}
	}

	/* Load in the rotation background data */
	//Temporary pointer to map data
	u16* bg2map =(u16*)ScreenBaseBlock(31);
	for(y = 0; y < 32; y++) //loop through all 32x32 tiles
	{
		for(x = 0; x < 16; x++)
		{
			//*** BG 2 Floor
			//First tile (Hiword)
			bg2map[x + (y*16)] = (u16) (
				((u8)m_pmapFloor[(x*2) + y*32])
			//Next tile (Loword)
				+((u8)m_pmapFloor[(x*2)+1 + y*32]<<8)
			);
		}
	}	


	gGravity = m_gravity;

	/* Display the screen again now we're finished */
	REG_DISPCNT &= ~FORCE_BLANK;
	REG_IME = 1;
}


