
//Fixed point math defines
#define int2fix(A) (A<<8)
#define fixmul(A,B) ( (A*B)>>8 )
#define fixdiv(A,B) ( (A*intReciprocal[B])>>16 )

//Integer reciprocal table in 16:16
extern const int intReciprocal[256];

//Trigonometry defines
#define fixsin16(A) sintable[(A)&2047]
#define fixcos16(A) sintable[((A)+512)&2047]
#define fixsin(A) (fixsin16(A>>8))
#define fixcos(A) (fixcos16(A>>8))

extern const int sintable[2048];

