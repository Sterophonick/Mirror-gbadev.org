This demo was created as my final year project for BSc Interactive Computer
Entertainment at Teeside University. I wanted to release the source code to
help other people learn GBA development because so many people helped me in
it's creation.

Feel free to do whatever you like with the code, but it'd be nice if you
dropped me a line (reno@theonering.net) to let me know what you're using it
for.

Special thanks to everyone over at www.gbadev.org.


Demo Controls:
	* Up/Down: Tile jets forward/back
	* Left/Right: Turn left/right
	* A: Thrust
	* L: Jump to level 1
	* R: Jump to level 2

Demo features:
	* "Mode 7" 3D graphics
	* Drawing text to a text layer
	* Rudimentary physics engine
	* Using the hblank interrupts to produce a copper bar effect

The compiled binary file "Jetpack.bin" is found in this directory.

The folder Project\Jetpack contains the complete source for the project.
The folder Project\Graphics contains all the graphics files used for the maps, 
screens and sprites in the project (each in tehre respective folders).

The report submitted with the project discusses how I developed this demo,
and also summarises most of the research I performed towards it. The full
document can be found at http://tbhl.theonering.net/petegunter/downloads/report.doc

Pete Gunter (Reno)
reno@theonering.net
http://tbhl.theonering.net/petegunter