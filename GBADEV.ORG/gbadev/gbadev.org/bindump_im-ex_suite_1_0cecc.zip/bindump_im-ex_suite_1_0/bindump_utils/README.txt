A suite of utilities that manipulate Bindump resource files.

Okay, only one tool. Guys help me out! If you write a tool that manipulates the
Bindump resources for your project, then send it to me! I'll have it in this
package in no time!

Credit to contributors... None yet... :-\

For info on individual tools, please see their individual README files.

LICENSE
All files in this package are part of the "Bindump TileMax Import/Export Suite"
Copyright (C) 2003 Alex Markley

The "Bindump TileMax Import/Export Suite" is free software; you can redistribute
it and/or modify it under the terms of the GNU General Public License as published
by the Free Software Foundation; either version 2 of the License, or (at your
option) any later version.

Foobar is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY;
without even the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR
PURPOSE. See the GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with Foobar; if not, write to the Free Software
Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA

(Your copy of the GNU GPL is availible in the file LICENSE, which came with this
package.)

