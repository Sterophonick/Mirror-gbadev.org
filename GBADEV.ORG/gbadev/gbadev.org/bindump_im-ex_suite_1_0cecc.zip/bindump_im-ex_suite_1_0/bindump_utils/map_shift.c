/*
 * map_shift.c - Takes a bindump map file, and shifts the entire map by specified coordinates.
 */
/*
This program is free software; you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation; either version 2 of the License, or
(at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
*/

#include <stdio.h>
#include <stdlib.h>

unsigned short *map, *map_src; //Here is the map pointer.

int max_x = 0; //The maximum X coord of the initialized map.
int max_y = 0; //The maximum Y coord of the initialized map.

int shift_x = 0; //The coordinate shift in X.
int shift_y = 0; //The coordinate shift in Y.

FILE *in = NULL, *out = NULL;

//Compute a map index, taking shift into account.
int map_seek(int x, int y)
{
int tx, ty; //The temp x and y.

tx = x + shift_x; //Shift.
if(tx > max_x) tx = tx - (max_x + 1); //wraparound up.
if(tx < 0) tx = tx + (max_x + 1); //wraparound down.

ty = y + shift_y; //Shift.
if(ty > max_y) ty = ty - (max_y + 1); //wraparound up.
if(ty < 0) ty = ty + (max_y + 1); //wraparound down.

return (tx + (ty * (max_x + 1))); //Return the computed map index.
}

//Allocate the map memory, and read in the buffer.
int init(void)
{
int loop;
int tint;
unsigned char a, b;

if((map = (unsigned short *)calloc(sizeof(unsigned short), ((max_x + 1) * (max_y + 1)))) == NULL)
	{
	fprintf(stderr, "Error! Not enough memory!\n");
	return 1;
	}
if((map_src = (unsigned short *)calloc(sizeof(unsigned short), ((max_x + 1) * (max_y + 1)))) == NULL)
	{
	fprintf(stderr, "Error! Not enough memory!\n");
	return 1;
	}

for(loop = 0;loop < ((max_x + 1) * (max_y + 1));loop++)
	{
	tint = fgetc(in); //Lets grab a byte of data...
	if(tint == EOF) //Uh oh, the user lied about the dimensions of the input map.
		{
		fprintf(stderr, "Error! Ran out of data in the input file! File is NOT %dx%d!\n", max_x+1, max_y+1);
		return 1;
		}
	a = (unsigned char)tint;

	tint = fgetc(in); //Lets grab a byte of data...
	if(tint == EOF) //Uh oh, the user lied about the dimensions of the input map.
		{
		fprintf(stderr, "Error! Ran out of data in the input file! File is NOT %dx%d!\n", max_x+1, max_y+1);
		return 1;
		}
	b = (unsigned char)tint;
	
	map_src[loop] = (((a << 8) & 0xFF00) | (b & 0xFF)); //Assemble the entry...
	}

return 0;
}

int main(int argc, char **argv)
{
int x, y, loop, t;
unsigned char a, b;

printf("Bindump Map Shifter\n");
printf("\n");
printf("Copyright (C) 2003 Alex Markley\n");
printf("\n");
printf("This program is free software; you can redistribute it and/or\n");
printf("modify it under the terms of the GNU General Public License\n");
printf("as published by the Free Software Foundation; either version 2\n");
printf("of the License, or (at your option) any later version.\n");
printf("\n");
printf("This program is distributed in the hope that it will be useful,\n");
printf("but WITHOUT ANY WARRANTY; without even the implied warranty of\n");
printf("MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the\n");
printf("GNU General Public License for more details.\n");
printf("\n");
printf("You should have received a copy of the GNU General Public License\n");
printf("along with this program; if not, write to the Free Software\n");
printf("Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.\n");
printf("\n");

if(argc < 7) //Must assume that the user is stupid.
	{
	printf("USAGE:\n      %s MAP_INFILE MAP_X MAP_Y SHIFT_X SHIFT_Y MAP_OUTFILE\n\nIf it's not clear, sorry, try the utility README, or, worst case, try the source code.\n  --Alex\n", argv[0]);
	return 1;
	}

if((in = fopen(argv[1], "rb")) == NULL)
	{
	fprintf(stderr, "Error! Failed to open %s for reading.\n", argv[1]);
	return 1;
	}
t = sscanf(argv[2], "%d", &max_x); max_x = max_x - 1; //Grab the arg, and offset it.
if(t != 1)
	{
	fprintf(stderr, "Error! Map X needs to be a number! \"%s\" is NOT a number.\n", argv[2]);
	return 1;
	}
if(max_x <= 0)
	{
	fprintf(stderr, "Error! Map X needs to be greater then 1, was set to %d!\n", max_x + 1);
	return 1;
	}
t = sscanf(argv[3], "%d", &max_y); max_y = max_y - 1; //Grab the arg, and offset it.
if(t != 1)
	{
	fprintf(stderr, "Error! Map Y needs to be a number! \"%s\" is NOT a number.\n", argv[3]);
	return 1;
	}
if(max_y <= 0)
	{
	fprintf(stderr, "Error! Map Y needs to be greater then 1, was set to %d!\n", max_y + 1);
	return 1;
	}
t = sscanf(argv[4], "%d", &shift_x); //Grab the arg.
if(t != 1)
	{
	fprintf(stderr, "Error! Shift X needs to be a number! \"%s\" is NOT a number.\n", argv[4]);
	return 1;
	}
if(shift_x < (max_x * (-1)) || shift_x > max_x)
	{
	fprintf(stderr, "Error! Shift X is out of bounds! Must be smaller then Map X. (Map X: %d, Shift X: %d)\n", max_x + 1, shift_x);
	return 1;
	}
t = sscanf(argv[5], "%d", &shift_y); //Grab the arg.
if(t != 1)
	{
	fprintf(stderr, "Error! Shift Y needs to be a number! \"%s\" is NOT a number.\n", argv[5]);
	return 1;
	}
if(shift_y < (max_y * (-1)) || shift_y > max_y)
	{
	fprintf(stderr, "Error! Shift Y is out of bounds! Must be smaller then Map Y. (Map Y: %d, Shift Y: %d)\n", max_y + 1, shift_y);
	return 1;
	}
if((out = fopen(argv[6], "wb")) == NULL)
	{
	fprintf(stderr, "Error! Failed to open %s for writing.\n", argv[6]);
	return 1;
	}

printf("Input Map:   %s\n", argv[1]);
printf("Output Map:  %s\n", argv[6]);
printf("Map X:       %d\n", max_x+1);
printf("Map Y:       %d\n", max_y+1);
printf("Moving in X: %d\n", shift_x);
printf("Moving in Y: %d\n", shift_y);
printf("Working...\n");

if(init())
	{
	fprintf(stderr, "There was an error during map initialization...\n");
	return 1;
	}

for(y = 0;y <= max_y;y++)
	for(x = 0;x <= max_x;x++)
		{
		map[(x + (y * (max_x + 1)))] = map_src[map_seek(x, y)]; //Populate the new, shifted map.
		}

for(loop = 0;loop < ((max_x + 1) * (max_y + 1));loop++)
	{
	a = ((map[loop] >> 8) & 0xFF); //Isolate one byte.
	b = (map[loop] & 0xFF); //Isolate one byte.
	
	fprintf(out, "%c%c", a, b); //Dump the map cell...
	}

fclose(in);
fclose(out);

printf("All done!\n");
return 0;
}

