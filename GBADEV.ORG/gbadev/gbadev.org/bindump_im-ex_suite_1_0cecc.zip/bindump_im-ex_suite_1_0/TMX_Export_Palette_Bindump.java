/*
This, and all other files in this package are part of the "Bindump TileMax Import/Export Suite"
Copyright (C) 2003 Alex Markley

The "Bindump TileMax Import/Export Suite" is free software; you can redistribute
it and/or modify it under the terms of the GNU General Public License as published
by the Free Software Foundation; either version 2 of the License, or (at your
option) any later version.

Foobar is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY;
without even the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR
PURPOSE. See the GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with Foobar; if not, write to the Free Software
Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA

(Your copy of the GNU GPL is availible in the file LICENSE, which came with this
package.)
*/

import ca.seanreid.project.tilemax.model.*;

import java.io.*;
import java.util.*;
import java.awt.*;
import javax.swing.*;
import java.awt.event.*;

public class TMX_Export_Palette_Bindump extends TMX_Export implements ActionListener
	{
	public String getName()         {return "Bindump Palette Exporter";}
	public String getVersion()      {return "1.0";}
	public String getAuthor()       {return "Alex Markley (CoolMan)";}
	public String getEmail()        {return "alex@milent.com";}
	public String getDescription()
		{
		return ""
		+ "This will Export a Palette to a binary stream.\n"
		+ "\n"
		+ "Shamelessly hacked from Sean's palette importer. ;)\n"
		+ "\n"
		+ "Notes: Please keep track of the number of colors and\n"
		+ "the bit size of the palette that you export, so that\n"
		+ "the exported palette may be imported later.\n"
		+ "\n"
		+ "**WARNING** This exporter will not function correctly\n"
		+ "if the total bits per palette entry are more then 16.\n"
		+ "((bit_size * 3) > 16)\n"
		+ "\n"
		+ "Linux owns you!!! Mhu-hahahaha!\n"
		;
		}
	
	JDialog dialog;
	ca.seanreid.project.tilemax.model.Palette palette = null;

	public void exportData(TileMaxModel model, String filename, PorterDialog parent)
		{
		if(palette == null)
			{
			parent.setResultMessage("You haven't selected the source palette!\nPlease choose the \"Configure\" button.", "Select a Palette", JOptionPane.ERROR_MESSAGE);
			}
		else
			{
			int palWidth = palette.getGridWidth();;
			int x = 0;
			int y = 0;
			int palent;
			byte a, b;
			
			try
				{
				File file = new File(filename);
				FileOutputStream out = new FileOutputStream(file);
				
				parent.startProgressDialog(1, palWidth);
				
				for(x = 0;x < palWidth;x++)
					{
					palent = palette.getEntry(x, 0);
					
					b = (byte)(palent & 0xFF); //Get another byte.
					palent = (palent >> 8);
					a = (byte)(palent & 0xFF); //Get a byte.
					
					out.write(a);
					out.write(b);
					
					parent.incProgress();
					}
				
				parent.endProgressDialog();
				parent.setResultMessage("The Palette was exported successfully.", "Export Successful", JOptionPane.INFORMATION_MESSAGE);
				
				out.close();
				}
			catch(Exception e)
				{
				parent.setResultMessage(e);
				}
			}
		}

	public void configure(TileMaxModel model, String filename, PorterDialog parent)
		{
		Vector Items = new Vector();
		Enumeration objs = model.getPalettes();
		while(objs.hasMoreElements())
			{
			ca.seanreid.project.tilemax.model.Palette object = (ca.seanreid.project.tilemax.model.Palette) objs.nextElement();
			Items.addElement(object.getGridName());
			}
		
		if(Items.size() == 0)
			{
			JOptionPane.showMessageDialog(parent, "There are no palettes to export.\nPlease create a palette so that you can export it.", "No Palettes", JOptionPane.ERROR_MESSAGE);
			}
		else
			{
			dialog = new JDialog(parent, "Configure Palette Exporter", true);
			
			JLabel label;
			
			GridBagLayout layout = new GridBagLayout();
			GridBagConstraints c = new GridBagConstraints();
			dialog.getContentPane().setLayout(layout);
			
			c.fill = GridBagConstraints.BOTH;
			c.insets = new Insets(4, 4, 4, 4);
			c.weightx = 0;
			c.weighty = 1;
			c.gridwidth = 1;
			
			label = new JLabel("Export From:");
			layout.setConstraints(label, c);
			dialog.getContentPane().add(label);
			
			c.gridwidth = GridBagConstraints.REMAINDER;
			
			JComboBox optionsComboBox = new JComboBox(Items);
			layout.setConstraints(optionsComboBox, c);
			dialog.getContentPane().add(optionsComboBox);
			
			c.weightx = 1;
			
			JButton selectButton = new JButton("Finish Configuration");
			selectButton.addActionListener(this);
			layout.setConstraints(selectButton, c);
			dialog.getContentPane().add(selectButton);
			
			dialog.pack();
			dialog.setSize(new Dimension(300, (int) dialog.getSize().getHeight()));
			parent.centerDialog(dialog);
			dialog.show();
			
			palette = (ca.seanreid.project.tilemax.model.Palette) model.findGridData((String) optionsComboBox.getSelectedItem());
			
			dialog = null;
			}
		}
	
	public void actionPerformed(ActionEvent event)
		{
		if(dialog != null)
			dialog.dispose();
		}
	}
