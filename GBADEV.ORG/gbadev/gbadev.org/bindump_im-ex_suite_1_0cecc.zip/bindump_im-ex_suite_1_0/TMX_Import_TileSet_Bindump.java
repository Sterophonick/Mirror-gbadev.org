/*
This, and all other files in this package are part of the "Bindump TileMax Import/Export Suite"
Copyright (C) 2003 Alex Markley

The "Bindump TileMax Import/Export Suite" is free software; you can redistribute
it and/or modify it under the terms of the GNU General Public License as published
by the Free Software Foundation; either version 2 of the License, or (at your
option) any later version.

Foobar is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY;
without even the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR
PURPOSE. See the GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with Foobar; if not, write to the Free Software
Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA

(Your copy of the GNU GPL is availible in the file LICENSE, which came with this
package.)
*/

import ca.seanreid.project.tilemax.model.*;

import java.io.*;
import java.util.*;
import java.awt.*;
import javax.swing.*;
import java.awt.event.*;

public class TMX_Import_TileSet_Bindump extends TMX_Import implements ActionListener
	{
	public String getName()         {return "Bindump TileSet Importer";}
	public String getVersion()      {return "1.0";}
	public String getAuthor()       {return "Alex Markley (CoolMan)";}
	public String getEmail()        {return "alex@milent.com";}
	public String getDescription()
		{
		return ""
		+ "This will import a tileset from a binary stream.\n"
		+ "\n"
		+ "Shamelessly hacked from Sean's palette importer. ;)\n"
		+ "\n"
		+ "Notes: Please be aware that this importer will assume\n"
		+ "that the height and width of the stream is the same as\n"
		+ "the height and width of the destination tileset. Improper\n"
		+ "use will cause clipping and/or shifting.\n"
		+ "\n"
		+ "Linux owns you!!! Mhu-hahahaha!\n"
		;
		}
	
	JDialog dialog;
	ca.seanreid.project.tilemax.model.TileSet tileset = null;

	public void importData(TileMaxModel model, String filename, PorterDialog parent)
		{
		if(tileset == null)
			{
			parent.setResultMessage("You haven't selected the destination tileset!\nPlease choose the \"Configure\" button.", "Select a TileSet", JOptionPane.ERROR_MESSAGE);
			}
		else
			{
			int a;
			int b;
			int tilesWidth = tileset.getGridWidth();
			int tilesHeight = tileset.getGridHeight();
			int x = 0;
			int y = 0;
			
			int streamok = 1;
			
			try
				{
				File file = new File(filename);
				FileInputStream in = new FileInputStream(file);
				
				parent.startProgressDialog(1, (tilesHeight * tilesWidth * 2));
				
				for(y = 0;y < tilesHeight;y++)
					{
					for(x = 0;x < tilesWidth;x++)
						{
						tileset.setEntry(x, y, 0); //Try zeroing out the array.
						parent.incProgress();
						}
					}
				
				//Now we will loop through the selected map, replacing each cell with a cell as read from the binary stream.
				for(y = 0;y < tilesHeight;y++)
					{
					for(x = 0;x < tilesWidth;x++)
						{
						if(streamok == 1)
							{
							b = in.read();
							if(b == (-1)) //Is the file over?
								{
								streamok = 0; //Not ok anymore...
								}
							else
								{
								a = (b & 0xFF);
								tileset.setEntry(x, y, a); //(Is this the way we're supposed to do this?! I have no idea of the definition of the model.)
								}
							}
						parent.incProgress();
						}
					}
				
				parent.endProgressDialog();
				parent.setResultMessage("The tileset was imported successfully.", "Import Successful", JOptionPane.INFORMATION_MESSAGE);
				
				in.close();
				}
			catch(Exception e)
				{
				parent.setResultMessage(e);
				}
			}
		}

	public void configure(TileMaxModel model, String filename, PorterDialog parent)
		{
		Vector Items = new Vector();
		Enumeration objs = model.getTileSets();
		while(objs.hasMoreElements())
			{
			ca.seanreid.project.tilemax.model.TileSet object = (ca.seanreid.project.tilemax.model.TileSet) objs.nextElement();
			Items.addElement(object.getGridName());
			}
		
		if(Items.size() == 0)
			{
			JOptionPane.showMessageDialog(parent, "There are no tilesets created.\nPlease create a tileset so that you can import data into it.", "No TileSets", JOptionPane.ERROR_MESSAGE);
			}
		else
			{
			dialog = new JDialog(parent, "Configure TileSet Importer", true);
			
			JLabel label;
			
			GridBagLayout layout = new GridBagLayout();
			GridBagConstraints c = new GridBagConstraints();
			dialog.getContentPane().setLayout(layout);
			
			c.fill = GridBagConstraints.BOTH;
			c.insets = new Insets(4, 4, 4, 4);
			c.weightx = 0;
			c.weighty = 1;
			c.gridwidth = 1;
			
			label = new JLabel("Import Into:");
			layout.setConstraints(label, c);
			dialog.getContentPane().add(label);
			
			c.gridwidth = GridBagConstraints.REMAINDER;
			
			JComboBox optionsComboBox = new JComboBox(Items);
			layout.setConstraints(optionsComboBox, c);
			dialog.getContentPane().add(optionsComboBox);
			
			c.weightx = 1;
			
			JButton selectButton = new JButton("Finish Configuration");
			selectButton.addActionListener(this);
			layout.setConstraints(selectButton, c);
			dialog.getContentPane().add(selectButton);
			
			dialog.pack();
			dialog.setSize(new Dimension(300, (int) dialog.getSize().getHeight()));
			parent.centerDialog(dialog);
			dialog.show();
			
			tileset = (ca.seanreid.project.tilemax.model.TileSet) model.findGridData((String) optionsComboBox.getSelectedItem());
			
			dialog = null;
			}
		}
	
	public void actionPerformed(ActionEvent event)
		{
		if(dialog != null)
			dialog.dispose();
		}
	}
