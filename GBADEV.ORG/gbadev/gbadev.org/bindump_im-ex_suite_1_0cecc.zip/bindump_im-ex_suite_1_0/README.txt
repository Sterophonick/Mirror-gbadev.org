Bindump TileMax Import/Export Suite 1.0

***What is it? - A suite of import and export plugins which allows you to import
and export any resource in tilemax. (Palette, TileSet, Map)
***Why is it kewl? - It allows you to manipulate resources in any manner you
desire, simply by exporting to a universal binary format, changing it, (with
another program), and importing it back in. (For instance, you might export all of
the palettes, brighten them, and import them back.) Also, this suite contains the
first public map importer for tilemax.
***Who came up with such an awesome bundle 'o code?! - Alex Markley (AKA: CoolMan)
***Who should I rant at if it doesn't work?! - Not me, thats for sure.

INSTALLING - Just copy all of the '.class' files to your tilemax directory and
enjoy!

BUILDING FROM SOURCE - Well, if you have a nice GNU environment, you could just
type 'make'. Or, if you don't know what a GNU environment is, you can follow the
instructions in the tilemax readme. (Then install the .class files like it says
above.) **NOTE** To compile, you MUST have "tmxmodel.jar" from the tilemax package!

CONTRIBUTION - Make the world better! Uh, or something... Anyway, if you have
a tool that does tiles, or palettes, or etc. Write in support for Bindump file
formats! They are really simple, and if everybody keeps it up, they will be
universal!

UPDATES - The newest version of this package is* availible from
http://opengbgames.sourceforge.net/
*(As of some time in March 2003...)

LICENSE
All files in this package are part of the "Bindump TileMax Import/Export Suite"
Copyright (C) 2003 Alex Markley

The "Bindump TileMax Import/Export Suite" is free software; you can redistribute
it and/or modify it under the terms of the GNU General Public License as published
by the Free Software Foundation; either version 2 of the License, or (at your
option) any later version.

Foobar is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY;
without even the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR
PURPOSE. See the GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with Foobar; if not, write to the Free Software
Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA

(Your copy of the GNU GPL is availible in the file LICENSE, which came with this
package.)

