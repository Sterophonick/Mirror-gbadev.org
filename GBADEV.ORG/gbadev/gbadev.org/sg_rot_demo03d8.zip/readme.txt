Happy Face Rotation and Scaling Demo
Brendan Sechter <sgeos@granicus.if.org>
May 14 ~ 15, 2003

Controls: "Red Mode"
  D-Pad:   Move
  A:       Increase Magnification
  B:       Decrease Magnification
  L:       Rotate Left
  R:       Rotate Right
  Select:  Muck Up Proportions
  Start:   Reset

Controls: "Blue Mode"
  D-Pad:   Move
  A:       Rotate Y Left
  B:       Rotate Y Right
  L:       Rotate X Left
  R:       Rotate X Right
  Select:  (Nothing)
  Start:   Reset

Hold select and press start to change modes.
If the proportions get mucked up when switching from
"blue mode" to "red mode", press start to reset
"red mode" with proper proportions.

In "red mode" try holding A and then pressing B so that
you are holding both at the same time.  Sometimes a
double shakey image will appear.  This also works if B
is held first, but does not always happen.

In "blue mode" apply some funky sheering, and then go
to the upper lefthand corner so that part of the image
is on the screen, and part of it is off the screen.
Then press A + R or B + L to get a pseudo 3D rotation
effect.

Source is included, somewhat commented. "Red mode" uses
SWI 0x0E.  If you want to see an example of calling ASM
from C code, look at the swi_bg_affine_set() function.
"Blue mode", written first, uses fixed point trig.
See fixedtrig.c
