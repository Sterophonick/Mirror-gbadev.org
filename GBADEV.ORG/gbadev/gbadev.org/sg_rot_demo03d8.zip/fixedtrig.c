#ifndef FIXEDTRIG_C
#define FIXEDTRIG_C

/*** Sin Table
 *
 *  Sin table for 0 to 90 degrees.
 *  This is setup for a fixed point system
 *  with an eight bit fractional component.
 */
signed short sin_table[91] =
{
    0,
    4,   9,  13,  18,  22,
   27,  31,  36,  40,  44,
   49,  53,  58,  62,  66,
   71,  75,  79,  83,  88,
   92,  96, 100, 104, 108,
  112, 116, 120, 124, 128,
  132, 136, 139, 143, 147,
  150, 154, 158, 161, 165,
  168, 171, 175, 178, 181,
  184, 187, 190, 193, 196,
  199, 202, 204, 207, 210,
  212, 215, 217, 219, 222,
  224, 226, 228, 230, 232,
  234, 236, 237, 239, 241,
  242, 243, 245, 246, 247,
  248, 249, 250, 251, 252,
  253, 254, 254, 255, 255,
  255, 256, 256, 256, 256
};


/*** fixedtrig_alpha_fixd()
 *
 *  Adjust the angle alpha to a useable value.
 *  The d in fixd is for degrees, as opposed to radians.
 */
int fixedtrig_alpha_fixd(int alpha)
{
  int neg = 0;

  if (alpha < 0)
  {
    neg = 1;
    alpha *= -1;
  }
  alpha %= 360;
  if (neg)
    alpha = 360 - alpha;
  return alpha;
}


/*** sind()
 *
 *  Returns sin(alpha).
 *  This is setup for a fixed point system
 *  with an eight bit fractional component.
 *  The d in sind is for degrees, as opposed to radians.
 */
signed short sind(int alpha)
{
  if (alpha < 0)
    alpha = fixedtrig_alpha_fixd(alpha);
  if (alpha <= 90)
    return sin_table[alpha];
  else if (alpha <= 180)
    return sin_table[180 - alpha];
  else if (alpha <= 270)
    return -1 * sin_table[alpha - 180];
  else if (alpha <= 360)
    return -1 * sin_table[360 - alpha];
  else
    return sind(fixedtrig_alpha_fixd(alpha));
}


/*** cosd()
 *
 *  Returns cos(alpha).
 *  This is setup for a fixed point system
 *  with an eight bit fractional component.
 *  The d in cosd is for degrees, as opposed to radians.
 */
signed short cosd(int alpha)
{
  if (alpha < 0)
    alpha = fixedtrig_alpha_fixd(alpha);
  if (alpha <= 90)
    return sind(90 - alpha);
  else if (alpha <= 360)
    return sind(450 - alpha);
  else
    return cosd(fixedtrig_alpha_fixd(alpha));
}

#endif  /* FIXEDTRIG_C */
