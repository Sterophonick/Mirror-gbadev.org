/*** Compile Options

gcc -Wall -o sg_rot_demo.elf sg_rot_demo.c
objcopy -v -O binary sg_rot_demo.elf sg_rot_demo.bin

 */


/*** included files
 */
#include "fixedtrig.c"


/*** typedefs and structs
 */
typedef signed int     s8;
typedef signed short   s16;
typedef signed long    s32;
typedef unsigned int   u8;
typedef unsigned short u16;
typedef unsigned long  u32;

typedef struct tbgaffinesource
{
  s32 x;   //Original data's center X coordinate (8bit frac portion)
  s32 y;   //Original data's center Y coordinate (8bit frac portion)
  s16 tx;  //Display's center X coordinate
  s16 ty;  //Display's center Y coordinate
  s16 sx;  //Scaling ratio in X direction (8bit fractional portion)
  s16 sy;  //Scaling ratio in Y direction (8bit fractional portion)
  u16 r;   //Angle of rotation (8bit fract portion) Effect Range 0-FFFF
} bgaffinesource;

typedef struct tbgaffinedest
{
  s16 pa;  //Difference in X coordinate along same line
  s16 pb;  //Difference in X coordinate along next line
  s16 pc;  //Difference in Y coordinate along same line
  s16 pd;  //Difference in Y coordinate along next line
  s32 x;   //Start X coordinate
  s32 y;   //Start Y coordinate
} bgaffinedest;


/*** Tile GFX
 */
const unsigned char box_gfx[] =
{
  1, 1, 1, 1, 1, 1, 1, 1,
  1, 2, 1, 1, 1, 1, 2, 3,
  1, 1, 2, 2, 2, 2, 3, 3,
  1, 1, 2, 2, 2, 2, 3, 3,
  1, 1, 2, 2, 2, 2, 3, 3,
  1, 1, 2, 2, 2, 2, 3, 3,
  1, 2, 3, 3, 3, 3, 2, 3,
  3, 3, 3, 3, 3, 3, 3, 3,
};


/*** Happyface BG Map
 */
const unsigned char happy_map[] =
{
  0, 0, 0, 0, 0, 1, 1, 1, 1, 1, 1, 0, 0, 0, 0, 0,
  0, 0, 0, 1, 1, 1, 0, 0, 0, 0, 1, 1, 1, 0, 0, 0,
  0, 0, 1, 1, 0, 0, 0, 0, 0, 0, 0, 0, 1, 1, 0, 0,
  0, 1, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 1, 0,
  0, 1, 0, 0, 1, 1, 1, 0, 0, 1, 1, 1, 0, 0, 1, 0,
  1, 1, 0, 0, 0, 1, 0, 0, 0, 0, 1, 0, 0, 0, 1, 1,
  1, 0, 0, 0, 0, 1, 0, 0, 0, 0, 1, 0, 0, 0, 0, 1,
  1, 0, 0, 0, 1, 1, 1, 0, 0, 1, 1, 1, 0, 0, 0, 1,
  1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1,
  1, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 1,
  1, 1, 0, 1, 1, 0, 0, 0, 0, 0, 0, 1, 1, 0, 1, 1,
  0, 1, 0, 0, 1, 1, 0, 0, 0, 0, 1, 1, 0, 0, 1, 0,
  0, 1, 1, 0, 0, 1, 1, 1, 1, 1, 1, 0, 0, 1, 1, 0,
  0, 0, 1, 1, 0, 0, 0, 0, 0, 0, 0, 0, 1, 1, 0, 0,
  0, 0, 0, 1, 1, 1, 0, 0, 0, 0, 1, 1, 1, 0, 0, 0,
  0, 0, 0, 0, 0, 1, 1, 1, 1, 1, 1, 0, 0, 0, 0, 0,
};


/*** Input related definitions
 *
 *  These could be for any demo.
 */
#define AGB_KEY_MAX    2
#define AGB_KEY_RESET  1
#define INPUT_HOLD(a) \
( \
  (press[(a)] == AGB_KEY_RESET) || \
  (press[(a)] < AGB_KEY_RESET && release[(a)]) \
)
#define AGB_A       0
#define AGB_B       1 
#define AGB_SELECT  2
#define AGB_START   3
#define AGB_RIGHT   4
#define AGB_LEFT    5
#define AGB_UP      6
#define AGB_DOWN    7
#define AGB_R       8
#define AGB_L       9


/*** Function Prototypes
 *
 *  Not every function is prototyped here.
 */
void *rot_input(void);
void *rot_input2(void);
void *rot_init(void);
void *rot_init2(void);
void *main_init(void);


/*** Global Variables
 *
 *  These could be for any demo.
 */
unsigned long seed;
unsigned long press[10];
unsigned long release[10];


/*** Global Variables
 *
 *  These are specific to this demo.
 */
signed long    x_bg;
signed long    y_bg;
signed short   x_angle;
signed short   y_angle;

bgaffinesource src_bga;
bgaffinedest   dest_bga;

void *(*mode_ptr)(void) = rot_init2;


/*** dice()
 *
 *  RNG
 */
int dice(int min, int max)
{
  seed *= 69069;
  return min + ((max - min + 1) * (seed >> (4 * sizeof(int)))) /
    (0x1 << (4 * sizeof(int)));
}


/*** key_zero()
 *
 *  Keypad input related function.
 *  Zero the data in the press[] and release[] arrays.
 */
void key_zero(void)
{
  int ctr;

  for (ctr = 0; ctr < 10; ctr++)
  {
    press[ctr] = 0;
    release[ctr] = 0;
  }
}


/*** key_refresh()
 *
 *  Keypad input related function.
 *  Update the data in the press[] and release[] arrays.
 */
void key_refresh(void)
{
  int ctr;

  for (ctr = 0; ctr < 10; ctr++)
  {
    if ((*(volatile unsigned short *)0x04000130 >> ctr) & 0x1)
    {
      if (release[ctr])
      {
        press[ctr] = 0;
        release[ctr] = 0;
      }
      if (press[ctr])
        release[ctr] = 1;
    }
    else
    {
      press[ctr]++;
      if (press[ctr] > AGB_KEY_MAX)
        press[ctr] = AGB_KEY_RESET;
    }
  }
}


/*** vblank()
 *
 *  If not already in vblank, stall until vblank.
 */
void vblank(void)
{
  while (*(volatile unsigned short *)0x04000006 < 160);
}


/*** vsync()
 *
 *  Stall until the start of vblank.
 */
void vsync(void)
{
  while (*(volatile unsigned short *)0x04000006 != 160);
}


/*** swi_bg_affine_set()
 *
 *  This is a good example of using a bios function in C code.
 *  SWI 0x0E is not documented here.
 */
void swi_bg_affine_set(void *src, void *dest)
{
  asm volatile ("mov r0,%0\nmov r1,%1\nmov r2,#1\nswi 0x0E0000\n" :
  /* No output */ :
  "r" (src), "r" (dest) :
  "r0", "r1", "r2", "memory");
}


/*** rot_disp()
 *
 *  Display function for "blue" mode.
 */
void *rot_disp(void)
{
  vsync();
  *(unsigned long *) 0x04000028 = x_bg;
  *(unsigned long *) 0x0400002C = y_bg;

  *(unsigned short *)0x04000020 = cosd(x_angle);
  *(unsigned short *)0x04000022 = sind(y_angle);
  *(unsigned short *)0x04000024 = sind(x_angle);;
  *(unsigned short *)0x04000026 = cosd(y_angle);
  return rot_input;
}


/*** rot_disp2()
 *
 *  Display function for "red" mode.
 */
void *rot_disp2(void)
{
  swi_bg_affine_set(&src_bga, &dest_bga);
  vsync();
  *(unsigned long *) 0x04000028 = dest_bga.x;
  *(unsigned long *) 0x0400002C = dest_bga.y;

  *(unsigned short *)0x04000020 = dest_bga.pa;
  *(unsigned short *)0x04000022 = dest_bga.pb;
  *(unsigned short *)0x04000024 = dest_bga.pc;
  *(unsigned short *)0x04000026 = dest_bga.pd;
  return rot_input2;
}


/*** rot_input()
 *
 *  Input function for "blue" mode.
 */
void *rot_input(void)
{
  key_refresh();
  if (INPUT_HOLD(AGB_A))
    y_angle++;
  if (INPUT_HOLD(AGB_B))
    y_angle--;
  if (INPUT_HOLD(AGB_L))
    x_angle++;
  if (INPUT_HOLD(AGB_R))
    x_angle--;
  if (INPUT_HOLD(AGB_UP))
    y_bg += 256;
  if (INPUT_HOLD(AGB_DOWN))
    y_bg -= 256;
  if (INPUT_HOLD(AGB_LEFT))
    x_bg += 256;
  if (INPUT_HOLD(AGB_RIGHT))
    x_bg -= 256;
  if (release[AGB_START])
  {
    if (press[AGB_SELECT])
      mode_ptr = rot_init2;
    return mode_ptr;
  }
  return rot_disp;
}


/*** rot_input2()
 *
 *  Input function for "red" mode.
 */
void *rot_input2(void)
{
  key_refresh();
  if (INPUT_HOLD(AGB_A))
  {
    src_bga.sx -= 0x10;
    src_bga.sy -= 0x10;
  }
  if (INPUT_HOLD(AGB_B))
  {
    src_bga.sx += 0x10;
    src_bga.sy += 0x10;
  }
  if (INPUT_HOLD(AGB_L))
    src_bga.r += 0x100;
  if (INPUT_HOLD(AGB_R))
    src_bga.r -= 0x100;
  if (INPUT_HOLD(AGB_UP))
    src_bga.ty--;
  if (INPUT_HOLD(AGB_DOWN))
    src_bga.ty++;
  if (INPUT_HOLD(AGB_LEFT))
    src_bga.tx--;
  if (INPUT_HOLD(AGB_RIGHT))
    src_bga.tx++;
  if (release[AGB_SELECT])
  {
    src_bga.sx += dice(-4, 4) * 0x10;
    src_bga.sy += dice(-4, 4) * 0x10;
  }
  if (release[AGB_START])
  {
    if (press[AGB_SELECT])
      mode_ptr = rot_init;
    return mode_ptr;
  }
  return rot_disp2;
}


/*** rot_init()
 *
 *  Initialization function for "blue" mode.
 */
void *rot_init(void)
{
  key_zero();
  seed *= 69069;
  seed += 0xFDB97531;

  x_bg  = -56 * 256;
  y_bg  = -16 * 256;
  x_angle = 0;
  y_angle = 0;

  vsync();
  *(unsigned short *)0x05000002 = 0x4E10;
  *(unsigned short *)0x05000004 = 0x4C00;
  *(unsigned short *)0x05000006 = 0x4000;
  *(unsigned short *)0x04000000 = 0x0401;
  return rot_disp;
}


/*** rot_init2()
 *
 *  Initialization function for "red" mode.
 */
void *rot_init2(void)
{
  key_zero();
  seed *= 69069;
  seed += 0xFDB97531;

  src_bga.x  =    64 * 256;
  src_bga.y  =    64 * 256;
  src_bga.tx =   120;
  src_bga.ty =    80;
  src_bga.sx = 0x100;
  src_bga.sy = 0x100;
  src_bga.r  = 0;

  vsync();
  *(unsigned short *)0x05000002 = 0x421F;
  *(unsigned short *)0x05000004 = 0x001F;
  *(unsigned short *)0x05000006 = 0x0010;
  *(unsigned short *)0x04000000 = 0x0401;
  return rot_disp2;
}


/*** main_init()
 *
 *  Main program initialization function.
 */
void *main_init(void)
{
  int ctr;

  *(unsigned short *)0x04000000 = 0x0080;
  *(unsigned short *)0x0400000C = 0x000C;
  for (ctr = 0; ctr < 32; ctr++)
    *(unsigned short *)(0x0600C040 + 2 * ctr) =
      box_gfx[2 * ctr] | (box_gfx[2 * ctr + 1] << 8);
  for (ctr = 0; ctr < 128; ctr++)
    *(unsigned short *)(0x06000000 + 2 * ctr) =
      happy_map[2 * ctr] | (happy_map[2 * ctr + 1] << 8);
  return mode_ptr;
}


/*** main()
 *
 *  fptr is a function pointer.
 *  Call the function pointed to by fptr,
 *  and set fptr to the return value.
 *  Repeat.
 *  The functions called by main return the
 *  address of the next funtion to be called.
 *  If the addres of an init function is returned,
 *  then something is reinitialized.
 *  This is usually some version of a software reset.
 */
int main(void)
{
  void *(*fptr)(void) = main_init;
  while ((fptr = fptr()));
  return (0);
}
