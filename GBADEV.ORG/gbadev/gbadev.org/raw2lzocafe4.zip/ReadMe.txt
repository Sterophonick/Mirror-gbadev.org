raw2lzoc
========

Version 1.01 - Monday, July 16, 2001

http://www.gbacode.net

Introduction
============

raw2lzoc is a command line utility that compresses raw data and a small code
library (for inclusion in your GameBoy Advance project) that can decompress
the output. Output can be in raw format or a C style header file.

Questions about raw2lzoc should be directed to <darren@gbacode.net> or in
the forums available at http://forums.gbacode.net

Distribution
============

This distribution contains two parts, one is the command line utility that
creates compressed data and the other is three C source files that need to be
added to your GameBoy Advance project to include the decompression
functionality.

The latest distribution will always be available at http://www.gbacode.net

Command Line Utility
====================

The command line utility has the following usage:
    raw2lzoc infile outfile [-v] [-w n] [-s n] [-c] [-t type] [-b]

The options have the following meaning:
    -v       verbose
    -w n     width, number of entries of data array per line, default = 8
    -s n     size, size in bytes of each entry, must be 1, 2 or 4, default = 1
    -c       C types, use standard C types instead of common GBA types
    -t type  type, type of data array, default depends on the following:
                 -s 1 => u8;   with -c => unsigned char
                 -s 2 => u16;  with -c => unsigned short int
                 -s 4 => u32;  with -c => unsigned int
    -b       binary, write compressed data out to a binary file

Library
=======

To use the decompression functions then add the files found in the source
directory (lzoconf.h, minilzo.h and minilzo.c) to your project.
Add a #include "minilzo.h" to your code and then use the following
function to decompress data:

    int lzo1x_decompress(const unsigned char *src,
                         unsigned int         src_len,
                         const unsigned char *dst,
                         unsigned int         dst_len)

The parameters are pretty self explanatory; src and dst are the source and
destination data pointers respectively and src_len and dst_len are the
lengths of the data areas pointed to.
The function returns the value LZO_E_OK if decompression was successful.

Currently, the decompress function cannot be used to decompress to VRAM
as it does not to 16 bit aligned writes. A version is forthcoming that
will get around this limitation.

Notes
=====

The library has not been optimized for the GameBoy Advance yet, expect an
ARM code version in the future.
Compiled with GCC 2.9, the .o file for the library was less than 14K.

Changes
=======

1.01 (July 16, 2001)
  * Fixed bug in C style output for 16 and 32 bit data types

Warranty
========

This tool is provided for free but without warranty of any kind.

Copyright
=========

Please see the individual copyright notice in Readme.LZO.

Darren Sillett <darren@gbacode.net>
