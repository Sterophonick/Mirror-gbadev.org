////////////////////////////////////////////////////////////////////
//
// Final Year Project Implementation Build Directory Readme File
// Author: Brian Davis
// Date: 16/03/2005
//
////////////////////////////////////////////////////////////////////

Platformer Demo Instructions:

The gameplay for this demo is based on Nintendo's Super Mario Bros. 3. The goal of the game is to safely reach the end of the level. Along the way, you will encounter enemies to evade, coins to pickup, and obsticles to jump over. To destroy an enemy you have to land directly on top of its head. To complete the level, you need to jump and hit the end-of-the-level box (Make sure you get those bonus points!).

User Input:

The user input description (below) is separated into columns to show the functionality mapped to the default keys in the VisualBoyAdvance emulator and the Game Boy Advance (GBA) hardware buttons.

Emulator 	GBA	Functionality

Down arrow	Down	Duck.
Left arrow	Left	Move Left.
Right arrow	Right	Move Right.
Enter		Start	Start/Pause Game.
Z		A	Jump.
X		B	Run (hold button + direction).
