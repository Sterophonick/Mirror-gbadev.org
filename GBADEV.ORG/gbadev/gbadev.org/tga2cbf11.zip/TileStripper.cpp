/****************************************************************************
    tga2c - a graphics conversion program for tile based systems
    Copyright (C) 2002  Richard T. Weeks

    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program; if not, write to the Free Software
    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
****************************************************************************/

#include <fstream>
#include <iomanip>
#include <cctype>
#include "TileStripper.h"
#include "TargaReader.h"


static CReportRecord sg_ReportMessages[] = {
  {rlInfo, "Convert OK"},
  {rlAppFatal, "No input files specified"},
  {rlAppFatal, "Unknown option"},
  {rlFileFatal, "Invalid image format"},
};

static const char* sg_LevelMessages[] = {
  "Info",
  "Notice",
  "Warning",
  "Error",
  "Error",
  "Fatal Error"
};

///////////////////
// CTileStripper //
///////////////////

CCmdLineFlag* CTileStripper::GetFlag(const char* pszName)
{
  if (!pszName)
    return &m_InputFiles;

  switch (pszName[0]) {
  case '-': 
    CheckFlagEnd(pszName, 1);
    return NULL;
  case 'i': 
    CheckFlagEnd(pszName, 1);
    return &m_InputFiles;
  case 'o': 
    CheckFlagEnd(pszName, 1);
    return &m_OutputFiles;
  case 'n': 
    CheckFlagEnd(pszName, 1);
    return &m_VarNames;
  case 'w': 
    CheckFlagEnd(pszName, 1);
    return &m_nWidth;
  case 'h': 
    CheckFlagEnd(pszName, 1);
    return &m_nHeight;
  case 'd': 
    return GetDefinitionFlag(pszName);
  case 'm':
    return GetMapFlag(pszName);
  case '@':
    return &m_CmdFileFlag;
  default: 
    Report(asBadOption, pszName); 
    return NULL;
  }
}

void CTileStripper::ProcessCommandLine(int argc, const char* const* argv)
{
  m_pszProgram = argv[0];
  try {
    ReadArguments(argc, argv);
  } catch (ExArgException e) {
    Report(asBadOption, e.what());
  }
}

void CTileStripper::Report(EAppState state, string Message)
{
  if (state != asGood && state > m_state)
    m_state = state;

  CReportRecord* pRecord = sg_ReportMessages + state;
  if (pRecord->level >= rlWarning) {
    clog << sg_LevelMessages[pRecord->level];
    if (state >= 0)
      clog << " C" << state;
    else
      clog << " W" << -state;
    clog << ": " << pRecord->message;
    if (Message[0] != 0)
      clog << ": " << Message;
    clog << endl;
  }

  switch (pRecord->level) {
  case rlFileFatal:
    throw ExFileFatalException(pRecord->message);
  case rlAppFatal:
    throw ExAppFatalException(pRecord->message);
  }
}

void CTileStripper::Strip()
{
  if (m_InputFiles.Count() < 1) {
    ShowUsage();
    return;
  }

  try {
    for (int nCurrentFile = 0; nCurrentFile < m_InputFiles.Count(); ++nCurrentFile) {
      string OutputFileName, VarBaseName;

      if (nCurrentFile < m_OutputFiles.Count()) {
        OutputFileName = m_OutputFiles[nCurrentFile];
      } else {
        OutputFileName = m_InputFiles[nCurrentFile];
        ChangeExtension(OutputFileName, "c");
      }

      if (nCurrentFile < m_VarNames.Count()) {
        VarBaseName = m_VarNames[nCurrentFile];
      } else {
        VarBaseName = ExtractFileBase(m_InputFiles[nCurrentFile]);
        MakeIdentifier(VarBaseName, false);
      }

      try {
        StripFile(m_InputFiles[nCurrentFile].c_str(), 
          OutputFileName.c_str(), VarBaseName.c_str());
      } catch (ExFileFatalException) {
        clog << "Skipping " << m_InputFiles[nCurrentFile] << '.' << endl;
      }
    }
  } catch (ExAppFatalException) {
    clog << "Terminating." << endl;
  }
}

void CTileStripper::StripFile(const char* pszIn, const char* pszOut, const char* pszName)
{
  ifstream in(pszIn, ios_base::binary);

  // Load the Targa file
  CTargaReader Tga;
  Tga.Load(in);
  if (!Tga.IsValid())
    Report(asInvalidImage, Tga.GetError());

  CTileOrganizer Organizer;
  CMappedImage Image(m_nWidth, m_nHeight);

  Organizer.Organize(Image, Tga, m_Flags[fCollectTiles]);

  // Open output file
  ofstream output(pszOut);

  // Print out the color table
  OutputPalette(output, Tga, pszName);

  // Print out the bitmap
  OutputTiles(output, Image, pszName);

  // Print out the tile map
  OutputTileMap(output, Image, pszName);

  // Output the tileset descriptor definition
  OutputDescriptor(output, Image, pszName);
}

CCmdLineFlag* CTileStripper::Switch(CFlags::reference r, const char* pFlag, int pos)
{
  switch (pFlag[pos]) {
  case '+':
    CheckFlagEnd(pFlag, pos + 1);
  case 0:
    r = true;
    break;
  case '-':
    CheckFlagEnd(pFlag, pos + 1);
    r = false;
    break;
  default:
    Report(asBadOption, pFlag);
  }

  return NULL;
}

void CTileStripper::CheckFlagEnd(const char *pFlag, int pos)
{
  if (pFlag[pos])
    Report(asBadOption, pFlag);
}

void CTileStripper::OutputPalette(ostream &output, CTargaReader &Tga, const char* pszName)
{
  if (!m_Flags[fDefinePalette])
    return;

  if (m_Flags[fDefineDescriptor])
    output << "static ";
  
  output << "const unsigned short ";
  
  if (m_Flags[fDefineDescriptor])
    output << "pal";
  else
    output << "pal_" << pszName;
  
  output << "[] = {" << endl;

  int i = 0;
  while (i < 256) {
    output << "  ";

    do {
      output << "0x" 
        << hex << setw(4) << setfill('0') << Tga.ColorTable()[i] 
        << ", ";
      i++;
    } while (i & 7);

    output << endl;
  }

  output << "};" << endl;
}

void CTileStripper::OutputDescriptor(ostream &output, CMappedImage& Image, const char* pszName)
{
  output.width(0);
  output.setf(ios_base::dec);

  if (!m_Flags[fDefineDescriptor])
    return;

  output << "typedef const struct" << endl << "{" << endl
    << "  const unsigned short *palette;" << endl
    << "  const unsigned char  *tiles;" << endl
    << "  const unsigned long  n_tiles;" << endl
    << "  union {" << endl
    << "    void *ptr;" << endl
    << "    const unsigned char *bytes;" << endl
    << "    const unsigned short *hwords;" << endl
    << "    const unsigned long *words;" << endl
    << "  } map;" << endl
    << "  const unsigned short map_tiles_x, map_tiles_y;" << endl
    << "} TILESET_DESCRIPTOR;" << endl;

  output << "TILESET_DESCRIPTOR tileset_" << pszName << " = {";

  if (m_Flags[fDefinePalette])
    output << "pal, ";
  else
    output << "0, ";

  if (m_Flags[fDefineTiles])
    output << "tiles, "
      << Image.TileSet().TileCount();
  else
    output << "0, 0";

  output << ", ";

  if (m_Flags[fDefineMap])
    output << "{map}, " << Image.MapWidth() << ", " << Image.MapHeight();
  else
    output << "{0}, 0, 0";

  output << "};" << endl;
}

CCmdLineFlag* CTileStripper::GetDefinitionFlag(const char *pszName)
{
  switch (pszName[1]) {
  case 't': return Switch(m_Flags[fDefineTiles], pszName, 2);
  case 'p': return Switch(m_Flags[fDefinePalette], pszName, 2);
  case 'd': return Switch(m_Flags[fDefineDescriptor], pszName, 2);
  case 'm': return Switch(m_Flags[fDefineMap], pszName, 2);
  default:
    Report(asBadOption, pszName);
    return NULL;
  }
}

CTileStripper::CTileStripper()
: m_CmdFileFlag(this)
{
  m_state = asGood;
  m_nWidth = 8;
  m_nHeight = 8;
  m_nMapBits = 16;
}

void CTileStripper::OutputTiles(ostream &output, CMappedImage &image, const char* pszName)
{
  if (!m_Flags[fDefineTiles])
    return;

  if (m_Flags[fDefineDescriptor])
    output << "static ";

  output << "const unsigned char ";

  if (m_Flags[fDefineDescriptor])
    output << "tiles";
  else
    output << "tiles_" << pszName;

  output << "[] = {" << endl;

  const CTileSet& TileSet = image.TileSet();

  output.fill('0');

  int i = 0;

  for (int Tile = 0; Tile < TileSet.TileCount(); Tile++)
  {
    for (int y = 0; y < TileSet.TileHeight(); y++)
    {
      for (int x = 0; x < TileSet.TileWidth(); x++)
      {
        if (!(i & 7))
          output << "  ";

        output 
          << "0x" 
          << setw(2) << hex << (int)TileSet.GetPixel(Tile, x, y) 
          << ", ";

        i++;

        if (!(i & 7))
          output << endl;
      }
    }
  }

  output << "};" << endl;
}

void CTileStripper::OutputTileMap(ostream &output, CMappedImage &Image, const char* pszName)
{
  if (!m_Flags[fDefineMap])
    return;

  if (m_Flags[fDefineDescriptor])
    output << "static ";

  output << "const unsigned " << GetMapElementType();

  if (m_Flags[fDefineDescriptor])
    output << " map";
  else
    output << " map_" << pszName;

  output << " [] = {" << endl;

  output.fill('0');

  int i = 0;

  for (int y = 0; y < Image.MapHeight(); y++)
  {
    for (int x = 0; x < Image.MapWidth(); x++)
    {
      if (!(i & 7))
        output << "  ";

      output << "0x" << setw(4) << hex << Image.GetMapEntry(y, x) << ", ";

      i++;
      if (!(i & 7))
        output << endl;
    }
  }

  output << "};" << endl;
}

CCmdLineFlag* CTileStripper::GetMapFlag(const char *pszName)
{
  switch (pszName[1])
  {
  case 'b': return &m_nMapBits;
  case 'u': return Switch(m_Flags[fCollectTiles], pszName, 2);
  default:
    Report(asBadOption, pszName);
    return NULL;
  }
}

const char* CTileStripper::GetMapElementType()
{
  if (m_nMapBits <= 8)
    return "char";
  if (m_nMapBits <= 16)
    return "short";
  return "long";
}

void CTileStripper::ShowUsage()
{
  cout 
    << "Usage:" << endl
    << "  " << m_pszProgram << " file1 [file2 ...] [Options]" << endl
    << endl
    << "Options:" << endl
    << "  -i          Input files follow" << endl
    << "  -o          Output files follow" << endl
    << "  -n          Variable base names follow" << endl
    << "  -w width    Tile width (default 8)" << endl
    << "  -h height   Tile height (default 8)" << endl
    << "  -dp[+|-]    Define palette" << endl
    << "  -dt[+|-]    Define tiles" << endl
    << "  -dd[+|-]    Define descriptor" << endl 
    << "  -dm[+|-]    Define map" << endl
    << "  -mu[+|-]    Collect identical tiles" << endl
    << "  -mb bits    Set map entry size (8, 16, or 32) (default 16)" << endl
    << "  -@ cmdfile  Read options from cmdfile" << endl
    << endl
    << "Specify at least one input file.  One output file and one" << endl
    << "variable base name may be specified for each input file." << endl
    << "If an output file name is not provided, the output file name" << endl
    << "will be the input file name with the extension changed to .c." << endl
    << "If a variable base name is not provided, the base name of the" << endl
    << "input file will be used." << endl;
}

void CTileStripper::ChangeExtension(string &FileName, const char *pExt)
{
  int ExtIndex = FileName.find_last_of(".\\/");

  if (ExtIndex != string::npos && FileName[ExtIndex] == '.') {
    FileName.replace(FileName.begin() + ExtIndex + 1, FileName.end(), pExt);
  } else {
    FileName.append(1, '.');
    FileName.append(pExt);
  }
}

string CTileStripper::ExtractFileBase(string FileName)
{
  int ExtIndex;
  
  ExtIndex = FileName.find_last_of(".\\/");
  if (ExtIndex != string::npos && FileName[ExtIndex] == '.') {
    FileName.erase(FileName.begin() + ExtIndex, FileName.end());
  }

  ExtIndex = FileName.find_last_of("\\/");
  if (ExtIndex != string::npos) {
    FileName.erase(0, ExtIndex + 1);
  }

  return FileName;
}

void CTileStripper::MakeIdentifier(string &Str, bool Check0)
{
  if (Str.size() == 0)
    return;

  if (Check0 && isdigit(Str[0]))
    Str.insert(0, "_");
  for (int i = 0; i < Str.size(); ++i) {
    if (Str[i] == ' ') 
      Str[i] = '_';
    else if (!isalnum(Str[i]) && Str[i] != '_') {
      Str.erase(i, 1);
      i--;
    }
  }
}
