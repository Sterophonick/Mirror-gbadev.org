/****************************************************************************
    tga2c - a graphics conversion program for tile based systems
    Copyright (C) 2002  Richard T. Weeks

    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program; if not, write to the Free Software
    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
****************************************************************************/

#pragma warning(disable: 4786)

#include <vector>
#include <fstream>
#include "CmdLineFlags.h"

class CArgFetcher
{
public:
  virtual string GetNextArg() = 0;
  virtual bool Done() = 0;
};

class CCmdLineArgFetcher : public CArgFetcher
{
  int m_argc;
  const char* const * m_argv;
public:
  CCmdLineArgFetcher(int argc, const char* const* argv, int start = 1)
    : m_argc(argc-start), m_argv(argv+start) {}
  virtual string GetNextArg()
    {--m_argc; return *(m_argv++);}
  virtual bool Done()
    {return m_argc <= 0;}
};

void CCmdLineApp::ReadArguments(int argc, const char* const * argv)
{
  CCmdLineArgFetcher Fetcher(argc,argv);
  ProcessArgs(Fetcher);
}

class CCmdStreamParser
{
  enum ECharType
  {
    ctComment,
    ctQuote,
    ctWhite,
    ctNewline,
    ctOther
  };

  enum EState
  {
    csLineStart,
    csArgument,
    csWhite,
    csQuoted,
    csComment,
    csError
  };

  enum EAction
  {
    aNone = 0,
    aApp = 1,
    aEmit = 2,
    aScan = 4
  };

  static const EState Transitions[][csError];
  static const int Actions[][csError];
  EState m_eState;
  ECharType CharType(char c);
public:
  CCmdStreamParser()
    : m_eState(csLineStart) {}
  string GetArgument(istream& in);
};

const CCmdStreamParser::EState CCmdStreamParser::Transitions[][csError] = {
  {csComment,   csError,     csComment,   csQuoted, csComment},
  {csQuoted,    csError,     csQuoted,    csWhite,  csComment},
  {csLineStart, csWhite,     csWhite,     csQuoted, csComment},
  {csLineStart, csLineStart, csLineStart, csError,  csLineStart},
  {csArgument,  csArgument,  csArgument,  csQuoted, csComment}
};

const int CCmdStreamParser::Actions[][csError] = {
  {aScan,      aNone,       aScan,      aApp+aScan,  aScan},
  {aScan,      aNone,       aScan,      aEmit+aScan, aScan},
  {aScan,      aEmit+aScan, aScan,      aApp+aScan,  aScan},
  {aScan,      aEmit+aScan, aScan,      aNone,       aScan},
  {aApp+aScan, aApp+aScan,  aApp+aScan, aApp+aScan,  aScan}
};

class CCmdStreamArgFetcher : public CArgFetcher
{
  istream& m_in;
  CCmdStreamParser m_Parser;
public:
  CCmdStreamArgFetcher(istream& in)
    : m_in(in) {}
  virtual string GetNextArg()
    {return m_Parser.GetArgument(m_in);}
  virtual bool Done()
    {return m_in.eof();}
};

void CCmdLineApp::ReadCommandStream(istream &in)
{
  CCmdStreamArgFetcher Fetcher(in);
  ProcessArgs(Fetcher);
}

string CCmdStreamParser::GetArgument(istream& in)
{
  string result;
  char c;
  in.get(c);
  for (; in.good() && m_eState != csError;) {
    ECharType type = CharType(c);
    int actions = Actions[type][m_eState];
    m_eState = Transitions[type][m_eState];
    if (m_eState == csError)
      throw ExArgException("Syntax error in command stream");
    if (actions & aApp)
      result += c;
    if (actions & aEmit) {
      in >> ws;
      return result;
    }
    if (actions & aScan)
      in.get(c);
  }
  return result;
}

CCmdStreamParser::ECharType CCmdStreamParser::CharType(char c)
{
  switch (c) {
  case ' ': case '\t': return ctWhite;
  case '\n': return ctNewline;
  case '#': return ctComment;
  case '"': return ctQuote;
  default: return ctOther;
  }
}

void CCmdLineApp::ProcessArgs(CArgFetcher &Fetcher)
{
  vector<CCmdLineFlag*> FlagStack;
  FlagStack.push_back(GetFlag(NULL));

  while (!Fetcher.Done()) {
    string arg = Fetcher.GetNextArg();
    if (arg[0] == '-') {
      CCmdLineFlag* pNewFlag = NULL;
      switch (FlagStack.back()->OnInterrupt()) {
      case CCmdLineFlag::irDone:
        FlagStack.pop_back();
        // Fall through to irPush
      case CCmdLineFlag::irPush:
        pNewFlag = GetFlag(arg.c_str()+1);
        break;
      case CCmdLineFlag::irMode:
        if (FlagStack.size() > 1) {
          pNewFlag = FlagStack.back();
          FlagStack.clear();
          FlagStack.push_back(pNewFlag);
        }
        pNewFlag = GetFlag(arg.c_str()+1);
        break;
      }
      if (pNewFlag)
        FlagStack.push_back(pNewFlag);
    } else {
      FlagStack.back()->TakeArgument(arg.c_str());
      while (FlagStack.size() > 1 && FlagStack.back()->Done())
        FlagStack.pop_back();
    }
  }
}

void CCmdFileFlag::TakeArgument(const char* Arg)
{
  ifstream in(Arg);
  ReadCommandStream(m_pApp, in);
}
