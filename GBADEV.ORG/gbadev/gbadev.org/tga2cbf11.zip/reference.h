#ifndef REFERENCE_H_77a79ac2_4ece_11d5_a653_00e098088b45
#define REFERENCE_H_77a79ac2_4ece_11d5_a653_00e098088b45

template <class T>
class byval_accessor
{
private:
  T* ptr;
public:
  typedef T& info_type;
  byval_accessor(T& r)
    : ptr(&r) {}
  T get_val() const {return *ptr;}
  void set_val(T val) {*ptr = val;}
};

template <class T>
class byref_accessor
{
private:
  T* ptr;
public:
  typedef T* info_type;
  byref_accessor(T* _ptr)
    : ptr(_ptr) {}
  const T& get_val() const {return *ptr;}
  void set_val(const T& val) {*ptr = val;}
};

template <class T, class Ac>
class reference_base
{
protected:
  Ac a;
public:
  typedef T value_type;
  typedef T& reference;
  typedef const T& const_reference;

  reference_base(Ac::info_type i)
    : a(i) {}
  reference_base<T,Ac>& operator = (const T& val)
    {a.set_val(val); return *this;}
};

template <class S, class T, class Ac>
S& operator >> (S& s, reference_base<T,Ac>& r)
{
  T t;
  s >> t;
  r = t;
  return s;
}

template <class T, class Ac = byval_accessor<T> >
class byval_reference : public reference_base<T,Ac>
{
public:
  typedef byval_reference<T,Ac> _MyT;

  byval_reference(Ac::info_type i)
    : reference_base<T,Ac>(i) {}

  _MyT& operator = (T v)
    {a.set_val(v); return *this;}
  _MyT& operator = (const _MyT& o)
    {a.set_val(o.a.get_val()); return *this;}
  operator T () const
    {return a.get_val();}
};

template <class T, class Ac = byref_accessor<T> >
class byref_reference : public reference_base<T,Ac>
{
public:
  typedef byref_reference<T,Ac> _MyT;

  byref_reference(Ac::info_type i)
    : reference_base<T,Ac>(i) {}

  _MyT& operator = (const T& v)
    {a.set_val(v); return *this;}
  _MyT& operator = (const _MyT& o)
    {a.set_val(o.a.get_val()); return *this;}
  operator const T& () const
    {return a.get_val();}
};

template <class T, class Ac = byval_accessor<T*> >
class ptr_reference : public reference_base<T*,Ac>
{
public:
  typedef ptr_reference<T,Ac> _MyT;
  
  ptr_reference(Ac::info_type i)
    : reference_base<T*,Ac>(i) {}

  _MyT& operator = (T* v)
    {a.set_val(v); return *this;}
  _MyT& operator = (const _MyT& o)
    {a.set_val(o.a.get_val()); return *this;}
  operator T* () const
    {return a.get_val();}

  // dereference
  T* operator -> () const
    {return a.get_val();}
  T& operator * () const
    {return *a.get_val();}
};

#endif // REFERENCE_H_77a79ac2_4ece_11d5_a653_00e098088b45