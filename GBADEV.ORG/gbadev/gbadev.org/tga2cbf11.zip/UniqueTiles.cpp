/****************************************************************************
    tga2c - a graphics conversion program for tile based systems
    Copyright (C) 2002  Richard T. Weeks

    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program; if not, write to the Free Software
    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
****************************************************************************/

#include <map>
#include <cstdlib>
#include <set>
#include <iterator>
#include <vector>
#include "UniqueTiles.h"
#include "TargaReader.h"
#include "mapxtra.h"

using namespace map_extra;

typedef unsigned TileHash;
typedef map<TileHash, vector<int> > CTileTable;
typedef vector<vector<int> > CTileGroups;

TileHash HashTile(const CTileSet& Tiles, int Tile);
bool SameTile(const CTileSet& Tiles, int Tile1, int Tile2);
void RegroupTiles(CTileSet& Tiles, CTileMap& Map);

/////////////////////////////
// CTileOrganizer
/////////////////////////////

CTileOrganizer::CTileOrganizer()
{
  m_nMapWidth = 0;
  m_nMapHeight = 0;
}

void CTileOrganizer::SetMapSize(int Width, int Height)
{
  m_nMapWidth = Width;
  m_nMapHeight = Height;
}

void CTileOrganizer::Organize(CMappedImage& Image, const CTargaReader& Tga, bool CollectUnique)
{
  // Compute the map size if not specified
  if (m_nMapWidth == 0)
    m_nMapWidth = Tga.Width() / Image.TileSet().TileWidth();

  if (m_nMapHeight == 0)
    m_nMapHeight = Tga.Height() / Image.TileSet().TileHeight();

  // Create the map array
  if (Image.m_pMap)
    delete []Image.m_pMap;
  Image.m_pMap = new int[m_nMapHeight * m_nMapWidth];
  Image.m_nMapHeight = m_nMapHeight;
  Image.m_nMapWidth = m_nMapWidth;

  // Make the tile set big enough to hold the whole image
  Image.m_TileSet.SetTileCount(m_nMapWidth * m_nMapHeight);

  int Tile = 0;
  int mx, my;
  const unsigned char* pData;
  CTileTable TileTable;
  CTileMap TileMap;

  TileMap.resize(Image.TileSet().TileCount());

  // pData starts at the beginning of the last (top) line in the TGA image
  pData = Tga.IndexMap() + (Tga.Height() - 1) * Tga.Width();
  
  // Cut each tile from the TGA image
  for (my = 0; my < m_nMapHeight; my++)
  {
    for (mx = 0; mx < m_nMapWidth; mx++)
    {
      CutTile(Image, Tile, Tga, pData + mx * Image.TileSet().TileWidth());
      Image.SetMapEntry(my, mx, Tile);
      TileTable[HashTile(Image.TileSet(), Tile)].push_back(Tile);
      TileMap[Tile] = Tile;
      Tile++;
    }

    pData -= Tga.Width() * Image.TileSet().TileHeight();
  }

  // If we are not to collect the unique tiles (like for a sprite)
  // return now
  if (!CollectUnique)
    return;
 
  // Combine tiles with same image
  CTileTable::iterator tti;
  for (tti = TileTable.begin(); tti != TileTable.end(); tti++)
  {
    vector<int>& List = tti->second;

    for (int i = 0; i < List.size(); i++)
    {
      for (int rj = List.size() - 1; rj > i; rj--)
      {
        if (SameTile(Image.TileSet(), List[i], List[rj]))
        {
          TileMap[List[rj]] = List[i];
          List.erase(List.begin() + rj);
        }
      }
    }
  }

  TileTable.clear();

  // Move all tiles to the beginning of the map
  Image.m_TileSet.RegroupTiles(TileMap);

  // Apply the equivalence map
  for (my = 0; my < Image.MapHeight(); ++my)
  {
    for (mx = 0; mx < Image.MapWidth(); ++mx)
    {
      Image.SetMapEntry(my, mx, TileMap[Image.GetMapEntry(my, mx)]);
    }
  }
}

void CTileOrganizer::CutTile(CMappedImage& Image, int Tile, const CTargaReader& Tga, const unsigned char* pData)
{
  for (int y = 0; y < Image.TileSet().TileHeight(); ++y)
  {
    for (int x = 0; x < Image.TileSet().TileWidth(); ++x)
    {
      Image.m_TileSet.SetPixel(Tile, x, y, pData[x]);
    }

    pData -= Tga.Width();
  }
}

/////////////////////////////
// CMappedImage
/////////////////////////////

CMappedImage::CMappedImage(int TileWidth, int TileHeight)
: m_TileSet(TileWidth, TileHeight)
{
  m_nMapWidth = 0;
  m_nMapHeight = 0;
  m_pMap = NULL;
}

CMappedImage::~CMappedImage()
{
  if (m_pMap)
    delete []m_pMap;
}

int CMappedImage::GetMapEntry(int row, int col) const
{
  return m_pMap[row * m_nMapWidth + col];
}

void CMappedImage::SetMapEntry(int row, int col, int value)
{
  m_pMap[row * m_nMapWidth + col] = value;
}

/////////////////////////////
// CTileSet
/////////////////////////////

CTileSet::CTileSet(int TileWidth, int TileHeight)
{
  m_nTileWidth = TileWidth;
  m_nTileHeight = TileHeight;
  m_pTiles = NULL;
  m_nTileCount = 0;
}

CTileSet::~CTileSet()
{
  if (m_pTiles)
    free(m_pTiles);
}

unsigned char CTileSet::GetPixel(int Tile, int x, int y) const
{
  return m_pTiles[(Tile * m_nTileHeight + y) * m_nTileWidth + x];
}

void CTileSet::SetPixel(int Tile, int x, int y, unsigned char color)
{
  m_pTiles[(Tile * m_nTileHeight + y) * m_nTileWidth + x] = color;
}

void CTileSet::SetTileCount(int Count)
{
  if (Count == 0)
  {
    if (m_pTiles)
      delete []m_pTiles;
    m_nTileCount = 0;
    return;
  }

  if (Count <= m_nTileCount)
  {
    m_nTileCount = Count;
    return;
  }

  if (m_pTiles)
  {
    m_pTiles = (unsigned char*)realloc(m_pTiles, 
      Count * m_nTileHeight * m_nTileWidth * sizeof(unsigned char));
  } else
  {
    m_pTiles = (unsigned char*)malloc(
      Count * m_nTileHeight * m_nTileWidth * sizeof(unsigned char));
  }

  m_nTileCount = Count;
}

/////////////////////////////
// functions
/////////////////////////////

TileHash HashTile(const CTileSet& Tiles, int Tile)
{
  unsigned value = 0;

  for (int y = 0; y < Tiles.TileHeight(); ++y)
  {
    for (int x = 0; x < Tiles.TileWidth(); ++x)
    {
      unsigned char Pixel = Tiles.GetPixel(Tile, x, y);
      value = (value << 5) | (value >> 27);
      value = (value ^ Pixel) + Pixel;
    }
  }

  return value;
}

bool SameTile(const CTileSet& Tiles, int Tile1, int Tile2)
{
  for (int y = 0; y < Tiles.TileHeight(); ++y)
  {
    for (int x = 0; x < Tiles.TileWidth(); ++x)
    {
      if (Tiles.GetPixel(Tile1, x, y) != Tiles.GetPixel(Tile2, x, y))
        return false;
    }
  }

  return true;
}

void CTileSet::RegroupTiles(CTileMap& Map)
{
  set<int> Moved;
  int rj = Map.size() - 1;

  for (int i = 0; i < rj; ++i)
  {
    if (Map[i] == i)
      continue;

    // There is a hole at i
    
    // Find something to fill the hole
    while (rj != Map[rj] && rj > i)
      rj--;

    // There might not be anything left to fill the hole with
    if (rj <= i)
      break;

    // Copy the tile to it's new home
    memcpy(m_pTiles + (i * TileSize()), m_pTiles + (rj * TileSize()), 
      TileSize());

    // Change the map so we know where this tile's new home is
    Map[rj] = i;

    // Remember that this tile was moved
    Moved.insert(rj);
  }

  //CTileMap::iterator j;
  int j;
  for (j = rj; j != Map.size(); j++)
  {
    if (Moved.find(Map[j]) != Moved.end())
      Map[j] = Map[Map[j]];
  }
  
  if (rj == Map[rj])
    SetTileCount(rj + 1);
  else
    SetTileCount(rj);
}
