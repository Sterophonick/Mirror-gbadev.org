#ifndef MAP_XTRA_H_09e3b7e2_4f59_11d5_a653_00e098088b45
#define MAP_XTRA_H_09e3b7e2_4f59_11d5_a653_00e098088b45

#include <map>
#include <set>
#include <algorithm>

namespace std {

  template <class _Ty>
  class masque
  {
  private:
    _Ty value;
  public:
    masque()
      {}
    explicit masque(const _Ty& _init)
      : value(_init) {}
    masque<_Ty>& operator = (const _Ty& _value)
      {value = _value; return *this;}
    operator _Ty& ()
      {return value;}
    operator _Ty () const
      {return value;}
  };

  template <class T, T initVal>
  class init : public masque<T>
  {
  public:
    init()
      {T value = initVal; masque<T>::operator = (value);}
    explicit init(T t)
      : masque(t) {}
    init<T,initVal>& operator = (T t)
      {masque<T>::operator = (t); return *this;}
  };

  namespace map_extra {
    template <class _I>
    class first_iterator
    {
      _I i;
      typedef first_iterator _MyT;
    public:
      typedef _I::value_type::first_type value_type;

      explicit first_iterator(_I _i)
        : i(_i) {}
      first_iterator(const _MyT& o)
        : i(o.i) {}
      _MyT& operator = (const _MyT& o)
        {i = o.i; return *this;}

      bool operator == (const _MyT& o) const
        {return i == o.i;}
      bool operator != (const _MyT& o) const
        {return i != o.i;}

      value_type& operator * ()
        {return i->first;}
      value_type* operator -> ()
        {return &(i->first);}

      _MyT& operator ++ ()
        {++i; return *this;}
      _MyT operator ++ (int)
        {return _MyT(i++);}
      _MyT& operator -- ()
        {--i; return *this;}
      _MyT operator -- (int)
        {return _MyT(i--);}

      _I original() const
        {return i;}
    };

    template <class _I>
    class const_first_iterator
    {
      _I i;
      typedef const_first_iterator _MyT;
    public:
      typedef const _I::value_type::first_type value_type;

      explicit const_first_iterator(_I _i)
        : i(_i) {}
      const_first_iterator(const _MyT& o)
        : i(o.i) {}
      _MyT& operator = (const _MyT& o)
        {i = o.i; return *this;}

      bool operator == (const _MyT& o) const
        {return i == o.i;}
      bool operator != (const _MyT& o) const
        {return i != o.i;}

      value_type& operator * ()
        {return i->first;}
      value_type* operator -> ()
        {return &(i->first);}

      _MyT& operator ++ ()
        {++i; return *this;}
      _MyT operator ++ (int)
        {return _MyT(i++);}
      _MyT& operator -- ()
        {--i; return *this;}
      _MyT operator -- (int)
        {return _MyT(i--);}

      _I original() const
        {return i;}
    };

    template <class _I>
    class second_iterator
    {
      _I i;
      typedef second_iterator _MyT;
    public:
      typedef _I::value_type::second_type value_type;

      explicit second_iterator(_I _i)
        : i(_i) {}
      second_iterator(const _MyT& o)
        : i(o.i) {}
      _MyT& operator = (const _MyT& o)
        {i = o.i; return *this;}

      bool operator == (const _MyT& o) const
        {return i == o.i;}
      bool operator != (const _MyT& o) const
        {return i != o.i;}

      value_type& operator * ()
        {return i->second;}
      value_type* operator -> ()
        {return &(i->second);}

      _MyT& operator ++ ()
        {++i; return *this;}
      _MyT operator ++ (int)
        {return _MyT(i++);}
      _MyT& operator -- ()
        {--i; return *this;}
      _MyT operator -- (int)
        {return _MyT(i--);}

      _I original() const
        {return i;}
    };

    template <class _I>
    class const_second_iterator
    {
      _I i;
      typedef const_second_iterator _MyT;
    public:
      typedef const _I::value_type::second_type value_type;

      explicit const_second_iterator(_I _i)
        : i(_i) {}
      const_second_iterator(const _MyT& o)
        : i(o.i) {}
      _MyT& operator = (const _MyT& o)
        {i = o.i; return *this;}

      bool operator == (const _MyT& o) const
        {return i == o.i;}
      bool operator != (const _MyT& o) const
        {return i != o.i;}

      value_type& operator * ()
        {return i->second;}
      value_type* operator -> ()
        {return &(i->second);}

      _MyT& operator ++ ()
        {++i; return *this;}
      _MyT operator ++ (int)
        {return _MyT(i++);}
      _MyT& operator -- ()
        {--i; return *this;}
      _MyT operator -- (int)
        {return _MyT(i--);}

      _I original() const
        {return i;}
    };

    template <class _I>
    first_iterator<_I> first(_I i)
    {return first_iterator<_I>(i);}

    template <class _I>
    const_first_iterator<_I> const_first(_I i)
    {return const_first_iterator<_I>(i);}

    template <class _I>
    second_iterator<_I> second(_I i)
    {return second_iterator<_I>(i);}

    template <class _I>
    const_second_iterator<_I> const_second(_I i)
    {return const_second_iterator<_I>(i);}

    template <class _K, class _Ty, class _Pr1, class _Pr2, class _A1, class _A2>
    void domain(const map<_K,_Ty,_Pr1,_A1>& m, set<_K,_Pr2,_A2>& r)
    {
      r.clear();
      copy(first(m.begin()),first(m.end()),inserter(r,r.end()));
    }

    template <class _K, class _Ty, class _Pr1, class _Pr2, class _A1, class _A2>
    void range(const map<_K,_Ty,_Pr1,_A1>& m, set<_K,_Pr2,_A2>& r)
    {
      r.clear();
      copy(second(m.begin()),second(m.end()),inserter(r,r.end()));
    }

  } // namespace map_extra
} // namespace std

#endif // MAP_XTRA_H_09e3b7e2_4f59_11d5_a653_00e098088b45