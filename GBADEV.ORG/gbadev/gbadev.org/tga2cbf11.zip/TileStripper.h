/****************************************************************************
    tga2c - a graphics conversion program for tile based systems
    Copyright (C) 2002  Richard T. Weeks

    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program; if not, write to the Free Software
    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
****************************************************************************/

#ifndef TILE_STRIPPER_H_bbfe0680_1f45_11d6_a654_00e098088b45
#define TILE_STRIPPER_H_bbfe0680_1f45_11d6_a654_00e098088b45

#include <iostream>
#include <string>
#include <bitset>
#include "CmdLineFlags.h"
#include "UniqueTiles.h"

enum EReportLevel
{
  rlInfo,
  rlNotice,
  rlWarning,
  rlError,
  rlFileFatal,
  rlAppFatal
};

struct CReportRecord
{
  EReportLevel level;
  const char* message;
};

enum EAppState {
  // Warnings
  asUnspecifiedWarning = -5000,

  // The Good state
  asGood = 0, 

  // Errors
  asNoInputFile,
  asBadOption,
  asInvalidImage,
};

class ExTileStripperException : public runtime_error
{
public:
  ExTileStripperException(string sMessage)
    : runtime_error(sMessage) {}
};

class ExFileFatalException : public ExTileStripperException
{
public:
  ExFileFatalException(string sMessage)
    : ExTileStripperException(sMessage) {}
};

class ExAppFatalException : public ExTileStripperException
{
public:
  ExAppFatalException(string sMessage)
    : ExTileStripperException(sMessage) {}
};

class CTileStripper : public CCmdLineApp
{
public:
  enum EFlags {
    fDefinePalette,
    fDefineTiles,
    fDefineDescriptor,
    fDefineMap,
    fCollectTiles,
    fFlagCount // last flag
  };
  typedef bitset<fFlagCount> CFlags;
private:
	static void MakeIdentifier(string& Str, bool Check0);
	static string ExtractFileBase(string FileName);
	static void ChangeExtension(string& FileName, const char* pExt);
	CCmdLineFlag* GetMapFlag(const char* pszName);
	void OutputTileMap(ostream& output, CMappedImage& Image, const char* pszName);
	void OutputTiles(ostream &output, CMappedImage& image, const char* pszName);
	EAppState m_state;
	void OutputDescriptor(ostream& output, CMappedImage& Image, const char* pszName);
	CCmdLineFlag* GetDefinitionFlag(const char* pszName);
	void OutputPalette(ostream& out, CTargaReader& Tga, const char* pszName);
	void CheckFlagEnd(const char* pFlag, int pos);
  CFlags m_Flags;
  CValueFlag<int> m_nWidth, m_nHeight, m_nMapBits;
  CModeFlag m_InputFiles, m_OutputFiles, m_VarNames;
  CCmdFileFlag m_CmdFileFlag;
  const char* m_pszProgram;

  void Report(EAppState state, string Message = "");
  void StripFile(const char* pszIn, const char* pszOut, const char* pszName);
  CCmdLineFlag* Switch(CFlags::reference r, const char* pFlag, int pos);
protected:
	const char* GetMapElementType();
  virtual CCmdLineFlag* GetFlag(const char* pszName);
public:
	void ShowUsage();
	int GetInputFileCount()
    {return m_InputFiles.Count();}
	CTileStripper();
  void ProcessCommandLine(int argc, const char* const* argv);
  void Strip();
  EAppState GetState()
    {return m_state;}
};



#endif // TILE_STRIPPER_H_bbfe0680_1f45_11d6_a654_00e098088b45