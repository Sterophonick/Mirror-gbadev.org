/****************************************************************************
    tga2c - a graphics conversion program for tile based systems
    Copyright (C) 2002  Richard T. Weeks

    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program; if not, write to the Free Software
    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
****************************************************************************/

#ifndef TARGA_H_448c9520_0d35_11d6_a654_00e098088b45
#define TARGA_H_448c9520_0d35_11d6_a654_00e098088b45

#include <istream>
#include <string>
#include <memory.h>

using namespace std;

class CTargaReader;

class CTargaColorTable
{
  friend CTargaReader;
private:
  unsigned short m_nStartOffset, m_nLength;
  unsigned short m_Table[256];
  void Reset()
    {/*memset(m_Table, 0, sizeof(m_Table));*/}
public:
  CTargaColorTable()
    {Reset();}
  int StartingOffset() const
    {return m_nStartOffset;}
  int EndingOffset() const
    {return m_nStartOffset + m_nLength;}
  int Length() const
    {return m_nLength;}
  unsigned short operator[](int i) const
    {return m_Table[i];}
};

class CTargaReader
{
private:
	static unsigned char Read16BitIndex(istream& in);
	static unsigned char Read8BitIndex(istream& in);
	static unsigned short Read32BitColor(istream& in);
	static unsigned short Read24BitColor(istream& in);
	static unsigned short Read16BitColor(istream& in);
  string m_sErrorMessage;
  unsigned short m_nWidth, m_nHeight;
  CTargaColorTable m_ColorTable;
  unsigned char* m_pIndexMap;
  void Error(string sMessage);
public:
  CTargaReader()
    {m_pIndexMap = NULL;}
  ~CTargaReader();
  void Load(istream& in);
  bool IsValid()
    {return m_sErrorMessage.size() == 0;}
  string GetError()
    {return m_sErrorMessage;}
  int Width() const
    {return m_nWidth;}
  int Height() const
    {return m_nHeight;}
  const CTargaColorTable& ColorTable() const
    {return m_ColorTable;}
  const unsigned char* IndexMap() const
    {return m_pIndexMap;}
};

#endif // TARGA_H_448c9520_0d35_11d6_a654_00e098088b45