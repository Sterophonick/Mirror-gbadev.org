/****************************************************************************
    tga2c - a graphics conversion program for tile based systems
    Copyright (C) 2002  Richard T. Weeks

    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program; if not, write to the Free Software
    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
****************************************************************************/

#include "binio"
#include "TargaReader.h"

template <class T>
inline void read_var(istream& in, T& var)
{
  in.read((char*)&var, sizeof(var));
}

void CTargaReader::Load(istream& in)
{
  m_sErrorMessage.resize(0);

  // Read file properties
  unsigned char IDLen, ImageTypeCode;

  in >> binary(IDLen);
  in.seekg(1, ios_base::cur);
  in >> binary(ImageTypeCode);

  if (ImageTypeCode != 1) {
    Error("Not an indexed color image");
    return;
  }

  // Read color map properties
  unsigned char ColorMapEntrySize;
  unsigned short (*ReadColor)(istream&);

  in 
    >> binary(m_ColorTable.m_nStartOffset)
    >> binary(m_ColorTable.m_nLength)
    >> binary(ColorMapEntrySize);

  switch (ColorMapEntrySize) {
  case 16: ReadColor = Read16BitColor; break;
  case 24: ReadColor = Read24BitColor; break;
  case 32: ReadColor = Read32BitColor; break;
  default: Error("Unknown color depth"); return;
  }

  // Read image properties
  unsigned char IndexBits, ImgAtts;
  unsigned char (*ReadIndex)(istream&);

  in.seekg(4, ios_base::cur);
  in 
    >> binary(m_nWidth) 
    >> binary(m_nHeight) 
    >> binary(IndexBits) 
    >> binary(ImgAtts);
  if (IndexBits <= 8) 
    ReadIndex = Read8BitIndex;
  else if (IndexBits <= 16)
    ReadIndex = Read16BitIndex;
  else {
    Error("Unknown index size");
    return;
  }


  // Skip the ID section
  in.seekg(IDLen, ios_base::cur);

  int i;

  // Read in the color table
  m_ColorTable.Reset();

  for (i = m_ColorTable.m_nStartOffset; i < m_ColorTable.m_nStartOffset + 
    m_ColorTable.m_nLength; ++i)
  {
    m_ColorTable.m_Table[i] = ReadColor(in);
  }

  // Read index map
  if (m_pIndexMap)
    delete []m_pIndexMap;

  m_pIndexMap = new unsigned char[m_nWidth * m_nHeight];

  for (i = 0; i < m_nWidth * m_nHeight; ++i) {
    m_pIndexMap[i] = ReadIndex(in);
  }

  if (!in.good())
    Error("Error reading input file");
}

CTargaReader::~CTargaReader()
{
  if (m_pIndexMap)
    delete []m_pIndexMap;
}

void CTargaReader::Error(string sMessage)
{
  m_sErrorMessage = sMessage;
}

unsigned short CTargaReader::Read16BitColor(istream &in)
{
  unsigned short Color;
  in >> binary(Color);

  return 
    ((Color >> 10) & 0x001f) |
    ((Color)        & 0x03E0) |
    ((Color << 10) & 0x7C00);
}

unsigned short CTargaReader::Read24BitColor(istream &in)
{
  unsigned char red, green, blue;
  in >> binary(blue) >> binary(green) >> binary(red);

  return 
    (red >> 3) |
    ((green << 2) & 0x03E0) |
    ((blue << 7) & 0x7C00);
}

unsigned short CTargaReader::Read32BitColor(istream &in)
{
  unsigned short Color = Read24BitColor(in);
  in.seekg(1, ios_base::cur);
  return Color;
}

unsigned char CTargaReader::Read8BitIndex(istream &in)
{
  unsigned char result;

  in >> binary(result);

  return result;
}

unsigned char CTargaReader::Read16BitIndex(istream &in)
{
  unsigned short result;

  in >> binary(result);

  return (unsigned char)result;
}
