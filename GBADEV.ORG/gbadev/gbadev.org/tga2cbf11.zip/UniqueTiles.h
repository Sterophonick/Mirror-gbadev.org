/****************************************************************************
    tga2c - a graphics conversion program for tile based systems
    Copyright (C) 2002  Richard T. Weeks

    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program; if not, write to the Free Software
    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
****************************************************************************/

#ifndef UNIQUE_TILES_H_dce10b41_1ba8_11d6_a654_00e098088b45
#define UNIQUE_TILES_H_dce10b41_1ba8_11d6_a654_00e098088b45

#include <vector>

using namespace std;

class CTargaReader;
typedef vector<int> CTileMap;

class CTileSet
{
private:
  int m_nTileWidth, m_nTileHeight, m_nTileCount;
  unsigned char* m_pTiles;
public:
  CTileSet(int TileWidth, int TileHeight);
  ~CTileSet();

  int TileWidth() const
    {return m_nTileWidth;}
  int TileHeight() const
    {return m_nTileHeight;}
  int TileSize() const
    {return m_nTileWidth * m_nTileHeight;}
  int TileCount() const
    {return m_nTileCount;}

  unsigned char GetPixel(int Tile, int x, int y) const;
  void SetPixel(int Tile, int x, int y, unsigned char color);
  void SetTileCount(int Count);

  void RegroupTiles(CTileMap& Map);
};

class CMappedImage;

class CTileOrganizer
{
private:
  int m_nMapWidth, m_nMapHeight;

  void CutTile(CMappedImage& Image, int Tile, const CTargaReader& Tga, const unsigned char* pData);
public:
  CTileOrganizer();

  void SetMapSize(int Width, int Height);
  void Organize(CMappedImage& Image, const CTargaReader& Tga, bool CollectUnique);
};

class CMappedImage
{
private:
  CTileSet m_TileSet;
  int* m_pMap;
  int m_nMapWidth, m_nMapHeight;

  friend class CTileOrganizer;
public:
  CMappedImage(int TileWidth, int TileHeight);
  ~CMappedImage();

  int MapWidth() const
    {return m_nMapWidth;}
  int MapHeight() const
    {return m_nMapHeight;}
  const CTileSet& TileSet() const
    {return m_TileSet;}
  int GetMapEntry(int row, int col) const;
  void SetMapEntry(int row, int col, int value);
};

#endif // UNIQUE_TILES_H_dce10b41_1ba8_11d6_a654_00e098088b45
