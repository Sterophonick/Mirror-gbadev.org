/****************************************************************************
    tga2c - a graphics conversion program for tile based systems
    Copyright (C) 2002  Richard T. Weeks

    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program; if not, write to the Free Software
    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
****************************************************************************/

#ifndef CMD_LINE_FLAGS_e4fcf621_4a9a_11d5_a653_00e098088b45
#define CMD_LINE_FLAGS_e4fcf621_4a9a_11d5_a653_00e098088b45

#ifdef _MSC_VER
#pragma once
#endif

#include <stdexcept>
#include <memory>
#include <cstring>
#include <vector>
#include <locale>
#include <strstream>
#include <iostream>
#include "mapxtra.h"
#include "reference.h"

using namespace std;

typedef vector<string> CArgList;

class ExArgException : public runtime_error
{
public:
  ExArgException(string sMessage)
    : runtime_error(sMessage) {}
};

class CCmdLineFlag;
class CArgFetcher;

class CCmdLineApp
{
protected:
	void ProcessArgs(CArgFetcher& Fetcher);
	void ReadCommandStream(istream& in);
  void ReadArguments(int argc, const char* const * argv);
  virtual CCmdLineFlag* GetFlag(const char* arg) = 0;
  friend class CCmdLineFlag;
};

class CCmdLineFlag
{
protected:
  static void ReadCommandStream(CCmdLineApp* pApp, istream& in)
    {pApp->ReadCommandStream(in);}
public:
  enum EInterruptResult {irDone,irPush,irMode};
  virtual void TakeArgument(const char* Arg) = 0;

  // Every flag must take at least one argument.  Switches (no arguments)
  // can be handled in CCmdLineApp::GetFlag, and NULL returned.  Also,
  // after OnInterrupt returns irMode, Done is not called again.
  virtual bool Done() = 0;
  virtual EInterruptResult OnInterrupt() = 0;
};

template <class _Ty>
class CValueFlag : public CCmdLineFlag, public masque<_Ty>
{
public:
  CValueFlag()
    {}
  CValueFlag(const _Ty& _init)
    : masque<_Ty>(_init) {}
  CValueFlag<_Ty>& operator = (const _Ty& _value)
    {masque<_Ty>::operator = (_value); return *this;}
  virtual void TakeArgument(const char* Arg)
    {if ((istrstream(Arg) >> *this).fail()) throw ExArgException(Arg);}
  virtual bool Done()
    {return true;}
  virtual EInterruptResult OnInterrupt()
    {throw ExArgException("Value missing"); return irDone;}
};

class CCustomArgsFlag : public CCmdLineFlag
{
private:
  size_t m_nReqArgs, m_nOptArgs;
  size_t m_nCur;
protected:
  virtual void ProcessArgument(size_t n, const char* Arg) = 0;
public:
  typedef byval_reference<size_t> count_reference;
  count_reference Required()
    {return count_reference(m_nReqArgs);}
  count_reference Optional()
    {return count_reference(m_nOptArgs);}
  CCustomArgsFlag(size_t nReqArgs = 1, size_t nOptArgs = 0) 
    {m_nReqArgs = nReqArgs; m_nOptArgs = nOptArgs; m_nCur = 0;}
  virtual void TakeArgument(const char* Arg) 
    {ProcessArgument(m_nCur++,Arg);}
  virtual bool Done() 
    {return m_nCur >= m_nReqArgs + m_nOptArgs;}
  virtual EInterruptResult OnInterrupt() 
  {
    if (m_nCur < m_nReqArgs)
      throw ExArgException("Required arguments missing");
    return irDone;
  }
};

class CArgsFlag : public CCustomArgsFlag
{
public:
  typedef string CArgument;

  CArgsFlag(size_t nReqArgs = 1, size_t nOptArgs = 0)
    : CCustomArgsFlag(nReqArgs,nOptArgs) {m_Strings.reserve(nReqArgs);}
  bool present()
    {return !m_Strings.empty();}
  size_t count()
    {return m_Strings.size();}
  CArgument operator [] (size_t n)
    {return m_Strings[n];}
protected:
  virtual void ProcessArgument(size_t n, const char* Arg)
  {
    if (n >= m_Strings.size()) 
      m_Strings.resize(n+1); 
    m_Strings[n] = Arg;
  }
private:
  vector<CArgument> m_Strings;  
};

template <class _Ty>
class CListFlag : public CCustomArgsFlag
{
public:
  CListFlag(size_t nReqArgs, size_t nOptArgs)
    : CCustomArgsFlag(nReqArgs,nOptArgs) {m_List.reserve(nReqArgs);}
  bool present()
    {return m_List.empty();}
  size_t count()
    {return m_List.size();}
  _Ty operator [] (size_t n)
    {return m_List[n];}
protected:
  virtual void ProcessArgument(size_t n, const char* Arg)
    {if ((istrstream(Arg) >> m_List[n]).fail()) throw ExArgException(Arg);}
private:
  vector<_Ty> m_List;
};


class CModeFlag : public CCmdLineFlag
{
private:
  CArgList m_Args;
public:
  virtual void TakeArgument(const char* Arg) 
    {m_Args.push_back(Arg);}
  virtual bool Done() 
    {return false;}
  const CArgList& GetArgs() 
    {return m_Args;}
  virtual EInterruptResult OnInterrupt()
    {return irMode;}
  size_t Count()
    {return m_Args.size();}
  CArgList::const_reference operator[](int n) const
    {return m_Args[n];}
};


class CCmdFileFlag : public CCmdLineFlag
{
private:
  CCmdLineApp* m_pApp;
public:
  CCmdFileFlag(CCmdLineApp* pApp)
    : m_pApp(pApp) {}
  virtual void TakeArgument(const char* Arg);
  virtual bool Done()
    {return true;}
  virtual EInterruptResult OnInterrupt()
    {throw ExArgException("Value missing"); return irDone;}
};

#endif // CMD_LINE_FLAGS_e4fcf621_4a9a_11d5_a653_00e098088b45