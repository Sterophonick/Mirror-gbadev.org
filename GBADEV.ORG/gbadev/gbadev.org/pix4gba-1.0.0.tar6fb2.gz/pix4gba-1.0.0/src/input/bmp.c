/******************************************************************************/
/*                      PIX4GBA by Juan Pablo Ugarte                          */
/*      This is a multi format pixmap converter for use in GBA projects       */
/*******************************************************************************
    Copyright (C) 2002-2003  Juan Pablo Ugarte

    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program; if not, write to the Free Software
    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
    
Contacts:
    * gba@xjuan.gq.nu
    * http://xjuan.gq.nu
*******************************************************************************/
#include"input.h"

#define BMP_MAGIC_NUMBER 0x4D42
#define BMP_ERROR "BMP.C: This File is not a bmp\n"
#define BMP_FORMAT_ERROR "BMP.C: BMP suport only for 8 and 24 bpp\n"
#define BMP_HEADER_SIZE 14
#define BMP_HEADER_INFO_SIZE 40

struct bmp_header{
	unsigned short int tipo;
	unsigned int   tam_archivo;
	unsigned short int reservado1;
	unsigned short int reservado2;
	unsigned int   offset;
};
struct bmp_header_info{
	unsigned int   	tam_header;
	int				res_x;
	int				res_y;
	unsigned short int  planos;
	unsigned short int  bpp;
	unsigned int   	tipo_compresion;
	unsigned int   	tam_imagen;
	int				dpi_x;
	int				dpi_y;
	unsigned int   	nro_colores_usados;
	unsigned int   	nro_colores_importantes;
};
/*
BMP_INFO:
*/
int bmp_info(struct bmp_header_info *image)
{
	if(image==NULL) return -1;

	printf( "BMP Header Info:\n"\
		"\tResolution = %dx%d\n"\
		"\tBits per Pixel = %d\n"\
		"\tCompresion = %d\n"\
		"\tAmount of colors = %d\n"\
		,image->res_x,image->res_y,image->bpp,image->tipo_compresion,\
		image->nro_colores_usados);

	return 0;
}
/*
BMP_MEMSWAP:
*/
void bmp_memswap(unsigned char *p1, unsigned char *p2, int size)
{
	void *temp=(void*)malloc(size);

	memcpy((void*)temp,(void*)p1,size);
	memcpy((void*)p1,(void*)p2,size);
	memcpy((void*)p2,(void*)temp,size);

	free(temp);
	return;
}
/*
LOAD_BMP:
*/
int load_bmp(char *file2load,struct imagen *return_value)
{
	FILE *file;
	unsigned char *ram_file;
	int tam_archivo;
	struct bmp_header *imagen_header;
	struct bmp_header_info *imagen_header_info;

	file=fopen(file2load,"r");
	if(file==NULL){
		error(OPENFILE_ERROR);
		fclose(file);
		return -1;
	}
	
	/*LOAD HEADER*/
	if((imagen_header=(struct bmp_header*) malloc(BMP_HEADER_SIZE))==NULL){
		error(MALLOC_ERROR);
		fclose(file);
		return -1;
	}
	fread((void*)imagen_header,1,BMP_HEADER_SIZE,file);
	
	/*CHECK FILE TYPE*/
	if(imagen_header->tipo!=BMP_MAGIC_NUMBER){
		error(BMP_ERROR);
		fclose(file);
		return -1;
	}
	rewind(file);

	/*LOAD ENTIRE FILE TO RAM*/
	tam_archivo=file_size(file2load);
	if((ram_file=(unsigned char *) malloc(tam_archivo))==NULL){
	error(MALLOC_ERROR);
		fclose(file);
		return -1;
	}
	fread((void*)ram_file,1,tam_archivo,file);
	fclose(file);	

	imagen_header_info=(struct bmp_header_info*)(ram_file+BMP_HEADER_SIZE);

	if(input_verbose_flag) bmp_info(imagen_header_info);

	/*CHECK FOR SUPORTED BMP FORMATS*/
	if(imagen_header_info->bpp!=8 && imagen_header_info->bpp!=24 && imagen_header_info->tipo_compresion!=0){
		error(BMP_FORMAT_ERROR);
		return -1;
	}
	/*IF BPP=8*/
	if(imagen_header_info->bpp==8){
		unsigned char *pal_dest,*pal_source,*pix_dest,*pix_source;
		int i;
	
		return_value->pal_data=(void*)malloc(imagen_header_info->nro_colores_usados*3);
		return_value->pix_data=(void*)malloc(imagen_header_info->res_x*imagen_header_info->res_y);
	
		pal_dest=(unsigned char*)return_value->pal_data;
		pal_source=(unsigned char*)(ram_file+BMP_HEADER_SIZE+BMP_HEADER_INFO_SIZE);
	
		for(i=0;i<imagen_header_info->nro_colores_usados;i++){
			memcpy(pal_dest,pal_source,3);
			pal_dest+=3;
			pal_source+=4;		
		}
		/*LOAD && REORDER PIXMAP*/
		pix_dest=(unsigned char*)return_value->pix_data;
		pix_source=(unsigned char*)(ram_file+BMP_HEADER_SIZE+BMP_HEADER_INFO_SIZE+\
			(imagen_header_info->nro_colores_usados*4));
		/*Flip pixmap*/
		{
			int x,y;
			y=imagen_header_info->res_y;
			x=imagen_header_info->res_x;
			for(i=0;i<y/2;i++){
				bmp_memswap(&pix_source[i*x],&pix_source[(y-i-1)*x],x);
			}
		}
		memcpy((void*)pix_dest,(void*)pix_source,(imagen_header_info->res_x*imagen_header_info->res_y));
		/*FILL return_value with specifics 8bpp values*/
		return_value->pal_size=imagen_header_info->nro_colores_usados;
	}
	/*IF BPP=24*/
	if(imagen_header_info->bpp==24){
		unsigned char *pix_dest,*pix_source;
		int i;
	
		return_value->pix_data=(void*)malloc(imagen_header_info->res_x*imagen_header_info->res_y*3);
	
		/*LOAD && REORDER PIXMAP*/
		pix_dest=(unsigned char*)return_value->pix_data;
		pix_source=(unsigned char*)(ram_file+BMP_HEADER_SIZE+BMP_HEADER_INFO_SIZE);
		/*Flip pixmap*/
		{
			int x,y;
			y=imagen_header_info->res_y;
			x=imagen_header_info->res_x*3;
			for(i=0;i<y/2;i++){
				bmp_memswap(&pix_source[i*x],&pix_source[(y-i-1)*x],x);
			}
		}
	
		memcpy((void*)pix_dest,(void*)pix_source,(imagen_header_info->res_x*imagen_header_info->res_y*3));
		/*FILL return_value with specifics 24bpp values*/
		return_value->pal_data=NULL;
		return_value->pal_size=-1;
	}
	
	/*FILL return_value with currents values*/
	return_value->pix_color_space=BGR;/*bmp is also BGR*/
	return_value->pal_color_space=BGR;
	return_value->res_x=imagen_header_info->res_x;
	return_value->res_y=imagen_header_info->res_y;
	return_value->bpp=imagen_header_info->bpp;

	/*FREE RESOURSES*/
	free(imagen_header);
	free(ram_file);
	
	return 0;
}
