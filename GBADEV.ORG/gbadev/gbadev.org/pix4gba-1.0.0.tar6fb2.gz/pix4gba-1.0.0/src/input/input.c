/******************************************************************************/
/*                      PIX4GBA by Juan Pablo Ugarte                          */
/*      This is a multi format pixmap converter for use in GBA projects       */
/*******************************************************************************
    Copyright (C) 2002-2003  Juan Pablo Ugarte

    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program; if not, write to the Free Software
    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
    
Contacts:
    * gba@xjuan.gq.nu
    * http://xjuan.gq.nu
*******************************************************************************/
#include"input.h"
/*
	CHECK_NAME:
		check if the string name could be a variable name.
*/
int check_name(char *name)
{
	int i,c;
	/*Check name: allowed characters are ascii 48-57 65-90 95 97-122*/
	if(name[0]>=48 && name[0]<=57){
		/*The first letter is a number !!!*/
		error(VARIABLE_NAME_ERROR);
		return 1;
	}
	i=strlen(name);
	for(c=1;c<i;c++)
		if((name[c]>=48 && name[c]<=57) || (name[c]>=65 && name[c]<=90) ||
		   (name[c]>=97 && name[c]<=122) || (name[c]==95));
	else{
		error(VARIABLE_NAME_ERROR);
		return 2;
	}
	return 0;
}
/*
LOAD_PIXMAP:
~~~~~~~~~~~
	This function determine the pixmap format, then execute the specific load
	function, and finaly return a pointer to the struct imagen of the pixmap.
*/
struct imagen* load_pixmap(char *file2load)
{
	struct stat the_file;
	char *extension,*realname;
	struct imagen *return_value=(struct imagen*)malloc(sizeof(struct imagen));		

	if(stat(file2load,&the_file)!=0){
		error(STAT_ERROR);
		free(return_value);
		return NULL;
	}
	if(!S_ISREG(the_file.st_mode)){
		error(ISNREG_ERROR);
		free(return_value);
		return NULL;
	}
	get_realname(file2load,&realname,&extension);
	if(extension==NULL){
		error(NO_EXTENSION_ERROR);
		free(return_value);
		return NULL;
	}
	/*Copy the file name to return_value->name*/
	return_value->name=realname;

	if(check_name(return_value->name)!=0){
		free(return_value);
		return NULL;
	}
				
	/*NOW we have the extension, lets run the corresponding function*/
	if(strcmp(extension,"bmp")==0){
		if(load_bmp(file2load,return_value)==0)	return return_value;
	}
	
/*
	IF the program reaches here is because the format is not supported
	It would be nice to use imlib to load unsuported file format or even
	better for all formats but... why do it the easy way if we can do it
	the hard way :)
*/
	error(FORMAT_NOT_SUPPORTED);
	free(return_value);
	return NULL;
}
