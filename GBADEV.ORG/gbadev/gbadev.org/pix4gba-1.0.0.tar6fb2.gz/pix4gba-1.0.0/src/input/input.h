/******************************************************************************/
/*                      PIX4GBA by Juan Pablo Ugarte                          */
/*      This is a multi format pixmap converter for use in GBA projects       */
/*******************************************************************************
    Copyright (C) 2002-2003  Juan Pablo Ugarte

    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program; if not, write to the Free Software
    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
    
Contacts:
    * gba@xjuan.gq.nu
    * http://xjuan.gq.nu
*******************************************************************************/
#ifndef INPUT_H
#define INPUT_H
#include"../common.h"
/*INPUT DECLARATIONS*/
struct imagen* load_pixmap(char *file2load);
int load_bmp(char *file2load,struct imagen *out_put);
#endif
