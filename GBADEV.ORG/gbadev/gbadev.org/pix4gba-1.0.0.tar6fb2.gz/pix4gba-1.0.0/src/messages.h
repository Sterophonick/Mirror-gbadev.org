/******************************************************************************/
/*                      PIX4GBA by Juan Pablo Ugarte                          */
/*      This is a multi format pixmap converter for use in GBA projects       */
/*******************************************************************************
    Copyright (C) 2002-2003  Juan Pablo Ugarte

    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program; if not, write to the Free Software
    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
    
Contacts:
    * gba@xjuan.gq.nu
    * http://xjuan.gq.nu
*******************************************************************************/
#ifndef MESSAGES_H
#define MESSAGES_H

#define PIX4GBA_VERSION "1.0.0"
#define PIX4GBA "PIX4GBA 1.0.0 (C) 2002-2003 Juan Pablo Ugarte"
#define UGARTE_CONTACT "Contacts:\n\t* gba@xjuan.gq.nu\n\t* http://xjuan.gq.nu\n"
#define STAT_ERROR "ERROR: File not found\n"
#define ISNREG_ERROR "ERROR: This is not a regular file\n"
#define NO_EXTENSION_ERROR "ERROR: File name without extension\n"
#define FORMAT_NOT_SUPPORTED "ERROR: File type not supported yet\n"
#define OPENFILE_ERROR "ERROR: Can not open file\n"
#define MALLOC_ERROR "ERROR: Malloc has returned NULL, probably not enought memory\n"
#define VARIABLE_NAME_ERROR "ERROR: Filename is not a valid variable name\n"
#define MAIN_SIGSEGV "\n\t\t\tSomething is wrong!!!\nThe program recieve a SEGV signal and this should not happen.\n"
#define BUG_REPORT "Read manpage before report any bug to webmaster@xjuan.gq.nu\n"

#endif