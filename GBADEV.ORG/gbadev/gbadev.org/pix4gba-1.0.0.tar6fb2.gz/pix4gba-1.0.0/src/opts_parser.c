/******************************************************************************/
/*                      OPTS PARSER by Juan Pablo Ugarte                      */
/*      This is a small library to parse command line options easily          */
/*******************************************************************************
    Copyright (C) 2003  Juan Pablo Ugarte

    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program; if not, write to the Free Software
    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
    
Contacts:
    * gba@xjuan.gq.nu
    * http://xjuan.gq.nu
*******************************************************************************/
#include "opts_parser.h"
int find_arg(char **argv_temp,char *opt1,char *opt2)
{
	int i=0;
    while(argv_temp[i]!=NULL){
		if((strcmp(argv_temp[i],opt1)==0 || strcmp(argv_temp[i],opt2)==0)){
	 	   return i;
		}
		i++;
	}
    return -1;
}
/*
	OPTS_PARSER:
	Return
		0 if everything was ok
		-1 if ARGC and number of arguments expected differs
		other when there was an error in that option (argv[other])
*/
int opts_parser(int argc,char **argv,int nro_opts,struct opts_item options[])
{
	int i,opt_index,nro_arguments=0;
	int *int_temp;
	float *float_temp;
	char **char_temp;
/*	char **endptr;*/
/*
endptr will not be used because strtod and strtol do not work as expected 
in ANSI C and ISO9899 respectivetly (or at least thats whats the man page says)
*/
	for(i=0;i<nro_opts;i++){
		opt_index=find_arg(argv,options[i].opt_long,options[i].opt_short);
		/*Initialize var_set_flag and *var if is a string*/
		options[i].var_set_flag=0;
		if(options[i].var_type==STRING){
			char_temp=(char**)options[i].var;
			*char_temp=NULL;/*just in case you dont check var_set_flag before
			printing or use the string which can cause a SEGV signal*/
		}
		if(opt_index>=0){
			if(options[i].opt_type==FLAG){
				if(options[i].var_type==INTEGER){
					int_temp=(int*)options[i].var;
					*int_temp=!*int_temp;
				}
				else {
					fprintf(stderr,OPTS_PARSER_ERROR_FLAG
							" (%s)\n",argv[opt_index]);
					return opt_index;
				}
				nro_arguments++;
				options[i].var_set_flag=1;
			}
			else
			if(options[i].opt_type==ARGUMENT){
				if(options[i].var_type==INTEGER){
						int_temp=(int*)options[i].var;
						if(argv[opt_index+1]!=NULL)
							*int_temp=(int)strtol(argv[opt_index+1],NULL,10);
						else {
							fprintf(stderr,OPTS_PARSER_ERROR_VAR_TYPE
									" (%s)\n",argv[opt_index]);
							return opt_index;
						}
				}
				else
				if(options[i].var_type==FLOAT){
						float_temp=(float*)options[i].var;
						if(argv[opt_index+1]!=NULL)
							*float_temp=(float)strtod(argv[opt_index+1],NULL);
						else {
							fprintf(stderr,OPTS_PARSER_ERROR_VAR_TYPE
									" (%s)\n",argv[opt_index]);
							return opt_index;
						}
				}
				else
				if(options[i].var_type==STRING){
						char_temp=(char**)options[i].var;
						if(char_temp!=NULL && argv[opt_index+1]!=NULL){
							*char_temp=(char*)malloc(
										strlen(argv[opt_index+1])+1);
							strcpy(*char_temp,argv[opt_index+1]);
						}
						else {
							fprintf(stderr,OPTS_PARSER_ERROR_VAR_TYPE
									" (%s)\n",argv[opt_index]);
							return opt_index;
						}
				}
				else
				if(options[i].var_type==BOOLEAN){
						int_temp=(int*)options[i].var;
						if(argv[opt_index+1]!=NULL){
							if(strcasecmp(argv[opt_index+1],"true")==0)
								*int_temp=1;
							else
							if(strcasecmp(argv[opt_index+1],"false")==0)
								*int_temp=0;
							else {
								fprintf(stderr,OPTS_PARSER_ERROR_VAR_BOOLEAN
									" (%s)\n",argv[opt_index]);
								return opt_index;
							}
						}
						else {
							fprintf(stderr,OPTS_PARSER_ERROR_VAR_TYPE
									" (%s)\n",argv[opt_index]);
							return opt_index;
						}
				}
				else {
					fprintf(stderr,OPTS_PARSER_ERROR_VAR);
					return opt_index;
				}
				nro_arguments+=2;
				options[i].var_set_flag=1;
			}
			else {
				fprintf(stderr,OPTS_PARSER_ERROR_OPT);
				return opt_index;
			}
		}
	}
	if(nro_arguments != (argc-1)){
		fprintf(stderr,OPTS_PARSER_ERROR"ARGC (%d) and number of "
				"arguments expected (%d) differs.\n",argc-1,nro_arguments);
		return -1;
	}
	return 0;
}
