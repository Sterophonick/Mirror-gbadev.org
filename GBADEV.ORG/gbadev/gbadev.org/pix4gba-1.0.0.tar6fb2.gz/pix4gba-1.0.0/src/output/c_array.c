/******************************************************************************/
/*                      PIX4GBA by Juan Pablo Ugarte                          */
/*      This is a multi format pixmap converter for use in GBA projects       */
/*******************************************************************************
    Copyright (C) 2002-2003  Juan Pablo Ugarte

    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program; if not, write to the Free Software
    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
    
Contacts:
    * gba@xjuan.gq.nu
    * http://xjuan.gq.nu
*******************************************************************************/
#include"output.h"
#define C_ARRAY_FILE_ERROR "C_ARRAY.C: Can't create file\n"

int out_c_array(struct imagen *out,int flags)
{
	FILE *file2save;
	char *filename=make_output_name(out,".c");
	
	if(flags==0) return 0;
	
	/*OPEN FILE TO SAVE OUTPUT*/
	file2save=fopen(filename,"w");
	if(file2save==NULL) error(C_ARRAY_FILE_ERROR);

	if(out->bpp==8 || out->bpp==4){
		int i,pixels=out->res_x*out->res_y;
		unsigned char *pix_data=out->pix_data,*pal_data=out->pal_data;
		unsigned short int gba_pal_pixel;
		
		/*if bpp=4 we have two pixels in the same byte*/
		if(out->bpp==4) pixels=pixels/2;
	
		/*OUTPUT IMAGEN PALETTE*/
		if(flags & PAL_DATA){
			fprintf(file2save,"const unsigned short int %s_pal[%d]={"
						,out->name,out->pal_size);
			for(i=0;i<out->pal_size;i++){
				gba_pal_pixel=((pal_data[2]>>3) | ((pal_data[1]>>3)<<5) |
								((pal_data[0]>>3)<<10));
				pal_data+=3;
				fprintf(file2save,"%d",gba_pal_pixel);
				if(i<(out->pal_size-1)) fprintf(file2save,",");
			}
			fprintf(file2save,"};\n");
		}
		/*OUTPUT IMAGEN DATA*/
		if(flags & PIX_DATA){
			fprintf(file2save,"const unsigned char %s_pix[%d]={"
						,out->name,pixels);
			for(i=0;i<pixels;i++){
				fprintf(file2save,"%d",pix_data[i]);
				if(i<(pixels-1)) fprintf(file2save,",");
			}
			fprintf(file2save,"};\n");
		}
	}
	if(out->bpp==24 && (flags & PIX_DATA)){
		int i,pixels=out->res_x*out->res_y;
		unsigned char *pix_data=out->pix_data;
		unsigned short int gba_pixel;
	
		/*OUTPUT IMAGEN DATA*/
		fprintf(file2save,"const unsigned short int %s_pix[%d]={",out->name,pixels);
		/*
			The GameBoy Advance stores pixels in 15 bit BGR format
			thats why i choose BGR in the struct imagen
		
			bits 15 14 13 12 11 10 09 08 07 06 05 04 03 02 01 00
				 /  B  B  B  B  B  G  G  G  G  G  R  R  R  R  R
		*/
		for(i=0;i<pixels;i++){
			gba_pixel=((pix_data[2]>>3) | ((pix_data[1]>>3)<<5) | ((pix_data[0]>>3)<<10));
			pix_data+=3;
			fprintf(file2save,"%d",gba_pixel);
			if(i<(pixels-1)) fprintf(file2save,",");
		}
		fprintf(file2save,"};\n");
	}
	free(filename);
	return 0;
}
