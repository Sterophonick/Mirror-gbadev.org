/******************************************************************************/
/*                       PIX4GBA by Juan Pablo Ugarte                          */
/*      This is a multi format pixmap converter for use in GBA projects       */
/*******************************************************************************
    Copyright (C) 2002-2003  Juan Pablo Ugarte

    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program; if not, write to the Free Software
    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
    
Contacts:
    * gba@xjuan.gq.nu
    * http://xjuan.gq.nu
*******************************************************************************/
#include"output.h"
#define OUT_FILE_ERROR "OUTPUT.C: Can't create file\n"

/*
	OUT_IMAGEN_INFO:
*/
int out_imagen_def(struct imagen *out,int flags){
	FILE *file2save;
	char *filename=make_output_name(out,".cat");

	if(flags==0) return 0;
	
	file2save=fopen(filename,"w");
	if(file2save==NULL) error(OUT_FILE_ERROR);

	if(flags & PIX_DATA)
		fprintf(file2save,"#define RESX_%s %d\n#define RESY_%s %d\n"\
				,out->name,out->res_x,out->name,out->res_y);

	if(out->bpp==8 || out->bpp==4){
		int pixels=out->res_x*out->res_y;
		/*if bpp=4 we have two pixels in the same byte*/
		if(out->bpp==4) pixels=pixels/2;

		if(flags & PAL_DATA){
			/*OUTPUT IMAGEN PALETTE*/		
			fprintf(file2save,"#define PALSIZE_%s %d\n"
						,out->name,out->pal_size);
			fprintf(file2save,"const unsigned short int %s_pal[%d];\n"
						,out->name,out->pal_size);
		}
		/*OUTPUT IMAGEN DATA*/
		if(flags & PIX_DATA)
			fprintf(file2save,"const unsigned char %s_pix[%d];\n"
						,out->name,pixels);
	}
	if(out->bpp==24 && (flags & PIX_DATA)){
		/*OUTPUT IMAGEN DATA*/
		fprintf(file2save,"const unsigned short int %s_pix[%d];\n"
					,out->name,out->res_x*out->res_y);
	}
	free(filename);
	return 0;
}
