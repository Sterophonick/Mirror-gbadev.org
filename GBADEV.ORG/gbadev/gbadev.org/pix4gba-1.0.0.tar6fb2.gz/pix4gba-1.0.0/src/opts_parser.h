/******************************************************************************/
/*                      OPTS PARSER by Juan Pablo Ugarte                      */
/*      This is a small library to parse command line options easily          */
/*******************************************************************************
    Copyright (C) 2003  Juan Pablo Ugarte

    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program; if not, write to the Free Software
    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
    
Contacts:
    * gba@xjuan.gq.nu
    * http://xjuan.gq.nu
*******************************************************************************/
#ifndef OPTS_PARSER_H
#define OPTS_PARSER_H
#include<stdio.h>
#include<stdlib.h>
#include<string.h>
#define OPTS_PARSER_VERSION 1.0
/*
Two classes of options are used in OPTS_PARSER, FLAGs and ARGUMENTs with their 
corresponding short and long form, like in most GNU soft.

EXAMPLE:
Short form
	#./myprogram -f -v 123
Long form
	#./myprogram --flag --value 123
*/
enum opt_type{
	FLAG,/* they dont use argument and are allways integer, *var=!*var */
	ARGUMENT,/*they use argument*/
};
enum var_type{
	INTEGER,/* *var is an int */
	FLOAT,/* *var is a float */
	STRING,/* *var is a newly malloc string*/
	BOOLEAN,/* *var is an int but the argument is the string true or fase*/
};
/*
The main idea is that you define a 'struct opts_item' array and then a single
function will fill all the variables in the array with the corresponding value.
*/
struct opts_item{
/*Public fields: must be completed*/
	char *opt_long;
	char *opt_short;
	int opt_type;
	int var_type;
	void *var;
/*Private fields: dont use them*/
	int var_set_flag;/* if *var was set then 1 else 0 */
};
/*
This is the core function of the library, the first two arguments are the
main's function arguments, the thirt argument is the number of opts_items in the
array options.
*/
int opts_parser(int argc,char **argv,int nro_opts,struct opts_item options[]);
/*
EXAMPLE to define the struct opts_item array and calculate the number of items
in the array (to lazy to count by hand).

#include "opts_parser.h"
int main(int argc,char **argv){
	int juan,nro_opts;
	struct opts_item options[]={
		{"--qwerty","-q",FLAG,INTEGER,(void*)&juan},
		{"--asdfgh","-a",FLAG,INTEGER,(void*)&juan}
	};

	nro_opts=sizeof(options)/sizeof(struct opts_item);
	
	opts_parser(argc,argv,nro_opts,options);
	return 0;
}
*/
#define OPTS_PARSER_ERROR "opts_parser.c: "
#define OPTS_PARSER_ERROR_FLAG OPTS_PARSER_ERROR"A flag is not integer"
#define OPTS_PARSER_ERROR_OPT OPTS_PARSER_ERROR"Unknow option type.\n"
#define OPTS_PARSER_ERROR_VAR OPTS_PARSER_ERROR"Unknow variable type.\n"
#define OPTS_PARSER_ERROR_VAR_TYPE OPTS_PARSER_ERROR"Error in option's argument"
#define OPTS_PARSER_ERROR_VAR_BOOLEAN OPTS_PARSER_ERROR"BOOLEANS arguments must be \"true\" or \"false\""
#endif

