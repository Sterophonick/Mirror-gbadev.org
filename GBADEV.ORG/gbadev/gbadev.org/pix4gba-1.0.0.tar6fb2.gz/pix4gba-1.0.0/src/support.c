/******************************************************************************/
/*                      PIX4GBA by Juan Pablo Ugarte                          */
/*      This is a multi format pixmap converter for use in GBA projects       */
/*******************************************************************************
    Copyright (C) 2002-2003  Juan Pablo Ugarte

    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program; if not, write to the Free Software
    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
    
Contacts:
    * gba@xjuan.gq.nu
    * http://xjuan.gq.nu
*******************************************************************************/

#include "common.h"
/*
	ERROR: Use this function to display error messages to the stderr
*/
void error (char *mes)
{
	fprintf (stderr, mes);
	return;
}

/*
	FILE_SIZE: returns file size in bytes
*/
int file_size (char *file_name)
{
	struct stat file;
	if (stat (file_name, &file) != 0)
		return -1;
	return file.st_size;  
}
/*
	GET_REALNAME:
	~~~~~~~~~~~~
	Find out the real name from the absolute filename path,
	*realname and *extension are malloc() in the same string so you only have
	to free() realname after use.
	return 0 if ok.
*/
int get_realname(char *source,char **realname,char **extension)
{
	int i;
	char (*temp)=malloc(strlen(source)+1);
	char *realname_temp;
	if(temp==NULL) return -1;
	strcpy(temp,source);

	/*Now find the latest slash '/'*/
	i=strlen(temp);/*Start from the back*/
	while(temp[i]!='/' && i>0) i--;
	if(temp[i]=='/') i++;
	realname_temp=malloc(strlen(&temp[i])+1);
	strcpy(realname_temp,&temp[i]);
	(*realname)=realname_temp;

	/*OK let's determine the extension*/
	i=strlen(realname_temp);
	while(realname_temp[i]!='.' && i>0) i--;
	if(i==0) (*extension)=NULL;
	else {
		(*extension)=&realname_temp[i+1];
		realname_temp[i]='\0';
	}
	free(temp);
	return 0;
	/*
	  NOTE: I am sure you note the extra "()" betwen *extension and *realname
	  this is to tell "gcc -O3" do what i want
	*/
}
/*
	MAKE_OUTPUT_NAME:
	Make a new string calling malloc and concatenating the name
	of the struct imagen input_imagen with suffix.
	return value should be free after use.
*/
char* make_output_name(struct imagen *input_imagen,char *suffix)
{
	char *new_name=malloc(strlen(input_imagen->name)+strlen(suffix)+1);
	sprintf(new_name,"%s%s",input_imagen->name,suffix);
	return new_name;
}
/*
	PIX_SWAP: auxiliar function used in convert_imagen_color_space.
*/
void pix_swap(char *src)
{
	char temp=src[0];
	src[0]=src[2];
	src[2]=temp;
	return;
}
/*
	CONVERT_IMAGEN_COLOR_SPACE:
	Convert input_imagen to color_space.
	returns 0 if ok;
*/
int convert_imagen_color_space(struct imagen *input_imagen,int color_space)
{
	int i,imagen_size=input_imagen->res_x*input_imagen->res_y;
	int pal_size=input_imagen->pal_size;
	char *temp;
	
	if(input_imagen->bpp==8){	
		if(input_imagen->pal_color_space!=color_space
			&& input_imagen->pal_data!=NULL){
			temp=input_imagen->pal_data;
			for(i=0;i<pal_size;i++){
				pix_swap(temp);
				temp+=3;
			}
		}
	}
	if(input_imagen->bpp==24){
		if(input_imagen->pix_color_space!=color_space
			&& input_imagen->pix_data!=NULL){
			temp=input_imagen->pix_data;
			for(i=0;i<imagen_size;i++){
				pix_swap(temp);
				temp+=3;
			}
		}
	}
	input_imagen->pal_color_space=color_space;
	input_imagen->pix_color_space=color_space;
	return 0;
}

/*
	COPY_IMAGEN:
	Return a new malloc imagen
*/
struct imagen* copy_imagen(struct imagen *input_imagen)
{
	int imagen_size=input_imagen->res_x*input_imagen->res_y;
	int pal_size=input_imagen->pal_size;
	struct imagen *temp=malloc(sizeof(struct imagen));

	if(input_imagen==NULL || input_imagen->name==NULL) return NULL;
	
	temp->name=malloc(strlen(input_imagen->name)+1);
	strcpy(temp->name,input_imagen->name);
	
	if(input_imagen->pal_data!=NULL){
		temp->pal_data=malloc(pal_size*3);
		memcpy(temp->pal_data,input_imagen->pal_data,pal_size*3);
	}
	if(input_imagen->pix_data!=NULL){
		int pix_size=input_imagen->bpp/8;
		temp->pix_data=malloc(imagen_size*pix_size);
		memcpy(temp->pix_data,input_imagen->pix_data,imagen_size*pix_size);
	}
	temp->res_x=input_imagen->res_x;
	temp->res_y=input_imagen->res_y;
	temp->bpp=input_imagen->bpp;
	temp->pal_size=input_imagen->pal_size;
	temp->pal_color_space=input_imagen->pal_color_space;
	temp->pix_color_space=input_imagen->pix_color_space;
	return temp;
}
/*
	FREE_IMAGEN:
*/
void free_imagen(struct imagen *input_imagen)
{
	if(input_imagen==NULL || input_imagen->name==NULL) return;
	free(input_imagen->name);
	free(input_imagen);
	return;
}
/*
	STRIP_TILES_FROM_IMAGEN:
	returns a new imagen strip in 8x8 tiles
*/
struct imagen* strip_tiles_from_imagen(struct imagen *input_imagen)
{
	unsigned char *source_pix_data=(unsigned char*)input_imagen->pix_data;
	unsigned char *dest_pix_data;
	int res_x=input_imagen->res_x,res_y=input_imagen->res_y;
	int tiles_x,tiles_y,index_x,index_y;
	struct imagen *strip_imagen;
	
	if(input_imagen->bpp!=8) return NULL;
	if(res_x%8!=0 || res_y%8!=0) return NULL;
	tiles_x=res_x/8;
	tiles_y=res_y/8;
	
	strip_imagen=copy_imagen(input_imagen);
	dest_pix_data=(unsigned char*)strip_imagen->pix_data;
	
	for(index_y=0;index_y<tiles_y;index_y++){
		for(index_x=0;index_x<tiles_x;index_x++){
			unsigned char *tile_source=source_pix_data+(index_y*8*res_x)+(index_x*8);
			int i;
			for(i=0;i<8;i++){
				memcpy(dest_pix_data,tile_source,8);
				dest_pix_data+=8;
				tile_source+=res_x;
			}
		}
	}
	return strip_imagen;
}
/*
	PIXDATA_8to4_bpp:
	used in CONVERT_IMAGEN_PIXDATA_TO4BPP
*/
int pixdata_8to4_bpp(char *dest,char *source,int pixdata_size)
{
	int i,size=pixdata_size/2;
	char a,b;
	for(i=0;i<size;i++){
		a=*source++;
		b=*source++;
		*dest++=(a & 0x0F)<<4 | (b & 0x0F);
	}
	return 0;
}
/*
	CONVERT_IMAGEN_PIXDATA_TO4BPP: 
*/
int convert_imagen_pixdata_to4bpp(struct imagen *input_imagen)
{
	int imagen_size=input_imagen->res_x*input_imagen->res_y;
	char *source=(char*)input_imagen->pix_data;
	char *dest=(char*)malloc(imagen_size/2);
	pixdata_8to4_bpp(dest,source,imagen_size);
	free(input_imagen->pix_data);
	input_imagen->pix_data=(void*)dest;
	input_imagen->bpp=4;
	return 0;
}
