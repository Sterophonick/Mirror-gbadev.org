/******************************************************************************/
/*                      PIX4GBA by Juan Pablo Ugarte                          */
/*      This is a multi format pixmap converter for use in GBA projects       */
/*******************************************************************************
    Copyright (C) 2002-2003  Juan Pablo Ugarte

    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program; if not, write to the Free Software
    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
    
Contacts:
    * gba@xjuan.gq.nu
    * http://xjuan.gq.nu
*******************************************************************************/
#include"common.h"
#include"input/input.h"
#include"output/output.h"
#include"opts_parser.h"
#include<signal.h>
int input_verbose_flag,output_verbose_flag;
/*
  INFO_IMAGEN
*/
int info_imagen (struct imagen *i)
{
	printf ("Imagen Information:\"%s\"\n\t %dx%dx%d\tPAL=%s\tPIX=%s\n",
			i->name, i->res_x, i->res_y, i->bpp,
			((i->pal_color_space == BGR) ? "BGR" : "RGB"),
			((i->pix_color_space == BGR) ? "BGR" : "RGB"));
	return 0;
}

void on_sigsegv_signal ()
{
	fprintf (stderr, MAIN_SIGSEGV);
	fprintf (stderr, BUG_REPORT);
	exit (-1);
}
void print_help(){
	printf(
		"Options:\n"
		"    -l     --load          <file> File to load.\n"
		"    -o     --output        <name> Name of the output files.\n"
		"    -oc    --out-c_array     Output imagen as C array.\n"
		"    -or    --out-raw         Output imagen as raw data.\n"
		"    -od    --out-defines     Output imagen C defines.\n"
		"    -c4bpp --convert-4bpp    Convert imagen to 4 bpp before output.\n"
		"    -ct    --convert-tiles   Strip tiles in the imagen before output(1D).\n"
		"    -npal  --no-palette      Do not output palette data.\n"
		"    -npix  --no-pixel        Do not output pixel data.\n"
		"    -i     --information     Print imagen information.\n"
		"    -q     --quiet           Don't print data to stdout.\n"
		"    -v     --version         Print version to stdout and exit.\n"
		"See man pages for more information.\n"
		UGARTE_CONTACT);
}
/*
  MAIN: PIX4GBA main function
*/
int main (int argc, char **argv)
{
	struct imagen *load;
	char *file2load,*output_name;
	int c_array=0,raw=0,defines=0,to4bpp=0,tiles=0,npal=0,npix=0;
	int quiet=0,info=0,flags=0,ver=0;
	struct opts_item options[]={
		{"--load","-l",ARGUMENT,STRING,(void*)&file2load},
		{"--output","-o",ARGUMENT,STRING,(void*)&output_name},		
		{"--out-c_array","-oc",FLAG,INTEGER,(void*)&c_array},
		{"--out-raw","-or",FLAG,INTEGER,(void*)&raw},
		{"--out-defines","-od",FLAG,INTEGER,(void*)&defines},
		{"--convert-4bpp","-c4bpp",FLAG,INTEGER,(void*)&to4bpp},
		{"--convert-tiles","-ct",FLAG,INTEGER,(void*)&tiles},
		{"--no-palette","-npal",FLAG,INTEGER,(void*)&npal},
		{"--no-pixel","-npix",FLAG,INTEGER,(void*)&npix},
		{"--information","-i",FLAG,INTEGER,(void*)&info},
		{"--quiet","-q",FLAG,INTEGER,(void*)&quiet},
		{"--version","-v",FLAG,INTEGER,(void*)&ver}
	};
	int nro_opts=sizeof(options)/sizeof(struct opts_item);

	signal(SIGSEGV, on_sigsegv_signal);

	if(opts_parser(argc,argv,nro_opts,options)!=0){
		print_help();
		return 1;
	}

	if(ver){
		printf(PIX4GBA_VERSION"\n");
		return 0;
	}

	if(quiet) input_verbose_flag=output_verbose_flag=0;
	else input_verbose_flag=output_verbose_flag=1;
	
	if(!options[0].var_set_flag){
		printf("The option -l, --load <file> must be present.\n");
		print_help();
		return 2;
	}
	if(!quiet) printf(PIX4GBA"\nLoading file %s ...\n",file2load);
	load=load_pixmap(file2load);
	if(load==NULL){
		return 3;
	}

	if(options[1].var_set_flag){
		if(!quiet) printf("Setting image name to \"%s\"\n",output_name);
		free(load->name);
		load->name=malloc(strlen(output_name)+1);
		strcpy(load->name,output_name);
	}

	if(info) info_imagen(load);

	if(tiles){
		struct imagen *new;
		new=strip_tiles_from_imagen(load);
		free_imagen(load);
		load=new;
		if(info) info_imagen(load);		
	}

	if(to4bpp) convert_imagen_pixdata_to4bpp(load);

	if(!npal)flags=flags | PAL_DATA;
	if(!npix)flags=flags | PIX_DATA;
	
	if(raw) out_raw(load,flags);

	if(c_array) out_c_array(load,flags);

	if(defines) out_imagen_def(load,flags);
	
	return 0;
}
