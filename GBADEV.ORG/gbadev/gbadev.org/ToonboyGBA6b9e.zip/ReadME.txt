 
"ToonBoy GBA" 
By Drew Medina 2003
http://www.drewmedina.com
drew_medina@hotmail.com

Made with HAM Devkit 2.71
http://www.ngine.de/
(kickass GBA kit, please support!)

This a public domain, free Rom. 
It was made for fun, demonstrating scrolling, animation,
parallaxing and a handrawn art style...
Burn to a dev cart or run in a GBA emulator.


Credits:
Art/design/construction.......Drew Medina (Dr. Jelly)
Programming...................Jomy Huang
Core game engine..............Cyber_Rat_98 



Dedicated to my son Kai and beautiful wife Kristy.




 