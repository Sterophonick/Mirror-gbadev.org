////////////////////////////////////////////////////////////////////////
// File:		mosaic.h
// Description:	to control mosaic effects on the bg and sprites
// Author:		dovoto (modified by Jenswa)
// Date:		9th February 2003
////////////////////////////////////////////////////////////////////////

#define MaxMosaic	14
#define MinMosaic	0


#define BG_MOSAIC_ENABLE		0x40
#define MOS_BG_HOR(n) (n)
#define MOS_BG_VER(n) (n<<4)
#define MOS_OBJ_HOR(n) (n<<8)
#define MOS_OBJ_VER(n) (n<<12)

#define SetMosaic(bh,bv,oh,ov) REG_MOSAIC = ((bh)+(bv<<4)+(oh<<8)+(ov<<12))

//usage REG_MOSAIC = SetMosaic(4,4,0,0); for a mosaic of 4x4 on the background
//and 0x0 on the sprites which have mosaic enabled, don't forget to set REG_BGxCNT (x is number)

