////////////////////////////////////////////////////////////////////////////
//File:		map.cpp
//Date:		08 - 08 - 2002
//Program:	Displays and moves a map on the gba
//Author:		Jenswa
//Thanks to:	gbajunkie, nokturn, dovoto
////////////////////////////////////////////////////////////////////////////

//general declarations
#include "gba.h"		//GBA register definitions
#include "dispcnt.h"		//REG_DISPCNT register #defines
#include "keypad.h"	//keypad defines
#include "background.h"	//background defines
#include "mosaic.h"		//the nice mosaic effect

//gfx
#include "tiles.h"		//tiles gfx and palette
#include "map.c"		//the tilemap

//create a background
BG bg3;

//wait for the screen to stop drawing
void WaitForVsync()
{
	while((volatile u16)REG_VCOUNT != 160){}
}

//draws the map, loads tiles and loads the palette
void DrawBG()
{
	int x;
	//loads the palette into memory
	for(x = 0; x < 256; x++)
	{
		BGPaletteMem[x] = tilesPalette[x];
	}
	//loads the tiels into memory
	for(x = 0; x < tiles_WIDTH*tiles_HEIGHT/2; x++)
	{
		BGTileMem[x] = tilesData[x];
	}
	//loads the map into memory
	for(x = 0; x < 32*32; x++)
	{
		VideoBuffer[x] = map[x];
	}
}

//read the gba keypad
void GetInput()
{
	//if key up is pressed
	if(KEY_DOWN(KEYUP))
	{
		bg3.y--;
	}
	//if key down is pressed
	if(KEY_DOWN(KEYDOWN))
	{
		bg3.y++;
	}
	//if key left is pressed
	if(KEY_DOWN(KEYLEFT))
	{
		bg3.x--;
	}
	//if key right is pressed
	if(KEY_DOWN(KEYRIGHT))
	{
		bg3.x++;
	}
	//if key L is pressed
	if(KEY_DOWN(KEYL))
	{
		SetMosaic(MaxMosaic,MaxMosaic,0,0);
	}
	//if key R is pressed
	if(KEY_DOWN(KEYR))
	{
		SetMosaic(MinMosaic,MinMosaic,0,0);
	}
}

int main()
{
	//sets the BG x and y coor, n is in which backgroudlayer the map is
	bg3.x = 0;
	bg3.y = 96;
	bg3.n = 3;

	//sets BG registers right for BG3
	REG_BG3CNT = CHAR_BASE(1) | BG_COLOR_256 | BG_MOSAIC_ENABLE;

	//sets the display mode, enables BG3 and OBJ mapping is 1D
	SetMode(MODE_0 | BG3_ENABLE | OBJ_MAP_1D);

	//this draws the bg on screen
	DrawBG();

	while (1)	//main loop
	{
	GetInput();
	UpdateBG(&bg3);
	WaitForVsync();
	}
}
