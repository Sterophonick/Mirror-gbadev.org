Flower demo
by Richard "Ries" van der Brugge
rvdbrugge@NOSPAMyahoo.com (remove NOSPAM)


The second experiment on the GBA, this time using the ARM SDK compiler. 
It is yet again mostly a rip/rewrite of other peoples hard work.
All credits for the scroller go to PAN/ATX. 
Thanx to warder1 for the example code of displaying a tile/mode0 picture on the GBA. 
This one shows a bouncing background picture and a textscroller. 

Source code included as usual.
