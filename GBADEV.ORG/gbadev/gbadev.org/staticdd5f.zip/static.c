#include <stdlib.h>
#include "pin8gba.h"
#include "menuchr.h"
MULTIBOOT


typedef struct STATIC_MENU_ITEM
{
  char name[28];
  void (*code)(void);
} STATIC_MENU_ITEM;

static unsigned char repeats[10];


void clear_keybuf(void)
{
  int i;

  for(i = 0; i < 10; i++)
    repeats[i] = 1;
}


/* make_repeats() **********************
   Handle auto-repeat for ten-bit joypad.
*/
void make_repeats(u32 keys)
{
  unsigned int i;

  for(i = 0;
      i < 10;
      keys >>= 1, i++)
  {
    if(keys & 1)
    {
      repeats[i]++;
      if(repeats[i] >= 18)
        repeats[i] = 16;
    }
    else
      repeats[i] = 0;
  }
}


/* expand_gb_to_gba4bit() *********
   Expand tiles from Game Boy format to Game Boy Advance
   format in 4-bit color.
*/
void expand_gb_to_gba4bit(void *in_dst, const u8 *src, size_t len, const unsigned char gbpal[4])
{
  u32 *dst = in_dst;

  len >>= 1;  /* convert from bytes to scanlines */

  for(; len > 0; len--)
  {
    unsigned int sr0 = *src++;
    unsigned int sr1 = *src++;
    unsigned int dstbits = 0;
    unsigned int bits = 8;

    for(; bits > 0; bits--)
    {
      unsigned int gb_color = ((sr1 & 1) << 1) | (sr0 & 1);
      sr0 >>= 1;
      sr1 >>= 1;
      dstbits = (dstbits << 4) | gbpal[gb_color];
    }
    *dst++ = dstbits;
  }
}


void menu_nputs(unsigned int nt, unsigned int x, unsigned int y,
                const char *str, size_t maxlen, unsigned int ormask)
{
  while((*str) && (maxlen > 0))
  {
    MAP[nt][y][x++] = *str++ | ormask;  /* copy a character */
    maxlen--;
  }
}






/***************************************
                MIRROR
***************************************/


void mirror(void)
{
  while(LCD_Y != 160);
  LCDMODE = 0;
  PALRAM[0] = 0;
  clear_keybuf();

  while(1)
  {
    while(LCD_Y != 0);
    while(LCD_Y != 160);
    make_repeats((JOY & 0x03ff) ^ 0x03ff);
    if(repeats[0] == 1 || repeats[3] == 1)
      return;
  }
}



/***************************************
               INTERLACE
***************************************/

static void setup_interlace_scr(void)
{
  u32 y;

  u32 *here = (u32 *)VRAM;
  for(y = 0; y < 160; y++)
    {
      u32 x;

      for(x = 0; x < 30; x++)  /* 30 blocks of four pixels */
	*here++ = 0x01010101;  /* four pixels of color 1 */
      for(x = 0; x < 30; x++)
	*here++ = 0x02020202;  /* four pixels of color 2 */
    }
}


void interlace(void)
{
  unsigned int frame = 1;  /* alternates between 1 and 2 */

  /* set up screen */
  LCDMODE = 4 | LCDMODE_BLANK;
  setup_interlace_scr();
  PALRAM[0] = 0;
  PALRAM[1] = RGB(0, 0, 24);
  PALRAM[2] = RGB(31, 31, 24);

  /* turn on screen */
  while(LCD_Y != 160);
  LCDMODE = 4 | LCDMODE_BG2;

  /* wait for keypress */
  clear_keybuf();
  do {
    while(LCD_Y != 0);
    while(LCD_Y != 160);
    make_repeats((JOY & 0x03ff) ^ 0x03ff);
  } while(repeats[0] != 1 && repeats[3] != 1);

  /* swap colors per frame */
  do {
    /* darken this color */
    PALRAM[frame] = RGB(0, 0, 24);  /* darken this color */
    frame = 3 - frame;
    PALRAM[frame] = RGB(31, 31, 24);  /* lighten this color */

    /* wait for vblank */
    while(LCD_Y != 0);
    while(LCD_Y != 160);
    make_repeats((JOY & 0x03ff) ^ 0x03ff);
  } while(repeats[0] != 1 && repeats[3] != 1);
}




/* nt_copy() ***************************
   Copy a portion of an NES-format nametable (32 tiles wide, low-order
   byte only) to the GBA screen.
*/
void nt_copy(size_t nt, size_t y, const unsigned char *nesnt, size_t height)
{
  unsigned short *vrp = MAP[nt][y];

  if(!height)
    return;

  height <<= 3;  /* mul by 8, unroll by 4, equals 32 */
  do {
    *vrp++ = *nesnt++;
    *vrp++ = *nesnt++;
    *vrp++ = *nesnt++;
    *vrp++ = *nesnt++;
  } while(--height);
}


void draw_gamma(void)
{
  unsigned short cur_color = RGB(1, 1, 1);
  u32 *p = ((u32 *)VRAM) + 8 * 128;
  size_t i;

  /* set palette */
  PALRAM[0] = PALRAM[1] = 0;
  PALRAM[1] = RGB(20, 20, 20);
  PALRAM[3] = RGB(31, 31, 31);
  PALRAM[15] = RGB(31, 31, 31);
  for(i = 17; i < 32; i++)
    {
      PALRAM[i] = cur_color;
      cur_color += RGB(1, 1, 1);
    }
  for(i = 33; i < 48; i++)
    {
      PALRAM[i] = cur_color;
      cur_color += RGB(1, 1, 1);
    }

  /* draw nametable */
  nt_copy(8, 0, gamscr_nam, 20);
  for(i = 0; i < 62; i++)
    MAP[8][10][i]|= 0x1000;
  for(i = 0; i < 62; i++)
    MAP[8][15][i]|= 0x2000;

  /* draw constant color patterns */
  p = ((u32 *)VRAM);
  for(i = 0; i < 16; i++)
    {
      unsigned int a = i | (i << 4);
      unsigned int b = a | (a << 8);
      unsigned int c = b | (b << 16);
      unsigned int x;

      for(x = 0; x < 8; x++)
	*p++ = c;
    }

  /* draw random bit patterns */
  p = ((u32 *)VRAM) + 8 * 132;
  for(i = 1; i < 31; i++)
    {
      unsigned int l = 32;  /* 8 rows of pixels * 4 tiles */
      unsigned int gamval = (i * i * i * i) / 3620;

      do {
	unsigned int pxls = 0;
	unsigned int x;

	for(x = 0; x < 8; x++)
	  {
	    unsigned int r = rand() & 0xff;

	    pxls <<= 4;
	    if(r < gamval)
	      pxls |= 0x0f;
	  }

	*p++ = pxls;
      } while(--l);
    }
}


void gamma_test(void)
{
  LCDMODE = 0 | LCDMODE_BLANK;
  draw_gamma();
  BGSCROLL[0].x = 0;
  BGSCROLL[0].y = 0;
  BGCTRL[0] = BGCTRL_PAT(0) | BGCTRL_16C | BGCTRL_NAME(8)
    | BGCTRL_H32 | BGCTRL_V32;
  while(LCD_Y != 160) ;
  LCDMODE = 0 | LCDMODE_BG0;

  while(1)
  {
    while(LCD_Y != 0);
    while(LCD_Y != 160);
    make_repeats((JOY & 0x03ff) ^ 0x03ff);
    if(repeats[0] == 1 || repeats[3] == 1)
      return;
  }
}



/***************************************
          6 PIXEL WIDE TILES
***************************************/

/* expand_a2() *************************
   Expands the leftmost 6 columns of an 8x8 pixel 1-bit character
   into a Six Pixel Wide Tile.
*/
void expand_a2(unsigned short *dst, const unsigned char *src, size_t src_len)
{
  if(!src_len)
    return;

  while(--src_len)
  {
    unsigned char s = *src++;

    *dst++ = ((s & 0x80) ? 0x000f : 0) |
             ((s & 0x40) ? 0x0f00 : 0);
    *dst++ = ((s & 0x20) ? 0x0f0f : 0);
    *dst++ = ((s & 0x10) ? 0x000f : 0) |
             ((s & 0x08) ? 0x0f00 : 0);
    *dst++ = ((s & 0x04) ? 0x0f0f : 0);
  }
}


/* cls() *******************************
   Clear the screen.
*/
static void cls_6pt(unsigned int nt, unsigned int c)
{
  unsigned short *dst = MAP[nt][0];
  int i;

  for(i = 0; i < 4096; i += 2)
    *dst++ = c;
}


/* put_text() **************************
   Write a string of text to a mode-7 nametable of width 64.
*/
static void put_text_6pt(unsigned int nt, unsigned int x, unsigned int y,
                         const char *str)
{
  for(; *str; x++,str++)
  {
    unsigned char this_char = *str;

    if(x >= 40)
    {
      x = 0;
      y++;
    }

    if(x & 1)
      MAP[nt][y][x >> 1] = (MAP[nt][y][x >> 1] & 0x00ff) | (this_char << 8);
    else
      MAP[nt][y][x >> 1] = (MAP[nt][y][x >> 1] & 0xff00) | this_char;
  }
}


/* set_mode7_params() ******************
   Set up the array that will be DMA'd into the affine registers.
*/
static void set_mode7_6pt(struct BGAFFINEREC *bg2lines, int x_o, int pa)
{
  int i;

  for(i = 0; i < 160; i++)
  {
    bg2lines[i].pa = pa;     /* When changing x_origin and y_origin per */
    bg2lines[i].pb = 0x0000; /* scanline, only pa and pc matter.  They set */
    bg2lines[i].pc = 0x0000; /* the vector from which a line segment is */
    bg2lines[i].pd = 0x0000; /* drawn mapping to the chosen segment. */
    bg2lines[i].x_origin = x_o;
    bg2lines[i].y_origin = i << 8;
  }
}


/* run_dma0() **************************
   Use DMA channel 0 to update BG2's affine registers.
*/
void run_dma0(struct BGAFFINEREC *bg2lines)
{
  BGAFFINE[2] = bg2lines[0];
  DMA[0].control = 0;
  DMA[0].src = &(bg2lines[1]);
  DMA[0].dst = (struct BGAFFINEREC *)&(BGAFFINE[2]);
  DMA[0].count = 8;
  DMA[0].control = DMA_DSTINCRESET | DMA_SRCINC | DMA_REPEAT | DMA_U16 |
                   DMA_HBLANK | DMA_ENABLE;
}


/*  Settings for tiles of arbitrary width

   wid  x base  pa      pixelpat
    15  0x000f  0x0111  1111111111111110
    14  still working on it
    13  0x0013  0x013b  1111101111011110
    12  0x0050  0x0155  1110111011101110  <-
    11  still working on it
    10  still working on it

*/
void demo_6pxwide(void)
{
  struct BGAFFINEREC bg2lines[160];

  /* hide display initially for speed */
  LCDMODE = 1 | LCDMODE_BLANK;

  /* set palette */
  PALRAM[0] = RGB(0, 0, 31);
  PALRAM[15] = RGB(31, 31, 31);

  /* load pattern table */
  expand_a2(VRAM, a2_chr, a2_chr_len);

  /* load nametable */
  cls_6pt(8, 0x2020);
  put_text_6pt(8, 0, 0, "0123456789012345678901234567890123456789");
  put_text_6pt(8, 1, 2,  "This text is written with 6-pixel-wide");
  put_text_6pt(8, 1, 3,  "tiles created by pre-scaling tiles and");
  put_text_6pt(8, 1, 4,  "then re-scaling them with GBA Mode 7.");
  put_text_6pt(8, 5, 6,      "The quick brown fox jumps over");
  put_text_6pt(8, 5, 7,      "the lazy dog.");
  put_text_6pt(8, 1, 18,  "Press A to exit.");

  /* show display */
  set_mode7_6pt(bg2lines, 0x0050, 0x0155);

  while(LCD_Y < 160) ;
  BGCTRL[2] = BGCTRL_PAT(0) | BGCTRL_256C | BGCTRL_NAME(8) |
              BGCTRL_M7WRAP | BGCTRL_M7_64;
  LCDMODE = 1 | LCDMODE_BG2;

  clear_keybuf();

  /* run mode 7 */
  do {
    while(LCD_Y != 227) ;
    run_dma0(bg2lines);
    while(LCD_Y != 160) ;
    DMA[0].control = 0;  /* stop DMA */
    make_repeats((JOY & 0x03ff) ^ 0x03ff);
  } while(repeats[0] != 1 && repeats[3] != 1);

  /* reset affine settings.
     If we don't do this, mode 3-5 will stop working.
     Note that the writes must be written IN ORDER or the GBA will
     get confused. */
  BGAFFINE[2].pa = 0x100;
  BGAFFINE[2].pb = 0;
  BGAFFINE[2].pc = 0;
  BGAFFINE[2].pd = 0x100;
  BGAFFINE[2].x_origin = 0;
  BGAFFINE[2].y_origin = 0;
  LCDMODE = LCDMODE_BLANK;
}







/***************************************
                THE MENU
***************************************/


#define N_MENU_ITEMS 4
const STATIC_MENU_ITEM mnu[N_MENU_ITEMS] =
{
  {"GAMMA TEST", gamma_test},
  {"6 PIXEL WIDE TILES", demo_6pxwide},
  {"MIRROR", mirror},
  {"INTERLACE", interlace}
};


void menu_draw(void)
{
  int i;
  const unsigned char gbtextpal[4] = {0, 0, 1, 3};
  const u16 pal[4] =
  {
    RGB(28,31,24),RGB(20,24,16),RGB(12,16, 8),RGB( 4, 8, 0)
  };
  const u32 spr_data[] =
  {
    0x00000012,
    0x00001212,
    0x00121002,
    0x12100002,
    0x23211113,
    0x00232113,
    0x00002323,
    0x00000023
  };

  /* clear screen */
  LCDMODE = 0 | LCDMODE_BLANK;
  for(i = 0; i < 1024; i++)
    MAP[8][0][i] = ' ';

  /* copy font */
  expand_gb_to_gba4bit(VRAM + 16*32, hudtiles_chr, hudtiles_chr_len, gbtextpal);

  /* copy palette */
  for(i = 0; i < 4; i++)
    PALRAM[i] = pal[i];
  for(i = 0; i < 4; i++)
    PALRAM[256 + i] = pal[i];

  /* write menu items */
  menu_nputs(8, 0, 0, "MENU", 256, 0);
  for(i = 0; i < N_MENU_ITEMS; i++)
  {
    menu_nputs(8, 2, i + 2, mnu[i].name, 28, 0);
  }

  /* copy spr image */
  {
    u32 *sprdst = (u32 *)0x06010000;  /* start of sprite data */
    for(i = 0; i < 8; i++)
    {
      sprdst[i] = spr_data[i];
    }
  }

  /* clear sprite table */
  for(i = 0; i < 128; i++)
  {
    OAM[i].y = 160;  /* 160 is hide on gba; 239 is hide on nes */
    OAM[i].x = 0;
    OAM[i].tile = 0;
  }
  OAM[0].x = 8;

  /* turn on display */
  BGSCROLL[0].x = 0x1fc;  /* -4 */
  BGSCROLL[0].y = 0x1fc;
  BGCTRL[0] = BGCTRL_PAT(0) | BGCTRL_16C | BGCTRL_NAME(8)
              | BGCTRL_H32 | BGCTRL_V32;
  LCDMODE = 0 | LCDMODE_BG0 | LCDMODE_SPR;
}


int main(void)
{
  int sel = 0;

  while(1)
  {
    int done_picked = 0;

    menu_draw();
    clear_keybuf();

    while(!done_picked)
    {
      /* read joypad */
      while(LCD_Y != 160);
      make_repeats((JOY & 0x03ff) ^ 0x03ff);

      /* move selection.  6 is up and 7 is down. */
      if(repeats[6] == 1 || repeats[6] == 17)
      {
        if(sel == 0)
          sel = N_MENU_ITEMS - 1;
        else
          sel--;
      }
      if(repeats[7] == 1 || repeats[7] == 17)
      {
        if(sel == N_MENU_ITEMS - 1)
          sel = 0;
        else
          sel++;
      }
      OAM[0].y = 20 + (sel << 3);

      /* start game?  0 is A and 3 is start. */
      if(repeats[0] == 1 || repeats[3] == 1)
        done_picked = 1;

      while(LCD_Y != 0);
    }
    if(mnu[sel].code)
      mnu[sel].code();
  }
}
