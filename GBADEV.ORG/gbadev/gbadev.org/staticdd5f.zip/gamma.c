/**************************************\
* gamma.c                              *
* Display a high-gray color ramp and a *
* dithered color ramp simulating the   *
* GBA display's native gamma.          *
*                                      *
\**************************************/

/* Copyright 2001 Damian Yerrick

Permission is hereby granted, free of charge, to any person obtaining
a copy of this software and associated documentation files (the
"Software"), to deal in the Software without restriction, including
without limitation the rights to use, copy, modify, merge, publish,
distribute, sublicense, and/or sell copies of the Software, and to
permit persons to whom the Software is furnished to do so, subject to
the following conditions:

The above copyright notice and this permission notice shall be
included in all copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND,
EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES
OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND
NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS
BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN
AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF
OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS
IN THE SOFTWARE.

*/


#define MULTIBOOT volatile const int __gba_multiboot;
MULTIBOOT

#include "pin8gba.h"
#include <stdlib.h>

const u32 dummy;  /* force aligned data */

#include "gamma_chr.h"
#include "gamscr_nam.h"


/* cpu_memcpy() ************************
   Copy a region of memory to VRAM or any other area of memory.
*/
void cpu_memcpy(void *in_dest, const void *in_source, size_t len)
{
  unsigned short *dst = in_dest;
  const unsigned short *src = in_source;

  len >>= 1;  /* bytes to shorts */
  if(len == 0)
    return;

  /* handle less than eight words */
  {
    size_t short_overage = len & 0x07;
    if(short_overage)
      do {
	*dst++ = *src++;
      } while(--short_overage);
  }

  len >>= 3;  /* shorts to 16-bytes */
  if(len == 0)
    return;

  /* unroll loop */
  do {
    *dst++ = *src++;
    *dst++ = *src++;
    *dst++ = *src++;
    *dst++ = *src++;
    *dst++ = *src++;
    *dst++ = *src++;
    *dst++ = *src++;
    *dst++ = *src++;
  } while(--len);

}


/* nt_copy() ***************************
   Copy a portion of an NES-format nametable (32 tiles wide, low-order
   byte only) to the GBA screen.
*/
void nt_copy(size_t nt, size_t y, const unsigned char *nesnt, size_t height)
{
  unsigned short *vrp = MAP[nt][y];

  if(!height)
    return;

  height <<= 3;  /* mul by 8, unroll by 4, equals 32 */
  do {
    *vrp++ = *nesnt++;
    *vrp++ = *nesnt++;
    *vrp++ = *nesnt++;
    *vrp++ = *nesnt++;
  } while(--height);
}


/* set_32gray() ************************
   Load a 32-level grayscale palette in hardware native gamma.
*/
void set_32gray(size_t palramoff)
{
  unsigned short cur_color = 0;
  size_t i;

  for(i = 0; i < 32; i++)
    {
      PALRAM[i + palramoff] = cur_color;
      cur_color += 0x421;
    }
}


/* gamma_correct() *********************
   Raise a pixel in (0..31) to the fourth power, producing a value
   in (0..255).  This simulates what the GBA display does to colors.
*/
unsigned int gamma_correct(unsigned int i)
{
  return (i * i * i * i) / 3620;
}


/* set_gamma_patterns() ****************
   Create a pattern of pixel 0 and pixel 31 that approximates a
   gamma curve.
*/
void set_gamma_patterns(size_t base_chr, size_t len)
{
  unsigned short *p = VRAM + 32 * base_chr;
  unsigned int i;

  for(i = 0; i < 32; i++)
    {
      unsigned int l = len << 5;
      unsigned gamval = gamma_correct(i);

      do {
	unsigned short r;
	unsigned short pxls = 0;

	r = rand() & 0xff;
	if(r < gamval)
	  pxls |= 0x001f;
	r = rand() & 0xff;
	if(r < gamval)
	  pxls |= 0x1f00;

	*p++ = pxls;
      } while(--l);
    }
}


int main(void)
{
  LCDMODE = 0 | LCDMODE_BLANK;

  set_32gray(0);
  cpu_memcpy(VRAM, gamma_chr, 4096);
  nt_copy(7, 0, gamscr_nam, 20);
  BGSCROLL[0].x = 0;
  BGSCROLL[0].y = 0;
  BGCTRL[0] = BGCTRL_PAT(0) | BGCTRL_256C | BGCTRL_NAME(7)
    | BGCTRL_H32 | BGCTRL_V32;
  set_gamma_patterns(0x40, 4);
  LCDMODE = 0 | LCDMODE_BG0;

  while(1) ;
}
