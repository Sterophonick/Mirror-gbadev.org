/**************************************\
* pin8gba.h                            *
* header file for compiling game boy   *
* advance software with devkit advance *
*                                      ********************************\
* Copyright 2001 Damian Yerrick                                        *
*                                                                      *
* (Insert GNU Lesser GPL notice here.)                                 *
*                                                                      *
\**********************************************************************/

#ifndef PIN8GBA_H
#ifdef __cplusplus
extern "C" {
#endif
#define PIN8GBA_H

/* Information based on CowBite spec
   http://www.gbadev.org/files/CowBiteSpec.txt
   and information gleaned from gbadev list
*/

#define IN_EWRAM __attribute__ ((section(".ewram")))
#define IN_IWRAM __attribute__ ((section(".iwram")))
/* and use like this:
   int array[100] IN_EWRAM;
   char temp IN_IWRAM;
*/

#define CODE_IN_IWRAM __attribute__((section(".iwram"),long_call))
/* and use like this:
   void fun(void) CODE_IN_IWRAM;

   void fun(void)
   {
     // ...
   }
*/

typedef unsigned char  u8;
typedef unsigned short u16;
typedef unsigned int   u32;

typedef signed char  s8;
typedef signed short s16;
typedef signed int   s32;


/* put MULTIBOOT at the top of the main src file to get a ROM that
   will work on both mbv2 and flash carts
*/
#define MULTIBOOT volatile const int __gba_multiboot;


/* Generic areas of GBA memory */
#define EWRAM  ((u8 *)0x02000000)   /* 256 KB */
#define IWRAM  ((u8 *)0x03000000)   /* 32 KB, fast */
#define IORAM  ((u8 *)0x04000000)   /* 1 KB */
#define PALRAM ((u16 *)0x05000000)  /* 0x200 words */
#define VRAM   ((u16 *)0x06000000)  /* 0xc000 words */
#define ROM    ((u8 *)0x08000000)   /* up to 32 megabytes */


/* LCD mode (0x04000000)
   Corresponds to NES's $2000 and $2001

fedcba9876543210  Register 0x04000000
||||||||||||||||
|||||||||||||+++- Display mode
||||||||||||+---- GBC mode (set to 0)
|||||||||||+----- In modes 4 and 5, view second page
||||||||||+------ Lock OAM during hblank (allows 128 sprites instead of 96)
|||||||||+------- 0: rowpitch for sprites is 32 tiles(?);
|||||||||         1: rowpitch for sprites is spr.width tiles
||||||||+-------- Blank LCD (may speed up rendering)
|||||||+--------- Show BG layer 0
||||||+---------- Show BG layer 1
|||||+----------- Show BG layer 2
||||+------------ Show BG layer 3
|||+------------- Show sprites
||+-------------- Enable window 0
|+--------------- Enable window 1
+---------------- Enable window 2

*/
#define LCDMODE (*(volatile u16 *)0x04000000)
#define LCDMODE_PAGE(x)  (((x) & 1) << 4)
#define LCDMODE_LOCKOAM  0x0020
#define LCDMODE_1DSPR    0x0040
#define LCDMODE_BLANK    0x0080
#define LCDMODE_BG0      0x0100
#define LCDMODE_BG1      0x0200
#define LCDMODE_BG2      0x0400
#define LCDMODE_BG3      0x0800
#define LCDMODE_SPR      0x1000
#define LCDMODE_WIN0     0x2000
#define LCDMODE_WIN1     0x4000
#define LCDMODE_SPRWIN   0x8000


/* LCD Status (0x04000004)
   Corresponds to NES's $2002, $4017, and MMC3 latches

fedcba9876543210  Register 0x04000004
||||||||  ||||||
||||||||  |||||+- 0: in refresh (160 scanlines)
||||||||  |||||   1: in vblank  (68 scanlines)
||||||||  ||||+-- 0: in refresh (1004 cycles)
||||||||  ||||    1: in hblank  (228 cycles)
||||||||  |||+--- we THINK this is set to 1 when a Y trigger int occurs
||||||||  ||+---- enable vblank interrupt
||||||||  |+----- enable hblank interrupt
||||||||  +------ enable Y trigger interrupt
++++++++--------- scanline on which to trigger interrupt

*/
/* defines to come later */


/* LCD Y position */
#define LCD_Y (*(volatile u16 *)0x04000006)  /* 0-159: draw; 160-227 vblank */


/* Background control (0x04000008-0x0400000e)
   Corresponds to NES's $2000
   This is a vector of four registers, one for each bg.

fedcba9876543210
||||||||||  ||||
||||||||||  ||++- Priority (00 closest; 11 furthest)
||||||||||  ++--- Pattern table to use (0x4000 bytes each)
|||||||||+------- Enable mosaic effect
||||||||+-------- Text: 0: 4-bit tiles; 16 palettes of 15 colors each.
||||||||                1: 8-bit tiles; 256 colors
||||||||          Affine: Always set to 1
|||+++++--------- Nametable to use (0x800 bytes each)
||+-------------- Affine: Draw transparency outside the active area
||                (active low/high ???)
++--------------- Size of map
                  Text: 00 32x32 tiles
                        01 64x32 tiles
                        10 32x64 tiles
                        11 64x64 tiles
                  Affine: 00 16x16 tiles
                          01 32x32 tiles
                          10 64x64 tiles
                          11 128x128 tiles

*/
#define BGCTRL ((volatile u16 *)0x04000008)
#define BGCTRL_PAT(m)    ((m) << 2)
#define BGCTRL_16C       0x0000
#define BGCTRL_256C      0X0080
#define BGCTRL_NAME(m)   ((m) << 8)
#define BGCTRL_M7WRAP    0x2000
#define BGCTRL_H32       0x0000
#define BGCTRL_H64       0x4000
#define BGCTRL_V32       0x0000
#define BGCTRL_V64       0x8000
#define BGCTRL_M7_16     0x0000
#define BGCTRL_M7_32     0x4000
#define BGCTRL_M7_64     0x8000
#define BGCTRL_M7_128    0xc000


/* Background scroll registers for text bgs (0x04000010-0x0400001E)
   Corresponds to NES's $2005

To scroll bg1 to (3, 7), do this:
BGSCROLL[1].x = 3;
BGSCROLL[1].y = 7;

Affine backgrounds ignore these registers.

*/
struct BGPOINT
{
  u16 x, y;
};

#define BGSCROLL ((volatile struct BGPOINT *)0x04000010)



/* Background affine registers (0x04000020-0x0400003e)

There are only two of these, BGAFFINE[2] and BGAFFINE[3].

*/
struct BGAFFINEREC
{
  u16 pa;  /* map_x increment per pixel */
  u16 pb;  /* map_x increment per scanline */
  u16 pc;  /* map_y increment per pixel */
  u16 pd;  /* map_y increment per scanline */
  u32 x_origin, y_origin;
};

#define BGAFFINE ((volatile struct BGAFFINEREC *)0x04000000)




/* The joypad.
   Note that the joypad is ACTIVE LOW meaning that
   0xffff represents "no buttons pressed" and
   0xfff6 represents "buttons A and B pressed"
*/



#define JOY (*(volatile u16 *)0x04000130)
#define JOY_A            0x0001
#define JOY_B            0x0002
#define JOY_SELECT       0x0004
#define JOY_START        0x0008
#define JOY_RIGHT        0x0010
#define JOY_LEFT         0x0020
#define JOY_UP           0x0040
#define JOY_DOWN         0x0080
#define JOY_R            0x0100
#define JOY_L            0x0200  /* could have these backwards */


/* DMA

DMA[0]  affine
DMA[1]  sound
DMA[2]  sound
DMA[3]  memcpy

The count register only copies up to 16,383 u16's or u32's.

Format of control register

fedcba9876543210  DMA Control (0x40000BA, 0x40000C6, 0x40000D2, 0x40000DE)
|||| ||||||
|||| ||||++------ 00: inc dest after each copy
|||| ||||         01: dec dest after each copy
|||| ||||         10: leave dest unchanged
|||| ||||         11: inc dest after each copy and reset after end of transfer
|||| ||++-------- 00: inc source after each copy
|||| ||           01: dec source after each copy
|||| ||           10: leave source unchanged
|||| |+---------- repeat transfer on every trigger
|||| +----------- 0: copy u16's; 1: copy u32's
||++------------- 00: copy now; 01: copy on vblank; 10: copy on hblank
|+--------------- irq (?)
+---------------- enable this channel

*/
struct DMACHN
{
  const void *src;
  void *dst;
  u16 count;
  u16 control;
};

#define DMA ((volatile struct DMACHN *)0x040000b0)
#define DMA_DSTINC      0x0000
#define DMA_DSTDEC      0x0020
#define DMA_DSTUNCH     0x0040
#define DMA_DSTINCRESET 0x0060
#define DMA_SRCINC      0x0000
#define DMA_SRCDEC      0x0080
#define DMA_SRCUNCH     0x0100
#define DMA_REPEAT      0x0200
#define DMA_U16         0x0000
#define DMA_U32         0x0400
#define DMA_COPYNOW     0x0000
#define DMA_VBLANK      0x1000
#define DMA_HBLANK      0x2000
#define DMA_SPECIAL     0x3000
#define DMA_IRQ         0x4000
#define DMA_ENABLE      0x8000




/* The palette

fedcba9876543210
 |||||||||||||||
 ||||||||||+++++- Red value
 |||||+++++------ Green value
 +++++----------- Blue value
 */
#define RGB(r,g,b) ((r)|(g)<<5|(b)<<10)


/* Pattern tables */

#define PATRAM(x) ((NAMETABLE *)(0x06000000 | ((x) << 14)))


/* Nametables */

typedef u16 NAMETABLE[32][32];

#define MAP ((NAMETABLE *)0x06000000)

/* Each nametable entry

fedcba9876543210  Text nametable entries
||||||||||||||||
||||||++++++++++- Tile number
|||||+----------- Flip tile horizontally
||||+------------ Flip tile vertically
++++------------- Palette

fedcba9876543210  Affine nametable entries
        ||||||||
        ++++++++- Tile number
*/


/* The sprites */

struct OAM_SPRITE
{
  u16 y;
  u16 x;
  u16 tile;
  u16 reserved;
};

#define GBA_NSPRITES 128
#define OAM ((volatile struct OAM_SPRITE *)0x07000000)


/* Sprite Y register (0x07000xx0, 0x07000xx8)

fedcba9876543210
||||||||||||||||
||||||||++++++++- Y position of nw corner of clipping rect
||||||++--------- 00: no affine; 01: affine clipped to orig. rect;
||||||            10: hide; 11: affine clipped to twice orig. rect
||||++----------- 00: opaque; 01: semitransparent; 10: object window
|||+------------- Enable mosaic
||+-------------- 0: 16-color; 1: 256-color
++--------------- 00: square; 01: wide; 10: tall

*/
#define OAM_YMASK       0x00ff
#define OAM_AFFINE      0x0100  /* set to 1 to use rot/scale */
#define OAM_DOUBLEANGLE 0x0200
#define OAM_TRANSLUCENT 0x0400
#define OAM_OBJWINDOW   0x0800
#define OAM_MOSAIC      0x1000
#define OAM_16C         0x0000
#define OAM_256C        0x2000
#define OAM_SQUARE      0x0000
#define OAM_WIDE        0x4000
#define OAM_TALL        0x8000

/* Sprite X register (0x07000xx2, 0x07000xxA)

fedcba9876543210  (Sprites using affine mapping)
||||||||||||||||
|||||||+++++++++- X position of nw corner of clipping rect
||+++++---------- (If this sprite uses affine) Affine record offset
++--------------- Size of sprite (see below)

fedcba9876543210  (Sprites using direct pixel mapping)
||||||||||||||||
|||||||+++++++++- X position of nw corner
|||+------------- Flip horizontally
||+-------------- Flip vertically
++--------------- Size of sprite (see below)

*/
#define OAM_XMASK       0x01ff
#define OAM_AFFINDEX(x) (((x) & 0x1f) << 9)
#define OAM_HFLIP       0x1000
#define OAM_VFLIP       0x2000
#define OAM_SIZE0       0x0000
#define OAM_SIZE1       0x4000
#define OAM_SIZE2       0x8000
#define OAM_SIZE3       0xc000

/* Size table
        square  wide    tall
size 0   8x 8   16x 8    8x16
size 1  16x16   32x 8    8x32
size 2  32x32   32x16   16x32
size 3  64x64   64x32   32x64
*/


/* Sprite name register (0x07000xx4, 0x07000xxC)

fedcba9876543210
||||||||||||||||
||||||++++++++++- Offset of tile data in 32-byte increments from
||||||            0x06010000
||||++----------- Priority (0 front; 3 back; sprites on a given layer
||||              cover background on the same layer)
++++------------- Palette number (16-color sprites only)
*/
#define OAM_TMASK       0x03ff
#define OAM_PRI(x)      (((x) & 0x03) << 10)
#define OAM_PAL(x)      (((x) & 0x0f) << 12)


struct SPRAFFINEREC
{
  u16 reserved0[3];
  u16 pa;  /* map_x increment per pixel */
  u16 reserved1[3];
  u16 pb;  /* map_x increment per scanline */
  u16 reserved2[3];
  u16 pc;  /* map_y increment per pixel */
  u16 reserved3[3];
  u16 pd;  /* map_y increment per scanline */
};

#define GBA_NSPRAFFINES 32
#define SPRAFFINE ((volatile struct SPRAFFINEREC *)0x07000000)



/* oooh... sound...  thanks to belogic.com */

/* DMG Sound Control (0x04000080)

fedcba9876543210
|||||||| ||| |||
|||||||| ||| +++- DMG left volume
|||||||| +++----- DMG right volume
|||||||+--------- Enable sqr1 on left
||||||+---------- Enable sqr2 on left
|||||+----------- Enable triangle on left
||||+------------ Enable noise on left
|||+------------- Enable sqr1 on right
||+-------------- Enable sqr2 on right
|+--------------- Enable triangle on right
+---------------- 

*/
#define DMGSNDCTRL         (*(volatile u16 *)0x04000080)
#define DMGSNDCTRL_LVOL(x) (x)
#define DMGSNDCTRL_RVOL(x) ((x) << 4)
#define DMGSNDCTRL_LSQR1   0x0100
#define DMGSNDCTRL_LSQR2   0x0200
#define DMGSNDCTRL_LTRI    0x0400
#define DMGSNTCTRL_LNOISE  0x0800
#define DMGSNDCTRL_RSQR1   0x1000
#define DMGSNDCTRL_RSQR2   0x2000
#define DMGSNDCTRL_RTRI    0x4000
#define DMGSNDCTRL_RNOISE  0x8000

/* Direct Sound Control (0x04000082)

fedcba9876543210
||||||||    ||||
||||||||    ||++- DMG sound output volume
||||||||    ||    (00: 25%; 01: 50%; 10: 100%)
||||||||    |+--- DSound A output volume (0: 50%; 1: 100%)
||||||||    +---- DSound B output volume (0: 50%; 1: 100%)
|||||||+--------- Enable DSound A on right
||||||+---------- Enable DSound A on left
|||||+----------- DSound A sample timer (0 or 1)
||||+------------ DSound A FIFO reset
|||+------------- Enable DSound B on right
||+-------------- Enable DSound B on left
|+--------------- DSound B sample timer (0 or 1)
+---------------- DSound B FIFO reset
*/
#define DSOUNDCTRL           (*(volatile u16 *)0x04000082)
#define DSOUNDCTRL_DMG25     0x0000
#define DSOUNDCTRL_DMG50     0x0001
#define DSOUNDCTRL_DMG100    0x0002
#define DSOUNDCTRL_A50       0x0000
#define DSOUNDCTRL_A100      0x0004
#define DSOUNDCTRL_B50       0x0000
#define DSOUNDCTRL_B100      0x0008
#define DSOUNDCTRL_AR        0x0100
#define DSOUNDCTRL_AL        0x0200
#define DSOUNDCTRL_ATIMER(x) ((x) << 10)
#define DSOUNDCTRL_ARESET    0x0400
#define DSOUNDCTRL_BR        0x1000
#define DSOUNDCTRL_BL        0x2000
#define DSOUNDCTRL_BTIMER(x) ((x) << 14)
#define DSOUNDCTRL_BRESET    0x8000

/* Sound Status (0x04000084)

Note that unlike NES's $4014, bits 0 to 3 of this register are
read-only.  They do not enable sound.

fedcba9876543210
        |   ||||
        |   |||+- Square 1 playing
        |   ||+-- Square 2 playing
        |   |+--- Triangle playing
        |   +---- Noise playing
        +-------- 0: save 10% battery power by turning off ALL sound;
                  1: play sound
*/
#define SNDSTAT        (*(volatile u16*)0x04000084)
#define SNDSTAT_SQR1   0x0001
#define SNDSTAT_SQR2   0x0002
#define SNDSTAT_TRI    0x0004
#define SNDSTAT_NOISE  0x0008
#define SNDSTAT_ENABLE 0x0080

/* Sound Bias: will not be documented.

fedcba9876543210
||    ||||||||||
||    ++++++++++- PWM bias
++--------------- Amplitude resolution
                  00: 9-bit at 32768 Hz
                  01: 8-bit at 65536 Hz (most common)
                  10: 7-bit at 131072 Hz
                  11: 6-bit at 262144 Hz

Do NOT use SNDBIAS directly.  To set the resolution, use
  SETSNDRES(1);
*/
#define SNDBIAS      (*(volatile u16 *)0x04000088)
#define SETSNDRES(x) SNDBIAS = (SNDBIAS & 0x3fff) | (x << 14)

#define DSOUND_FIFOA (*(volatile u32 *)0x040000a0)
#define DSOUND_FIFOB (*(volatile u32 *)0x040000a4)

/* Triangle Channel Control Register

fedcba9876543210
        |||
        ||+------ Bank mode (0: 2 banks of 32; 1: 1 bank of 64)
        |+------- Play this bank (and write other bank)
        +-------- Enable triangle channel
*/
#define TRICTRL         (*(volatile u16 *)0x04000070)
#define TRICTRL_2X32    0x0000
#define TRICTRL_1X64    0x0020
#define TRICTRL_BANK(x) ((x) << 6)
#define TRICTRL_ENABLE  0x0080

/* Triangle Channel Length/Volume (0x04000072)

fedcba9876543210
|||     ||||||||
|||     ++++++++- Length ((256-x)/256 seconds)
+++-------------- Volume (000: mute; 001: 100%; 010: 50%;
                          011: 25%; 100: 75%)
*/
#define TRILENVOL        (*(volatile u16 *)0x04000072)
#define TRILENVOL_LEN(x) (256 - (x))
#define TRILENVOL_MUTE   0x0000
#define TRILENVOL_25     0x6000
#define TRILENVOL_50     0x4000
#define TRILENVOL_75     0x8000
#define TRILENVOL_100    0x2000

/* Triangle Channel Frequency (0x04000074)

fedcba9876543210
||   |||||||||||
||   +++++++++++- frequency (131072/(2048-x))
|+--------------- 0: continuous; 1: timed
+---------------- 1: Reset
*/
#define TRIFREQ       (*(volatile u16 *)0x04000074)
#define TRIFREQ_HOLD  0x0000
#define TRIFREQ_TIMED 0x4000
#define TRIFREQ_RESET 0x8000

#define TRIWAVERAM ((volatile u32 *)0x04000090)



#ifdef __cplusplus
}
#endif
#endif
