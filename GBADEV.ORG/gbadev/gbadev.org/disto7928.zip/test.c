#include "bumpgfx.c"
#include "cossin.h"	// Precalculated Cos / Sin tables.
#include "logo.c"
typedef unsigned short int uint16;
typedef unsigned int uint;
typedef unsigned char bool;

#define TRUE (0 == 0)
#define FALSE (0 == 1)
#define VRAM        0x06000000
#define BCK_M5_VRAM 0x0600A000
#define REG_BG0CNT  0x04000008
#define REG_BG1CNT  0x0400000a
#define REG_BLDCNT  0x04000050
#define REG_BLDY    0x04000054
#define REG_JP      0x04000130
#define REG_DISPCNT *(uint16*)0x04000000
#define SetMode(Mode) REG_DISPCNT=(Mode)
#define MODE_3	    0x03	//   240*160 15bits
#define MODE_4	    0x04	//   240*160 8bits indexed palette
#define MODE_5	    0x05	//   160*128 15bits :-O	
#define BACKBUFFER  0x010	
#define BG2_ENABLE  0x0400
#define RGB(r,g,b) ((r)+((g)<<5)+((b)<<10))

void waitretrace(void);
void WaitVBlank (void);
void sleep(int x);
uint16 jp_getstate(void);
void Copy32 (int *src,int *dst,unsigned int nb);
void Clear32 (int *src,unsigned int nb);
void M3_PutPixel (int x,int y, uint16 color);
void M5_PutPixel (int x,int y, uint16 color);
void M5_DirtyDrawSprite (int x,int y,int w,int h,unsigned short *src,unsigned short *dst);
void VStretch (short *src, short *dst,int x,int y);
void SwapScreen (void);
int abs (int value);

uint16 *ActualVideoBuffer;

int main()
{
int u,v,alpha;
SetMode (MODE_5 | BG2_ENABLE);
ActualVideoBuffer = (uint16*)0x600A000;// BCK_M5_VRAM;


u =0;
v=0;
alpha =0;
while (1) 
  {
  u = 80 + ((80 * Cos [alpha])>>7);
  v = 64 + ((64 * Sin [alpha])>>7);    
  alpha+=4;
  if (alpha>359) alpha =0;
  VStretch(bump_bg,ActualVideoBuffer,u,v);
  M5_DirtyDrawSprite (0,107,60,20,logo,ActualVideoBuffer);
  WaitVBlank();
  SwapScreen ();
  }
  return(0);
}

/* returns joypad state */
uint16 jp_getstate(void)
{
  return(~*((uint16 *)REG_JP));
}

void waitretrace(void)
{
  while(!((*((volatile uint16 *)0x04000004) & (1<<0))));
  return;
}

/* 
 * sleep for a few vblanks just to slow this down on hardware
 */
void sleep(int x)
{
  for(;x;x--)
  {
    waitretrace();
    while(((*((volatile uint16 *)0x04000004) & (1<<0))));
  }
  return;
}

void M3_PutPixel (int x,int y, uint16 color)
{
ActualVideoBuffer[(y*240)+x] = color;
}

void M5_PutPixel (int x,int y, uint16 color)
{
ActualVideoBuffer[(y*160)+x] = color;
}

void Copy32 (int *src,int *dst,unsigned int nb)
{
unsigned int i=0;

for (i=0;i<nb;i++)
  {
  *dst= *src;
  dst++;
  src++;
  }
}

void Clear32 (int *src,unsigned int nb)
{
unsigned int i=0;

for (i=0;i<nb;i++)
  {
  *src=0;
  src++;
  }
}

void M5_DirtyDrawSprite (int x,int y,int w,int h,unsigned short *src,unsigned short *dst)
{
unsigned int i,o;
unsigned int idst;

idst =(y*160)+x;
for (i=0;i<h;i++)
  {
  for (o=0;o<w;o++)
    {
    if (*src != 0) 
      {
       dst [idst] = *src;
      } 
    idst++;
    src++;
    } 
  idst += (160-w);	// jmp next line
  }
}




int abs (int value)
{
if (value <0) return (value* -1);
else return (value);
}

void SwapScreen ()
{
if (REG_DISPCNT & BACKBUFFER)
  {
  
  REG_DISPCNT &= ~BACKBUFFER;
  ActualVideoBuffer = (uint16*) BCK_M5_VRAM;
  }
else
  {
  
  REG_DISPCNT |= BACKBUFFER;
  ActualVideoBuffer = (uint16*) VRAM;
  }
}

void WaitVBlank (void)
{
while (*(volatile uint16*)0x4000006<160) {};
}


void VStretch (short *src, short *dst,int x0,int y0)
{
int i,o,isrc,idst,x,y,dsrc;

dsrc =(y0*128)+x0;
idst =0;
for (i = 0;i<128;i++)
  {
  for (o=0;o<160;o++)
    {
    x = Sin [o+x0];
    y = Sin [i+y0]+x;
    isrc = ((y*128)+x+dsrc) & 16383;
    dst[idst] = src[isrc];
    idst++;
    }
  }
}

#ifdef __GNUC__
static void __gccmain() { }
#endif
