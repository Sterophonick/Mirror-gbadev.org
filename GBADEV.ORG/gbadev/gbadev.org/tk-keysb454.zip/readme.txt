TK-KEYS
Button tester demo for the GameBoy Advance
Written by: TeleKawaru

This is just a very simple demo to test the buttons on the GameBoy Advance.
It also has scrolling text. The source is included but undocumented. 
I will hopefully be able to document it and re-release the source.