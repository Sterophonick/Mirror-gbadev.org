// Yes, I know the code is terrible and undocumented, hopefully I can document it and reupload it or something.
// Sorry if this causes any confusion, I know I'm not a very organized coder!
// - TeleKawaru

#include "gba.h"
#include "opening.h"
#include "keys.h"

#define OAM     ((Sprite*)0x07000000)
#define START   1
#define SELECT  2
#define A       3
#define B       4
#define L       5
#define R       6
#define UP      7
#define DOWN    8
#define LEFT    9
#define RIGHT  10



typedef struct _Sprite { u16 Attrib0, Attrib1, Attrib2, RotateScale; } Sprite;

char scroll_text[]={"HERE IT IS: THE NEXT DEMO BY TELEKAWARU FOR THE GAMEBOY ADVANCE! THIS TIME WE ARE GOING BACK TO THE BASICS. IT'S JUST A SIMPLE BUTTON TESTER, BUT HEY, WE COULD ALWAYS USE ANOTHER OF THOSE! JUST A THANKS TO EVERBODY IN THE GBA DEV SCENE, THEIR DOCUMENTATION AND SOURCE CODE ARE JUST AMAZING HELP FOR PEOPLE WANTING TO GET STARTED IN GBA PROGRAMMING. ALSO, CHECK OUT HTTP://WWW.GBADEV.ORG FOR ALL YOUR GBA DEV NEEDS, THEY HAVE IT ALL! CHECK ME OUT ON THE WEB: HTTP://WWW.TELEKAWARU.COM OR EMAIL: TELEKAWARU@THEASYLUM.NET.. GREETS: UTSUKUSHII/JENNY: I LOVE YOU, AS ALWAYS, ZSKNIGHT: FOR BEING A GREAT FRIEND, HIPPOEATER/MIKE: IT WAS ALMOST TOO MUCH WORK TYPING THIS OUT FOR YOU, THE GUYS I WORK WITH IN THE TECH BENCH AT BEST BUY IN ELYRIA: MIKE BURNS, MIKE CIU, JOEL LARGE, PAUL DEMPSEY, LINDSEY DUTE, AND THE NEW GUYS... ALL MY FRIENDS ONLINE: GANGIS, DARKDAZE, PHAROS, STARCREATOR, STARFOX, CLGAMER, KAIDEN, GREENIMP, XSYKODAD, KMARX, SPICEONE, BATTOUSAI, VICVIPER, DUCKROLL, TOGEPY, GEECHYGUY, DOOMSTALK, KREED. ALSO SPECIAL GREETS: ALPHALUX/RYAN: YOU NEED TO GET OUT MORE OFTEN, DRIVEX/RYAN: NICE NIPPLE RINGS, ULTRA LAZER/MURDOCK/BEN: YOU'LL ALWAYS BE ULTRA LAZER TO ME! X/KARA: I BET YOU DIDN'T THINK YOU'D GET YOUR NAME IN A GBA ROM! IF I FORGOT ANYONE ELSE, I AM VERY SORRY! HRM, IT SEEMS AS THOUGH I AM RAMBLING, OH WELL, IT'S MY ROM ANYWAYS. ALRIGHT, I AM DONE HERE! LET'S LOOP THAT TEXT!"};

int strlen(char * ch){
  int i;
  i=0;
  while (*ch){
    i++;
    ch++;
  }
  return i;
}

// VSYNC function by Eloist
void WaitForVSync()
{
  __asm
   {
    mov 	r0, #0x4000006
    scanline_wait:
     ldrh	r1, [r0]
     cmp	r1, #160
    bne 	scanline_wait
   }
}

void ClearSprite(int i) {
    OAM[i].Attrib0=0;
    OAM[i].Attrib1=0;
    OAM[i].Attrib2=0;
}

void Draw_Text(int x, int z) {
  int i, charnum, sn;
  sn=12;
 if (z-14 <= 0) { z = 14; };
 for (i=z-14;i<z+1;i++) {
    if ((x+(i*8) < 180) && (x+(i*8)+8 > 70)) {
      charnum = (int)scroll_text[i];
      if (charnum < 65) {
        switch (charnum) {
          case 64: charnum = (int)'Z'+8; break;
          case 32: charnum = (int)'Z'+7; break;
          case 44: charnum = (int)'Z'+6; break;
          case 33: charnum = (int)'Z'+5; break;
          case 47: charnum = (int)'Z'+4; break;
          case 58: charnum = (int)'Z'+3; break;
          case 39: charnum = (int)'Z'+2; break;
          case 46: charnum = (int)'Z'+1; break;
        };
      };
      OAM[sn].Attrib0 = 64 | 0x2000;
      OAM[sn].Attrib1 = x+(i*8) & 0x1FF | 0x0000;
      OAM[sn].Attrib2 = ((charnum - 65)*2) + 10 | 0x0400;
      sn++;
    };
  }
}

void Draw_Keys(int key) {
switch (key) {
  case L:
    OAM[key].Attrib0 = 22 | 0x2000;
    OAM[key].Attrib1 = 22 | 0x4000;
    OAM[key].Attrib2 = 2 | 0x0000; 
    break;
  case R:
    OAM[key].Attrib0 = 18 | 0x2000;
    OAM[key].Attrib1 = 200 | 0x4000;
    OAM[key].Attrib2 = 2 | 0x0000; 
    break;
  case A:
    OAM[key].Attrib0 = 48 | 0x2000;
    OAM[key].Attrib1 = 206 | 0x4000;
    OAM[key].Attrib2 = 2 | 0x0000; 
    break;
  case B:
    OAM[key].Attrib0 = 55 | 0x2000;
    OAM[key].Attrib1 = 186 | 0x4000;
    OAM[key].Attrib2 = 2 | 0x0000; 
    break;
  case START:
    OAM[key].Attrib0 = 82 | 0x2000;
    OAM[key].Attrib1 = 41 | 0x4000;
    OAM[key].Attrib2 = 2 | 0x0000; 
    break;
  case SELECT:
    OAM[key].Attrib0 = 95 | 0x2000;
    OAM[key].Attrib1 = 40 | 0x4000;
    OAM[key].Attrib2 = 2 | 0x0000; 
    break;
  case UP:
    OAM[key].Attrib0 = 43 | 0x2000;
    OAM[key].Attrib1 = 27 | 0x4000;
    OAM[key].Attrib2 = 2 | 0x0000; 
    break;
  case DOWN:
    OAM[key].Attrib0 = 64 | 0x2000;
    OAM[key].Attrib1 = 26 | 0x4000;
    OAM[key].Attrib2 = 2 | 0x0000; 
    break;
  case LEFT:
    OAM[key].Attrib0 = 54 | 0x2000;
    OAM[key].Attrib1 = 15 | 0x4000;
    OAM[key].Attrib2 = 2 | 0x0000; 
    break;
  case RIGHT:
    OAM[key].Attrib0 = 54 | 0x2000;
    OAM[key].Attrib1 = 38 | 0x4000;
    OAM[key].Attrib2 = 2 | 0x0000; 
    break;
}
}

void Show_Intro ()
{

  int i, x, y, a, mos, x1, y1, timer[11], txtoff, txtchr, z;

  u16 *tpal=(u16*)0x05000000;
  u16 *textpal=(u16*)0x05000200;
  u8 *tiles=(u8*)0x06004000;
  u16 *map0=(u16*)0x06000000;
  u8 *text=(u8*)0x06010000;
  mos = 15;                      
  REG_BG0CNT =  0x00C4;
  REG_DISPCNT = 0x1140;


  for (i=0;i<openingPalLen;i++) {
    tpal[i]=openingPal[i];
  }
  
  for (i=0;i<keysPalLen;i++) {
    textpal[i]=keysPal[i];
  }
  
  for (i=0;i<openingDataLen;i++) {
    tiles[i]=openingData[i];
  }
 
  for (i=0;i<keysDataLen;i++) {
    text[i]=keysData[i];
  }

  REG_MOSAIC = mos | mos*16;  
  for (x=0;x<30;x++) {
    for (y=0;y<20;y++) {
      map0[y*32+x] = openingMap[y*30+x];
    }
  }

  for (i=15;i>0;i--) {
    for (a=0;a<120;a++) {
       WaitForVSync();
    }
    REG_MOSAIC = i | i*16;
  }
   REG_MOSAIC = 0;
  a=0;
  x=-140;
  y=20;
  x1=262;
  y1=100;
  txtoff=180;
  txtchr=0;
  while (a==0) {
    
    if (!(REG_P1 & J_L))   
    {
      Draw_Keys(L);
      REG_P1 |= J_L;
      timer[L]=20;
    }
    if (!(REG_P1 & J_R))   
    {
      Draw_Keys(R);
      REG_P1 |= J_R;
      timer[R]=20;
    }
    if (!(REG_P1 & J_A))   
    {
      Draw_Keys(A);
      REG_P1 |= J_A;
      timer[A]=20;
    }    
    if (!(REG_P1 & J_B))   
    {
      Draw_Keys(B);
      REG_P1 |= J_B;
      timer[B]=20;
    }
    if (!(REG_P1 & J_START))   
    {
      Draw_Keys(START);
      REG_P1 |= J_START;
      timer[START]=20;
    }
    if (!(REG_P1 & J_SELECT))   
    {
      Draw_Keys(SELECT);
      REG_P1 |= J_SELECT;
      timer[SELECT]=20;
    }
    if (!(REG_P1 & J_UP))   
    {
      Draw_Keys(UP);
      REG_P1 |= J_UP;
      timer[UP]=20;
    }
    if (!(REG_P1 & J_DOWN))   
    {
      Draw_Keys(DOWN);
      REG_P1 |= J_DOWN;
      timer[DOWN]=20;
    }
    if (!(REG_P1 & J_LEFT))   
    {
      Draw_Keys(LEFT);
      REG_P1 |= J_LEFT;
      timer[LEFT]=20;
    }
    if (!(REG_P1 & J_RIGHT))   
    {
      Draw_Keys(RIGHT);
      REG_P1 |= J_RIGHT;
      timer[RIGHT]=20;
    }
    for (i=1;i<11;i++) {
    if (timer[i]==0) { ClearSprite(i); };
    if (timer[i]>0) { timer[i]--; };
  }
  Draw_Text(txtoff, txtchr);
  WaitForVSync();
  txtoff--; 
  z++;
  if (z == 8) {
    txtchr++;
    z=0;
  }
  if (txtoff < (62-(strlen(scroll_text)*8))) {
    txtoff=180;
    z=0;
    txtchr=0;
  };
  };

}

void C_Entry()
{
Show_Intro();
}