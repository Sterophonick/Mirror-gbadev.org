/* 
* Blowhole (Game Boy Advance puzzler) - sprites_specs.c
* Description: Definitions, global variables, and functions pertaining
*    to sprites
* License: Copyright (C) 2002 Lance Legan, Something Screwy Productions;
*    This file is part of Blowhole.
*
*    Blowhole is free software; you can redistribute it and/or modify
*    it under the terms of the GNU General Public License as published by
*    the Free Software Foundation; either version 2 of the License, or
*    (at your option) any later version.
*
*    Blowhole is distributed in the hope that it will be useful,
*    but WITHOUT ANY WARRANTY; without even the implied warranty of
*    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
*    GNU General Public License for more details.
*
*    You should have received a copy of the GNU General Public License
*    along with Blowhole; if not, write to the Free Software
*    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
*
*    The GNU GPL can be found online at: http://www.gnu.org/licenses/
*    Blowhole can be found online at: http://www.somethingscrewy.com/
*/

//Dependencies: include gba.h, sprites.h before this file

#ifndef SPRITES_SPECS_C
#define SPRITES_SPECS_C

//definitions:
typedef enum Direction { UP, DOWN, LEFT, RIGHT } Direction;

typedef struct tagAnimatedSprite {
   u16 x;			   //x position on screen
   u16 y;                          //y position on screen
   bool flipped;                   //false = facing left, true = facing right
   Direction direction;            //direction sprite is moving
   u8 spriteCollision[16][8];      //sprite collision map
   int activeFrame;                //which frame is active
   u16 spriteFrame[4];             //offset from OAMdata to get to each frame
   int frames;                     //number of frames in animation
   int squaresize;                 //pixel size of sprite, 16x16 = 16
   u16 OAMSpriteNum;               //sprite number in OAM
} AnimatedSprite;


//global variables:
AnimatedSprite blowhole;
OAMEntry mysprites[128];
u16 *myOAM = (u16*)OAMmem;
u16 *myOBJPaletteMem = (u16*)OBJPaletteMem;
u16 *myOAMdata = (u16*)OAMdata;


//functions (with an explanation preceding each):
/*
* InitializeSprites() sets all sprites in OAM offscreen to prevent 
* a screen artifact.
*/
void InitializeSprites()
{
   u16 i;
   for (i = 0; i < 128; i++) {
      mysprites[i].attribute0 = 160;
      mysprites[i].attribute1 = 240;
   }
}

/*
* InitSpriteFrames(AnimatedSprite*) initializes each spriteFrame[]
* entry based on the sprite's size and number of frames.
*/
void InitSpriteFrames(AnimatedSprite *sprite)
{
   u16 i;
   sprite->activeFrame = 0;
   for (i = 0; i < sprite->frames; i++)
      sprite->spriteFrame[i] = ((sprite->squaresize / 8) * (sprite->squaresize / 8) * 2 * i);
}

/*
* LoadSpriteData(const u16[], u16, u16) loads a sprite frame graphic into
* the appropriate place in OAMdata given the graphic's data, the sprite's 
* size, and which frame to load.
*/
void LoadSpriteData(const u16 data[], u16 size, u16 frame)
{
   u16 i;
   for (i = ((size * size / 2) * frame); i < ((size * size / 2) * (frame + 1)); i++)
         myOAMdata[i] = data[i - ((size * size / 2) * frame)];   // writes 16 bits at a time
}

/*
* Animate(AnimatedSprite*) changes the active/displayed sprite frame to
* the next frame in the animation sequence.
*/
void Animate(AnimatedSprite *sprite)
{
   sprite->activeFrame = (++sprite->activeFrame) % sprite->frames;
   mysprites[sprite->OAMSpriteNum].attribute2 = sprite->spriteFrame[sprite->activeFrame];
}

/*
* MoveSprite(AnimatedSprite) changes the sprite attribute position values
* to move the sprite on screen based on the sprite's x and y members 
* which are updated by GetGameInput().
*/
void MoveSprite(AnimatedSprite *sprite)
{
   mysprites[sprite->OAMSpriteNum].attribute0 = (mysprites[sprite->OAMSpriteNum].attribute0) & 0xFF00;
   mysprites[sprite->OAMSpriteNum].attribute0 = (mysprites[sprite->OAMSpriteNum].attribute0) | sprite->y;
   mysprites[sprite->OAMSpriteNum].attribute1 = (mysprites[sprite->OAMSpriteNum].attribute1) & 0xFE00;
   mysprites[sprite->OAMSpriteNum].attribute1 = (mysprites[sprite->OAMSpriteNum].attribute1) | sprite->x;
}

/*
* CopyOAM() copies all the sprites' current attributes to OAM.
*/
void CopyOAM()
{
   u16 i;
   u16 *temp;
   temp = (u16*)mysprites;             // Each sprite in OAM uses 8 bytes,
   for (i = 0; i < 128 * 4; i++)       // writing 16 bits per loop for 128
      myOAM[i] = temp[i];              // sprites (4 * 16 bits = 8 bytes)
}

/*
* MoveSpriteOffscreen(AnimatedSprite*) immediately moves the sprite off
* the screen.
*/
void MoveSpriteOffscreen(AnimatedSprite *sprite)
{
   mysprites[sprite->OAMSpriteNum].attribute0 = (mysprites[sprite->OAMSpriteNum].attribute0) & 0xFF00;
   mysprites[sprite->OAMSpriteNum].attribute0 = (mysprites[sprite->OAMSpriteNum].attribute0) | 160;
   mysprites[sprite->OAMSpriteNum].attribute1 = (mysprites[sprite->OAMSpriteNum].attribute1) & 0xFE00;
   mysprites[sprite->OAMSpriteNum].attribute1 = (mysprites[sprite->OAMSpriteNum].attribute1) | 240;
   WaitForVblank();
   CopyOAM();
}

#endif

