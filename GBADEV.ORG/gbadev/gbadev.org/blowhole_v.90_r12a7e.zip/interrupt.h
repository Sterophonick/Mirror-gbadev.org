/* 
* Blowhole (Game Boy Advance puzzler) - interrupt.h
* Modified by Lance from a tutorial by dovoto (see PROPS.txt file)
* Description: Definitions to control interrupts
* License: Public Domain - this file may be used and redistributed 
*    as desired (see PUBLIC.txt file)
*
*    Blowhole can be found online at: http://www.somethingscrewy.com/
*/

#ifndef INTERRUPT_H
#define INTERRUPT_H

//REG_IE and REG_IF flags for each interrupt
#define INT_VBLANK         0x0001
#define INT_HBLANK         0x0002 
#define INT_VCOUNT         0x0004
#define INT_TIMER0         0x0008
#define INT_TIMER1         0x0010
#define INT_TIMER2         0x0020 
#define INT_TIMER3         0x0040
#define INT_COMMUNICATION  0x0080
#define INT_DMA0           0x0100
#define INT_DMA1           0x0200
#define INT_DMA2           0x0400
#define INT_DMA3           0x0800
#define INT_KEYPAD         0x1000
#define INT_CART           0x2000
#define INT_ALL            0x4000

#endif

