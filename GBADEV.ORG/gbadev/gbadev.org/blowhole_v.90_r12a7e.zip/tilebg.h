/* 
* Blowhole (Game Boy Advance puzzler) - tilebg.h
* Modified by Lance from a tutorial by dovoto (see PROPS.txt file)
* Description: Definitions for tile/map backgrounds
* License: Public Domain - this file may be used and redistributed 
*    as desired (see PUBLIC.txt file)
*
*    Blowhole can be found online at: http://www.somethingscrewy.com/
*/

#ifndef TILEBG_H
#define TILEBG_H

//REG_BGxCNT flags
#define BG_MOSAIC_ENABLE   0x0040
#define BG_COLOR_256       0x0080
#define BG_COLOR_16        0x0000

#define TEXTBG_SIZE_256x256   0x0000
#define TEXTBG_SIZE_256x512   0x8000
#define TEXTBG_SIZE_512x256   0x4000
#define TEXTBG_SIZE_512x512   0xC000

#define ROTBG_SIZE_128x128    0x0000
#define ROTBG_SIZE_256x256    0x4000
#define ROTBG_SIZE_512x512    0x8000
#define ROTBG_SIZE_1024x1024  0xC000

#define WRAPAROUND 0x2000

/*
* The following simplify the determining of base blocks according to these formulae:
* 16k * number + start of VRAM = address of character base block
* 2k * number + start of VRAM = address of screen base block
*/
#define CharBaseBlock(n) (((n)*0x4000)+0x6000000)
#define ScreenBaseBlock(n) (((n)*0x800)+0x6000000)

//used to shift the number over to the right place in REG_BGxCNT
#define CHAR_SHIFT 2
#define SCREEN_SHIFT 8

//background structure
typedef struct tagTileBg
{
   u16* tileData;         //set in EnableBackground() according to charBaseBlock
   u16* mapData;          //set in EnableBackground() according to screenBaseBlock
   u8 mosaic;             //BG_MOSIAC_ENABLE, disable = 0
   u8 colorMode;          //BG_COLOR_256 or BG_COLOR_16
   u8 number;             //background number (0-3) 
   u16 size;              //TEXTBG_SIZE_*x* or ROTBG_SIZE_*x* as defined above
   u8 charBaseBlock;      //0-3, each is 16k
   u8 screenBaseBlock;    //0-31, each is 2k, overlaps character base blocks
   u8 bgpriority;         //0-3, higher priority is drawn first
   u8 wraparound;         //wraparound flag, WRAPAROUND enables
   s16 x_scroll,y_scroll; //horizontal and vertical offsets for text backgrounds
   s32 DX,DY;             //scroll for rotation backgrounds
   s16 PA,PB,PC,PD;       //rotation attributes for the background
}TileBg, *pTileBg;

#endif

