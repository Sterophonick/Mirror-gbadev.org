/* 
* Blowhole (Game Boy Advance puzzler) - mapmanip_specs.c
* Description: Definitions, global variables, and functions pertaining
*    to manipulating the game tile map
* License: Copyright (C) 2002 Lance Legan, Something Screwy Productions;
*    This file is part of Blowhole.
*
*    Blowhole is free software; you can redistribute it and/or modify
*    it under the terms of the GNU General Public License as published by
*    the Free Software Foundation; either version 2 of the License, or
*    (at your option) any later version.
*
*    Blowhole is distributed in the hope that it will be useful,
*    but WITHOUT ANY WARRANTY; without even the implied warranty of
*    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
*    GNU General Public License for more details.
*
*    You should have received a copy of the GNU General Public License
*    along with Blowhole; if not, write to the Free Software
*    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
*
*    The GNU GPL can be found online at: http://www.gnu.org/licenses/
*    Blowhole can be found online at: http://www.somethingscrewy.com/
*/

//Dependencies: include gba.h, blowhole.h, sprites.h, sprites_specs.c, 
//   collision_specs.c before this file

#ifndef MAPMANIP_SPECS_C
#define MAPMANIP_SPECS_C

//definitions:
void WaitForVblank();
void DMACopy(u16 *source, u16 *dest, u32 WordCount, u32 mode);


//global variables:
u8 pearlsCollected = 0, pearlsTotal;
u8 currentlevel[10][15];


//functions (with an explanation preceding each):
/*
* CountPearls(u8[][]) takes a level in the Blowhole standard level format
* (see levels_data.h) and counts the number of yellow pearls in it,
* storing the total in pearlsTotal.
*/
void CountPearls(u8 level[10][15])
{
  u8 i, j;
  pearlsTotal = 0;
  for (j = 0; j < 10; j++) {
     for (i = 0; i < 15; i++) {
        if (level[j][i] == PEARL)
           pearlsTotal++;
     }
  }
}

/*
* CollectPearl() uses the blowhole sprite members and a level's collision 
* map (see collision_specs.cpp) to double check if a specific pixel of the 
* sprite is touching a yellow pearl, and then collects the pearl from the map,
* changing the map and incrementing pearlsCollected appropriately.  I have 
* only commented the first case because the rest of the cases follow the 
* same idea.
*/
void CollectPearl()
{
   u16 xlevel, ylevel;
   u16 *temp = (u16*)currentmap;
   
   switch(blowhole.direction) {
      case UP:                                 //sprite is moving up
         if (!blowhole.flipped) {
            xlevel = ((blowhole.x + 5) >> 4);  //translate a pixel in sprite's screen position to a level map position
            if (blowhole.y < 151) {            //if the sprite is on the screen and not touching a pearl, break
               if ((collisionmap[blowhole.y + 4][(blowhole.x + 5) >> 1] & 0x0F) != PEARL)
                  break;
            }
         }
         else {                                //if sprite is not flipped, use a different xlevel translation
            xlevel = ((blowhole.x + 10) >> 4); //translate a pixel in sprite's screen position to a level map position
            if (blowhole.y < 151) {            //if the sprite is on the screen and not touching a pearl, break
               if ((collisionmap[blowhole.y + 4][(blowhole.x + 10) >> 1] & 0x0F) != PEARL)
                  break;
            }
         }
         if (blowhole.y > 150)                 //if sprite is off the screen vertically, break
            break;
         ylevel = ((blowhole.y + 4) >> 4);     //translate a pixel in sprite's screen position to a level map position
         currentlevel[ylevel][xlevel] = WATER; //change the pearl tile to a water tile
         pearlsCollected++;                    //note the pearl was collected
         RenderLevelMap(currentlevel);         //rerender the level map
         WaitForVblank();                      //DMA new map into appropriate screen base block
         DMACopy(temp, gametiles.mapData, 512, DMA_16NOW);
         RenderCollisionMap(currentlevel);     //rerender the collision map
         break;                                //success!
      case DOWN:
         if (!blowhole.flipped) {
            xlevel = ((blowhole.x + 4) >> 4);
            if (blowhole.y < 146) {
               if ((collisionmap[blowhole.y + 14][(blowhole.x + 4) >> 1] & 0x0F) != PEARL)
                  break;
            }
         }
         else {
            xlevel = ((blowhole.x + 11) >> 4);
            if (blowhole.y < 146) {
               if ((collisionmap[blowhole.y + 14][(blowhole.x + 11) >> 1] & 0x0F) != PEARL)
                  break;
            }
         }
         if (blowhole.y > 145 && blowhole.y < 247)
            break;
         if (blowhole.y > 246) {
            if ((collisionmap[7][(blowhole.x + 4) >> 1] & 0x0F) != PEARL)
               break;
            ylevel = 0;
         }
         else
            ylevel = ((blowhole.y + 14) >> 4);
         currentlevel[ylevel][xlevel] = WATER;
         pearlsCollected++;
         RenderLevelMap(currentlevel);
         WaitForVblank();
         DMACopy(temp, gametiles.mapData, 512, DMA_16NOW);
         RenderCollisionMap(currentlevel);
         break;
      case LEFT:
         if (blowhole.x < 231) {
            if ((collisionmap[blowhole.y + 9][blowhole.x >> 1] & 0x0F) != PEARL)
               break;
         }
         if (blowhole.x > 230)
            break;
         xlevel = ((blowhole.x) >> 4);
         ylevel = ((blowhole.y + 9) >> 4);
         currentlevel[ylevel][xlevel] = WATER;
         pearlsCollected++;
         RenderLevelMap(currentlevel);
         WaitForVblank();
         DMACopy(temp, gametiles.mapData, 512, DMA_16NOW);
         RenderCollisionMap(currentlevel);
         break;
      case RIGHT:
         if (blowhole.x < 224) {
            if ((collisionmap[blowhole.y + 9][(blowhole.x + 15) >> 1] & 0x0F) != PEARL)
               break;
         }
         if (blowhole.x > 223 && blowhole.x < 503)
            break;
         if (blowhole.x > 502) {
            if ((collisionmap[blowhole.y + 9][7] & 0x0F) != PEARL)
               break;
            xlevel = 0;
         }
         else
            xlevel = ((blowhole.x + 15) >> 4);
         ylevel = ((blowhole.y + 9) >> 4);
         currentlevel[ylevel][xlevel] = WATER;
         pearlsCollected++;
         RenderLevelMap(currentlevel);
         WaitForVblank();
         DMACopy(temp, gametiles.mapData, 512, DMA_16NOW);
         RenderCollisionMap(currentlevel);
         break;
   }
}

/*
* HitFish() uses the blowhole sprite members and a level's collision 
* map (see collision_specs.cpp) to double check if a specific pixel of the 
* sprite is touching a school of fish.  It then moves the school of fish 
* across the screen until it hits rocks or a net, and reacts accordingly.
* I have only commented the first case because the rest of the cases 
* follow the same idea.
*/
void HitFish()
{
   u16 xlevel, ylevel, nexttile;
   bool sidecollide = false, stopcollide = false, netcollide = false;
   u16 *temp = (u16*)currentmap;
   
   switch(blowhole.direction) {
      case UP:                                 //sprite is moving up
         if (!blowhole.flipped) {
            xlevel = ((blowhole.x + 5) >> 4);  //translate a pixel in sprite's screen position to a level map position
            if ((collisionmap[blowhole.y + 4][(blowhole.x + 5) >> 1] & 0x0F) != FISH)
               break;                          //double check collision, break if necessary
         }
         else {                                //if sprite is not flipped, use a different xlevel translation
            xlevel = ((blowhole.x + 10) >> 4); //translate a pixel in sprite's screen position to a level map position
            if ((collisionmap[blowhole.y + 4][(blowhole.x + 10) >> 1] & 0x0F) != FISH)
               break;                          //double check collision, break if necessary
         }
         ylevel = ((blowhole.y + 4) >> 4);     //translate a pixel in sprite's screen position to a level map position
         nexttile = currentlevel[ylevel - 1][xlevel]; //find what the next tile is so we can check collision for the moving fish
         if (ylevel == 0)                      //test for collision with top of screen
            sidecollide = true;
         else if (nexttile == NET)             //test for collision with a net
            netcollide = true;
         else if (nexttile == ROCKS || nexttile == FISH) //test for collision with rocks or another school of fish
            stopcollide = true;
         while (!stopcollide) {                //while no rock or school of fish collision
            if (netcollide) {                  //if collision with a net
               currentlevel[ylevel - 1][xlevel] = WATER;
               stopcollide = true;
            }
            else if (sidecollide)              //if fish movement has been stopped
               stopcollide = true;
            else                               // else move the fish to the next spot on the map
               currentlevel[ylevel - 1][xlevel] = FISH;
            currentlevel[ylevel][xlevel] = WATER;
            RenderLevelMap(currentlevel);      //rerender the level map
            RenderCollisionMap(currentlevel);  //rerender the collision map (provides some delay to slow down block movement)
            WaitForVblank();                   //DMA new map into appropriate screen base block
            DMACopy(temp, gametiles.mapData, 512, DMA_16NOW);
            ylevel--;                          //change index to next tile up
            nexttile = currentlevel[ylevel - 1][xlevel];
            if (ylevel == 0)                   //do similar tests as above to determine what to do on next iteration of loop
               sidecollide = true;
            else if (nexttile == NET)
               netcollide = true;
            else if (nexttile == ROCKS || nexttile == FISH)
               stopcollide = true;
         }
         break;                                //after everything is keen, break
      case DOWN:
         if (!blowhole.flipped) {
            xlevel = ((blowhole.x + 4) >> 4);
            if ((collisionmap[blowhole.y + 14][(blowhole.x + 4) >> 1] & 0x0F) != FISH)
               break;
         }
         else {
            xlevel = ((blowhole.x + 11) >> 4);
            if ((collisionmap[blowhole.y + 14][(blowhole.x + 11) >> 1] & 0x0F) != FISH)
               break;
         }
         ylevel = ((blowhole.y + 14) >> 4);
         nexttile = currentlevel[ylevel + 1][xlevel];
         if (ylevel == 9)
            sidecollide = true;
         else if (nexttile == NET)
            netcollide = true;
         else if (nexttile == ROCKS || nexttile == FISH)
            stopcollide = true;
         while (!stopcollide) {
            if (netcollide) {
               currentlevel[ylevel + 1][xlevel] = WATER;
               stopcollide = true;
            }
            else if (sidecollide)
               stopcollide = true;
            else
               currentlevel[ylevel + 1][xlevel] = FISH;
            currentlevel[ylevel][xlevel] = WATER;
            RenderLevelMap(currentlevel);
            RenderCollisionMap(currentlevel);
            WaitForVblank();
            DMACopy(temp, gametiles.mapData, 512, DMA_16NOW);
            ylevel++;
            nexttile = currentlevel[ylevel + 1][xlevel];
            if (ylevel == 9)
               sidecollide = true;
            else if (nexttile == NET)
               netcollide = true;
            else if (nexttile == ROCKS || nexttile == FISH)
               stopcollide = true;
         }
         break;
      case LEFT:
         if ((collisionmap[blowhole.y + 9][blowhole.x >> 1] & 0x0F) != FISH)
            break;
         xlevel = ((blowhole.x) >> 4);
         ylevel = ((blowhole.y + 9) >> 4);
         nexttile = currentlevel[ylevel][xlevel - 1];
         if (xlevel == 0)
            sidecollide = true;
         else if (nexttile == NET)
            netcollide = true;
         else if (nexttile == ROCKS || nexttile == FISH)
            stopcollide = true;
         while (!stopcollide) {
            if (netcollide) {
               currentlevel[ylevel][xlevel - 1] = WATER;
               stopcollide = true;
            }
            else if (sidecollide)
               stopcollide = true;
            else
               currentlevel[ylevel][xlevel - 1] = FISH;
            currentlevel[ylevel][xlevel] = WATER;
            RenderLevelMap(currentlevel);
            RenderCollisionMap(currentlevel);
            WaitForVblank();
            DMACopy(temp, gametiles.mapData, 512, DMA_16NOW);
            xlevel--;
            nexttile = currentlevel[ylevel][xlevel - 1];
            if (xlevel == 0)
               sidecollide = true;
            else if (nexttile == NET)
               netcollide = true;
            else if (nexttile == ROCKS || nexttile == FISH)
               stopcollide = true;
         }
         break;
      case RIGHT:
         if ((collisionmap[blowhole.y + 9][(blowhole.x + 15) >> 1] & 0x0F) != FISH)
            break;
         xlevel = ((blowhole.x + 15) >> 4);
         ylevel = ((blowhole.y + 9) >> 4);
         nexttile = currentlevel[ylevel][xlevel + 1];
         if (xlevel == 14)
            sidecollide = true;
         else if (nexttile == NET)
            netcollide = true;
         else if (nexttile == ROCKS || nexttile == FISH)
            stopcollide = true;
         while (!stopcollide) {
            if (netcollide) {
               currentlevel[ylevel][xlevel + 1] = WATER;
               stopcollide = true;
            }
            else if (sidecollide)
               stopcollide = true;
            else
               currentlevel[ylevel][xlevel + 1] = FISH;
            currentlevel[ylevel][xlevel] = WATER;
            RenderLevelMap(currentlevel);
            RenderCollisionMap(currentlevel);
            WaitForVblank();
            DMACopy(temp, gametiles.mapData, 512, DMA_16NOW);
            xlevel++;
            nexttile = currentlevel[ylevel][xlevel + 1];
            if (xlevel == 14)
               sidecollide = true;
            else if (nexttile == NET)
               netcollide = true;
            else if (nexttile == ROCKS || nexttile == FISH)
               stopcollide = true;
         }
         break;
   }
}

#endif

