/* 
* Blowhole (Game Boy Advance puzzler) - tilebg.h
* Modified by Lance from a tutorial by dovoto (see PROPS.txt file)
* Description: Definitions to access the GBA buttons
* License: Public Domain - this file may be used and redistributed 
*    as desired (see PUBLIC.txt file)
*
*    Blowhole can be found online at: http://www.somethingscrewy.com/
*/

#ifndef KEYPAD_H
#define KEYPAD_H

//Key definitions
#define KEY_A       0x0001
#define KEY_B       0x0002
#define KEY_SELECT  0x0004
#define KEY_START   0x0008
#define KEY_RIGHT   0x0010
#define KEY_LEFT    0x0020
#define KEY_UP      0x0040
#define KEY_DOWN    0x0080
#define KEY_R       0x0100
#define KEY_L       0x0200

//Defined as REG_P1 in gba.h
#define KEYS        (*(volatile u16*)0x4000130)

/*
* To check if a key is pressed, do as follows:
* KEY_PRESS(KEY_A) returns true when A is pressed
*/
#define KEY_PRESS(k)   (!((KEYS) & k))

#endif

