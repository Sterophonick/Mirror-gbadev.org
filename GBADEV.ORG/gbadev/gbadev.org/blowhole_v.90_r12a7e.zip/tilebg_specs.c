/* 
* Blowhole (Game Boy Advance puzzler) - tilebg_specs.c
* Description: Definitions, global variables, and functions pertaining
*    to tile backgrounds
* License: Copyright (C) 2002 Lance Legan, Something Screwy Productions;
*    This file is part of Blowhole.
*
*    Blowhole is free software; you can redistribute it and/or modify
*    it under the terms of the GNU General Public License as published by
*    the Free Software Foundation; either version 2 of the License, or
*    (at your option) any later version.
*
*    Blowhole is distributed in the hope that it will be useful,
*    but WITHOUT ANY WARRANTY; without even the implied warranty of
*    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
*    GNU General Public License for more details.
*
*    You should have received a copy of the GNU General Public License
*    along with Blowhole; if not, write to the Free Software
*    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
*
*    The GNU GPL can be found online at: http://www.gnu.org/licenses/
*    Blowhole can be found online at: http://www.somethingscrewy.com/
*/

//Dependencies: include gba.h, tilebg.h before this file

#ifndef TILEBG_SPECS_C
#define TILEBG_SPECS_C

//definitions:


//global variables:
u16 *myBGPaletteMem = (u16*)BGPaletteMem;
u16 *myTileData0 = (u16*)CharBaseBlock(0);
u16 *myTileData1 = (u16*)CharBaseBlock(1);
TileBg textscreen;
TileBg title;
TileBg gametiles;
u8 currentmap[32][32];


//functions (with an explanation preceding each):
/*
* EnableBackground(TileBg*) sets the appropriate members of the background
* passed to it, and turns the background on in the necessary hardware 
* registers.
*/
void EnableBackground(TileBg *bg)
{
   u16 temp;
   bg->tileData = (u16*)CharBaseBlock(bg->charBaseBlock);
   bg->mapData = (u16*)ScreenBaseBlock(bg->screenBaseBlock);
   temp = bg->size | (bg->charBaseBlock<<CHAR_SHIFT) | (bg->screenBaseBlock<<SCREEN_SHIFT) | bg->colorMode | bg->mosaic | bg->bgpriority;
   switch (bg->number) {
      case 0:
         REG_BG0CNT = temp;
         REG_DISPCNT |= BG0_ENABLE;
         break;
      case 1:
         REG_BG1CNT = temp;
         REG_DISPCNT |= BG1_ENABLE;
         break;
      case 2:
         REG_BG2CNT = temp;
         REG_DISPCNT |= BG2_ENABLE;
         break;
      case 3:
         REG_BG3CNT = temp;
         REG_DISPCNT |= BG3_ENABLE;
         break;
      default:
         break;
   }
}

/*
* DisableBackground(TileBg*) turns the background off in the necessary
* hardware registers.
*/
void DisableBackground(TileBg *bg)
{
   switch (bg->number) {
      case 0:
         REG_DISPCNT &= BG0_DISABLE;
         break;
      case 1:
         REG_DISPCNT &= BG1_DISABLE;
         break;
      case 2:
         REG_DISPCNT &= BG2_DISABLE;
         break;
      case 3:
         REG_DISPCNT &= BG3_DISABLE;
         break;
      default:
         break;
   }
}

/*
* PrintNumber(u8, TileBg*, u8, u8) prints a passed number (1 or 2 digit)
* on the screen given a text background to print it on, and a position.
*/
void PrintNumber(u8 number, TileBg *bg, u8 xpos, u8 ypos)
{
   u16 x = xpos, y = ypos;
   u16 MSD = 0, LSD = 0;               //Most and Least Significant Digit
   if (number > 9) {                   //if the number is double digit,
      while ((MSD * 10) <= number)     //determine each digit
         MSD++;
      MSD--;
      while ((LSD + MSD * 10) != number)
         LSD++;
      bg->mapData[x + y * 32] = MSD + 0x0023;
      x++;
      bg->mapData[x + y * 32] = LSD + 0x0023;
   }
   else {
      bg->mapData[x + y * 32] = 0x0023;  //0x0023 is a zero in the tileset
      x++;
      bg->mapData[x + y * 32] = number + 0x0023;
   }
}

/*
* PrintText(char*, TileBg*, u8, u8) prints a string of text on the
* screen given a pointer to an appropiately formatted text string,
* a text background to print it on, and a position.
* The text string should be formatted using \n for a newline with
* carriage return and \t to denoted the end of the string.
*/
void PrintText(char *text, TileBg *bg, u8 xpos, u8 ypos)
{
   u16 x = xpos, y = ypos;
   u16 i;
   bool endofstring = false;
   for (i = 0; i < 640; i++)     //clear the background
      bg->mapData[i] = 0x0072;
   i = 0;
   while (!endofstring) {
      switch (text[i]) {
         case ' ':
            bg->mapData[x + y * 32] = 0x0072;
            x++;
            break;
         case '\n':
            y++;
            x = xpos;
            break;
         case '\t':
            endofstring = true;
            break;
         default:
            bg->mapData[x + y * 32] = (text[i] - 0x0D);  // value 0x0D adjusts from ascii
            x++;                                         // to the correct map position
            break;
      }
      i++;
   }
   for (i = x + y * 32; i < 640; i++)     //blank the remainder of the screen
      bg->mapData[i] = 0x0072;            //to prevent artifacts
}

/*
* RenderLevelmap(u8[][]) takes a level in the Blowhole standard
* level format (see levels_data.h) and converts it to a screen map
* corresponding to the correct tiles.
*/
void RenderLevelMap(u8 level[10][15])
{
   u16 x, y;

   for (y = 0; y < 10; y++) {
      for (x = 0; x < 15; x++) {
         switch(level[y][x]) {
            case 0:                                 //water
               currentmap[y * 2][x * 2] = 0x00;
               currentmap[y * 2][x * 2 + 1] = 0x01;
               currentmap[y * 2 + 1][x * 2] = 0x0A;
               currentmap[y * 2 + 1][x * 2 + 1] = 0x0B;
               break;
            case 1:                                 //rocks
               currentmap[y * 2][x * 2] = 0x02;
               currentmap[y * 2][x * 2 + 1] = 0x03;
               currentmap[y * 2 + 1][x * 2] = 0x0C;
               currentmap[y * 2 + 1][x * 2 + 1] = 0x0D;
               break;
            case 2:                                 //net
               currentmap[y * 2][x * 2] = 0x04;
               currentmap[y * 2][x * 2 + 1] = 0x05;
               currentmap[y * 2 + 1][x * 2] = 0x0E;
               currentmap[y * 2 + 1][x * 2 + 1] = 0x0F;
               break;
            case 3:                                 //yellow pearl
               currentmap[y * 2][x * 2] = 0x06;
               currentmap[y * 2][x * 2 + 1] = 0x07;
               currentmap[y * 2 + 1][x * 2] = 0x10;
               currentmap[y * 2 + 1][x * 2 + 1] = 0x11;
               break;
            case 4:                                 //school of fish
               currentmap[y * 2][x * 2] = 0x08;
               currentmap[y * 2][x * 2 + 1] = 0x09;
               currentmap[y * 2 + 1][x * 2] = 0x12;
               currentmap[y * 2 + 1][x * 2 + 1] = 0x13;
               break;
            case 5:                                 //character start location
               currentmap[y * 2][x * 2] = 0x00;
               currentmap[y * 2][x * 2 + 1] = 0x01;
               currentmap[y * 2 + 1][x * 2] = 0x0A;
               currentmap[y * 2 + 1][x * 2 + 1] = 0x0B;
               blowhole.x = x * 16;
               blowhole.y = y * 16;
               level[y][x] = 0;
               break;
         }
      }
   }
}

#endif

