/* 
* Blowhole (Game Boy Advance puzzler) - blowhole.c
* Description: The central source file with AgbMain() function
* License: Copyright (C) 2002 Lance Legan, Something Screwy Productions;
*    This file is part of Blowhole.
*
*    Blowhole is free software; you can redistribute it and/or modify
*    it under the terms of the GNU General Public License as published by
*    the Free Software Foundation; either version 2 of the License, or
*    (at your option) any later version.
*
*    Blowhole is distributed in the hope that it will be useful,
*    but WITHOUT ANY WARRANTY; without even the implied warranty of
*    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
*    GNU General Public License for more details.
*
*    You should have received a copy of the GNU General Public License
*    along with Blowhole; if not, write to the Free Software
*    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
*
*    The GNU GPL can be found online at: http://www.gnu.org/licenses/
*    Blowhole can be found online at: http://www.somethingscrewy.com/
*/

/*
* Standard *.h header files contain universal GBA defines and macros.
*/
#include "gba.h"
#include "dispcnt.h"
#include "sprites.h"
#include "tilebg.h"
#include "keypad.h"
#include "dma.h"
#include "interrupt.h"

typedef u8 bool;     //ANSI C does not inherently have a bool type
#define true 1
#define false 0

/*
* All *_specs.c files contain program specific definitions, global
* variable declarations, and functions, all of which pertain to the 
* related topic of the filename.
*/
#include "sprites_specs.c"
#include "tilebg_specs.c"
#include "collision_specs.c"
#include "mapmanip_specs.c"
#include "interrupt_specs.c"

/*
* All *_data.h files contain data pertaining to the related topic
* of the filename.
*/
#include "titlescreen_data.h"
#include "titlemap_data.h"
#include "levels_data.h"
#include "sprites_data.h"
#include "tilebg_data.h"
#include "collision_data.h"

#define CART_SRAM 0x0e000000         //Visoly flash cartridge SRAM address

int __gba_multiboot;                 //compile for multiboot mode
u16 *myVideoBuffer = (u16*)VideoBuffer;
u8 *saveCheckptr = (u8*)CART_SRAM;
u8 *saveSpotptr = (u8*)(CART_SRAM + 1);
u8 *saveStartptr = (u8*)(CART_SRAM + 2);

//Some necessary global variables
u8 movement = 0;
u8 startLevel, highestLevel;
bool paused, stoplevel;

/*
* SoftReset() completely resets the game, branching to the address where
* where the game code begins.  The address needs to be 0x08000000 if this 
* is not compiled in multiboot mode.
*/
void SoftReset()
{
   __asm__
   (
      "ResetAddress: .word 0x02000000\n\t"
      "ldr r0, ResetAddress\n\t"
      "bx r0\n\t"
   );
}

/*
* WaitForVblank() returns when a Vblank occurs or is currently
* occuring.  When the value of the vertical trace counter at
* 0x4000006 equals 160, there is a Vblank.
*/
void WaitForVblank()
{
   __asm__
   (
      "VertTraceCtr: .word 0x4000006\n\t"
      "ldr r0, VertTraceCtr\n\t"
      "scanline_wait:\n\t"
         "ldrh r1, [r0]\n\t"
         "cmp r1, #160\n\t"
         "bne scanline_wait\n\t"
      :                          //output registers
      :                          //input registers
      : "r0", "r1"               //clobbered registers
   );

}

/*
* DMACopy(u16*, u16*, u32, u32) performs a DMA0 transfer according to the
* parameters passed.
*/
void DMACopy(u16 *source, u16 *dest, u32 wordCount, u32 mode)
{
   REG_DM0SAD = (u32)source;
   REG_DM0DAD = (u32)dest;
   REG_DM0CNT = wordCount | mode;
}

/*
* GetGameInput(AnimatedSprite*) gets the keypad input for the main game
* screen and updates the sprites position accordingly.  It also calls
* the functions to collect a pearl and hit a school of fish as necessary.
* Although long, I have only briefly commented this function because it
* is very readable.
*/
void GetGameInput(AnimatedSprite *sprite)
{
   int collision;
   if (KEY_PRESS(KEY_UP)) {
      sprite->direction = UP;
      collision = TestCollision();
      if (collision == WATER || collision == PEARL) {
         if (sprite->y == 0)      //wrap around screen vertically
            sprite->y = 255;
         if (sprite->y == 240)
            sprite->y = 156;
         sprite->y = sprite->y - 1;
         movement++;  
         if (collision == PEARL)
            CollectPearl();
      }
      if (KEY_PRESS(KEY_A) && collision == FISH)
         HitFish();
   }

   if (KEY_PRESS(KEY_DOWN)) {
      sprite->direction = DOWN;
      collision = TestCollision();
      if (collision == WATER || collision == PEARL) {
         if (sprite->y == 159)    //wrap around screen vertically
            sprite->y = 243;
         if (sprite->y == 255)
            sprite->y = 0;
         sprite->y = sprite->y + 1;
         movement++;
         if (collision == PEARL)
            CollectPearl();
      }
      if (KEY_PRESS(KEY_A) && collision == FISH)
         HitFish();
   }

   if (KEY_PRESS(KEY_LEFT)) {
      sprite->direction = LEFT;
      if (sprite->flipped) {      //if sprite is facing right, now face it left
         mysprites[0].attribute1 = (mysprites[0].attribute1 & ~HORIZONTAL_FLIP);
         sprite->flipped = false;
      }
      collision = TestCollision();
      if (collision == WATER || collision == PEARL) {
         if (sprite->x == 0)      //wrap around screen horizontally
            sprite->x = 511;
         if (sprite->x == 496)
            sprite->x = 236;
         sprite->x = sprite->x - 1;
         movement++;
         if (collision == PEARL)
            CollectPearl();
      }
      if (KEY_PRESS(KEY_A) && collision == FISH)
         HitFish();
   }

   if (KEY_PRESS(KEY_RIGHT)) {
      sprite->direction = RIGHT;
      if (!sprite->flipped) {     //if sprite is facing left, now face it right
         mysprites[0].attribute1 = (mysprites[0].attribute1 | HORIZONTAL_FLIP);
         sprite->flipped = true;
      }
      collision = TestCollision();
      if (collision == WATER || collision == PEARL) {
         if (sprite->x == 239)    //wrap around screen horizontally
            sprite->x = 499;
         if (sprite->x == 511)
            sprite->x = 0;
         sprite->x = sprite->x + 1;
         movement++;
         if (collision == PEARL)
            CollectPearl();
      }
      if (KEY_PRESS(KEY_A) && collision == FISH)
         HitFish();
   }

   if (KEY_PRESS(KEY_L) && KEY_PRESS(KEY_R)) {
      paused = false;             //L + R restarts the current level
      stoplevel = true;
   }

   if (KEY_PRESS(KEY_START) && KEY_PRESS(KEY_SELECT) && KEY_PRESS(KEY_A) && KEY_PRESS(KEY_B)) {
      SoftReset();
   }

   if (KEY_PRESS(KEY_START) && keytap) {
      keytap = false;             //START returns to the level select screen
      paused = true;
      stoplevel = true;
   }
}

/*
* DisplayCopyleft() displays the statement of copyright and license under
* the GNU GPL.  It was necessary to use 5000 iterations of WaitForVblank()
* in order for about 10 seconds to elapse, even though a Vblank occurs about
* 60 times per second.  I believe this is because the Vblank lasts a certain 
* amount of time, and during that time the WaitForVblank() function returns
* as soon as it is called.
*/
void DisplayCopyleft()
{
   SetMode(SCREENMODE_1);
   EnableBackground(&textscreen);
   extern char *__eheap_start;    //store string at the start of empty EWRAM
   char *copylefttext = __eheap_start;
   copylefttext = "\n\nBLOWHOLE version .90\nCOPYRIGHT 2002 LANCE LEGAN,\n"
      "SOMETHING SCREWY PRODUCTIONS\n\nBLOWHOLE is licensed under the\n"
      "GNU General Public License,\nNOT by Nintendo,and comes\n"
      "with ABSOLUTELY NO WARRANTY.\nThis is free software,and you\n"
      "are welcome to redistribute\nit under certain conditions.\n\nVisit:\n"
      "http://www.gnu.org/licenses/\nfor details.\t";

   u16 vblank_counter = 0;
   WaitForVblank();
   PrintText(copylefttext, &textscreen, 0, 0);
   while ((!KEY_PRESS(KEY_START) || !keytap) && vblank_counter != 5000) {
      WaitForVblank();            //return after START is pressed or 10 seconds
      vblank_counter++;
   }
   keytap = false;
   DisableBackground(&textscreen);
}

/*
* DisplayTitleScreen() displays the title screen image using screen mode 4
* and then, like DisplayCopyleft(), removes the image after 10 seconds or
* when START is pressed.  If L + R + SELECT is pressed while the title 
* screen is displayed, the SRAM saved information will be cleared.
*/
void DisplayTitleScreen()
{
   SetMode(SCREENMODE_4 | BG2_ENABLE);
   u16 x, y, i;

   for (i = 0; i < 256; i++)
      myBGPaletteMem[i] = titlescreenPalette[i];
   WaitForVblank();
   u16 *picData = (u16*)titlescreen;
   for (x = 0; x < 120; x++) {    //writes 16 bits at a time, 240/2 = 120
     for (y = 0; y < 160; y++)
        myVideoBuffer[x + y * 120] = picData[x + y * 120];
   }
   u16 vblank_counter = 0;
   while ((!KEY_PRESS(KEY_START) || !keytap) && vblank_counter != 5000) {
      WaitForVblank();
      vblank_counter++;
      if (KEY_PRESS(KEY_L) && KEY_PRESS(KEY_R) && KEY_PRESS(KEY_SELECT)) {
         *saveCheckptr = 0;
         *saveSpotptr = 0;
         *saveStartptr = 0;
         vblank_counter = 5000;
      }
   }
   keytap = false;
}

/*
* DisplayLevelSelect() displays the level select screen and allows the
* player to select which level to play out of the levels they have completed.
* It adjusts the correct global variables so that when START or A is pressed,
* the game begins on the correct level.
*/
void DisplayLevelSelect()
{
   u16 i;

   EnableBackground(&title);
   for (i = 0; i < 512; i++)
      title.mapData[i] = titlemap[i];

   EnableBackground(&textscreen);
   u8 currentlevel = startLevel + 1, highlevel = highestLevel + 1;
   u8 numberLevels = NUMBERLEVELS;
   extern char *__eheap_start;    //store string at the start of empty EWRAM
   char *levelselecttext = __eheap_start;
   levelselecttext = "Total Number of Levels:  "
      "\n\n\n\nHighest Level Completed:  "
      "\n\nCurrent Level:  \t";
   WaitForVblank();
   PrintText(levelselecttext, &textscreen, 2, 11);
   PrintNumber(numberLevels, &textscreen, 26, 11);
   PrintNumber(highlevel, &textscreen, 27, 15);
   PrintNumber(currentlevel, &textscreen, 17, 17);
   for (i = 0; i < 300; i++)
      WaitForVblank();
   while ((!KEY_PRESS(KEY_START) && !KEY_PRESS(KEY_A)) || !keytap) {
      if (KEY_PRESS(KEY_UP) && keytap && currentlevel < highlevel) {
         keytap = false;
         currentlevel++;
         *saveStartptr = currentlevel - 1;
         WaitForVblank();
         PrintNumber(currentlevel, &textscreen, 17, 17);
      }
      if (KEY_PRESS(KEY_DOWN) && keytap && currentlevel > 1) {
         keytap = false;
         currentlevel--;
         *saveStartptr = currentlevel - 1;
         WaitForVblank();
         PrintNumber(currentlevel, &textscreen, 17, 17);
      }
   }
   keytap = false;
   startLevel = currentlevel - 1;
   DisableBackground(&textscreen);
   DisableBackground(&title);
}

/*
* DisplayEnding() displays a simple ending screen and congratulations
* when the player completes all the levels of the game.  This is something 
* that should be improved for future releases.  Rewarding endings are just
* so much cooler.
*/
void DisplayEnding()
{
   u16 i;

   EnableBackground(&title);
   for (i = 0; i < 512; i++)
      title.mapData[i] = titlemap[i];

   EnableBackground(&textscreen);
   extern char *__eheap_start;    //store string at the start of empty EWRAM
   char *endgametext = __eheap_start;
   endgametext = "     WHALE OF A GOOD JOB!\n\n"
      "You have completed all of the\nlevels in BLOWHOLE version .90\n\n"
      "Stay tuned to:\nhttp://www.somethingscrewy.com\n"
      "for future releases of\nBLOWHOLE with additional\n"
      "levels and new features.\t";
   WaitForVblank();
   PrintText(endgametext, &textscreen, 0, 10);
   while (1) {
      if (KEY_PRESS(KEY_START) && KEY_PRESS(KEY_SELECT) && KEY_PRESS(KEY_A) && KEY_PRESS(KEY_B)) {
         SoftReset();             //allow the player to reset the game
      }
   }
}

/*
* Here it is, the AgbMain() function.  It contains the necessary initializations
* and then the main game loop.
*/
int AgbMain()
{
   u16 i, j;
   u16 *tempptr;

   textscreen.number = 1;         //settings for the background to display text
   textscreen.charBaseBlock = 0;
   textscreen.screenBaseBlock = 25;
   textscreen.colorMode = BG_COLOR_256;
   textscreen.size = TEXTBG_SIZE_256x256;
   textscreen.mosaic = 0;
   textscreen.bgpriority = 1;
   textscreen.wraparound = 0;
   textscreen.x_scroll = 0;
   textscreen.y_scroll = 0;
   
   title.number = 0;              //settings for the background to display the title logo
   title.charBaseBlock = 1;
   title.screenBaseBlock = 26;
   title.colorMode = BG_COLOR_256;
   title.size = TEXTBG_SIZE_256x256;
   title.mosaic = 0;
   title.bgpriority = 0;
   title.wraparound = 0;
   title.x_scroll = 0;
   title.y_scroll = 0;

   gametiles.number = 2;          //settings for the main game background
   gametiles.charBaseBlock = 0;
   gametiles.screenBaseBlock = 24;
   gametiles.colorMode = BG_COLOR_256;
   gametiles.size = ROTBG_SIZE_256x256;
   gametiles.mosaic = 0;
   gametiles.bgpriority = 3;
   gametiles.wraparound = 0;
   gametiles.x_scroll = 0;
   gametiles.y_scroll = 0;

   blowhole.x = 250;              //settings for the blowhole sprite
   blowhole.y = 170;
   blowhole.flipped = false;
   blowhole.squaresize = 16;
   blowhole.frames = 4;
   blowhole.OAMSpriteNum = 0;
   for (j = 0; j < 16; j++) {
      for (i = 0; i < 8; i++) {
         blowhole.spriteCollision[j][i] = whalecollision[j][i];
      }
   }

   for (i = 0; i < 32; i++) {     //blank the current tile map
      for (j = 0; j < 32; j++)
         currentmap[j][i] = 0x00;
   }
   for (i = 0; i < 100; i++)
      myBGPaletteMem[i] = tilebgPalette[i];
   for (i = 0; i < (80 * 96) / 2; i++)  //game and text tileset to character base block 0
      myTileData0[i] = tilebg[i];
   for (i = 0; i < (216 * 80) / 2; i++) //title logo tileset to character base block 1
      myTileData1[i] = titlelogo[i];

   for (i = 0; i < 3; i++)
      myOBJPaletteMem[i] = whalePalette[i];
   InitializeSprites();
   LoadSpriteData(whale0, 16, 0);
   LoadSpriteData(whale1, 16, 1);
   LoadSpriteData(whale2, 16, 2);
   LoadSpriteData(whale3, 16, 3);
   InitSpriteFrames(&blowhole);

   EnableKeyInterrupt(KEY_START | KEY_A | KEY_UP | KEY_DOWN);

   DisplayCopyleft();
   DisplayTitleScreen();

   SetMode(SCREENMODE_1);
   for (i = 0; i < 100; i++)      //recopy palette and tileset data since DisplayTitleScreen() overwrote it
      myBGPaletteMem[i] = tilebgPalette[i];
   for (i = 0; i < (80 * 96) / 2; i++)
      myTileData0[i] = tilebg[i];
   for (i = 0; i < (216 * 80) / 2; i++)
      myTileData1[i] = titlelogo[i];

   if (*saveCheckptr == 69) {     //check if a save is present and load...
      highestLevel = *saveSpotptr;//if necessary
      startLevel = *saveStartptr;
   }
   else {
      highestLevel = 0;
      startLevel = 0;
   }
   paused = true;       //paused returns to the level select screen when true
   stoplevel = false;

   while (startLevel != NUMBERLEVELS) {
      if (paused) {
         MoveSpriteOffscreen(&blowhole);
         DisableBackground(&gametiles);
         DisplayLevelSelect();
      }

      for (i = 0; i < 15; i++) {  //copy the level to be played into an array that can be manipulated
         for (j = 0; j < 10; j++)
            currentlevel[j][i] = level[startLevel][j][i];
      }
      RenderLevelMap(currentlevel);
      CountPearls(currentlevel);
      RenderCollisionMap(currentlevel);
      pearlsCollected = 0;

      blowhole.flipped = false;
      paused = true;
      stoplevel = false;

      SetMode(SCREENMODE_1 | OBJ_ENABLE | OBJ_MAP_1D);
      EnableBackground(&gametiles);

      tempptr = (u16*)currentmap; //copy the map of the level into the correct screen base block
      for (i = 0; i < 512; i++)
         gametiles.mapData[i] = tempptr[i];

      mysprites[0].attribute0 = (COLOR_16 | SQUARE | blowhole.y);
      mysprites[0].attribute1 = (SIZE_16 | blowhole.x);
      mysprites[0].attribute2 = (PRIORITY(2) | PALETTE(0));

      while((pearlsCollected != pearlsTotal) && !stoplevel) {
         GetGameInput(&blowhole);
         MoveSprite(&blowhole);
         if (movement == 10 || movement == 11) {  //animate the sprite as it moves
            Animate(&blowhole);                   //one frame for every 10 movements
            movement = 0;
         }
         WaitForVblank();
         CopyOAM();
      }
      if (pearlsCollected == pearlsTotal) {       //level is completed
         startLevel++;
         if (startLevel > highestLevel) {         //if the level completed was...
            highestLevel++;                       //not completed already
            *saveCheckptr = 69;
            *saveSpotptr = highestLevel;
            *saveStartptr = startLevel;
         }
      }
   }
   startLevel--;                    //when the game is completed
   highestLevel--;
   *saveStartptr = startLevel;
   *saveSpotptr = highestLevel;
   MoveSpriteOffscreen(&blowhole);
   DisableBackground(&gametiles);
   DisplayEnding();

   return 0;
}


