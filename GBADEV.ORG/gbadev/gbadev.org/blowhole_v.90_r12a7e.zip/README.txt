Welcome to Blowhole version .90.  Blowhole is a puzzle game for the Game Boy Advance.
Blowhole is NOT licensed by Nintendo.

Copyright (C) 2002 Lance Legan, Something Screwy Productions

Blowhole is free software; you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation; either version 2 of the License, or
(at your option) any later version.

Blowhole is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with Blowhole; if not, write to the Free Software
Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA

The GNU GPL can be found online at: http://www.gnu.org/licenses/
Blowhole can be found online at: http://www.somethingscrewy.com/

The information in this README file can also be found online, at the Blowhole website,
in the About section.

The idea for Blowhole came from the game Slippy 1.0 by Martin Hock for the TI-85 
calculator with ZShell.  15 of Blowhole's 25 levels are adapted forms of levels from
Slippy 1.0.  The other 10 are original levels.  Slippy 1.0 can still be found in the file archives at 
http://www.ticalc.org, or more specifically: http://www.ticalc.org/pub/85/asm/games/zshell/slippy.zip

The Story:
You are Blowhole, a fun loving killer whale in the ocean.  Being the inquisitive whale 
that you are, you enjoy collecting mysterious YELLOW PEARLS.  It is not hard to spot 
these YELLOW PEARLS, but it sometimes is difficult to get to them because there are ROCKS, 
pesky fisherman's NETS, and SCHOOLS OF FISH in your way.  Unfortunately, you can not move 
the ROCKS, but you are a strong and smart whale, and you have figured out that you can hit 
a SCHOOL OF FISH into a NET, causing the SCHOOL OF FISH to be captured and the NET to be 
raised, clearing a path for you to swim through.  You can also swim off one side of the 
screen and end up on the opposite side.  When you hit a SCHOOL OF FISH, it will move in a 
straight line in the direction that you hit it, and it will stop when it reaches ROCKS 
or another SCHOOL OF FISH, or be captured if it reaches a NET.  Be careful though, if you 
hit a SCHOOL OF FISH off one side of the screen, they will swim away and not return.  Also, 
if you hit a SCHOOL OF FISH into a YELLOW PEARL the fish will take the pearl!  Your goal is 
to collect all the YELLOW PEARLS in a level in order to move on to the next level.  Complete 
all 25 levels to win the game!

The Controls:
After the Copyright Screen and Title Screen that appear when you turn on the game, you 
will see the Level Select Screen.  At the Level Select Screen you can use UP and DOWN 
on the control pad to choose which level to play from the levels you have already 
completed.  Press START or A to begin the level.  Once you have started a level, the 
controls are as follows:

Use the control pad to swim around.
To hit a school of fish, swim up to it in the direction you want to hit it, hold that 
direction on the control pad, and press A.
To collect a pearl, just swim over it.
To return to the Level Select Screen, press START.
To restart the level if you get stuck, press L + R.
To reset the game, hold down A + B + SELECT and press START

Your progress will be battery saved after you complete each level, so you can turn off the 
system and resume play later from where you left off.  To reset the save (clear all completed 
levels and restart from level one), at the Title Screen, hold down L + R and press SELECT.  
Note: if you are using a multiboot cable to load the game, your progress can not be saved.  
Once the system is turned off, you will have to start over from level one.

Running The Game:
Blowhole has been designed for and tested on hardware (an actual Game Boy Advance).  You 
can load it on a Game Boy Advance via an MBV2 Multiboot cable using the file blowhole.mb.  
It will also run on a Visoly Flash Card (necessary for your game in progress to be saved).  
You can use the file blowhole.gba or blowhole.mb with a Flash Card, either will work, but I 
recommend using blowhole.mb, as it stangely gives better performance in some aspects.  
Lastly, Blowhole will run on GBA emulators.  It has been tested on BoycottAdvance and 
VisualBoyAdvance, and the game save also works on emulators (the emulator will typically 
create a blowhole.sav file with the saved data).  Performance on an emulator is not as 
good as on an actual GBA, no emulator is perfect.  Both blowhole.gba and blowhole.mb will 
work on emulators, however, I have noticed slower performance with the blowhole.mb ROM on 
emulators.  Use blowhole.gba with emulators for the best results.  See the Note About 
Emulators just below.

To obtain an MBV2 Multiboot cable or Visoly Flash Card and Flash Linker to program the 
card (you can also program a Flash Card with the MBV2 cable), visit http://www.lik-sang.com.  
To obtain a GBA emulator, visit http://www.gbadev.org/ and look in the Tools section.

Note About Emulators:
As stated above, emulators are imperfect and will not match the performance of an actual
Game Boy Advance exactly.  One particular issue is that I have not seen an emulator that 
accurately emulates the GBA's key press interrupt.  This means that when pressing START 
to move between the Level Select Screen and the game, on emulators it will often switch 
back and forth very rapidly with just one keypress.  Also, when selecting a level on 
emulators, the numbers scroll much too quickly.  To compensate for this just hit the key 
that you are using for START on your keyboard very gingerly (and it may take a few tries) 
until the level starts.  The hold A + B + SELECT and press START reset also causes problems
on emulators.  Nearly everything else in the game seems to run fine on emulators.

Feedback:
If you have any feedback about Blowhole I would love to hear it.  Like it, hate it, 
suggestions for improvement, bug reports, questions, or if you have designed your own 
level that you would like to include in a possible future release of Blowhole 
(see levels_data.h for details).  Also, I am new to program development, so any 
suggestions for improvement of my code and my design approach in general from someone 
more experienced in software development, game development, or GBA development would 
be appreciated.  My contact info is just below.

Contact Info:
lance@somethingscrewy.com
http://www.somethingscrewy.com
Lance Legan
P.O. Box 266
Goldenrod, FL 32733

Why Version .90?:
Blowhole is almost totally complete and there may or may not be another version released.  
I wanted to keep this one at version .90 to give me the option of adding sound and some 
new levels before releasing version 1.0.  Whether it happens or not depends if I have 
time and on the feedback I get from this release.

Technical Details:
Blowhole was developed using the Unofficial GameBoy Advance Software Development Kit (devkitadv) 
and the Rhide C/C++ editor for DJGPP.  Adobe Photoshop 6.0 was used for the graphics.  
The utilities gifs2sprites, gfx2gba, and gbarm were used for converting sprites, converting 
bitmaps, and patching the ROM header respectively.  See the PROPS.txt file for a more 
comprehensive list of the resources used.

Compiling Blowhole Yourself:
If you have devkitadv for DOS/Windows setup correctly, Blowhole should be easy to compile.
Just unzip all the files from the Blowhole release into a directory, and while in that 
directory, use the included make.bat file like this: 'make blowhole.c myfile.gba' which will
compile, link, (using the included crt0.o and lnkscript by Jeff Frohwein) and objcopy 
blowhole.c into the binary myfile.gba, or whatever you choose to call it.  I have not 
yet tried to compile this with the Linux version of devkitadv, but I will soon.  
If you are using Linux, I'm sure you know how to compile things.

Development Details:
I have been spending my summer learning about programming for the Game Boy Advance.  
I was looking for a simple game idea that I could develop to completion that would be 
challenging, but not overwhelming.  I also set the goal of documenting the program 
adequately and releasing it under the GNU GPL so that other newbie GBA programmers 
like myself would have a simple and clearly written game to learn from that directly 
applies the techniques taught in various GBA programming tutorials that can be found 
online.  (see PROPS.txt file)  I remembered a game from high school for the TI-85 
calculator (Slippy 1.0) that was challenging and fun, and decided a clone of it would 
be a perfect project.

Significant Features:
-Clear code and documentation
As mentioned above, the code is well documented and also very consistently formatted.  
I did not want to go overboard with in code comments, as they clutter up the code, but 
each function has an explanation with it.  The documentation is clear and concise.

-Sub-Pixel Rendered font
The font you see in Blowhole has been made with a technique called Sub-Pixel Rendering, 
which uses the LCD screen's display properties to increase the available horizontal 
resolution three times.  Details of this technique and the program I used to render 
the font can be found at http://grc.com/cleartype.htm.  I did not spend a great deal 
of time perfecting the rendered font, but even so, the advantage of Sub-Pixel Rendering 
is clearly seen on the GBA screen.  Someone who is more artistic and willing to render 
a font by hand could do wonders with this idea.  Note: You will only see the effects
of sub-pixel rendered font on the actual GBA screen.  On your computer screen, the 
font will look strange unless your display is an LCD that displays pixels in BGR format 
like the GBA does.

-Level maps in an easy format
The levels are defined in a simple format which makes it easy to enter them by hand 
and easy for anyone to write their own level, enter it, recompile the game, and play 
their level.  It also makes it easy to write a level editor, either built into the 
game for the GBA, or seperate for a PC.  If anyone wants to do this, go for it.  
For details on the level format and how to input your own, see the file levels_data.h.

-Complete and playable game
Blowhole is, for the most part, a complete game.  The simple nature of the game 
mechanics made it possible to make this a full game.  I have seen lots of impressive 
and technically challenging demos from the GBA homebrew community, but very few 
fully playable and complete games, even simple ones.

Development History:
The complete development cycle from idea to release was July 3, 2002 to August 3, 2002.  
I worked on the game almost daily and usually for several hours each day.  The 
dates below are just some landmark dates.
July 3, 2002 - Began game development starting with designing the graphics and began programming
July 11, 2002 - Game engine was complete and playable but needed some collision tweaking
July 12, 2002 - Collision was perfected and moved into programming the Level Select Screen
July 22, 2002 - Added the battery save feature which completed the game, moved into documentation
July 26, 2002 - Completed commenting the code and writing documentation files, all that is left is designing more levels
August 3, 2002 - Completed 25 level designs/adaptations and prepared game for release
August 4, 2002 - Finished game web page and officially released Blowhole version .90

Contact Info:
lance@somethingscrewy.com
http://www.somethingscrewy.com
Lance Legan
P.O. Box 266
Goldenrod, FL 32733
