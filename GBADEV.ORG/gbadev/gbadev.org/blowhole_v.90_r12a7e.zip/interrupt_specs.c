/* 
* Blowhole (Game Boy Advance puzzler) - interrupt_specs.c
* Description: Definitions, global variables, and functions pertaining
*    to interrupts
* License: Copyright (C) 2002 Lance Legan, Something Screwy Productions;
*    This file is part of Blowhole.
*
*    Blowhole is free software; you can redistribute it and/or modify
*    it under the terms of the GNU General Public License as published by
*    the Free Software Foundation; either version 2 of the License, or
*    (at your option) any later version.
*
*    Blowhole is distributed in the hope that it will be useful,
*    but WITHOUT ANY WARRANTY; without even the implied warranty of
*    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
*    GNU General Public License for more details.
*
*    You should have received a copy of the GNU General Public License
*    along with Blowhole; if not, write to the Free Software
*    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
*
*    The GNU GPL can be found online at: http://www.gnu.org/licenses/
*    Blowhole can be found online at: http://www.somethingscrewy.com/
*/

//Dependencies: include gba.h, keypad.h, interrupt.h before this file

#ifndef INTERRUPT_SPECS_C
#define INTERRUPT_SPECS_C

//definitions:
typedef void (*fp)(void);  //function pointer type
//extern fp intr_main;
void VBLANK(void) ;
void HBLANK(void) ;
void VCOUNT(void) ;
void TIMER0(void) ;
void TIMER1(void) ;
void TIMER2(void) ;
void TIMER3(void) ;
void COMMUNICATION(void) ;
void DMA0(void) ;
void DMA1(void) ;
void DMA2(void) ;
void DMA3(void) ;
void KEYPAD(void) ;
void CART(void) ;


//global variables:
bool keytap = false;       //true when key interrupt is generated, must be reset
                           //to false immediately by any function that uses it
fp IntrTable[] =           //array of interrupt function pointers,
{                          //must be listed in this order
   VBLANK,
   HBLANK,
   VCOUNT,
   TIMER0,
   TIMER1,
   TIMER2,
   TIMER3,
   COMMUNICATION,
   DMA0,
   DMA1,
   DMA2,
   DMA3,
   KEYPAD,
   CART
};


//functions (with an explanation preceding each):
/*
* EnableKeyInterrupt(u16) turns on a key press interrupt for the 
* key (defined in keypad.h) passed to it.  Multiple keys can be interrupt 
* enabled by bitwise ORing the key values to pass to this function, or
* by calling it multiple times.
*/
void EnableKeyInterrupt(u16 key)
{
   REG_IME = 0;
   keytap = false;
   REG_P1CNT |= (key | 0x4000);
   REG_IE |= INT_KEYPAD;
   REG_IME = 1;
}

/*
* KEYPAD(void) below sets keytap to true indicating an interrupt enabled 
* key has been pressed.  The rest of these interrupt functions do nothing but 
* mark the interrupt as processed, since other interrupts are not needed at 
* this point.
*/
void VBLANK()
{
   REG_IF |= INT_VBLANK;
}

void HBLANK(void)
{
   REG_IF |= INT_HBLANK;
}

void VCOUNT(void)
{
   REG_IF |= INT_VCOUNT;
}

void TIMER0(void)
{
   REG_IF |= INT_TIMER0;   
}

void TIMER1(void)
{
   REG_IF |= INT_TIMER1;
}

void TIMER2(void)
{
   REG_IF |= INT_TIMER2;
}

void TIMER3(void)
{
   REG_IF |= INT_TIMER3;
}

void COMMUNICATION(void)
{
   REG_IF |= INT_COMMUNICATION;
}

void DMA0(void)
{
   REG_IF |= INT_DMA0;
}

void DMA1(void)
{
   REG_IF |= INT_DMA1;
}

void DMA2(void)
{
   REG_IF |= INT_DMA2;
}

void DMA3(void)
{
   REG_IF |= INT_DMA3;
}

void KEYPAD(void)
{
   keytap = true;
   REG_IF |= INT_KEYPAD;
}

void CART(void)
{
   REG_IF |= INT_CART;
}

#endif

