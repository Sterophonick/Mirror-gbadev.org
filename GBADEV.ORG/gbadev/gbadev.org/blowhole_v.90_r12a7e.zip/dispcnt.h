/* 
* Blowhole (Game Boy Advance puzzler) - dispcnt.h
* Modified by Lance from tutorials by dovoto and gbajunkie (see PROPS.txt file)
* Description: Definitions for the REG_DISPCNT register found in gba.h
* License: Public Domain - this file may be used and redistributed 
*    as desired (see PUBLIC.txt file)
*
*    Blowhole can be found online at: http://www.somethingscrewy.com/
*/

#ifndef DISPCNT_H
#define DISPCNT_H

//flags to control the screen mode
#define SCREENMODE_0	0x0000
#define SCREENMODE_1	0x0001
#define SCREENMODE_2	0x0002
#define SCREENMODE_3	0x0003
#define SCREENMODE_4	0x0004
#define SCREENMODE_5	0x0005

//enables a backbuffer for double screen buffering
#define BACKBUFFER 	0x0010

//when set, allows OAM to be updated during a horizontal blank
#define H_BLANK_OAM 	0x0020

//flags to control the sprite mapping mode
#define OBJ_MAP_2D 	0x0000
#define OBJ_MAP_1D 	0x0040

//force the screen to blank white
#define FORCE_BLANK 	0x0080

//flags for enabling backgrounds and sprites
#define BG0_ENABLE	0x0100
#define BG1_ENABLE	0x0200
#define BG2_ENABLE	0x0400
#define BG3_ENABLE	0x0800
#define OBJ_ENABLE	0x1000

//flags to diable backgrounds and sprites; bitwise AND with these values
#define BG0_DISABLE	0xFEFF
#define BG1_DISABLE	0xFDFF
#define BG2_DISABLE	0xFBFF
#define BG3_DISABLE	0xF7FF
#define OBJ_DISABLE	0xEFFF

//flags to enable window displays
#define WIN1_ENABLE	0x2000
#define WIN2_ENABLE	0x4000
#define WINOBJ_ENABLE	0x8000

/*
* To set the flags that you want to use, bitwise OR them together as follows:
* SetMode(MODE_2 | OBJ_ENABLE | OBJ_MAP_1D);
*/
#define SetMode(mode) REG_DISPCNT = (mode)

#endif


