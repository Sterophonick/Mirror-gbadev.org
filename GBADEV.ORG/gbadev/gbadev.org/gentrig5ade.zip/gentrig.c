//
// gentrig - generates fixed point trig tables
// by dj_fishstix
//
// you are free to do anything with this code, but i accept no responsibility if it breaks anything :)

// apologies for tacky style: i just quickly knocked it up...

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>


#define PI 3.151592653589793238
#define TORADIANS(deg,cal) ((double)(deg)*2*PI/(double)cal)


int outputSize = 32;	//by default use 32 bit output
char outputSizeName[32] = "long";
int outputSizeMask = 0xffffffff;
int outputCal = 360;	//default calibration (ie. degrees)
int outputBP = 16;		//position of the binary point
char outputFilename[256] = "trig.h";


void genData (FILE *f)
{
	int i, j;
	int data;

	fprintf (f, "\n\nconst %s sintab[] = {\n", outputSizeName);

	for (i=0; i<outputCal;)
	{
		fprintf (f, "\t");

		for (j=0; j<8 && i<outputCal; j++,i++)
		{
			data = (int) ((double) sin (TORADIANS(i,outputCal)) * (double)(1 << outputBP));
			data &= outputSizeMask;
			fprintf (f, "%#.*x", outputSize/4, data);
			if (i<outputCal-1) 
				fprintf (f, ",");
			else
				fprintf (f, " };");
		}

		fprintf (f, "\n");
	}

	//cos
	fprintf (f, "\n\nconst %s costab[] = {\n", outputSizeName);

	for (i=0; i<outputCal;)
	{
		fprintf (f, "\t");

		for (j=0; j<8 && i<outputCal; j++,i++)
		{
			data = (int) ((double) cos (TORADIANS(i,outputCal)) * (double)(1 << outputBP));
			data &= outputSizeMask;
			fprintf (f, "%#.*x", outputSize/4, data);
			if (i<outputCal-1) 
				fprintf (f, ",");
			else
				fprintf (f, " };");
		}

		fprintf (f, "\n");
	}

	//tan
	fprintf (f, "\n\nconst %s tantab[] = {\n", outputSizeName);

	for (i=0; i<outputCal;)
	{
		fprintf (f, "\t");

		for (j=0; j<8 && i<outputCal; j++,i++)
		{
			data = (int) ((double) tan (TORADIANS(i,outputCal)) * (double)(1 << outputBP));
			data &= outputSizeMask;
			fprintf (f, "%#.*x", outputSize/4, data);
			if (i<outputCal-1) 
				fprintf (f, ",");
			else
				fprintf (f, " };");
		}

		fprintf (f, "\n");
	}
}

void printHelp ()
{
	printf ("\nUsage: gentrig [OPTIONS] [OUTPUTFILE]\n");
	printf ("\tIf OUTPUTFILE is not specified, output is put into trig.h\n\n");
	printf ("Options:\n");
	printf ("  -sX\tSets the size of data to X. X can be 32, 16 or 8 (bits).\n");
	printf ("  -pX\tSets the binary point to X. For best accuracy, set this to SIZE-2\n");
	printf ("  \tTo turn a value into an integer in code, use '>> X'\n");
	printf ("  -cX\tSets the calibration to X (eg. use -c360 for degrees)\n");
}

int main (int argc, char **argv)
{
	int i;
	FILE *f;

	printf ("gentrig by dj_fishstix\n");

	if (argc == 1)
	{
		printHelp ();
		exit (0);
	}

	for (i=1; i<argc; i++)
	{
		if (argv[i][0] == '-')
		{
			switch (argv[i][1])
			{
			case 's':
			case 'S':
				outputSize = atoi (&argv[i][2]);
				break;

			case 'p':
			case 'P':
				outputBP = atoi (&argv[i][2]);
				break;

			case 'c':
			case 'C':
				outputCal = atoi (&argv[i][2]);
				break;

			case 'h':
			case 'H':
			case '?':
				printHelp ();
				exit (0);

			default:
				printf ("skipping unrecognised parameter: %s\n", argv[i]);
			}
		}
		else
		{
			//it must be the filename
			strcpy (outputFilename, argv[i]);
		}
	}


	switch (outputSize)
	{
	case 32:
		strcpy (outputSizeName, "long");
		outputSizeMask = 0xffffffff;
		break;

	case 16:
		strcpy (outputSizeName, "short");
		outputSizeMask = 0xffff;
		break;

	case 8:
		strcpy (outputSizeName, "char");		
		outputSizeMask = 0xff;
		break;
	}


	f = fopen (outputFilename, "wt");

	//print some header info
	fprintf (f, "//\n// trig data created using gentrig.exe by dj_fishstix\n");
	fprintf (f, "//\n// format: %d-bit %d.%d fixed point\n//\n", outputSize, outputSize-outputBP, outputBP);

	genData (f);	

	fclose(f);

	return 0;
}