This is a demo of a 3d engine I have been working on.
It features:
	- voxel landscape
	- ray casting method of rendering
	- large maps from small amount of data
	- Runs on VBA, Boycott Advance, and runs nicely on hardware!

The keys are
	Up - Move forward in current direction
	Down - Move back in current direction
	Left - Strafe left
	Right - Strafe right
	L - Rotate left
	R - Rotate Right
	A - Decrease viewing distance
	B - Increase viewing distance
	Start - Decrease level of detail
	Select - Increase level of detail

Any comments or suggestions, feel free to email me at
dm93@hotmail.com

Thanks for your interest

Damien Marshall