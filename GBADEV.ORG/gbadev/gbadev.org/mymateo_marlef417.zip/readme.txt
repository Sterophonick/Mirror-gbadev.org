mymateo is proud (but not high-and-mighty about it) to present

MARLE

A demo.

This demo utilizes Mode 0 text background, using 1 backgound layer and 1 sprite with 60 frames of animation (15 frames in each direction - up down left and right) and DMA to copy sprite data.  I have also included MOD playback by the AAS Sound System.

CONTROLS

Up - Move Marle up
Down - Move Marle down
Left - Move Marle left
Right - Move Marle right
B - Run
A - Amuses some of us to no end (And only Brandon know the inside joke) - Otherwise, nothing
L - Pauses MOD playback
R - Resumes MOD playback

*Note - A working power switch is required for this demo to work on a GBA.  Otherwise, a good emulator will do.  i used VisualBoyAdvance.
 
*Another note - Yes, I realize that Marle has a bad habit of jumping up on tables and counters and walking through walls.  But for you Chrono Trigger buffs, you will realize that her movement almost exactly mimicks the movement you would find on the original SNES game.

*Legal Disclaimer - I took the images from Chrono Trigger.  Yes, I used an emulator.  YES I own the game (lay off, will ya?). NO NO NO I have NO affiliation with Nintendo OR SquareSoft (Though I wish I did...).  NO I did NOT make ANY of the images you will find in this demo.  The intro screen was made by Apex Designs (www.apex-designs.net).  The rest were made by SquareSoft or whoever they contracted to help with graphics.  I can't remember where I grabbed the MOD from, but I didn't make it.  Sorry, I wish I could give credit.

Programs used:
Code - UltraEdit
Image Grabbing - ZSNES
Image Editing - Paint Shop Pro
Image Converting (Sprites) - pcx2sprite
Image Converting (Background) - AGBGFXCon
Music - Apex Audio System
Environment - DevKitAdvance (R5 Beta 3) - Windows 2000
Emulator - VisualBoyAdvance
Hardware - Flash2Advance 64 Mb - Classic NES GBA SP (I fell victim to Nintendo's Advertising)

SPECIAL THANKS
And a very special thanks to those great guys who have helped me get to where I am.  Listed in alphabetical order, these are the great people who have helped me through the forums:
dagamer34
jd
Miked0801
poslundc
sgeos
tepples

And a very special thank to Brandon.  You got me addicted to RPG's, RPG's got me addicted to Emulators, and Emulators got me addicted to wanting to program games.  You also lent me your C++ book.  And probably a bunch of other stuff I could mention, but I won't because no-one reading this really cares.  No offense, but I doubt anyone reading this knows you.