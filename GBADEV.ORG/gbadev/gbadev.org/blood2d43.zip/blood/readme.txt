Blood demo by diabolik
diabolik@nitric.net

It was originally based on the tank ravagers game by loirak development
(check out www.loirak.com for a good GBA tutorial and some demos)

The PCX only uses 3 palette entries - 0, 254, and 255.
255 is the palette entry of the text "Blood Demo" and "(c) diabolik"
254 is the palette entry of the text "http://www.nettwerked.net/diabolik"
0 is everything else

The reason I used two seperate colors was because I could add a nice fade at
the end where the url goes to a seperate color than the words, or something
to that effect.. But I'd rather just move on and go study for economics :)

The PCX file was 240 pixels wide, and I didn't want to make the blood resolution
that high (dealing with the stupid 2-pixels-at-a-time mode 4).  However, the blood
doesn't overwrite any of the text (look at PlotBloodIn and PlotBloodOut to see how
I got it to filter the text).

do what you want with this, its not good enough to really be used much anywhere :)

http://www.nettwerked.net/diabolik

oh, and by the way.. I have no clue if this actually works on the GBA hardware, seeing
as I don't have a GBA :).. if anyone could try it an email me it'd be great, thanks.