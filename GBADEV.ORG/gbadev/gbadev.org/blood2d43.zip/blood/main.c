/*
blood demo by diabolik
coded while I should be at school November 26th, 2002
its my first GBA demo, so bear with me (actually i like it so shh)

the source was originally 
  Tank Ravagers by Loirak Development
  Programming: Ben Rhoades (benr@loirak.com)

but I've modded it beyond comprehension with the exception of a few small routines

thanks to Loirak for the tutorial/tank code, and everyone in the scene
*/
#include "gba.h"
#include "screenmode.h"
#include "keypad.h"
#include "gfx.h"
#include "gfx\logo.h"

// some memory location defines
u16* ScreenBuffer = (u16*)0x6000000;

volatile u16* ScanlineCounter = (volatile u16*)0x4000006;

u16* paletteMem = (u16*)0x5000000;	//PalMemory is 256 16 bit BGR values starting at 0x5000000

//function prototypes

#define WIDTH 		120
#define HEIGHT		160
#define RGB16(r,g,b)  ((r)+(g<<5)+(b<<10)) 

// Mode 4 is 240(120)x160 by 8bit
void PlotPixel(int x,int y, unsigned short int c)	
{ 
	ScreenBuffer[(y) *120 + (x)] = (c); 
}

void PlotBloodOut(int x,int y, unsigned short int c)
{
	u16 color = ScreenBuffer[(y) * 120 + (x)];
	if (color == 0x0000)
		PlotPixel(x,y,(c*256)+c);
	if (color == 0xFF00 || color == 0xFE00)
		PlotPixel(x,y,(c));
	if (color == 0x00FF || color == 0x00FE)
		PlotPixel(x,y,(c*256));
}

void PlotBloodIn(int x,int y, unsigned short int c)
{
	u16 color = ScreenBuffer[(y) * 120 + (x)];
	if (color == 0xFFFF || color == 0xFEFE)
		PlotPixel(x,y,(c*256)+c);
	if (color == 0xFF00 || color == 0xFE00)
		PlotPixel(x,y,(c*256));
	if (color == 0x00FF || color == 0x00FE)
		PlotPixel(x,y,(c));
}

void EraseScreen(void);		// erases the screen in mode4
void WaitForVblank(void);	// waits for the drawer to get to end before flip
void WaitForStart(void);

int main(void)
{
	int leastHeight;
	int dripSpeed[WIDTH];
	int dripTimer[WIDTH];
	int dripHeight[WIDTH];
	int i; // counters, prolly could be initialized in first for loop but whatever..
	int x;
	int y;
	int inOut = -1; // if 1, bloodifies the exterier to the words, if -1, bloodifies the words.  just showing variations..

	SetMode(MODE_4 | BG2_ENABLE ); //set mode 4

	EraseScreen();

	while (1) // always stay in this loop
	{
		EraseScreen();
		
		// set up palette
		paletteMem[0] = RGB16(0,0,0);
		paletteMem[254] = RGB16(0,0,0);
		paletteMem[255] = RGB16(0,0,0);
		for (i = 10; i <= 31; i++)
			paletteMem[i-9] = RGB16(i,0,0);  // set the 2nd-23nd colors to be shades of red.

		// draw the hidden logo
		for(y = 0; y < 160; y++)
		{
			for(x = 0; x < 120; x++)
			{
				PlotPixel(x,y,logoData[y*120+x]);//logoData contains the color values of your pict
			}
		}

		leastHeight = 0; // When leastHeight = 160, the blood's finished dripping.

		// initialize the drip paths
		for (i = 0; i <= WIDTH; i++) 
		{
			dripSpeed[i] = RAND(6) + 1; // number of iterations of entire while loop before it drips lower
			dripHeight[i] = 0;
		}
		
		while (leastHeight < 160)
		{
			leastHeight = 160;
			for (i = 0; i <= WIDTH; i++) 
			{
				if (dripHeight[i] < leastHeight)
					leastHeight = dripHeight[i];
				if (dripHeight[i] < 160) 
				{
					dripTimer[i]++;
					if (dripTimer[i] >= dripSpeed[i] || RAND(3)==2) 
					{
						dripTimer[i] = 0;
						dripHeight[i]++;
						if (inOut == 1) 
							PlotBloodOut(i,dripHeight[i],RAND(22)+1);
						else
							PlotBloodIn(i,dripHeight[i],RAND(22)+1);
					}
				}
			}
			WaitForVblank();  // used more as a pause then a vsync since im not page flipping :)
			Sleep(1);
		}
		WaitForStart();
		inOut = inOut * -1;
	}
	return 0;
} // end Agbmain

void EraseScreen(void)
{
	int x,y;
	for(y = 0; y < 160; y++)
	{
		for(x = 0; x < 120; x++)
		{
			PlotPixel(x,y,0x0000);//logoData contains the color values of your pict
		}
	}
	WaitForVblank();
}

void WaitForStart(void)
{
	while (1) // loops infinitely till they press start
		if (! ((*KEYS) & KEY_START) )
			return;
}

void WaitForVblank(void)	// waits for the drawer to get to end before flip
{
	while(*ScanlineCounter < 160) {	// do nothing
	}//now we are in the vblank period
}
