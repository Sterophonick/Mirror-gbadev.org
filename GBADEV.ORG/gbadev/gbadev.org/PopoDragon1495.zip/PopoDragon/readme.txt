------------------------------
Mode 4 and sprites
------------------------------

File:		PopoDragon.bin
Program:	Plots a picture and some active sprites
Author:		Dafa (Zhang Jianguo)
Contact:	dafa@yycat.com
Site:		http://www.yycat.com
		

-----------------------------
About this bin-file:
This bin file is created for learning purposes. The screenmode used is mode 4,
it cotains a background picture and some clouds and dragon sprites, the sprites 
are animate.
I hope this will give some newbies like me some advantage in making games
in mode 4.

--------------
Controlls:
Used the Left & Right keys to move (at least if it was a pc game) .
Press A will show a AD, press B will disable it.


----------------
Thanks to:


GBADEV.org (their new forum is great for beginners like me)



-----------------
Disclaimer:
This game is freeware. This software is provided 'as is' with no warranty or guarantees of
any kind, you use this software at your own risk. You accept all responsibility for any 
damage caused as a result of using this software. The author is not liable for any costs 
incurred as a result of using this software.

