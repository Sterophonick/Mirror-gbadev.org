////////////////////////////////////////////////////////////////////////////
//File:		mode4sprites.cpp
//Description:	displaying sprites in mode 4
//Author:	Dafa
//Time:		about 2 hours
//visit:	www.yycat.com
//
////////////////////////////////////////////////////////////////////////////

//general stuff and definitions
#include "gba.h"		//GBA register definitions
#include "dispcnt.h"		//REG_DISPCNT register #defines
#include "keypad.h"	//gba button registers
#include "sprites.h"		//sprite definitions

//gfx stuff
#include "ghost.h"		//cotains data and palette for ghost sprite
#include "cloud.h"		//cotains data and palette for ghost sprite
#include "dragon.h"		//cotains data and palette for ghost sprite
#include "AD.h"		//cotains data and palette for ghost sprite
#include "picture.h"		//cotains data and palette for the background
#include "sky.h"		//cotains data and palette for the background

//create an OAM variable and make it point to the address of OAM
u16* OAM = (u16*)0x7000000;

//some variables
int ghostx = 80;
int ghosty = 133;
int IsRun = 0;
int IsShowAD = 0;

// Mode 4 is 240(120)x160 by 8bit
void PlotPixel(int x,int y, unsigned short int c)	
{ 
	VideoBuffer[(y) *120 + (x)] = (c); 
}

//wait for the screen to stop drawing
void WaitForVsync()
{
	while((volatile u16)REG_VCOUNT != 160){}
}

//create the array of sprites
OAMEntry sprites[128];

//Copy sprite array to OAM
void CopyOAM()
{
	u16 loop;
	u16* temp;
	temp = (u16*)sprites;
	for(loop=0; loop < 128*2; loop++)
	{
		OAM[loop] = temp[loop];
	}
}

// Set sprites off screen
void InitializeSprites()
{
	u16 loop;
	for (loop = 0; loop < 128; loop++)
	{
		sprites[loop].attribute0 = 160;	//y > 159
		sprites[loop].attribute1 = 240;	//x > 239
	}
	//ctrl sprite
	sprites[0].attribute0 = COLOR_256 | SQUARE| ghosty ;
	sprites[0].attribute1 = SIZE_16 | ghostx ;
	sprites[0].attribute2 = 512 + 128 ;	

	//cloud sprites
	sprites[1].attribute0 = COLOR_256 | SQUARE | 0;
	sprites[1].attribute1 = SIZE_32 | HORIZONTAL_FLIP | 0;
	sprites[1].attribute2 = 512;			

	sprites[2].attribute0 = COLOR_256 | SQUARE | 0;
	sprites[2].attribute1 = SIZE_32 | VERTICAL_FLIP | 0;
	sprites[2].attribute2 = 512;

	sprites[3].attribute0 = COLOR_256 | SQUARE | 0;
	sprites[3].attribute1 = SIZE_32 | 0;
	sprites[3].attribute2 = 512;			

	sprites[4].attribute0 = COLOR_256 | TALL | 0;
	sprites[4].attribute1 = SIZE_32 | 140;
	sprites[4].attribute2 = 512 + 32;

	sprites[5].attribute0 = COLOR_256 | TALL | 0;
	sprites[5].attribute1 = SIZE_32 | 140;
	sprites[5].attribute2 = 512 + 32 + 16;

	//AD
	sprites[20].attribute0 = COLOR_256 | SQUARE | 30;
	sprites[20].attribute1 = SIZE_64 | 88;
	sprites[20].attribute2 = 512 + 128 + 80;

}

//move the sprite
void MoveSprite(OAMEntry* sp, int x, int y)
{
	if(x < 0)			//if it is off the left correct
		x = 512 + x;
	if(y < 0)			//if off the top correct
		y = 256 + y;

	sp->attribute1 = sp->attribute1 & 0xFE00;  //clear the old x value
	sp->attribute1 = sp->attribute1 | x;

	sp->attribute0 = sp->attribute0 & 0xFF00;  //clear the old y value
	sp->attribute0 = sp->attribute0 | y;
}

//loads the palette of the objects
void LoadOBJPalette()
{
	int x;
	for(x=0; x< 256; x++)
	{
		OBJPaletteMem[x] = cloud_pal[x];
	}
}

//draws the background picture to the screen (also initializes palette)
void DrawBG()
{
	int x,y;

	//for(x=0; x < 256; x++)
	//{
	//	BGPaletteMem[x] = picturePalette[x];
	//}
	for(x=0; x < 16; x++)
	{
		BGPaletteMem[x] = sky_pal[x];
	}

	for(y=0; y < 160; y++)
	{
		for(x=0; x < 120; x++)
		{
			PlotPixel(x,y,sky_gfx[y*120+x]);
		}
	}
}

//GetInput
void GetInput()
{
	IsRun = 0;

	if(KEY_DOWN(KEYLEFT))	//left pressed on the gamepad
	{
		IsRun = 1;
		sprites[0].attribute1 = SIZE_16 | HORIZONTAL_FLIP | 0;
		ghostx--;
		if(ghostx<-16)
			ghostx=240;
	}
	if(KEY_DOWN(KEYRIGHT))	//right pressed on the gamepad
	{
		IsRun = 1;
		sprites[0].attribute1 = SIZE_16 | 0;
		ghostx++;
		if(ghostx>240)
			ghostx=-16;
	}

	if(KEY_DOWN(KEYA))	//right pressed on the gamepad
	{
		IsShowAD = 1;
	}
	if(KEY_DOWN(KEYB))	//right pressed on the gamepad
	{
		IsShowAD = 0;
	}
}

void NormalMove()
{
	static int cx1=120,cy1=-7;
	static int cx2=350,cy2=-50;
	static int cx3=800,cy3=-10;
	static int cx4=900,cy4=3;
	static int cx5=400,cy5=13;
	MoveSprite(&sprites[1], cx1/6, cy1);		//moves the ghost sprite around the screen
	cx1 --;
	if(cx1<-64*6)
		cx1=240*6;
	MoveSprite(&sprites[2], cx2/5, cy2);		//moves the ghost sprite around the screen
	cx2 --;
	if(cx2<-64*5)
		cx2=240*5;
	MoveSprite(&sprites[3], cx3/5, cy3);		//moves the ghost sprite around the screen
	cx3 --;
	if(cx3<-64*5)
		cx3=240*5;
	MoveSprite(&sprites[4], cx4/4, cy4);		//moves the ghost sprite around the screen
	cx4 --;
	if(cx4<-64*4)
		cx4=240*4;
	MoveSprite(&sprites[5], cx5/4, cy5);		//moves the ghost sprite around the screen
	cx5 --;
	if(cx5<-64*4)
		cx5=240*4;

	//////////////////////////////////////////////////////////////////
	GetInput();				//check if one of the buttons is pressed
	if(IsRun == 1)
	{
		static int runsteps = 0;
		runsteps ++;
		if(runsteps>5)
			runsteps = 1;
		sprites[0].attribute2 = 512 + 128 + 8*runsteps ;	
		MoveSprite(&sprites[0], ghostx, ghosty);		//moves the ghost sprite around the screen
		IsRun = 0;
	}
	else
		sprites[0].attribute2 = 512 + 128;	

	/////////////////// Show AD
	if(IsShowAD == 0)
		sprites[20].attribute2 = 0 ;	
	else
		sprites[20].attribute2 = 512 + 128 + 80;
	

}

//MMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMM
int main()
{
	int i,j,k;
    SetMode(MODE_4 | OBJ_ENABLE | OBJ_MAP_1D | BG2_ENABLE);

	DrawBG();
	LoadOBJPalette();
	InitializeSprites();

	for(i = 0; i < 2048; i++)		//load cloud sprite
	{
		OAMData[i + 8192] = cloud_gfx[i];
	}
	for(j = 0; j < 1280; j++)		//load dragon sprite
	{
		OAMData[i + j + 8192] = dragon_gfx[j];
	}
	for(k = 0; k < 2048; k++)		//load dragon sprite
	{
		OAMData[i + j + k + 8192] = AD_gfx[k];
	}

	while(1){
		NormalMove();			//wind blow the clouds


		CopyOAM();				//copy sprite data in memory
		WaitForVsync();				//wait for the screen to stop drawing
	}

}
