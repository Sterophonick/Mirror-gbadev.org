#ifndef sound_H
#define sound_H

//sound files
#include "fire.h"
#include "jump.h"
#include "mega.h"
#include "swap.h"
//#include "tune.cpp"
//#include "boss.cpp"
#include "rock.cpp"
//#include "music.cpp"

#endif
