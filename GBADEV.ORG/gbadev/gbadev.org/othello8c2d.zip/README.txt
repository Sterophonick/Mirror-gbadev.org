simple othello for the gba version 1.0
19/08/2003

by yanos (yanos at inbox lv)

INFO
this is a very simple othello game. there is no sound, and the ai sucks a bit, but it's perfect for some quickies on the subway. hope you have some fun poking around with it.

CHANGE LOG

version 1.0   
  initial release

