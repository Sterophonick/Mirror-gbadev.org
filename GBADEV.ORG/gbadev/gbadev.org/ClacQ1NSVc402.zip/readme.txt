------------------------------------------
  [ Clac Q one ] v.nosound   by Etage97
	     www.etage97.fr.st
------------------------------------------

see the howtoplay.html


-----------------------------------------------------------
The Etage97 Crew:
		- OLEMONDE
		- GallechaWestMedia
		- St_Abdoul

The Sound Engine by:
		- Sergej KRAVCENKO

Special thanks to:

website: www.gbadev.org
	 www.devrs.com/gba


PeoplZ:
	To our crew at IUT-Valence:
		- All the GTR Funk Squad 2002
		- M C DUCCINI
		- DBZ
	
	To our Meridian Crew:
		- Gaby
		- Ivan aka Docs
		- Francois
		- Vinz (First wallen Fans) 
		- Ragnagna
		- Anthony P aka Gary (Dreamcast console de Jeu)
		- Anthony F
				

	To All TGE2 Team...

	To All People GBADEV Mailing-List

	Big Respect to All GBA coder;
		- ZoneGN
		- Russ Prince
		- Leonard/OXYGENE
		- Codewaves
		- Pern Project
		- StaringMonkey
		- Forgotten for VisualBoyAdvance
		- Gollum for BoycottAdvance
		- French Coder (Vous dechirez !!!)




GRAND Merci NINTENDO pour la GBA: quelle merveilleuse machine !