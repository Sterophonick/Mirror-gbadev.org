// sound.c

/*
Address: 0x04000068 - REG_SOUND2CNT_L (Sound 2 Length, wave duty and envelope control)(Unimplemented in CowBite)

                      W W  W W W W
F E D C  B A 9 8  7 6 5 4  3 2 1 0 
I I I I  M T T T  D D L L  L L L L
0-5 (L) = Sound length. This is a 6 bit value obtained from the following
          formula:  Sound length= (64-register value)*(1/256) seconds.
          After the sound length has been changed, the sound channel must be
          resetted via bit F of REG_SOUND1CNT_X (when using timed mode). 

6-7 (D) = Wave duty cycle. This controls the percentage of the ON state of
          the square wave.
          
          00 - 12.5%
          01 - 25%
          10 - 50%
          11 - 75%
8-A (T) = Envelope step time. This is the delay between successive envelope increase
          or decrease. It is given by the following formula: Time=register value*(1/64)
          seconds. 

B   (M) = Envelope mode. Controls if the envelope is to increase or decrease in volume
          over time.
        
          0 - Envelope decreases
          1 - Envelope increases
C-F (I) = Initial Envelope value. 1111 produces the maximum volume and 0000 mutes
          the sound. When sound 2 is playing, modifying the volume envelope bits has
          no effect until the sound is resetted.


Address: 0x0400006C- REG_SOUND2CNT_H (Sound 2 Frequency, reset and loop control)(Unimplemented in CowBite)

W          W W W  W W W W  W W W W
F E D C  B A 9 8  7 6 5 4  3 2 1 0 
R T X X  X F F F  F F F F  F F F F

0-A (F) = Sound frequency. The minimum frequency is 64Hz and the maximum is
         131Khz. Can be calculated from the following formula:
         F(hz)=4194304/(32*(2048-register value)).

E   (T) = Timed sound. When set to 0, sound 2 is played continuously regardless of
          the length data in REG_SOUND2CNT_L. When set to 1, sound is played for
          that specified length and after that, bit 1 of REG_SOUNDCNT_X is reset.

F   (R) = Sound reset. When set, sound resets and restarts at the specified
          frequency. When sound 2 is playing, modifying the volume envelope bits
          has no effect until the sound is resetted. Frequency and sound reset must
          be perfomed in a single write since both are write only. Frequency can
          always be changed without resetting the sound channel.


*/

/*
C	262 Hz - 0x60C
C#	277 Hz - 0x627
D	294 Hz - 0x643
D#	311 Hz - 0x65B
E	330 Hz - 0x673
F	349 Hz - 0x689
F#	370 Hz - 0x69E
G	392 Hz - 0x6B2
G#	415 Hz - 0x6C5
A	440 Hz - 0x6D7
A#	466 Hz - 0x6E7
B	494 Hz - 0x6F7

C	523 Hz - 0x706
C#	554 Hz - 0x714
D	587 Hz - 0x721
D#	622 Hz - 0x72E
E	659 Hz - 0x73A
F	698 Hz - 0x745
F#	740 Hz - 0x74F
G	784 Hz - 0x759
G#	831 Hz - 0x763
A	880 Hz - 0x76C
A#	932 Hz - 0x774
B	988 Hz - 0x77C
*/

#include "gba.h"
#include "sound.h"

void InitSound(void)
{
	// Turn on sound circuit
	REG_SOUNDCNT_X = 0x80;

	// Full volume, enable sound 1 & 2 to left and right
	REG_SOUNDCNT_L = 0x3377;

	// Overall output ratio - Full
	REG_SOUNDCNT_H = 2;
}

/*
void PlaySoundChannel1(u8 duration, u16 frequency, u16 duty_cicle)
{
	REG_SOUND1CNT_L=0x0011; //sweep shifts=6, increment, sweep time=39.1ms
	REG_SOUND1CNT_H=0xF000 | duty_cicle | duration;
	REG_SOUND1CNT_X=0xC000 | frequency;
}
*/

void PlaySoundChannel2(u8 duration, u16 frequency, u16 duty_cicle)
{
	REG_SOUND2CNT_L = 0xF000 | duty_cicle | duration;    // No Envelope
	REG_SOUND2CNT_H = 0xC000 | frequency;				 // Timed mode
}

void PlayMelody( const u16* notes, u16 size )
{
	u16 i;

	for( i = 0; i < size; i++)
	{
		PlaySoundChannel2( 0xA0, notes[i], DUTY_CICLE_50 );

		// wait while the sound is playing
		while(REG_SOUNDCNT_X & 2)
		{
		}
	}
}
