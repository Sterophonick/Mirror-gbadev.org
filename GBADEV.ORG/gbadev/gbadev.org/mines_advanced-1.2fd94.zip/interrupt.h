//////////////////////////////////////////////////////////////////////////
//        File: interrupt.h                                            	//
// Description: Keypad Control Registers and Definitions				//
//      Author:	Vortex 													//
//        Date: January,11 2003                                     	//
//////////////////////////////////////////////////////////////////////////

#ifndef __INTERRUPT_H
#define __INTERRUPT_H

u32* UserInterruptHandler = (u32*) 0x03007FFC;

//////////////////////////////////////////////////////////////////////////
// Interrupt Registers

// IME - Interrupt Master Enable Register (R/W)
// IE  - Interrupt Enable Register (R/W)
// IF  - Interrupt Request Flags / IRQ Acknowledge

volatile u16* IME = (volatile u16*)0x04000208;
volatile u16* IE  = (volatile u16*)0x04000200;
volatile u16* IF  = (volatile u16*)0x04000202;

//////////////////////////////////////////////////////////////////////////
// IME bits

#define IME_DISABLE_ALL	(1)

//////////////////////////////////////////////////////////////////////////
// IE bits

#define IE_LCD_VBLANK			(1)
#define IE_LCD_HBLANK			(2)
#define IE_LCD_VCOUNTER_MATCH	(4)
#define IE_TIMER0_OVERFLOW		(8)
#define IE_TIMER1_OVERFLOW		(16)
#define IE_TIMER2_OVERFLOW		(32)
#define IE_TIMER3_OVERFLOW		(64)
#define IE_SERIAL_COMM			(128)
#define IE_DMA0					(256)
#define IE_DMA1					(512)
#define IE_DMA2					(1024)
#define IE_DMA3					(2048)
#define IE_KEYPAD				(4096)
#define IE_GAMEPAK				(8192)

//////////////////////////////////////////////////////////////////////////
// IF bits

#define IF_LCD_VBLANK			(1)
#define IF_LCD_HBLANK			(2)
#define IF_LCD_VCOUNTER_MATCH	(4)
#define IF_TIMER0_OVERFLOW		(8)
#define IF_TIMER1_OVERFLOW		(16)
#define IF_TIMER2_OVERFLOW		(32)
#define IF_TIMER3_OVERFLOW		(64)
#define IF_SERIAL_COMM			(128)
#define IF_DMA0					(256)
#define IF_DMA1					(512)
#define IF_DMA2					(1024)
#define IF_DMA3					(2048)
#define IF_KEYPAD				(4096)
#define IF_GAMEPAK				(8192)

#endif  // __INTERRUPT_H


