Mines Advanced version 1.2 by Vortex (vortex1939@yahoo.com)
-----------------------------------------------------------
May 31 2003

Programing and graphics by Vortex.

WHAT'S NEW IN THAT VERSION

* The source code is included (GPL license)
* Basic sound support
* Larger game field
* DMA ClearScreen for Mode 3 implement 
* Cleanup the main loop 
* Fade In/Fade Out effects
* Animated flags

TODO:

* Use Mode4 instead Mode3 for the compressed image
* Implement DMA ClearScreen using Mode 4
* Use a better font (8x16 or 16x16)
* Tile animation for explosions 
* Design a better side panel 
* Game options: gamefield size, number of mines
* Implement a scrollable gamefield 
* Scoreboard with top scores (+save)
* Wizard mode - autodetection/resolve of trivial combinations

RULES:

The object of Mines Advanced is to find mines which have 
been hidden at random on a grid.
The grid is 15x10 and there are 15 mines to be found. 

GAME CONTROLS

  D-PAD: Move cursor in playing area
      A: Reveal Mine
 	  B: Mark Mine
  RIGHT: Automatically reveal all surrounding cases not marked by a flag
  START: New Game/End Game
 SELECT: Show/Hide Info Panel


TESTING

Tested using VBA, BATGBA and hardware (multiboot mode)


SPECIAL THANKS

tepples
Splam




