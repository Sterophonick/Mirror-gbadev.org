// sound.h

#ifndef SOUND_H
#define SOUND_H

#define DUTY_CICLE_12 (0x0000)
#define DUTY_CICLE_25 (0x0040)
#define DUTY_CICLE_50 (0x0080)
#define DUTY_CICLE_75 (0x00C0)

void InitSound(void);
void PlaySoundChannel2(u8 duration, u16 frequency, u16 duty_cicle );
void PlayMelody( const u16* notes, u16 size );

#endif	// SOUND_H




