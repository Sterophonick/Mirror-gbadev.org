/*********************************************************************

 Mines Advanced for GBA
 Copyright (C) 2003 Vortex (vortex1939@yahoo.com)

 This program is free software; you can redistribute it and/or
 modify it under the terms of the GNU General Public License
 as published by the Free Software Foundation; either version 2
 of the License, or (at your option) any later version.

 This program is distributed in the hope that it will be useful,
 but WITHOUT ANY WARRANTY; without even the implied warranty of
 MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 GNU General Public License for more details.

 You should have received a copy of the GNU General Public License
 along with this program; if not, write to
   Free Software Foundation, Inc., 59 Temple Place - Suite 330,
   Boston, MA  02111-1307, USA.
 GNU licenses can be viewed online at http://www.gnu.org/copyleft/

 *********************************************************************/

/*********************************************************************
 Nintendo and Game Boy are trademarks of Nintendo.

 This is NOT a Nintendo product, nor is it in any way licensed by
 Nintendo of America Inc.  The "Nintendo" logo displayed at the start
 of the program is the result of a checksum performed on the ROM
 data, and the inclusion thereof is a fair use of Nintendo's copyrights
 and trademarks under the Sega v. Accolade precedent.

 *********************************************************************/

////////////////////////////////////////////////////////////////////////////////
//     file: minesweeper.c
//  version: 1.2
// revision: 41
////////////////////////////////////////////////////////////////////////////////

////////////////////////////////////////////////////////////////////////////////
// TODO:
//
// version 1.1
// 1. Use Mode4 instead Mode3 for the compressed image
// 2. Implement DMA ClearScreen for modes 3 (done) and 4
// 3. Cleanup the main loop (done)
// 4. Fade In/Fade Out (done)
//
// version 1.2
// 1. Use better font (8x16 or 16x16)
// 2. Tile animation for explosions and flags (done)
// 3. Basic sound implementation (fx only, no bg music) (done)
// 4. Design a better side panel and make it use different bg layer
//
// version 2.0
// 1. Game options: gamefield size, number of mines
// 2. Implement a scrolling gamefield + (semitransparent???) floating panel (2 bg)
// 3. Scoreboard with top scores (save)
// 4. Wizard mode - autodetection/resolve of trivial combinations
//
////////////////////////////////////////////////////////////////////////////////

#define MULTIBOOT int __gba_multiboot;
MULTIBOOT

/*****************************************************************
 Keypad Controls:

  D-PAD: Move cursor in playing area
      A: Reveal Mine
 	  B: Mark Mine
  RIGHT: Automatically reveal all surrounding cases not marked by a flag
  START: New Game/End Game
 SELECT: Show/Hide Info Panel
 *****************************************************************/

#include "gba.h"
#include "screenmode.h"
#include "sprites.h"
#include "keypad.h"
#include "interrupt.h"
#include "sound.h"

 // Sound duration
#define TONE_DURATION (0xBD)

const u16 hello_melody[4] = { 0x74F, 0x6F7, 0x714, 0x721 };		// F#4, B3, C#4, D4
const u16 win_melody[4]   = { 0x60C, 0x673, 0x6B2, 0x706 };		// C3,E3,G3,C4
const u16 lost_melody[4]  = { 0x6D7, 0x706, 0x73A, 0x706 };

volatile u32* OAMmem  			=(volatile u32*)0x7000000;
volatile u16* VideoBuffer 		=(volatile u16*)0x6000000;
volatile u16* OAMData			=(volatile u16*)0x6010000;
volatile u16* BGPaletteMem 		=(volatile u16*)0x5000000;
volatile u16* OBJPaletteMem 	=(volatile u16*)0x5000200;

//////////////////////////////////////////////////////////////////////////
// IF bits

#define INT_VBLANK			(1)
#define INT_HBLANK			(2)
#define INT_VCOUNT			(4)
#define INT_TIMER0			(8)
#define INT_TIMER1			(16)
#define INT_TIMER2			(32)
#define INT_TIMER3			(64)
#define INT_COMMUNICATION	(128)
#define INT_DMA0			(256)
#define INT_DMA1			(512)
#define INT_DMA2			(1024)
#define INT_DMA3			(2048)
#define INT_KEYBOARD		(4096)
#define INT_CART			(8192)

//////////////////////////////////////////////////////////////////////////////////
// Splash screens

extern const char bmp_logo[];

//////////////////////////////////////////////////////////////////////////////////
// Sprites definitions

#include "bmpCursor.h"
//#include "bmpFaces.h"

#define NUM_SPRITES             (1)
#define SPRITE_WIDTH            (16)
#define SPRITE_HEIGHT           (16)
#define SPRITE_DATA_START_INDEX (512)

//////////////////////////////////////////////////////////////////////////////////
// Sprite variables

//create an OAM variable and make it point to the address of OAM
u16* OAM = (u16*)0x7000000;

// Create the array of sprites (128 is the maximum)
OAMEntry sprites[128];
// pRotData rotData = (pRotData)sprites;

//////////////////////////////////////////////////////////////////////////////////
// Tiles definitions
#include "bmpTiles.h"

// 57+18+18
// 18: 0123456789-MTimnes

#define NUM_TILES   (101)

#define MAP_WIDTH   (32)
#define MAP_HEIGHT  (32)

u16 bg2_buffer[ MAP_WIDTH * MAP_HEIGHT ];
u16 bg3_buffer[ MAP_WIDTH * MAP_HEIGHT ];

struct BGControl
{
	unsigned Priority            : 2;
	unsigned CharacterBaseBlock  : 2;
	unsigned NotUsed             : 2;
	unsigned Mosaic              : 1;
	unsigned ColorPalettes       : 1;
	unsigned ScreenBaseBlock     : 5;
	unsigned DisplayAreaOverflow : 1;
	unsigned ScreenSize          : 2;
} __attribute__ ((aligned (2),packed));

//////////////////////////////////////////////////////////////////////////////////
// Tile variables

#define CharBaseBlock(n)		(((n)*0x4000)+0x6000000)
#define ScreenBaseBlock(n)		(((n)*0x800) +0x6000000)

#define BG2_CHR_BASE (0)
#define BG2_SCR_BASE (16)

#define BG3_CHR_BASE (0)
#define BG3_SCR_BASE (8)

u16* BgTiles     = (u16*) CharBaseBlock(BG3_CHR_BASE);		//tells the compiler to load all the tile info into that address
u16* Bg2MapData  = (u16*) ScreenBaseBlock(BG2_SCR_BASE);
u16* Bg3MapData  = (u16*) ScreenBaseBlock(BG3_SCR_BASE);

//////////////////////////////////////////////////////////////////////////////////
// Game Matrix

// End Game Flags

#define GAME_CONTINUE (0)
#define GAME_WIN      (1)
#define GAME_LOST	  (2)
#define GAME_NEW	  (3)

#define TRUE  (1)
#define FALSE (0)

#define UNOPENED_TILE_INDEX		 1
#define OPENED_TILE_INDEX		 2
#define MINE_TILE_INDEX			 3
#define EXLODED_MINE_TILE_INDEX  4
#define WRONG_FLAG_TILE_INDEX    5
#define FLAG_TILE_INDEX			 6
#define NUMBER_TILE_INDEX		 7

#define FLAG_TILE_ANI1_INDEX     15
#define FLAG_TILE_ANI2_INDEX     16

const u8 FlagAnimationTiles[4] = { FLAG_TILE_ANI1_INDEX, FLAG_TILE_INDEX, FLAG_TILE_ANI2_INDEX, FLAG_TILE_INDEX };

#define NUM_MINES     (15)
#define MATRIX_WIDTH  (15)
#define MATRIX_HEIGHT (10)

typedef struct tagPoint
{
	u8 col;
	u8 row;
} Point;

struct tagCell
{
	unsigned mine       : 1;
	unsigned open       : 1;
	unsigned mark       : 1;
	unsigned neighbors  : 5;
	unsigned tile       : 8;
} __attribute__ ((aligned (2),packed));

typedef struct tagCell Cell;

// Game matrix
Cell matrix[MATRIX_HEIGHT][MATRIX_WIDTH];

//////////////////////////////////////////////////////////////////////////////////
// Global variables

static          u32 NumMines;
static volatile u32 TimeElapsed;

//////////////////////////////////////////////////////////////////////////////////
// Prototypes

int  rand(void);
void matrixInitialize(u32 num_mines);
u32  matrixCellNeighbors(u32 row, u32 col);
u32  matrixCellMarked( u32 row, u32 col );
u32  matrixCellMarkedMines( u32 row, u32 col );
void matrixCalcNeighbors(void);
void matrixRandomize(int num_mines);
void matrixMapToBackground(void);
u32  matrixAllSpacesOpen(void);
void matrixAutoReveal( u32 cursor_col, u32 cursor_row, u32* last_col, u32* last_row, u32* game_flag, u32* auto_reveal_flag );
void matrixAutoRevealCell( u32 row, u32 col );
void matrixAutoRevealSetTiles( u32 row, u32 col, u32 pressed );
void matrixRevealWrongMark( u32 row, u32 col );
void matrixFill(u32 row, u32 col);
void matrixMarkMine(u32 row, u32 col);
u32  matrixRevealMine(u32 row, u32 col);
void matrixAnimateFlags(void);
void matrixAnimateExplosion(void);

void WaitForVSync(void);

void ClearPanelIndicator( u32 left, u32 right, u32 row );
void InitPanel(void);
void UpdateCounters( s32 num_mines, u32 seconds );

//////////////////////////////////////////////////////////////////////////////////
// Decompression Functions (defined in LZ77.s)

extern void LZ77UnCompWram(void *src, void *dest);
extern void LZ77UnCompVram(void *src, void *dest);

//////////////////////////////////////////////////////////////////////////////////
// Matrix Functions

int rand(void)
{
	static int work = 0xD371F947;

	work = work * 0x41C64E6D + 0x3039;
	return(( work >> 16) &0x7FFF );
}

// Initializes the game matrix. Fills the matrix with random mines.
// Calculates the number of neighbors for each field

void matrixInitialize( u32 num_mines )
{
	u32 row, col;

	for( row = 0; row < MATRIX_HEIGHT; row ++ )
		for( col = 0; col < MATRIX_WIDTH; col ++ )
		{
			matrix[row][col].mine = FALSE;
			matrix[row][col].open = FALSE;
			matrix[row][col].mark = FALSE;
			matrix[row][col].neighbors = 0;
			matrix[row][col].tile = UNOPENED_TILE_INDEX;
		}

	matrixRandomize( num_mines );
	matrixCalcNeighbors();
}

void matrixAutoRevealSetTiles( u32 row, u32 col, u32 pressed )
{
	u32 r,c;
	u32 start_row = (row > 0) ? row-1 : 0;
	u32 end_row   = (row < MATRIX_HEIGHT-1) ? row+1 : MATRIX_HEIGHT-1;
	u32 start_col = (col > 0) ? col-1 : 0;
	u32 end_col   = (col < MATRIX_WIDTH-1)  ? col+1 : MATRIX_WIDTH-1;

	for( r = start_row; r <= end_row; r++ )
		for( c = start_col; c <= end_col; c++ )
		{
			// Skip the center cell
			if( r == row && c == col )
				continue;

			if( ! matrix[r][c].mark && ! matrix[r][c].open )
			{
				if( pressed )
					matrix[r][c].tile = OPENED_TILE_INDEX;
				else
					matrix[r][c].tile = UNOPENED_TILE_INDEX;
			}
		}
}

void matrixAutoReveal( u32 cursor_col, u32 cursor_row, u32* last_col, u32* last_row, u32* game_flag, u32* auto_reveal_flag )
{
	u32 auto_reveal_done = FALSE;

	if( matrix[cursor_row][cursor_col].open &&	matrix[cursor_row][cursor_col].neighbors > 0 )
	{
		u32 num_marked = matrixCellMarked(cursor_row,cursor_col);

		if( matrix[cursor_row][cursor_col].neighbors  == num_marked )
		{
			// We have correct marks on mines
			if( matrixCellMarkedMines(cursor_row,cursor_col))
			{
				matrixAutoRevealCell( cursor_row,cursor_col );
			}
			// Incorrect marks on mines: show the errors and end the game
			else
			{
				matrixRevealWrongMark( cursor_row,cursor_col );
				*game_flag = GAME_LOST;
			}

			auto_reveal_done = TRUE;
		}
	}

	// Show open tiles while the key is pressed
	if( ! auto_reveal_done )
		{
			*last_col = cursor_col;
			*last_row = cursor_row;

			*auto_reveal_flag = TRUE;

			matrixAutoRevealSetTiles( cursor_row, cursor_col, TRUE );
		}
}

// Reveals the surround 8 cells
void matrixAutoRevealCell( u32 row, u32 col )
{
	u32 r,c;
	u32 start_row = (row > 0) ? row-1 : 0;
	u32 end_row   = (row < MATRIX_HEIGHT-1) ? row+1 : MATRIX_HEIGHT-1;
	u32 start_col = (col > 0) ? col-1 : 0;
	u32 end_col   = (col < MATRIX_WIDTH-1)  ? col+1 : MATRIX_WIDTH-1;

	for( r = start_row; r <= end_row; r++ )
		for( c = start_col; c <= end_col; c++ )
		{
			// Skip the center cell
			if( r == row && c == col )
				continue;

			if( ! matrix[r][c].mark && ! matrix[r][c].open )
				matrixFill( r, c );
		}
}

u32 matrixCellMarkedMines( u32 row, u32 col )
{
	u32 r,c;
	u32 start_row = (row > 0) ? row-1 : 0;
	u32 end_row   = (row < MATRIX_HEIGHT-1) ? row+1 : MATRIX_HEIGHT-1;
	u32 start_col = (col > 0) ? col-1 : 0;
	u32 end_col   = (col < MATRIX_WIDTH-1)  ? col+1 : MATRIX_WIDTH-1;

	for( r = start_row; r <= end_row; r++ )
		for( c = start_col; c <= end_col; c++ )
		{
			// Skip the center cell
			if( r == row && c == col )
				continue;

			// If there is a mark but not mine or there is a mine but not a mark
			// return false
			if((matrix[r][c].mark && ! matrix[r][c].mine) || (!matrix[r][c].mark && matrix[r][c].mine))
				return FALSE;
		}

	return TRUE;
}

// Calculates the number of surrounding marked cells
u32 matrixCellMarked( u32 row, u32 col )
{
	u32 r,c;
	u32 start_row = (row > 0) ? row-1 : 0;
	u32 end_row   = (row < MATRIX_HEIGHT-1) ? row+1 : MATRIX_HEIGHT-1;
	u32 start_col = (col > 0) ? col-1 : 0;
	u32 end_col   = (col < MATRIX_WIDTH-1)  ? col+1 : MATRIX_WIDTH-1;
	u32 num = 0;

	for( r = start_row; r <= end_row; r++ )
		for( c = start_col; c <= end_col; c++ )
		{
			// Skip the center cell
			if( r == row && c == col )
				continue;

			if( matrix[r][c].mark )
				num++;
		}

	return num;
}

// Calculates the number of surrounding mine cells
u32 matrixCellNeighbors( u32 row, u32 col )
{
	u32 r,c;
	u32 start_row = (row > 0) ? row-1 : 0;
	u32 end_row   = (row < MATRIX_HEIGHT-1) ? row+1 : MATRIX_HEIGHT-1;
	u32 start_col = (col > 0) ? col-1 : 0;
	u32 end_col   = (col < MATRIX_WIDTH-1)  ? col+1 : MATRIX_WIDTH-1;
	u32 num = 0;

	for( r = start_row; r <= end_row; r++ )
		for( c = start_col; c <= end_col; c++ )
		{
			// Skip the center cell
			if( r == row && c == col )
				continue;

			if( matrix[r][c].mine )
				num++;
		}

	return num;
}

// Calculates the number of surrounding mine cells for the
// entire matrix
void matrixCalcNeighbors(void)
{
	u32 row, col;

	for( row = 0; row < MATRIX_HEIGHT; row ++ )
		for( col = 0; col < MATRIX_WIDTH; col ++ )
			if( ! matrix[row][col].mine )
				matrix[row][col].neighbors = matrixCellNeighbors( row, col );
}

// A flood fill function which reveals
// cells with zero neighbors
void matrixFill( u32 row, u32 col )
{
	u32 r,c;
	u32 start_row = (row > 0) ? row-1 : 0;
	u32 end_row   = (row < MATRIX_HEIGHT-1) ? row+1 : MATRIX_HEIGHT-1;
	u32 start_col = (col > 0) ? col-1 : 0;
	u32 end_col   = (col < MATRIX_WIDTH-1)  ? col+1 : MATRIX_WIDTH-1;

	if( matrix[row][col].open || matrix[row][col].mark )
		return;

	matrix[row][col].open = TRUE;

	if( matrix[row][col].neighbors > 0 )
	{
		matrix[row][col].tile = NUMBER_TILE_INDEX + matrix[row][col].neighbors - 1;
		return;
	}
	else
		matrix[row][col].tile = OPENED_TILE_INDEX;

	for( r = start_row; r <= end_row; r++ )
		for( c = start_col; c <= end_col; c++ )
		{
			// Skip the center cell
			if( r == row && c == col )
				continue;

			matrixFill( r, c );
		}
}

// Populates the game matrix with randon mines
void matrixRandomize( int num_mines )
{
	u32 i;
	int row,col;

	for( i = 0; i < num_mines; i++ )
	{
		do
		{
			do
				row = rand() & 0x0F;
			while( row < 0 || row >= MATRIX_HEIGHT );

			do
				col = rand() & 0x0F;
			while( col < 0 || col >= MATRIX_WIDTH );
		}
		while( matrix[row][col].mine == TRUE );

		matrix[row][col].mine = TRUE;
	}
}

/*
// Reveals the matrix cells
void matrixReveal(void)
{
	u32 row, col;

	for( row = 0; row < MATRIX_HEIGHT; row ++ )
		for( col = 0; col < MATRIX_WIDTH; col ++ )
		{
			if( matrix[row][col].mine == TRUE )
				matrix[row][col].tile = MINE_TILE_INDEX;
			else if( matrix[row][col].neighbors > 0 )
				matrix[row][col].tile = NUMBER_TILE_INDEX + matrix[row][col].neighbors - 1;
			else
				matrix[row][col].tile = OPENED_TILE_INDEX;
		}
}
*/

// Reveals the matrix cells when a mine is hit
void matrixRevealExplode( u32 row, u32 col )
{
	u32 r, c;

	for( r = 0; r < MATRIX_HEIGHT; r ++ )
		for( c = 0; c < MATRIX_WIDTH; c ++ )
			if( matrix[r][c].mine )
				matrix[r][c].tile = MINE_TILE_INDEX;

	matrix[row][col].tile = EXLODED_MINE_TILE_INDEX;
}

void matrixRevealWrongMark( u32 row, u32 col )
{
	u32 r, c;
	u32 start_row = (row > 0) ? row-1 : 0;
	u32 end_row   = (row < MATRIX_HEIGHT-1) ? row+1 : MATRIX_HEIGHT-1;
	u32 start_col = (col > 0) ? col-1 : 0;
	u32 end_col   = (col < MATRIX_WIDTH-1)  ? col+1 : MATRIX_WIDTH-1;

	// First show all unmarked mines
	for( r = 0; r < MATRIX_HEIGHT; r ++ )
		for( c = 0; c < MATRIX_WIDTH; c ++ )
			if( matrix[r][c].mine && ! matrix[r][c].mark )
				matrix[r][c].tile = MINE_TILE_INDEX;

	// Second scan the surrounding cell for wrong marks
	for( r = start_row; r <= end_row; r++ )
		for( c = start_col; c <= end_col; c++ )
		{
			// Skip the center cell
			if( r == row && c == col )
				continue;

			if( matrix[r][c].mine && ! matrix[r][c].mark )
				matrix[r][c].tile = EXLODED_MINE_TILE_INDEX;

			if( ! matrix[r][c].mine && matrix[r][c].mark )
				matrix[r][c].tile = WRONG_FLAG_TILE_INDEX;
		}
}

// Checks the end game condition
// Count the number of open cells and mines
// and compares with the total number of cells
u32 matrixAllSpacesOpen(void)
{
	u32 row, col;
	u32 opened = 0;
	u32 marked = 0;

	for( row = 0; row < MATRIX_HEIGHT; row ++ )
		for( col = 0; col < MATRIX_WIDTH; col ++ )
		{
			if( matrix[row][col].open )
				opened++;

			if( matrix[row][col].mark && matrix[row][col].mine )
				marked++;
		}

	if( opened == (MATRIX_HEIGHT * MATRIX_WIDTH - NUM_MINES) && marked == NUM_MINES )
		return TRUE;

	return FALSE;
}

// Renders 16x16 meta-tiles into hardware tiles
void matrixMapToBackground(void)
{
	u32 row, col;
	u32 matrix_index;
	u32 map_index1, map_index2;

	for( row = 0; row < MATRIX_HEIGHT; row ++ )
		for( col = 0; col < MATRIX_WIDTH; col ++ )
		{
			if( matrix[row][col].tile == 0 )
			{
				map_index1 = (row << 1)       * MAP_WIDTH;
				map_index2 = ((row << 1) + 1) * MAP_WIDTH;

				bg3_buffer[ map_index1 + (col << 1) ]     =
				bg3_buffer[ map_index1 + (col << 1) + 1 ] =
				bg3_buffer[ map_index2 + (col << 1) ]	   =
				bg3_buffer[ map_index2 + (col << 1) + 1]  = 0;
			}
			else
			{
				map_index1 = (row << 1)       * MAP_WIDTH;
				map_index2 = ((row << 1) + 1) * MAP_WIDTH;

				matrix_index = (matrix[row][col].tile-1) << 2;

				bg3_buffer[ map_index1 + (col << 1) ]      = matrix_index + 1;
				bg3_buffer[ map_index1 + (col << 1) + 1 ]  = matrix_index + 2;
				bg3_buffer[ map_index2 + (col << 1) ]		= matrix_index + 3;
				bg3_buffer[ map_index2 + (col << 1) + 1]	= matrix_index + 4;
			}
		}
}

// Places/removes a mark
void matrixMarkMine(u32 row, u32 col)
{
	if( ! matrix[row][col].open )
	{
		if( ! matrix[row][col].mark )
		{
			matrix[row][col].mark = TRUE;
			matrix[row][col].tile = FLAG_TILE_INDEX;
			NumMines--;
		}
		else
		{
			matrix[row][col].mark = FALSE;
			matrix[row][col].tile = UNOPENED_TILE_INDEX;
			NumMines++;
		}
	}
}

// Animates all of the marked mines
void matrixAnimateFlags(void)
{
	static u32 counter = 0;
	static u32 ani_sec = 0;
	u32 row, col;

	if( ++counter == 10 )
	{
		for( row = 0; row < MATRIX_HEIGHT; row ++ )
			for( col = 0; col < MATRIX_WIDTH; col ++ )
			{
				if( matrix[row][col].mark == TRUE )
					matrix[row][col].tile = FlagAnimationTiles[ani_sec];
			}

		ani_sec++;
		ani_sec %= 4;
		counter = 0;
	}
}

// Animates all of the expoded mines
void matrixAnimateExplosion(void)
{
	u32 row, col;

	for( row = 0; row < MATRIX_HEIGHT; row ++ )
		for( col = 0; col < MATRIX_WIDTH; col ++ )
		{
			if( matrix[row][col].tile == EXLODED_MINE_TILE_INDEX )
			{
				// do something
			}
		}
}

// Opens a cell. If the cell contains a mine, reveals the game field
// and ends the game
// returns TRUE if the game is over, FALSE otherwise
u32 matrixRevealMine(u32 row, u32 col)
{
	u32 end_flag = FALSE;

	if( ! matrix[row][col].mark && ! matrix[row][col].open )
	{
		if( matrix[row][col].mine )
		{
			matrixRevealExplode( row,col );
			end_flag = TRUE;
		}
		else
		{
			if( matrix[row][col].neighbors > 0 )
			{
				matrix[row][col].tile = NUMBER_TILE_INDEX + matrix[row][col].neighbors - 1;
				matrix[row][col].open = TRUE;
			}
			else
				matrixFill( row, col );
		}
	}

	return end_flag;
}

//////////////////////////////////////////////////////////////////////////////////
// Background and Tile Functions

void BgClearVRAM( void )
{
	static const u16 zero = 0;

	(REG_DMA3SAD)   = (u32) &zero;
 	(REG_DMA3DAD)   = (u32) VideoBuffer;
	(REG_DMA3CNT_L) = 0x7C00;
	(REG_DMA3CNT_H) = 0x8100;
}

void RefreshBackground(void)
{
	// Copy the bg3_buffer data
	// DMA FLAGS (REG_DMA3CNT_H):
	// DMA_ENABLE | DMA_START_TIMING=VBlank | DMA_TRANSFER_TYPE=32bit
	(REG_DMA3SAD)   = (u32) bg2_buffer;
 	(REG_DMA3DAD)   = (u32) Bg2MapData;
	(REG_DMA3CNT_L) = (MAP_HEIGHT * MAP_WIDTH / 2);
	(REG_DMA3CNT_H) = 0x8400;	// 0x9400;

	WaitForVSync();
	(REG_DMA3SAD)   = (u32) bg3_buffer;
 	(REG_DMA3DAD)   = (u32) Bg3MapData;
	(REG_DMA3CNT_L) = (MAP_HEIGHT * MAP_WIDTH / 2);
	(REG_DMA3CNT_H) = 0x8400;
}

void InitializeBackground(void)
{
	u32 i;

	BgClearVRAM();

	for ( i = 0; i < 256; i++ )
		BGPaletteMem[i] = tilesPalette[i];				// Load the pallette info into the desired address

	// we have NUM_TILES 8x8 256 color tiles:
	// NUM_TILES * 64 bytes or NUM_TILES * 32 words

	for( i = 0; i < NUM_TILES * 32; i++)
		BgTiles[i] = tiles[i];							// Load the bg BgTiles into the desired address

	InitPanel();

	WaitForVSync();
	RefreshBackground();
}

//////////////////////////////////////////////////////////////////////////////////
// Fade In/Fade Out Functions

// Special Effect Registers
volatile u16* BLDMOD = (volatile u16*) 0x4000050;	// REG_BLDMOD
volatile u16* COLEV  = (volatile u16*) 0x4000052;	// REG_COLEV
volatile u16* COLY   = (volatile u16*) 0x4000054;	// REG_COLY

void WaitBlanks(u32 numBlanks)
{
	u32 i = 0;

	while(i < numBlanks)
	{
		WaitForVSync();
		i++;
	}
}

// val: 0-16
static void BgFadeIn(u16 val)
{
	// First  Target: BG1, Second Target: BG2, Mode: 01
	*BLDMOD = 0x084;
	*COLY   = val;
}

// val: 0-16
static void BgFadeOut(u16 val)
{
//	*BLDMOD = 0x00C4;		// BG2
	*BLDMOD = 0x00DF;		// BG0,1,2,3 and SPRITES
	*COLY   = val;
}

#define FADE_WAIT_TIME 50

void BackgroundFadeOut(void)
{
	u16 val;

	for( val = 0; val <= 16; val++ )
	{
		WaitBlanks(FADE_WAIT_TIME);
		BgFadeOut(val);
	}
}

void BackgroundFadeIn(void)
{
	u16 val;

	for( val = 17; val > 0; val-- )
	{
		WaitBlanks(FADE_WAIT_TIME);
		BgFadeOut(val-1);
	}
}

//////////////////////////////////////////////////////////////////////////////////
// Text Functions

#define FIRST_CHAR_TILE_INDEX (75+8)

u16 DecodeChar( char c )
{
	switch(c)
	{
		case '-':
			return FIRST_CHAR_TILE_INDEX + 10;
		case 'M':
			return FIRST_CHAR_TILE_INDEX + 11;
		case 'T':
			return FIRST_CHAR_TILE_INDEX + 12;
		case 'i':
			return FIRST_CHAR_TILE_INDEX + 13;
		case 'm':
			return FIRST_CHAR_TILE_INDEX + 14;
		case 'n':
			return FIRST_CHAR_TILE_INDEX + 15;
		case 'e':
			return FIRST_CHAR_TILE_INDEX + 16;
		case 's':
			return FIRST_CHAR_TILE_INDEX + 17;
	}

	if( c >= '0' && c <= '9' )
		return (c - '0') + FIRST_CHAR_TILE_INDEX;

	return 0;
}

u32 StrLen( const char * text )
{
	u32 len = 0;

	while( *text++ )
		len++;

	return len;
}

#define ITOA_BUFFER_SIZE 8

char * ItoA( s32 num )
{
	static char  stack[ITOA_BUFFER_SIZE];
	static char  buffer[ITOA_BUFFER_SIZE+1];

	u32 pos = 0;
	u32 tos = 0;

	if( num == 0 )
		buffer[pos++] = '0';
	else if( num < 0 )
	{
		buffer[pos++] = '-';
		num = -num;
	}

	while( num > 0 && tos < ITOA_BUFFER_SIZE )
	{
		stack[tos++] = (char) (num % 10) + '0';
		num /= 10;
	}

	while( tos > 0 )
		buffer[pos++] = stack[--tos];

	buffer[pos] = '\0';

	return buffer;
}

void Center( u32 row, u32 left, u32 right, const char * text )
{
	u32 i;
	u32 len = StrLen(text);

	u32 col   = left + ((right-left+1) - len) / 2;
	u32 cell  = row * MAP_WIDTH + col;

	for( i = 0; i < len; i++ )
		bg2_buffer[cell++] = DecodeChar( text[i] );
}

void Print( u32 row, u32 col, const char * text )
{
	u32 i;
	u32 len   = StrLen(text);
	u32 cell  = row * MAP_WIDTH + col;
	u32 left  = 30 - col;
	u32 last  = len > left ? left : len;

	// row: 0-19
	// col: 0-29

	/*
	if( row > 19 || col > 29 )
		return;
	*/

	for( i = 0; i < last; i++ )
		bg2_buffer[cell++] = DecodeChar( text[i] );
}

//////////////////////////////////////////////////////////////////////////////////
// Side Panel Functions
/*
u16 PanelTop  =  1;
u16 PanelLeft = 24;

void InitPanel(void)
{
	Print( PanelTop  , PanelLeft, "Mines");
	Print( PanelTop+3, PanelLeft, "Time" );
}

void UpdateCounters( s32 num_mines, u32 seconds )
{
	u32 i;

	for( i = PanelLeft; i <= PanelLeft+6; i++ )
	{
		bg2_buffer[i + MAP_WIDTH*2] = 0;
		bg2_buffer[i + MAP_WIDTH*6] = 0;
	}

	Print( PanelTop+1, PanelLeft+2, ItoA( num_mines ));
	Print( PanelTop+4, PanelLeft+2, ItoA( seconds ));
}
*/
u16 PanelTop  =  1;
u16 PanelLeft =  20;

void InitPanel(void)
{
	Print( PanelTop  , PanelLeft, "Mines");
	Print( PanelTop+2, PanelLeft, " Time" );
}

void UpdateCounters( s32 num_mines, u32 seconds )
{
	u32 i;

	for( i = PanelLeft+6; i <= PanelLeft+10; i++ )
	{
		bg2_buffer[i + MAP_WIDTH*PanelTop]     = 0;
		bg2_buffer[i + MAP_WIDTH*(PanelTop+2)] = 0;
	}

	Print( PanelTop  , PanelLeft+6, ItoA( num_mines ));
	Print( PanelTop+2, PanelLeft+6, ItoA( seconds ));
}

//////////////////////////////////////////////////////////////////////////////////
// Sprite Functions

void LoadSpriteData()
{
	// Copy the actual sprite data in the OAMData buffer
	// The starting index is 512 since we are using mode 3
	u32  loop;
	u16* data = (u16*) cursor;
	u32  index = 0;

	// Our first sprite (cursor: 16x16 256 colors) goes at address 0x06014000
	for( loop = 0; loop < SPRITE_WIDTH * SPRITE_HEIGHT * NUM_SPRITES; loop++ )
	{
		OAMData[(SPRITE_DATA_START_INDEX << 4) + index] = data[loop];
		index++;
	}
/*
	// Next tree sprites (faces: 3 32x32 256 colors)
	data = (u16*) faces;
	for( loop = 0; loop < 32 * 32 * 3; loop++ )
	{
		OAMData[(SPRITE_DATA_START_INDEX << 4) + index] = data[loop];
		index++;
	}
*/
}

// Copy our sprite array to OAM
void CopyOAM()
{
	u32 loop;
	u16* temp = (u16*)sprites;

	for(loop = 0; loop < (128*4); loop++)
		OAM[loop] = temp[loop];
}

// Set sprites to off screen
void MoveSpritesOffscreen()
{
	u32 loop;

	for( loop = 0; loop < 128; loop++)
	{
		sprites[loop].attribute0 = 160;  //y to > 159
		sprites[loop].attribute1 = 240;  //x to > 239
	}
}

/*
void ShowFace( u32 face )
{
	sprites[4].attribute0 = COLOR_256 | SQUARE | 104;
	sprites[4].attribute1 = SIZE_32 | 184;

	switch( face )
	{
	case 0:		// Smiling face
		sprites[4].attribute2 = SPRITE_DATA_START_INDEX+16;
		break;

	case 1:		// Sad face
		sprites[4].attribute2 = SPRITE_DATA_START_INDEX+48;
		break;

	case 2:		// Face with sunglasses
		sprites[4].attribute2 = SPRITE_DATA_START_INDEX+80;
		break;
	}
}
*/

void InitializeSprites()
{
	u16 loop;

	for( loop = 0; loop < 256; loop++)
		OBJPaletteMem[loop] = cursorPalette[loop];

	MoveSpritesOffscreen();

	LoadSpriteData();

	sprites[0].attribute0 = COLOR_256 | SQUARE;
	sprites[0].attribute1 = SIZE_16;
	sprites[0].attribute2 = SPRITE_DATA_START_INDEX;

	sprites[1].attribute0 = COLOR_256 | SQUARE;
	sprites[1].attribute1 = SIZE_16 | HORIZONTAL_FLIP;
	sprites[1].attribute2 = SPRITE_DATA_START_INDEX;

	sprites[2].attribute0 = COLOR_256 | SQUARE;
	sprites[2].attribute1 = SIZE_16 | VERTICAL_FLIP;
	sprites[2].attribute2 = SPRITE_DATA_START_INDEX;

	sprites[3].attribute0 = COLOR_256 | SQUARE;
	sprites[3].attribute1 = SIZE_16 | VERTICAL_FLIP | HORIZONTAL_FLIP;
	sprites[3].attribute2 = SPRITE_DATA_START_INDEX;

//	ShowFace(0);

	CopyOAM();
}

inline void MoveCursorPart( int x, int y, u32 index )
{
	if(x < 0)			//if it is off the left correct
		x = 512 + x;
	if(y < 0)			//if off the top correct
		y = 256 + y;

	sprites[index].attribute0 &= 0xFF00;
	sprites[index].attribute0 |= y;
	sprites[index].attribute1 &= 0xFE00;
	sprites[index].attribute1 |= x;
}

void MoveCursor( u16 row, u16 col, u16* delta )
{
	u16 dx, dy;

	int x = (col << 4);
	int y = (row << 4);

	dx = *delta >> 3;
	dy = *delta >> 3;

	MoveCursorPart( x-dx, y-dy, 0 );
	MoveCursorPart( x+dx-1, y-dy, 1 );
	MoveCursorPart( x-dx, y+dy-1, 2 );
	MoveCursorPart( x+dx-1, y+dy-1, 3 );

	CopyOAM();

	(*delta)++;
//	(*delta) += 2;

	if(*delta == 32)
		*delta = 0;
}

void HideCursor(void)
{
	u32 loop;

	for( loop = 0; loop < 4; loop++ )
	{
		sprites[loop].attribute0 = 160;
		sprites[loop].attribute1 = 240;
		sprites[loop].attribute2 = SPRITE_DATA_START_INDEX;
	}

	CopyOAM();
}

//////////////////////////////////////////////////////////////////////////////////
// Video Functions

// Wait for the screen to stop drawing
void WaitForVSync(void)
{
	while((volatile u16)REG_VCOUNT != 160) {}
/*
     asm volatile(
		"scanline_wait:
		ldr	    r3, #0x4000006
		ldrh	r3, [r3]
		cmp	    r3, #160
		bne	    scanline_wait"
		: // no ouput
        : // no input
        : "r3" );
*/
}

//////////////////////////////////////////////////////////////////////////////////
// Keypad Functions
void WaitForKeyPress( void )
{
	while(((*KEYS) & KEY_START))
		rand();

	while(!((*KEYS) & KEY_START))
		rand();
}

//////////////////////////////////////////////////////////////////////////////////
// MODE3 and MODE4 Video Functions

//////////////////////////////////////////////////////////////////////////////////
// MODE4 Video Functions
/*
void ShowImageMode4( const void* image )
{
	u32 loop;
	u16* palette_mem = (u16*) 0x5000000;
	u16* temp        = (u16*) image;

    for( loop = 0; loop < 256; loop++ )
	{
		palette_mem[loop] = *temp;
		temp++;
	}

	// Copy the image data
	// DMA FLAGS: DMA_ENABLE | DMA_START_TIMING=VBlank | DMA_TRANSFER_TYPE=32bit
	(REG_DMA3SAD)   = (u32) temp;
 	(REG_DMA3DAD)   = 0x6000000;
	(REG_DMA3CNT_L) = (160 * 240 / 4);
	(REG_DMA3CNT_H) = 0xA400;
}
*/

//////////////////////////////////////////////////////////////////////////////////
// MODE3 Video Functions

// Color convertion (converts a RGB colour to a 15-bit BGR value used by the GBA)
#define RGB(r, g, b) ((r)+(g<<5)+(b<<10))

void ShowCompressedImageMode3( const void* image )
{
	LZ77UnCompVram((u16*) image,(u16*) VideoBuffer);
}

void DMAClearScreenMode3(u16 color)
{
	REG_DMA3SAD     = (u32) &color;
	REG_DMA3DAD     = 0x06000000;		//Destination Address
	(REG_DMA3CNT_L) = (160 * 240);
	(REG_DMA3CNT_H) = 0x9100;
}

void ShowImageMode3( const void* image )
{
	// Copy the image data
	// DMA FLAGS: DMA_ENABLE | DMA_START_TIMING=VBlank | DMA_TRANSFER_TYPE=32bit
	(REG_DMA3SAD)   = (u32) image;
 	(REG_DMA3DAD)   = 0x6000000;
	(REG_DMA3CNT_L) = (160 * 240 / 2);
	(REG_DMA3CNT_H) = 0x9400;
}

void ShowSplashPage()
{
	SetMode( MODE_3 );

	WaitForVSync();
	ShowCompressedImageMode3( bmp_logo );

	REG_DISPCNT |= BG2_ENABLE;

	WaitForKeyPress();
}

///////////////////////////////////////////////////////////////////////////////
// Timer Interrupt Control

void InterruptProcess(void)
{
	if(REG_IF & IF_TIMER0_OVERFLOW)
		if( TimeElapsed < 999999 )
			TimeElapsed++;

	// Clear the interrupt(s)
	REG_IF |= REG_IF;
}

void EnableTimerInterrupt(void)
{
	const u32 cpuFreq = 16777216;

    REG_IE        = 0x08;	// Enable IRQ for timer 0
	REG_IME       = 0x01;	// Master enable interrupts

	REG_TM0CNT_L = 0xFFFF - (cpuFreq/1024);
	REG_TM0CNT_H = 0x00C3;  // Enable Timer0 + IRQ + Prescaler Selection=System Clock/1024
}

void DisableTimerInterrupt(void)
{
	REG_TM0CNT_H  = 0;		// Disable Timer0
	REG_IE        = 0;		// Disable all interrupts
	REG_IME       = 0;		// Master disable interrupts
}

///////////////////////////////////////////////////////////////////////////////
// Keypad trigger detection

u16 ReadKeys(u16* down)
{
	// Trigger detection variables
	u16 current, keys;
	static u16 previous = 0;

/*
	// Trigger detection: full form
	keys     = *KEYS;
	keys     = keys & 0x03FF;
	current  = keys;
	keys     = keys ^ 0x03FF;
	delta    = keys ^ previous;
	down     = delta & previous;
	previous = current ^ 0x03FF;
*/

/*
	// This trigger detection code detects button releases
	current  = keys = *KEYS & 0x03FF;
	keys    ^= 0x03FF;
	down     = (keys ^ previous) & previous;
	previous = current ^ 0x03FF;
*/

	// This trigger detection code detects button presses
	current  = keys = *KEYS & 0x03FF;
	keys    ^= 0x03FF;
	*down    = (keys ^ previous) & (~previous);
	previous = current ^ 0x03FF;

	return keys;
}

///////////////////////////////////////////////////////////////////////////////
// Main

int AgbMain(void)
{
	u32 cursor_col, cursor_row;
	u16 cursor_delta;
	u32 last_col, last_row;
	u32 game_flag;
	u32 auto_reveal_flag;
	u32 panel_visible_flag;

	struct BGControl bg2cnt;
	struct BGControl bg3cnt;

	InitSound();

start:
	auto_reveal_flag = FALSE;
	game_flag = GAME_CONTINUE;

	NumMines    = NUM_MINES;
	TimeElapsed = 0;

	last_col = cursor_col = 0;
	last_row = cursor_row = 0;
	cursor_delta = 0;

	panel_visible_flag = FALSE;

	bg2cnt.Priority            = 0;					// 0 - highest
	bg2cnt.CharacterBaseBlock  = BG2_CHR_BASE;		// 0-3 in units of 16 KB (=BG Tile Data)
	bg2cnt.NotUsed             = 0;					// Must be 0
	bg2cnt.Mosaic              = 0;					// Mosaic effect
	bg2cnt.ColorPalettes       = 1;					// 256 Colors
	bg2cnt.ScreenBaseBlock     = BG2_SCR_BASE;		// 0-31 in units of 2 KB (=BG Map Data)
	bg2cnt.DisplayAreaOverflow = 0;					// 0 - Transparent; 1-Wraparaund BG2CNT/BG4CNT only
	bg2cnt.ScreenSize		   = 0;					// ROT BG: 0 - 128x128 (16x16), 1 - 256x256 (32x32)...

	bg3cnt.Priority            = 3;					// 0 - highest
	bg3cnt.CharacterBaseBlock  = BG3_CHR_BASE;		// 0-3 in units of 16 KB (=BG Tile Data)
	bg3cnt.NotUsed             = 0;					// Must be 0
	bg3cnt.Mosaic              = 0;					// Mosaic effect
	bg3cnt.ColorPalettes       = 1;					// 256 Colors
	bg3cnt.ScreenBaseBlock     = BG3_SCR_BASE;		// 0-31 in units of 2 KB (=BG Map Data)
	bg3cnt.DisplayAreaOverflow = 0;					// 0 - Transparent; 1-Wraparaund BG2CNT/BG4CNT only
	bg3cnt.ScreenSize		   = 0;					// ROT BG: 0 - 128x128 (16x16), 1 - 256x256 (32x32)...
													// CHR BG: 0 - 256x256 (32x32)...

	BgFadeOut(0);
	ShowSplashPage();
	PlayMelody( hello_melody, 4 );

	//////////////////////////////////////////////////////
	// Initialize game arrays
	matrixInitialize( NUM_MINES );
	matrixMapToBackground();

	//////////////////////////////////////////////////////
	// Using MODE 0
	REG_BG2CNT  = *((u16*) &bg2cnt);				// Turn on REG_BG2CNT. Tells where the bg3_buffer and tile locations are
	REG_BG3CNT  = *((u16*) &bg3cnt);

	SetMode( MODE_0 | OBJ_MAP_1D | OBJ_ENABLE );

	BgFadeOut(16);								// Fade to black

	WaitForVSync();
	InitializeBackground();						// Display the background

	WaitForVSync();
	InitializeSprites();

	if( panel_visible_flag )
		REG_DISPCNT |= (BG2_ENABLE | BG3_ENABLE);
	else
		REG_DISPCNT |= BG3_ENABLE;

	BackgroundFadeIn();

	// Trigger detection variables
	u16 keys, down;

	EnableTimerInterrupt();

	while( game_flag == GAME_CONTINUE )					// Main Loop
	{
		keys = ReadKeys( &down );

		if( matrixAllSpacesOpen())
			game_flag = GAME_WIN;

		// Keypad input is not active while the AutoReveal key is pressed
		if( ! auto_reveal_flag )
		{
			if(down & KEY_LEFT)
			{
				if(cursor_col > 0)
					cursor_col--;
				else
					cursor_col = MATRIX_WIDTH-1;
			}
			else if(down & KEY_RIGHT)
			{
				if(cursor_col < MATRIX_WIDTH-1)
					cursor_col++;
				else
					cursor_col = 0;
			}
			else if(down & KEY_UP)
			{
				if(cursor_row > 0)
					cursor_row--;
				else
					cursor_row = MATRIX_HEIGHT-1;
			}
			else if(down & KEY_DOWN)
			{
				if(cursor_row < MATRIX_HEIGHT-1)
					cursor_row++;
				else
					cursor_row = 0;
			}

			// A: Reveal Mine
			else if(down & KEY_A)
			{
				PlaySoundChannel2( TONE_DURATION, 0x750, DUTY_CICLE_75 );
				if( matrixRevealMine( cursor_row, cursor_col ))
					game_flag = GAME_LOST;
			}
			// B: Mark Minez
			else if(down & KEY_B)
			{
				PlaySoundChannel2( TONE_DURATION, 0x6FF, DUTY_CICLE_50 );
				matrixMarkMine( cursor_row, cursor_col );
			}
			// RIGHT: Automatically reveal all surrounding cases not marked by a flag
			else if(down & KEY_R)
			{
				PlaySoundChannel2( TONE_DURATION, 0x750, DUTY_CICLE_50 );
				matrixAutoReveal( cursor_col, cursor_row, &last_col, &last_row, &game_flag, &auto_reveal_flag );
			}
			// START: End Game
			else if(down & KEY_START)
			{
				game_flag = GAME_NEW;
			}
			else if(down & KEY_SELECT)	// Show/Hide Panel
			{
				if( panel_visible_flag )
					REG_DISPCNT = REG_DISPCNT & ~BG2_ENABLE;
				else
					REG_DISPCNT = REG_DISPCNT | BG2_ENABLE;

				panel_visible_flag = !panel_visible_flag;
			}
		}

		// Restores the tiles when the AutoReveal key is released
		if(!(keys & KEY_R) && auto_reveal_flag == TRUE)
		{
			auto_reveal_flag = FALSE;
			matrixAutoRevealSetTiles( last_row, last_col, FALSE );
		}

		matrixAnimateFlags();
		matrixMapToBackground();
		UpdateCounters( NumMines, TimeElapsed );

//		WaitForVSync();			// IT IS STRANGE THE PROGRAM WORKS FINE WITHOUT THIS ONE
		RefreshBackground();

		MoveCursor( cursor_row, cursor_col, &cursor_delta );
	}	// while

	DisableTimerInterrupt();
	WaitForVSync();
	HideCursor();

	// TO DO: show game statistics and appropriate message
	switch(game_flag)
	{
		case GAME_WIN:
			WaitForVSync();
//			ShowFace(2);
//			CopyOAM();

			PlayMelody( win_melody, 4 );
			break;

		case GAME_NEW:
			WaitForVSync();
//			ShowFace(1);
//			CopyOAM();
			break;

		case GAME_LOST:
			matrixAnimateExplosion();
			WaitForVSync();
//			ShowFace(1);
//			CopyOAM();

			PlayMelody( lost_melody, 4 );
			break;
	}

	WaitForKeyPress();
	BackgroundFadeOut();

	goto start;
}


