Labyrinth!

GBA implementation by Rob Blanding, April 2003

Based on the board game �Master Labyrinth� created by Max J. Kobbert and distributed by Ravensburger games

I have tested this on VisualBoy Advance and GBA SP hardware. Please direct any feedback to:

rblanding@hotmail.com

Be sure to mention Labyrinth or GBA in the subject line or else it's likely to be mistaken for junk mail.

In this release the AI is incredibly stupid and just makes random moves, so for a real game, find a friend or three to play against.

The complete rules to the board game can be found here:
http://globetrotter.crosswinds.net/index.htm?E&game/eMasLab.htm

Here's a quick summary:
You must pick up the numbered tokens in order from lowest to highest.

At the end of the game bonus points are awarded as follows: 3 points per unused wand(/), 20 points per special goal tile collected (pressing B on your turn will hilight your special goals).

On your turn you:
(1) shift the board by sliding the free tile
(2) move your piece
(3) pickup the number token if (a) it is the lowest # on the board and (b) you did not end your move on the square you started at.
(4) you may choose to use one wand per turn, which will grant you an extra turn.
 

Game Controls:

In the Player Setup Screen:
            D-pad left-right to select player
            D-pad up-down to change player type (none/human/AI)
            A starts the game

When shifting the board:
            D-pad moves the free tile
            Left and Right shoulder buttons rotate the free tile
            A shifts the board from the current free tile position 

When placing your piece:
            D-pad moves the piece
            A places the piece (you will be prompted to pick up the piece, and/or use a wand if possible)

Either shifting or placing:
            B hides player pieces (so you can see tiles under them) and highlights the current player�s special goal tiles

Respond to popup dialogs with A or B as prompted.

Pressing select will end the current game prematurely.

 

Coming soon:

AI. Right now it just makes random moves 
Advanced setup screen featuring AI difficulty selection, turn time limit setup. 