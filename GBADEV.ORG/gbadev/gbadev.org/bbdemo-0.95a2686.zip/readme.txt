
/**********************************************************************\

Bubble Bobble GBA/Demo  ver. 0.95a - 11/12/2003

Coded by:
  Thomas Maniero aka gersen
  e-mail: thomas.maniero@tin.it
  web   : http://www.shlzero.com



Art ripped from the original coin-op (Taito '86)
concept and gfx (C) Taito


\**********************************************************************/




Yesterday I played the official Bubble Bobble port for GBA and I saw that the 
developers have used a clever trick to fit the original sized levels 
(or just something very close to) on the little GBA screen. 
So after an hour I have reproduced the trick on my oooold Bubble Bobble demo. 
Just for fun, uaz uaz :)


If you want to write me some words please send a mail at:
                                           
    thomas.maniero@tin.it






Thanks\Links:
  * Sergej Kravcenko --(http://www.codewaves.com - sergej@codewaves.com)--
       for his sound engine library
  * Forgotten        --(http://vboy.emuhq.com)--
       for his very accurate GBA emulator
  * Dovoto           --(http://www.thepernproject.com)--
       for his gba hardware info/tutorial 
  * Tom Happ         --(http://cowbite.emuunlim.com)--
       for his CowBite Hardware Specifications
  * Jason Wilkins    --(http://www.io.com/~fenix/devkitadv)--
       for his (and GNU...) Dev-Kit Advance
  * Jeff Frohwein    --(http://www.devrs.com/gba)--
       for his crt.S
  * and all the others...
