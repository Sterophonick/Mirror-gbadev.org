8Bit 3D Lighting Demo

Programmed by Robert Parnell

Description:
Demonstration of 3D Lighting in 256 color mode 4, using a
256*32 entry color lookup table. Needs some serious optimization.

