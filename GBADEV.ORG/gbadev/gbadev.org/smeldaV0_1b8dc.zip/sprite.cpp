#include"gba.h"
#include"data.h"

#define SIZE_8x8    1
#define SIZE_16x16  2
#define SIZE_32x32  3
#define SIZE_64x64  4


typedef struct sprite
{
	u16 Atribute1;				
	u16 Atribute2;
	u16 Atribute3;
	u16* Data;
	u32 DataOffset;
	u8 FramesPerAnimation;
	u8 NumFrames;
	u32 Frame;
	u8 State;
	u8 Counter;
	u8 SpriteNumber;
	u16 Size;
	u8* AnimBuffer;
	u8 NumAnims;
}Sprite,*pSprite;


#define SetBit(reg,n) (reg) |= (1<<(n))

extern u16* OAM;
extern u16* OAMdata;
u16* CHAR_DATA = (u16*) 0x6010000;

/////////////Function Definitions////////////////
void S_Move(pSprite sp, u16 x, u16 y)
{
	sp->Atribute1 &= ~0x01ff;
	sp->Atribute2 &= ~0x01ff;

	sp->Atribute1 |= y;
	sp->Atribute2 |= x;

	OAM[sp->SpriteNumber] = sp->Atribute1;
	OAM[sp->SpriteNumber+1] = sp->Atribute2;
}

void S_Kill(pSprite sp)
{
	S_Move(sp,241,241);  //move sprite offscreen
}

void S_Animate(pSprite sp,u8 NewFrame)
{
	sp->Atribute3 = NewFrame*8;  //also controles priority
								//and selected palet.
//SetBit(sp->Atribute3,11);
	OAM[sp->SpriteNumber+2] = sp->Atribute3;


}
void S_CopyToRam(pSprite sp)
{
	
}
int S_Initialize(pSprite sp, u16* tFile, u16 tOffset, u16 x, u16 y,
		char NumFrame, u16 datasize, char shape, char fEnable)
{
	int i;
	u16 temp;
	sp->Atribute1 = x;
	sp->Atribute2 = y;
	sp->Atribute3 = 0;
	SetBit(sp->Atribute1,13);
	switch(shape)
	{
	case SIZE_64x64:
		{
			SetBit(sp->Atribute2,14);
			SetBit(sp->Atribute2,15);
		};
	case SIZE_32x32:
		{
			SetBit(sp->Atribute2,15);
		};
	case SIZE_16x16:
		{
			SetBit(sp->Atribute2,14);
		};
	default: break;
	}
	
	sp->Frame = 0;


	sp->SpriteNumber = 0;
	sp->Atribute3 = 0;
	OAM[sp->SpriteNumber] = sp->Atribute1;
	OAM[sp->SpriteNumber+1] = sp->Atribute2;
//	SetBit(sp->Atribute3,11);
	OAM[sp->SpriteNumber+2] = sp->Atribute3;
	sp->Counter = 3;
	sp->NumFrames = 8;
	for(i=0;i<(datasize);i++)
	{
		OAMdata[i] = tFile[i+tOffset];
	
	}
}
