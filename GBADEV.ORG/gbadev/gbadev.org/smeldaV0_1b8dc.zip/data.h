extern u16 palette[];
extern u16 tLink[];
extern u16 tOW[];