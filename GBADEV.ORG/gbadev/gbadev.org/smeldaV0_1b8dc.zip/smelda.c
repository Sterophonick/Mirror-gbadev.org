/********************************************************
*		smelda v0.1
*
*				by devoto
*
*    I am trying to learn and understand the sprite engine 
*	so this seemed like a good way to do it.  When done this
*  	source should serve as good documentation on mode 1.
*	it will cover alpha blending sprite rotation and scaling.  
*	Some of the things will be done in ways that may seem ineficient
*	and that is because I am trying to include as many features 
*	of the gameboy hardware as posible(or because i suck:)).
********************************************************/

// Gba.h has all the register definitions
#include "gba.h"     //from Eloist Wire cube Demo, defines the main GBA registers
#include "data.h"	 //all the external textures and such are declared here.
#include "keypad.h"  //All the keypad definitions thanks to nokturn
#include "sprite.h"
#include "overworld.h"
#include <math.h>


#define NUM_OW_TILES  103   //this is the number of diferent tiles in the overworld
							//the origanle zelda probably used far fewer than this 
							//But it is easier this way.

//Some direction defines 
#define UP 2
#define LEFT 3
#define DOWN 1
#define RIGHT 4
#define PI 3.14159
#define RADIAN(n) (((float)n)/(float)180*PI)

#define fixed s32  //fixed point numbers gotta love em.

typedef void (*fp)(); //this is a funcion pointer.  It is used to call a function that has 
				//been moved to RAM.  It is highly recomended that any code that you plan on 
				//exicuteing from ROM be thumb code.  If you have any functions that are 
				//highly speed critical do them with ARM and copy that function to ram.
				


//memory offset of the palette mem and video
u16 *palette_mem = (u16*)0x5000000;//this is were palette data is stored. A 16 bit value
									//for the redgreenblue of each color.  256 entries
									//for the background followed by 256 for object data
u16* Video_Buffer16 = (u16*)0x600A000;//this is for mode 4 and 5 which have a back buffer.
							
u16* Video_Memory = (u16*)0x6000000;//this is the area that map data will be stored in 
									//tile modes. and video mem in modes 3,4,5;
u32* RAM = (u32*)0x3000000;			//this is a pointer to the begining of RAM
									//used to copy functions to RAM for faster exicution
u16* OAM = (u16*)0x7000000;			//OAM data starts here.  Room for 128 objects

u16* OAMdata = (u16*)0x6010000;     //holds oam tile data actual sprite frames; if mode 3,4
									//or 5 there is only have the texture space.  OAM data
									//starts at 0x6014000;

u16* ScreenData0 = (u16*)0x6008000; //this were the screen map goes.  It can be placed any 
									//ware on a 2k boundry in video ram.  Must be specified
									//by BG*CNT register.  By setting bits 8 - 12 you can specify
									//were screne data resides.  It is just a 5 bit number
									//were 0 = 0x6000000, 1 = 0x6000500 ...16 =0x6008000 ...
									//31 = 0x600f500.
u16* CharData0 = (u16*)0x6000000;   //this is were the actual tile data goes.  It is controled
									//by bits 2 and 3 of BG*CNT.  tile data can be placed on any 
									//16k boundry in video ram.You must ensure that the BG*CNT
									//register points to the corect memory location for character
									//data and screen data.


	int x,y;//holds link x and y;
	int world_x,world_y;//world x and y for traking link through the world

	Sprite link;  //bet you allready know what this is

int mode = 0x1141;  //current video mode.  This is the value that will be placed at 0x4000000;
			//this register controles the mode,obj mapping(1 dimensional or 2),visable 
			//backgrounds ond objects, visable windows, you can cause a blanking period by
			//setting bit 7, and switch between front and back buffers with bit 4.  I used
			//GBAemu's gbaregister tool to generate this number.  it enables all backgrounds 
			//and objects, selects linear object mapping, and selects video mode 1.
//////////LUTs (not needed yet)
//fixed COS[360];  //LUTs for sign and cosign
//fixed SIN[360];

//Declerations
void WaitForVsync(void);   
void Move(int Direction);			    //moves 
int Get_Input(void);					//reads PAD 
void Wait(int time);					//waits
void InitializeOAM(void);
void DrawWorld(void);

///////////////// C code entry (main())/////////////////////
int C_entry()
{
	int i,i2;//counter
	int offset;

	x=100;  //set link to middle of screen
	y=100;
	
	world_x = 7;  //this is the real start screen
	world_y = 7;
	
	

	S_Move(&link,x,y);  //move link to his position


	//setup the display mode
	REG_DISPCNT = mode;   //set screen mode(REG_DISPCNT = *0x4000000)
	REG_BG0CNT  = 0x1083;  //this is the main control for the background. bits 0&1 conrol priority.
							//the higher the number the lower the priority.  Priority determines
							//the order in wich the backgrounds and sprites are drawn. the order
							//is as follows BG3,OBJ3,BG2,OBJ2,BG1,OBJ1,BG0,OBJ0. The next 2 bits
							//(2*3)controll what memory to use for character data. Bits 4&5 are 
							//used and 6 controls mosaic enable. 7 controles color mode(set is 
							//256 color not set is 16 color).bits 8-12 control what memory is 
							//used for screen data and bits 14 and 15 control size of the virtual
							//screen.  00 is 256x256, 01 is 512x256, 10 is 256x512, 11 is 512x512.  
							//this only always true for text backgrounds(those that do not have 
							//scaling and rotation abilitis). in mode 1 bg0 & bg1 are text back-
							//grounds and bg 2 is a scaling/rotating backgroun.
							//mode 0 all 4 are text backgrounds.  mode 2 bg 2&3 are rotation and
							//scaling.  bit 13 controls area overflow in scaling/rotation back
							//grounds but that is beyond me for the moment.

	REG_BG0HOFS = 0;		//ensure that we are not offset
	REG_BG0VOFS = 0;
	
	DrawWorld();   //this is the function that actualy draws the world.  It places the screen 
					//data corisponding to overworld aray.

	for(i = 0; i<(NUM_OW_TILES*16*8);i++) //this copies the overworld tile data to the memory
	{									  //location we set up earlier.  it is 16*8 not 16*16
										  //because we are copying 2 bytes at a time	
		CharData0[i] = tOW[i];            //tOW contains the actual texture data that was 
										  //created by screen captures from zelda in an emu and
	}									  //and cut and paste into a vertical column of 16x16 
										  //tiles.  I then used joats sprite stripper and saved
										  //the result as a raw file.  and included it in my data
										  //file
	
	
	InitializeOAM(); //this function intializes all sprite atributes such that they are 
				//not shown on the screen.  OAM is aranged starting at 0x7000000
				//It has four 16 bit atributes per sprite, the first atribute controls
				//the Y coordinate, mosaic enable,color mode(16 or 256 color palette),
				//double size enable(will be explained later),OBJ mode(this is the cool one,
				//once again to explained later),OBJ form(squar rec ect...explained later),
				//and rotation/scale enable...Thats a lot for 16 bits huh?
				//Atribute 2 determins obj size, x coordinate, rotation/scaling peramiter
				//selection,horizontal and vertical flip,
				//Atribute 3 is the character name(ie the tiles it coorisponds to in
				//video mem., priority(what order it is drawn),number of palette if 16 
				//color
				//The last atribute is actualy one of four rotation/scaling permiters
				//they control the change in x and y.  this will be explained in detail
				//at a later time(as soon as i figure it out).

//Palette is 2 256 16 bit entries one for backgrounds one for Objects(sprites) the file was 
	//created by saving the palette in PSP 7 and then converting using JASK2RAW available
	//on gbadev.org

	//:  bbbbbgggggrrrrr-
S_Initialize(&link,tLink,0,x,y,1,16*8*8,SIZE_16x16,1);
	for(i = 0; i < (256); i++)
	{
		palette_mem[i] = palette[i]; //backgtound palette
		palette_mem[i+256] = palette[i]; //object palette(does not have to be the same)
	}
//this is were the sign and cosign LUT's are created. stored in a table of 2:30 fixed point
//numbers(we don't realy need then so they are comented out
	//for(i = 0;i<360;i++)
//	{
	//	SIN[i] = (fixed)(sin(RADIAN(i))*((float)(1<<30)));
	//	COS[i] = (fixed)(cos(RADIAN(i))*((float)(1<<30)));
//	}
/////////////////MAIN LOOP////////////////////	

	while (1)  
	 {

	
	Move(Get_Input());	//get_input returns direction pressed and move takes apropriate action 
	WaitForVsync();     //this is used for smoother video but don't think it realy matters much
						//yet
	REG_BG0HOFS = 16 * x/240;   //original zelda screen was 16 x ll tiles which unfortunatly is
	REG_BG0VOFS = 16 * y/160;	//one too many in both directions.  This is fixed by BG*HOFS &
								//BG*VOFS wich control the background scroll.  The most it will
								//scroll is one tile(16 pixles).  How far it srolles is determined 
								//by links position on the screen.  This allows the whole screen 
								//to be viewed using the original graphics.
	
	

	}//end main loop
}//end C_entry()
//////////////////////////////////////////////

///////WaitForVsync//////////////////////////
void WaitForVsync(void)
{
	__asm 
	{
		mov 	r0, #0x4000006   //0x4000006 is vertical trace counter; when it hits 160					 //160 the vblanc starts
		scanline_wait:	       	//the vertical blank period has begun. done in asm just 
								//because:)
		ldrh	r1, [r0]
		cmp	r1, #160
		bne 	scanline_wait
	}			
}



///////////////Get Input////////////////////////////////
int Get_Input(void)
{
	int d = 0; //just a variable to return direction..
//keypad register is a 16 bit register at 0x40000130;
//key bits are reset when a key is pressed.  Apperantly they must be manualy set back to 0;
//keys are defined in keypad.h

	if(!((*KEYS) & KEY_UP))        //is UP bit 0?
	{
		d = UP;
		//do up stuff	
		(*KEYS) |= KEY_UP;      //reset KEY_UP bit to 1
	}
	if(!((*KEYS) & KEY_DOWN))
	{
		d = DOWN;
		//do down stuff
		(*KEYS) |= KEY_DOWN;
	}
	if(!((*KEYS) & KEY_LEFT))
	{
		d = LEFT;
		//do left stuff
		(*KEYS) |= KEY_LEFT;
	}
	if(!((*KEYS) & KEY_RIGHT))
	{
		d = RIGHT;
		//do right stuff

		(*KEYS) |= KEY_RIGHT;
	}
	if(!((*KEYS) & KEY_A))
	{
		//do A button stuff here
		(*KEYS) |= KEY_A;
	}
	if(!((*KEYS) & KEY_B))
	{
		//do B button stuff here
		(*KEYS) |= KEY_B;
	}
	if(!((*KEYS) & KEY_R))
	{
		//do R button stuff here
		(*KEYS) |= KEY_R;
	}
	if(!((*KEYS) & KEY_L))
	{
		//do R button stuff here
		(*KEYS) |= KEY_L;
	}


	return d;
}

/////////////////////////////////////////////////////////

////////////////////MOVE/////////////////////////////////
void Move(int d)
{
	const static u8 animate[8] =           //this is links animation matrix
							{	0,1,		//it is used to keep track of what frame to select
								2,3,
								4,5,
								6,7   };
	const static s8 move[8] = {				//this is his move matrix and controls change in x
								0,2,		//and y based on direction
								0,-2,
								-2,0,
								2,0  };
	static u8 count = 0;					//counter to control how often we need to change 
											//animation frames.
	int oldx,oldy,temp;						//these hold old x and y incase we go some were bad

	oldx = x;								
	oldy = y;
if(d)
{		
	count++;      
	if (count>15) count = 0;  //this just cycles count from 0-15;

	x += move[((d-1)<<1)];   //move matrix is consulted and link x & y are updated
	y += move[((d-1)<<1)+1]; //direction is 1-4 so we subtract 1 and multiply by 2(same as<<1)
								//to get x and then do the same but add one to get y;
	
	S_Animate(&link,animate[((d-1)<<1)+(count>>3)]);  //this sets the right frame of animation
														//for link.  based on direction and
												//count.  we shift all but the high bit of count
												//away this causes the frame to be change every
												//8 frames.
	//this is were the tile number is retrieved for links current position.  Looks complicated 
	//but is realy just two offsets added together.  it is also corected for background scroll
	//(16*x/240)&(16*y/160).  It is hard to explane but it works..:)
	temp = OverWorld[((x+(16*x/240)+8)/16)+((y+(16*y/160)+9)/16)*16*(ScreensW)+
		(16*(world_y*ScreensW)*11+16*(world_x))] ;
	//this is were we check temp to see if it is a tile we can walk on.  It probably would be
	//more eficient to have a hole seperate aray for this but this works too;)
	if(temp != 5 && temp != 6 && temp != 7 && temp != 36 //these are all the tiles I can walk on
		&& temp!=68 && temp!=67 && temp != 48 && temp != 87 && temp != 41)
	{
		x = oldx;  //oops tryed to move into a tile that cant be steped on move back
		y = oldy;
	}
	 if(x>(239-16))  //this is were the world x and y are updated if we go off the screen.
	 {				 //it checks to make sure we didn't wander off the face of the earth
					 //and then redraws the new screen.
	
		 world_x++;
		if(world_x<ScreensW)
		 {
			x -= (239-16);
			DrawWorld();
			REG_BG0HOFS = 0;
		 }
		 else 
		{
			 world_x--;  //oops fell of the earth move back(uhh hyrule i meen)
			x = oldx;
		}
	}

	 if(x<0)   //the next three do the same thing
	{
		 world_x--;
		if(world_x>=0)
		 {
			x += (239-16);
			DrawWorld();
			REG_BG0HOFS = 16;
		 }
		 else 
		 {
			 world_x++;
			x = oldx;
		 }
	}
	if(y<0)
	{
		 world_y--;
		if(world_y>=0)
		 {
			y += (160-16);
			DrawWorld();
			REG_BG0VOFS = 16;
		 }
		 else 
		 {
			 world_y++;
			y = oldy;
		 }
	}
	if(y>=(159-16))
	{
		 world_y++;
		if(world_y<ScreensH)
		 {
			y -= (159-16);
			DrawWorld();
			REG_BG0VOFS = 0;
		 }
		 else 
		 {
			 world_y--;
			y = oldy;
		 }
	}
   S_Move(&link,x,y);  //move link to his new home

	}
}

void Wait(int time)//this is wait funtcion that is exponential in nature(ie proprtional to 
					//time^2)
{
	int i1,i2,temp;
	for(i1 = 0; i1 < time; i1++)
		for(i2 = 0; i2 < time; i2++)
			temp = i1*i2;
}//end Wait




void InitializeOAM(void)
{
	int i;
	for(i = 0; i<(128 * 4); i+=4)  //all this function does is set atribute 1(y) and 2(x) to 
	{					//to a location not on the screen to prevent them from
		OAM[i] = 241;		//being displayed.
		OAM[i+1] = 241;
	}
}
void DrawWorld(void)
{
	int offset,i,i2;
	offset = 0;
//allright this function requires some explaining.  I had origanly started this port for the 
	//pc were 16x16 tiles were no problem.  Unfortunatly only 8x8 tiles are alowed.  In stead of
	//rewrighting my overworld.h i just cheeted.  i loop through the tiles 4 at a time an the 
	//tile number that i use works out to be 4 times my 16x16 tilenumber.  If this doesnt make sence
	//that is okay.  I recently wrote a program that generated the tile data from a huge bitmap
	//that was comprised of a screen shot of every screen in the overworld.  There was no way
	//I was hand typing the hole overworld matrix.  It would be easy to modify the program to
	//output a matrix comprised of 8x8 tiles but it would be 4 times as big so I think I will
	//leave it just the way it is.
	
	for(i=0;i<11;i++)
	{
		for(i2 = 0; i2<16;i2++)
		{
			ScreenData0[offset+(i2<<1)] = 4*(OverWorld[(16*11*(world_y*ScreensW)+16*(world_x))+i2 + i*16*(ScreensW)]);
			ScreenData0[offset+(i2<<1)+1] = 4*(OverWorld[(16*11*(world_y*ScreensW)+16*(world_x))+i2 + i*16*(ScreensW)])+1;
			ScreenData0[offset+(i2<<1)+0x20] = 4*(OverWorld[(16*11*(world_y*ScreensW)+16*(world_x))+i2 + i*16*(ScreensW)])+2;
			ScreenData0[offset+(i2<<1)+0x21] = 4*(OverWorld[(16*11*(world_y*ScreensW)+16*(world_x))+i2 + i*16*(ScreensW)])+3;

		}
		offset+=0x40;//memory width for screen data in 256x256 screen size.
	}
}