#include"gba.h"

#ifndef SPRITE_H
#define SPRITE_H



#define SIZE_8x8    1
#define SIZE_16x16  2
#define SIZE_32x32  3
#define SIZE_64x64  4


typedef struct sprite
{
	u16 Atribute1;				
	u16 Atribute2;
	u16 Atribute3;
	u16* Data;
	u32 DataOffset;
	u8 FramesPerAnimation;
	u8 NumFrames;
	u32 Frame;
	u8 State;
	u8 Counter;
	u8 SpriteNumber;
	u16 Size;
	u8* AnimBuffer;
	u8 NumAnims;
}Sprite,*pSprite;

///sprite functions

extern void S_Move(pSprite sp,u16 x, u16 y);
extern void S_Kill(pSprite sp);
extern void S_CopyToRam(pSprite sp);
extern void S_Animate(pSprite sp, u8 NewFrame);
extern int S_Initialize(pSprite sp, u16* tFile, u16 tOffset, u16 x, u16 y,
		char NumFrame, u16 datasize, char shape, char fEnable);
#endif