Tetris
=-=-=-

  By Chris Adams aka Lithium aka pluto9

Controls
=-=-=-=-

 In Game:

  Left/Right             -> Move block one space at a time
  Hold A with Left/Right -> Let block slide over
  Up                     -> Rotate block
  L/R                    -> Rotate block left/right
  Down                   -> Accelerate block down
  
 High Scores:

  Up/Down                -> Change letter
  A                      -> Next letter
  B                      -> Previous letter
  Start                  -> Accept

Contact
=-=-=-=

   ICQ: 58401399
   MSN: lithium_eadgbe@hotmail.com
   Emails: pluto9@rock.com && lithium@zext.net
   Website: http://lithium.zext.net