/*

Tetanus On Drugs for GBA
tod.h : header files. and lots of them.
Copyright (C) 2002  Damian Yerrick

This program is free software; you can redistribute it and/or
modify it under the terms of the GNU General Public License
as published by the Free Software Foundation; either version 2
of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to 
  Free Software Foundation, Inc., 59 Temple Place - Suite 330,
  Boston, MA  02111-1307, USA.
GNU licenses can be viewed online at http://www.gnu.org/copyleft/

Visit http://www.pineight.com/ for more information.

*/

#ifndef PINEIGHT_TOD_H
#define PINEIGHT_TOD_H

#include <stdlib.h>
#include <time.h>
#include "fmul.h"
#include "pin8gba.h"
#include "gbfs.h"


#define NUM_PIECES    10
#define NUM_FLIPS      4
#define NUM_BLOCKS     4

#define VIRTUAL_FPS  100

#define PLAYFIELD_MAP 16
#define HUD_MAP       18

// CONSTANTS
enum {
  STATE_INACTIVE = 0,
  STATE_GET_NEW_PIECE,
  STATE_FALLING_PIECE,
  STATE_CHECKSQUARES,
  STATE_CHECK4LINES,
  STATE_MARK,
  STATE_FALL,
  STATE_FALL2,
  STATE_PUSHUP,
  STATE_GAMEOVER,
  STATE_HISCORE,
  STATE_PAUSED
};

enum {
  ENDMODE_MARATHON = 0,
  ENDMODE_15KPTS,
  ENDMODE_3MINUTES,
  ENDMODE_DEATHMODE
};

enum {
  PIECE_T = 0,
  PIECE_Z, PIECE_S, PIECE_J, PIECE_L, PIECE_SQUARE, PIECE_SMALL_L,
  PIECE_STICK, PIECE_TINY_STICK, PIECE_SHORT_STICK,
  PIECE_MAGNET,
  PIECE_INVERSE
};

// DATA TYPES

typedef struct TetGlobals
{
  signed char endMode;
  signed char winLimit, timeLimit;
  /* teflonMode: generate no stick pieces
     tntMode: emulate The New Tetris for N64 */
  unsigned char teflonMode, tntMode, usingJoy;
  int handicap, yBase;
} TetGlobals;

typedef struct Field
{
  unsigned char b[21][10];
} Field;

typedef struct Player
{
  Field b, c;  /* block map and connection map */

  signed char repeatTime[10];
  unsigned char curPiece[5];
  unsigned char curColor[5];
  signed char dropTime;
  signed char curHelp;
  unsigned char q;
  signed char curFlip, dropMove, spinMove, hasSwitched;

  int coming, top;
  int scoreFac, chainCount, state, stateTime;
  int pieceDone, inverse, handiLines;
  int x, y, yy;
  unsigned int sprCoveredRows;

  int gameStart;  /* used to figure play time */

  /* stats */

  int score;
  int lines;
  int playTime;
  int silvers;
  int golds;
  int score40;
  int nSpinMoves;
  int wins, hsMode;
  unsigned short lineBins[8];
} Player;

typedef struct ScreenPos
{
  fixed cubic, dcubic;
  fixed quad, dquad;
  fixed linear, dlinear;
  fixed cnst, dcnst;
  fixed theta, dtheta;
  fixed phi, dphi;
  fixed scale, dscale;
  fixed fuzz;
  fixed center_x, center_y;
  fixed back_x, back_y, quake_speed;
  fixed palphase;
  unsigned char palrot;
  /* unimplemented effects: phi, amp/sinusFreq, heat */

  /* omitted fps because it's always 30 on GBA */
  unsigned short lastBeat, midiLoop, curSong;
  unsigned short cached_fxword, land_pos;
  unsigned short mana, n_effects;
  unsigned char fxQueue[10];
} ScreenPos;

/* use the Rijndael s-box as a source of noisy displacement */
extern const u8 rijndaelS[256];
const u8 p8logo_map[10][10];
const u16 p8logo_pal[16];

// GLOBALS

extern const GBFS_FILE *data_gbfs, *bkgnds_gbfs, *samples_gbfs;
extern TetGlobals g;
extern ScreenPos m7;
extern unsigned char backbits[32][32];
extern unsigned char m7scrbuf[32][32];
extern unsigned int dirty_rows;
extern int retrace_count;  /* at 60fps, won't run out for more than a year */
extern Player p;

extern unsigned int music_beat;

extern unsigned char dirty_hud;
extern unsigned char dirty_next;


void dma_memcpy(void *in_dest, const void *in_source, size_t len);

/*
void cpu_memcpy(void *in_dest, const void *in_source, size_t len);
int puuncrunch_mem2mem(unsigned char *outBuffer, const unsigned char *data);
*/
/* a 64 KB work buffer in EWRAM (includes PU_OUTBUF) */
#define MYRAM  ((unsigned char *)0x02030000)
/* a 40 KB EWRAM buffer for asset decompression */
#define PU_OUTBUF ((unsigned char *)0x02035000)
#define PU_OUTBUF_PRE (PU_OUTBUF - 16)

void cycle_pal(unsigned int phase);
void copy_dirty_rows(void);
void postgame_stats(void);
void set_next_pal(void);
void itoa_lpad(char *buf, size_t len, int n, int lpad_chr);
void format_time(char *buf, size_t len, unsigned int n);
void nttextout(u32 nt, u32 x, u32 y, u32 c, const char *str);
void set_status_bar(void);

/* ALWAYS use this function to wait for the vblank;
   otherwise, the mixer won't get called */
void wait4vbl(void);


/* tetanus.c **************************/

int GameLoop(unsigned int j);
void NewGame(void);
void DrawNext(void);


/* initvram.c *************************/

void gblz_unpack(const void *src);
void hud_cls(void);
void init_status_bar(void);
void switch_bg(int direction);
void expand_gb_to_gba4bit(void *in_dst, const u8 *src, size_t len, const unsigned char gbpal[4]);
void expand_1b_to_gba4bit(void *in_dst, const u8 *src, size_t len, const unsigned char gbpal[2]);
void load_hud_font(unsigned int pat_table, const unsigned char *gbtextpal);
void init_vram_blocks(void);
void init_vram_ui(void);
void gameover_screen(unsigned int won);
void draw_bg_name(void);


/* fx.c *******************************/

int get_fxword(void);
void process_physics(unsigned int j);
void reset_view(void);


/* tri.c ******************************/

typedef struct SAMPLE_8GBS SAMPLE_8GBS;

void init_sound(const GBFS_FILE *samples);
void music_play(void);
void start_song(const unsigned char *song_data);
void music_pause(int paused);  /* 1 pause; 0 resume */
void play_8gbs(unsigned int voice,
               const SAMPLE_8GBS *sample,
               unsigned int freq_fac);
void mixer(void);
void dsound_vblank(void);


/* help.c *****************************/

/* draw a screenful of text */
void draw_text(const char *s,
               unsigned int xo, unsigned int y,
               unsigned int color);
int draw_help(int h);
void copr_notice(void);

int pause_menu(unsigned int j);
void pause_menu_init(void);

/* data.c *****************************/

int hgrcos(int theta);
int hgrsin(int theta);
int hgrtan(int theta);





#endif
