#ifndef FMUL_H
#define FMUL_H

typedef long fixed;

fixed fastfmul(fixed a, fixed b);
#if 0
fixed fmul(fixed a, fixed b);
fixed fdiv(fixed a, fixed b);
#endif

int dv(int a, int b);
int fracmul(int a, int b);
unsigned int fracumul(unsigned int a, unsigned int b);

#endif

