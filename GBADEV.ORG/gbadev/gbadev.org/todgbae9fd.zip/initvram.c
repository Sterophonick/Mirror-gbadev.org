/*

Tetanus On Drugs for GBA
initvram.c : initialize VRAM for a new game
Copyright (C) 2002  Damian Yerrick

This program is free software; you can redistribute it and/or
modify it under the terms of the GNU General Public License
as published by the Free Software Foundation; either version 2
of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to 
  Free Software Foundation, Inc., 59 Temple Place - Suite 330,
  Boston, MA  02111-1307, USA.
GNU licenses can be viewed online at http://www.gnu.org/copyleft/

Visit http://www.pineight.com/ for more information.

*/



#include <stdlib.h>
#include <string.h>
#include <ctype.h>
#include "tod.h"


#define WRAP_PLAYFIELD 0


/* Palette

00-0f background colors
10-12 blue
13-15 green
16-18 cyan
19-1b red 
1c-1e magenta
1f-21 yellow
22-28 grayscale for superblk
29-2f goldscale for superblk
30-3f next
40-7f blank
80-bf outer bg coloring
c0-ff inner bg coloring

*/

/* VRAM

0000 playfield tiles (160 8-bit tiles)
2800 animated playfield tiles (96 8-bit tiles)
4000 blank
8000 playfield map (32x32 bytes)
8400 hud tiles (96 4-bit tiles)
9000 hud map
9800 background map (32x32 u16s)
a000 blank
b000 background tiles (600 4-bit tiles)
fb00 blank

*/



const unsigned char shading_indices[7][4] =
{
  /* low, medium, high, blink color */
  {16, 17, 18, 18},
  {19, 20, 21, 19},
  {22, 23, 24, 24},
  {25, 26, 27, 27},
  {28, 29, 30, 30},
  {31, 32, 33, 31},
  {35, 38, 40, 36}
};

const unsigned short blocks_pal[32] =
{
  RGB( 0, 0,24),RGB(12,12,31),RGB(25,25,31), /* blue */
  RGB( 0,24, 0),RGB(12,31,12),RGB(25,31,25), /* green */
  RGB( 0,24,24),RGB(12,31,31),RGB(25,31,31), /* cyan */
  RGB(24, 0, 0),RGB(31,12,12),RGB(31,25,25), /* red */
  RGB(24, 0,24),RGB(31,12,31),RGB(31,25,31), /* magenta */
  RGB(24,24, 0),RGB(31,31,12),RGB(31,31,25), /* yellow */
  RGB(10,10,10),RGB(15,15,15),RGB(19,19,19), /* gray */
  RGB(22,22,22),RGB(25,25,25),RGB(28,28,28),RGB(31,31,31),
  RGB(14,10, 5),RGB(19,15, 7),RGB(23,19, 9), /* gold */
  RGB(26,22,10),RGB(29,25,11),RGB(31,28,12),RGB(31,31,13)
};


static unsigned short back_pal[16];
static unsigned char cur_bg = 2;

void _gblz_unpack(const char *src, char *dst);

void gblz_unpack(const void *src)
{
/* I've apparently fixed the bug */
#if WORKAROUND_LZCOMP_BUG
  u32 *killbuf = (u32 *)(PU_OUTBUF - 20);

  /* work around a bug in that causes files to refer to extra 0's */
  *killbuf++ = 0;
  *killbuf++ = 0;
  *killbuf++ = 0;
  *killbuf++ = 0;
  *killbuf++ = 0;
#endif
  _gblz_unpack(src, PU_OUTBUF);

}


void set_next_pal(void)
{
  unsigned int nextn, color_idx = 49;

  for(nextn = 1; nextn < 5; nextn++)
  {
    unsigned int shade;
    unsigned int c = (p.curColor[nextn] >> 4) - 1;

    for(shade = 0; shade < 3; shade++)
    {
      PALRAM[color_idx++] = blocks_pal[shading_indices[c][shade] - 16];
    }
  }
}

void cycle_pal(unsigned int phase)
{
  unsigned int i;

  for(i = 0;
      i < 16;
      i++, phase++)
    PALRAM[i] = back_pal[phase & 0x0f];
}


static void produce_normal_block(unsigned char n[8][8], unsigned int conn)
{
  int x, y;

  for(y = 0; y < 8; y++)
    for(x = 0; x < 8; x++)
      n[y][x] = 1;

  if(!(conn & 1))  /* if there's no east conn */
    for(y = 0; y < 8; y++)
      n[y][7]--;
  if(!(conn & 2))  /* if there's no west conn */
    for(y = 0; y < 8; y++)
      n[y][0]++;
  if(!(conn & 4))  /* if there's no south conn */
    for(x = 0; x < 8; x++)
      n[7][x]--;
  if(!(conn & 8))  /* if there's no north conn */
    for(x = 0; x < 8; x++)
      n[0][x]++;
  n[0][0] = 2;
  n[7][7] = 0;

  conn = (conn >> 4) - 1;  /* convert blockid to color */
  for(y = 0; y < 8; y++)
    for(x = 0; x < 8; x++)
      n[y][x] = shading_indices[conn][n[y][x]];
}


/* expand_gb_to_gba4bit() *********
   Expand tiles from Game Boy format to Game Boy Advance
   format in 4-bits
*/
void expand_gb_to_gba4bit(void *in_dst, const u8 *src, size_t len, const unsigned char gbpal[4])
{
  u32 *dst = in_dst;
  const unsigned char dfltpal[4] = {0, 1, 2, 3};

  if(!gbpal)
    gbpal = dfltpal;

  len >>= 1;  /* convert from bytes to scanlines */

  for(; len > 0; len--)
  {
    unsigned int sr0 = *src++;
    unsigned int sr1 = *src++;
    unsigned int dstbits = 0;
    unsigned int bits = 8;

    for(; bits > 0; bits--)
    {
      unsigned int gb_color = ((sr1 & 1) << 1) | (sr0 & 1);
      sr0 >>= 1;
      sr1 >>= 1;
      dstbits = (dstbits << 4) | gbpal[gb_color];
    }
    *dst++ = dstbits;
  }
}


/* expand_1b_to_gba4bit() *********
   Expand tiles from 1-bit format to Game Boy Advance
   format in 4-bits
*/
void expand_1b_to_gba4bit(void *in_dst, const u8 *src, size_t len, const unsigned char gbpal[4])
{
  u32 *dst = in_dst;
  const unsigned char dfltpal[4] = {0, 1};

  if(!gbpal)
    gbpal = dfltpal;

  for(; len > 0; len--)
  {
    unsigned int sr0 = *src++;
    unsigned int dstbits = 0;
    unsigned int bits = 8;

    for(; bits > 0; bits--)
    {
      dstbits = (dstbits << 4) | gbpal[sr0 & 1];
      sr0 >>= 1;
    }
    *dst++ = dstbits;
  }
}


/* load_bg_pic() ***********************
   Load a background picture into the unpacking buffer, turn off
   the screen, copy the picture to VRAM, and set up the palette.
*/
void load_bg_pic(const char *src_filename)
{
  {
    const void *src = gbfs_get_obj(bkgnds_gbfs, src_filename, NULL);

    gblz_unpack(src);
    wait4vbl();
  }

  LCDMODE = 1;
  dma_memcpy(back_pal, PU_OUTBUF, 32);
  cycle_pal(0);
  dma_memcpy((void *)0x0600b000, PU_OUTBUF + 32, 19200);

  m7.palphase = 0;
  if(!memcmp(src_filename, "kale", 4))
  {
    m7.palrot = 1;
  }
  else
  {
    m7.palrot = 0;
  }
}


/* switch_bg() *************************
   If direction = 0, load the current background.
   If direction > 0, load the next background.
   If direction < 0, load the previous background.
*/
void switch_bg(int direction)
{
  const GBFS_ENTRY *dir;

  if(direction > 0)
  {
    cur_bg++;
    if(cur_bg >= bkgnds_gbfs->dir_nmemb)
      cur_bg = 0;
  }
  else if(direction < 0)
  {
    if(cur_bg)
      cur_bg--;
    else
      cur_bg = bkgnds_gbfs->dir_nmemb - 1;
  }

  dir = (const GBFS_ENTRY *)((const char *)bkgnds_gbfs +
                             bkgnds_gbfs->dir_off);
  load_bg_pic(dir[cur_bg].name);
}

/* draw_bg_name() **********************
   Draw the current background name to (16, 7) on hud map.
   If direction > 0, load the next background.
   If direction < 0, load the previous background.
*/
void draw_bg_name(void)
{
  const GBFS_ENTRY *dir =
    (const GBFS_ENTRY *)((const char *)bkgnds_gbfs +
                         bkgnds_gbfs->dir_off);
  const char *s = dir[cur_bg].name;
  unsigned int x = 16;

  /* write string */
  while(*s != ' ' && *s != 0 && x < 30)
    MAP[HUD_MAP][7][x++] = toupper(*s++) | 0x2000;
  /* clear to eol */
  while(x < 30)
    MAP[HUD_MAP][7][x++] = ' ';
}

void load_hud_font(unsigned int pat_table, const unsigned char *gbtextpal)
{
  const void *src = gbfs_get_obj(data_gbfs, "hudtiles.lz", NULL);

  gblz_unpack(src);
  expand_gb_to_gba4bit(VRAM + 16384 + 16*32, PU_OUTBUF, 1536, gbtextpal);
  expand_gb_to_gba4bit(VRAM + 16384 + 16*992, PU_OUTBUF + 1536, 512, gbtextpal);
}

void set_bg_nametable(void)
{
  int x, y, i;

  i = 384;  /* base address of tile 0xb000 from pattable 2 */

  /* Make a box of flipped tiles around the background so that when
     the background starts rumbling, you don't get blank spaces on
     the sides */
  for(y = 1; y < 21; y++)
    {
      MAP[19][y][0] = i | 0x0400;  /* flip H */
      for(x = 1; x < 31; x++)
	MAP[19][y][x] = i++;
      MAP[19][y][31] = (i - 1) | 0x0400;
    }
  for(x = 0; x < 32; x++)
    {
      MAP[19][0][x] = MAP[19][1][x] | 0x0800;  /* flip V */
      MAP[19][21][x] = MAP[19][20][x] | 0x0800;
    }

}


/* init_vram_blocks() ******************
   Initialize vram for gameplay, creating block images
*/
void init_vram_blocks(void)
{
  unsigned char n[8][8];
  int i;
  const char gbtextpal[4] = {0, 2, 5, 8};


  /* Background setup **********************************************/

  /* When switching from a bitmap, you must switch off the screen
     first. switch_bg() has this side effect. */
  switch_bg(0);
  set_bg_nametable();


  /* HUD setup *****************************************************/

  /* Upconvert HUD font from GB to GBA format */
  load_hud_font(2, gbtextpal);

  /* Convert blocks for 'next' tiles (hud:7c-7f) */
  {
    const u32 next_tile_img[8] =
    {
      0x23333333,
      0x12222223,
      0x12222223,
      0x12222223,
      0x12222223,
      0x12222223,
      0x12222223,
      0x11111112
    };
    u32 *dst = ((u32 *)MAP[16][0]) + 8*123;
    int j;
    u32 color_bias = 0x33221100;

    for(i = 0;
	i < 4;
        i++, color_bias += 0x44444444)
    {
      *dst++ = color_bias;
      *dst++ = color_bias;
    }

    color_bias = 0x00000000;

    for(i = 0;
	i < 4;
	i++, color_bias += 0x33333333)
      for(j = 0; j < 8; j++)
	*dst++ = next_tile_img[j] + color_bias;
  }
  wait4vbl();


  /* Playfield (rot/scale) bg setup ********************************/

  /* Clear out all unused tile area */
  for(i = 32*160; i < 32*192; i += 32)
    {
      unsigned int c = (i >> 5) - 144;
      unsigned int j;

      c |= c << 8;

      for(j = i; j < i + 32; j++)
	VRAM[j] = c;
    }
  for(i = 32*192; i < 32*256; i++)
    VRAM[i] = 0;

  /* Clear out tiles 0-15 */
  for(i = 0; i < 512; i++)
    VRAM[i] = 0;

  /* Create normal blocks' images */
  for(i = 16; i < 128; i++)
    {
      produce_normal_block(n, i);
      dma_memcpy(VRAM+32*i, n, 64);
    }

  /* Set up semitransparent tiles for the playfield backdrop */
  {
    u32 *dst = (u32 *)(VRAM + 32*0x01);  /* 32 u16's per tile */

    /* 16 u32's per tile times four tiles (0x01 to 0x04) */
    for(i = 64; i > 0; i--)
    {
      u16 c = rijndaelS[i];
      *dst++ = ((c & 0xc0) ? 0 : 0x26000000)
               | ((c & 0x30) ? 0 : 0x00260000)
               | ((c & 0x0c) ? 0 : 0x00002600)
               | ((c & 0x03) ? 0 : 0x00000026);
    }
  }

  /* Copy gray superblock */
  {
    const void *src = gbfs_get_obj(data_gbfs, "superblk.lz", NULL);

    gblz_unpack(src);
  }
  dma_memcpy(VRAM + 32*128, PU_OUTBUF, 1024);
  /* Transform into gold superblock by adding 7 to each pixel */
  {
    u16 *dst = VRAM + 32*144;
    u16 *src = (u16 *)PU_OUTBUF;

    for(i = 0; i < 64*16; i += 2)
      *dst++ = *src++ + 0x0707;
  }

  /* Palette setup */
  dma_memcpy(PALRAM+16, blocks_pal, 32*sizeof(short));

  /* Register setup */
    BGCTRL[2] =
      1 | BGCTRL_PAT(0) | BGCTRL_256C | BGCTRL_NAME(PLAYFIELD_MAP)
#if WRAP_PLAYFIELD
      | BGCTRL_M7WRAP
#endif
      | BGCTRL_M7_32;
    BGCTRL[0] =
      0 | BGCTRL_PAT(2) | BGCTRL_16C | BGCTRL_NAME(18)
      | BGCTRL_H32 | BGCTRL_V32;
    BGCTRL[1] =
      2 | BGCTRL_PAT(2) | BGCTRL_16C | BGCTRL_NAME(19)
      | BGCTRL_H32 | BGCTRL_V32;
    BGSCROLL[0].x = 0;
    BGSCROLL[0].y = 0;
    BGSCROLL[1].x = 8;
    BGSCROLL[1].y = 8;
}


/* hud_cls() ***************************
   Clear the HUD layer.
   FIXME:  May want to use DMA instead.
*/
void hud_cls(void)
{
  u32 *dst = (u32 *)MAP[HUD_MAP][0];
  int i = 21 * 4;  /* 4*8 spaces per row, up to 21 visible rows */

  do {  /* write 8 spaces at once */
    *dst++ = 0x00200020;
    *dst++ = 0x00200020;
    *dst++ = 0x00200020;
    *dst++ = 0x00200020;
  } while(--i);
}

/* init_status_bar() *******************
   Draw a blank screen with status bar labels.
*/
void init_status_bar(void)
{
  hud_cls();
  nttextout(18, 1,  6, 0x2380, "pqrs");  /* Score: */
  nttextout(18, 1,  8, 0x2380, "tuvw");  /* Lines: */
  nttextout(18, 1, 19, 0x2380, "{|");  /* Lv. */
}



/* expand_4to8() ***********************
   Expand a 4-bit graphic to 8-bit for use on rot/scale backgrounds.
*/
static void expand_4to8(void *in_dst, const void *in_src, size_t len, u32 ormask)
{
  const u16 *src = in_src;
  u32 *dst = in_dst;

  /* expand ormask into the whole word */
  ormask &= 0xff;
  ormask |= ormask << 8;
  ormask |= ormask << 16;

  /* convert len to words */
  len >>= 1;

  for(; len > 0; len--)
    {
      u16 srcbits = *src++;
      u32 dstbits = 0;

      dstbits = ((srcbits & 0x000f) << 0) |
	((srcbits & 0x00f0) << 4) |
	((srcbits & 0x0f00) << 8) |
	((srcbits & 0xf000) << 12) | ormask;
      *dst++ = dstbits;

    }
}


/* init_vram_ui() **********************
   Initialize vram for user interface.
*/
void init_vram_ui(void)
{
  const char gbtextpal[4] = {0, 2, 5, 8};

  LCDMODE = LCDMODE_BLANK;

  /* HUD setup *****************************************************/

  /* Upconvert HUD font from GB to GBA format */
  load_hud_font(2, gbtextpal);


  /* Spinning background setup *************************************/
  {
    const void *src = gbfs_get_obj(data_gbfs, "p8logo.lz", NULL);

    if(!src)
    {
      LCDMODE = 0;
      PALRAM[0] = RGB(31, 0, 0);
    }

    gblz_unpack(src);
    expand_4to8(VRAM, PU_OUTBUF, 1536, 16);
  }
  wait4vbl();
  dma_memcpy(PALRAM+16, p8logo_pal, sizeof(p8logo_pal));
  {
    unsigned int x, y;
    unsigned char the_map[16][16];

    for(y = 0; y < 10; y++)
      {
	for(x = 0; x < 10; x++)
	  the_map[y][x] = p8logo_map[y][x];
	for(; x < 16; x++)
	  the_map[y][x] = 1;
      }
    for(; y < 16; y++)
      for(x = 0; x < 16; x++)
	the_map[y][x] = 1;
    dma_memcpy(MAP[16][0], the_map[0], sizeof(the_map));
  }

  /* Background setup **********************************************/
	  

  /* Palette setup */
  dma_memcpy(PALRAM+32, blocks_pal + 16, 16*sizeof(short));

  /* Registers setup */
  *(volatile u16 *)0x04000050 = 0;
  {
    struct BGAFFINEREC mnu_rot = {0xc0, 0x40, -0x40, 0xc0, 0, 0};

    BGAFFINE[2] = mnu_rot;
  }

  BGCTRL[2] =
    1 | BGCTRL_PAT(0) | BGCTRL_256C | BGCTRL_NAME(PLAYFIELD_MAP)
    | BGCTRL_M7WRAP | BGCTRL_M7_16;
  BGCTRL[0] =
    0 | BGCTRL_PAT(2) | BGCTRL_16C | BGCTRL_NAME(18)
    | BGCTRL_H32 | BGCTRL_V32;
  BGCTRL[1] =
    2 | BGCTRL_PAT(2) | BGCTRL_16C | BGCTRL_NAME(19)
    | BGCTRL_H32 | BGCTRL_V32;
  BGSCROLL[0].x = 0;
  BGSCROLL[0].y = 0;
  BGSCROLL[1].x = 8;
  BGSCROLL[1].y = 8;

  LCDMODE = 1 | LCDMODE_BG0 | LCDMODE_BG2;
}


void gameover_screen(unsigned int won)
{
  const char gotext[] = "GAME  OVER";
  const char wintext[] = " COMPLETE!";
  const char *src = won ? wintext : gotext;
  int i;

  init_status_bar();
  set_status_bar();
  for(i = 0; i < 10; i++)
  {
    MAP[18][10][i + 10] = *src++ | 0x2000;
  }
  dirty_hud = 1;
}




