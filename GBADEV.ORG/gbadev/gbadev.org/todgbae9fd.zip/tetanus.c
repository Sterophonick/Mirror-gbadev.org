/*

Tetanus On Drugs for GBA
tetanus.c : game logic
Copyright (C) 1997-2002  Damian Yerrick

This program is free software; you can redistribute it and/or
modify it under the terms of the GNU General Public License
as published by the Free Software Foundation; either version 2
of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to 
  Free Software Foundation, Inc., 59 Temple Place - Suite 330,
  Boston, MA  02111-1307, USA.
GNU licenses can be viewed online at http://www.gnu.org/copyleft/

Visit http://www.pineight.com/ for more information.

*/

/* POSSIBLE CODE OPTIMIZATION TARGETS IN tetanus.c

CheckLines()
BreakLine()
CarbonStillGoing()

*/



#include "tod.h"

#define DIFFICULTY 350
#define INITIAL_LEVEL 5 // is 10 in FPA tetanus but FPA has no drugz
#define REPEAT_DELAY 11
#define SMALL_PIECES_IN_HR 0

/* This table defines the color for each type of block. */
enum
{
  BCOL_J     = 0x10,
  BCOL_S     = 0x20,
  BCOL_STICK = 0x30,
  BCOL_Z     = 0x40,
  BCOL_L     = 0x50,
  BCOL_T     = 0x60,
  BCOL_O     = 0x70,
  BCOL_H     = BCOL_T,
  BCOL_R     = BCOL_J,
  BCOL_MULTISQUARE = 0x80,
  BCOL_MONOSQUARE = 0x90,
  BCOL_ALL   = 0xf0,

  /* utility tiles */
  BCOL_LINECLEAR = 0x94,  /* drawn only to screen */
  BCOL_NEUTRAL = 0x80,
  BCOL_DOTTED_LINE = 0x88,
  BCOL_FALLING_HILITE = 0x8c
};


/* This table defines connections.  For example, if BCON_E is set,
   then this block is connected to the block on the E side and should
   be shaded appropriately.  If BCON_E is clear, draw an edge.
*/
enum
{
  BCON_NONE = 0,
  BCON_E    = 1,
  BCON_W    = 2,
  BCON_WE   = BCON_W | BCON_E,
  BCON_S    = 4,
  BCON_SE   = BCON_S | BCON_E,
  BCON_SW   = BCON_S | BCON_W,
  BCON_SWE  = BCON_S | BCON_WE,
  BCON_N    = 8,
  BCON_NE   = BCON_N | BCON_E,
  BCON_NW   = BCON_N | BCON_W,
  BCON_NWE  = BCON_N | BCON_WE,
  BCON_NS   = BCON_N | BCON_S,
  BCON_NSE  = BCON_N | BCON_SE,
  BCON_NSW  = BCON_N | BCON_SW,
  BCON_NSWE = BCON_N | BCON_SWE,
  BCON_ALL  = BCON_NSWE
};

enum
{
  JPAD_ROTR = 0,
  JPAD_ROTL = 1,
  JPAD_SELECT = 2,
  JPAD_START = 3,
  JPAD_RIGHT = 4,
  JPAD_LEFT = 5,
  JPAD_UP = 6,
  JPAD_DOWN = 7,
  JPAD_MISC = 8,
  JPAD_SWAP = 9,

  JPAD_MASK_UP    = 1 << JPAD_UP,
  JPAD_MASK_DOWN  = 1 << JPAD_DOWN,
  JPAD_MASK_LEFT  = 1 << JPAD_LEFT,
  JPAD_MASK_RIGHT = 1 << JPAD_RIGHT,
  JPAD_MASK_ROTL  = 1 << JPAD_ROTL,
  JPAD_MASK_ROTR  = 1 << JPAD_ROTR,
  JPAD_MASK_SWAP  = 1 << JPAD_SWAP,
  JPAD_MASK_MISC  = 1 << JPAD_MISC

};

static const char gPieceColor[NUM_PIECES] =
{
  BCOL_T, BCOL_Z, BCOL_S, BCOL_J, BCOL_L,
  BCOL_O, BCOL_Z, BCOL_STICK, BCOL_STICK, BCOL_STICK
};

const unsigned char shading_indices[7][4];

/* DATA TABLES

   This might need a little clarification. Take the T piece:
     x={{0,1,2,1},{1,1,1,0},{2,1,0,1},{1,1,1,2}}
     y={{1,1,1,2},{0,1,2,1},{1,1,1,0},{2,1,0,1}}
   This is a set of (x, y) data for each block in each rotation
   of the piece. The shape it defines is
         0 1 2 3   0 1 2 3   0 1 2 3   0 1 2 3
       0 . . . .   . X . .   . X . .   . X . .
       1 X X X .   X X . .   X X X .   . X X .
       2 . X . .   . X . .   . . . .   . X . .
       3 . . . .   . . . .   . . . .   . . . .

   gCBlocks records which blocks exist and how they're connected
   for display purposes.
 */
static const char gXBlocks[NUM_PIECES][NUM_FLIPS][NUM_BLOCKS] =
{
  {{0,1,2,1},{1,1,1,0},{2,1,0,1},{1,1,1,2}}, /* t        */
  {{0,1,1,2},{2,2,1,1},{2,1,1,0},{1,1,2,2}}, /* z        */
  {{0,1,1,2},{0,0,1,1},{2,1,1,0},{1,1,0,0}}, /* s        */
  {{0,1,2,2},{1,1,1,0},{2,1,0,0},{1,1,1,2}}, /* j        */
  {{0,0,1,2},{0,1,1,1},{2,2,1,0},{2,1,1,1}}, /* l        */
  {{1,1,2,2},{2,1,1,2},{2,2,1,1},{1,2,2,1}}, /* package  */
  {{1,1,2,2},{2,1,1,2},{2,2,1,1},{1,2,2,1}}, /* 3-l      */
  {{0,1,2,3},{1,1,1,1},{3,2,1,0},{1,1,1,1}}, /* 4-stick  */
  {{0,1,2,3},{1,1,1,1},{3,2,1,0},{1,1,1,1}}, /* 2-stick  */
  {{0,1,2,0},{1,1,1,0},{2,1,0,0},{1,1,1,0}}  /* 3-stick  */
};

static const char gYBlocks[NUM_PIECES][NUM_FLIPS][NUM_BLOCKS] =
{
  {{1,1,1,2},{0,1,2,1},{1,1,1,0},{2,1,0,1}},
  {{1,1,2,2},{0,1,1,2},{2,2,1,1},{2,1,1,0}},
  {{2,2,1,1},{0,1,1,2},{1,1,2,2},{2,1,1,0}},
  {{1,1,1,2},{0,1,2,2},{1,1,1,0},{2,1,0,0}},
  {{2,1,1,1},{0,0,1,2},{0,1,1,1},{2,2,1,0}},
  {{1,2,2,1},{1,1,2,2},{2,1,1,2},{2,2,1,1}},
  {{1,2,2,1},{1,1,2,2},{2,1,1,2},{2,2,1,1}},
  {{2,2,2,2},{0,1,2,3},{2,2,2,2},{3,2,1,0}},
  {{2,2,2,2},{0,1,2,3},{2,2,2,2},{3,2,1,0}},
  {{2,2,2,0},{1,2,3,0},{2,2,2,0},{3,2,1,0}}
};

/* big fat ass connection lut */
static const char gCBlocks[NUM_PIECES][NUM_FLIPS][NUM_BLOCKS] =
{
  {
    {BCON_E,BCON_SWE,BCON_W,BCON_N},
    {BCON_S,BCON_NSW,BCON_N,BCON_E},
    {BCON_W,BCON_NWE,BCON_E,BCON_S},
    {BCON_N,BCON_NSE,BCON_S,BCON_W}
  },
  {
    {BCON_E,BCON_SW,BCON_NE,BCON_W},
    {BCON_S,BCON_NW,BCON_SE,BCON_N},
    {BCON_W,BCON_NE,BCON_SW,BCON_E},
    {BCON_N,BCON_SE,BCON_NW,BCON_S}
  },
  {
    {BCON_E,BCON_NW,BCON_SE,BCON_W},
    {BCON_S,BCON_NE,BCON_SW,BCON_N},
    {BCON_W,BCON_SE,BCON_NW,BCON_E},
    {BCON_N,BCON_SW,BCON_NE,BCON_S}
  },
  {
    {BCON_E,BCON_WE,BCON_SW,BCON_N},
    {BCON_S,BCON_NS,BCON_NW,BCON_E},
    {BCON_W,BCON_WE,BCON_NE,BCON_S},
    {BCON_N,BCON_NS,BCON_SE,BCON_W}
  },
  {
    {BCON_N,BCON_SE,BCON_WE,BCON_W},
    {BCON_E,BCON_SW,BCON_NS,BCON_N},
    {BCON_S,BCON_NW,BCON_WE,BCON_E},
    {BCON_W,BCON_NE,BCON_NS,BCON_S}
  },
  {
    {BCON_SE,BCON_NE,BCON_NW,BCON_SW},
    {BCON_SE,BCON_NE,BCON_NW,BCON_SW},
    {BCON_SE,BCON_NE,BCON_NW,BCON_SW},
    {BCON_SE,BCON_NE,BCON_NW,BCON_SW}
  },
  {
    {BCON_SE,BCON_N,0,BCON_W},
    {BCON_SW,BCON_E,0,BCON_N},
    {BCON_NW,BCON_S,0,BCON_E},
    {BCON_NE,BCON_W,0,BCON_S}
  },
  {
    {BCON_E,BCON_WE,BCON_WE,BCON_W},
    {BCON_S,BCON_NS,BCON_NS,BCON_N},
    {BCON_W,BCON_WE,BCON_WE,BCON_E},
    {BCON_N,BCON_NS,BCON_NS,BCON_S}
  },
  {
    {0,BCON_E,BCON_W,0},
    {0,BCON_S,BCON_N,0},
    {0,BCON_W,BCON_E,0},
    {0,BCON_N,BCON_S,0}
  },
  {
    {BCON_E,BCON_WE,BCON_W,0},
    {BCON_S,BCON_NS,BCON_N,0},
    {BCON_W,BCON_WE,BCON_E,0},
    {BCON_N,BCON_NS,BCON_S,0}
  }
};




#define NUM_gTips 7
/*
static char gTips[NUM_gTips][2][32] =
{
  {"When reducing your stack, try", "taking advantage of gravity."},
  {"Lines of all one color", "(H or R) count double."},
  {"Try sliding one block", "under another block."},
  {"Some days you win;", "some days it rains."},
  {"Baking cookies with butter (not", "margarine) improves the flavor."},
  {"To survive longer,", "lay sticks flat."},
  {"The best defense is a good", "offense; make tetrises often."}
};
*/

/* GLOBAL VARIABLES */

TetGlobals g = {0};
static int attackMode = 0, raceMode = 0;

/* FUNCTION PROTOTYPES AND MACROS */

/* "Carbon" is the code name of the flood-fill based gravity algorithm. */
static int CarbonStillGoing(void);
static void DrawPiece(int x, int y, int inPiece, int inFlip, int color, int style);
static int FindDropTarget(int x, int y, int inPiece, int inFlip);
static void TeFloodFill(int x, int y, unsigned int c);
static void FloodFillLoop(int x, int y, unsigned int c, unsigned int uc);
static int MarkCarbon(int spinMove, int y);
static char CheckOverlap(int x, int y, int inPiece, int inFlip);
static void PushUp(void);
//static void ScrollDown(int top, int bottom);
static void TeDrawBlock(int x, int y, unsigned int colour);
void TeShutDown(void);
short TeStartUp(void);
static void GetNewPiece(int depth);

int lastClock;



static unsigned int ReadJPad(int n)
{
  unsigned int out;

  if(n != 0)
    return 0;  /* only one player on GBA */

  out = JOY ^ 0x03ff;

  /* if holding R, don't control the piece */
#if 0
  if((out & JOY_R))
    out = 0;
#endif
  return (out & 0x03ff);
}

static void EraseSprites(void)
{
  unsigned int y, rows;

  for(rows = p.sprCoveredRows, y = 0;
      rows != 0;
      rows >>= 1, y++)
  {
    if(rows & 1)
    {
      int x;

      for(x = 0; x < 10; x++)
        TeDrawBlock(x, y, p.b.b[y][x]);
    }
  }
  p.sprCoveredRows = 0;
}


/* MakeRepeats() ***********************
 * Autorepeats digital pad motion.  After autoDelay calls, it repeats
 * a key HZ/autoRate times a second.
 */
void MakeRepeats(char *repeatTime, int j, int autoDelay, int autoRate)
{
  int i;

  for(i = 0; i < 10; i++)
  {
    if(j & 0x01)
    {
      repeatTime[i]++;
      if(repeatTime[i] >= autoDelay)
        repeatTime[i] -= autoRate;
    }
    else
    {
      repeatTime[i] = 0;
    }
    j >>= 1;
  }
}


/* ClearOutCleared() *******************
   Clears out the graphical garbage left by cleared rows.
   This must be PORTED.  If you can't port it, substitute a
   full-screen redraw.
*/
static void ClearOutCleared(void)
{
  int y, x;

  for(y = 6; y < 26; y++)
    for(x = 11; x < 21; x++)
      if(m7scrbuf[y][x] == BCOL_LINECLEAR)
      {
        m7scrbuf[y][x] = backbits[y][x];
        dirty_rows |= 1 << y;
      }
}

/* CarbonStillGoing() ******************
   Moves everything down one line if still floating.
   Split into two functions to even the load on the CPU.
   CarbonFallOnce() REALLY needs further optimization; it takes
   20 lines.
*/
static void CarbonFallOnce(void)
{
  int x, y;

/* debugging information: enable if you touched any function with Carbon in
 * its name and your modifications make the program screw up */
#if 0
  for(y = 0; y <= 20; y++)
    for (x = 0; x < 10; x++)
    {
      gotoxy(x * 2 + 11, y + 1);
      cputs("%d", (int)p.c.b[y][x]);
    }
#endif

  /* move everything down if it is floating */
  for(x = 0; x < 10; x++)
  {
    unsigned char e = p.c.b[19][x];
    unsigned char d;

    for(y = 19; y >= 0; y--)
    {
      d = e;
      if(y)
        e = p.c.b[y - 1][x];
      else
	e = 0;
      if((d || e) && (e != 1) && (d != 1))
      {
        p.c.b[y][x] = e;
        if(y)
          p.b.b[y][x] = p.b.b[y - 1][x];
        else
          p.b.b[y][x] = 0;
        TeDrawBlock(x, y, p.b.b[y][x]);
      }
    }
  }
}

static int CarbonStillGoing(void)
{
  int flooded = 0;
  int x, y;

  /* if something just hit the ground, mark it as ground */
  for(y = 19; y >= 0; y--)
    for(x = 0; x < 10; x++)
      if((p.c.b[y][x] > 1) && (p.c.b[y + 1][x] == 1))
      {
	TeFloodFill(x, y, 1);
	flooded = 1;
      }

  /* if something hit the ground, play a thud */
  if(flooded)
  {
    const SAMPLE_8GBS *s = gbfs_get_obj(samples_gbfs, "01kick.8gbs", NULL);
    play_8gbs(3, s, 0x10000);
  }

  /* Give the scroller a hint as to the location of the action */
  p.y++;
  if(p.x < 3)
    p.x++;
  else if(p.x > 3)
    p.x--;

  /* if everything isn't ground, we're still going */
  for(y = 0; y <= 19; y++)
    for(x = 0; x < 20; x++)
      if(p.c.b[y][x] > 1)
	return 1;

  return 0;
}



static void BreakLineLoop(int x, int y)
{
  int c = p.b.b[y][x];

  if((c & BCOL_ALL) >= BCOL_MULTISQUARE)
  {
    if(y < 19 && p.b.b[y + 1][x] != 0)
    {
      p.b.b[y + 1][x] &= ~BCON_N;
      TeDrawBlock(x, y + 1, p.b.b[y + 1][x]);
    }
    if(y > 0 && p.b.b[y - 1][x] != 0)
    {
      p.b.b[y - 1][x] &= ~BCON_S;
      TeDrawBlock(x, y - 1, p.b.b[y - 1][x]);
    }
    return;
  }

  if(g.tntMode)
    p.b.b[y][x] = BCOL_NEUTRAL;
  else
    p.b.b[y][x] &= ~BCON_ALL;
  TeDrawBlock(x, y, p.b.b[y][x]);
  if((c & BCON_N) && y > 0)
    BreakLineLoop(x, y - 1);
  if((c & BCON_S) && y < 19)
    BreakLineLoop(x, y + 1);
  if((c & BCON_W) && y > 0)
    BreakLineLoop(x - 1, y);
  if((c & BCON_E) && x < 9)
    BreakLineLoop(x + 1, y);
}


#define USE_TENGEN_BREAKLINE 0


/* BreakLine() *************************
 * Break connections between blocks on this row and blocks on
 * neighboring rows.
 */
static void BreakLine(int y)
{
  int x;

/* BreakLine() *************************
 * Break connections inside blocks on this row.
 */

#if USE_TENGEN_BREAKLINE
  if(y > 0)
    for(x = 0; x < 10; x++)
      if(p.b.b[y - 1][x] & BCON_S)
      {
        p.b.b[y - 1][x] &= ~BCON_S;
        TeDrawBlock(x, y - 1, p.b.b[y - 1][x]);
      }

  if(y < 19)
    for(x = 0; x < 10; x++)
      if(p.b.b[y + 1][x] & BCON_N)
      {
        p.b.b[y + 1][x] &= ~BCON_N;
        TeDrawBlock(x, y + 1, p.b.b[y + 1][x]);
      }
#else
  for(x = 0; x < 10; x++)
  {
    if((p.b.b[y][x] & BCON_ALL) != 0)
      BreakLineLoop(x, y);
  }
#endif

}


/* MarkSquaresTest() *******************
 * Look for a TNT square in this position.  Return 1 if found.
 * Assumes: 0 <= x <= 6; 0 <= y <= 16
 */
static int MarkSquaresTest(int x, int y, int multiOK)
{
  int i, j, firstColor = p.b.b[y][x] & BCOL_ALL;

  for(i = 0; i <= 3; i++)
  {
    /* don't allow squares within parts of squares */
    if((p.b.b[y + i][x] & BCOL_ALL) >= BCOL_MULTISQUARE)
      return 0;
    /* the block doesn't connect on the left */
    if(p.b.b[y + i][x] & BCON_W)
      return 0;
    /* the block doesn't connect on the right */
    if(p.b.b[y + i][x + 3] & BCON_E)
      return 0;
    /* the block doesn't connect on the top */
    if(p.b.b[y][x + i] & BCON_N)
      return 0;
    /* the block doesn't connect on the bottom */
    if(p.b.b[y + 3][x + i] & BCON_S)
      return 0;

    for(j = 0; j <= 3; j++)
    {
      int c = p.b.b[y + i][x + j];

      /* the square contains no single blocks */
      if((c & BCON_ALL) == 0)
        return 0;
      /* if looking for monosquares, disallow multisquares */
      if(multiOK == 0 && (c & BCOL_ALL) != firstColor)
        return 0;
    }
  }
  return 1;
}

/* MarkSquare() ************************
 * Places a multisquare or monosquare in the field.
 */
static void MarkSquare(int x, int y, int multiOK)
{
  int i, j, c;

  if(multiOK)
    p.silvers++;
  else
    p.golds++;
  multiOK = (multiOK ? BCOL_MULTISQUARE : BCOL_MONOSQUARE) | BCON_ALL;
  for(i = 0; i <= 3; i++)
  {
    if(i == 0)
      c = multiOK & ~BCON_N;
    else if(i == 3)
      c = multiOK & ~BCON_S;
    else
      c = multiOK;

    for(j = 0; j <= 3; j++)
    {
      if(j == 0)
        p.b.b[y + i][x + j] = c & ~BCON_W;
      else if(j == 3)
        p.b.b[y + i][x + j] = c & ~BCON_E;
      else
        p.b.b[y + i][x + j] = c;
      TeDrawBlock(x + j, y + i, p.b.b[y + i][x + j]);
    }
  }

}


/* MarkSquares() ***********************
 * Create TNT monosquares and multisquares.
 */
static int MarkSquares(int multiOK)
{
  int x, y;
  int got = 0;

  for(y = 16; y >= 0; y--)
    for(x = 0; x <= 6; x++)
    {
      int conn = p.b.b[y][x] & BCON_ALL;
      if(conn &&
         !(conn & (BCON_W | BCON_N)) )
        if(MarkSquaresTest(x, y, multiOK))
        {
          MarkSquare(x, y, multiOK);
          got++;
        }
    }
  return got;
}


/* CheckLines() *****************
 * Clears horizontal rows using Carbon (flood fill drops) algorithm.
 */
static int CheckLines(int spinMove)
{
  int theseLines = 0, chainCount = 0;
  int x, y;
  static int fib[20] =
    {1, 1, 1, 2, 3, 5, 8, 13, 21, 34,
     55, 89, 144, 233, 377, 610, 987, 1597, 2584, 4181};

  /* Initialize screen line.  The scrolling engine uses the current
     piece y position; use this to give it a hint as to where the
     next action (i.e. a line clearing animation) will take place. */
  p.y = 16;

  for(y = 0; y <= 19; y++)
  {
    int hCount = 0, rCount = 0, grayCount = 0;
    for(x = 0; x < 10; x++)
    {
      switch(p.b.b[y][x] & BCOL_ALL)
      {
        case 0:
          break;
        case BCOL_H:
          hCount++;
          break;
        case BCOL_R:
          rCount++;
          break;
        default:
          grayCount++;
          break;
      }
    }
    if(hCount + rCount + grayCount == 10)
    {
      /* break lines up and down */
      BreakLine(y);

      /* remove the line */
      for(x = 0; x < 10; x++)
      {
        switch(p.b.b[y][x] & (BCON_WE | BCOL_ALL))
        {
          case BCOL_MONOSQUARE | BCON_E:
            p.score += 1000;
            break;
          case BCOL_MULTISQUARE | BCON_E:
            p.score += 500;
            break;
          default:
            break;
        }

        p.b.b[y][x] = 0;
        TeDrawBlock(x, y, BCOL_LINECLEAR);
      }

      /* score the line */
/*
      if(p.scoreFac && attackMode)
        p[1 - curTurn].coming++;
*/
      if(g.tntMode)
        p.score += fib[(int)(p.scoreFac++)] * 100;
      else
        p.score += (int)(++p.scoreFac) * 100;
      p.lines++;
      theseLines++;
      m7.quake_speed += 0x8000;

      /* if H or R line, score double */
      if(hCount == 10 || rCount == 10)
      {
        p.scoreFac++;
        p.score += (int)(p.scoreFac) * 100;
        p.lines++;
        theseLines++;
      }
      /* scroll the screen to the top line cleared */
      if(y < p.y)
        p.y = y;
    }
  }

  if(theseLines)
  {
    /* Handle the combo counter. */
#if 0
    textprintf(screen, font, chainCount * 12, 0, 12, "%d", theseLines);
#endif
    chainCount++;
    if(dirty_hud < 1)
      dirty_hud = 1;

    {
      const SAMPLE_8GBS *s = gbfs_get_obj(samples_gbfs, "pow.8gbs", NULL);
      play_8gbs(2, s, 0x10000);
    }

    if(spinMove)
    {
      /* break apart all the pieces */

      if(g.tntMode)
      {
        for(y = 0; y < 20; y++)
          for(x = 0; x < 10; x++)
            if(p.b.b[y][x])
            {
              p.b.b[y][x] = BCOL_NEUTRAL;
            }
      }
      else
      {
        for(y = 0; y < 20; y++)
          for(x = 0; x < 10; x++)
            if(p.b.b[y][x])
            {
              p.b.b[y][x] &= ~BCOL_ALL;
              TeDrawBlock(x, y, p.b.b[y][x]);
            }
      }
    }
  }
  return theseLines;
}


/* DrawPiece() ************************
   Unlike TeDrawBlock, this probably won't need to be changed
   too much when someone ports Tetanus to other platforms.
*/
static void DrawPiece(int x, int y, int inPiece, int inFlip,
                      int color, int style)
{
  int n, k;

  switch(style)
  {
    case 0: /* erase */
      for(n = 0; n < NUM_BLOCKS; n++)
        if(gCBlocks[inPiece][inFlip][n])
	  TeDrawBlock(x + gXBlocks[inPiece][inFlip][n],
                      y + gYBlocks[inPiece][inFlip][n],
                      0);
      break;
    case 1: /* high intensity */
      for(n = 0; n < NUM_BLOCKS; n++)
        if(gCBlocks[inPiece][inFlip][n])
        {
          int yb = y + gYBlocks[inPiece][inFlip][n];
          int xb = x + gXBlocks[inPiece][inFlip][n];

          if(yb >= 0 && yb < 20)
          {
            TeDrawBlock(xb, yb, color);
            p.sprCoveredRows |= 1 << yb;
          }
        }
      break;
    case 2: /* add to array */
      for(n = 0; n < NUM_BLOCKS; n++)
      {
        int blkType = gCBlocks[inPiece][inFlip][n];
        if(blkType != 0)
	{
          int j = y + gYBlocks[inPiece][inFlip][n];

          if (p.top > j)
            p.top = j;

	  if (j >= 0)
	  {
            k = x + gXBlocks[inPiece][inFlip][n];
            p.b.b[j][k] = color | blkType;
            TeDrawBlock(k, j, color | blkType);
	  }
	}
      }
      break;
  }
}


/* DrawNext() **************************
 * THIS MUST BE PORTED UP THE ASS for each new tetanus platform.
 */
void DrawNext(void)
{
  unsigned int i;

  const char xCellpos[4] = {25, 25, 25, 2};
  const char yCellpos[4] = {1, 4, 7, 1};

  for(i = 0; i < 4; i++)
  {
    unsigned int xBase = xCellpos[i];
    unsigned int yBase = yCellpos[i];
    unsigned int inPiece = p.curPiece[i + 1];
    unsigned int n;

    /* clear out previous piece */
    for(n = 0; n < 4; n++)
    {
      MAP[18][yBase + 1][xBase + n] = ' ' | 0x2000;
      MAP[18][yBase + 2][xBase + n] = ' ' | 0x2000;
    }

    for(n = 0; n < NUM_BLOCKS; n++)
    {
      if(gCBlocks[inPiece][0][n])
      {
        int xDst = gXBlocks[inPiece][0][n] + xBase;
        int yDst = gYBlocks[inPiece][0][n] + yBase;

        MAP[18][yDst][xDst] = i + 0x307c;
      }
    }
  }

  /* write the Next header */
  nttextout(18, 25, 0, 0x2380, "xyz");  /* NeXT */
}


/* TeFloodFill() ************************
 * This pair of functions fills an area with color.  They have been
 * adapted to the context of Tetanus by marking any contiguous block
 * area with a given unique falling block.
 */
static void TeFloodFill(int x, int y, unsigned int c)
{
  FloodFillLoop(x, y, c, p.c.b[y][x]);
  p.c.b[y][x] = c;
}

static void FloodFillLoop(int x, int y, unsigned int c, unsigned int fillC)
{
  int fillL, fillR, i;
  int still_in = 1;

  fillL = fillR = x;
  while(still_in)
  {
    p.c.b[y][fillL] = c;
    fillL--;
    still_in = (fillL < 0) ? 0 : (p.c.b[y][fillL] == fillC);
  }
  fillL++;

  still_in = 1;
  while(still_in)
  {
    p.c.b[y][fillR] = c;
    fillR++;
    still_in = (fillR > 9) ? 0 : (p.c.b[y][fillR] == fillC);
  }
  fillR--;

  /* Use this only on systems with acceptably deep stacks.
     Do NOT try this on a 6502 machine with a 256 byte stack.
  */

  for(i = fillL; i <= fillR; i++)
  {
    if(y > 0)
      if(p.c.b[y - 1][i] == fillC)
	FloodFillLoop(i, y - 1, c, fillC);
    if(y < 20)
      if(p.c.b[y + 1][i] == fillC)
	FloodFillLoop(i, y + 1, c, fillC);
  }
}


static int FindDropTarget(int x, int y, int pc, int flip)
{
  do {
    y++;
  } while(!CheckOverlap(x, y, pc, flip));

  return y - 1;
}


static void GameOver(int won)
{
  const unsigned char *song =
    gbfs_get_obj(data_gbfs,
                 won ? "_todwin.8gbm" : "_gameover.8gbm",
                 NULL);

  p.x = 3;
  p.y = 7;
  p.state = STATE_GAMEOVER;
  dirty_hud = 3 + won;

  if(song)
    start_song(song);
  else
  {
    int i;

    for(i = 0; i < 16; i++)
      PALRAM[i] = (PALRAM[i]) >> 1 & RGB(15, 15, 15);
  }

  /* high score omitted */
}


static void UpdatePlayTime(void)
{
  int playTime = retrace_count - p.gameStart;

  if(playTime > (p.playTime + 1) * 60)
  {
    p.playTime++;
    if(dirty_hud < 1)
      dirty_hud = 1;
  }
}


/* GameLoop() *************************
   Play one frame of the game.
   Input:  The current state of the joypad.
   Output: 0 for continue or 1 for gameover.
 */
int GameLoop(unsigned int j)
{
  int i;
  int moved_this_frame = 0;

  if(g.endMode == ENDMODE_DEATHMODE)  /* death mode */
    p.dropTime = 25;
  else
    p.dropTime = 13;

/* for debugging spin-cheat */
#if 0
  itoa_lpad(buf, 5, p.stateTime - retrace_count, ' ');
  nttextout(HUD_MAP, 24, 19, 0x2000, buf);
#endif


#if 0
  for(curTurn = 0; curTurn < nPlayers; curTurn++)
  {
#endif
    moved_this_frame = 0;
    if(g.endMode == ENDMODE_15KPTS && p.score >= 15000)
      GameOver(1);
    if(g.endMode == ENDMODE_3MINUTES && p.playTime >= 180)
      GameOver(1);


    switch(p.state)
      {
      case STATE_INACTIVE:
        return 1;
#if 0
        /* restart key is both flips */
        j = ReadJPad(0);
        i = ((j & (JPAD_MASK_ROTL | JPAD_MASK_ROTR)) ==
             (JPAD_MASK_ROTL | JPAD_MASK_ROTR));
        p.coming = 0;
        if(i && !lastEnter[curTurn] && !won)
          NewGame();
        lastEnter[curTurn] = i;
        yield_timeslice();
#endif
        break;

      case STATE_GET_NEW_PIECE:
        /* update 40 lines score */
        if(p.lines >= 40 && p.score40 == 0)
        {
          p.score40 = p.score;
        }

        /* update bins for stats */
        if(p.scoreFac > 0)
        {
          unsigned int bin = p.scoreFac - 1;

          if(bin > 7)
            bin = 7;
          p.lineBins[bin]++;
        }

        /* make the new piece */
        for(i = 0; i < 3; i++)
        {
          p.curPiece[i] = p.curPiece[i + 1];
          p.curColor[i] = p.curColor[i + 1];
        }
        GetNewPiece(3);

        /* Tell the observer thread to draw the next pieces */
        dirty_next = 1;

        p.x = 3;
        /* handle the first piece slightly differently */
        if(retrace_count - p.gameStart < 10)
        {
          /* put it on screen so the player can see an initial piece */
          p.y = 3;
          /* give player four seconds to get into the groove */
          p.stateTime = retrace_count + 240;
        }
        else  /* on subsequent pieces */
        {
          p.y = -3;
          p.stateTime = retrace_count +
                        ((g.endMode == ENDMODE_DEATHMODE) ? 12 : 4);
        }
        p.dropMove = 0;
        p.state = STATE_FALLING_PIECE;
        p.hasSwitched = p.curFlip = p.pieceDone = 0;
	p.yy = FindDropTarget(p.x, p.y, p.curPiece[0], p.curFlip);
	moved_this_frame = 1;

        DrawPiece(p.x, p.yy, p.curPiece[0], p.curFlip, BCOL_DOTTED_LINE, 1);
        DrawPiece(p.x, p.y, p.curPiece[0], p.curFlip, p.curColor[0], 1);
        
        break;

      case STATE_FALLING_PIECE:
        UpdatePlayTime();

        /* read the keyboard and joystick */
        MakeRepeats(p.repeatTime, j, REPEAT_DELAY + 1, 2);

        /* swap button: L, A+B, or B+A */
        if(p.repeatTime[JPAD_SWAP] == 1 ||
           (p.repeatTime[JPAD_ROTR] == 1 && p.repeatTime[JPAD_ROTL] > 0) ||
           (p.repeatTime[JPAD_ROTL] == 1 && p.repeatTime[JPAD_ROTR] > 0)) /* swap button */
        {
          if(!p.hasSwitched)
          {
            j = p.curPiece[0];
            p.curPiece[0] = p.curPiece[4];
            p.curPiece[4] = j;
            j = p.curColor[0];
            p.curColor[0] = p.curColor[4];
            p.curColor[4] = j;

    {
      const SAMPLE_8GBS *s = gbfs_get_obj(samples_gbfs, "spin.8gbs", NULL);
      play_8gbs(2, s, 0x10000);
    }
            dirty_next = 1;

            p.x = 3;
            p.y = -3;
	    moved_this_frame = 1;
            p.stateTime = retrace_count + 4;
            p.hasSwitched = 1;
            p.curFlip = p.pieceDone = 0;
	    p.yy = FindDropTarget(p.x, p.y, p.curPiece[0], p.curFlip);
            p.repeatTime[JPAD_ROTL] = p.repeatTime[JPAD_ROTR] = 2; /* wait for release */
          }
        }

        /* rotate left.  Rotating squares is pointless so don't even try. */
        if(p.repeatTime[JPAD_ROTL ^ p.inverse] == 1 && p.curPiece[0] != PIECE_SQUARE)
        {
          int okHere = !CheckOverlap(p.x, p.y, p.curPiece[0], (p.curFlip + 3) & 3);
          int okUp   = okHere ? 0 : !CheckOverlap(p.x, p.y - 1, p.curPiece[0], (p.curFlip + 3) & 3);

          if(okUp)
          {
            p.y -= 1;
            if(p.stateTime - retrace_count > 0)
              p.stateTime = retrace_count;
          }

          if(okUp || okHere)
          {
    {
      const SAMPLE_8GBS *s = gbfs_get_obj(samples_gbfs, "spin.8gbs", NULL);
      play_8gbs(2, s, 0x18000);
    }
            p.curFlip = (p.curFlip + 3) & 3;
            p.yy = FindDropTarget(p.x, p.y, p.curPiece[0], p.curFlip);
            moved_this_frame = 1;
          }
        }

        /* rotate right */
        if(p.repeatTime[JPAD_ROTR ^ p.inverse] == 1 && p.curPiece[0] != PIECE_SQUARE)
        {
          int okHere = !CheckOverlap(p.x, p.y, p.curPiece[0], (p.curFlip + 1) & 3);
          int okUp   = okHere ? 0 : !CheckOverlap(p.x, p.y - 1, p.curPiece[0], (p.curFlip + 1) & 3);

          if(okUp)
          {
            p.y -= 1;
            if(p.stateTime - retrace_count > 0)
              p.stateTime = retrace_count;
          }

          if(okUp || okHere)
          {
    {
      const SAMPLE_8GBS *s = gbfs_get_obj(samples_gbfs, "spin.8gbs", NULL);
      play_8gbs(2, s, 0x17000);
    }
            p.curFlip = (p.curFlip + 1) & 3;
            p.yy = FindDropTarget(p.x, p.y, p.curPiece[0], p.curFlip);
            moved_this_frame = 1;
          }
        }

        /* Move left */
        if(p.repeatTime[JPAD_LEFT ^ p.inverse] == 1 ||
           p.repeatTime[JPAD_LEFT ^ p.inverse] == REPEAT_DELAY)
        {
          if(!CheckOverlap(p.x - 1, p.y, p.curPiece[0], p.curFlip))
          {
    {
      const SAMPLE_8GBS *s = gbfs_get_obj(samples_gbfs, "move.8gbs", NULL);
      play_8gbs(3, s, 0x10000);
    }
            p.x--;
	    moved_this_frame = 1;
	    p.yy = FindDropTarget(p.x, p.y, p.curPiece[0], p.curFlip);
          }
          else  /* if it's blocked, let player slide the piece in
                   as soon as it clears the overhang */
            p.repeatTime[JPAD_LEFT ^ p.inverse] = REPEAT_DELAY - 1;
        }

        if(p.repeatTime[JPAD_DOWN]) // move down
        {
          if(p.stateTime - retrace_count > 1)
          {
            p.stateTime = retrace_count + 1;
            if(!g.tntMode)
              p.score++;
            p.dropMove = 0;
	    moved_this_frame = 1;
          }
        }

        /* Move right */
        if(p.repeatTime[JPAD_RIGHT ^ p.inverse] == 1 ||
           p.repeatTime[JPAD_RIGHT ^ p.inverse] == REPEAT_DELAY)
        {
          if(!CheckOverlap(p.x + 1, p.y, p.curPiece[0], p.curFlip))
          {
    {
      const SAMPLE_8GBS *s = gbfs_get_obj(samples_gbfs, "move.8gbs", NULL);
      play_8gbs(3, s, 0x10000);
    }
            p.x++;
	    moved_this_frame = 1;
	    p.yy = FindDropTarget(p.x, p.y, p.curPiece[0], p.curFlip);
          }
          else  /* if it's blocked, let player slide the piece in
                   as soon as it clears the overhang */
            p.repeatTime[JPAD_RIGHT ^ p.inverse] = REPEAT_DELAY - 1;
        }

        /* the essence of death mode is that pieces start on the
           bottom.  Wait a couple seconds to start death mode. */
        if(g.endMode == ENDMODE_DEATHMODE &&
           p.stateTime - retrace_count < 120)
          p.repeatTime[JPAD_UP] = 1;

        if(p.repeatTime[JPAD_UP] == 1 && p.dropMove == 0) // drop
        {
    if(g.endMode != ENDMODE_DEATHMODE)
    {
      const SAMPLE_8GBS *s = gbfs_get_obj(samples_gbfs, "spin.8gbs", NULL);
      play_8gbs(2, s, 0x0a000);
    }

          if(p.stateTime - retrace_count > 0)
            p.stateTime = retrace_count;

          if(!g.tntMode)
            p.score += p.yy - p.y;
	  p.y = p.yy;
	  moved_this_frame = 1;
          p.dropMove = 1;
        }

        // is it time to move the piece down 1?
        if(p.stateTime - retrace_count <= 0)
        {
          if(CheckOverlap(p.x, p.y + 1, p.curPiece[0], p.curFlip) != 0)
          {
            /* give the player some time to slide the piece in before
             * it locks into place
             */
            if(p.stateTime - retrace_count <= -p.dropTime)
            {
              if(p.pieceDone == 0)
                p.pieceDone = 1;
    {
      const SAMPLE_8GBS *s = gbfs_get_obj(samples_gbfs, "01kick.8gbs", NULL);
      play_8gbs(3, s, 0x10000);
    }

              /* check for a spinmove, hardest part */
              p.spinMove =
                CheckOverlap(p.x + 1, p.y, p.curPiece[0], p.curFlip) &&
                CheckOverlap(p.x - 1, p.y, p.curPiece[0], p.curFlip) &&
                CheckOverlap(p.x, p.y - 1, p.curPiece[0], p.curFlip);
              EraseSprites();
              DrawPiece(p.x, p.y, p.curPiece[0], p.curFlip, p.curColor[0], 2);
              p.scoreFac = 0;
              p.chainCount = 0;
              p.state = STATE_CHECKSQUARES;
            }
          }
          else
          {
            p.y++;
	    moved_this_frame = 1;

            if(g.endMode == ENDMODE_DEATHMODE)
              p.stateTime++;
            else
              p.stateTime += dv(2 * DIFFICULTY,
                                p.lines + p.handiLines + 2 * INITIAL_LEVEL);
            p.dropMove = 0;
          }
        }

        if(p.state == STATE_FALLING_PIECE)
        {
          if(moved_this_frame)
          {
            EraseSprites();
            DrawPiece(p.x, p.yy, p.curPiece[0], p.curFlip, BCOL_DOTTED_LINE, 1);
          }
          DrawPiece(p.x, p.y,
                    p.curPiece[0], p.curFlip,
                    (retrace_count & 0x07) ?
                      p.curColor[0] :
                      shading_indices[(p.curColor[0] >> 4) - 1][3] + 0x90,
                    1);
        }

        break;

      case STATE_CHECKSQUARES:
        p.stateTime = retrace_count + 1;
        if(g.tntMode)
        {
          int got;

          got = MarkSquares(0) * 2;
          got += MarkSquares(1);
          if(got)
          {
            m7.quake_speed += 0x10000 * got;
            p.stateTime = retrace_count + 25;
    {
      const SAMPLE_8GBS *s = gbfs_get_obj(samples_gbfs, "square.8gbs", NULL);
      play_8gbs(3, s, 0x10000);
    }
          }
        }
        p.state = STATE_CHECK4LINES;
        break;

      case STATE_CHECK4LINES:
        if(retrace_count - p.stateTime >= 0)
        {
          /* check for lines */
          if(CheckLines(p.spinMove))
          {
            p.state = STATE_MARK;
            p.yy = 21;
            if(p.spinMove)
            {
              p.nSpinMoves++;
              m7.quake_speed += 0x30000;
            }
          }
          else
            p.state = STATE_PUSHUP;
          p.dropMove = 0;
        }
        break;

      case STATE_MARK:
        UpdatePlayTime();
        do {
          MarkCarbon(p.spinMove, p.yy);
          if(p.yy == 0)
          {
            ClearOutCleared();
            p.state = STATE_FALL;
            p.stateTime = retrace_count;
            p.spinMove = 0;
            break;
          }
          else
            p.yy--;

          /* speed the game up for death mode */
        } while((p.yy & 1) && g.endMode == ENDMODE_DEATHMODE);
	break;

      case STATE_FALL:
        UpdatePlayTime();
        if(retrace_count - p.stateTime >= 0)
        {
          p.stateTime += 2;
          CarbonFallOnce();
          p.state = STATE_FALL2;
        }
        break;

      case STATE_FALL2:
        if(!CarbonStillGoing())
          p.state = STATE_CHECKSQUARES;
        else
          p.state = STATE_FALL;
        break;

      case STATE_PUSHUP:
        UpdatePlayTime();
        if(retrace_count - p.stateTime >= 0)
        {
          p.state = STATE_GET_NEW_PIECE;

          if(p.top < 0)
            GameOver(0);

#if 0  /* multiplayer only */

          /* If both players have some garbage coming, subtract
             the smaller amount of garbage from both players.
             This creates a "seesaw" effect.
          */
          if(p[1].coming > p[0].coming)
          {
            p[1].coming -= p[0].coming;
            p[0].coming = 0;
          }
          else
          {
            p[0].coming -= p[1].coming;
            p[1].coming = 0;
          }
          if(p.coming > 0)
          {
            PushUp();
            p.coming--;
          }
          else
          {
            if(MarkCarbon(0))  /* FIXME with new 1 frame per line marking */
              p.state = STATE_FALL;
            else if(p.pieceDone == 0)
              p.state = STATE_FALLING_PIECE;
            else if(p.top >= 0)
            {
              // remove inverse
              if(p.scoreFac >= 1)
              {
                p.inverse = 0;

                // play tetris sound and add an item
                if(p.scoreFac >= 4)
                {
//                  SendSound(gTetrisSound);
                  // If player has nothing in the item box, add an item, but
                  // don't add an inverse in non-versus mode.
                  if(p.curPiece[4] < 0)
                    p.curPiece[4] = PIECE_MAGNET + rand() % (attackMode + 1);
                }
              }
              p.state = STATE_GET_NEW_PIECE;
            }
            else
            {
/*
              if(attackMode)
                p[1 - curTurn].wins++;
*/
              GameOver();
              return 1;
            }
          }
#endif /* multiplayer */
        }
        break;
      case STATE_GAMEOVER:
        return 1;
      }
#if 0  /* curTurn loop */
  }
#endif

  return 0;
}

/* GetNewPiece() ***********************
 * Places a new random piece in the piece queue.
 */
static void GetNewPiece(int depth)
{
  if(g.tntMode)
  { /* tnt way */
    int piece = p.curPiece[depth] = rand() % 7;
    p.curPiece[depth] = (piece == 6) ? 7 : piece;
    p.curColor[depth] = gPieceColor[p.curPiece[depth]];
  }
  else
  { /* fpa-tetanus way */
#if SMALL_PIECES_IN_HR
    p.curPiece[depth] = rand() % (g.teflonMode ? NUM_PIECES - 3 : NUM_PIECES);
#else
    int piece = p.curPiece[depth] = rand() % (g.teflonMode ? 6 : 7);
    p.curPiece[depth] = (piece == 6) ? 7 : piece;
#endif
    p.curColor[depth] = ((rand() >> 13) & 1) ? BCOL_H : BCOL_R;
  }
}


/* MarkCarbon() ************************
   This function marks areas of blocks as either ground or floating
   by filling contiguous areas with a value denoting to which area
   each block belongs.
   It has been modified to do only a bit of work at a time
   to even out the load on the CPU from frame to frame;
   call it with decreasing values of markY from 21 to 0.
*/
static int MarkCarbon(int spinMove, int markY)
{
  int markX;

  if(spinMove)
    /*SendSound(gTetrisSound)*/;

  if(markY == 21)
    {
      for(markY = 0; markY < 20; markY++)
	for(markX = 0; markX < 10; markX++)
	  p.c.b[markY][markX] = -(p.b.b[markY][markX] != 0);
      for(markX = 0; markX < 10; markX++)
	p.c.b[20][markX] = 255;
      p.q = 0;
      return 0;
    }
      
  for(markX = 0; markX < 10; markX++)
    if(p.c.b[markY][markX] == 255)
      {
        if(spinMove)
        {
          if(markY == 20) // the bottom row should be all 1's
          {
            p.q = 1;
            p.c.b[markY][markX] = p.q;
          }
          else
          {
            TeDrawBlock(markX, markY, p.b.b[markY][markX]);
            if(p.c.b[markY + 1][markX]) // booth's algorithm?
              p.c.b[markY][markX] = p.c.b[markY + 1][markX];
            else
              p.c.b[markY][markX] = ++p.q;
          }
        }
        else
          TeFloodFill(markX, markY, ++p.q);
      }
  return (p.q > 1);
}

/* NewGame() ***************************
 * Sets up the grid and other parameters for a game of Tetanus.
 */
void NewGame(void)
{
  int y;
  const void *mockup_nam = gbfs_get_obj(data_gbfs, "mockup.nam", NULL);

  /* set up initial next pieces */
  for(y = 1; y <= 4; y++)
    GetNewPiece(y);

  /* init bg */
  dma_memcpy(backbits, mockup_nam, 1024);
  dirty_rows = 0xffffffff;
  dma_memcpy(m7scrbuf, backbits, 1024);

  /* clear field */
  for(y = 0; y < 20; y++)
  {
    int x;

    for(x = 0; x < 10; x++)
    {
      p.b.b[y][x] = p.c.b[y][x] = 0;
      TeDrawBlock(x, y, 0);
    }
  }

  /* init player stats */
  p.score = p.lines = p.coming = p.inverse = 0;
  p.top = 20;
  p.state = STATE_GET_NEW_PIECE;
  p.golds = p.silvers = p.playTime = p.score40 = 0;

  p.gameStart = retrace_count;

  /* clear out number of occurrences of chains */
  for(y = 0; y < 8; y++)
    p.lineBins[y] = 0;
  p.scoreFac = 0;


  /* ignore keys held down at game start */
  for(y = 0; y < 10; y++)
    p.repeatTime[y] = 1;
}

/* CheckOverlap() *********************
 * Is the piece overlapping something?
 */
static char CheckOverlap(int x, int y, int inPiece, int inFlip)
{
  int g, j, k;

  for(g = 0; g < NUM_BLOCKS; g++)
    if(gCBlocks[inPiece][inFlip][g]) // some pieces do not have all the blocks
    {
      j = y + gYBlocks[inPiece][inFlip][g];
      k = x + gXBlocks[inPiece][inFlip][g];
      if(k < 0 || k > 9 || j > 19)
	return 1;
      else if(j >= 0 && p.b.b[j][k])
	  return 1;
    }
  return 0;
}

static void PushUp(void)
{
  int x, e, d, g = 0;

  for(x = 0; x < 10; x++)
  {
    e = 666;
    for (g = 1; g < 20; g++)
    {
      d = e;
      e = p.b.b[g][x];
      if(e != d)
      {
        p.b.b[g - 1][x] = e;
	TeDrawBlock(x, g - 1, e);
      }
    }
    p.b.b[19][x] = BCOL_NEUTRAL;
  }

  p.b.b[19][rand() % 10] = 0;
  for(x = 0; x < 10; x++)
    TeDrawBlock(x, 19, p.b.b[19][x]);
}

/* ScrollDown() ************************
 * Nintendo's Tetris does this instead of CarbonStillGoing(). I'll put it back
 * in when I implement Purist Mode.
 */
/*
static void ScrollDown(short top, short bottom)
{
  short x, e, d, g;

  for(x = 0; x < 10; x++)
  {
    e = 66;
    for (g = bottom; g >= top; g--)
    {
      d = e;
      if(!g)
	e = 0;
      else
        e = p.b.b[g - 1][x];
      if(e != d || g == bottom)
      {
	if(e == -1)
	  e = 0;
        p.b.b[g][x] = e;
	TeDrawBlock(x, g, e);
      }
    }
  }
  top++;
}
*/

/* TeDrawBlock() **********************
 * Draws a colored block to the screen.  THIS MUST BE PORTED.
 */
static void TeDrawBlock(int x, int y, unsigned int colour)
{
  /* reject oob draws */
  if(y < 0 || y >= 20)
    return;

  /* translate from playfield to screen coords */
  x += 11;
  y += 6;

  /* show the background through */
  if(colour == 0)
    colour = backbits[y][x];

  dirty_rows |= 1 << y;
  m7scrbuf[y][x] = colour;
}


/* copy_dirty_rows() *******************
   Unrolled speed-copy of changed display rows.
   It's possible to do this more cleanly, but this is faster
   because it inlines the copying.
 */
void copy_dirty_rows(void)
{
  int i;
  unsigned int *dst = (unsigned int *)(MAP[PLAYFIELD_MAP][0]);
  unsigned int *src = (unsigned int *)m7scrbuf;

  for(i = 0; i < 32; i++)
  {
    if(dirty_rows & 0x01)
    {
      *dst++ = *src++;
      *dst++ = *src++;
      *dst++ = *src++;
      *dst++ = *src++;

      *dst++ = *src++;
      *dst++ = *src++;
      *dst++ = *src++;
      *dst++ = *src++;
    }
    else /* skip this row */
    {
      dst += 8;
      src += 8;
    }

    dirty_rows >>= 1;
  }
}
