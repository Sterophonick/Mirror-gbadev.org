/*

Tetanus On Drugs for GBA
stats.c : statistics and high score tracking
Copyright (C) 2002  Damian Yerrick

This program is free software; you can redistribute it and/or
modify it under the terms of the GNU General Public License
as published by the Free Software Foundation; either version 2
of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to 
  Free Software Foundation, Inc., 59 Temple Place - Suite 330,
  Boston, MA  02111-1307, USA.
GNU licenses can be viewed online at http://www.gnu.org/copyleft/

Visit http://www.pineight.com/ for more information.

*/

#include "tod.h"


#define SAVE_RAM ((volatile unsigned char *)0x0e000000)

/*
______________________________

    YOU HAVE A HIGH SCORE!

       ENTER YOUR NAME:


  5. PINOCC           123600
     ~~~~~~^~~~~~


        !"#$%&'()*+,-./
       0123456789:;<=>?
       @ABCDEF[H]JKLMNO
       PQRSTUVWXYZ[\]~_



 +PAD: MOVE        A: SELECT
    B: DELETE  START: ACCEPT

~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
*/


/* Layout of save
00-07  "TOD save"


60-ff  High scores

*/

#if 0
typedef struct Score
{
  char name[12];
  unsigned int score;
} Score;

static Score scores[10];

static const Score default_scores[10] =
{
  {"PIN EIGHT", 100000},
  {"PIN EIGHT",  90000},
  {"PIN EIGHT",  80000},
  {"PIN EIGHT",  70000},
  {"PIN EIGHT",  60000},
  {"PIN EIGHT",  50000},
  {"PIN EIGHT",  40000},
  {"PIN EIGHT",  30000},
  {"PIN EIGHT",  20000},
  {"PIN EIGHT",  10000}
};


/* init_scores() ***********************
   Search for the TOD scores in save RAM.  If they're not there,
   initialize them from ROM.
*/
void init_scores(void)
{
  const char save_sig[] = "TOD save";
  unsigned int i;
  const volatile unsigned char *src = SAVE_RAM + 0x60;

  for(i = 0; i < 8; i++)
  {
    if(SAVE_RAM[i] != save_sig[i])
    {
      src = (const unsigned char *)default_scores;
      break;
    }
  }
  {
    unsigned char *dst = (unsigned char *)scores;
    for(i = 160; i > 0; i--)
      *dst++ = *src++;
  }
}


/* get_score_name() ********************
   Get the name of the player who had a high score.
*/
void get_score_name(void)
{
  while(LCD_Y < 160);
  LCDMODE = 0;  /* darken screen */
  init_status_bar();
  set_status_bar();

}
#endif



/* postgame_stats() *********************
   Draw some stats.

0____5____0____5____0____5____

          GAME  OVER

  SCORE            000000000
  LINES                00000
  POINTS/LINE          00000
  40 LINES SCORE      000000
  PLAY TIME           000:00
  SILVER SQUARES       00000
  GOLD SQUARES         00000
  T-SPIN QUAKES        00000

 SINGLE DOUBLE TRIPLE  X4
  00000  00000  00000  00000
  X5     X6     X7     X8+
  00000  00000  00000  00000


         PRESS  START

~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

*/
void postgame_stats(void)
{
  const char stat_names[8][16] =
  {
    "SCORE", "LINES", "POINTS/LINE", "40 LINES SCORE",
    "PLAY TIME", "SILVER SQUARES", "GOLD SQUARES", "T-SPIN QUAKES"
  };
  const char bin_names[8][8] =
  {
    "SINGLE", "DOUBLE", "TRIPLE", "TET*IS",
    "t5", "t6", "t7", "t8+"
  };

  char buf[32];
  int i;

  wait4vbl();
  init_vram_ui();
  hud_cls();

  for(i = 0; i < 8; i++)
  {
    nttextout(HUD_MAP, 3, 3 + i, 0x2000, stat_names[i]);
  }

  nttextout(HUD_MAP, 10, 1, 0x2000, "GAME  OVER");
  nttextout(HUD_MAP, 9, 18, 0x2000, "PRESS  START");

  itoa_lpad(buf, 9, p.score, ' ');
  nttextout(HUD_MAP, 18, 3, 0x2000, buf);
  itoa_lpad(buf, 9, p.lines, ' ');
  nttextout(HUD_MAP, 18, 4, 0x2000, buf);
  if(p.lines)
  {
    itoa_lpad(buf, 9, dv(p.score, p.lines), ' ');
    nttextout(HUD_MAP, 18, 5, 0x2000, buf);
  }
  else
  {
    nttextout(HUD_MAP, 24, 5, 0x2000, "N/A");
  }
  if(p.lines >= 40)
  {
    itoa_lpad(buf, 9, p.score40, ' ');
    nttextout(HUD_MAP, 18, 6, 0x2000, buf);
  }
  else
  {
    nttextout(HUD_MAP, 24, 6, 0x2000, "N/A");
  }
  format_time(buf, 9, p.playTime);
  nttextout(HUD_MAP, 18, 7, 0x2000, buf);
  itoa_lpad(buf, 9, p.silvers, ' ');
  nttextout(HUD_MAP, 18, 8, 0x2000, buf);
  itoa_lpad(buf, 9, p.golds, ' ');
  nttextout(HUD_MAP, 18, 9, 0x2000, buf);
  itoa_lpad(buf, 9, p.nSpinMoves, ' ');
  nttextout(HUD_MAP, 18, 10, 0x2000, buf);

  for(i = 0; i < 4; i++)
  {
    int i7 = (i << 3) - i;
    nttextout(HUD_MAP, i7 + 1, 12, 0x2000, bin_names[i]);
    nttextout(HUD_MAP, i7 + 4, 14, 0x2000, bin_names[i + 4]);

    itoa_lpad(buf, 5, p.lineBins[i], ' ');
    nttextout(HUD_MAP, i7 + 2, 13, 0x2000, buf);
    itoa_lpad(buf, 5, p.lineBins[i + 4], ' ');
    nttextout(HUD_MAP, i7 + 2, 15, 0x2000, buf);
  }
  wait4vbl();
}
