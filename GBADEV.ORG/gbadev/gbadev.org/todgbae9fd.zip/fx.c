/*

Tetanus On Drugs for GBA
fx.c : render screen effects
Copyright (C) 2002  Damian Yerrick

This program is free software; you can redistribute it and/or
modify it under the terms of the GNU General Public License
as published by the Free Software Foundation; either version 2
of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to 
  Free Software Foundation, Inc., 59 Temple Place - Suite 330,
  Boston, MA  02111-1307, USA.
GNU licenses can be viewed online at http://www.gnu.org/copyleft/

Visit http://www.pineight.com/ for more information.

*/


#include "tod.h"


struct BGAFFINEREC bg2lines[160];

typedef struct BGSIDES
{
  int xl, xr, yl, yr;
} BGSIDES;
static BGSIDES bg2sides[160];

//#define USE_FASTFMUL

#define N_EFFECTS 8

void init_sides(int erlace)
{
  unsigned int i = 80;
  BGSIDES init_line =
  {-128 << 16, 128 << 16, -159 << 15, -159 << 15};
  BGSIDES *dst = bg2sides + erlace;

  if(erlace)
    init_line.yl += 1 << 16;
  do {
    *dst = init_line;
    dst += 2;
    init_line.yl += 2 << 16;
    init_line.yr = init_line.yl;
  } while(--i);
}


void init_sides_phi(fixed phi, int erlace)
{
  unsigned int i = 80;
  fixed m, zCos = hgrcos(phi);
  int scanline = erlace ? -157 : -159;
  BGSIDES *dst = bg2sides + erlace;

  /* don't use the expensive phi version if you don't need to */
  if(hgrcos(phi) >= 0xffff)
    {
      init_sides(erlace);
      return;
    }
  /* for a flat line, rotate it ever so slightly */
  if(hgrcos(phi) == 0)
  {
    phi -= 0x8000;
    zCos = hgrcos(phi);
  }
  zCos = dv(0x1000000 + (zCos >> 1), zCos);
  m = dv(hgrtan(phi) + 40, 160);

  do {
    fixed mline = (m * scanline + 0x10040) >> 8;

    if(mline <= 0)
    {
      dst->xl = 0;
      dst->xr = 0;
      dst->yl = 0;
      dst->yr = 0;
    }
    else
    {
      int x1 = dv(0x7fffffff, mline) - 1;
      int y1 = ((zCos * scanline >> 9) * x1 + 0x20) >> 7;

      dst->xl = -x1;
      dst->xr = x1;
      dst->yl = y1;
      dst->yr = y1;
    }
    scanline += 4;
    dst += 2;
  } while(--i);
}


void matrix_sides(fixed theta, fixed scale, fixed xc, fixed yc, int erlace)
{
  fixed c = (fastfmul(hgrcos(theta), scale) + 0x80) >> 8;
  fixed s = (fastfmul(hgrsin(theta), scale) + 0x80) >> 8;
  unsigned int i = 80;
  BGSIDES *dst = bg2sides + erlace;

  do {
    fixed lx = (dst->xl + 0x80) >> 8;
    fixed rx = (dst->xr + 0x80) >> 8;
    fixed ly = (dst->yl + 0x80) >> 8;
    fixed ry = (dst->yr + 0x80) >> 8;

    dst->xl  = lx * c - ly * s + xc;
    dst->xr = rx * c - ry * s + xc;
    dst->yl  = ly * c + lx * s + yc;
    dst->yr = ry * c + rx * s + yc;
    dst += 2;
  } while(--i);
}


/* maple code to produce *exact* values:

cubi := 6*jrk;
sqari := 2*acc - 486*jrk;
linei := vel - 161*acc + 19441*jrk;
x := -80*vel+6400*acc-512000*jrk;
for i from 1 to 80 do
  sqari := sqari + cubi:
  linei := linei + sqari:
  x := x + linei:
od:

however, on GBA, speed is more important than exactitude

*/

/* if shift_sides() is called before matrix_sides()
   then we need only process the X texel coordinates */
#define SHIFT_SIDES_PROCESS_Y_TOO 0

void shift_sides(int cubic, int quad, int linear, int cnst, int random, int erlace)
{
  int cubm, quadm, linem, cnstm, x;
  unsigned int i;
  unsigned char sbox_p;
  BGSIDES *dst = bg2sides;

  cubm = 6*cubic;
  quadm = 2*quad - ((486*cubic) >> 5);
  linem = linear - ((161*quad) >> 5) + ((19441*cubic) >> 10);
  cnstm = cnst - ((5*linear) >> 1) + ((25*quad)>>2) - ((125*cubic) >> 3);

  /* to render only the bottom half:
  cubm = 6*cubic;
  quadm = 2*quad - ((6*cubic) >> 5);
  linem = linear - (quad >> 5) + (cubic >> 10);
  cnstm = cnst;
  */
  
  /*
  x = 80*(80*(-80*cubic + quad) - linear) + cnst;
  */
  sbox_p = (rand() >> 7) & 0xff;
  for(i = 0; i < 160; i++)
  {
    quadm += cubm >> 5;
    linem += quadm >> 5;
    cnstm += linem >> 5;

    erlace = !erlace;
    if(erlace)
    {
      fixed lx = dst[i].xl;
      fixed wx = dst[i].xr - lx;
#if SHIFT_SIDES_PROCESS_Y_TOO
      fixed ly = dst[i].yl;
      fixed wy = dst[i].yr - ly;
#endif

      x = cnstm + (random * rijndaelS[sbox_p] >> 10);

      dst[i].xl  = lx + ((wx >> 6) * (x >> 6) >> 4);
      dst[i].xr = dst[i].xl + wx;
#if SHIFT_SIDES_PROCESS_Y_TOO
      dst[i].yl  = ly + ((wy >> 6) * (x >> 6) >> 4);
      dst[i].yr = dst[i].yl + wy;
#endif
      sbox_p = (sbox_p + 1) & 0xff;
    }
  }
}


/* fill_bg2() **************************
   Convert L/R coords to GBA HW format.
*/
void fill_bg2(int erlace)
{
  unsigned int i = 80;
  const BGSIDES *src = bg2sides + erlace;
  struct BGAFFINEREC *dst = bg2lines + erlace;

  do {
    if(src->xl == src->xr && src->yl == src->yr)
    {
      dst->pa = dst->pb = dst->pc = dst->pd = 0;
      dst->x_origin = dst->y_origin = 0x0800;
    }
    else
    {  /* When changing x_origin and y_origin per scanline, only pa and
         pc matter. They set the vector from which a line segment is
         drawn mapping to the chosen segment. */
      dst->pa = (src->xr - src->xl) >> 16;
      dst->pc = (src->yr - src->yl) >> 16;
      dst->pb = dst->pd = 0;
      dst->x_origin =
	(src->xl + ((src->xr - src->xl) >> 5) + 0x80) >> 8;
      dst->y_origin =
	(src->yl + ((src->yr - src->yl) >> 5) + 0x80) >> 8;
    }
    src += 2;
    dst += 2;
  } while(--i);
}



/* PHYSICS **********************************************************/



/* process_physics() *******************
   Convert a controller word to a set of effects,
   then perform resonance.

A       Cubic displacement
B       Linear displacement
Select  Fuzz
Start   (unused)
Right   Shift screen sideways
Left    Rock on z axis
Up      Quadratic displacement
Down    Zoom in/out
L       Rock on x axis
R       Constant zoom out

*/
void process_physics(unsigned int j)
{
  if(p.state != STATE_GAMEOVER)
  {
    unsigned int dscaledir = -0x44;

    m7.dscale += (0x14600 - m7.scale) >> 8;
    if(j & JOY_DOWN)
    {
      if(m7.dscale > 0)
        dscaledir = 0x44;
    }
    else if(j & JOY_R)
      dscaledir = 0x44;
    m7.dscale += dscaledir;
  }
  else
  {
    m7.dscale += 0x44;
  }

  m7.dscale = m7.dscale * 63 / 64;
  m7.scale += m7.dscale;
  /* If going through the center, turn image upside down */
  if(m7.scale < 0x0f)
  {
    m7.dscale = -m7.dscale;
    m7.scale = -m7.scale;
    m7.theta = (m7.theta & 0xffffff) ^ 0x800000;
    if(m7.dtheta > -0x1000 && m7.dtheta < 0x1000)
      m7.dtheta = 0x1000;
  }

  m7.dtheta -= hgrsin(m7.theta) >> 3;
  if(j & JOY_LEFT)
  {
    if(m7.dtheta < 0)
      m7.dtheta -= 0x0800;
    else
      m7.dtheta += 0x0800;
  }
  m7.dtheta = m7.dtheta * 127/128;
  m7.theta += m7.dtheta;

  m7.dphi -= hgrsin(m7.phi) >> 3;
  if(j & JOY_L)
  {
    if(m7.dphi < 0)
      m7.dphi -= 0x0800;
    else
      m7.dphi += 0x0800;
  }

  m7.dphi = m7.dphi * 63 / 64;
  m7.phi += m7.dphi;

  m7.dcubic  -= m7.cubic  >> 4;
  m7.dquad   -= m7.quad   >> 4;
  m7.dlinear -= m7.linear >> 4;
  m7.dcnst  -= m7.cnst  >> 4;
  if(j & JOY_RIGHT)
  {
    if(m7.dcnst < 0)
      m7.dcnst -= 0x0200;
    else
      m7.dcnst += 0x0200;
  }
  if(j & JOY_B)
  {
    if(m7.dlinear < 0)
      m7.dlinear -= 0x0100;
    else
      m7.dlinear += 0x0100;
  }
  if(j & JOY_UP)
  {
    if(m7.dquad < 0)
      m7.dquad -= 0x0080;
    else
      m7.dquad += 0x0080;
  }
  if(j & JOY_A)
  {
    if(m7.dcubic > 0)
      m7.dcubic += 0x0040;
    else
      m7.dcubic -= 0x0040;
  }
  if(j & JOY_SELECT)
    m7.fuzz += 0x100;

  m7.cubic  += m7.dcubic  >> 5;
  m7.quad   += m7.dquad   >> 5;
  m7.linear += m7.dlinear >> 5;
  m7.cnst   += m7.dcnst  >> 5;
  m7.dcubic  = m7.dcubic  * 63/64;
  m7.dquad   = m7.dquad   * 63/64;
  m7.dlinear = m7.dlinear * 63/64;
  m7.dcnst  = m7.dcnst  * 63/64;

  m7.fuzz = m7.fuzz * 63/64;
/* not yet implemented 
  pos->damp = pos->damp * 15/16;

  pos->damp -= pos->amp / 8;
*/

  m7.center_x += ((p.x + 13) * 0x80000 - m7.center_x) >> 4;
  m7.center_y += ((p.y + 49) * 0x28000 - m7.center_y) >> 4;

  m7.back_x = (rijndaelS[retrace_count & 0xff] - 128) * m7.quake_speed;
#if 0
  m7.back_y = rijndaelS[(retrace_count & 0xff) ^ 0xa5] * m7.quake_speed;
#endif
  m7.quake_speed = m7.quake_speed * 63/64;

}


void reset_view(void)
{
  unsigned int i;

  m7.theta = m7.dtheta = m7.cnst = m7.dcnst = m7.linear = m7.dlinear =
    m7.quad = m7.dquad = m7.cubic = m7.dcubic = m7.fuzz = m7.dscale =
    m7.dphi = m7.phi = 0;
  m7.scale = 0x24000;
  m7.center_x = 0x800000;
  m7.center_y = 0x800000;

  m7.lastBeat = 0;
  m7.cached_fxword = 0;
  m7.mana = 0;
  m7.n_effects = 0;
  m7.midiLoop = 1;
  m7.land_pos = 0;

  for(i = 0; i < N_EFFECTS; i++)
  {
    m7.fxQueue[i] = i;
  }
}


/* here, we're supposed to control the fx based on mana */
/* i'll get to this later */


/* the order in which the effects are introduced */

static const unsigned short fx_order[N_EFFECTS] =
{
  JOY_LEFT, JOY_DOWN,  /* rolling and zooming */
  JOY_SELECT, JOY_L,   /* fuzz and pitching */
  JOY_A, JOY_B,        /* cubic and linear */
  JOY_RIGHT, JOY_UP    /* sideways and quadratic */
};


unsigned short lands[] =
{
  32, 48, 64, 65, 80, 81,  /* verse */
  96, 104, 112, 116, 120,  /* bridge */
  130, 136, 142,           /* chorus */
  147, 152, 156, 160,
  164, 168, 172, 175,
  178, 181, 184, 187,
  0xffff
};

/* get_fxword() ************************
   Read the state of the music, and pull the strings.
*/
int get_fxword(void)
{
  unsigned int i;
  unsigned int beat = music_beat;

  if(beat != m7.lastBeat)
  {
    if(beat < m7.lastBeat)
    {
      m7.land_pos = 0;
      m7.midiLoop++;
      if(!dirty_hud)
        dirty_hud = 1;
    }
    m7.lastBeat = beat;

    if(beat == lands[m7.land_pos])
    {
      m7.land_pos++;

      /* shift fx queue */
      unsigned int max_effect = m7.midiLoop * 2;
      unsigned int front_effect = m7.fxQueue[0];
      unsigned int mid_effect;

      if(max_effect > N_EFFECTS)
        max_effect = N_EFFECTS;

      mid_effect = rand() % max_effect;

      m7.fxQueue[0] = m7.fxQueue[1];
      m7.fxQueue[1] = m7.fxQueue[mid_effect];
      m7.fxQueue[mid_effect] = front_effect;

      /* shift fx queue */
      m7.mana += m7.midiLoop;
    }

    /* handle effects for this mana */
    m7.mana -= m7.n_effects;
    if(m7.mana > 0 && m7.land_pos > 0)
    {
      m7.n_effects = (m7.mana + 7) / 8;
      if(m7.n_effects > N_EFFECTS)
        m7.n_effects = N_EFFECTS;
    }
    else
      m7.n_effects = 0;

    m7.cached_fxword = 0;
    for(i = 0; i < m7.n_effects; i++)
      m7.cached_fxword |= fx_order[m7.fxQueue[i]];
  }

  return m7.cached_fxword;
}
