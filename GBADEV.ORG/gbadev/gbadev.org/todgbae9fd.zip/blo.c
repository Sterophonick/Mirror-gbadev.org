/*

Tetanus On Drugs for GBA
blo.c : main
Copyright (C) 2002  Damian Yerrick

This program is free software; you can redistribute it and/or
modify it under the terms of the GNU General Public License
as published by the Free Software Foundation; either version 2
of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to 
  Free Software Foundation, Inc., 59 Temple Place - Suite 330,
  Boston, MA  02111-1307, USA.
GNU licenses can be viewed online at http://www.gnu.org/copyleft/

Visit http://www.pineight.com/ for more information.

*/

#include <stdio.h>
#include "tod.h"

MULTIBOOT


#define PROFILE_EFFECTS 0
#define PROFILE_MIXER 0
#define SLOWDOWN_EFFECTS 0
#define USE_EFFECTS_AT_ALL 1
#define HDMA_RUNS_DURING_VBLANK 0
#define N_MAIN_MENU 6

void isr(void);
extern volatile int want_reset;

void *old_master_isr;
extern struct BGAFFINEREC bg2lines[160];

int retrace_count;
unsigned int tree_egg;  /* seed for rand() based on a CRC */
unsigned char backbits[32][32];
unsigned char m7scrbuf[32][32];
unsigned int dirty_rows;
unsigned char dirty_hud, dirty_next;

const GBFS_FILE *data_gbfs, *bkgnds_gbfs, *bgm_gbfs, *samples_gbfs;


Player p;
ScreenPos m7;

/* dma_memcpy() ************************
   Copy a region of memory to VRAM or any other area of memory
   using the GBA hardware.  src and dst must be aligned to a 32-bit
   boundary, and len must be a multiple of 4.  The GBA's DMA
   controller needs a 2-cycle wait after writing to the control
   register; making this a non-inline function introduces the proper
   rest time.
*/
void dma_memcpy(void *dst, const void *src, size_t len)
{
  DMA[3].control = 0;
  DMA[3].src = src;
  DMA[3].dst = dst;
  DMA[3].count = len >> 2;
  DMA[3].control = DMA_ENABLE | DMA_COPYNOW | DMA_U32 | DMA_SRCINC | DMA_DSTINC;
}

#if 0
/* cpu_memcpy() ************************
   Copy a region of memory to VRAM or any other area of memory
   using the ARM7TDMI processor.
*/
void cpu_memcpy(void *in_dest, const void *in_source, size_t len)
{
  unsigned short *dst = in_dest;
  const unsigned short *src = in_source;

  len >>= 1;  /* bytes to shorts */
  if(len == 0)
    return;

  /* handle less than eight words */
  {
    size_t short_overage = len & 0x07;
    if(short_overage)
      do {
	*dst++ = *src++;
      } while(--short_overage);
  }

  len >>= 3;  /* shorts to 16-bytes */
  if(len == 0)
    return;

  /* unroll loop */
  do {
    *dst++ = *src++;
    *dst++ = *src++;
    *dst++ = *src++;
    *dst++ = *src++;
    *dst++ = *src++;
    *dst++ = *src++;
    *dst++ = *src++;
    *dst++ = *src++;
  } while(--len);
}
#endif


void wait4vbl(void)
{
#if PROFILE_MIXER
  int pal0 = PALRAM[0];

  PALRAM[0] = RGB( 0, 0, 0);
#endif

  music_play();

#if PROFILE_MIXER
  PALRAM[0] = RGB(31,23, 0);
#endif

  mixer();

#if PROFILE_MIXER
  PALRAM[0] = pal0;
#endif


#if 1
  asm volatile("mov r2, #0; swi 0x05" ::: "r0", "r1", "r2", "r3");
#else
  while(LCD_Y != 160);
#endif
  while(LCD_Y != 161);

  retrace_count++;

  /* compute crc */
  if(tree_egg & (1 << 31))
    tree_egg = (tree_egg << 1) ^ 0x12345679;
  else
    tree_egg = (tree_egg << 1);
}


/* keep this around so we know what's slow */
inline fixed fastfmul2(fixed lhs, fixed rhs)
{
  return ((unsigned long long)(lhs) * rhs) >> 16;
}


void init_sides(int erlace);
void init_sides_phi(fixed phi, int erlace);
void matrix_sides(fixed theta, fixed scale, fixed xc, fixed yc, int erlace);
void shift_sides(int cubic, int quad, int linear, int cnst, int random, int erlace);
void fill_bg2(int erlace);

void nttextout(u32 nt, u32 x, u32 y, u32 c, const char *str)
{
  while(*str)
    MAP[nt][y][x++] = (*str++ & 0xff) | c;
}


/* itoa_lpad() *************************
   Convert n into a string of len characters, left-padded with
   lpad_chr.  buf points to a buffer of at least (len + 1) chars.
*/
void itoa_lpad(char *buf, size_t len, int n, int lpad_chr)
{
  int sign_char = lpad_chr;

  /* handle negative integers */
  if(n < 0)
  {
    n = -n;
    sign_char = '-';
  }

  /* terminate the string */
  buf[len] = 0;

  /* extract each digit */
  do {
    unsigned int tenths = fracmul(n, (0xffffffffUL)/10+1);
    int ncomp = tenths * 10;

    if(ncomp > n)
    {
      --tenths;
      ncomp -= 10;
    }
    /* assumes compiler can optimize n % 10 and n / 10 into one op
       also assumes digits appear consecutively in 0123456789 order
       (this is true of ascii) */
    buf[--len] = (n - ncomp) + '0';
    n = tenths;
  } while(n && len);

  /* write sign */
  if(len)
    buf[--len] = sign_char;

  /* left pad */
  while(len)
    buf[--len] = lpad_chr;
}


/* format_time() ***********************
   Convert number of seconds n into a string min:sec
   of len characters, left-padded with spaces ' '.
   buf points to a buffer of at least (len + 1) chars.
*/
void format_time(char *buf, size_t len, unsigned int n)
{
  unsigned int minutes = dv(n, 60);
  unsigned int seconds = n - minutes * 60;

  itoa_lpad(buf, len - 3, minutes, ' ');
  buf[len - 3] = ':';
  itoa_lpad(buf + len - 2, 2, seconds, '0');
}


void set_status_bar(void)
{
  char buf[32];

  itoa_lpad(buf, 8, p.score, ' ');
  nttextout(18, 0, 7, 0x2000, buf);
  itoa_lpad(buf, 8, p.lines, ' ');
  nttextout(18, 0, 9, 0x2000, buf);

  itoa_lpad(buf, 2, m7.midiLoop, ' ');
  nttextout(18, 3, 19, 0x2000, buf);
  format_time(buf, 8, p.playTime);
  nttextout(18, 5, 19, 0x2000, buf);
}


/* run_dma() ***************************
   Start a background DMA of affine data on DMA channel 0
   from RAM to background 2.
*/
void run_dma(void)
{
  BGAFFINE[2] = bg2lines[0];
  DMA[0].control = 0;
  DMA[0].src = &(bg2lines[1]);
  DMA[0].dst = (u16 *)&(BGAFFINE[2]);
  DMA[0].count = 4;
  DMA[0].control = DMA_DSTINCRESET | DMA_SRCINC | DMA_REPEAT | DMA_U32 |
                   DMA_HBLANK | DMA_ENABLE;
}


/* start_wait() ************************
   Wait for the user to press Start, or for vbls/59.7 seconds to
   pass, whichever comes first.  Finishes at the start of vblank.
 */
void start_wait(unsigned int vbls)
{
  /* first wait for release */
  do {
    wait4vbl();
  } while(((JOY ^ 0x3ff) & (JOY_A | JOY_START)));
  /* then wait for press */
  do {
    wait4vbl();
    vbls--;
  } while((!((JOY ^ 0x3ff) & (JOY_A | JOY_START))) && vbls != 0);
}


#define P8LOGO_Y 3

void Pin8Logo(void)
{
  int x, y;

  LCDMODE = LCDMODE_BLANK;

  /* might want to use whatever cruncher the game uses */
  {
    unsigned int src_len;
    const void *src = gbfs_get_obj(data_gbfs, "p8logo.lz", NULL);
    unsigned char copr_colors[2] = {9, 5};
    if(!src)
    {
      LCDMODE = 0;
      PALRAM[0] = RGB(31, 0, 0);
    }

    gblz_unpack(src);
    dma_memcpy(VRAM, PU_OUTBUF, 1536);

    src = gbfs_get_obj(data_gbfs, "minicopr.chr", &src_len);
    expand_1b_to_gba4bit(VRAM + 768, src, src_len, copr_colors);
  }

  /* draw background */
  for(y = 0; y < 10 + P8LOGO_Y; y++)
    for(x = 0; x < 30; x++)
      MAP[2][y][x] = 0x0001;  /* solid white */
  for(x = 0; x < 30; x++)
    MAP[2][10 + P8LOGO_Y][x] = 0x0004;
  for(y = 11 + P8LOGO_Y; y < 20; y++)
    for(x = 0; x < 30; x++)
      MAP[2][y][x] = 0x0003;  /* solid blue */

  /* draw square */
  for(y = 0; y < 10; y++)
    for(x = 0; x < 10; x++)
      MAP[2][y + P8LOGO_Y][x + 10] = p8logo_map[y][x];

  /* draw words */
  for(x = 0; x < 10; x++)
    MAP[2][11 + P8LOGO_Y][x + 10] = x + 16;
  MAP[2][11 + P8LOGO_Y][20] = 0x0005; /* TM symbol */
  for(x = 0; x < 10; x++)
    MAP[2][12 + P8LOGO_Y][x + 10] = x + 32;

  /* draw mini copyright notice */
  nttextout(2, 10, 14 + P8LOGO_Y, 0x0000, "I012345678");

  /* load palette */
  dma_memcpy(PALRAM, p8logo_pal, sizeof(p8logo_pal));

  BGSCROLL[0].x = 0;
  BGSCROLL[0].y = 0;
  BGCTRL[0] = BGCTRL_PAT(0) | BGCTRL_16C | BGCTRL_NAME(2)
              | BGCTRL_H32 | BGCTRL_V32;

  while(LCD_Y < 160);
  LCDMODE = 0 | LCDMODE_BG0;

  /* first wait for release */
  y = 120;
  do {
    wait4vbl();
    if(y > 0)
      y--;
  } while(((JOY ^ 0x3ff) & (JOY_A | JOY_START | JOY_SELECT)) || y > 0);

  nttextout(2, 4, 15 + P8LOGO_Y, 0x0000, "@ABCDEFGHEJKLMNO:;<=>?");

  /* then wait for press */
  y = 360;
  do {
    wait4vbl();
    y--;
  } while((!((JOY ^ 0x3ff) & (JOY_A | JOY_START | JOY_SELECT))) && y > 0);
  if(!(JOY & JOY_SELECT))
  {
    copr_notice();
  }
}


/* title_screen() **********************
   Display a menu of 5 selections:
   Return
  -1  Enter demo
   0  Endless
   1  Play until 15,000 points
   2  Play for 180 seconds
   4  Options
   5  Reset
*/
static int title_screen(void)
{
  const struct BGAFFINEREC identity =
  {
    0x100, 0, 0, 0x100, 0, 0  /* FIXME: second elem should be 0 */
  };
  int sel = g.endMode;
  unsigned int last_j = 0x3ff;
  int picked = 0;

  /* decompress the title screen */
  {
    const void *src = gbfs_get_obj(data_gbfs, "todtitle.lz", NULL);

    gblz_unpack(src);
  }
  wait4vbl();

  LCDMODE = LCDMODE_BLANK;
  dma_memcpy(VRAM, PU_OUTBUF + 512, 38400);
  BGAFFINE[2] = identity;
  dma_memcpy(PALRAM, PU_OUTBUF, 512);
  LCDMODE = 4 | LCDMODE_BG2;

  for(picked = 2; picked < 128; picked++)
  {
    OAM[picked].y = OAM_HIDDEN;
  }
  OAM[0].y = OAM_WIDE | OAM_16C | 136;
  OAM[0].x = OAM_SIZE1 | 88;
  OAM[0].tile = 512;
  OAM[1].y = OAM_WIDE | OAM_16C | 136;
  OAM[1].x = OAM_SIZE1 | 120;
  OAM[1].tile = 516;

  /* load the sprites */
  {
    const void *src = gbfs_get_obj(data_gbfs, "openmenu.lz", NULL);

    gblz_unpack(src);
    expand_gb_to_gba4bit((void *)0x06014000, PU_OUTBUF, 1024, NULL);
  }
  PALRAM[257] = RGB( 0, 0, 0);
  PALRAM[258] = RGB(21,21,21);
  PALRAM[259] = RGB(31,31,31);
  LCDMODE = 4 | LCDMODE_BG2 | LCDMODE_SPR;

  /* display the menu */
  picked = 0;

  do {
    unsigned int j = (JOY ^ 0x3ff) & 0x3ff;
    unsigned int jnew = j & ~last_j;

    wait4vbl();
    OAM[0].tile = 512 + (sel << 3);
    OAM[1].tile = 516 + (sel << 3);

    if(jnew & JOY_UP)
      {
	if(sel == 0)
          sel = N_MAIN_MENU - 1;
	else
	  sel--;
      }
    if(jnew & JOY_DOWN)
      {
        if(sel >= N_MAIN_MENU - 1)
          sel = 0;
	else
	  sel++;
      }
    if(jnew & (JOY_A | JOY_START))
      picked = 1;
    last_j = j;
  } while(!picked);

  g.endMode = sel;

  return sel;
}


/* stats_wait() ************************
   Waits for the user to press Start, while slowly rotating the
   background.
 */
void stats_wait(void)
{
  signed int x = 0, y = 0, theta = 859131;
  signed int dx = 0, dy = 0, dtheta = -256;
  signed int d2x = 0, d2y = 0, d2theta = 0;

  unsigned int last_joy = 0x3ff;
  char done = 0;

  do {
    unsigned int cur_joy = JOY ^ 0x3ff;
    unsigned int jnew = cur_joy & ~last_joy;
    struct BGAFFINEREC svn;

    if(jnew & (JOY_A | JOY_START))
      done = 1;

    /* calculate new accelerations */
    if((retrace_count & 0x0f) == 0)
    {
      d2x = rijndaelS[(retrace_count >> 3) & 0xfe] - 128 - (dx >> 8);
      d2y = rijndaelS[((retrace_count >> 3) & 0xfe) | 1] - 128 - (dy >> 8);
      d2theta = (((x ^ y) & 0xff) - 0x80) - (dtheta >> 7);
      d2theta -= ((theta - 0x8000) >> 16);
    }

    /* newton's laws */
    dx += d2x;
    x += (dx + 128) >> 4;
    dy += d2y;
    y += (dy + 128) >> 4;
    dtheta += d2theta;
    theta += dtheta << 3;

    /* calculate affine coefficients */
    svn.pa = fastfmul(hgrcos(theta), 0x00e8);
    svn.pd = svn.pa;
    svn.pb = fastfmul(hgrsin(theta), 0x00e8);
    svn.pc = -svn.pb;
    svn.x_origin = (x & 0x7fff) - 120 * svn.pa - 80 * svn.pb;
    svn.y_origin = (y & 0x7fff) - 120 * svn.pc - 80 * svn.pd;
    
    last_joy = cur_joy;
    wait4vbl();
    BGAFFINE[2] = svn;
  } while(!done);
}


void play_tod(void)
{
    char got_gameover = 0;
    char game_paused = 0;
    char done = 0;
    char erlace = 0;
    unsigned int last_j = 0x3ff;
    init_vram_blocks();

    LCDMODE = 1 | LCDMODE_BLANK;

    reset_view();
    init_sides(0);
    init_sides(1);
    fill_bg2(0);
    fill_bg2(1);
    init_status_bar();

    if(g.endMode == 3)
    {
      /* death mode uses H&R and longer slides */
      p.dropTime = 25;
      g.tntMode = 0;
    }
    else
    {
      /* normal modes use TNT and shorter slides */
      p.dropTime = 13;
      g.tntMode = 1;
    }

    srand(tree_egg);
    NewGame();
    start_song(gbfs_get_obj(bgm_gbfs, "idltd.8gbm", NULL));
    dirty_hud = 1;
    dirty_next = 1;
    last_j = 0x3ff;
    game_paused = 0;

    while(!done)
    {
      unsigned int j = (JOY ^ 0x3ff) & 0x3ff;
      unsigned int jnew = j & ~last_j;

#if PROFILE_EFFECTS
      while(LCD_Y != 0) ;
#endif

      if(game_paused)
      {
        /* nothing */
      }
      else if(!got_gameover)
      {
        got_gameover = GameLoop(j);
      }
      else
      {
        if(m7.scale > 0x100000)  /* once the scaleout effect completes */
        {
          done = 1;
        }
      }

      /* Transform the screen */
      if(game_paused)
      {
        wait4vbl();
      }
      else
      {
#if PROFILE_EFFECTS
        unsigned int pal0 = PALRAM[0];
#endif


#if USE_EFFECTS_AT_ALL
        process_physics(get_fxword() | ((JOY ^ 0x3ff) & JOY_R));

  #if SLOWDOWN_EFFECTS
        erlace++;
        if(erlace >= 18)
          erlace = 0;
        if(erlace == 0 || erlace == 9)
        {

    #if PROFILE_EFFECTS
          PALRAM[0] = RGB( 0, 0,31);
    #endif
          init_sides_phi(m7.phi, erlace & 1);
          shift_sides(m7.cubic, m7.quad, m7.linear, m7.cnst, m7.fuzz, erlace & 1);
          matrix_sides(m7.theta, m7.scale, m7.center_x, m7.center_y, erlace & 1);
    #if PROFILE_EFFECTS
          PALRAM[0] = pal0;
    #endif
        }
  #else
        erlace = !erlace;
    #if PROFILE_EFFECTS
        PALRAM[0] = RGB( 0, 0,31);
    #endif
        init_sides_phi(m7.phi, erlace);
        shift_sides(m7.cubic, m7.quad, m7.linear, m7.cnst, m7.fuzz, erlace);
        matrix_sides(m7.theta, m7.scale, m7.center_x, m7.center_y, erlace);
    #if PROFILE_EFFECTS
        PALRAM[0] = pal0;
    #endif
  #endif
#else
	erlace = !erlace;
	init_sides(erlace);
        matrix_sides(0, 0x10000, 0x800000, 0x800000, erlace);
#endif
        wait4vbl();
        fill_bg2(erlace & 1);
      }
      /* Now we're in vblank time */
      copy_dirty_rows();

      if(game_paused)
      {
        int result = pause_menu(j);

        if(result == 1)
        {
          game_paused = 0;
          dirty_hud = 2;
          dirty_next = 1;
          p.gameStart += retrace_count;
          p.stateTime += retrace_count;
          jnew = 0;
          music_pause(0);
        }
        else if(result == -1)  /* user chose to quit */
        {
          const unsigned char *song =
            gbfs_get_obj(data_gbfs, "_gameover.8gbm", NULL);

          if(song)
            start_song(song);
          done = 1;
        }

        LCDMODE = 0 | LCDMODE_BG0 | LCDMODE_BG1;
      }
      else
      {
        switch(dirty_hud)
        {
        case 3:  /* 3: draw game over screen */
	case 4:
          gameover_screen(dirty_hud - 3);
          dirty_hud = 0;
          break;
        case 2:
          init_status_bar();
        case 1:
          set_status_bar();
          dirty_hud = 0;
          break;
        case 0:
          if(dirty_next)
          {
            dirty_next = 0;
            set_next_pal();
            DrawNext();
          }
          break;
        }

        if(jnew & JOY_START)
        {
          if(got_gameover)  /* start on Game Over will skip the fadeout */
          {
            done = 1;
          }
          else              /* start during gameplay will pause the game */
          {
            /* pause game */
            pause_menu_init();
            game_paused = 1;
            p.gameStart -= retrace_count;
            p.stateTime -= retrace_count;
            music_pause(1);
          }
        }

        if(retrace_count & 1)
        {
          if(m7.palrot)
          {
            BGSCROLL[1].x = 8;
            cycle_pal((m7.palphase >> 20) & 0x0f);
#if USE_EFFECTS_AT_ALL
            m7.palphase += 0x80000 + (m7.quake_speed << 5);
#endif
          }
          else
          {
            BGSCROLL[1].x = ((m7.back_x + 0x2200000) >> 22);
          }
          BGSCROLL[1].y = 8;
        }
        LCDMODE = 1 | LCDMODE_BG0 | LCDMODE_BG1 | LCDMODE_BG2;
      }
#if HDMA_RUNS_DURING_VBLANK
      while(LCD_Y != 227) ;
#endif
      run_dma();
      last_j = j;
    }



  DMA[0].control = 0;  /* turn off mode 7 dma */
  LCDMODE = 1 | LCDMODE_BG0 | LCDMODE_BG1;
  postgame_stats();
  stats_wait();
}


#define ROM_BANKSWITCH (volatile u16 *)(0x096B592E)
#define WRITE_LOC_1 (volatile u16 *)(0x987654*2+0x8000000)
#define WRITE_LOC_2 (volatile u16 *)(0x012345*2+0x8000000)
#define WRITE_LOC_3 (volatile u16 *)(0x007654*2+0x8000000)
#define WRITE_LOC_4 (volatile u16 *)(0x765400*2+0x8000000)
#define WRITE_LOC_5 (volatile u16 *)(0x013450*2+0x8000000)

void reset_gba(void)
{
  unsigned int i;

  INTENABLE = 0;

  /* reset cart bankswitching */
  for(i=0;i<1;i++) *WRITE_LOC_1=0x5354;
  for(i=0;i<500;i++) *WRITE_LOC_2=0x1234;
  for(i=0;i<1;i++) *WRITE_LOC_2=0x5354;
  for(i=0;i<500;i++) *WRITE_LOC_2=0x5678;
  for(i=0;i<1;i++) *WRITE_LOC_1=0x5354;
  for(i=0;i<1;i++) *WRITE_LOC_2=0x5354;
  for(i=0;i<1;i++) *WRITE_LOC_4=0x5678;
  for(i=0;i<1;i++) *WRITE_LOC_5=0x1234;
  for(i=0;i<500;i++) *WRITE_LOC_2=0xabcd;
  for(i=0;i<1;i++) *WRITE_LOC_1=0x5354;   
  *ROM_BANKSWITCH=0;

  /* reset GBA */
  *(u16 *)0x03007ffa = 0;  /* reset to ROM (= 0) rather than RAM (= 1) */
  asm volatile(
    "mov r0, #0xfc  \n"  /* clear everything other than RAM */
    "swi 0x01       \n"
    "swi 0x00       \n"
    ::: "r0", "r1", "r2", "r3");
}


int main(void)
{
#if 1
  data_gbfs = find_first_gbfs_file(find_first_gbfs_file);
#else
  data_gbfs = find_first_gbfs_file(ROM);
#endif

  if(!data_gbfs)
  {
    LCDMODE = 0;
    PALRAM[0] = RGB(31, 0, 0);
  }
  bkgnds_gbfs = skip_gbfs_file(data_gbfs);
  bgm_gbfs = skip_gbfs_file(bkgnds_gbfs);
  samples_gbfs = skip_gbfs_file(bgm_gbfs);

  /* set the ISR */
  SET_MASTER_ISR(isr);
  /* turn on interrupt sources */
  LCDSTAT = LCDSTAT_VBLINT;  /* vbl interrupt */
  /* turn on interrupt controller */
  INTMASK = INT_VBLANK;
  INTENABLE = 1;

#if 0
  {
    int x;

    for(x = 0; x < 16; x++)
      PU_OUTBUF_PRE[x] = 0;
  }
#endif
  init_sound(samples_gbfs);
  Pin8Logo();

  while(1)
  {
    int sel;

    tree_egg ^= 1;
    music_pause(1);

    sel = title_screen();
    if(sel < 4)
      play_tod();
    else if(sel == 5)
      reset_gba();
  }
}

