#define N_GBMXR_VOICES 4
#define MIXBUF_SIZE 352

#define DMA_MIXBUS_CLEAR 1

#if DMA_MIXBUS_CLEAR
struct DMACHN
{
  const void *src;
  void *dst;
  unsigned short count;
  unsigned short control;
};

#define DMA ((volatile struct DMACHN *)0x040000b0)
#define DMA_DSTINC      0x0000
#define DMA_DSTDEC      0x0020
#define DMA_DSTUNCH     0x0040
#define DMA_DSTINCRESET 0x0060
#define DMA_SRCINC      0x0000
#define DMA_SRCDEC      0x0080
#define DMA_SRCUNCH     0x0100
#define DMA_REPEAT      0x0200
#define DMA_U16         0x0000
#define DMA_U32         0x0400
#define DMA_COPYNOW     0x0000
#define DMA_VBLANK      0x1000
#define DMA_HBLANK      0x2000
#define DMA_SPECIAL     0x3000
#define DMA_IRQ         0x4000
#define DMA_ENABLE      0x8000
#endif


typedef struct GBMXR_VOICE
{
  unsigned long sample_rate;  /* 16.16 fixed point; 0x10000 = 100% */
  unsigned char volume;
  unsigned char reserved;
  unsigned short subsample;     /* counter used for resampling */
  const signed char *sample_data;
  const signed char *loop_end;
  unsigned long loop_len;
} GBMXR_VOICE;

extern GBMXR_VOICE gbmxr_voices[N_GBMXR_VOICES];

static long unused_align_mixbus16;  /* to align the following buffer */
static signed short mixbus16[MIXBUF_SIZE];

void mix_more(signed char *dst, const unsigned int bufsiz)
{
  unsigned int channels_left = N_GBMXR_VOICES;
  GBMXR_VOICE *ch = gbmxr_voices;

  {
#if DMA_MIXBUS_CLEAR
    long mxb_src = 0;
    /* UNTESTED: conversion to dma memset */

    DMA[3].control = 0;
    DMA[3].src = &mxb_src;
    DMA[3].dst = mixbus16;
    DMA[3].count = bufsiz >> 1;
    DMA[3].control = DMA_DSTINC | DMA_SRCUNCH | DMA_U32 | DMA_COPYNOW | DMA_ENABLE;
#else
    long *mxb = (long *)mixbus16;
    unsigned int left = bufsiz >> 3;

    do {
      *mxb++ = 0;
      *mxb++ = 0;
      *mxb++ = 0;
      *mxb++ = 0;
    } while(--left);
#endif
  }

  do {
    const unsigned int rate = ch->sample_rate;

    if(rate)
    {
      const unsigned int len = ch->loop_len;
      const signed char *const loop_end = ch->loop_end;
      const unsigned int vol = ch->volume >> 2;
      const signed char *sample_data = ch->sample_data;
      unsigned int sub = ch->subsample;
      signed long *mixbus_pos = (signed long *)mixbus16;
      unsigned int bufleft = bufsiz >> 1;

      if(sample_data + (rate * bufsiz >> 16) + 1 < loop_end)
      {
        /* if we know we're not going to end or loop,
           use a fast path with fewer branches */
        do {
          unsigned int mbus = *mixbus_pos;

          /* mix the first sample into the low order word */
          mbus += (int)sample_data[sub >> 16] * vol;
          sub += rate;

          /* mix the second sample into the high order word */
          mbus += (int)sample_data[sub >> 16] * vol << 16;
          sub += rate;

          *mixbus_pos++ = mbus;
        } while(--bufleft);
        sample_data += sub >> 16;
        sub &= 0xffff;
      }
      else
      {
        do {
          unsigned int mbus = *mixbus_pos;

          /* mix the first sample into the low order word */
          mbus += (int)*sample_data * vol;
          sub += rate;
          sample_data += sub >> 16;
          sub &= 0xffff;

          if(sample_data >= loop_end)
          {
            if(len)
            {
              sample_data -= len;
            }
            else
            {
              ch->sample_rate = 0;
              break;
            }
          }

          /* mix the second sample into the high order word */
          mbus += (int)*sample_data * vol << 16;
          sub += rate;
          sample_data += sub >> 16;
          sub &= 0xffff;

          if(sample_data >= loop_end)
          {
            if(len)
            {
              sample_data -= len;
            }
            else
            {
              ch->sample_rate = 0;
              break;
            }
          }

          *mixbus_pos++ = mbus;
        } while(--bufleft);
      }

      ch->sample_data = sample_data;
      ch->subsample = sub;
    }

    ch++;
  } while(--channels_left);

  /* convert mixed buffer to 8-bit for playback */
  {
    unsigned int bufleft = bufsiz;
    signed short *mixbus_pos = mixbus16;

    do {
      int mixbus = *mixbus_pos++;

      mixbus >>= 7;

      /* clip */
      if(mixbus > 127)
        mixbus = 127;
      else if(mixbus < -127)
        mixbus = -127;

      /* write */
      *dst++ = mixbus;
    } while(--bufleft);
  }
}
