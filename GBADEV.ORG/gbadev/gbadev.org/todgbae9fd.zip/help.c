/*

Tetanus On Drugs for GBA
help.c : help functions
Copyright (C) 2002  Damian Yerrick

This program is free software; you can redistribute it and/or
modify it under the terms of the GNU General Public License
as published by the Free Software Foundation; either version 2
of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to 
  Free Software Foundation, Inc., 59 Temple Place - Suite 330,
  Boston, MA  02111-1307, USA.
GNU licenses can be viewed online at http://www.gnu.org/copyleft/

Visit http://www.pineight.com/ for more information.

*/
#include "tod.h"

static const char help_controls[] =
"GAME CONTROLS\n"
"\n"
"+PAD MOVE PIECE\n"
"  UP DROP PIECE QUICKLY\n"
"   A ROTATE CLOCKWISE\n"
"   B ROTATE ANTICLOCKWISE\n"
"   L SWAP PIECE WITH RESERVE\n"
" B+A (SAME AS L)\n"
"   R ZOOM OUT\n"
"  ST PAUSE\n";

static const char help_objective[] =
"OBJECTIVE\n"
"\n"
"PACK THE FALLING PIECES INTO\n"
"COMPLETE HORIZONTAL LINES OF\n"
"BLOCKS.  IF YOU MAKE A LINE,\n"
"IT IS REMOVED FROM THE PLAY\n"
"FIELD, AND THE BLOCKS ABOVE\n"
"IT FALL, POTENTIALLY FILLING\n"
"IN OTHER LINES.  DON'T FILL\n"
"THE PLAYFIELD.";

static const char help_scoring[] =
"SCORING\n"
"\n"
"YOU GET 100 POINTS PER LINE.\n"
"YOU GET MORE FOR CLEARING 4\n"
"OR MORE LINES WITH ONE PIECE\n"
"(THINK CHAIN REACTION) OR\n"
"FOR MAKING 4-BY-4 BLOCK\n"
"SQUARES OUT OF THE PIECES.\n";


static const char help_header[] =
"TETANUS ON DRUGS        HELP\n";

static const char help_footer[] =
" +PAD: VIEW HELP\n"
"    B: RETURN TO MENU\n";



void set_status_bar(void);  /* from blo.c */


void draw_text(const char *s,
               unsigned int xo, unsigned int y,
               unsigned int color)
{
  unsigned int x = xo;

  for(; *s; s++)
  {
    char c = *s;

    if(c >= ' ')
    {
      MAP[HUD_MAP][y][x] = c | color;
      x++;
    }
    else if(c == '\n')
    {
      x = xo;
      y++;
    }
  }
}

int draw_help(int scrn)
{
  hud_cls();

  switch(scrn)
  {
  case 0:
    draw_text(help_controls, 1, 3, 0x2000);
    break;

  case 1:
    draw_text(help_objective, 1, 3, 0x2000);
    break;

  case 2:
    draw_text(help_scoring, 1, 3, 0x2000);
    break;

  }

  draw_text(help_header, 1, 1, 0x2000);
  draw_text(help_footer, 1, 17, 0x2000);


  return scrn;
}


void start_wait(unsigned int vbls);
void expand_gb_to_gba4bit(void *in_dst, const u8 *src, size_t len, const unsigned char gbpal[4]);

/* TOD as a whole is GPL, but some files therein are x11 licensed. */

static const char copr_notice_text[] =
"TETANUS ON DRUGS       PRE-M3\n"
"\n"
"` 1999-2002 Damian YERRICK\n"
"\n"
"TETANUS ON DRUGS IS *NOT*\n"
"LICENSED BY NINTENDO OR THE\n"
"TETRIS COMPANY AND COMES WITH\n"
"ABSOLUTELY NO WARRANTY.\n"
"THIS IS FREE SOFTWARE, AND\n"
"YOU ARE WELCOME TO SHARE IT\n"
"UNDER THE TERMS GIVEN IN THE\n"
"CHAPTER \"LEGAL INFORMATION\"\n"
"IN THE MANUAL.\n"
"\n\n\n\n\n"
"                  PRESS START";

/* display copyright notice */
void copr_notice(void)
{
  const unsigned char gbtextpal[4] = {0, 0, 1, 3};
  const u16 pal[4] =
  {
    RGB(28,31,24),RGB(20,24,16),RGB(12,16, 8),RGB( 4, 8, 0)
  };

  /* blank screen while uploading image data */
  while(LCD_Y < 160);
  LCDMODE = 0 | LCDMODE_BLANK;

  /* copy font and palette */
  load_hud_font(2, gbtextpal);
  dma_memcpy(PALRAM, pal, 4 * sizeof(u16));

  /* write message */
  hud_cls();
  draw_text(copr_notice_text, 0, 1, 0);

  /* set up screen */
  while(LCD_Y != 224);
  BGCTRL[0] =
    0 | BGCTRL_PAT(2) | BGCTRL_16C | BGCTRL_NAME(18)
    | BGCTRL_H32 | BGCTRL_V32;
  BGSCROLL[0].x = 256-4;
  BGSCROLL[0].y = 4;
  LCDMODE = 0 | LCDMODE_BG0;

  start_wait(127<<24);
}


enum {
  PAUSE_MENU_MAIN = 0,
  PAUSE_MENU_HELP
};


static unsigned char pause_menu_y = 0;
static unsigned char pause_menu_mode;
static unsigned int last_j = 0;

/* the new pause menu

______________________________

          GAME PAUSED



          > CONTINUE
 Score
 0000000    BG: 420
 Lines
 0000000    HELP

            QUIT







 Lv 2
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
*/

void pause_menu_init(void)
{
  init_status_bar();
  set_status_bar();
  nttextout(HUD_MAP, 10,  1, 0x2000, "GAME PAUSED");
  nttextout(HUD_MAP, 12,  5, 0x2000, "CONTINUE");
  nttextout(HUD_MAP, 12,  7, 0x2000, "BG:");
  nttextout(HUD_MAP, 12,  9, 0x2000, "HELP");
  nttextout(HUD_MAP, 12, 11, 0x2000, "SLEEP (ST+SEL");
  nttextout(HUD_MAP, 12, 12, 0x2000, "  TO WAKE)");
  nttextout(HUD_MAP, 12, 13, 0x2000, "QUIT");
  draw_bg_name();
  MAP[HUD_MAP][5][10] = 0x2000 | '>';

  last_j = 0x03ff;
  pause_menu_mode = PAUSE_MENU_MAIN;
  pause_menu_y = 0;

}

void help_menu_init(void)
{
  pause_menu_y = 0;
  pause_menu_mode = PAUSE_MENU_HELP;
  draw_help(0);
}


static void swi_3(void)
{
  asm volatile("swi 0x03");
}

void halt_gba(void)
{
  /* Disable video (force blank). */
  wait4vbl();
  LCDMODE = LCDMODE_BLANK;

  /* Wait for 2 vblanks (so as not to produce any fading
     horizontal line artifacts). */
  wait4vbl();
  wait4vbl();

  /* Disable all interrupts but the joypad. */
  INTENABLE = 0;
  INTMASK = INT_JOY;
  JOYINT = JOY_SELECT | JOY_START | JOYINT_ALL;
  INTENABLE = 1;

  /* Call swi 0x03 ("Stop") */
  swi_3();

  /* reinitialize everything that needs it */
  LCDMODE = 1 | LCDMODE_BG0 | LCDMODE_BG1;
  INTMASK = INT_VBLANK;
}


#define MAIN_MENU_ITEMS 5

static int pause_menu_main(unsigned int j)
{
  unsigned int jnew =  j & ~last_j;
  unsigned int last_y = pause_menu_y;

  if(jnew & JOY_DOWN)
  {
    pause_menu_y++;
    if(pause_menu_y >= MAIN_MENU_ITEMS)
      pause_menu_y = 0;
  }

  if(jnew & JOY_UP)
  {
    if(pause_menu_y > 0)
      pause_menu_y--;
    else
      pause_menu_y = MAIN_MENU_ITEMS - 1;
  }

  switch(pause_menu_y)
  {
  case 0:
    if(jnew & (JOY_A | JOY_START))
      return 1;
    break;
  case 1:
    if(jnew & (JOY_A | JOY_RIGHT))
    {
      switch_bg(1);
      draw_bg_name();
    }
    if(jnew & (JOY_LEFT))
    {
      switch_bg(-1);
      draw_bg_name();
    }
    if(jnew & (JOY_START))
      return 1;
    break;
  case 2:
    if(jnew & (JOY_A | JOY_START))
      help_menu_init();
    break;
  case 3:
    if(jnew & (JOY_A | JOY_START))
    {
      halt_gba();
      j = JOY_A | JOY_SELECT | JOY_START;
    }
    break;
  case 4:
    if(jnew & (JOY_A | JOY_START))
      return -1;
  }

  /* move cursor if necessary */
  if(last_y != pause_menu_y && pause_menu_mode == PAUSE_MENU_MAIN)
  {
    MAP[HUD_MAP][last_y*2+5][10] = ' ';
    MAP[HUD_MAP][pause_menu_y*2+5][10] = 0x2000 | '>';
  }
  last_j = j;
  return 0;
}

static int pause_menu_help(unsigned int j)
{
  unsigned int jnew =  j & ~last_j;
  unsigned int last_y = pause_menu_y;

  if(jnew & JOY_LEFT)
  {
    if(pause_menu_y == 0)
      pause_menu_y = 2;
    else
      pause_menu_y--;
  }

  if(jnew & JOY_RIGHT)
  {
    if(pause_menu_y == 2)
      pause_menu_y = 0;
    else
      pause_menu_y++;
  }

  if(jnew & (JOY_A | JOY_B))
  {
    pause_menu_init();
    return 0;
  }

  if(jnew & JOY_START)
  {
    return 1;
  }

  if(last_y != pause_menu_y)
    draw_help(pause_menu_y);

  last_j = j;
  return 0;
}


/* pause_menu() ************************
   Operate pause menu.
   Return: 0 still paused; 1 continue game; -1 exit game
*/
int pause_menu(unsigned int j)
{
  switch(pause_menu_mode)
  {
  case PAUSE_MENU_MAIN:
    return pause_menu_main(j);
  case PAUSE_MENU_HELP:
    return pause_menu_help(j);
  default:
    return 0;
  }
}
