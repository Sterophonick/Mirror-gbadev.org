#ifndef DEMO
#define DEMO 0
#endif

#define N_GBMXR_VOICES 8
#define MIXBUF_SIZE 352

#include <stdlib.h>
#include "pin8gba.h"

#include "gbfs.h"

unsigned int fracumul(unsigned int x, unsigned int frac);


typedef struct SAMPLE_8GBS
{
  unsigned short data_off;
  unsigned short sample_rate;
  unsigned long len;
  unsigned long loop_len;
  unsigned char vol;
} SAMPLE_8GBS;

static unsigned char music_is_paused = 0;
unsigned int music_beat;

typedef struct MusicGlobals
{
  const GBFS_FILE *dsound_samples;
  const unsigned short *insts;
  const unsigned short *orders;
  const unsigned char *ch3_samples;
  const unsigned short *patptrs;
  const unsigned char *patdata;
  unsigned int patptr[N_GBMXR_VOICES + 4];
  unsigned short row_n;
  unsigned char tempo[2];
  unsigned char row_ticks_left;
  unsigned char n_ch;
  char note_rows_left[N_GBMXR_VOICES + 4];
  char base_note[N_GBMXR_VOICES + 4];
  unsigned short sqr_inst[2];
  unsigned char sample_inst[N_GBMXR_VOICES];
  unsigned char vol[N_GBMXR_VOICES + 4];
  unsigned short freq[N_GBMXR_VOICES + 4];
  signed short freq_delta[N_GBMXR_VOICES + 4];
  unsigned short order_no[N_GBMXR_VOICES + 4];
} MusicGlobals;

MusicGlobals mus;


typedef struct GBMXRVOICE
{
  unsigned long sample_rate;  /* 16.16 fixed point; 0x10000 = 100% */
  unsigned char volume;
  unsigned char reserved;
  unsigned short subsample;     /* counter used for resampling */
  const signed char *sample_data;
  const signed char *loop_end;
  unsigned long loop_len;
} GBMXR_VOICE;

GBMXR_VOICE gbmxr_voices[N_GBMXR_VOICES];

#define SAMPLE_TIME (280896/MIXBUF_SIZE)

static int cur_mixbuf = 0;
static long mixbuf[2][MIXBUF_SIZE >> 2];

void mix_more(unsigned char *dst, unsigned int bufsiz);

/* get note frequencies */
#include "notefreq.h"

void load_waveram(const unsigned char *src)
{
  u32 *srcL = (u32 *)src;

  TRIWAVERAM[0] = *srcL++;
  TRIWAVERAM[1] = *srcL++;
  TRIWAVERAM[2] = *srcL++;
  TRIWAVERAM[3] = *srcL++;
}

/* mixer() *****************************
   Call this sometime each frame.
*/
void mixer(void)
{
  mix_more((signed char *)mixbuf[cur_mixbuf], MIXBUF_SIZE);
}


static void dsound_switch_buffers(const void *src)
{
  DMA[1].control = 0;
#if 0
  /* no-op to let DMA registers catch up */
  asm volatile ("eor r0, r0; eor r0, r0" ::: "r0");
#endif
  DMA[1].src = src;
  DMA[1].dst = (void *)0x040000a0; /* write to FIFO A address */
  DMA[1].count = 1;
  DMA[1].control = DMA_DSTUNCH | DMA_SRCINC | DMA_REPEAT | DMA_U32 |
                   DMA_SPECIAL | DMA_ENABLE;
}


/* dsound_vblank() *********************
   Call this first in your vblank handler.
*/
void dsound_vblank(void)
{
  dsound_switch_buffers(mixbuf[cur_mixbuf]);
  cur_mixbuf = !cur_mixbuf;
}


/* music_set_instrument() **************
   Set an instrument on a channel.
*/
void music_set_instrument(unsigned int ch, unsigned int n)
{
  if(ch >= 4)
  {
    unsigned int inst_id = n & 0x3f;

    if(inst_id)
    {
      const SAMPLE_8GBS *sample =
        gbfs_get_objn(mus.dsound_samples, inst_id - 1, NULL);

      if(sample)
      {
        mus.vol[ch] = sample->vol;
      }
    }
    mus.sample_inst[ch - 4] = inst_id;
  }

  /* FIXME: GB instruments should set volume */
  switch(ch)
  {
  case 0:
  case 1:
    mus.sqr_inst[ch] = mus.insts[n & 0x3f];
    break;
  case 2:
    TRICTRL = TRICTRL_2X32 | TRICTRL_BANK(1) | TRICTRL_ENABLE;
    load_waveram(mus.ch3_samples + (n & 0x3f) * 16);
    TRICTRL = TRICTRL_2X32 | TRICTRL_BANK(0) | TRICTRL_ENABLE;
    break;
  }
}


#if 0
void play_sample(unsigned int voice, const char *s, size_t len, unsigned int rate, unsigned int vol)
{
  gbmxr_voices[voice].sample_rate = rate;
  gbmxr_voices[voice].volume = vol;
  gbmxr_voices[voice].subsample = 0;
  gbmxr_voices[voice].sample_data = s;
  gbmxr_voices[voice].loop_end = s + len;
  gbmxr_voices[voice].loop_len = 0;
}
#endif


void play_8gbs_vol(unsigned int voice,
                   const SAMPLE_8GBS *sample,
                   unsigned int freq_fac, unsigned int vol)
{
  const signed char *start = (const signed char *)sample + sample->data_off;

  /*
   To convert a sample rate in Hz to a gbmxr rate, multiply it by
   SAMPLE_TIME and divide by 256.
  */
  gbmxr_voices[voice].sample_rate =
          fracumul(sample->sample_rate * SAMPLE_TIME, freq_fac << 8);
  gbmxr_voices[voice].volume = vol;
  gbmxr_voices[voice].subsample = 0;
  gbmxr_voices[voice].sample_data = start;
  gbmxr_voices[voice].loop_end = start + sample->len;
  gbmxr_voices[voice].loop_len = sample->loop_len;
#if 0
  PALRAM[0] = RGB(gbmxr_voices[voice].volume >> 2, voice * 8, 0);
#endif
}


void play_8gbs(unsigned int voice,
               const SAMPLE_8GBS *sample,
               unsigned int freq_fac)
{
  play_8gbs_vol(voice, sample, freq_fac, sample->vol);
}


/* music_note() ************************
   Play a note on a channel.
*/
void music_note(unsigned int ch, unsigned int n)
{
  if(ch >= 4)
  {
    unsigned int inst_id = mus.sample_inst[ch - 4];
    unsigned int freq_fac = 0x10000;
    const SAMPLE_8GBS *sample;
    int vol = -1;

    if(inst_id)  /* positive instrument means a melody track */
    {
      mus.freq[ch] = (unsigned int)sampled_freqs[(n + mus.base_note[ch]) & 0x3f];
      freq_fac = mus.freq[ch] << 4;
      inst_id--;
      vol = mus.vol[ch];
    }
    else  /* for a drum track */
    {
      inst_id = n & 0x3f;
#if 0
      PALRAM[0] = RGB((n >> 3) & 0x1f, 0, 0);
#endif
    }
    sample = gbfs_get_objn(mus.dsound_samples, inst_id, NULL);
    if(vol < 0)
      vol = sample->vol;

    if(sample)
    {
      play_8gbs_vol(ch - 4, sample, freq_fac, vol);
    }
    
    return;
  }

  /* FIXME: GB instruments should respect their volume setting */

  mus.freq[ch] = note_freqs[(n + mus.base_note[ch]) & 0x3f];
  switch(ch)
  {
  case 0:
    if(n & 0x40)
    {
      SQR1CTRL = mus.sqr_inst[0] & 0xffc0;
      SQR1FREQ = (mus.freq[0]) | FREQ_HOLD | FREQ_RESET;
    }
    else
      SQR1FREQ = (mus.freq[0]) | FREQ_HOLD;
    break;

  case 1:
    if(n & 0x40)
    {
      SQR2CTRL = mus.sqr_inst[1] & 0xffc0;
      SQR2FREQ = (mus.freq[1] + 1) | FREQ_HOLD | FREQ_RESET;
    }
    else
      SQR2FREQ = (mus.freq[1] + 1) | FREQ_HOLD;
    break;

  case 2:
    TRIFREQ = mus.freq[2] | FREQ_HOLD;
    if(n & 0x40)
      TRILENVOL = TRILENVOL_100;
    break;

  case 3:
    mus.freq[ch] = mus.insts[n & 0x3f] & 0x00ff;
    if(n & 0x40)
    {
      NOISECTRL = mus.insts[n & 0x3f] & 0xff00;
      NOISEFREQ = mus.freq[3] | FREQ_HOLD | FREQ_RESET;
    }
    else
      NOISEFREQ = mus.freq[3] | FREQ_HOLD;
    break;
  }
}


/* music_kill_note() *******************
   Release the note on a given channel.
*/
void music_kill_note(unsigned int ch)
{
  mus.freq_delta[ch] = 0;
  switch(ch)
  {
  case 0:
    SQR1CTRL = 0;
    SQR1FREQ = FREQ_HOLD | FREQ_RESET;
    break;
  case 1:
    SQR2CTRL = 0;
    SQR2FREQ = FREQ_HOLD | FREQ_RESET;
    break;
  case 2:
    TRILENVOL = 0;
    break;
  case 3:
    NOISECTRL = 0;
    NOISEFREQ = FREQ_HOLD | FREQ_RESET;
    break;
  default:
    gbmxr_voices[ch - 4].volume = 0;
    gbmxr_voices[ch - 4].sample_rate = 0;
  }
}



/* music_new_pat() *********************
   Read and decode order table entries until the next play_pat.
*/
static void music_new_pat(unsigned int ch)
{
  while(1)
  {
    unsigned int c = mus.orders[mus.order_no[ch]];

    if((c & 0xf000) == 0)  /* goto */
    {
      mus.order_no[ch] = c & 0x0fff;

      /* FIXME!
         Current behavior: when triangle channel jumps, reset the
         row number.
         Change this when order command "reset row_n" is added */
      if(ch == 2)
        mus.row_n = 0;
    }
    else if(c & 0x8000)    /* play pattern */
    {
#if 0
/*
      PALRAM[0] = RGB((mus.order_no[ch] & 0x07) << 2,
                      (c & 0x07) << 2,
                      0);
*/
#endif
      mus.patptr[ch] = mus.patptrs[c & 0x01ff];
      mus.base_note[ch] = (c >> 9) & 0x3f;
      mus.order_no[ch]++;
                      
      break;
    }
  }
}


/* music_tick() ************************
   Update envelopes per tick.
*/
static void music_tick(void)
{
  unsigned int ch;


  if(mus.freq_delta[0])
    SQR1FREQ = (mus.freq[0] += mus.freq_delta[0]) | FREQ_HOLD;
  if(mus.freq_delta[1])
    SQR2FREQ = (mus.freq[1] += mus.freq_delta[1]) | FREQ_HOLD;
  if(mus.freq_delta[2])
    TRIFREQ = (mus.freq[2] += mus.freq_delta[2]) | FREQ_HOLD;

  for(ch = 4; ch < mus.n_ch; ch++)
  {
    gbmxr_voices[ch - 4].sample_rate += mus.freq_delta[ch] * SAMPLE_TIME;
  }
}


/* music_new_row() *********************
   Read and decode the current row and set all variables.
*/
static void music_new_row(void)
{
  unsigned int ch;

  for(ch = 0; ch < mus.n_ch; ch++)
  {
    --mus.note_rows_left[ch];


    /* if it's time for the next command, start executing commands */
    while(mus.note_rows_left[ch] == 0)
    {
      unsigned int n = mus.patdata[mus.patptr[ch]++];
      if(n & 0x80)  /* note */
      {
        music_note(ch, n);
        mus.note_rows_left[ch] = 1;
      }
      else if(n & 0x40)  /* instrument switch */
      {
        music_set_instrument(ch, n & 0x3f);
      }
      else if(n & 0x20)
      {
        unsigned int effect = n & 0x0f;
	unsigned int effdata = (n & 0x10)
	                       ? mus.patdata[mus.patptr[ch]++]
	                       : 0;
        switch(effect)
        {
        case 1:   /* 1xy: frequency increase */
          mus.freq_delta[ch] = effdata;
          break;
        case 2:   /* 2xy: frequency decrease */
          mus.freq_delta[ch] = -effdata;
          break;
        case 12:  /* cxy: volume */
          mus.vol[ch] = effdata;
          break;
        case 13:  /* d00: new pattern */
          music_new_pat(ch);
          break;
        case 15:
          if(effdata == 0)  /* f00: reset speed to song's default */
          {
            mus.tempo[0] = mus.patdata[4];
            mus.tempo[1] = mus.patdata[5];
          }
          else if(effdata <= 16)  /* f0x/f10: set speed to x */
            mus.tempo[1] = mus.tempo[0] = effdata;
          else  /* fxy: set speed to x on even rows, y on odd rows */
          {
            mus.tempo[0] = (effdata >> 4) & 0x0f;
            mus.tempo[1] = effdata & 0x0f;
            if(mus.tempo[1] == 0)  /* treat f70 as f77 */
              mus.tempo[1] = mus.tempo[0];
          }
          break;
        }
      }
      else
      {
        if(n & 0x10)
          music_kill_note(ch);
        mus.note_rows_left[ch] = (n & 0x0f) + 1;
      }
    }
  }
  mus.row_ticks_left = mus.tempo[mus.row_n & 1];
  mus.row_n++;
  music_beat = mus.row_n >> 2;
}


void music_play(void)
{
  if(music_is_paused)
    return;

  mus.row_ticks_left--;
  if(mus.row_ticks_left > 0)
    music_tick();
  else
    music_new_row();
}


const void *start_song(const unsigned char *data)
{
  unsigned int ch;
  const unsigned char *userdata;

  mus.patdata = data;

  mus.tempo[0] = mus.patdata[4];
  mus.tempo[1] = mus.patdata[5];

  mus.sqr_inst[1] = mus.sqr_inst[0] = 0xf700;

  mus.n_ch = mus.patdata[6];
  if(mus.n_ch == 0)
    mus.n_ch = 4;
  if(mus.n_ch > 4 + N_GBMXR_VOICES)
    mus.n_ch = 4 + N_GBMXR_VOICES;

  mus.insts = (unsigned short *)
              (mus.patdata + mus.patdata[8] + 256 * mus.patdata[9]);
  mus.ch3_samples = mus.patdata + mus.patdata[10] + 256 * mus.patdata[11];
  mus.orders = (unsigned short *)
               (mus.patdata + mus.patdata[12] + 256 * mus.patdata[13]);
  mus.patptrs = (unsigned short *)
                (mus.patdata + mus.patdata[14] + 256 * mus.patdata[15]);
  userdata = mus.patdata + mus.patdata[16] + 256 * mus.patdata[17];

  mus.row_n = 0;
  mus.row_ticks_left = 1;

  for(ch = 0; ch < mus.n_ch; ch++)
  {
    mus.order_no[ch] = ch;
    mus.note_rows_left[ch] = 1;
    music_new_pat(ch);
  }
  for(ch = 0; ch < 4 + N_GBMXR_VOICES; ch++)
  {
    music_kill_note(ch);
  }
  for(ch = 0; ch < 4; ch++)
    mus.sample_inst[ch] = 0;
  music_new_row();
  music_is_paused = 0;
  return userdata;
}


void music_pause(int is)
{
  if(is)
  {
    unsigned int i = 4 + N_GBMXR_VOICES - 1;

    for(i = 0; i < 4 + N_GBMXR_VOICES; i++)
      music_kill_note(i);
    music_is_paused = 1;
  }
  else
  {
    music_is_paused = 0;
  }

}

static void set_bias(void)
{
  asm volatile("mov r2, #2; lsl r2, #8; swi 0x19" ::: "r0", "r1", "r2", "r3");
  SETSNDRES(1);
}

void init_sound(const GBFS_FILE *gbfs)
{
  TIMER[0].control = 0;
  //turn on sound circuit
  SNDSTAT = SNDSTAT_ENABLE;
  //62% volume, enable sound 3 to left and right
  DMGSNDCTRL = DMGSNDCTRL_LVOL(4) | DMGSNDCTRL_RVOL(4) |
               DMGSNDCTRL_LSQR1 | DMGSNDCTRL_RSQR1 | 
               DMGSNDCTRL_LSQR2 | DMGSNDCTRL_RSQR2 | 
               DMGSNDCTRL_LTRI | DMGSNDCTRL_RTRI |
               DMGSNDCTRL_LNOISE | DMGSNDCTRL_RNOISE;
  DSOUNDCTRL = 0x0b0e;
  TIMER[0].count = 0x10000 - SAMPLE_TIME;
  TIMER[0].control = TIMER_16MHZ | TIMER_ENABLE;

  TRICTRL = TRICTRL_2X32 | TRICTRL_BANK(0) | TRICTRL_ENABLE;
  TRILENVOL = 0;
  TRIFREQ = 1046 | FREQ_RESET | FREQ_HOLD;
  SQR1SWEEP = SQR1SWEEP_OFF;
  set_bias();

  mus.dsound_samples = gbfs;
}




/* DEMO ******************************************/

#if DEMO
MULTIBOOT
#include "chr.h"
static const GBFS_FILE *songs_gbfs, *samples_gbfs;
void isr(void);
#define SCR_MAP 16
ISR saved_isr;

#define NUM_PIECES 8

static const char pieces[NUM_PIECES][32] =
{
  "p8d.8gbm",
  "p8demo.8gbm",
  "cthulu.8gbm",
  "idltd.8gbm",
  "kalinka.8gbm",
  "_todwin.8gbm",
  "korobeyniki.8gbm",
  "_gameover.8gbm"
};


static void wait4vbl(void)
{
  asm volatile("mov r2, #0; swi 0x05" ::: "r0", "r1", "r2", "r3");
}


/* upcvt_4bit() ************************
   Convert a 1-bit font to GBA 4-bit format.
*/
void upcvt_4bit(void *dst, const u8 *src, size_t len)
{
  u32 *out = dst;

  for(; len > 0; len--)
  {
    u32 dst_bits = 0;
    u32 src_bits = *src++;
    u32 x;

    for(x = 0; x < 8; x++)
    {
      dst_bits <<= 4;
      dst_bits |= src_bits & 1;
      src_bits >>= 1;
    }
    *out++ = dst_bits;
  }
}


/* itoa_lpad() *************************
   Convert n into a string of len characters, left-padded with
   lpad_chr.  buf points to a buffer of at least (len + 1) chars.
*/
void itoa_lpad(char *buf, size_t len, unsigned int n, int lpad_chr)
{
  buf[len] = 0;
  if(n == 0)
    n = 0;

  /* extract each digit */
  do {
    /* assumes compiler can optimize n % 10 and n / 10 into one op
       also assumes digits appear consecutively in 0123456789 order
       (this is true of ascii) */
    buf[--len] = (n % 10) + '0';
    n = n / 10;
  } while(n && len);

  /* left pad */
  while(len)
    buf[--len] = lpad_chr;
}


/* ntclrline() *************************
   Clear a line of the map.
*/
void ntclrline(u32 nt, u32 y, u32 c)
{
  u32 x;
  u32 *here = (u32 *)(MAP[nt][y]);
  
  /* duplicate c into the high word */
  c &= 0x0000ffff;
  c |= c << 16;

  /* clear the line 2 characters at a time */
  for(x = 16; x > 0; x--)
    *here++ = c;
}


/* nttextout() *************************
   Write the given text to a nametable.
*/
void nttextout(u32 nt, u32 x, u32 y, u32 c, const char *str)
{
  while(*str)
    MAP[nt][y][x++] = (*str++ & 0xff) | c;
}


/* ntcls() *****************************
   Clear the screen.
*/
void ntcls(u32 nt, u32 c)
{
  u32 x;
  u32 *here = (u32 *)(MAP[nt][0]);
  
  /* duplicate c into the high word */
  c &= 0x0000ffff;
  c |= c << 16;

  /* clear the screen 2 characters at a time */
  for(x = 512; x > 0; x--)
    *here++ = c;
}


/* init_all() **************************
   Set up the display.

   VRAM:
     0000  font (16-bit, 256 tiles)
     2000  map (32x32 tiles)

*/
void init_video(void)
{
  LCDMODE = 0 | LCDMODE_BLANK;
  BLENDMODE = 0;
  BGCTRL[0] = BGCTRL_PAT(0) | BGCTRL_16C | BGCTRL_NAME(SCR_MAP) |
              BGCTRL_H32 | BGCTRL_V32;
  BGCTRL[1] = 0;
  BGCTRL[2] = 0;
  BGCTRL[3] = 0;
  BGSCROLL[0].x = 0;
  BGSCROLL[0].y = 0;
  PALRAM[0] = RGB(31, 31, 31);
  PALRAM[1] = RGB(0, 0, 0);

  /* load pattern table */
  upcvt_4bit(VRAM, text_chr, text_chr_len);

  ntcls(SCR_MAP, ' ');

  /* clear OAM and set up a single sprite image */
  {
    const struct OAM_SPRITE hidden = {160, 20, 0, 0};
    u32 x;
    const u32 arrow[8] =
    {
      0x00000000,
      0x00010000,
      0x00100000,
      0x01111111,
      0x00100000,
      0x00010000,
      0x00000000,
      0x00000000
    };
    u32 *spr_vram = (u32 *)0x06010000;

    for(x = 0; x < 128; x++)
      OAM[x] = hidden;
    for(x = 0; x < 8; x++)
      spr_vram[x] = arrow[x];
  }

  wait4vbl();
  LCDMODE = 0 | LCDMODE_BG0 | LCDMODE_SPR;
}


#define ROM_BANKSWITCH (volatile u16 *)(0x096B592E)
#define WRITE_LOC_1 (volatile u16 *)(0x987654*2+0x8000000)
#define WRITE_LOC_2 (volatile u16 *)(0x012345*2+0x8000000)
#define WRITE_LOC_3 (volatile u16 *)(0x007654*2+0x8000000)
#define WRITE_LOC_4 (volatile u16 *)(0x765400*2+0x8000000)
#define WRITE_LOC_5 (volatile u16 *)(0x013450*2+0x8000000)

void reset_gba(void)
{
  unsigned int i;

  INTENABLE = 0;

  /* reset cart bankswitching */
  for(i=0;i<1;i++) *WRITE_LOC_1=0x5354;
  for(i=0;i<500;i++) *WRITE_LOC_2=0x1234;
  for(i=0;i<1;i++) *WRITE_LOC_2=0x5354;
  for(i=0;i<500;i++) *WRITE_LOC_2=0x5678;
  for(i=0;i<1;i++) *WRITE_LOC_1=0x5354;
  for(i=0;i<1;i++) *WRITE_LOC_2=0x5354;
  for(i=0;i<1;i++) *WRITE_LOC_4=0x5678;
  for(i=0;i<1;i++) *WRITE_LOC_5=0x1234;
  for(i=0;i<500;i++) *WRITE_LOC_2=0xabcd;
  for(i=0;i<1;i++) *WRITE_LOC_1=0x5354;   
  *ROM_BANKSWITCH=0;

  /* reset GBA */
  *(u16 *)0x03007ffa = 0;  /* reset to ROM (= 0) rather than RAM (= 1) */
  asm volatile(
    "mov r0, #0xfc  \n"  /* clear everything other than RAM */
    "swi 0x01       \n"
    "swi 0x00       \n"
    ::: "r0", "r1", "r2", "r3");
}


/* swi_3() *****************************
   Call swi 3 to stop the GBA.  Placed in a function wrapper to
   protect it against overzealous compiler optimization.
*/
static void swi_3(void)
{
  asm volatile("swi 0x03");
}

void halt_gba(void)
{
  /* Disable sound.  OMITTED */

  /* Disable video (force blank). */
  wait4vbl();
  LCDMODE = LCDMODE_BLANK;

  /* Disable all interrupts but the joypad. */
  INTENABLE = 0;
  INTMASK = INT_JOY;
  JOYINT = JOY_SELECT | JOY_START | JOYINT_ALL;
  INTENABLE = 1;

  /* Call swi 0x03 ("Stop") */
  swi_3();

  /* Afterward, software must reinitialize video mode, interrupts,
     and sound.  Turn on at least the basic vblank interrupt handler. */
  INTMASK = INT_VBLANK;
}



const void *demo_start_song(const GBFS_FILE *dat, const char *name)
{
  const void *song_data = gbfs_get_obj(dat, name, NULL);

  ntclrline(SCR_MAP, 5, ' ');
  if(!song_data)
  {
    nttextout(SCR_MAP, 1, 5, 0, name);
    return NULL;
  }
  nttextout(SCR_MAP, 1, 5, 0, name);
  return start_song(song_data);
}

int main(void)
{
  unsigned int lj = 0x3ff;
  int cur_piece = 1;
  const unsigned char *user_data;
  char buf[16];

  /* set the ISR */
  INTENABLE = 0;
  saved_isr = GET_MASTER_ISR();
  SET_MASTER_ISR(isr);
  /* turn on interrupt sources */
  LCDSTAT = LCDSTAT_VBLINT;
  /* turn on interrupt controller */
  INTMASK = INT_VBLANK;
  INTENABLE = 1;

  songs_gbfs = find_first_gbfs_file(find_first_gbfs_file);
  if(!songs_gbfs)
  {
    LCDMODE = 4;
    PALRAM[0] = RGB(31, 0, 0);
    while(1) { wait4vbl(); }
  }

  samples_gbfs = skip_gbfs_file(songs_gbfs);

  init_sound(samples_gbfs);

  NOISECTRL = SQR_VOL(15) | 0x100;
  NOISEFREQ = 4 | NOISEFREQ_OCT(4) | FREQ_RESET | FREQ_HOLD;
#if 0
  SQR1CTRL = SQR_VOL(15) | 0x0040;
  SQR1FREQ = FREQ_HOLD | FREQ_RESET | 0x0601;
  SQR2CTRL = SQR_VOL(15) | 0x0080;
  SQR2FREQ = FREQ_HOLD | FREQ_RESET | 0x0700;
#endif

  init_video();
  nttextout(SCR_MAP, 1, 1, 0, "Tri Engine Demo");
  nttextout(SCR_MAP, 1, 2, 0, "� 2003 Damian Yerrick");
  nttextout(SCR_MAP, 1, 4, 0, "Press Start");
  /* wait for vbl then A release */
  while(!(JOY & JOY_START)) wait4vbl();
  /* wait for vbl then A press */
  while((JOY & JOY_START)) wait4vbl();

  nttextout(SCR_MAP, 1, 4, 0, "Now playing");
  nttextout(SCR_MAP, 1, 6, 0, "(press A to switch)");
  nttextout(SCR_MAP, 1, 7, 0, "(press A+B+Sel+Start to exit)");
  nttextout(SCR_MAP, 1, 12, 0, "Mixer time at       Hz");
  itoa_lpad(buf, 5, fracumul(MIXBUF_SIZE << 16, 0x3bba3d), ' ');
  nttextout(SCR_MAP, 15, 12, 0, buf);

  user_data = demo_start_song(songs_gbfs, pieces[cur_piece]);
  while(1)
  {
    unsigned int j = JOY ^ 0x3ff;

    wait4vbl();
    dsound_vblank();

#if 0
    if(last_beat != music_beat)
    {
      if(mana)
        mana -= (mana + 7) >> 3;
      if(last_beat < music_beat)
        user_off = 0;
      if(--beatcd == 0)
      {
        beatcd = user_data[user_off++]);
        if(beatcd)
        {
          mana++;
        }
        else
        {
          loop++;
          beatcd = user_data[user_off++]);
        }
    }
#endif

    if(j & JOY_B)
    {
      music_play();
      music_play();
      music_play();
    }
    if(j & ~lj & JOY_A)
    {
      cur_piece++;
      if(cur_piece >= NUM_PIECES)
        cur_piece = 0;
      user_data = demo_start_song(songs_gbfs, pieces[cur_piece]);
    }
    if(j & ~lj & (JOY_LEFT | JOY_RIGHT))
    {
      const SAMPLE_8GBS *s = gbfs_get_obj(mus.dsound_samples, "move.8gbs", NULL);
      play_8gbs(3, s, 0x10000);
    }
    if(j & ~lj & JOY_L)
    {
      const SAMPLE_8GBS *s = gbfs_get_obj(mus.dsound_samples, "spin.8gbs", NULL);
      play_8gbs(3, s, 0x10000);
    }
    if(j & ~lj & JOY_DOWN)
    {
      const SAMPLE_8GBS *s = gbfs_get_obj(mus.dsound_samples, "01kick.8gbs", NULL);
      play_8gbs(3, s, 0x10000);
    }
    if(j & ~lj & JOY_SELECT)
    {
#if 1
      halt_gba();
      LCDMODE = 0 | LCDMODE_BG0;
      lj = 0x3ff;
#else
      const SAMPLE_8GBS *s = gbfs_get_obj(mus.dsound_samples, "square.8gbs", NULL);
      play_8gbs(3, s, 0x10000);
#endif
    }
    if(j & ~lj & JOY_R)
    {
      const SAMPLE_8GBS *s = gbfs_get_obj(mus.dsound_samples, "pow.8gbs", NULL);
      play_8gbs(3, s, 0x10000);
    }

    if((j & (JOY_A | JOY_B | JOY_SELECT | JOY_START)) ==
            (JOY_A | JOY_B | JOY_SELECT | JOY_START))
      reset_gba();

    lj = j;

    while(LCD_Y >= 160) ;  /* wait for frame start */
    while(LCD_Y < 80) ;
    PALRAM[0] = RGB(24,28,31);
    music_play();
    PALRAM[0] = RGB(31,31,31);

    while(LCD_Y < 100) ;
    PALRAM[0] = RGB(31,28,24);
    mixer();
    PALRAM[0] = RGB(31,31,31);
    j = LCD_Y;
    itoa_lpad(buf, 3, j - 100, ' ');
    nttextout(SCR_MAP, 1, 13, 0, buf);
  }
}

#endif
