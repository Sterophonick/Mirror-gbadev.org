/*
splash4.c
Convert an 8-bit bitmap into a format suitable for GBA mode 4
By Damian Yerrick


Copyright 2001 Damian Yerrick

Permission is hereby granted, free of charge, to any person obtaining
a copy of this software and associated documentation files (the
"Software"), to deal in the Software without restriction, including
without limitation the rights to use, copy, modify, merge, publish,
distribute, sublicense, and/or sell copies of the Software, and to
permit persons to whom the Software is furnished to do so, subject to
the following conditions:

The above copyright notice and this permission notice shall be
included in all copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND,
EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES
OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND
NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS
BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN
AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF
OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS
IN THE SOFTWARE.

*/
#include <stdio.h>
#define USE_CONSOLE
#include <allegro.h>
#ifndef ALLEGRO_CONSOLE_OK
#error This platform does not support compiling Allegro console applications.
#endif

#include <allegro.h>
#include <stdio.h>
#include <math.h>  /* for sqrt() */
#include <string.h>  /* for strerror() */


/* fputu16() ***************************
   Write a 16-bit integer in little-endian format to a file.
*/
inline void fputu16(unsigned int n, FILE *fp)
{
    fputc(n & 0xff, fp);
    fputc(n >> 8, fp);
}


/* rgb2gba() ******************************
   Convert an RGB color in (0..63) to a gamma-corrected GBA color in (0..31).
*/
unsigned int rgb2gba(const RGB *color)
{
  return ((int)sqrt(color->b * 16) << 10)
         | ((int)sqrt(color->g * 16) << 5)
         | ((int)sqrt(color->r * 16));
}


int main(int argc, char **argv)
{
  BITMAP *bmp;
  PALETTE pal;
  char newpath[PATH_MAX];
  FILE *fout;
  int xx, yy;

  install_allegro(SYSTEM_NONE, &errno, atexit);
  set_color_depth(8);

  if(argc < 2)
    {
      allegro_message("usage: splash4 foo.bmp\n");
      return 1;
    }

  bmp = load_bitmap(argv[1], pal);
  if(!bmp)
    {
      allegro_message("Could not load %s: %s\n",
		      argv[1], strerror(errno));
      return 1;
    }

  replace_extension(newpath, argv[1], "spl4", PATH_MAX);
  fout = fopen(newpath, "wb");
  if(!fout)
    {
      destroy_bitmap(bmp);
      allegro_message("Could not open %s for writing: %s\n",
		      newpath, strerror(errno));
      return 1;
    }

  /* Write palette */
  for(yy = 0; yy < 256; yy++)
    fputu16(rgb2gba(&(pal[yy])), fout);

  /* Write pattable */
  for(yy = 0; yy < bmp->h; yy++)
    for(xx = 0; xx < bmp->w; xx++)
      fputc(getpixel(bmp, xx, yy), fout);
  fclose(fout);
  destroy_bitmap(bmp);
  return 0;
}
