#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>

typedef short s16;
typedef unsigned short u16;
typedef unsigned long u32;

/* The format of a 'fmt ' chunk */
typedef struct WAVE_FMT
{
  u16 format;
  u16 channels;
  u32 sample_rate;
  u32 bytes_sec;
  u16 frame_size;
  u16 bits_sample;
} WAVE_FMT;


typedef struct WAVE_SRC
{
  WAVE_FMT fmt;
  FILE *fp;
  size_t chunk_left;
  int cur_chn;
} WAVE_SRC;
 

unsigned int fgetu16(FILE *fp)
{
  unsigned char a = fgetc(fp);
  unsigned char b = fgetc(fp);

  return a | (b << 8);
}

unsigned long fgetu32(FILE *fp)
{
  unsigned char a = fgetc(fp);
  unsigned char b = fgetc(fp);
  unsigned char c = fgetc(fp);
  unsigned char d = fgetc(fp);

  return a | (b << 8) | (c << 16) | (d << 24);
}


void fputu32(unsigned long a, FILE *fp)
{
  fputc(a      , fp);
  fputc(a >>  8, fp);
  fputc(a >> 16, fp);
  fputc(a >> 24, fp);
}


void fputu16(unsigned int a, FILE *fp)
{
  fputc(a      , fp);
  fputc(a >>  8, fp);
}


/* get_fmt() ***************************
   Reads a format chunk from a wav file.
   Returns 0 for success or negative for failure.
*/
int get_fmt(WAVE_FMT *format, FILE *fp)
{
  unsigned int fmt_len = fgetu32(fp);

  if(fmt_len < 16)
    return -3;

  format->format = fgetu16(fp);
  format->channels = fgetu16(fp);
  format->sample_rate = fgetu32(fp);
  format->bytes_sec = fgetu32(fp);
  format->frame_size = fgetu16(fp);
  format->bits_sample = fgetu16(fp);

  fseek(fp, fmt_len - 16, SEEK_CUR);
  return 0;
}


void close_wave_src(WAVE_SRC *wav)
{
  fclose(wav->fp);
  wav->fp = 0;
}

/* open_wave_src() *********************
   Opens a RIFF WAVE (.wav) file for reading through
   get_next_wav_sample().  Returns the following error codes:
     -1  could not open; details are in errno
     -2  bad signature
     -3  bad format metadata or no format metadata before sample data
     -4  no sample data
*/
int open_wave_src(WAVE_SRC *wav, const char *filename)
{
  char buf[256];
  int got_fmt = 0;

  /* open the file */
  wav->fp = fopen(filename, "rb");
  if(!wav->fp)
    return -1;

  /* read the header */
  if(fread(buf, 1, 12, wav->fp) < 12)
  {
    close_wave_src(wav);
    return -2;
  }

  /* check for RIFF/WAVE signature */
  if(memcmp("RIFF", buf, 4) || memcmp("WAVE", buf + 8, 4))
  {
    close_wave_src(wav);
    return -2;
  }

  /* parse chunks */
  while(fread(buf, 4, 1, wav->fp))
  {
    if(!memcmp("fmt ", buf, 4))
    {
      int errc = get_fmt(&(wav->fmt), wav->fp);
      if(errc < 0)
      {
        close_wave_src(wav);
        return -3;
      }
      got_fmt = 1;
    }
    else if(!memcmp("data", buf, 4))
    {
      if(!got_fmt)
      {
        close_wave_src(wav);
        return -3;
      }

      wav->chunk_left = fgetu32(wav->fp);
      if(wav->chunk_left == 0)
      {
        close_wave_src(wav);
        return -4;
      }

      /* at this point, we have success */
      return 0;
    }
    else /* skip unrecognized chunk type */
    {
      unsigned long chunk_size = fgetu32(wav->fp);

      fseek(wav->fp, chunk_size, SEEK_CUR);
    }
  }
  /* we've come to the end of all the chunks and found no data */
  close_wave_src(wav);
  return -4;
}


/* get_next_wav_sample() ***************
   Get the next sample from a wav file.
*/
int get_next_wav_sample(WAVE_SRC *wav)
{
  int cur_sample = 0;
  int i;

  for(i = 0; i < wav->fmt.bits_sample; i += 8)
  {
    int c = fgetc(wav->fp);

    cur_sample >>= 8;
    cur_sample |= (c & 0xff) << 8;
    if(--wav->chunk_left == 0)
      return 0;
  }

  if(wav->fmt.bits_sample <= 8) /* handle unsigned samples */
    cur_sample -= 32768;
  cur_sample = (s16)cur_sample; /* sign-extend */

  if(++wav->cur_chn >= wav->fmt.channels)
    wav->cur_chn = 0;

  return cur_sample;
}



const char helptext[] =
"Converts a wav file to 8gbs format.\n"
"syntax: wav28gbs src.wav dst.8gbs [volume [looplen]]\n"
"  (src_wav and dest_wav are paths to wav files)\n"
"example: wav28gbs kick.wav kick.8gbs 32 32\n";


int main(int argc, char **argv)
{
  FILE *outfp;
  int errc;
  unsigned long len;
  int vol = 64;
  int loop_len = 0;
  WAVE_SRC wav;

  if(argc < 3)
    {
      fputs(helptext, stderr);
      return 1;
    }

  if(argc >= 4)
  {
    vol = strtol(argv[3], NULL, 0);
  }

  if(argc >= 5)
  {
    loop_len = strtol(argv[4], NULL, 0);
  }

  errc = open_wave_src(&wav, argv[1]);
  if(errc < 0)
  {
    switch(errc)
    {
    case -1:  /* could not open file */
      fputs("readwav could not open", stderr);
      perror(argv[1]);
      return 1;

    case -2:  /* no RIFF/WAVE header */
      fputs(argv[1], stderr);
      fputs("doesn't have a RIFF/WAVE header\n", stderr);
      return 1;

    case -3:  /* no format info */
      fputs(argv[1], stderr);
      fputs("doesn't have format information\n", stderr);
      return 1;
      
    case -4:  /* no data */
      fputs(argv[1], stderr);
      fputs("doesn't have sample data\n", stderr);
      return 1;
    }
  }

  /* create destination wav file */
  len = wav.chunk_left / wav.fmt.frame_size;

  outfp = fopen(argv[2], "wb");
  if(!outfp)
  {
    fputs("could not open ", stderr);
    perror(argv[2]);
    close_wave_src(&wav);
    return 1;
  }

  /* write the header */
  fputu16(16, outfp);  /* size of header */
  fputu16(wav.fmt.sample_rate, outfp);
  fputu32(len, outfp);
  fputu32(loop_len, outfp);
  fputc(vol, outfp);
  fputc(0, outfp);fputc(0, outfp);fputc(0, outfp);

  while(wav.chunk_left > 0)
  {
    int s = get_next_wav_sample(&wav);
    fputc(s >> 8, outfp);
  }

  close_wave_src(&wav);
  fclose(outfp);
  return 0;
}
