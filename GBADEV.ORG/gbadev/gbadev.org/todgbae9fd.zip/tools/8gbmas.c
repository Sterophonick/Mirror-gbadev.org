#include <stdio.h>
#include <stdlib.h>
#include <ctype.h>
#include <string.h>

enum {
  STATE_NONE = 0,
  STATE_SPEED,
  STATE_CHANNELS,
  STATE_INST,
  STATE_CH3INST,
  STATE_ORDER,
  STATE_PAT,
  STATE_USER
};


unsigned char speed[2];
unsigned char n_channels = 4;

unsigned short insts[64];
unsigned char ch3insts[64][16];
unsigned short orderlabels[512];
unsigned short order[4096];
unsigned short patptrs[512];
unsigned char patdata[65536];
unsigned char userdata[65536];

unsigned int n_insts = 0;
unsigned int n_ch3insts = 0;
unsigned int n_order = 0;
unsigned short n_patptrs = 0;
unsigned int n_patdata = 0;
unsigned int n_userdata = 0;



int state = 0;


/* fputi16() ***************************
   write a little-endian short to a file
*/
void fputi16(unsigned int in, FILE *fp)
{
  fputc(in & 0xff, fp);
  fputc((in >> 8) & 0xff, fp);
}


/* fgetc2() ****************************
   fgetc, but skip from # to end of line
*/
int fgetc2(FILE *fp)
{
  int c = fgetc(fp);

  if(c != '#')
    return c;

  while(c != '\n')
  {
    c = fgetc(fp);
    if(c == EOF)
      return c;
  }
  return c;
}
  

char *getword(char *buf, int maxlen, FILE *fp)
{
  int len = 0;
  int c = fgetc2(fp);
  
  /* skip to first nonspace character */
  while(c != EOF && isspace(c))
  {
    c = fgetc2(fp);
  }
  if(c == EOF)
    return NULL;

  while(c != EOF && !isspace(c) && len < maxlen - 1)
  {
    buf[len++] = c;
    c = fgetc2(fp);
  }

  buf[len] = 0;
  return buf;
}




void parse_channels(const char *s)
{
  n_channels = strtol(s, NULL, 0);
}

void parse_speed(const char *s)
{
  const char *comma = strchr(s, ',');
  int first, second;

  if(comma)
    comma++;  /* advance past comma to start of second */
  else
    comma = s;  /* first and second are the same */

  first = strtol(s, NULL, 0);
  second = strtol(comma, NULL, 0);
  printf("speed %d,%d\n", first, second);
  speed[0] = first;
  speed[1] = second;
}

void parse_inst(const char *s)
{
  int vol = 0, direction = 0, envspeed = 0, lobeit = 0;
  char *rest;

  vol = strtol(s, &rest, 0);
  if(*rest == '-')
  {
    envspeed = strtol(rest + 1, &rest, 0);
    direction = 0;
  }
  else if(*rest == '+')
  {
    envspeed = strtol(rest + 1, &rest, 0);
    direction = 1;
  }
  if(*rest == ',')
    lobeit = strtol(rest+1, &rest, 0);

  insts[n_insts] =
    ((vol & 0x0f) << 12) |
    (direction << 11) |
    ((envspeed & 0x07) << 8) |
    (lobeit & 0xff);
  printf("instrument %2d = 0x%04x\n", n_insts, insts[n_insts]);
  n_insts++;
}


static const char hexdigits[] = "0123456789abcdef";

void parse_ch3inst(const char *s)
{
  int i;

  for(i = 0; i < 32; i += 2)
  {
    int c = s[i];
    int val = 0;

    if(!c)
    {
      fprintf(stderr, "wave %s too short (needs %d more samples)\n",
              s, 32 - i);
      return;
    }
    else if(isxdigit(c))
    {
      val = (strchr(hexdigits, tolower(c)) - hexdigits) << 4;
    }
    else
    {
      fprintf(stderr, "invalid hex digit '%c'\n", c);
      return;
    }
    c = s[i + 1];
    if(!c)
    {
      fprintf(stderr, "wave %s too short (needs %d more samples)\n",
              s, 31 - i);
      return;
    }
    else if(isxdigit(c))
    {
      val |= (strchr(hexdigits, tolower(c)) - hexdigits);
    }
    else
    {
      fprintf(stderr, "invalid hex digit '%c'\n", c);
      return;
    }

    ch3insts[n_ch3insts][i >> 1] = val;
  }
  if(s[32])
  {
    fprintf(stderr, "wave %s is too long\n", s);
    return;
  }

  printf("ch3 instrument %2d = ", n_ch3insts);
  for(i = 0; i < 16; i++)
    printf("%02x", (int)ch3insts[n_ch3insts][i]);
  putchar('\n');

  n_ch3insts++;
}


void parse_order(const char *s)
{
  if(isdigit(s[0]))
  {
    int label = strtol(s, NULL, 0);

    orderlabels[label] = n_order;
  }
  else if(s[0] == 'g')  /* goto */
  {
    int label = strtol(s + 1, NULL, 0);

    order[n_order++] = label;
  }
  else if(s[0] == 'p')  /* play */
  {
    char *rest;
    int label = strtol(s + 1, &rest, 0);
    int transpose = 0;

    if(*rest == '+')
    {
      transpose = strtol(rest + 1, &rest, 0);
    }
    else if(*rest == '-')
    {
      transpose = -strtol(rest + 1, &rest, 0);
    }

    order[n_order++] = label | 0x8000 | ((transpose & 0x3f) << 9);
  }
}


/* get_noteno() ************************
   Translate a human-readable string into a note number.
*/
unsigned int get_noteno(const char *s)
{
  /* FIXME: need to recognize real note numbers */
  return strtol(s, NULL, 0);
}


/* get_octave_noteno() *****************
   Given an offset (C = 0, D = 2, G = 7, etc), read legato and octave
   and then construct the note command.
*/
unsigned int get_octave_noteno(const char *s, const char **endp, int offset)
{
  unsigned int retrig = 0xc0;
  unsigned int noteno;

  if(s[0] == '+' || s[0] == 's')  /* sharp */
  {
    offset++;
    s++;
  }
  else if(s[0] == '-' || s[0] == 'b')  /* flat */
  {
    offset--;
    s++;
  }
  if(s[0] == 'l')
  {
    retrig = 0x80;
    s++;
  }
  noteno = ((strtol(s, (char **)&s, 0) * 12 + offset) & 0x3f) | retrig;
  if(endp)
    *endp = s;

  return noteno;
}


void parse_pat(const char *s)
{
/*
   patline => patinst | patno
   patinst => hold | rest | setinst | note | end
       end => "end"
      hold => "h" holdtime
      rest => "r" holdtime
  holdtime => int(1..16)
   setinst => "i" instid
    instid => int(0..63)
      note => "n" legato noteid
    legato => "" | "l"
    noteid => notenumber     #or note name once I learn that
notenumber => int(0..63)
*/
  if(isdigit(*s))
  {
    int patid = strtol(s, NULL, 0);

    if(n_patptrs < patid + 1)
      n_patptrs = patid + 1;
    patptrs[patid] = n_patdata;
  }
  else if(!strcmp(s, "end"))
  {
    patdata[n_patdata++] = 0x2d;
  }
  else if(*s == 'h')  /* hold note */
  {
    unsigned int holdtime = strtol(s + 1, NULL, 0);

    patdata[n_patdata++] = (holdtime - 1) & 0x0f;
  }
  else if(*s == 'r')  /* rest */
  {
    unsigned int holdtime = strtol(s + 1, NULL, 0);

    patdata[n_patdata++] = ((holdtime - 1) & 0x0f) | 0x10;
  }
  else if(*s == 'i')  /* instrument */
  {
    unsigned int instno = strtol(s + 1, NULL, 0);

    patdata[n_patdata++] = (instno & 0x3f) | 0x40;
  }
  else if(*s == 'n')  /* note */
  {
    unsigned int retrig = 0xc0;

    if(s[1] == 'l')
    {
      retrig = 0x80;
      s++;
    }

    patdata[n_patdata++] = retrig | strtol(s + 1, NULL, 0);
  }
  else if(*s == 'c')  /* note C */
  {
    patdata[n_patdata++] = get_octave_noteno(s + 1, &s, 0);
  }
  else if(*s == 'd')  /* note D */
  {
    patdata[n_patdata++] = get_octave_noteno(s + 1, &s, 2);
  }
  else if(*s == 'e')  /* note E */
  {
    patdata[n_patdata++] = get_octave_noteno(s + 1, &s, 4);
  }
  else if(*s == 'f')  /* note F */
  {
    patdata[n_patdata++] = get_octave_noteno(s + 1, &s, 5);
  }
  else if(*s == 'g')  /* note G */
  {
    patdata[n_patdata++] = get_octave_noteno(s + 1, &s, 7);
  }
  else if(*s == 'a')  /* note A */
  {
    patdata[n_patdata++] = get_octave_noteno(s + 1, &s, 9);
  }
  else if(*s == 'b')  /* note B */
  {
    patdata[n_patdata++] = get_octave_noteno(s + 1, &s, 11);
  }
  else if(*s == 'x')  /* effect */
  {
    unsigned int fx = 0;
    unsigned int i;

    for(i = 1; i <= 3; i++)
    {
      int c = s[i];

      if(!c)
      {
        fprintf(stderr, "effect %s too short (needs %d more samples)\n",
                s, 32 - i);
        return;
      }
      else if(isxdigit(c))
      {
        fx = (fx << 4) | (strchr(hexdigits, tolower(c)) - hexdigits);
      }
      else
      {
        fprintf(stderr, "invalid hex digit '%c'\n", c);
        return;
      }
    } while(--i);

    if(fx & 0xff)
    {
      patdata[n_patdata++] = 0x30 | (fx >> 8);
      patdata[n_patdata++] = fx & 0xff;
    }
    else
    {
      patdata[n_patdata++] = 0x20 | (fx >> 8);
    }
  }
}


void parse_user(const char *s)
{
  int c1 = s[0];
  int c2 = s[1];

  if(!c2)
  {
    c2 = c1;
    c1 = '0';
  }

  if(isxdigit(c1) && isxdigit(c2))
  {
    int val = ((strchr(hexdigits, tolower(c1)) - hexdigits) << 4) |
               (strchr(hexdigits, tolower(c2)) - hexdigits);
    userdata[n_userdata++] = val;
  }
  else
  {
    fprintf(stderr, "invalid hex byte '%c%c'\n", c1, c2);
  }
}


int main(int argc, char **argv)
{
  FILE *infile;
  char buf[256];

  if(argc < 3)
  {
    fputs("8gbm assembler by Damian Yerrick\n"
          "usage: 8gbmas foo.8gbm.in foo.8gbm\n", stdout);
    return 1;
  }

  infile = fopen(argv[1], "rt");
  if(!infile)
  {
    fputs("8gbmas could not open ", stderr);
    perror(argv[1]);
    return 1;
  }
  while(getword(buf, sizeof(buf), infile))
  {
    if(!strcmp(buf, "speed"))
    {
      state = STATE_SPEED;
    }
    else if(!strcmp(buf, "channels"))
    {
      state = STATE_CHANNELS;
    }
    else if(!strcmp(buf, "instruments"))
    {
      state = STATE_INST;
    }
    else if(!strcmp(buf, "ch3instruments"))
    {
      state = STATE_CH3INST;
    }
    else if(!strcmp(buf, "orders"))
    {
      state = STATE_ORDER;
    }
    else if(!strcmp(buf, "patterns"))
    {
      state = STATE_PAT;
    }
    else if(!strcmp(buf, "user"))
    {
      state = STATE_USER;
    }
    else switch(state)
    {
    case STATE_SPEED:
      parse_speed(buf);
      break;
    case STATE_CHANNELS:
      parse_channels(buf);
      break;
    case STATE_INST:
      parse_inst(buf);
      break;
    case STATE_CH3INST:
      parse_ch3inst(buf);
      break;
    case STATE_ORDER:
      parse_order(buf);
      break;
    case STATE_PAT:
      parse_pat(buf);
      break;
    case STATE_USER:
      parse_user(buf);
      break;
    }
  }
  fclose(infile);

  /* generate output */

  n_insts = (n_insts + 1) & -2;  /* round up to nearest 32-bit word */
  {
    FILE *outfile = fopen(argv[2], "wb");
    size_t inst_off = 20;
    size_t ch3inst_off = inst_off + n_insts * 2;
    size_t order_off = ch3inst_off + n_ch3insts * 16;
    size_t patptrs_off = order_off + n_order * 2;
    size_t patdata_off = patptrs_off + n_patptrs * 2;
    size_t userdata_off = patdata_off + n_patdata;
    unsigned int i;

    if(!outfile)
    {
      fputs("8gbmas could not open ", stderr);
      perror(argv[2]);
      return 1;
    }

    fputi16(20, outfile);     /* header size */
    fputi16(0x0101, outfile); /* format version 1.0.1 */
    fputc(speed[0], outfile);
    fputc(speed[1], outfile);
    fputc(n_channels, outfile);
    fputc(0, outfile); /* reserved */
    fputi16(inst_off, outfile);
    fputi16(ch3inst_off, outfile);  /* pointer to ch3 instruments */
    fputi16(order_off, outfile);
    fputi16(patptrs_off, outfile);
    fputi16(userdata_off, outfile);
    fputi16(0, outfile);

    for(i = 0; i < n_insts; i++)
    {
      fputi16(insts[i], outfile);
    }

    for(i = 0; i < n_ch3insts; i++)
    {
      fwrite(ch3insts[i], 16, 1, outfile);
    }

    for(i = 0; i < n_order; i++)
    {
      if(order[i] < 4096)
        fputi16(orderlabels[order[i]], outfile);
      else
        fputi16(order[i], outfile);
    }

    for(i = 0; i < n_patptrs; i++)
    {
      fputi16(patptrs[i] + patdata_off, outfile);
    }

    fwrite(patdata, 1, n_patdata, outfile);
    fwrite(userdata, 1, n_userdata, outfile);
    fclose(outfile);
  }

  return 0;
}
