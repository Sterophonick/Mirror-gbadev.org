#include <allegro.h>
#include <stdio.h>
#include <math.h>



/* rgb2gba() ******************************
   Convert an RGB color in (0..63) to a gamma-corrected GBA color in (0..31).
*/
unsigned int rgb2gba(const RGB *color)
{
  return ((int)sqrt(color->b * 16) << 10)
         | ((int)sqrt(color->g * 16) << 5)
         | ((int)sqrt(color->r * 16));
}

int main(int argc, char **argv)
{
  BITMAP *bmp;
  PALETTE pal;
  int n_colors;
  int i;

  if(argc != 3)
  {
    fputs("getpal: writes gamma-corrected gba hexes for the\n"
          "first n colors of a bitmap's palette\n"
          "usage: getpal foo.bmp 256\n", stderr);
    return 1;
  }
  install_allegro(SYSTEM_NONE, &errno, atexit);

  n_colors = atoi(argv[2]);
  bmp = load_bitmap(argv[1], pal);
  if(!bmp)
  {
    fputs("getpal: Could not load ", stderr);
    perror(argv[1]);
    return 1;
  }

  for(i = 0; i < n_colors - 1; i++)
  {
    printf("0x%04x,", rgb2gba(&(pal[i])));
    if((i & 0x0f) == 0x0f)
      putchar('\n');
  }
  printf("0x%04x\n", rgb2gba(&(pal[i])));

  destroy_bitmap(bmp);

  return 0;
}
