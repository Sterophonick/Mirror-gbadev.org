/*
bmp2bg.c
Pack a 240x160 pixel 4-bit bitmap into a format suitable for display
in the GBA's tiled modes (0, 1)

Copyright 2001 Damian Yerrick

Permission is hereby granted, free of charge, to any person obtaining
a copy of this software and associated documentation files (the
"Software"), to deal in the Software without restriction, including
without limitation the rights to use, copy, modify, merge, publish,
distribute, sublicense, and/or sell copies of the Software, and to
permit persons to whom the Software is furnished to do so, subject to
the following conditions:

The above copyright notice and this permission notice shall be
included in all copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND,
EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES
OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND
NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS
BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN
AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF
OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS
IN THE SOFTWARE.

*/

/*
1. Read a 240x160 image in 16 colors.
2. Gamma-correct and write the palette immediately.
*/

#include <allegro.h>
#include <stdio.h>
#include <math.h>  /* for sqrt() */
#include <string.h>  /* for strerror() */



/* fputu16() ***************************
   Write a 16-bit integer in little-endian format to a file.
*/
void fputu16(unsigned int n, FILE *fp)
{
    fputc(n & 0xff, fp);
    fputc(n >> 8, fp);
}


#if 0

unsigned char this_tile[600][8][8];
/* I'm not really using is_match() or find_match() this time because
   they didn't help much. */
unsigned int is_match(unsigned int i, unsigned int n,
		      unsigned int x_xor, unsigned int y_xor)
{
  unsigned int x, y;

  for(y = 0; y < 8; y++)
    for(x = 0; x < 8; x++)
      if(this_tile[i][y ^ y_xor][x ^ x_xor] != this_tile[n][y][x])
	return 0;  /* bail on the first mismatch */
  return 1;
}


/* find_match() ************************
   Find the first match for tile n.  If there is no match, return n.
*/
unsigned int find_match(unsigned int n)
{
  unsigned int i = 0;

  if(n == 0)
    return 0;

  for(i = 0; i < n; i++)
    {
      if(is_match(i, n, 0, 0))  /* straight matches */
	return i;
      else if(is_match(i, n, 7, 0))  /* h-flipped matches */
	return i | 0x0200;
      else if(is_match(i, n, 0, 7))  /* v-flipped matches */
	return i | 0x0400;
      else if(is_match(i, n, 7, 7))  /* upside-down matches */
	return i | 0x0600;
    }
  return n;  /* this is a new tile */
}
#endif


/* rgb2gba() ******************************
   Convert an RGB color in (0..63) to a gamma-corrected GBA color in (0..31).
*/
unsigned int rgb2gba(const RGB *color)
{
  return ((int)sqrt(color->b * 16) << 10)
         | ((int)sqrt(color->g * 16) << 5)
         | ((int)sqrt(color->r * 16));
}


int main(int argc, char **argv)
{
  BITMAP *bmp;
  PALETTE pal;
  char newpath[PATH_MAX];
  FILE *fout;
  int xx, yy;

  install_allegro(SYSTEM_NONE, &errno, atexit);
  set_color_depth(8);

  if(argc < 2)
    {
      allegro_message("usage: todbg foo.bmp\n");
      return 1;
    }

  bmp = load_bitmap(argv[1], pal);
  if(!bmp)
    {
      allegro_message("Could not load %s: %s\n",
		      argv[1], strerror(errno));
      return 1;
    }

  replace_extension(newpath, argv[1], "todbg", PATH_MAX);
  fout = fopen(newpath, "wb");
  if(!fout)
    {
      destroy_bitmap(bmp);
      allegro_message("Could not open %s for writing: %s\n",
		      newpath, strerror(errno));
      return 1;
    }

  /* Write palette */
  for(yy = 0; yy < 16; yy++)
    fputu16(rgb2gba(&(pal[yy])), fout);

  /* Write pattable */
  for(yy = 0; yy < 160; yy += 8)
    for(xx = 0; xx < 240; xx += 8)
      {
	unsigned int x, y;

	for(y = 0; y < 8; y++)
	  for(x = 0; x < 8; x += 2)
	    {
	      unsigned int b = getpixel(bmp, x + xx, y + yy);
	      b |= getpixel(bmp, x + xx + 1, y + yy) << 4;
	      fputc(b, fout);
	    }
      }
  fclose(fout);
  destroy_bitmap(bmp);
  return 0;
}
END_OF_MAIN();
