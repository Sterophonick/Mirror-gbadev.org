/*
mktunnel.c
Make tunnel wallpapers for TOD
By Damian Yerrick


Copyright 2001 Damian Yerrick

Permission is hereby granted, free of charge, to any person obtaining
a copy of this software and associated documentation files (the
"Software"), to deal in the Software without restriction, including
without limitation the rights to use, copy, modify, merge, publish,
distribute, sublicense, and/or sell copies of the Software, and to
permit persons to whom the Software is furnished to do so, subject to
the following conditions:

The above copyright notice and this permission notice shall be
included in all copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND,
EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES
OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND
NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS
BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN
AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF
OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS
IN THE SOFTWARE.

*/

#include <allegro.h>

PALETTE pal;

void build_pal(unsigned int phase)
{
  const unsigned char pal_phase[16] =
  {
    32, 44, 54, 60, 63, 60, 54, 44, 32, 20, 10, 4, 1, 4, 10, 20
  };
  unsigned int i;

  for(i = 0; i < 16; i++)
  {
    pal[i].r = pal_phase[(phase + i) & 0x0f];
    pal[i].g = pal_phase[(phase + 4 + i) & 0x0f];
    pal[i].b = 63;

/*
    rectfill(bmp, i * 20, 232, i * 20 + 19, 239, i);
*/
  }
  for(; i < 256; i++)
    pal[i].r = pal[i].g = pal[i].b = 0;
}

void aliased_kaleido(BITMAP *bmp)
{
  int x, y;

  for(y = 0; y < 160; y++)
  {
    int ysam = (y - 80);

    for(x = 0; x < 240; x++)
    {
      int xsam = (x - 120);
      int d2 = xsam*xsam + ysam*ysam;
      int z = d2 ? fdiv(itofix(1), fsqrt(itofix(d2))) : 0;
      int c = z & 0x0f;

      putpixel(bmp, x, y, c);
    }
  }
}


void draw_tunnel(BITMAP *bmp)
{
  int x, y;

  for(y = 0; y < 160; y++)
  {
    int ysam = (y - 80);

    for(x = 0; x < 240; x++)
    {
      int xsam = (x - 120);
      int d2 = xsam*xsam + ysam*ysam;
      int z = d2 ? fixdiv(itofix(1024), fixsqrt(itofix(d2))) : 0;
#if 0
      int c = ((z + (rand() & 0x3fff)) >> 14) & 0x0f;
#else
      int c = ((z + (rand() & 0x1f00)
                  + (((x ^ y) & 1) << 13) )
               >> 14) & 0x0f;
#endif
      putpixel(bmp, x, y, c);
    }
  }
}


void draw_sunburst(BITMAP *bmp)
{
  int x, y;

  for(y = 0; y < 160; y++)
  {
    int ysam = (y - 80);

    for(x = 0; x < 240; x++)
    {
      int xsam = (x - 120);
      int d2 = xsam*xsam + ysam*ysam;
      int z = d2
              ? (fixdiv(itofix(1024), fixsqrt(itofix(d2)))
                 + (fatan2(xsam, ysam) >> 2))
              : 0;
#if 0
      int c = ((z + (rand() & 0x3fff)) >> 14) & 0x0f;
#else
      int c = ((z + (rand() & 0x1f00)
                  + (((x ^ y) & 1) << 13) )
               >> 14) & 0x0f;
#endif

      putpixel(bmp, x, y, c);
    }
  }
}


void cycle_colors(void)
{
  int t = 0;
  while(!keypressed())
  {
    build_pal(++t);
    set_palette(pal);
    rest(100);
  }
  readkey();
}


int main(void)
{
  install_allegro(SYSTEM_NONE, &errno, atexit);
  {
    BITMAP *bmp = create_bitmap(240, 160);

    if(bmp)
    {
      build_pal(0);

      aliased_kaleido(bmp);
      save_bmp("../bkgnds/kaleid3.bmp", bmp, pal);

      draw_tunnel(bmp);
      save_bmp("../bkgnds/kaleid1.bmp", bmp, pal);

      draw_sunburst(bmp);
      save_bmp("../bkgnds/kaleid2.bmp", bmp, pal);
    }
    else
    {
      allegro_message("Could not save the bitmaps.");
      return 1;
    }
  }
  return 0;
}
END_OF_MAIN();
