/*

Tetanus On Drugs
data.c : some data tables
Copyright (C) 2002  Damian Yerrick

This program is free software; you can redistribute it and/or
modify it under the terms of the GNU General Public License
as published by the Free Software Foundation; either version 2
of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to 
  Free Software Foundation, Inc., 59 Temple Place - Suite 330,
  Boston, MA  02111-1307, USA.
GNU licenses can be viewed online at http://www.gnu.org/copyleft/

Visit http://www.pineight.com/ for more information.

*/



/*
The object file for data also includes other objects that have
lots of data and little code.
*/

#include "tod.h"
#include <stdlib.h>
#include "hgrcos.inc"


/* hgrcos() ****************************
   Given theta = 0 to 1 << 24, find cos(theta) * 65536.
   Uses a 4,096-point table.
*/
int hgrcos(int theta)
{
  char neg = 0;
  int y;

  /* rescale theta to 0-4095 */
  theta = ((theta + 0x800) & 0xfff000) >> 12;

  /* handle quadrants 3 and 4: cos(theta) = cos(2*Pi - theta) */
  if(theta > 2048)
    theta = 4096 - theta;

  /* handle quadrant 2: cos(theta) = -cos(Pi - theta) */
  if(theta > 1024)
  {
    theta = 2048 - theta;
    neg = 1;
  }

  y = hirescostable[theta];
  if(y == 0 && theta < 512)
    y = 65536;

  return neg ? -y : y;
}


int hgrsin(int theta)
{
  return hgrcos(theta + 0xc00000);
}

int hgrtan(int theta)
{
  return (hgrcos(theta + 0xc00000) << 14) / (hgrcos(theta) >> 2);
}

const u8 rijndaelS[256] = {
  99,124,119,123,242,107,111,197, 48,  1,103, 43,254,215,171,118, 
 202,130,201,125,250, 89, 71,240,173,212,162,175,156,164,114,192, 
 183,253,147, 38, 54, 63,247,204, 52,165,229,241,113,216, 49, 21, 
   4,199, 35,195, 24,150,  5,154,  7, 18,128,226,235, 39,178,117, 
   9,131, 44, 26, 27,110, 90,160, 82, 59,214,179, 41,227, 47,132, 
  83,209,  0,237, 32,252,177, 91,106,203,190, 57, 74, 76, 88,207, 
 208,239,170,251, 67, 77, 51,133, 69,249,  2,127, 80, 60,159,168, 
  81,163, 64,143,146,157, 56,245,188,182,218, 33, 16,255,243,210, 
 205, 12, 19,236, 95,151, 68, 23,196,167,126, 61,100, 93, 25,115, 
  96,129, 79,220, 34, 42,144,136, 70,238,184, 20,222, 94, 11,219, 
 224, 50, 58, 10, 73,  6, 36, 92,194,211,172, 98,145,149,228,121, 
 231,200, 55,109,141,213, 78,169,108, 86,244,234,101,122,174,  8, 
 186,120, 37, 46, 28,166,180,198,232,221,116, 31, 75,189,139,138, 
 112, 62,181,102, 72,  3,246, 14, 97, 53, 87,185,134,193, 29,158, 
 225,248,152, 17,105,217,142,148,155, 30,135,233,206, 85, 40,223, 
 140,161,137, 13,191,230, 66,104, 65,153, 45, 15,176, 84,187, 22
};

const u8 p8logo_map[10][10] =
{
  { 8, 9, 9, 9, 9, 9, 9, 9, 9,10},
  {11, 2, 2, 2,26,27, 2, 2, 2,12},
  {11, 2, 2,26,43,42,27, 2, 2,12},
  {11, 2,26,43,28,29,42,27, 2,12},
  {11, 2,42,30,45,44,31,43, 2,12},
  {11, 2, 6,46,27, 7,47,29, 2,12},
  {11, 2,44,29,42,43,28,45, 2,12},
  {11, 2, 2,44,29,28,45, 2, 2,12},
  {11, 2, 2, 2,44,45, 2, 2, 2,12},
  {13,14,14,14,14,14,14,14,14,15}
};

const u32 p8logo_pal_align = 0;
const u16 p8logo_pal[16] =
{
  RGB(31, 0,31), RGB( 0, 0, 0), RGB(15,15,15), RGB(21,21,21),
  RGB(26,26,26), RGB(31,31,31), RGB(27,22,17), RGB(29,26,23),
  RGB(31,29,27), RGB(14,20,24), RGB(20,24,27), RGB(26,28,29),
  RGB( 0, 0, 0), RGB( 0, 0, 0), RGB( 0, 0, 0), RGB( 0, 0, 0)
};
