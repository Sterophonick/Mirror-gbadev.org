Ed_smash.bin

This is Edmund Wong's first ever demo!
Use the arrow keys to move around.
Use other buttons to shoot in a direction.
Press start to release enemies after starting the game.
Hope you guys like it!
This demo is not for profit or commercial use.
It is just to demonstrate my programming skills.
Graphics and sounds are taken from various sources.

E-Mail me feedback at: ginsingtome@hotmail.com

Thanks!
Edmund Wong