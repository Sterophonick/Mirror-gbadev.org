The Nomad II: Trapped
The Open GameBoy Games Project
http://opengbgames.sourceforge.net/

Thank you for trying this demo. If you enjoy it, please come to our site
in June to download the full version. The full version will include all 40
levels and source code.

This demo is released specifically for the "GBAX.COM 2003" Contest.
(http://www.gbaemu.com/)

HOW TO PLAY: See the enclosed 'manual.pdf' for the instruction manual.

Some Key Features

* Works perfectly on the Game Boy Advance.
* Works great in most Game Boy Advance Emulators
* 40 Levels in the final version.
* 14 Techno Dance Beats
* Stereo Sound
* Two Main Game Play Modes
* Save Progress In Story Mode
* 20 Save Slots
* Random Level Generation In Chaos Mode
* Overall High Scores
* Each Player Gets a Personal High Score List.
* 5 Different Tile Sets - Change the entire feel of the game from one
level to another.
* LZ77 Compressed Bitmaps
* 512-Colors During Game Play
* Alpha Blended Menus
* Main Menu times out to a demo.

Thank you for playing. Enjoy
--Alex Markley
alex@milent.com

