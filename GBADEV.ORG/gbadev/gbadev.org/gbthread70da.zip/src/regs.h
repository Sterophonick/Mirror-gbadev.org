////////////////////////////////////////////////////////////////////////////////
//
// regs.h
// gameboy advance hardware register definitions
//
// by DarkPhantom
//
////////////////////////////////////////////////////////////////////////////////
#ifndef _regs_h_
#define _regs_h_
////////////////////////////////////////////////////////////////////////////////
#include "typedef.h"
////////////////////////////////////////////////////////////////////////////////
#define REG_INTERUPT   *(volatile u32*)0x03007FFC
#define REG_DISPCNT    *(volatile u32*)0x04000000

#define REG_DISPSTAT   *(volatile u16*)0x04000004
#define REG_VCOUNT     *(volatile u16*)0x04000006

#define REG_BG0CNT     *(volatile u16*)0x04000008
#define REG_BG1CNT     *(volatile u16*)0x0400000A
#define REG_BG2CNT     *(volatile u16*)0x0400000C
#define REG_BG3CNT     *(volatile u16*)0x0400000E

#define REG_SOUNDCNT_L *(volatile u16*)0x04000080
#define REG_SOUNDCNT_H *(volatile u16*)0x04000082
#define REG_SOUNDCNT_X *(volatile u32*)0x04000084
#define REG_FIFO_A     *(volatile u32*)0x040000A0
#define REG_FIFO_B     *(volatile u32*)0x040000A4

#define REG_DM0SAD     *(volatile u32*)0x040000B0
#define REG_DM0DAD     *(volatile u32*)0x040000B4
#define REG_DM0CNT     *(volatile u32*)0x040000B8

#define REG_DM1SAD     *(volatile u32*)0x040000BC
#define REG_DM1DAD     *(volatile u32*)0x040000C0
#define REG_DM1CNT     *(volatile u32*)0x040000C4
#define REG_DM2SAD     *(volatile u32*)0x040000C8
#define REG_DM2DAD     *(volatile u32*)0x040000CC
#define REG_DM2CNT     *(volatile u32*)0x040000D0
#define REG_DM3SAD     *(volatile u32*)0x040000D4
#define REG_DM3DAD     *(volatile u32*)0x040000D8
#define REG_DM3CNT     *(volatile u32*)0x040000DC

#define REG_TM0D       *(volatile u16*)0x04000100
#define REG_TM0CNT     *(volatile u16*)0x04000102
#define REG_TM1D       *(volatile u16*)0x04000104
#define REG_TM1CNT     *(volatile u16*)0x04000106
#define REG_TM2D       *(volatile u16*)0x04000108
#define REG_TM2CNT     *(volatile u16*)0x0400010A
#define REG_TM3D       *(volatile u16*)0x0400010C
#define REG_TM3CNT     *(volatile u16*)0x0400010E

#define REG_IE         *(volatile u16*)0x04000200
#define REG_IF         *(volatile u16*)0x04000202
#define REG_IME        *(volatile u16*)0x04000208
////////////////////////////////////////////////////////////////////////////////
#endif
////////////////////////////////////////////////////////////////////////////////
