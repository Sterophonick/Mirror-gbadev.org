////////////////////////////////////////////////////////////////////////////////
//
// thread.h
// header file for thread.c
//
// by DarkPhantom
//
////////////////////////////////////////////////////////////////////////////////
#ifndef _thread_h_
#define _thread_h_

#include "typedef.h"
////////////////////////////////////////////////////////////////////////////////
#define USE_DEFAULT_STACK 0
////////////////////////////////////////////////////////////////////////////////
typedef struct tagThread
{

    //
    // the format of this structure may seem odd but it is designed to
    // facilitate the fastest possible swap-in/swap-out procedure.
    // the exact reasoning behind the ordering of the registers in this
    // structure is explained in, and should be selfevident from, the
    // assembly code in dispatch.s
    //

    // general purpose registers that are saved first
    word r4, r5, r6, r7, r8, r9, r10, r11;

    // registers pushed by the BIOS that are poped and then saved
    // note: pc is really the value or lr_irq but is restored to pc
    // upon the interrupt return
    word r0, r1, r2, r3, r12, pc;

    word cpsr; // value from spsr_irq
    word spsr_svc, lr_svc, sp_svc; // svc mode banked registers
    word lr, sp; // system mode banked registers

    // queued list functions
    struct tagThread *next;
    struct tagThread *prev;
    
    // dynamic stack pointers
    void *stack;
    void *svcstack;

} thread;
////////////////////////////////////////////////////////////////////////////////
thread* createthread(void *entry, int stack, int svcstack, word wparam);
void killthread(thread *t);
void resumethread(thread *t);
void suspendthread(thread *t);
////////////////////////////////////////////////////////////////////////////////
void enqueuethread(thread **queue, thread *t);
void appendqueue(thread **dest, thread **src);
void dequeuethread(thread *t);
////////////////////////////////////////////////////////////////////////////////
void disable_irq(void);
void enable_irq(void);
void killself(void);
////////////////////////////////////////////////////////////////////////////////
#endif
////////////////////////////////////////////////////////////////////////////////
