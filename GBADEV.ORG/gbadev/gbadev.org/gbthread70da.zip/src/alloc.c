////////////////////////////////////////////////////////////////////////////////
//
// alloc.c
// memory allocation routines by DarkPhantom
//
// I know there are already memory allocation routines available for GBA,
// I just wanted to write my own since dynamic memory allocation is really a
// prerequisite for threading.
//
// Here is the gist of this module: The unused memory of both iwram and ewram
// (the "heap") could be dynamically allocated at runtime. For this, we
// basically turn both heaps into one large "block" of unallocated memory.
// When an allocation is requested, the block is split into two leaving
// one block of the request size that is marked as allocated and another
// empty block that can be further allocated. Many blocks of many different
// sizes can be made in this way. When memory starts to get deallocated,
// holes of unallocated memory may popup between blocks of allocated
// memory. To fight this, we turn the unallocated blocks into a
// linked list so that unused areas of memory can be quickly searched for
// one that fits the requested size. This is one of many possible methods
// of dymanicly allocating from the heap.
//
// this module as a whole has data coupling and is very cohesive since as
// a whole it exhibits informational cohesion and each "method" has
// functional cohesion. as such it is a model of ideal software engineering
// but is (generously) only reasonable optimized. I'm sure I could come
// up with a better design if I thought about it and I could really
// improve it just by recoding entirely in assembly. in addition, I
// have not thourougly tested this module so they're are probobly
// still some faults in it. therefore, like the thread demo, I suggest
// you just use this module as a learning experiance and not as a library
// because I don't think its good enough for that but, I'm probobly my own
// worst critic. ;)
//
// one thing to note about these functions: They are NOT thread safe.
// that means that steps must be taken to ensure that no two or more threads
// are attempting any allocation/deallocation operations at the same time
// or else the heap and allocated blocks WILL become corrupted!
////////////////////////////////////////////////////////////////////////////////
#include "alloc.h"
////////////////////////////////////////////////////////////////////////////////
extern char __iheap_start, __iheap_end; // values from the linkscript
extern char __eheap_start, __eheap_end;
////////////////////////////////////////////////////////////////////////////////
blockheader *iwram_head; // first unallocated block
blockheader *iwram_foot; // last unallocated block

blockheader *ewram_head;
blockheader *ewram_foot;
////////////////////////////////////////////////////////////////////////////////
void add_block_to_list(blockheader *block)
{
    blockheader **head;
    blockheader **foot;
    
    // simple linked list functionality, add a block to a list
    
    // figure out which list the node should go on
    // and get pointers to the pointers of the head and foot of that list
    if( (((word)block) & 0xfff00000) == IWRAM )
    {
        head = &iwram_head;
        foot = &iwram_foot;
    }
    else if ( (((word)block) & 0xfff00000) == EWRAM )
    {
        head = &ewram_head;
        foot = &ewram_foot;
    }
    else return; // doesn't go on either list
    
    // add this new node to the end of the list
    if(*foot == NULL) // empty list! make the node the head and foot
    {
        *head = block;
        *foot = block;
        block -> next = block -> prev = NULL;
    }
    else // add node to the end of the list
    {
        (*foot) -> next = block; // old end of list points here
        block -> prev = *foot;
        block -> next = NULL; // end of the list
        *foot = block;
    }
    
}
////////////////////////////////////////////////////////////////////////////////
void remove_block_from_list(blockheader *block)
{

    // simple linked list functionality, remove a block from the list

    if(!block) return; // NULL pointer

    // remove the node from the list by redirecting other nodes
    if( block -> prev ) block -> prev -> next = block -> next;
    if( block -> next ) block -> next -> prev = block -> prev;

    // if this node is either the head or the foot of the list, it must
    // surrender that title to another node or to NULL (if it is the last
    // remaining node) as it is being removed from the list.
    if( iwram_head == block ) iwram_head = block -> next;
    if( iwram_foot == block ) iwram_foot = block -> prev;
    if( ewram_head == block ) ewram_head = block -> next;
    if( ewram_foot == block ) ewram_foot = block -> prev;

}
////////////////////////////////////////////////////////////////////////////////
void init_heap(void)
{
    blockheader *header;
    blockfooter *footer;
    int i, size;
    
    // simple function to setup the heap in both iwram and ewram
    // when the system is first powerd on or when both
    // heaps could simply be completely reinitalized to clear
    // all allocated memory.
    
    // this function just setups both heaps to be two large unallocated
    // blocks that consume the size of their respecitive heaps.
    // this is acomplished by putting an unallocted block header
    // at the begginning of the heap and then the corresponding
    // footer at the end.
    
    // the code is the same for both ewram and iwram so do it twice in a loop
    for ( i = 0 ; i < 2 ; i++ )
    {
        
        // position pointer to header and calculate block size
        if( i == 0 ) // first do ewram
        {
            header = (blockheader *)&__eheap_start;
            size = &__eheap_end - &__eheap_start;
        }
        else // do iwram second
        {
            header = (blockheader *)&__iheap_start;
            size = &__iheap_end - &__iheap_start;
        }
    
        // initialize the header
        header -> allocated = 0x00000000; // not allocated
        header -> size = size; // size of block
        header -> prev = NULL; // head and foot of single item list
        header -> next = NULL;
    
        // calculate position the footer
        footer = (blockfooter *)( ((word)header)
               + header -> size - sizeof(blockfooter) );
      
        // setup the footer
        footer -> allocated = 0x00000000;
        footer -> size = size;
        
        // lastly, position pointer to first and last free block
        // which are both the block that was just made since it
        // is the only one right now
        if( i == 0 )
             ewram_foot = ewram_head = header;
        else
             iwram_foot = iwram_head = header;
            
    }
    
}
////////////////////////////////////////////////////////////////////////////////
void* allocate_block(int size, int ram)
{
    blockheader *current;
    blockheader *newblock;
    blockfooter *footer;
    const int minsize = sizeof(blockheader)
                      + sizeof(blockfooter);

    // function attempts to find an empty block of the requested size
    // in either the ewram or iwram heaps. if a suitable unallocated
    // block is found then it is marked as allocated and returned.
    // otherwise, no block bigenough is available and NULL is returned.
    
    // the linked list stored within the unallocated blocks is to
    // reduce the time a search for a suitable unallocated block
    // takes as it will effectively eliminate the need to search
    // any of the allocated blocks since they can be skipped entirely.
    
    // the size of the block must be enough for the data and for the
    // header and footer so the requested size is incremented to
    // reflect the total size of the block. Also, since the
    // the block will need to contain two pointers if the block get
    // unallocated, there is a minimum size involved
    size += minsize - (sizeof(void*) << 1); // header size less two pointers
    if(size < minsize) size = minsize;
    
    // determine which block of memory we are working with
    if(ram == IWRAM)
        current = iwram_head;
    else if(ram == EWRAM)
        current = ewram_head;
    else
        return NULL; // invalid request
        
    // if the pointer is NULL, then nothing is available at all
    if(!current) return NULL;
    
    // transverse the linked list to find a suitable unallocated block.
    for ( ; ; )
    {
        if(current -> size >= size ) // this block big enough?
            break; // yes!
        else
            current = current -> next; // try next block
            
        if( current == NULL ) return NULL; // nothing was big enough
    }
    
    // current is the first block in the list that fits the requirements.
    // it is more effective to "right" justify the the new allocated block
    // relative to the space that is left over from the block that is
    // being cut to do the allocation. unfortunately, the remaining
    // unallocated memory in the block must be atleast the minimum size or
    // it will be unable to hold the pointers of the list, if there is a
    // tiny little bit of extra space just add that onto the allocation.
    if( current -> size - size < minsize)
    {
        size = current -> size; // use the entire block
    
        // if the entire block is to be used then it must be entirely
        // removed from the linked list of unallocated blocks.
        remove_block_from_list( current );

        // current is now the new block
        newblock = current;
    }
    else // enough memory left for another allocation
    {
        // position the new node right justified
        newblock = (blockheader *) ( ((word)current)
                 + current -> size - size);
                 
        // position the new footer of the current block
        // this is adjacent to the header of the new block because
        // all the blocks are stored back to back.
        footer = (blockfooter *) ( ((word)newblock)
               - sizeof(blockfooter));
               
        // update the header and footer of the current block
        current -> size = current -> size - size; // reduce size
        footer -> allocated = 0x00000000; // unallocated
        footer -> size = current -> size; // copy size
    }
    
    // whew! almost done. just fill in the header and footer for the new
    // block and everything is all good.
    newblock -> allocated = 0xffffffff; // allocated
    newblock -> size = size; // stored size of block
    
    // position footer and fill the fields
    footer = (blockfooter *) ( ((word)newblock)
           + size - sizeof(blockfooter));
    footer -> size = size;
    footer -> allocated = 0xffffffff;
    
    // return pointer to usable memory in block
    return (void*)(((word)newblock) + (sizeof(int) << 1));
}
////////////////////////////////////////////////////////////////////////////////
void deallocate_block(void *allocated_block)
{
    blockheader *header;
    blockheader *nextheader;
    blockfooter *footer;
    blockfooter *prevfooter;
    void *heap_start, *heap_end;
    
    // deallocate the specified block, if there are free blocks on either
    // side, combine this block with them.
    
    // again, figure out if this is in IWRAM or EWRAM
    if( (((word)allocated_block) & 0xfff00000) == IWRAM )
    {
        heap_start = &__iheap_start;
        heap_end = &__iheap_end;
    }
    else if ( (((word)allocated_block) & 0xfff00000) == EWRAM)
    {
        heap_start = &__eheap_start;
        heap_end = &__eheap_end;
    }
    else return;
    
    // first things first, when the pointer to the allocated memory
    // was first issued, it was offset from the start of the header
    // to the first byte of usable memory. change the offset back
    // to the beginning of the header
    header = (blockheader *)( ((word)allocated_block)
           - (sizeof(int) << 1));
    footer = (blockfooter *)( ((word)header)
           + header -> size - sizeof(blockfooter));
           
    // validate that this is an allocated block, if the pointer to
    // deallocate wasn't an allocatable block, then it can't be deallocated
    // this is done by checking the values of the header and then using
    // checking the footer as well. If the block was invalid then the
    // "size" from the header won't land the footer pointer on a valid footer
    if(header -> allocated != 0xffffffff || footer -> allocated != 0xffffffff)
        return; // not an allocated block
    if(header -> size != footer -> size)
        return; // not an allocated block


    // when freeing a block, the two surrounding blocks must be check
    // to see if they are also free blocks. In order to make sure that
    // any section of free memory is represented by one block, instead
    // of multipul smaller blocks, adjacent free blocks get combined
    // here as soon as they appear.
    if( (((word)header) + header -> size) < ((word)heap_end) )
    {
        // position the header of the next block
        nextheader = (blockheader *) ( ((word)footer)
                   + sizeof(blockfooter));

        // if this block is unallocated, remove it from the list and
        // reposition the footer of the new block
        if(nextheader -> allocated == 0x00000000)
        {
            remove_block_from_list(nextheader); // remove from list

            // move footer to end of block on the right side
            footer = (blockfooter *) ( ((word)nextheader)
                   + nextheader -> size
                   - sizeof(blockfooter) );
        }
    }

    // do the samething for the preceeding block
    if( ((void *)header) > heap_start) // not first block in heap, right?
    {
        // position the footer of the previous block
        prevfooter = (blockfooter *) ( ((word)header)
                   - sizeof(blockfooter) );
               
        // if the previous block is unallocated, move the start of the new
        // block to the where the start of the previous block is
        if(prevfooter -> allocated == 0x00000000)
        {
            header = (blockheader *)( ((word)header)
                   - prevfooter -> size );
            
            // remove this free block from the list because it is being
            // combined with another block to form a new block which will
            // be added to the list of free blocks
            remove_block_from_list( header );
        }
    }
    
    // the header and footer are positioned, just mark it as unallocated,
    // calculate the size and add it to the list of unallocated blocks
    header -> allocated = footer -> allocated = NULL;
    header -> size = ( ((word)footer) - ((word)header)
                   + sizeof(blockfooter) );
    footer -> size = header -> size;
    add_block_to_list(header);
}
////////////////////////////////////////////////////////////////////////////////
