////////////////////////////////////////////////////////////////////////////////
//
// thread.c
//
// thread management functions
//
// by DarkPhantom
//
////////////////////////////////////////////////////////////////////////////////
#include "regs.h"
#include "alloc.h"
#include "thread.h"
#include "dispatch.h"
////////////////////////////////////////////////////////////////////////////////
thread* createthread(void *entry, int stack, int svcstack, word wparam)
{
    thread *newthread;

    // fairly straight forward function, allocate memory for a thread
    // and configure the initial state of it so that it may be "resumed."
    
    // the activities of heap allocation, and modify the thread queues are not
    // thread safe. as such, this entire is function is a critical section. in
    // addition, the process of modifying the thread queue, once started,
    // must be finished before anything else can happen since a partially
    // modified queue is not usable by the scheduler. therefore, interrupts
    // must be disabled while this code executes.
    disable_irq();

    if(stack == USE_DEFAULT_STACK) stack = 128; // default stack values
    if(svcstack == USE_DEFAULT_STACK) svcstack = 64;
    
    // allocate a thread discriptor block for the new thread
    newthread = allocate_block(sizeof(thread), IWRAM);
    if(!newthread) return NULL; // out of memory
    
    // allocate stacks for the new thread
    // each thread needs a stack for system mode (in which the gamepak's code
    // is run) and supervisor mode (in which the BIOS' software interrupt
    // functions are run) because each mode has its own independant stack.
    // (see an assembly lanaguage guide if you are confused about what a
    // stack is or why one is a concern here).
    newthread -> stack = allocate_block(stack, IWRAM);
    newthread -> svcstack = allocate_block(svcstack, IWRAM);
    
    // check for allocation erros
    if(!newthread -> stack || !newthread -> svcstack)
    {
        // if stack allocation failed, free any successfully allocated
        // resources and return NULL
        
        if(newthread -> stack) deallocate_block(newthread -> stack);
        if(newthread -> svcstack) deallocate_block(newthread -> svcstack);
        deallocate_block(newthread);
        
        return NULL;
    }

    // setup the initial state of the thread
    newthread -> r0 = wparam; // function argument
    newthread -> pc = (word)entry; // thread entry point
    newthread -> lr = (word)killself; // return point
    newthread -> cpsr = 0x1f; // start in system mode
    newthread -> sp = (word)newthread -> stack + stack; // user stack
    newthread -> sp_svc = (word)newthread -> svcstack + svcstack; // svc stack
    
    // add the new thread to the ready queue
    enqueuethread(&ready_queue, newthread);
    
    enable_irq(); // safe to interrupt now
    return newthread; // return new thread
}
////////////////////////////////////////////////////////////////////////////////
void killthread(thread *t)
{
    
    // remove the specified thread from any queues and free its resources.
    // just like createthread, this function can't be interrupted
    
    disable_irq();
    
    // remove the thread from any queues
    dequeuethread(t);
    
    // deallocate the stacks and the thread discriptor
    deallocate_block(t -> stack);
    deallocate_block(t -> svcstack);
    deallocate_block(t);
    
    // if the thread was commiting suicide then clear the current_thread pointer
    // and wait for the dispatcher to swap something else in
    if( t == current_thread )
    {
        current_thread = NULL; // don't store the state
        enable_irq();
        for(;;);
    }
    else enable_irq();
    
}
////////////////////////////////////////////////////////////////////////////////
void resumethread(thread *t)
{
    
    // remove the thread from any queue and add to the the ready_queue
    
    if(!t) return;
    
    disable_irq();
    dequeuethread(t);
    enqueuethread(&ready_queue, t);
    enable_irq();
    
}
////////////////////////////////////////////////////////////////////////////////
void suspendthread(thread *t)
{
    
    // remove the thread from any queue and add to the suspended queue
    
    if(!t) return;
    
    disable_irq();
    dequeuethread(t);
    enqueuethread(&suspended_queue, t);
    enable_irq();
    
}
////////////////////////////////////////////////////////////////////////////////
void enqueuethread(thread **queue, thread *t)
{
    
    // add the thread to the end of the queue
    
    if(*queue == NULL) // no threads on the queue?
    {
        // no threads are on the queue, so make this thread the only one

        *queue = t;
        t -> next = t; // circular list
        t -> prev = t;
    }
    else
    {
        // threads are already on the queue, so add this thread to
        // end of it.

        t -> next = *queue;
        t -> prev = (*queue) -> prev;
        t -> next -> prev = t;
        t -> prev -> next = t;
    }

}
////////////////////////////////////////////////////////////////////////////////
void appendqueue(thread **dest, thread **src)
{
    thread *end_of_dest;
    thread *end_of_src;
    
    // take one queue and add it to the of another queue
    if(*dest)
    {
        if(!*src) return; // nothing to add
        
        // get pointers to last node of both queues
        end_of_dest = (*dest) -> prev;
        end_of_src = (*src) -> prev;
        
        // attach the queue onto the end of the other queue
        (*dest) -> prev = end_of_src;
        (*src) -> prev = end_of_dest;
        end_of_dest -> next = *src;
        end_of_src -> next = *dest;
    }
    else *dest = *src;
    
    *src = NULL; // nothing on that queue anymore
}
////////////////////////////////////////////////////////////////////////////////
void dequeuethread(thread *t)
{

    // remove the thread from the queue
    
    // remove the thread from the list
    t -> next -> prev = t -> prev;
    t -> prev -> next = t -> next;

    // if this is the last node, make the pointers NULL to clear the
    // the queue pointer in the next step
    if( t -> next == t) t -> next = t -> prev = NULL;
    
    // if this thread was at the front of the queue, move to the next thread
    // (not really a great way to do this but it ensures that it is removed
    // from whatever queue it was on so its okay).
    if(t == ready_queue) ready_queue = t -> next;
    if(t == suspended_queue) suspended_queue = t -> next;
    
}
////////////////////////////////////////////////////////////////////////////////
void disable_irq(void)
{

    // merely set the CPU flags to ignore irq and fiq requests so that code
    // may execute uninterrupted. it gets used enough to the warrent extra
    // instructions to make it a function.

    // disabling interrupts is one way to do a critical section of code but
    // is not prefered because it may causes the thread to consume more than
    // its fair share of CPU time and will lockup the system it if
    // locksup during a period when interrupts are diabled. semaphores are
    // are preferred when the code can be interrupted during a critical section.
    // incidently, semaphores are cool and easy to implement using assembly.
    // infact, a simple binary semaphore could be implemented using the ARM
    // swap intrustion in only a few lines.

    asm("mrs r0, cpsr"); // get cpu flags
    asm("orr r0, r0, #0xc0"); // set irq and fiq inhibitor flags
    asm("msr cpsr, r0"); // update cpu flags
}
////////////////////////////////////////////////////////////////////////////////
void enable_irq(void)
{

    // resverse of diable, set the cpu flags to allow irq and fiq requests

    asm("mrs r0, cpsr"); // get cpu flags
    asm("bic r0, r0, #0xc0"); // clear flags to enable
    asm("msr cpsr, r0"); // update cpu flags
}
////////////////////////////////////////////////////////////////////////////////
void killself(void)
{

    // function to be used as the return address for threads main functions
    // so that they may use a C "return" statement to end the thread.

    asm("ldr r0, =current_thread");
    asm("ldr r0, [r0]");
    asm("ldr lr, =killthread");
}
////////////////////////////////////////////////////////////////////////////////
