Hi all.  This little ditty was created from Nokturn's pong demo (bless him)!  Much of the code still has
his comments... There's a better WaitForVsync() and now OAM memory is cleared correctly.

It shows off a little bit of rotation/scaling and I tried to comment code as much as possible.  There are
still some pieces of unused code like a swap() routine for doing page flipping that's still sitting in
the source from other things I was trying out.

I've been trying in vain to get alpha-fading to work in mode 4, so if anyone figures it out, let me know.

Hope it puts a smile on your face, however briefly :/

-Vince
BydoEmpire@excite.com
