//---------------------------------------------------//
//       AGB Pong Demo by Nokturn                    //
//                                                   //
//    First Version: 6.  Jan. 2001                   //
//    Last  Version: 18. Apr. 2001                   //
//    View readme for more info                      //
//---------------------------------------------------//

#include "pong.h"
#include "math.h"

extern u16 e3chicks1;
extern u16 e3background;
extern u16 blonde;
extern u16 asian;

extern u8 palbg;
extern u8 palobj;

u16 *Bg         = &e3background;
u16 *Blonde		= &blonde;
u16 *Asian		= &asian;

u8 page=0;	// which page to write/display

u16 AsianX = 32;
u16 AsianY = 10;

u16 BlondeX = 160;
u16 BlondeY = 12;

s16 AsianDX=1;
s16 AsianDY=1;
s16 BlondeDX=-1;
s16 BlondeDY=-1;

u16 angle_index=0;
s16 fixed_angle;

short int sin_lut[360], cos_lut[360]; // two tables to make it easier and faster

void SetUpLookUpTables(void) // Compute these tables. NOTE: This is in fixed-point format!!!
{
	float f;
	for (f=0; f<256; f+=1)
		{
		sin_lut[(int)f] = (short int)((float)sin(f*3.1415926f/128.0f) *256.0);
		cos_lut[(int)f] = (short int)((float)cos(f*3.1415926f/128.0f) *256.0);
		}
}
 void InitMode4()
 {
	 LoadPalette( &palbg, PaletteBG ); // Loads the palette of the BG 
	 LoadPalette( &palobj, PaletteOBJ ); // Loads the OBJ palette

	 //LoadPalette( &palbg, PaletteBG ); // Loads the palette of the BG 
	 //LoadPalette( &palobj, PaletteOBJ ); // Loads the OBJ palette
	 
	 //DISPCNT = 0x01;	//0x04;  // Set video mode to mode4
	 //DISPCNT |= BIT09;       // Makes BG1 visible. 
	 DISPCNT = 0x04;  // Set video mode to mode4
	 DISPCNT |= BIT10;       // Makes BG2 visible. 
	 DISPCNT |= BIT12;       // Makes OBJs visible. 
	 DISPCNT |= BIT06;		 // 1-D mapping mode
	 MOSAIC = 0;             // Mosaic is 0
	 //BG1CNT |= BIT07|BIT06|BIT01;       // 256 color, Enable mosaic, 2nd priority
	 BG2CNT |= BIT07|BIT06|BIT01;       // 256 color, Enable mosaic, 2nd priority

	 BLDMOD = BIT06;		// enable alpha blending
	 BLDMOD |= BIT04|BIT10;		// bg2 is 2nd target pixel, obj is 1st target pxl (BIT 12 isn't really needed :p)

	 COLEV = BIT04 | BIT12;	// blend each 1/2

	 page = 0;				// write to page 0
	 curBuffer = VBuffer0;

 }

 void ShowBackGround()
 {
	 DISPCNT |= BIT04; // Show empty VBuffer1 to avoid tearing when we write to VBuffer0
	 Copy16( 38400, Bg, VBuffer0 ); // Copy the BG into VBuffer0 
	 DISPCNT &= ~BIT04;                       // And display it
	 Copy16( 38400, Bg, VBuffer1 ); // Copy the BG into VBuffer0 
 }

void ClearOAM()
	{
	for( i=0; i < 4*128; i+=4 )
		{
		Oam[i]   =  161 | BIT13;
		Oam[i+1] =  241;
		Oam[i+2] =  512;
		Oam[i+3] =  0;
		}
	}

void LoadSprites()
	{
	Copy16( 128*128, Asian, ObjectData);

	//angle = 0.7071067;  // sin/cos 45'
	//fixed = (angle * 256);
	angle_index = 0;
	SetUpLookUpTables(); // Compute these tables. NOTE: This is in fixed-point format!!!
	}

void WriteOAM()
	{
	 u8 rotate = 1;
	// Asian
	 	 //Oam[0]  =  AsianY|BIT13|BIT10; // Bit 10 is alpha-blending
		 Oam[2]  =  512|BIT11;	// BIT10 = priority 3
		 if (AsianDX < 0)	// hflip
			 {
		 	 Oam[0]  =  AsianY|BIT13; // Bit 8 is rotation, BIT 9 is double size rot.
			 Oam[1]  =  AsianX|BIT14|BIT15;	  // 64x64;                    
		 	 Oam[1] |= BIT12;			// hflip image
			 rotate = 0;
			 }
		 if (rotate)
			 {
		 	 Oam[0]  =  AsianY|BIT13|BIT08|BIT09; // Bit 8 is rotation, BIT 9 is double size rot.
			 Oam[1]  =  AsianX|BIT14|BIT15;	  // 64x64;                    
			 Oam[3]   = cos_lut[angle_index];	//fixed;	// PA
			 Oam[7]   = sin_lut[angle_index];	//fixed;	// PB
			 Oam[11]  = -1*sin_lut[angle_index];	//-1*fixed;	// PC
			 Oam[15]  = cos_lut[angle_index];	//fixed;	// PD
			 if (++angle_index >= 256)
				 angle_index = 0;
			 }

	 	 Oam[4]  =  (AsianY+64) | BIT13|BIT10; // BIT 10 = semi-transparent obj
		 Oam[5]  =  AsianX|BIT14|BIT15;
		 if (AsianDX < 0)	// hflip
		 	 Oam[5] |= BIT12;
		 Oam[6]  =  (512 + 128);	// BIT 10 = 2nd priority
		
	// Blonde
	 	 Oam[8]  =  (BlondeY)|BIT13|BIT10; // BIT 10 = semi-transparent obj
		 Oam[9]  =   (BlondeX)|BIT14|BIT15;
		 if (BlondeDX > 0)	// hflip
			 Oam[9] |= BIT12;
		 Oam[10]  =  (512+256)|BIT10;	// BIT 10 = 2nd priority
		
		 
	 	 Oam[12]  =  (BlondeY+64) | BIT13;
		 Oam[13]  =   (BlondeX)|BIT14|BIT15;
		 if (BlondeDX > 0)	// hflip
			 Oam[13] |= BIT12;
		 Oam[14]  =  (512+384);	// 516
		 
  }
 
 void MoveBall()
 {
	if (BlondeX<1 && BlondeDX < 0)
		BlondeDX = 1;
	if (BlondeX>=(239-64) && BlondeDX > 0)
		BlondeDX = -1;
	if (BlondeY<1 && BlondeDY < 0)
		BlondeDY = 1;
	if (BlondeY>=(159-128) && BlondeDY > 0)
		BlondeDY = -1;

	BlondeX += BlondeDX;
	BlondeY += BlondeDY;

	if (AsianX<1 && AsianDX < 0)
		AsianDX = 1;
	if (AsianX>=(239-64) && AsianDX > 0)
		AsianDX = -1;
	if (AsianY<1 && AsianDY < 0)
		AsianDY = 1;
	if (AsianY>=(159-128) && AsianDY > 0)
		AsianDY = -1;

	AsianX += AsianDX;
	AsianY += AsianDY;

 }

 void ProcessAI()
 {
	 // You can insert AI here. Stuff like:
 }

 void GetKeys()
 {
	if( !(P1 & KEY_UP ) ) 
		{
		BlondeDY = -1;
		}

	if( !(P1 & KEY_DOWN ) ) 
		{
		BlondeDY = 1;
		}

	 if( !(P1 & KEY_LEFT) )
		 {
		 BlondeDX = -1;
		 }

	 if( !(P1 & KEY_RIGHT) )
		 {
		 BlondeDX = 1;
		 }

 }

void swap()
	{
	WaitForVSync();
	if (page == 0)				// was page 0, switch to page 1
		{
		page = 1;
		curBuffer = (u16 *)0x600A000;	// write to buffer 1
		DISPCNT &= ~BIT04;				// display page 0
		}
	else						// was page 1, switch to page 0
		{
		page = 0;
		curBuffer = (u16 *)0x6000000;	// write to buffer 0
		DISPCNT |= BIT04;				// display page 1
		}
	//Wait(1);
	}

void DrawSprite32x32(u16 *obj, u32 x, u32 y)
	{
	u32 k;
	u32 offset = 0;
	for (k=0; k<32; k++)
		{
		DMA3SRC = (u32)obj + offset; // (u32)32*k;
		DMA3DST = (u32) curBuffer + x + 240*(y+k);
		DMA3CTL = 16;		// draw 8 dwords words at a time
		DMA3CTL |= DMA_ENABLE|DMA_SRC_INC|DMA_DST_INC;		// enable and don't inc src/dest addresses
		offset += 32;
		}
	return;
	}

void DrawSprite(u16 *obj, u32 x, u32 y, u32 w, u32 h)
	{
	u32 k;
	u32 offset = 0;
	for (k=0; k<h; k++)
		{
		DMA3SRC = (u32)obj + offset; //(u32)w*k;
		DMA3DST = (u32) curBuffer + x + 240*(y+k);
		DMA3CTL = w>>1;		// draw 16-bit words
		DMA3CTL |= DMA_ENABLE|DMA_SRC_INC|DMA_DST_INC;		// enable and don't inc src/dest addresses
		offset += w;
		}
	return;
	}

void BlankScreen(u8 pcolor)
	{

	/*
	u16 color = (u16)pcolor|((u16)pcolor<<8);
	//u32 color = (u32)pcolor|((u32)pcolor<<8)|((u32)pcolor<<16)|((u32)pcolor<<24);
	DMA3SRC = (u32)color;
	//DMA3SRC = (u32) Bg+BgOffset;
	DMA3CTL = (u32) 19200;	// number of u32's to copy
	DMA3DST = (u32) curBuffer;
	DMA3CTL |= DMA_ENABLE|DMA_SRC_LEV|DMA_DST_INC;		// enable and don't inc src/dest addresses
	*/

	// Fill with a texture
	/*
	u32 x = (u32)0;
	u32 y = (u32)0;
	u32 k = (u32)0;
	
	for (x=0; x<240; x+=32)	// 32 pixels at a time
		{
		for (y=0; y<160; y+=32)
			{
			// Draw Texture Square
			for (k=0; k<32; k++)
				{
				DMA3SRC = (u32)Ship + (u32)32*k;	// (u32) Bg+BgOffset;
				//DMA3SRC = (u32)Textures[0] + (u32)32*k; // (u32) Bg+BgOffset;
				DMA3DST = (u32) curBuffer + x + 240*(y+k);
				DMA3CTL = 8;		// draw 16 words at a time
				DMA3CTL |= DMA_ENABLE|DMA_SRC_INC|DMA_DST_INC|DMA_DWORD;		// enable and don't inc src/dest addresses
				}	
			}
		}
	*/

	// /*********** This one works **************
	u16 color = pcolor | (pcolor<<8);
	u32 i;
	u16 *dest = curBuffer;

	for( i = 0; i < (38400>>1); i++ ) 
		*dest++ = color;
	// *****************************************/

	return;
	}
void PlotPixel(u16 x, u16 y, u8 pcolor)
	{
	//u8 offset = y*SCREEN_WIDTH + (u8)x;
	//u16 color = * ( *PaletteBG + pcolor);
	u16 offset = y*(SCREEN_WIDTH>>1) + x;

	u16 color = (u16)pcolor|((u16)pcolor<<8);
	//u16 color = (u16)0x1a1a;
	*(u16 *)( curBuffer + offset) = color;
	//*( curBuffer + (u16)offset + 1) = pcolor;
	//*( (u16 *)0x06000000 + (u16)offset) = color;
	
	}

void AGBMain()
	{
	InitMode4();
	ClearOAM();
	LoadSprites();
	BlankScreen(0x01);
	swap();
	//BlankScreen(0x01);
	ShowBackGround();
	while( AGBRULEZ )
		{
		GetKeys();
		MoveBall();
		WriteOAM();
		WaitForVSync();
		//swap();
		}
	}

