//---------------------------------------------------//
//             AGB Header by Nokturn                 //
//        Ripped out version for the Pong game       //
//                                                   //
//    First Version: 29. Nov. 2000                   //
//    Last  Version: 14. Jan. 2001                   //
//    Last  Used in: Pong Demo                       //
//---------------------------------------------------//

 // Defines first

#define AGBRULEZ 1          // Define some morale. What would a demo without morale be? ;) 

#define PI 3.141592654

 // Here go the BITXX Macros to spare me some typing later and make the code more readable

#define BIT00 1
#define BIT01 2
#define BIT02 4
#define BIT03 8
#define BIT04 16
#define BIT05 32
#define BIT06 64
#define BIT07 128
#define BIT08 256
#define BIT09 512
#define BIT10 1024
#define BIT11 2048
#define BIT12 4096
#define BIT13 8192
#define BIT14 16384
#define BIT15 32768

#define KEY_A      BIT00 
#define KEY_B      BIT01
#define KEY_SELECT BIT02
#define KEY_START  BIT03
#define KEY_RIGHT  BIT04
#define KEY_LEFT   BIT05
#define KEY_UP     BIT06
#define KEY_DOWN   BIT07
#define KEY_R      BIT08
#define KEY_L      BIT09

#define CHAR(x) 64*x

#define SCREEN_WIDTH	240
#define SCREEN_HEIGHT	160

 // Some "new" types. A must-be.

typedef unsigned char u8;
typedef unsigned short u16;
typedef unsigned long u32;

typedef signed char s8;
typedef signed short s16;
typedef signed long s32;

 // Registers

#define DISPCNT    *( u32 * )0x04000000
#define VCOUNT     *( u16 * )0x04000006
#define DISPSTAT   *( u16 * )0x04000004
#define P1         *( u16 * )0x04000130

#define BG1CNT     *( u16 * )0x0400000A
#define BG2CNT     *( u16 * )0x0400000C

#define MOSAIC     *( u16 * )0x0400004C

#define BLDMOD	   * ( u16 * )0x04000050
#define COLEV	   * ( u16 * )0x04000052
#define COLY	   * ( u16 * )0x04000054

#define DMA3SRC		* ( u32 * )0x040000D4	// dma source address
#define DMA3DST		* ( u32 * )0x040000D8	// dma destination address
#define DMA3CTL		* ( u32 * )0x040000DC	// dma control


#define DMA_ENABLE	(0x80000000)
#define DMA_INT_REQ	(0x40000000)
#define DMA_DWORD	(0x04000000)
#define DMA_WORD	(0x00000000)
#define DMA_REPEAT  (0x02000000)

#define DMA_DST_INC	(0x00000000)
#define DMA_DST_DEC	(0x00200000)
#define DMA_DST_LEV	(0x00400000)	// leave src unchanged

#define DMA_SRC_INC	(0x00000000)
#define DMA_SRC_DEC	(0x00800000)
#define DMA_SRC_LEV	(0x01000000)	// leave src unchanged

 // GFX Specific

#define PALBG      *( u16 * )0x05000000
#define PALOBJ     *( u16 * )0x05000200

#define OBJDATA    *( u16 * )0x06014000
#define OAM        *( u16 * )0x07000000

 // GFX Mode 4 - Used for the Intro

#define VBUFFER0   *( u16 * )0x06000000
#define VBUFFER1   *( u16 * )0x0600A000

// Now some globals.

// Used in the intro

u16 *BackBuffer     = &VBUFFER1;
u16 *VBuffer0       = &VBUFFER0;
u16 *VBuffer1       = &VBUFFER1;
u16 *curBuffer		= &VBUFFER0;

// Used everywhere

u16 *PaletteBG     = &PALBG;
u16 *PaletteOBJ    = &PALOBJ;
u16  *ObjectData    = &OBJDATA;
u16 *Oam           = &OAM;


u16 i,j,k;   // Counter values

// Function that returns a RGB color in 15bit format 

u16 RRGBColor( u8 R, u8 G, u8 B )          // Uses u8 because it only needs 5 bits. Int is waste of speed.
 { 
  return ((R)|(G<<5)|(B<<10));
 }

 // Function to wait for Vertical Sync. I took Eloist's ASM Version

void WaitForVSync()
{
 __asm
	  {
	   mov 	r0, #0x4000006
	   scanline_wait2:
       ldrh r1,[r0]
       cmp r1,#160
       beq scanline_wait2
       scanline_wait:
       ldrh	r1, [r0]
       cmp	r1, #160
       bne 	scanline_wait
	  }
}

// The next one will copy raw data

void Copy16( u32 HowMuch, u16 *Src, u16 *Dest )
{
 u32 i;
 for( i = 0; i < (HowMuch>>1); i++ ) Dest[i] = Src[i];
}

// A stupid function that waits a certain number of VSyncs... well, it tries to ;)

void Wait( u32 HowManyVSyncs )
{
	u8 i,j;
	u32 Waiter;
	for( Waiter = 0; Waiter < HowManyVSyncs; Waiter++ )
	{
		WaitForVSync();
		for( i = 0; i < 100; i++ ) j = i*32/3; // Do something stupid
	}
}

// These are mosaic functions. aWait is the frames to wait between a mosaic. Try out EnMosaic( 1 ) to EnMosaic( 10 )

void EnMosaic( u32 aWait )
{
	s8 MosaicSize;
	for( MosaicSize = 0; MosaicSize < 16; MosaicSize++ )
	{
		MOSAIC = (MosaicSize)|( MosaicSize<<4)|(MosaicSize<<8)|(MosaicSize<<12); 
		Wait( aWait );
	}
}

void DeMosaic( u32 aWait )
{
	s8 MosaicSize;
	for( MosaicSize = 15; MosaicSize >= 0; MosaicSize-- )
	{
		MOSAIC = (MosaicSize)|( MosaicSize<<4)|(MosaicSize<<8)|(MosaicSize<<12); 
		Wait( aWait );
	}
}


// Loads a palette from a file: First argument is a pointer to a palette and second, the 
// palette you want to write to.
void LoadPalette( u8 *aPal, u16 *addrPal )
{
	u16 i,j=0;
	for( i = 0; i < 768; i+=3 )
	{		
		addrPal[j] = RRGBColor( aPal[i], aPal[i+1], aPal[i+2] );
		j++;
	}
}