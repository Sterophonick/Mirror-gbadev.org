Rainbow Islands

GBA Prototype / Demo

MakSW (09/09/2002)

Cover Note : 

This demo is intended for public viewing and appraisal by prosepective publishers.

MakSW reserve all rights relating to the binary and the source code used to produce it.

MakSW do not lay claim to ANY graphical or sound content within the demo - as the majority of it has been obtained from Taito copyrighted sources (Mame ROMS etc...).


We have coded this with every intention of doing a full, legal and legitimate version for full hardware release - but we are having difficulties getting publishers interested (EA said they were not interested, Acclaim simply will not answer the phone...), so we hope that the exposure through yout site will help. Because of the lack of interest, the project is now on hold at the prototype stage - which is a damned shame because it is really shaping up to be a great conversion.

Our original plan was to do a Bubble Bobble and Rainbow Islands compendium release on a single GBA ROM - but Taito scuppered that by releasing BB themselves :(

Ideally, we'd like to get Taito to publish this for us - so if any of your site users have any contacts within the Taito Corp. let them know! :D

We have had no luck so far in getting in touch with Taito ourselves so any help would be greatly appreciated. Having said that - any other reputable publisher willing to buy the licence from Taito will do!

The Demo : 

Any button other than START inserts a credit, then START starts a game.
SELECT in game will bring up a quick dev menu.

There are lots of "issues" with this version, and they are all known so no bug reports please! :D This is only a "Look at What we Did!" version.

If anyone can be of any help, let us know through email : bivins42@hotmail.com



