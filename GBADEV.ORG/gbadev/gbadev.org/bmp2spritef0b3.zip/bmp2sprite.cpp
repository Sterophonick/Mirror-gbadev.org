// bmp2sprite.cpp : Defines the entry point for the console application.
// http://www.pbwhere.com

#include "stdafx.h"
#include <string.h>
#include <stdlib.h>

typedef unsigned char BYTE;
typedef unsigned short WORD;
typedef unsigned long DWORD;

int hexNibble(char c)
{
	if (c == '1') return 1;
	if (c == '2') return 2;
	if (c == '3') return 3;
	if (c == '4') return 4;
	if (c == '5') return 5;
	if (c == '6') return 6;
	if (c == '7') return 7;
	if (c == '8') return 8;
	if (c == '9') return 9;
	if (c == 'a' || c == 'A') return 0xA;
	if (c == 'b' || c == 'B') return 0xB;
	if (c == 'c' || c == 'C') return 0xC;
	if (c == 'd' || c == 'D') return 0xD;
	if (c == 'e' || c == 'E') return 0xE;
	if (c == 'f' || c == 'F') return 0xF;
	return 0;
}

int hexByte(char *str)
{
	return (hexNibble(str[0]) << 4) | hexNibble(str[1]);
}

int main(int argc, char* argv[])
{
	if (argc < 3)
	{
		printf("%c Usage:                                                                  v2.0\n", 254);
		printf("   bmp2sprite infile.bmp palette.raw [-o outfile.bin] [-16 X] [-c RRGGBB] [-O]\n\n");
		printf("   infile.bmp         24-bit sprite image.\n");
		printf("   palette.raw        GBA Palette (512 bytes used for object palette).\n");
		printf("   -o outfile.bin     Output file (default: infile.bin).\n");
		printf("   -16 X              Output 16-color image based on palette.raw's 16-color\n");
		printf("                      palette X, where X = 0..15. Without this option set, it\n");
		printf("                      uses all 256 colors.\n");
		printf("   -c RRGGBB          Sets the clear color as RRGGBB (hex) (default: 000000).\n");
		printf("   -O                 Overwrite outfile.bin if it exists.\n\n");
		return 0;
	}

// *******************************************
// *
// *
// *           Load command line options
// *
// *
// *******************************************

	bool overwrite = false;
	int pal = -1, i = 0;
	int clearR = 0, clearG = 0, clearB = 0;
	char outfile[_MAX_PATH];
	char in_drive[_MAX_DRIVE];
	char in_dir[_MAX_DIR];
	char in_fname[_MAX_FNAME];
	char in_ext[_MAX_EXT];

	_splitpath(argv[1], in_drive, in_dir, in_fname, in_ext);
	_makepath(outfile, in_drive, in_dir, in_fname, "bin");

	for (i = 3; i < argc; i++)
	{
		if (strcmp(argv[i], "-16") == 0)
			pal = atoi(argv[++i]);
		if (strcmp(argv[i], "-c") == 0)
		{
			clearR = hexByte(&argv[++i][0]);
			clearG = hexByte(&argv[i][2]);
			clearB = hexByte(&argv[i][4]);
		}
		if (strcmp(argv[i], "-o") == 0)
			strcpy(outfile, argv[++i]);
		if (strcmp(argv[i], "-O") == 0)
			overwrite = true;
	}

// *******************************************
// *
// *
// *           Load bitmap
// *
// *
// *******************************************

	FILE *inp_fp = fopen(argv[1], "rb");

	if (inp_fp == NULL)
	{
		printf("Couldn't open %s\n", argv[1]);
		fcloseall();
		return 1;
	}

	BYTE header[54];
	BYTE picture[12288];
	fread((void *)header, 1, 54, inp_fp);
	fread((void *)picture, 1, 12288, inp_fp);
	fclose(inp_fp);

	DWORD *width = (DWORD *)&header[0x12];
	DWORD *height = (DWORD *)&header[0x16];
	WORD *bpp = (WORD *)&header[0x1C];

	if (header[0] != 'B' || header[1] != 'M' || *bpp != 24)
	{
		printf("Input file isn't a 24-bit bitmap.\n");
		return 1;
	}

	if (*width > 64 || *height > 64)
	{
		printf("Image too big. Max size = 64 x 64.\n");
		return 1;
	}

// *******************************************
// *
// *
// *           Figure out correct size for GBA
// *
// *
// *******************************************

	WORD x_size = 8;
	WORD y_size = 8;
	WORD attrib0 = 0, attrib1 = 0, attrib2 = 0;
	while (x_size < *width) x_size *= 2;
	while (y_size < *height) y_size *= 2;

	if (x_size == 8 && y_size == 8)
	{
		attrib0 = 0x0000;
		attrib1 = 0x0000;
	}
	if (x_size == 8 && y_size == 16)
	{
		attrib0 = 0x8000;
		attrib1 = 0x0000;
	}
	if (x_size == 8 && y_size == 32)
	{
		attrib0 = 0x8000;
		attrib1 = 0x4000;
	}
	if (x_size == 8 && y_size == 64)
	{
		x_size = 32;
	}

	if (x_size == 16 && y_size == 8)
	{
		attrib0 = 0x4000;
		attrib1 = 0x0000;
	}
	if (x_size == 16 && y_size == 16)
	{
		attrib0 = 0x0000;
		attrib1 = 0x4000;
	}
	if (x_size == 16 && y_size == 32)
	{
		attrib0 = 0x8000;
		attrib1 = 0x8000;
	}
	if (x_size == 16 && y_size == 64)
	{
		x_size = 32;
	}

	if (x_size == 32 && y_size == 8)
	{
		attrib0 = 0x4000;
		attrib1 = 0x4000;
	}
	if (x_size == 32 && y_size == 16)
	{
		attrib0 = 0x4000;
		attrib1 = 0x8000;
	}
	if (x_size == 32 && y_size == 32)
	{
		attrib0 = 0x0000;
		attrib1 = 0x8000;
	}
	if (x_size == 32 && y_size == 64)
	{
		attrib0 = 0x8000;
		attrib1 = 0xC000;
	}

	if (x_size == 64 && y_size == 8)
	{
		y_size = 32;
	}
	if (x_size == 64 && y_size == 16)
	{
		y_size = 32;
	}
	if (x_size == 64 && y_size == 32)
	{
		attrib0 = 0x4000;
		attrib1 = 0xC000;
	}
	if (x_size == 64 && y_size == 64)
	{
		attrib0 = 0x0000;
		attrib1 = 0xC000;
	}

	if (pal == -1)
		attrib0 |= 0x2000;
	else
		attrib2 = pal << 12;

// *******************************************
// *
// *
// *           Load palette
// *
// *
// *******************************************

	FILE *pal_fp = fopen(argv[2], "rb");

	if (pal_fp == NULL)
	{
		printf("Couldn't open %s\n", argv[2]);
		fcloseall();
		return 1;
	}

	WORD palette[256] = {0};
	fread((void *)palette, 2, 256, pal_fp);
	fclose(pal_fp);

	struct {
		BYTE r;
		BYTE g;
		BYTE b;
	} gba_pal[256];

	for (i = 0; i < 256; i++)
	{
		gba_pal[i].r = palette[i] & 0x1F;
		gba_pal[i].g = (palette[i] >> 5) & 0x1F;
		gba_pal[i].b = (palette[i] >> 10) & 0x1F;
	}

// *******************************************
// *
// *
// *           Conversion
// *
// *
// *******************************************

	BYTE gba_pic[64][64] = {0};

	i = 0;
	for (int y = *height - 1; y >= 0; y--)
	{
		for (int x = 0; x < *width; x++)
		{
			int picB = picture[i++];
			int picG = picture[i++];
			int picR = picture[i++];
			if (picR == clearR &&
				picG == clearG &&
				picB == clearB)
			{
				gba_pic[x][y] = 0;
				continue;
			}

			int fromR = picR >> 3;
			int fromG = picG >> 3;
			int fromB = picB >> 3;
			int fromColor = 1;
			int toColor = 256;
			if (pal != -1)
			{
				fromColor = pal * 16 + 1;
				toColor = fromColor + 15;
			}
			BYTE toPal = fromColor;
			for (int j = fromColor + 1; j < toColor; j++)
			{
				int thisR = fromR - gba_pal[j].r;
				int thisG = fromG - gba_pal[j].g;
				int thisB = fromB - gba_pal[j].b;
				int bestR = fromR - gba_pal[toPal].r;
				int bestG = fromG - gba_pal[toPal].g;
				int bestB = fromB - gba_pal[toPal].b;
				if (thisR * thisR + thisG * thisG + thisB * thisB <
					bestR * bestR + bestG * bestG + bestB * bestB)
					toPal = j;
			}
			if (pal != -1)
				toPal = toPal & 0x0F;
			gba_pic[x][y] = toPal;
		}
		switch (*width % 4)
		{
		case 1:
			i += 3;
			break;
		case 2:
			i += 2;
			break;
		case 3:
			i += 1;
			break;
		}
	}

// *******************************************
// *
// *
// *           Write results
// *
// *
// *******************************************

	if (!overwrite)
	{
		FILE *ovr_fp = fopen(outfile, "r");
		if (ovr_fp != NULL)
		{
			printf("Output file already exists.\n");
			fcloseall();
			return 1;
		}
	}

	FILE *out_fp = fopen(outfile, "wb");

	if (out_fp == NULL)
	{
		printf("Couldn't open %s\n", outfile);
		fcloseall();
		return 1;
	}

	fwrite(&attrib0, 1, 2, out_fp);
	fwrite(&attrib1, 1, 2, out_fp);
	fwrite(&attrib2, 1, 2, out_fp);

	if (pal == -1)
	{
		for (int celly = 0; celly < y_size; celly+=8)
			for (int cellx = 0; cellx < x_size; cellx+=8)
			{
				for (int py = 0; py < 8; py++)
					for (int px = 0; px < 8; px++)
					{
						BYTE pix = gba_pic[cellx + px][celly + py];
						fwrite((void *)&pix, 1, 1, out_fp);
					}
			}
	}
	else
	{
		for (int celly = 0; celly < y_size; celly+=8)
			for (int cellx = 0; cellx < x_size; cellx+=8)
			{
				for (int py = 0; py < 8; py++)
					for (int px = 0; px < 8; px+=2)
					{
						BYTE pix = gba_pic[cellx + px][celly + py];
						BYTE pix2 = gba_pic[cellx + px + 1][celly + py];
						pix |= (pix2 << 4);
						fwrite((void *)&pix, 1, 1, out_fp);
					}
			}
	}

	fclose(out_fp);

	return 0;
}

