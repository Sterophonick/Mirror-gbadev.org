Pop! is my first attempt at writing a game for the GameBoy Advance. The bulk of
it was done over a long weekend. At the moment it's playable including basic
scoring, music and sound effects.

The game is in the style of Puyo-Puyo (a.k.a Dr. Robotnik's Bean Machine).

I still need to add the AI/linkup second player, high scores, better graphics,
more flourishes and other things.

The code and graphics are all original. The sound effects were taken from
random wav archive sites.

Toby Jaffey
toby-gba@earth.li
