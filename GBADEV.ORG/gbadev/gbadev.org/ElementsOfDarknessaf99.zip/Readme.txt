+-------------------------
  Elements of Darkness
+-------------------------

A mostly finished, but far from polished, Castlevania style game with outdoor areas, scads of secrets, and an rotate/scale style boss!!  Tried to get a publishing deal, but it never went anywhere.  

Hence releasing it for free, as-is, so use it at your own risk!


+-------------------------
  Controls
+-------------------------


 *Basic Moves
    -Left/Right  = Move left right
    -Down        = Duck/Crouch
    -Up          = Enter a doorway
    
    -A           = Jump
    -B           = Attack

 *Advanced Moves
    -Double Tap Left/Right = Dash
    -A + A                 = Double Jump (must have jump boots)
    -Down + A              = Jump down through special platforms

    -try dashing off a ledge, then pressing A in-air...wheeeee!



+-------------------------
  Misc Notes
+-------------------------

Certain areas require the double jump boots.  If you 'warp' to different maps in the game from the game title screen, you may well find yourself unable to properly navigate certain areas.  

There are many, many secrets to be found.  Try walking throug walls, jumping down through platforms, and jumping up to find hidden platforms.  

The goofy floating letters are items that increase various player stats.

The snow level was mostly just to demo an idea I had about rendering cool looking snow...

MapEd was used for all level creation.