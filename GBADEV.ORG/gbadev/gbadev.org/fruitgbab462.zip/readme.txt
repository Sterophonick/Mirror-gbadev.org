
Fruit Land	(c) 2001 Arjan Bakker
----------------------------------------

Introduction
---------------
Fruit Land is my first program for the GBA, or AGB, whatever you want. It's a simple puzzle game I
ported over from the PC-version I did one year ago (which was a port of the MSX-version I did in 1998
or so). Actually it's more a rewrite than a port, but that doesn't matter. Anyways, I did this game in
only 4 days, in which I also had to write some tools and discover that some documents aren't always
correct...

What do you need to run it?
------------------------------
The only emulator I know it runs on is VGBA 0.2. It doesn't seem to work on iGBA, GbaEmu and EloGba,
but I've only tested it on some older versions. It probably doesn't work on the real thing either, but I haven't
tested that.

What do you need to compile it?
----------------------------------
You need GCC and gfxlib to be able to compile this game. Before compiling the thing, make sure you set
the paths in makefile correctly. You need to change _AGBINC, _AGBLIB and .OFILES. Change their paths
into the paths you've installed the include-dir and lib-dir from the GCC-compiler and the gfxlib-dir
respectively.

How do you play this game?
-----------------------------
The game's goal is completing all levels by eating all cherries in all levels. To achieve this you
probably need to use some items scattered in all levels, like screen-turners, enemy-stoppers, time-
stoppers, rocks, blocks and teleporters. There are also diamonds and little dots, but they only give
you extra points. The teleporters are a bit tricky, so I'll tell you how they work. If you enter a
teleporter, the game scans the level from the top-left corner to top down-right corner (first from
the left to the right and then one line down) to find another teleporter. To make things a bit harder
you need to do this within the timelimit. After completing a level, you'll get some bonuspoints. After
every 5th level, you'll get a password so you don't have to start from the beginning next time you
play the game.

How to control?
------------------
In the intro-screen, use up and down to move to another option and press button A to select.
In the password-screen, use left and right to move left and right, up and down to change a letter and
button A to confirm.
In the game, use the directional buttons to move around, button B to pause the game and select to kill
yourself.

Other things
---------------
If you find bugs, want to criticize my code or can make it run on the real thing, just mail me. And
offcourse you can also mail me to tell me you like (or don't like) the game :) The only thing I don't
like is that the game seems to be a bit slow...
Anyway, my mail-address is: abeker@hetnet.nl

Disclaimer
-------------
No-one has been hurt during the process of making this game. The author cannot be held responsible for
any damage caused by having, distributing or playing this game. In other words: use it on your own risk!
