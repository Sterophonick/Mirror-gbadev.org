
typedef unsigned char           u8;
typedef unsigned short int      u16;
typedef unsigned int            u32;
typedef unsigned long long int  u64;

typedef signed char             s8;
typedef signed short int        s16;
typedef signed int              s32;
typedef signed long long int    s64;

#define DISP_LCDC_OFF  0x80
#define DISP_MODE_0	   0
#define DISP_MODE_1    1
#define DISP_MODE_2    2
#define DISP_MODE_3    3
#define DISP_MODE_4    4
#define DISP_MODE_5    5
#define DISP_OBJ_ON	   0x1000
#define DISP_BG3_ON	   0x0800
#define DISP_BG2_ON    0x0400
#define DISP_BG1_ON    0x0200
#define DISP_BG0_ON    0x0100
#define MOSAIC		*(u16 *)0x0400004C
#define REG_BASE    0x4000000
#define REG_DISPCNT (REG_BASE + 0x0)
#define REG_STAT    (REG_BASE + 0x4)
#define VRAM        0x6000000


#define J_A			1
#define J_B			2
#define J_SELECT	4
#define J_START		8
#define J_RIGHT		16
#define J_LEFT		32
#define J_UP		64
#define J_DOWN		128
#define J_R			256
#define J_L			512
#define KEYS *(u16 *)0x4000130








