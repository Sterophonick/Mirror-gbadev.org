   Future Shock Software (Canada) Presents:

   Santa Escapes the Labyrinth of Presents
   
   for the Gameboy Advance

   Completed December 2004
   
   Programmed by Jeff King.
   
   
Story:

Santa is trapped in the Labyrinth of Presents, with only 3 minutes until Xmas eve! Help him
get to his sleigh before time runs out. There will be many presents blocking your path,
so you must move them out of the way. 


Controls:

(A) - Action. 

	This will move presents, talk to elves, and activate a few immovable items around the map. 
	Try to action everything! 

(R) - Toggle music on/off during game

(Start) - Pause (press again to unpause)



Info:

This is a quick game I made up for the xmas season. 
Presents will only move on the shaded path below it (2 possible positions).
I programmed everything except for the music/sfx player. That is by Apex-Designs.
Check them out: http://www.apex-designs.net

Hopefully any bugs have been fixed. If not, feel free to contact me (akolade@gmail.com).
I frequent the forum at gbadev.org as well (Username: akolade).

Comments are welcome!!

Email: akolade@gmail.com
Website: www.fshock.com
