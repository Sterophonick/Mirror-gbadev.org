// starfield test using my old GBC starfield code
//using the ARM SDK
//
//15 April 2001
// Richard "Ries" van der Brugge / rvdbrugge@yahoo.com
//

//replace this with the number of start you want onscreen
#define MAXSTARS 200

//include standard routines
#include "rieslib.h"
//#include "matrix.h"

//random value lookup table
#include "xarray.c"




//********************************************************************************
//entry from startup asm code, probably the only original bit in this source all others use c_entry :)))
//this is the replacement for the main() stuff you find in other C programs
//********************************************************************************
void StartHere()
{

long starx[MAXSTARS], stary[MAXSTARS], starz[MAXSTARS];
long posx,posy,i,rndcounter;


SetDisplayMode4On();
CreatePalette();


//init star values
rndcounter=10;
for (i=0;i<MAXSTARS;i++){
	starx[i]=xarray[rndcounter];
	stary[i]=yarray[rndcounter];
	starz[i]=32;
	rndcounter++;
	if(rndcounter==160){rndcounter=0;}

}

while(1){

	VSync();
	DMAClearScreen();

    for (i=0;i<MAXSTARS;i++){
		// do posx=startx[i]*32 a bit faster
        posx=starx[i]<<5;
        posx=posx/starz[i];
        posx+=120;
        posy=stary[i]<<5;
        posy=posy/starz[i];
        posy+=90;
        starz[i]--;
		//hit the bottom or top ?
        if (starz[i]==0||posx>240||posx<1||posy>160||posy<1){
				starx[i]=xarray[rndcounter];
				stary[i]=yarray[rndcounter];
				rndcounter++;
					if(rndcounter==160){rndcounter=0;}
					starz[i]=32;
			        }
		DrawPixel(posx,posy,25);//oops narrowing cast warnings....
	    }//end for


}//wend

}//end starthere
