
----------------------------------------------------------
tileConverter v2.0 - Test Breakdown 

Converts a bitmap into tiles suitable for GBA.

Supported formats:
	4-bit bitmap -> 4bit tiles (16 colour).
	8-bit bitmap -> 8bit tiles (256 colour).

A c file (default) with same name as inputFile is generated.

Usage:	tileconverter [-v] [-d] [-np] [-nm] [-lp #] [-b] [-O outputFile] inputFile.bmp

	-v		Verbose mode.
	-d		Keep duplicate tiles.
	-np		No palette.
	-nm		No map.
	-lp #		Export only first # palette entries.
	-b		Binary file output.
	-O outputFile	Specify name of outputFile.
	-?		Display this help.

----------------------------------------------------------

testbreakdown@hotmail.com
