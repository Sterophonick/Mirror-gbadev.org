Game	: Reversi
Author	: Panit Wechasil (Roto the HERO)
e-mail 	: panitw@yahoo.com
Homepage: http://www.roto-studio.com (Under Construction 3/8/2001)

Hi!

I'm new in GBA development and this is my first GBA demo written in C and compile by GCC. 
if you have any comment you can send it to me at panitw@yahoo.com