This is a demo of othello. 
The goal of othello is to capture as much of the board as you can.
You capture opponents pieces by having at least one of their pieces
in between 2 of yours. For example
    
      X O O 
      X O

X can capture two O pieces by
    
      X O O X
      X O

This then becomes

      X X X X
      X O

Simple!

It features:
		- 3D view of board
		- Computer player
		- Top down map

The keys are
		Up - Move Forward
		Down - Move Back
		Left - Strafe left
		Right - Strafe right

		A - Place piece
		B - View map
		L - Skip Go

All feedback greatly appreciated!
Send to dm93@hotmail.com

Cheers