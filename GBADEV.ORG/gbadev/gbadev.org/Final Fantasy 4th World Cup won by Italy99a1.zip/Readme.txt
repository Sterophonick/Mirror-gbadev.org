Final, (Fantasy) 4th World Cup won by Italy

a demo game from Magnetic_dud

It's like a port of the alright famous similar flash game.
But mine is cooler :p

Disclaimer:
This software doesn't want to be offensive.
Also it's not authorized nor endorsed by Nintendo, Square Enix, Camelot, EA Sports.


Thanks to:
-Italian soccer team
-Square Enix for give me the Final Fantasy 4 source code :p
-Camelot for give me the Golden Sun source code :p
-EA Sports for give me the FIFA World Cup 2006 source code :p
-UEFA for give me the UEFA theme score :p