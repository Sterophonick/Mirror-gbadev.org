Use the a button to enter a mode
press start to pause the demos/games/simulations
and select what you want with a
if you want to return to the demos/games/simulations press start again

in simulation mode start by placing out the planets pressing start after you 
have placed out each planet

Have fun!