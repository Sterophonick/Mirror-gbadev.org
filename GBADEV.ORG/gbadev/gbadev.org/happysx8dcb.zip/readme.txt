/==============================================================================\                                                                  
|               __   __                              ____  __  ,__             | 
|               #B   #B                             /###@ ]#G ,@@              |  
|               W@   W@                             M@  "  MB d@               |  
|               #@   #@ ,gM##- #k#Bg_ p@##g, gg  gp #@     \#dB"               |  
|              ]#Mgg##L @@"7#  #@"9#b E#""#@ Q@ ,#C Q#@_    @#C                |  
|              l#"""7# IB  &B  #C  #@ #@  ED QB &B   9#W_  ,M#,                |  
|              &#   &# W@  W@ ]#?  #@ #L  W@ l#_#C    \#G  W@#@                |  
|              E@   E@ #@ ,#@ [#  /#")#  /#$ `#WM  ,_ ,#@ d# YB_               |  
|              #@   #@ V#gM#@ ##g##P [#g##@   9#@  Q#g#@ Z#" `#G               |  
|              ""   ""  """"" W@""   Q@"""    #B   `"""  ""   ""               |  
|                             #@     M@     ,g#@                               |  
|                            .#L     #P     #@"                                |
\==============================================================================/

Name of demo: Happy Birthday SlasherX

This is a demo that's made in mode 4 and uses bg2. This is my first attempt
at a demo, and I have to thank #gbadev and dovoto for his tutorial and darkfader, which showed
me where my original attempt was failing at. This demo was aimed for an 8/26/01 
release, but because of my problems with transfering the palette into the palette
ram, I couldn't. Thanks to everyone who helped me out.                                               
                                                                                
                                                                                
                                                                                
                                                                                
                                                                                
