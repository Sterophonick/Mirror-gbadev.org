The Trouble with Tribbles

A game by Will Thomas, written for the Ludum Dare 48 hour competition in April, 2004.

All code and art were created by me durring the 48-hours of the competition, to fit with the theme, "Infection"

The Game
You control Ensign Disposable. The ship is covered in tribbles, and it's up to you to wipe them out.
Your only weapon is a modified hand phaser that emits a field that will kill the tribbles. This field isn't
exactly good for you either - so watch out, or you'll cook yourself, too!

When you clear the first room, or you kill your ensign, you will be taken to the map screen.
From here you can move back into the original room or any connected rooms (indicated by green lines). If you move into a room with tribbles, you will be taken back to the game screen to wipe them out. While you are clearing each room, the population in other rooms grows. Additionally, rooms with large numbers of tribbles will spread the infection out into connected rooms - including rooms you might have already cleared! The rate of growth and spread is blocked by the presence of the player in a room, and the rate of growth/spread is constant, regardless of how long it takes to clear the room. This is where the strategy of the game lies. Even with a winning strategy for clearing rooms, it takes a bit of patience and persistance, but if you just clear rooms at random you will probably never manage to clear every room on the ship.

Controls
A Note!! these instructions say 'A', refering to the 'A' button of the GBA. Most emulators do not map this to the 'A' key on your keyboard!
In VBA, the default keys are (GBA,Keyboard) : (A,Z), (B,X), (L,A), (R,S),(Start,enter),(select,backspace), and the arrows for the d-pad

Press and hold 'A' to use your radiation field. The longer you hold it, the stronger it becomes (represented by the brightness
of the circular red field) This field also hurts you; watch the hud in the upper-left. If it is filled red, you will die.  
This meter drops if you release the 'A' button.



Known Bugs:
Radiation field wraps around if it goes off the right or left edge of the screen. Doesn't actually hurt tribbles on other side, just draws there. Background seems not to be set correctly?

No replay - if you finish the game, you can hit start to go back to the menu and start a new game. The game states are not reset, though - the new game will not happen, you will just go directly back to the "victory" screen. Whoops, just forgot that.


All star-trek references copyright Paramount. 