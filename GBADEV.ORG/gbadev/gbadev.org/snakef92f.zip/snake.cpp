////////////////////////////////////////////////////////////////////////////
//File:		snake.cpp
//Description:	the classic snake game
//Date:		27 - 04 - 2003
//Author:		Jenswa
//Thanks to:	gbajunkie, dovoto and nokturn
////////////////////////////////////////////////////////////////////////////


//general declarations
#include "gba.h"		//GBA register definitions
#include "dispcnt.h"		//REG_DISPCNT register defines
#include "keypad.h"	//keypad defines
#include "sprites.h"		//sprite defines
#include "fade.h"		//background fades

//dma stuff
#include "dma.h"		//dma defines
#include "dma.c"		//dma copy function

//gfx
#include "objpalette.h"	//normal mspaint 256 colour palette
#include "numbers.h"	//number 0 - 9
#include "block.h"		//green block for the snake
#include "miniblock.h"	//little block icon, for lives
#include "title.h"		//8-bit title screen

//other stuff
#include "list.c"		//my predefined 'random' list


//create an OAM variable and make it point to the address of OAM
u16* OAM = (u16*)0x7000000;

//create the array of sprites (128 is the maximum)
OAMEntry sprites[128];


int move = 16;		//pixel it moves per turn
int walk = 0;		//to decide what direction the snake is going
int t = 0;			//t used as timer (could also have used build in timer)
int score = 0;		//score
int lives = 3;		//lives
int x =0;			//to walk trough my predifened 'random' array

int foodx = 32;		//x from the food
int foody = 48;		//y from the food

int max = 100;		//maximum number of blocks, following the head
int size = 1;		//number of blocks, following  the head
int lastx[100];		//all x coordinates from the sprite
int lasty[100];		//all y coordinates from the sprite


//clear VideoBuffer with some unused VRAM
void ClearBuffer()
{
	REG_DM3SAD = 0x06010000;				//Source Address - Some unused VRAM
	REG_DM3DAD = 0x06000000;				//Destination Address - Front buffer
	REG_DM3CNT = DMA_ENABLE | DMA_SOURCE_FIXED | 19200;
}

//wait for the screen to stop drawing
void WaitForVsync()
{
	while((volatile u16)REG_VCOUNT != 160){}
}

//Wait until the start key is pressed
void WaitForStart()
{

	u8 t=0;		//used for detecting a single press

	while (1)
		if( KEY_DOWN(KEYSTART) )
		{
		t++;
			if(t<2){
				return;
			}
		}
		else{
			t = 0;
		}
}

//Copy sprite array to OAM
void CopyOAM()
{
	u16 loop;
	u16* temp;
	temp = (u16*)sprites;
	for(loop=0; loop < 128*4; loop++)
	{
		OAM[loop] = temp[loop];
	}
}

// Set sprites off screen
void InitializeSprites()
{
	u16 loop;
	for (loop = 0; loop < 128; loop++)
	{
		sprites[loop].attribute0 = 160;	//y > 159
		sprites[loop].attribute1 = 240;	//x > 239
	}
}

//move the sprite
void MoveSprite(OAMEntry* sp, int x, int y)
{
	if(x < 0)			//if it is off the left correct
		x = 512 + x;
	if(y < 0)			//if off the top correct
		y = 256 + y;

	sp->attribute1 = sp->attribute1 & 0xFE00;  //clear the old x value
	sp->attribute1 = sp->attribute1 | x;

	sp->attribute0 = sp->attribute0 & 0xFF00;  //clear the old y value
	sp->attribute0 = sp->attribute0 | y;
}

//counter structure, for creating a sprite based counter
typedef struct
{
	u16 frame[9];	//total frames
	int activeFrame;	//which frame is active
}Counter;

//Declare some sprites
Counter one;		//create an instance
Counter two;		//create an instance
Counter three;		//create an instance
Counter four;		//create an instance
Counter five;		//create an instance

//set counters to a score (less than 999)
void SetCounters(int score)
{
	int hundreds = (score/100)%10;
	int tens =(score/10)%10;
	int units =(score/1)%10;

	sprites[127].attribute2 = one.frame[hundreds];
	sprites[126].attribute2 = two.frame[tens];
	sprites[125].attribute2 = three.frame[units];
}

void SetLives(int lives)
{
	sprites[123].attribute2 = four.frame[lives%10];
	sprites[122].attribute2 = five.frame[(lives/10)%10];
}


//simple 'random' function
int random()
{	int y;
	y = list[x];
	x++;
	if(x > 31){
		x=0;
	}
	return list[y];
}

//move all sprites which are used
void MoveSprites()
{
	for(int x=0; x < size; x++){
		MoveSprite(&sprites[x], lastx[x], lasty[x]);
	}
}

//the main function of the game
void CheckCollision()
{
	//collision with the food block
	if(lastx[0] == foodx && lasty[0] == foody){
		score++;
		size++;
		foodx = random()*16;
		foody = random()*16;
		if(foody > 144){
			foody-=160;
		}
		MoveSprite(&sprites[124],foodx,foody);
	}
	//head collides with other part of the snake
	for(int x = 1; x < size; x++){
		if(lastx[0] == lastx[x] && lasty[0] == lasty[x]){
			lives--;
			for(int y=1; y < max; y++){
				lastx[y] = 240;
				lasty[y] = 160;
				MoveSprites();
			}
			walk=0;
			lastx[0] = 128;
			lasty[0] = 80;
			size=1;
		}
	}
	//reached maximum -> bonus points, extra life and cut snake
	if(size > 99){
		score+=10;
		lives++;
		size = 1;
	}
	//lives has reached zero, you are dead
	if(lives < 1){
		walk = 0;
		size = 1;
		score = 0;
		lives = 3;
		//wait a little
		SleepQ(32);
	}
}

//read the gba keypad
void GetInput()
{
	if(KEY_DOWN(KEYLEFT)){
		walk = 4;
	}
	if(KEY_DOWN(KEYRIGHT)){
		walk = 2;
	}
	if(KEY_DOWN(KEYUP)){
		walk = 1;
	}
	if(KEY_DOWN(KEYDOWN)){
		walk = 3;
	}
}

//walk, the actual move function
void Walk()
{
	t++;
	if(t > 8){
		//take over last values from the previous block
		for(int x = size; x > 0; x--){
			lastx[x] = lastx[x-1];
			lasty[x] = lasty[x-1];
		}

		//move the snake head
		if(walk == 1){
			lasty[0]-=move;
			if(lasty[0] < 0){
				lasty[0] = 144;
			}
		}
		else if(walk == 2){
			lastx[0]+=move;
			if(lastx[0] > 224){
				lastx[0] = 0;
			}
		}
		else if(walk == 3){
			lasty[0]+=move;
			if(lasty[0] > 144){
				lasty[0] = 0;
			}
		}
		else if(walk == 4){
			lastx[0]-=move;
			if(lastx[0] < 0){
				lastx[0] = 224;
			}
		}
	t=0;
	}
}

//main starting point from ROM
int main()
{
	//Enable background 2 and set mode to mode 4
	SetMode(MODE_4 | OBJ_MAP_1D | BG2_ENABLE);

	//loads the background palette
	DMACopy(3, (void*)OBJPalette, (void*)BGPaletteMem, 128, DMA_32NOW);

	//draw some pictures in mode 4 and do some fades
	FadeOut(0);
	//draw title screen, actually, just copy the data into the right memeroy position with a dma transfer
	DMACopy(3, (void *)titleData, (void *)VideoBuffer, 19200, DMA_16NOW);
	FadeIn(2);
	WaitForStart();
	FadeOut(2);

	//clear buffer
	ClearBuffer();

	int x;
	lastx[0] = 128;
	lasty[0] = 80;

	for(x=1; x < max; x++){
		lastx[x] = 240;
		lasty[x] = 160;
	}

	//load the (objects) sprite palette
	DMACopy(3, (void*)OBJPalette, (void*)OBJPaletteMem, 256, DMA_16NOW);

	InitializeSprites();

	//setup 100 green square blocks to form a snake
	for(x = 0; x < max; x++){
		sprites[x].attribute0 = COLOR_256 | SQUARE | lasty[x];
		sprites[x].attribute1 = SIZE_16 | lastx[x];
		sprites[x].attribute2 = 0;
	}

	//setup the food sprite
	sprites[124].attribute0 = COLOR_256 | SQUARE | foody;
	sprites[124].attribute1 = SIZE_16 | foodx;
	sprites[124].attribute2 = 0;

	//load block sprite image
	DMACopy(3, (void*)blockData, (void*)OAMData, 128, DMA_16NOW);

	//loads the three sprites, which will create a counter from 0 - 999
	for(x=0; x < 3; x++){
		//set up counters
		sprites[127-x].attribute0 = COLOR_256 | SQUARE | 0;
		sprites[127-x].attribute1 = SIZE_8 | x*8;
		sprites[127-x].attribute2 = 520;
	}

	//setting up frames, for counters one, two and three
	//counter one
	one.frame[0] = 520;
	one.frame[1] = 522;
	one.frame[2] = 524;
	one.frame[3] = 526;
	one.frame[4] = 528;
	one.frame[5] = 530;
	one.frame[6] = 532;
	one.frame[7] = 534;
	one.frame[8] = 536;
	one.frame[9] = 538;
	//counter two
	two.frame[0] = 520;
	two.frame[1] = 522;
	two.frame[2] = 524;
	two.frame[3] = 526;
	two.frame[4] = 528;
	two.frame[5] = 530;
	two.frame[6] = 532;
	two.frame[7] = 534;
	two.frame[8] = 536;
	two.frame[9] = 538;
	//counter three
	three.frame[0] = 520;
	three.frame[1] = 522;
	three.frame[2] = 524;
	three.frame[3] = 526;
	three.frame[4] = 528;
	three.frame[5] = 530;
	three.frame[6] = 532;
	three.frame[7] = 534;
	three.frame[8] = 536;
	three.frame[9] = 538;

	DMACopy(3,(void*)numbersData,(void*)(OAMData + 8320), 320, DMA_16NOW);

	//setup sprite attributeslives counter
	sprites[123].attribute0 = COLOR_256 | SQUARE | 0;
	sprites[123].attribute1 = SIZE_8 | 232;
	sprites[123].attribute2 = 520;

	sprites[122].attribute0 = COLOR_256 | SQUARE | 0;
	sprites[122].attribute1 = SIZE_8 | 224;
	sprites[122].attribute2 = 520;

	//setup frames for counter four and five
	//four
	four.frame[0] = 520;
	four.frame[1] = 522;
	four.frame[2] = 524;
	four.frame[3] = 526;
	four.frame[4] = 528;
	four.frame[5] = 530;
	four.frame[6] = 532;
	four.frame[7] = 534;
	four.frame[8] = 536;
	four.frame[9] = 538;
	//five
	five.frame[0] = 520;
	five.frame[1] = 522;
	five.frame[2] = 524;
	five.frame[3] = 526;
	five.frame[4] = 528;
	five.frame[5] = 530;
	five.frame[6] = 532;
	five.frame[7] = 534;
	five.frame[8] = 536;
	five.frame[9] = 538;

	//setup life icon
	sprites[121].attribute0 = COLOR_256 | SQUARE | 0;
	sprites[121].attribute1 = SIZE_8 | 216;
	sprites[121].attribute2 = 8;

	//load miniblock sprite image
	DMACopy(3, (void*)miniblockData, (void*)(OAMData+128), 32, DMA_16NOW);

	//set display mode
	SetMode(MODE_0 | OBJ_ENABLE | OBJ_MAP_1D);

	//main loop
	while(1)
	{
		GetInput();			//read the gba keypad
		Walk();				//move the snake into one direction
		CheckCollision();			//is the food eaten?
		MoveSprites();			//move all sprites
		WaitForVsync();			//wait for the screen to stop drawing
		CopyOAM();			//copies sprite data
		SetCounters(score);			//set the counters 3 digits
		SetLives(lives);			//set the live counter 2 digits
	}


}
