/**********************************************\
*       miniblock.h                                   *
*          by dovotos pcx->gba program         *
/**********************************************/
#define  miniblock_WIDTH   8
#define  miniblock_HEIGHT  8


const u16 miniblockData[] = {
                    0x1C00, 0x1C1C, 0x1C1C, 0x001C, 0x101C, 0x1010, 0x1010, 0x1C10, 0x101C, 0x1010,
                    0x1010, 0x1C10, 0x101C, 0x1010, 0x1010, 0x1C10, 0x101C, 0x1010, 0x1010, 0x1C10,
                    0x101C, 0x1010, 0x1010, 0x1C10, 0x101C, 0x1010, 0x1010, 0x1C10, 0x1C00, 0x1C1C,
                    0x1C1C, 0x001C,};
