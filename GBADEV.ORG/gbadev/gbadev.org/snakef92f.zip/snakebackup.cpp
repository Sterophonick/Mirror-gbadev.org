////////////////////////////////////////////////////////////////////////////
//File:		snake.cpp
//Description:	the classic snake game
//Date:		27 - 04 - 2003
//Author:		Jenswa
//Thanks to:	gbajunkie, dovoto and nokturn
////////////////////////////////////////////////////////////////////////////


//general declarations
#include "gba.h"		//GBA register definitions
#include "dispcnt.h"		//REG_DISPCNT register defines
#include "keypad.h"	//keypad defines
#include "sprites.h"		//sprite defines

//dma stuff
#include "dma.h"		//dma defines
#include "dma.c"		//dma copy function

//gfx
#include "objpalette.h"	//normal mspaint 256 colour palette
#include "numbers.h"	//number 0 - 9
#include "block.h"		//green block for the snake

//other stuff
#include "list.c"		//my predefined 'random' list


//create an OAM variable and make it point to the address of OAM
u16* OAM = (u16*)0x7000000;

//create the array of sprites (128 is the maximum)
OAMEntry sprites[128];


int xpos = 120;		//x from the snake top
int ypos = 80;		//y from the snake top
int move = 16;		//pixel it moves per turn
int walk = 0;		//to decide what direction the snake is going
int t = 0;			//t used as timer (could also have used build in timer)
int score = 0;		//score
int lives = 3;		//lives
int x =0;			//to walk trough my predifened 'random' array

int foodx = 32;		//x from the food
int foody = 48;		//y from the food


//wait for the screen to stop drawing
void WaitForVsync()
{
	while((volatile u16)REG_VCOUNT != 160){}
}

//Wait until the start key is pressed
void WaitForStart()
{

	u8 t=0;		//used for detecting a single press

	while (1)
		if( KEY_DOWN(KEYSTART) )
		{
		t++;
			if(t<2){
				return;
			}
		}
		else{
			t = 0;
		}
}

//Copy sprite array to OAM
void CopyOAM()
{
	u16 loop;
	u16* temp;
	temp = (u16*)sprites;
	for(loop=0; loop < 128*4; loop++)
	{
		OAM[loop] = temp[loop];
	}
}

// Set sprites off screen
void InitializeSprites()
{
	u16 loop;
	for (loop = 0; loop < 128; loop++)
	{
		sprites[loop].attribute0 = 160;	//y > 159
		sprites[loop].attribute1 = 240;	//x > 239
	}
}

//move the sprite
void MoveSprite(OAMEntry* sp, int x, int y)
{
	if(x < 0)			//if it is off the left correct
		x = 512 + x;
	if(y < 0)			//if off the top correct
		y = 256 + y;

	sp->attribute1 = sp->attribute1 & 0xFE00;  //clear the old x value
	sp->attribute1 = sp->attribute1 | x;

	sp->attribute0 = sp->attribute0 & 0xFF00;  //clear the old y value
	sp->attribute0 = sp->attribute0 | y;
}

//counter structure, for creating a sprite based counter
typedef struct
{
	u16 frame[9];	//total frames
	int activeFrame;	//which frame is active
}Counter;

//Declare some sprites
Counter one;		//create an instance
Counter two;		//create an instance
Counter three;		//create an instance

//set counters to a score (less than 999)
void SetCounters(int score)
{
	int hundreds = (score/100)%10;
	int tens =(score/10)%10;
	int units =(score/1)%10;

	sprites[127].attribute2 = one.frame[hundreds];
	sprites[126].attribute2 = two.frame[tens];
	sprites[125].attribute2 = three.frame[units];
}

//move all sprites which are used
void MoveSprites()
{
	MoveSprite(&sprites[0], xpos, ypos);
}

//simple 'random' function
int random()
{	int y;
	y = list[x];
	x++;
	if(x > 31){
		x=0;
	}
	return list[y];
}

//the main function of the game
void CheckCollision()
{

	if(xpos == foodx && ypos == foody){
		score++;
		foodx = random()*16;
		foody = random()*16;
		if(foody > 144){
			foody-=160;
		}
		MoveSprite(&sprites[1],foodx,foody);
	}

}

//read the gba keypad
void GetInput()
{
	if(KEY_DOWN(KEYLEFT)){
		walk = 4;
	}
	if(KEY_DOWN(KEYRIGHT)){
		walk = 2;
	}
	if(KEY_DOWN(KEYUP)){
		walk = 1;
	}
	if(KEY_DOWN(KEYDOWN)){
		walk = 3;
	}
}

//walk, the actual move function
void Walk()
{
	t++;
	if(t > 8){
		if(walk == 1){
			ypos-=move;
			if(ypos < 0){
				ypos = 144;
			}
		}
		else if(walk == 2){
			xpos+=move;
			if(xpos > 224){
				xpos = 0;
			}
		}
		else if(walk == 3){
			ypos+=move;
			if(ypos > 144){
				ypos = 0;
			}
		}
		else if(walk == 4){
			xpos-=move;
			if(xpos < 0){
				xpos = 224;
			}
		}
	t=0;
	}
}

//main starting point from ROM
int main()
{
	int x;

	//load the (objects) sprite palette
	DMACopy(3, (void*)OBJPalette, (void*)OBJPaletteMem, 256, DMA_16NOW);

	InitializeSprites();

	//setup the snake sprite
	sprites[0].attribute0 = COLOR_256 | SQUARE | ypos;
	sprites[0].attribute1 = SIZE_16 | xpos;
	sprites[0].attribute2 = 0;

	//setup the food sprite
	sprites[1].attribute0 = COLOR_256 | SQUARE | foody;
	sprites[1].attribute1 = SIZE_16 | foodx;
	sprites[1].attribute2 = 0;

	//loads block sprite image
	DMACopy(3, (void*)blockData, (void*)OAMData, 128, DMA_16NOW);

	//loads the three sprites, which will create a counter from 0 - 999
	for(x=0; x < 3; x++){
		//set up counters
		sprites[127-x].attribute0 = COLOR_256 | SQUARE | 0;
		sprites[127-x].attribute1 = SIZE_8 | x*8;
		sprites[127-x].attribute2 = 520;
	}

	//setting up frames, for counters one, two and three
	//counter one
	one.frame[0] = 520;
	one.frame[1] = 522;
	one.frame[2] = 524;
	one.frame[3] = 526;
	one.frame[4] = 528;
	one.frame[5] = 530;
	one.frame[6] = 532;
	one.frame[7] = 534;
	one.frame[8] = 536;
	one.frame[9] = 538;
	//counter two
	two.frame[0] = 520;
	two.frame[1] = 522;
	two.frame[2] = 524;
	two.frame[3] = 526;
	two.frame[4] = 528;
	two.frame[5] = 530;
	two.frame[6] = 532;
	two.frame[7] = 534;
	two.frame[8] = 536;
	two.frame[9] = 538;
	//counter three
	three.frame[0] = 520;
	three.frame[1] = 522;
	three.frame[2] = 524;
	three.frame[3] = 526;
	three.frame[4] = 528;
	three.frame[5] = 530;
	three.frame[6] = 532;
	three.frame[7] = 534;
	three.frame[8] = 536;
	three.frame[9] = 538;

	DMACopy(3,(void*)numbersData,(void*)(OAMData + 8320), 320, DMA_16NOW);

	//set display mode
	SetMode(MODE_0 | OBJ_ENABLE | OBJ_MAP_1D);

	//main loop
	while(1)
	{
		GetInput();			//read the gba keypad
		Walk();				//move the snake into one direction
		MoveSprites();			//move all sprites
		CheckCollision();			//collision stuff
		WaitForVsync();			//wait for the screen to stop drawing
		CopyOAM();			//copies sprite data
		SetCounters(score);			//set the counters to something
	}


}
