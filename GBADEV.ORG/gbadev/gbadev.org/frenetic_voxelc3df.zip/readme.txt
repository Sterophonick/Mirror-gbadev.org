Hi there !

what ?
------

This is the readme for my first gba program GBAVoxel 1.0. It uses a
quite traditional way of rendering voxel landscapes, although it
is not very common that you can look up/down in most other voxel
implementations. It uses a 256x256 pixel heightmap (8 bit), and the
some resolution for the color map. It runs in mode 4, fullscreen ;) 
at 120x160 pixels, which are all set during rendering of one frame.
I didn't measure the frame rate, but it seems to be quite satisfiing.
At least for the not optimized code I wrote. A propos optimizing:
the raycasting routines use a simplified form of quadtree structure
for faster search for mountains you know ;)

you don't have to rip the raycasting routine (which is placed
at 0x0300... ;) ) because i'll release the code anyway, when it's
finished and cleaned up. as i told you, it's my first gba program,
and the stuff i know, came from other people and examples. therefore
i think it's only fair to share the source...

what will come next ? 
---------------------

- i think i badly need some sort of sky... perhaps sprites will work. 
  never tried sprite programming on gba before *g*
- the rotation around the viewing axis is no problem, since the gba
  hardware would do that for us... only have to code that...

credits
-------
landscape
		as far as i remember some popular game...
		
inopia, neon, and all the others
		aswering many many questions
		
Dark Fader
		dev kit and examples

title screen
		i think it a terragen landscape, i found on the web

me
		the code ;)


for any comment, you can contact me via carsten@dachsbacher.de