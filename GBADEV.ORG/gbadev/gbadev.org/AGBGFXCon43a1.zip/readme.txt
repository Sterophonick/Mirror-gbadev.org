Gameboy Advance graphics converter utility, by sweetlicks 2001.

Hello, I've decided to release this version of a utility I programmed several months back.
This isn't the latest version of the utility, as it couldn't be released to the public, and
eventually it got formatted and lost anyway. So I've resurrected this version and fixed some
bugs in it. However there are still bugs in the mode0-2 character mapping conversions -
the unique tile routine appears to miss certain tiles, so holes can 'sometimes' appear in
maps. Theres meant to be support for iff lbm images from dpaint/promotion, but it doesn't work
in this version. I'm not sure what the faults are and I haven't had time to fix them - but the
bitmap modes work okay. The source code won't be released, as it's very messy and needs a
re-write :O)

Infact, I might code a much better tool soon, but then I use this at work - so it can't be all
that bad :)

Instructions: well the tool is pretty self explanatory - so just poke around with it.

I'm quite busy with work at the moment, but will try to answer emails at licksweets@yahoo.co.uk

Greets to #gbadev and all the happy coders out there!