-------------------------
Arkanoid Demo
-------------------------

File:		score_sprite.bin
Program:		Score example using sprites (can also be done with background)
Author:		Johan Jansen (Jenswa)
Contact:		awsnej@hotmail.com
Site:		http://www.geocities.com/flashsite_jrj/gba
		

-----------------------------
About this bin-file:
This is my 4th gba-demo, it's to understand the programming in c
and also because don't have much knowledge of the gba.
But, I don't know what command they use for substring in c,
so I had to do the same but then in 10 lines of code instead of 1 or 2.
If someone nows, perhaps he can email(awsnej@hotmail.com) it to me, thanx.
I'm following gbajunkies tutorials, they're great!

I built this demo for understanding displaying scores at the gba,
gbajunkie told me that I should use bg tiles for displaying, score.
But I am not quite familair with bg (can display bg and sprite at the same time).
So I thought, what does it matter I use 8x8 tiles bg or 8x8 sprites ?
And what happend, I created a score counter,
that I can use for my arkanoid demo which I am working on now.

Added variable x to slow score counting down.

---------------
Features:
Score counter from 0 to 99 and starts over again.
Two 8x8 counters from 0 to 9.
One 8x32 sprite for the text: score.

----------------
Thanks to:

Forgotten (VisualBoyAdvance, great emulator!)
Jason Wilkins (Dev-Kit Advance, nice comiler set)
Eloist (gba.h)
GBAjunkie (tutorial, dovoto, dispcnt.h, sprite_info.h, great tutorials!)
Dovoto (pcx2sprite, dispcnt.h, sprite_info.h)
Noktrun (keypad.h)
GBADEV.org (they have lots of sources and updates around gba, always usefull)
devrs.com/gba (they are just like gbadev.org, comes in handy)
----------------
Jenswa

