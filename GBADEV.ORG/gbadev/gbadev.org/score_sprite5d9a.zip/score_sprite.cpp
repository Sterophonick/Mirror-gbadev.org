/////////////////////////////////////////////
//sprite_score.cpp
//Jenswa
//Score example using sprites
//Thanks to: Gbajunkie, Dovoto, Eloist, Nokturn
////////////////////////////////////////////

#include "gba.h"	//GBA register definitions
#include "keypad.h"  //button registers
#include "dispcnt.h"    //REG_DISPCNT register #defines
#include "sprite_info.h" //sprite definitions
#include "palette.h"   //palette data
#include "numbers.h" //numbers 0 to 9
#include "text.h" //text: score


//create an OAM variable and make it point to the address of OAM
u16* OAM = (u16*)0x7000000;

//create the array of sprites (128 is the maximum)
OAMEntry sprites[128];

//declare ypos and xpos
s16 xpos = 32;
s16 ypos = 0;

s16 xpos2 = 40;
s16 ypos2 = 0;

s16 xpos3=0;
s16 ypos3=0;

s8 score = 0;
s16 x = 0;

//Copy sprite array to OAM
void CopyOAM()
{
	u16 loop;
	u16* temp;
	temp = (u16*)sprites;
	for(loop=0; loop < 128*4; loop++)
	{
		OAM[loop] = temp[loop];
	}
}

//sprite strucure, for animation of the sprite
typedef struct
{
	u16 xpos;		//x position
	u16 ypos;		//y position
	u16 spriteFrame[9];	//total frames
	int activeFrame;	//which frame is active
}Sprite;

Sprite number1;		//create an instance
Sprite number2;		//create an instance

//Adding 1 to score
void Addscore()
{
x+=1;
if(x == 128)
{
score+=1;
x = 0;
		if(score < 10)
		{
		number2.activeFrame=score;
		}
		if( (score > 9) && (score < 20) )
		{
		number2.activeFrame = score-10;
		number1.activeFrame = 1;
		}
		if( (score > 19) && (score < 30) )
		{
		number2.activeFrame = score-20;
		number1.activeFrame = 2;
		}
		if( (score > 29) && (score < 40) )
		{
		number2.activeFrame = score-30;
		number1.activeFrame = 3;
		}
		if( (score > 39) && (score < 50) )
		{
		number2.activeFrame = score-40;
		number1.activeFrame = 4;
		}
		if( (score > 49) && (score < 60) )
		{
		number2.activeFrame = score-50;
		number1.activeFrame = 5;
		}
		if( (score > 59) && (score < 70) )
		{
		number2.activeFrame = score-60;
		number1.activeFrame = 6;
		}
		if( (score > 69) && (score < 80) )
		{
		number2.activeFrame = score-70;
		number1.activeFrame = 7;
		}
		if( (score > 79) && (score < 90) )
		{
		number2.activeFrame = score-80;
		number1.activeFrame = 8;
		}
		if( (score > 79) && (score < 90) )
		{
		number2.activeFrame = score-80;
		number1.activeFrame = 8;
		}
		if( (score > 89) && (score < 99) )
		{
		number2.activeFrame = score-90;
		number1.activeFrame = 9;
		}
		if(score > 99)
		score = 0;

sprites[0].attribute2 = number1.spriteFrame[number1.activeFrame];
sprites[1].attribute2 = number2.spriteFrame[number2.activeFrame];
}
}

// Set sprites off screen
void InitializeSprites()
{
	u16 loop;
	for (loop = 0; loop < 128; loop++)
	{
		sprites[loop].attribute0 = 160;	//y > 159
		sprites[loop].attribute1 = 240;	//x > 239
	}
}

//wait for the screen to stop drawing
void WaitForVsync()
{
	while((volatile u16)REG_VCOUNT != 160){}
}

int main()
{
	u16 loop;	//generic loop variable


	SetMode(MODE_1 | OBJ_ENABLE | OBJ_MAP_1D);

	for(loop = 0; loop < 256; loop++)		//load palette into memory
	OBJPaletteMem[loop] = Palette[loop];


	InitializeSprites();

	sprites[0].attribute0 = COLOR_256 | SQUARE | ypos;
	sprites[0].attribute1 = SIZE_8 | xpos;
	sprites[0].attribute2 = 0;			//pointer to tile where sprite starts

	number1.spriteFrame[0] = 0;
	number1.spriteFrame[1] = 2;
	number1.spriteFrame[2] = 4;
	number1.spriteFrame[3] = 6;
	number1.spriteFrame[4] = 8;
	number1.spriteFrame[5] = 10;
	number1.spriteFrame[6] = 12;
	number1.spriteFrame[7] = 14;
	number1.spriteFrame[8] = 16;
	number1.spriteFrame[9] = 18;
	number1.activeFrame = 0;

for(loop = 0; loop < 320; loop++)		//load sprite image data
{
	OAMData[loop] = numbersData[loop];
}

	sprites[1].attribute0 = COLOR_256 | SQUARE | ypos2;
	sprites[1].attribute1 = SIZE_8 | xpos2;
	sprites[1].attribute2 = 0;			//pointer to tile where sprite starts

	number2.spriteFrame[0] = 0;
	number2.spriteFrame[1] = 2;
	number2.spriteFrame[2] = 4;
	number2.spriteFrame[3] = 6;
	number2.spriteFrame[4] = 8;
	number2.spriteFrame[5] = 10;
	number2.spriteFrame[6] = 12;
	number2.spriteFrame[7] = 14;
	number2.spriteFrame[8] = 16;
	number2.spriteFrame[9] = 18;
	number2.activeFrame = 0;

for(loop = 0; loop < 320; loop++)		//load sprite image data
{
	OAMData[loop] = numbersData[loop];
}

	sprites[2].attribute0 = COLOR_256 | TALL | ypos3;
	sprites[2].attribute1 = SIZE_16 | xpos3;
	sprites[2].attribute2 = 20;			//pointer to tile where sprite starts

for(loop = 320; loop < 448; loop++)		//load sprite image data
{
	OAMData[loop] = textData[loop-320];
}


	while(1)		//main loop
	{
		Addscore();		//adds one to number1
		WaitForVsync();		//waits for the screen to stop drawing
		CopyOAM();		//copies sprite array into memory
	}
}

