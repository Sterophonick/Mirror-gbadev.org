 .-''{ kunterbunt }''-.
!. a simple fx screen .!
!..for gameboy advance.!
!...       by       ...!
!.. exoticorn/icebird..!
!.                    .!
!..  .jpeg^plasma..  ..!
!......................!
!......   ....   ......!
!...                ...!
!..gfx by gizmo/icbird.!
!.         ..         .!
 '-.....--'  '--.....-'

"everything in beautiful
32 bit assembler code.."

  tested on gbaemu and
      real hardware
   real hw recommended