THE SEARCH FOR SHADOW
PLAYABLE DEMO


INSTRUCTIONS

Press A to begin the game.

Use the Control Pad to move.
Press A to use objects, enter doors, talk, etc.
Press B to Swing the Sword.
Press R to use the Mask's special function.

Press Select to bring up the Mask select menu.
Press Left and Right to Select a Mask.
Press A to wear the Selected Mask.

This game features the first playable dungeon.
Collect the Statue's Missing Fingers from 
chests within the dungeon.
Return the Fingers to the State to collect
the final mask.


NOTES

This is my fifth GBA demo and my second GBA game.

This project took approximately 5 weeks of rather hard work.  I hope you all enjoy playing the demo.  

All of the game is running on a generic engine so adding new Dungeons will be very easy.  However, I am going to need some encouragement from those who play the game.  Please let me know if you have liked the game, or even if you haven't.  Tell me what you want to see...

I am currently seeking employment as a Full Time GBA Programmer.  I hope those in the industry like this demo enough to offer me a position.  Please let me know if you could use me.

I also feel that this Demo is of high enough quality to warrant an official release.  If anyone is interested in publishing the full version of The Search For Shadow, please contact me.

There is no sound as there is no good unofficial documentation on playing multiple sound samples.  This game has been designed with sound in mind, and some of the rooms puzzles may be a little tricky because of this.  I apologise.

The demo runs on real Hardware and all Emulators that I have tested.

Also thanks always to Matt Tighe for the PCX2GBA program, to AGENTQ for his technical documentation, and also hats off the the Pern Project.  Thank you for your site, it has been very very useful...

Thanks also to WWW.GBAEMU.COM and WWW.GBADEV.ORG.  Your time and effort is appreciated.

Finally, don't forget to download my other game "Swallow Gulch".  You can find it at my website along with my other demos...


The Letter M
hallmb@yahoo.com
http://users.bigpond.net.au/theletterm