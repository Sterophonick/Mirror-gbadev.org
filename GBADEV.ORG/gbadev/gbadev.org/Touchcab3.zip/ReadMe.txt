Touch! Readme file

PLEASE ENCLOSE THIS FILE WHEN DISTRIBUTING THE TOUCH! PACKAGE
The package Touch.zip contains: touch.gba and ReadMe.txt

This program was successfully tested on VisualBoyAdvance 1.3.1 and an actual GBA.

The playing instructions are located in the instructions section of the game.

This game is free for personal (NON COMMERCIAL) use on your GBA and/or GBA emulator.

DISCLAIMER!
I am not responsible for any possible loss of data or damage to you or any equipment.  That is to say if you're driving a car and playing Touch! on your GBA and get into an accident IT'S NOT MY FAULT. 

If you wish, send me your thoughts (good and bad are welcome), or questions about TOUCH! or just let me know you've tried the game.

I hope you enjoy it.

Dave Mejia
J_Dave_Mejia@yahoo.com
