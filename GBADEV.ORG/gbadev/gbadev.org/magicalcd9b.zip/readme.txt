Hi


Here is a demo of a remake of MagicalChase for the GBA, release in 1988 for PcEngine
I take the sprites sheets and the background of the game , mix with some new fresh style.......

The demo include CodeWave but do not run actually ( problem with interrupt , the sound s is disynchronise )

Actually i do not send ennemis automaticly, you must push Start button to call ennemlis wave ( 3 differents waves available )

I like you to check the Title Screen witch work in full mode 7
you can use :

	Left   :  Decal Left
	Right  :  DecalRight
	R      :  Rotate Right
	L      :  Rotate Left
	A      :  Go Up
	B      :  Go Down
	Start  :  Begin the game
	
While in the Game :

	R      :  Upgrade the Background blend
	L      :  Downgrade ( ??? ) the background blend  
	A      :  Shoot ( max of 5 shoot at the same time )
	B      :  Special power
	Start  :  Call a new wave of ennemis ( actually , 3 waves are calculated )
	Select :  Special Fire
	
	
I 'd like you to send me your impression about this game
at

matthieu_debray@hotmail.com
or
mdebray@hotmail.com


And if someone can tell me why with VisualBoy advance the Interrupts works well and with the Real Gameboy hardware this don't works......

hey, a last thing
I'm a french guy from Paris 
27 years old
Informatician .... ( that's sure ;o) )

bye