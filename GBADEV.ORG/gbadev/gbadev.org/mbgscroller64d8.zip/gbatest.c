//Scrolling Background Demo
//by Martin
//
//E-Mail mjjw@yahoo.com
//
//Everything I have learned about AGB comes from reading, examining and
//playing with the source codes availible on www.gbadev.org, as well
//as reading all of the documentation availible there.
//
//If I have made any mistakes in my source code, then please e-mail me
//and tell me. Or if you have any questions on how it all works then
//also e-mail me. I will try my best to respond to all e-mails sent,
//although it may sometimes take a while depending on how full my Inbox
//is from day to day.
//
//I started this project to discover more about how backgrounds work
//on the GBA. I have tried to document it as well as possible so that
//other people may read this and learn also what is happening.
//
//Still left to do ... Two Backgrounds scrolling parrallax style
//and of course, multiple maps with A and B buttons to move between them
//with each individual map stored in cart ram, and the current used
//map stored in external ram for extra speed.
//
//Also the scroll function should be called from internal cpu ram
//but I haven't a clue of hoiw to do this, or any examples from
//which to learn ... any ideas? please feel free to mail me!

#include <stdio.h>

#define DISPCNT      *(u16*)0x04000000 //The display control register
#define BG0CNT       *(u16*)0x04000008 //Background 0 Control register
#define BG0HOFS	     *(u16*)0x04000010 //Background 0 H-Offset
#define BG0VOFS	     *(u16*)0x04000012 //Background 0 V-Offset
#define P1           *(u16*)0x04000130 //JoyPad 1
#define BIT00 1 //Some bit defines direct from Nokturns KeyDemo
#define BIT01 2 //Needed for the keyboard entry code
#define BIT02 4
#define BIT03 8
#define BIT04 16
#define BIT05 32
#define BIT06 64
#define BIT07 128
#define BIT08 256
#define BIT09 512
#define BIT10 1024
#define BIT11 2048
#define BIT12 4096
#define BIT13 8192
#define BIT14 16384
#define BIT15 32768
#define maxmapx 31 //define the width of the map
#define maxmapy 21 //define the height of the map
//these are defined here rather than hard coded so that they can
//easily be changed if the map array is changed.

//next we define some locations for variables within external ram
#define worldx 0 //stores the x value of the topleft tile displayed
#define worldy 2 //stores the y value of the topleft tile displayed
#define vofs 4 //current vertical offset
#define hofs 6 //current horizontal offset
#define sfac 8 //scroll factor - holds number of pixels to scroll

typedef unsigned char u8;
typedef unsigned short u16;

//here we must setup some memory addresses in which to send data
u16 *pal=(u16*)0x5000000;
u8 *tiledata=(u8*)0x06004000;
u16 *tilemap=(u16*)0x6000000;

//most important of all - a pointer to external working ram
//this is needed because stupid ARM compiler tries to keep
//global variables in cart ram where they are read-only (duh!)
//so we must force them into external ram

//I guess they could go in internal ram, but I decided to
//start with external as there is more of it and I may need
//a lot of space in the end (who knows what this will become)
//and I also my need internal ram for something more important
//(who knows???)

u16 *extram=(u16*)0x02000000;

//now to include the external files we need to use
extern u8 bgblocks; //the actual blocks
extern u16 bgpal;   //the background pallete

//next comes the MapMatrix - this was created using warder1s
//map editor program. The output was pasted directly in, with
//very few changes. the line:
//const u8 MapMatrix[ 30 * 20 ] = {
//was changed to the one seen below
//Also, as my tile engine uses 16x16 tiles, and the map tool
//only allows 8x8 tiles, I created two tilesets, one is 16x16
//that the tile engine uses, the other is the same tiles shrunk to
//8x8 for use in the map editor tool

const u8 MapMatrix[21][31] = {
1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,
1,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,1,
1,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,1,
1,2,2,1,1,1,1,1,1,2,2,1,1,1,1,1,2,2,2,2,1,1,1,1,1,2,2,1,2,2,1,
1,2,2,1,2,2,2,2,1,2,2,1,2,2,2,2,1,2,2,1,2,2,2,2,2,1,2,1,2,2,1,
1,2,2,1,2,2,2,2,1,2,2,1,2,2,2,2,1,2,2,1,2,2,2,2,2,1,2,1,2,2,1,
1,2,2,1,2,2,2,2,1,2,2,1,2,2,2,2,1,2,2,1,2,2,2,2,2,1,2,1,2,2,1,
1,2,2,1,2,2,2,2,2,2,2,1,2,2,2,2,1,2,2,1,2,2,2,2,2,1,2,1,2,2,1,
1,2,2,1,2,2,2,2,2,2,2,1,1,1,1,1,2,2,2,1,1,1,1,1,1,1,2,1,2,2,1,
1,2,2,1,2,2,1,1,1,2,2,1,2,2,2,2,1,2,2,1,2,2,2,2,2,1,2,1,2,2,1,
1,2,2,1,2,2,2,2,1,2,2,1,2,2,2,2,1,2,2,1,2,2,2,2,2,1,2,2,2,2,1,
1,2,2,1,1,1,1,1,1,2,2,1,1,1,1,1,2,2,2,1,2,2,2,2,2,1,2,1,2,2,1,
1,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,1,
1,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,1,
1,2,2,2,2,2,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,2,2,2,2,2,1,
1,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,1,
1,2,2,2,2,2,2,2,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,2,2,2,2,2,2,2,1,
1,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,1,
1,2,2,2,2,2,2,2,2,2,1,1,1,1,1,1,1,1,1,1,1,2,2,2,2,2,2,2,2,2,1,
1,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,1,
1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,

};

//The next function is called at the start of the running of the
//program. It simply copies the tile and pallete data to an appropriate
//place in VRAM.

void CopyTileData()
{
	
	u8 *bg_data;
	u16 counter;
	u16 *tmp_pal;

   	bg_data = (u8*)(&bgblocks);
   	tmp_pal = (u16*)(&bgpal);

//I could have used DMA transfer here, but a for loop is easier
//for people to understand.

//pal is the actual pallete in vram and tmp_pal is the pallete resource file

   	for (counter=0;counter<256;counter++) pal[counter]=tmp_pal[counter];

//tiledata is where the tiledata is going in VRAM nd bg_data is the tiledata resource file

   	for (counter=0;counter<9*64;counter++) tiledata[counter]=bg_data[counter];
		
}

void Init()
{

//Okay, I'll try and explain what is going on here as best as possible

//First, we are setting certain registers up. For those of you who
//don't know how the BG0CNT and DISPCNT registers work, I have broken
//down what the below values mean.

//Sorry for the really long explanation - but if you don't understand
//the hex values that DISPCNT and BG0CNT etc are set to in some demos,
//then read on. I have explained in as much detail as I have knowledge of.

//BG0CNT is first set to 0x0084 - which we from 0000000010000100 in binary
//taking the furthest righthand bit as bit 0, it works as follows.
//bits 0 and 1 set the priority of the background layer - so the priority
//is 00 (0 is highest priority - 11 (3 in decimal) is the lowest).
//bits 2 and 3 set where the character is located in VRAM. This can be
//anything from 00 to 11 (0-3) and says which 16k boundary our tiledata
//is stored at. (00 is with no offset, 01 is 16k offset, 10 is 32k offset
//and 11 is a 48k offset). Here we have a 16k offset in VRAM, hence
//why tiledata is set to point to 0x6004000
//bits 4 and 5 are unused and always set to 0
//bit 6 sets whether mosaic is turned on or off - here it is turned off (0)
//bit 7 says what colour mode the BG layer uses (0 = each tile references
//one of sixteen 16 colour pallettes, 1 = tiles all use a single 256 colour
//pallette. We use a single 256 colour pallete here.
//bits 8 to 12 specify the area in VRAM where the screen data is stored.
//A value of 0000 means at the start of VRAM, 0001 means start of VRAM +2kbyte
//0010 means start of VRAM +4kbyte, 0011 means start of VRAM +6kbyte and so on
//all of the way up to 1111 (31 in decimal) which gives VRAM +62Kbyte
//In this example we use 0000, and as such tilemap points to 0x06000000, which
//is the start of VRAM
//bit 13 is only used for backgrounds 2 and 3 and so is unused here
//bits 14 and 15 set the size of out virtual screen which we can scroll into
//by using the BG0HOFS and BG0VOFS registers.
//It is set as follows - 00 is 256x256, 01 is 512x256, 10 is 256x512 and
//a setting of 11 is 512x512. In this demo we use a 256x256 screen. which is more
//than enough for what we need.

//Next we set DISPCNT to be equal to 0x0140 this is 0000000101000000 in binary.
//again, taking the furthest bit to the right as 0, counting upto 15 on the left,
//it works as follows ...
//bits 0-2 set the background mode. You my have heard people reference terms like
//mode 0 or mode 4 - using these three bits one of 5 background modes may be selected.
//mode 0 gives us 4 Backgrounds with all of the gizmos the big N provide us with,
//with the exception of rotation and scaling. As no rotation or scaling are required,
//mode 0 is more than adequate for the task in hand.
//bit 3 is and should always be set to 0
//bit 4 is only useful for bitmap mode (modes 3-5) and selects which frame buffer
//is displayed, so here we set it to be equal to 0
//bit 5 selects whether the AGB will do OBJ processing during HBlank. A setting
//of 1 allows OBJ and OAM ram to be altered during H-Blank, however results in
//slower OBJ performance by the AGB.
//bit 6 selects whether characters stored in VRAM are stored with 1 dimension or 2.
//As our files on disk contain 2 dimensional data outputed by sprite stripper and hackit
//we set this to 1 (2 dimensional data).
//bit 7, when set forces the display to go blank. hint - don't set this bit to a 1
//unless you are seriously altering the VRAM with some slow code or something and
//need to blank the display.
//bits 8-12 set which layers are displayed (1 = displayed, 0 = off)
//bit 08 - BG0
//bit 09 - BG1
//bit 10 - BG2
//bit 11 - BG3
//bit 12 - OBJ
//here bit 8 is set to 1, and the rest to 0, as we are only using BG0
//bits 13-15 are used for setting window displays. As we do not use or need windows
//for this program they are set to 0.

	BG0CNT = 0x0084;
	DISPCNT = 0x0140;

	BG0VOFS = 0;       //Set the vertical offset to 0
	BG0HOFS = 0;       //And also set the horizontal offset to 0

	extram[hofs]=0;    //hofs and vofs are kept to be the same as
	extram[vofs]=0;    //the BG0HOFS and BG0VOFS and the function
                           //offsync() syncronises them. This is because
                           //we need to check the values of BG0HOFS and
                           //BG0VOFS but these registers are readonly.

	extram[worldx]=0;  //worldx,worldy are the co-ordinates of the
	extram[worldy]=0;  //topleft map tile displayed - this sets us to the
                           //topleft of the map.

        extram[sfac]=1;    //set the scroll factor to 1 - we move 1 pixel each time
                           //we press a key.
}


//this was taken wholesale from the fire effect demo - why reinvent the wheel?
void vsync()
{

  __asm
   {
    mov 	r0, #0x4000006
    scanline_wait:
     ldrh	r1, [r0]
     cmp	r1, #160
    bne 	scanline_wait
   }
}

//The next function is fairly straightforward - it doesn't take a brain the size
//of a planet to figure out what it is doing.
void offsync()
{
BG0HOFS=extram[hofs];
BG0VOFS=extram[vofs];
}


//However the next function is anything but straightforward.
//Basically, we run through mapx and mapy - 32 tiles accross
//and 22 tiles down. The two nested for loops accomplish this.
//we go through the tiles four at a time because my tile engine
//works with 16x16 tiles, while the BG data is 8x8 tiles.

//the four lines inside the for loops work as follows

//firstly, we go to the correct location on screen - mapy*32
//will take us down mapy number of lines  - there are afterall
//32 tiles accross (address are stored serially in memory -
//so you cant just say x,y).
//we then set this location of the screen to be equal held in the
//MapMatrix at an appropriate place - so worldx,worldy with half
//the current mapx and mapy value added - halved because mapx and
//mapy goes from 0 to 31 because the screen has 8x8 blocks, however
//out map references 16x16 tiles - so there are half as many.

//we then -1 the resulting number and multiply that number by 4.
//this gives us the first block in VRAM of the 4 required to
//make up our 16x16 (four 8x8's to make one 16x16).
//so if block 0 is unused, and blocks 1,2,3 and 4 make up tile 1
//and blocks 5,6,7,8 make up tile 2 - and we want tile 2 then the
//maths works as follows: 2 take away 1 is 1 ... multiply 1 by 4 and
//we get 4 the four lines then each add 1,2,3 and 4 in turn to this
//to get 5,6,7 and 8 - the four blocks required to display tile 2

void drawmap()
{

u16 mapx,mapy;

	for (mapx=0;mapx<32;mapx=mapx+2)
	{
		for(mapy=0;mapy<22;mapy=mapy+2)
		{
		tilemap[ mapy   *32+ mapx   ]=((MapMatrix[extram[worldy]+(mapy/2)][extram[worldx]+(mapx/2)]-1)*4)+1;
		tilemap[ mapy   *32+(mapx+1)]=((MapMatrix[extram[worldy]+(mapy/2)][extram[worldx]+(mapx/2)]-1)*4)+2;
		tilemap[(mapy+1)*32+ mapx   ]=((MapMatrix[extram[worldy]+(mapy/2)][extram[worldx]+(mapx/2)]-1)*4)+3;
		tilemap[(mapy+1)*32+(mapx+1)]=((MapMatrix[extram[worldy]+(mapy/2)][extram[worldx]+(mapx/2)]-1)*4)+4;
		}
	}
}

//This is the hardest of them all to describe what it does.
//firstly, direction is 1 for up, 2 for right, 3 for down and
//4 for left.
//pixels is an integer containing the number of pixels we wish to scroll
//in the given direction.
//each time we move a pixel we test to see if we have reached either edge of
//our 1 tile buffer zone around the edge of the screen - if we are not on the
//edge of the buffer zone then we add or take away 1 from the correct offset register.
//(here set as vofs and hofs - synchronised at the end because we need to be able to
//check the value of the register, but BG0HOFS and BG0VOFS are readonly memory addresses).
//if we reach the edge then we change worldx or worldy accordingly and redraw the screen.
//we then set the offset to a correct new value - so if it was at 0, and  new row of tiles
//has been added to the far left hand side (worldx=worldx-1) then to get the illusion of
//scrolling just one pixel left, and not 1 row of tiles left, the offset must go 1 whole
//tile minus one pixel (for the pixel we have scrolled) pixels to the right.
//All of this is done in the VBlank period so that the illusion of beatuifully
//smooth scrolling around the entire map is attained, when in reality only one
//row and column of tiles more than can be seen on screen are held in VRAM at any one time.
//this routine would probably have to be copied to internal working ram on the real hardware
//to avoid the slowness of cart ram making us take more time than we have availible in the
//VBlank period, but I don't know how to copy a function to Internal RAM and execute it from
//there ... any hints welcome.
//Anyway, the best way to understand the code I have written is to examine it and experiment
//with it a bit (assuming you don't already understand how it works ;)

void scroll(u8 direction, u8 pixels)
{

u8 pcount;

vsync();

for (pcount=0; pcount<pixels; pcount++)
{

	     if (direction == 1)
		{
			if (extram[vofs]>0) extram[vofs]--;
		   else if (extram[worldy]>0)
				{
					extram[worldy]--;
					drawmap();
					extram[vofs] = 15;
				}
		}		
	     if (direction == 2)
		{
			if (extram[hofs]<16) extram[hofs]++;
		   else if (extram[worldx]+16<maxmapx)
				{
					extram[worldx]++;
					drawmap();
					extram[hofs] = 1;
				}
		}
	     if (direction == 3)
		{
			if (extram[vofs]<16) extram[vofs]++;
		   else if (extram[worldy]+11<maxmapy)
				{
					extram[worldy]++;
					drawmap();
					extram[vofs] = 1;
				}
		}
	     if (direction == 4)
		{
			if (extram[hofs]>0) extram[hofs]--;
		   else if (extram[worldx]>0)
				{
					extram[worldx]--;
					drawmap();
					extram[hofs] = 15;
				}
		}
offsync();
}
}

//The next function was borrowed wholesale from Nokturn's keydemo
//once again - why reinvent the wheel when the purpose of the demo is to explore
//backgrounds - not key input.
//Notice that the L and R buttons alter the scrolling factor,
//while the direction buttons call the scroll routine.
void GetKeys()
 {
  if( !(P1 & BIT06) ) { scroll(1,extram[sfac]);      P1 |= BIT06; }           // Up
  if( !(P1 & BIT07) ) { scroll(3,extram[sfac]);      P1 |= BIT07; }           // Down
  if( !(P1 & BIT05) ) { scroll(4,extram[sfac]);      P1 |= BIT05; }           // Left
  if( !(P1 & BIT04) ) { scroll(2,extram[sfac]);      P1 |= BIT04; }           // Right
  if( !(P1 & BIT09) ) { if (extram[sfac]>1) extram[sfac]--;  P1 |= BIT09; }   // L
  if( !(P1 & BIT08) ) { if (extram[sfac]<4) extram[sfac]++;  P1 |= BIT08; }   // R
 }

//Finally the main block of code!!!
void C_entry()
{

	Init();         //Initialise registers and variables etc
	CopyTileData(); //Copy tile and pallette data to VRAM

	drawmap();      //draw correct part of the map onto the screen

	while(1)        //loop forever
	{
	GetKeys();      //forever checks the state of which keys are pressed
                        //on the JoyPad and acts accordingly
	}

}

// The End
// Phew!