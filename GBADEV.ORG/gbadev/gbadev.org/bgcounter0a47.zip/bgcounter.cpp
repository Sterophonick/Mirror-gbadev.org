////////////////////////////////////////////////////////////////////////////
//File:		bgcounter.cpp
//Description:	a score counter in the background
//Date:		21 - 08 - 2003
//Author:		Jenswa
//Thanks to:	gbajunkie, dovoto and nokturn
////////////////////////////////////////////////////////////////////////////


//general declarations
#include "gba.h"		//GBA register definitions
#include "dispcnt.h"		//REG_DISPCNT register defines
#include "keypad.h"	//keypad defines
#include "background.h"	//background defines

//dma stuff
#include "dma.h"		//dma defines

//gfx
#include "objpalette.h"	//normal tgf 256 colour palette
#include "numbers.h"	//number 0 - 9
#include "map.c"		//background map

//createa background
BG bg3;


//let's make it multiboot, just for fun! (uncomment it)
//don't foget to fix it with gbafix from darkfader
#define MULTIBOOT int __gba_multiboot;
//MULTIBOOT

//variables
int score = 0;
int pointers[9];


//wait for the screen to stop drawing
void WaitForVsync()
{
	while((volatile u16)REG_VCOUNT != 160){}
}



//set counters to a score (less than 999)
void SetScore(int score)
{
	//because counters exist of a numberset ranging from 0 - 9
	//we break the score down into 3 digits (hundreds, tens, units),
	//that way we have a range from 0 - 999.

	int hundreds = (score/100)%10;
	int tens =(score/10)%10;
	int units =(score/1)%10;


	//map is an array, of the on screen map in bg3
	//buy changing numbers in the array, we can
	//change the background, in this case,
	//we change the numbers of the first three positions.
	map[0] = pointers[hundreds];
	map[1] = pointers[tens];
	map[2] = pointers[units];

	//and off course we should load the new map
	//otherwise the changes will not be made visible
	//update map
	REG_DM3SAD = (u32) map;			//dma3 source adress
	REG_DM3DAD = (u32) ScreenMem0;		//dma 3 destination adress
	REG_DM3CNT = 32*32/2 | DMA_32NOW;		//the size of the transfer and the method used
}

//read the gba keypad
void GetInput()
{
	//if key a is hold, add one to the score
	if(KEY_DOWN(KEYA)){
		if(score < 999){
			score++;
		}
	}
	//if key b is hold, substract one from the score
	if(KEY_DOWN(KEYB)){
		if(score > 0){
			score--;
		}
	}
}


//main starting point from ROM
int main()
{

	for(int x = 0; x < 10; x++){
		//the array pointers stores the pointers to the right tiles,
		//in this case it's very simple, since we only use tile 0 - tile 9
		//and the tiles (numbers) are sorted in order.
		pointers[x] = x;
	}

	//loads the bg palette into memory
	REG_DM3SAD = (u32) OBJPalette; 
	REG_DM3DAD = (u32) BGPaletteMem; 
	REG_DM3CNT = 128 | DMA_32NOW;

	//loads the number tiles into character memory 1
	REG_DM3SAD = (u32) numbersData;
	REG_DM3DAD = (u32) CharMem1;
	REG_DM3CNT = numbers_WIDTH*numbers_HEIGHT/4 | DMA_32NOW;


	//Settings for bg3
	//sets BG registers right for BG3
	REG_BG3CNT = CHAR_BASE(1) | SCREEN_BASE(0) | BG_COLOR_256;
	//loads the map (map = const u16!)
	REG_DM3SAD = (u32) map; 
	REG_DM3DAD = (u32) ScreenMem0; 
	REG_DM3CNT = 32*32/2 | DMA_32NOW;


	//set display mode and enable bg3
	SetMode(MODE_0 | BG3_ENABLE | OBJ_MAP_1D);


	//main loop
	while(1)
	{
		GetInput();			//read the gba keypad
		WaitForVsync();			//wait for the screen to stop drawing
		SetScore(score);			//set score and hiscore
	}


}
