1942 0.9 by Zapf Bandit
--------

Here it is, my remake of the Capcom arcade classic 1942.

I have decided to finally put my creation into the big wide world.

Please keep in mind it is not the full game and only consists of the first level repeating ad-infinitum.

I have tried to remain as true to the orginial as possible but having a completely different aspect ratio makes it a little hard.

This is my first real game using music and sounds so please forgive the song choice (Select toggles music ;-)

Anyway, I hope you all like it.

My next release will be Lemmings (full graphics, music, sound and levels from the original).

It's finished and I'm just adding as many levels as I could be stuffed doing (up to 15 levels so far).

Peace Out,
Zapf Bandit

PS. Please don't bother reporting the landing bug... I'll fix it soon.

PPS. For more info/demos try www.zapfbandit.com (under development).

