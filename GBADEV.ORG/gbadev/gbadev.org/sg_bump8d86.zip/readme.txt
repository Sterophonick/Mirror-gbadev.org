sg_bump
Realtime(Almost) bumpmapper for the GBA

Written in pure ARM ASM
by Stephen Stair (sgstair@hotmail.com)


The Code includes: Palette generator, random number generator, lightmap generator (w/ pseudo square root function), heightfield smoother, and realtime bumpmapper.

I have no idea if this will run fast on a REAL GBA, but I would like to know the results if anyone does try...
This is partly optimized code, so it doesn't have too bad of a framerate on iGBA and Mappy.  The 'slowness' is caused by 5 reads and 1/4 write per pixel... It could be re-written to be faster (i.e. load words instead of bytes), but I will save that for later (and maybe someone else).. I plan to do 3D stuff in the future, after I have made the GBA MapEditor more usable.

If you have any questions, comments, etc... (complaints?  Nah.) Please email me.

Greets to:
Warder1
SimonB
Nokturn
VBRunner
Joat (Mappy is great!)
Iki (iGBA is great too!)
subice
TwinD
DuoDreamr
re-eject
DarkFader
Eloise
And all others at #gbadev
and anyone else not on #gbadev that I might have missed  

;) Cya
-sgstair
