GBAGraphicsTool 1.0 by Decept

This program currently only converts bmp files to header files so that they can be included into GBA projects. In the future it may support more file formats and contain a map editor.

The program splits the image into 8x8 tiles when it saves it as a Header file, so it can be loaded into the GBA in a simple way.



Instructions:

1.
Click on the "Load BMP" button and select the file you want to convert.

2.
You may now change the properties of the image if you want.

3.
Click on the "Save H" button to save the file with the current settings.




Any questions or comments: ddecept@hotmail.com

