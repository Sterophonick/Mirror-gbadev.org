/*******************************************************************************
 *
 *  pwgba.cpp
 *
 *  My personal C++ GBA library, edited for colorDemo.cpp
 *
 *  Copyright 2002+ by Sean Connelly (aka Peebrain) http://www.pbwhere.com
 *  All Rights Reserved.
 *
 *  Created with DevKitAdv gcc 3.0.2 and ConTEXT v0.97.2a
 ******************************************************************************/

#ifndef __PWGBA_CPP__2AE24FB62CB97974843E87C86D10A6DA032FEB61AFA83F66E576C54A131
#define __PWGBA_CPP__2AE24FB62CB97974843E87C86D10A6DA032FEB61AFA83F66E576C54A131

#ifndef __cplusplus
typedef          unsigned char             bool;
#define true     1
#define false    0
#endif

#define _ALIGN(x)   __attribute__((aligned(x)))
#define SWAP(x, y)  { x = x ^ y; y = x ^ y; x = x ^ y; }
#define ABS(x)      (((x) < 0) ? (-(x)) : (x))
#define SGN(x)      (((x) < 0) ? -1 : ((x) == 0) ? 0 : 1)

typedef          unsigned char             u8;
typedef          unsigned short int        u16;
typedef          unsigned int              u32;
typedef          unsigned long long int    u64;

typedef          signed   char             s8;
typedef          signed   short int        s16;
typedef          signed   int              s32;
typedef          signed   long long int    s64;

typedef volatile unsigned char             vu8;
typedef volatile unsigned short int        vu16;
typedef volatile unsigned int              vu32;
typedef volatile unsigned long long int    vu64;

typedef volatile signed   char             vs8;
typedef volatile signed   short int        vs16;
typedef volatile signed   int              vs32;
typedef volatile signed   long long int    vs64;

typedef                   s16              sfp16;  //1:7:8 fixed point
typedef                   s32              sfp32;  //1:19:8 fixed point
typedef                   u16              ufp16;  //8:8 fixed point
typedef                   u32              ufp32;  //24:8 fixed point


// Taken from Eloist's gba.h (http://www.cs.rit.edu/~tjh8300/CowBite/gba.h)

/////////////////Registers/////////////////
#define REG_INTERUPT   *(vu32*)0x3007FFC		//Interrupt Register
#define REG_DISPCNT    *(vu32*)0x4000000		//Display Control (Mode)
#define REG_DISPCNT_L  *(vu16*)0x4000000		//???
#define REG_DISPCNT_H  *(vu16*)0x4000002		//???
#define REG_DISPSTAT   *(vu16*)0x4000004		//???
#define REG_VCOUNT     *(vu16*)0x4000006		//Vertical Control (Sync)
#define REG_BG0CNT     *(vu16*)0x4000008		//Background 0
#define REG_BG1CNT     *(vu16*)0x400000A		//Background 1
#define REG_BG2CNT     *(vu16*)0x400000C		//Background 2
#define REG_BG3CNT     *(vu16*)0x400000E		//Background 3
#define REG_BG0HOFS    *(vu16*)0x4000010		//Background 0 Horizontal Offset
#define REG_BG0VOFS    *(vu16*)0x4000012		//Background 0 Vertical Offset
#define REG_BG1HOFS    *(vu16*)0x4000014		//Background 1 Horizontal Offset
#define REG_BG1VOFS    *(vu16*)0x4000016		//Background 1 Vertical Offset
#define REG_BG2HOFS    *(vu16*)0x4000018		//Background 2 Horizontal Offset
#define REG_BG2VOFS    *(vu16*)0x400001A		//Background 2 Vertical Offset
#define REG_BG3HOFS    *(vu16*)0x400001C		//Background 3 Horizontal Offset
#define REG_BG3VOFS    *(vu16*)0x400001E		//Background 3 Vertical Offset
#define REG_BG2PA      *(vu16*)0x4000020		//Background 2 PA Rotation (pa = x_scale * cos(angle);)
#define REG_BG2PB      *(vu16*)0x4000022		//Background 2 PB Rotation (pb = y_scale * sin(angle);)
#define REG_BG2PC      *(vu16*)0x4000024		//Background 2 PC Rotation (pc = x_scale * -sin(angle);)
#define REG_BG2PD      *(vu16*)0x4000026		//Background 2 PD Rotation (pd = y_scale * cos(angle);)
#define REG_BG2X       *(vu32*)0x4000028		//Background 2 X Location
#define REG_BG2X_L     *(vu16*)0x4000028		//???
#define REG_BG2X_H     *(vu16*)0x400002A		//???
#define REG_BG2Y       *(vu32*)0x400002C		//Background 2 Y Location
#define REG_BG2Y_L     *(vu16*)0x400002C		//???
#define REG_BG2Y_H     *(vu16*)0x400002E		//???
#define REG_BG3PA      *(vu16*)0x4000030		//Background 3 PA Rotation (pa = x_scale * cos(angle);)
#define REG_BG3PB      *(vu16*)0x4000032		//Background 3 PB Rotation (pb = y_scale * sin(angle);)
#define REG_BG3PC      *(vu16*)0x4000034		//Background 3 PC Rotation (pc = x_scale * -sin(angle);)
#define REG_BG3PD      *(vu16*)0x4000036		//Background 3 PD Rotation (pd = y_scale * cos(angle);)
#define REG_BG3X       *(vu32*)0x4000038		//Background 3 X Location
#define REG_BG3X_L     *(vu16*)0x4000038		//???
#define REG_BG3X_H     *(vu16*)0x400003A		//???
#define REG_BG3Y       *(vu32*)0x400003C		//Background 3 Y Location
#define REG_BG3Y_L     *(vu16*)0x400003C		//???
#define REG_BG3Y_H     *(vu16*)0x400003E		//???
#define REG_WIN0H      *(vu16*)0x4000040		//Window 0 X coords (bits 0-7 right, bits 8-16 left)
#define REG_WIN1H      *(vu16*)0x4000042		//Window 1 X coords (bits 0-7 right, bits 8-16 left)
#define REG_WIN0V      *(vu16*)0x4000044		//Window 0 Y coords (bits 0-7 bottom, bits 8-16 top)
#define REG_WIN1V      *(vu16*)0x4000046		//Window 1 Y coords (bits 0-7 bottom, bits 8-16 top)
#define REG_WININ      *(vu16*)0x4000048		//Inside Window Settings
#define REG_WINOUT     *(vu16*)0x400004A		//Outside Window Settings
#define REG_MOSAIC     *(vu32*)0x400004C		//Mosaic Mode
#define REG_MOSAIC_L   *(vu32*)0x400004C		//???
#define REG_MOSAIC_H   *(vu32*)0x400004E		//???
#define REG_BLDMOD     *(vu16*)0x4000050		//Blend Mode
#define REG_COLEV      *(vu16*)0x4000052		//???
#define REG_COLEY      *(vu16*)0x4000054		//???

#define REG_SOUND1CNT   *(vu32*)0x4000060		//sound 1
#define REG_SOUND1CNT_L *(vu16*)0x4000060		//
#define REG_SOUND1CNT_H *(vu16*)0x4000062		//
#define REG_SOUND1CNT_X *(vu16*)0x4000064		//

#define REG_SOUND2CNT_L *(vu16*)0x4000068		//sound 2 lenght & wave duty
#define REG_SOUND2CNT_H *(vu16*)0x400006C		//sound 2 frequency+loop+reset

#define REG_SG30       *(vu32*)0x4000070		//???
#define REG_SOUND3CNT  *(vu32*)0x4000070		//???
#define REG_SG30_L     *(vu16*)0x4000070		//???
#define REG_SOUND3CNT_L *(vu16*)0x4000070		//???
#define REG_SG30_H     *(vu16*)0x4000072		//???
#define REG_SOUND3CNT_H *(vu16*)0x4000072		//???
#define REG_SG31       *(vu16*)0x4000074		//???
#define REG_SOUND3CNT_X *(vu16*)0x4000074		//???

#define REG_SOUND4CNT_L *(vu16*)0x4000078		//???
#define REG_SOUND4CNT_H *(vu16*)0x400007C		//???

#define REG_SGCNT0     *(vu32*)0x4000080
#define REG_SGCNT0_L   *(vu16*)0x4000080
#define REG_SOUNDCNT   *(vu32*)0x4000080
#define REG_SOUNDCNT_L *(vu16*)0x4000080		//DMG sound control

#define REG_SGCNT0_H   *(vu16*)0x4000082
#define REG_SOUNDCNT_H *(vu16*)0x4000082		//Direct sound control

#define REG_SGCNT1     *(vu16*)0x4000084
#define REG_SOUNDCNT_X *(vu16*)0x4000084	    //Extended sound control

#define REG_SGBIAS     *(vu16*)0x4000088
#define REG_SOUNDBIAS  *(vu16*)0x4000088		//bit rate+sound bias

#define REG_WAVE_RAM0  *(vu32*)0x4000090		//???
#define REG_SGWR0_L    *(vu16*)0x4000090		//???
#define REG_SGWR0_H    *(vu16*)0x4000092		//???
#define REG_WAVE_RAM1  *(vu32*)0x4000094		//???
#define REG_SGWR1_L    *(vu16*)0x4000094		//???
#define REG_SGWR1_H    *(vu16*)0x4000096		//???
#define REG_WAVE_RAM2  *(vu32*)0x4000098		//???
#define REG_SGWR2_L    *(vu16*)0x4000098		//???
#define REG_SGWR2_H    *(vu16*)0x400009A		//???
#define REG_WAVE_RAM3  *(vu32*)0x400009C		//???
#define REG_SGWR3_L    *(vu16*)0x400009C		//???
#define REG_SGWR3_H    *(vu16*)0x400009E		//???

#define REG_SGFIFOA    *(vu32*)0x40000A0		//???
#define REG_SGFIFOA_L  *(vu16*)0x40000A0		//???
#define REG_SGFIFOA_H  *(vu16*)0x40000A2		//???
#define REG_SGFIFOB    *(vu32*)0x40000A4		//???
#define REG_SGFIFOB_L  *(vu16*)0x40000A4		//???
#define REG_SGFIFOB_H  *(vu16*)0x40000A6		//???
#define REG_DMA0SAD     *(vu32*)0x40000B0		//DMA0 Source Address
#define REG_DMA0SAD_L   *(vu16*)0x40000B0		//DMA0 Source Address Low Value
#define REG_DMA0SAD_H   *(vu16*)0x40000B2		//DMA0 Source Address High Value
#define REG_DMA0DAD     *(vu32*)0x40000B4		//DMA0 Destination Address
#define REG_DMA0DAD_L   *(vu16*)0x40000B4		//DMA0 Destination Address Low Value
#define REG_DMA0DAD_H   *(vu16*)0x40000B6		//DMA0 Destination Address High Value
#define REG_DMA0CNT     *(vu32*)0x40000B8		//DMA0 Control (Amount)
#define REG_DMA0CNT_L   *(vu16*)0x40000B8		//DMA0 Control Low Value
#define REG_DMA0CNT_H   *(vu16*)0x40000BA		//DMA0 Control High Value

#define REG_DMA1SAD     *(vu32*)0x40000BC		//DMA1 Source Address
#define REG_DMA1SAD_L   *(vu16*)0x40000BC		//DMA1 Source Address Low Value
#define REG_DMA1SAD_H   *(vu16*)0x40000BE		//DMA1 Source Address High Value
#define REG_DMA1DAD     *(vu32*)0x40000C0		//DMA1 Desination Address
#define REG_DMA1DAD_L   *(vu16*)0x40000C0		//DMA1 Destination Address Low Value
#define REG_DMA1DAD_H   *(vu16*)0x40000C2		//DMA1 Destination Address High Value
#define REG_DMA1CNT     *(vu32*)0x40000C4		//DMA1 Control (Amount)
#define REG_DMA1CNT_L   *(vu16*)0x40000C4		//DMA1 Control Low Value
#define REG_DMA1CNT_H   *(vu16*)0x40000C6		//DMA1 Control High Value

#define REG_DMA2SAD     *(vu32*)0x40000C8		//DMA2 Source Address
#define REG_DMA2SAD_L   *(vu16*)0x40000C8		//DMA2 Source Address Low Value
#define REG_DMA2SAD_H   *(vu16*)0x40000CA		//DMA2 Source Address High Value
#define REG_DMA2DAD     *(vu32*)0x40000CC		//DMA2 Destination Address
#define REG_DMA2DAD_L   *(vu16*)0x40000CC		//DMA2 Destination Address Low Value
#define REG_DMA2DAD_H   *(vu16*)0x40000CE		//DMA2 Destination Address High Value
#define REG_DMA2CNT     *(vu32*)0x40000D0		//DMA2 Control (Amount)
#define REG_DMA2CNT_L   *(vu16*)0x40000D0		//DMA2 Control Low Value
#define REG_DMA2CNT_H   *(vu16*)0x40000D2		//DMA2 Control High Value

#define REG_DMA3SAD     *(vu32*)0x40000D4		//DMA3 Source Address
#define REG_DMA3SAD_L   *(vu16*)0x40000D4		//DMA3 Source Address Low Value
#define REG_DMA3SAD_H   *(vu16*)0x40000D6		//DMA3 Source Address High Value
#define REG_DMA3DAD     *(vu32*)0x40000D8		//DMA3 Destination Address
#define REG_DMA3DAD_L   *(vu16*)0x40000D8		//DMA3 Destination Address Low Value
#define REG_DMA3DAD_H   *(vu16*)0x40000DA		//DMA3 Destination Address High Value
#define REG_DMA3CNT     *(vu32*)0x40000DC		//DMA3 Control (Amount)
#define REG_DMA3CNT_L   *(vu16*)0x40000DC		//DMA3 Control Low Value
#define REG_DMA3CNT_H   *(vu16*)0x40000DE		//DMA3 Control High Value

#define REG_TM0D        *(vu16*)0x4000100		//Timer 0
#define REG_TM0CNT      *(vu16*)0x4000102		//Timer 0 Control
#define REG_TM1D        *(vu32*)0x4000104		//Timer 1
#define REG_TM1CNT  	*(vu16*)0x4000106		//Timer 1 Control
#define REG_TM2D        *(vu16*)0x4000108		//Timer 2
#define REG_TM2CNT      *(vu16*)0x400010A		//Timer 2 Control
#define REG_TM3D        *(vu16*)0x400010C		//Timer 3
#define REG_TM3CNT      *(vu16*)0x400010E		//Timer 3 Control

#define REG_SCD0       *(vu16*)0x4000120		//32-bit Normal Serial Communication Data 0 / Multi-play
#define REG_SCD1       *(vu16*)0x4000122		//32-bit Normal Serial Communication Data 1 /Multi-play
#define REG_SCD2       *(vu16*)0x4000124		//Multi-play Communication Data 2
#define REG_SCD3       *(vu16*)0x4000126		//Multi-play Communication Data 3
#define REG_SCCNT      *(vu32*)0x4000128		//???
#define REG_SCCNT_L    *(vu16*)0x4000128		//???
#define REG_SCCNT_H    *(vu16*)0x400012A		//???
#define REG_P1         *(vu16*)0x4000130		//Player 1 Input
#define REG_KEYPAD     *(vu16*)0x4000130		//Player 1 Input
#define REG_P1CNT      *(vu16*)0x4000132		//Player 1 Input Interrupt Status
#define REG_R          *(vu16*)0x4000134		//???
#define REG_HS_CTRL    *(vu16*)0x4000140		//???
#define REG_JOYRE      *(vu32*)0x4000150		//???
#define REG_JOYRE_L    *(vu16*)0x4000150		//???
#define REG_JOYRE_H    *(vu16*)0x4000152		//???
#define REG_JOYTR      *(vu32*)0x4000154		//???
#define REG_JOYTR_L    *(vu16*)0x4000154		//???
#define REG_JOYTR_H    *(vu16*)0x4000156		//???
#define REG_JSTAT      *(vu32*)0x4000158		//???
#define REG_JSTAT_L    *(vu16*)0x4000158		//???
#define REG_JSTAT_H    *(vu16*)0x400015A		//???
#define REG_IE         *(vu16*)0x4000200		//Interrupt Enable
#define REG_IF         *(vu16*)0x4000202		//Interrupt Flags
#define REG_WSCNT      *(vu16*)0x4000204		//???
#define REG_IME        *(vu16*)0x4000208		//Interrupt Master Enable
#define REG_PAUSE      *(vu16*)0x4000300		//Pause
// End


#define BIT0         0x0001
#define BIT1         0x0002
#define BIT2         0x0004
#define BIT3         0x0008
#define BIT4         0x0010
#define BIT5         0x0020
#define BIT6         0x0040
#define BIT7         0x0080
#define BIT8         0x0100
#define BIT9         0x0200
#define BIT10        0x0400
#define BIT11        0x0800
#define BIT12        0x1000
#define BIT13        0x2000
#define BIT14        0x4000
#define BIT15        0x8000
#define BIT16        0x00010000
#define BIT17        0x00020000
#define BIT18        0x00040000
#define BIT19        0x00080000
#define BIT20        0x00100000
#define BIT21        0x00200000
#define BIT22        0x00400000
#define BIT23        0x00800000
#define BIT24        0x01000000
#define BIT25        0x02000000
#define BIT26        0x04000000
#define BIT27        0x08000000
#define BIT28        0x10000000
#define BIT29        0x20000000
#define BIT30        0x40000000
#define BIT31        0x80000000

#define NOT_BIT0     0xFFFE
#define NOT_BIT1     0xFFFD
#define NOT_BIT2     0xFFFB
#define NOT_BIT3     0xFFF7
#define NOT_BIT4     0xFFEF
#define NOT_BIT5     0xFFDF
#define NOT_BIT6     0xFFBF
#define NOT_BIT7     0xFF7F
#define NOT_BIT8     0xFEFF
#define NOT_BIT9     0xFDFF
#define NOT_BIT10    0xFBFF
#define NOT_BIT11    0xF7FF
#define NOT_BIT12    0xEFFF
#define NOT_BIT13    0xDFFF
#define NOT_BIT14    0xBFFF
#define NOT_BIT15    0x7FFF
#define NOT_BIT16    0xFFFEFFFF
#define NOT_BIT17    0xFFFDFFFF
#define NOT_BIT18    0xFFFBFFFF
#define NOT_BIT19    0xFFF7FFFF
#define NOT_BIT20    0xFFEFFFFF
#define NOT_BIT21    0xFFDFFFFF
#define NOT_BIT22    0xFFBFFFFF
#define NOT_BIT23    0xFF7FFFFF
#define NOT_BIT24    0xFEFFFFFF
#define NOT_BIT25    0xFDFFFFFF
#define NOT_BIT26    0xFBFFFFFF
#define NOT_BIT27    0xF7FFFFFF
#define NOT_BIT28    0xEFFFFFFF
#define NOT_BIT29    0xDFFFFFFF
#define NOT_BIT30    0xBFFFFFFF
#define NOT_BIT31    0x7FFFFFFF


#define SMC_KEYPAD         *((vu16 *)0x4000130)
#define SMC_KEYPAD_A       BIT0
#define SMC_KEYPAD_B       BIT1
#define SMC_KEYPAD_SELECT  BIT2
#define SMC_KEYPAD_START   BIT3
#define SMC_KEYPAD_RIGHT   BIT4
#define SMC_KEYPAD_LEFT    BIT5
#define SMC_KEYPAD_UP      BIT6
#define SMC_KEYPAD_DOWN    BIT7
#define SMC_KEYPAD_R       BIT8
#define SMC_KEYPAD_L       BIT9
#define SMC_KEYPAD_DPAD    0x00F0

#define s_keyA       (!(SMC_KEYPAD & SMC_KEYPAD_A))
#define s_keyB       (!(SMC_KEYPAD & SMC_KEYPAD_B))
#define s_keySelect  (!(SMC_KEYPAD & SMC_KEYPAD_SELECT))
#define s_keyStart   (!(SMC_KEYPAD & SMC_KEYPAD_START))
#define s_keyRight   (!(SMC_KEYPAD & SMC_KEYPAD_RIGHT))
#define s_keyLeft    (!(SMC_KEYPAD & SMC_KEYPAD_LEFT))
#define s_keyUp      (!(SMC_KEYPAD & SMC_KEYPAD_UP))
#define s_keyDown    (!(SMC_KEYPAD & SMC_KEYPAD_DOWN))
#define s_keyR       (!(SMC_KEYPAD & SMC_KEYPAD_R))
#define s_keyL       (!(SMC_KEYPAD & SMC_KEYPAD_L))
#define s_keyDPad    (!((SMC_KEYPAD & SMC_KEYPAD_DPAD) == SMC_KEYPAD_DPAD))


#define s_color(r,g,b)            ((r) | (((u16)(g)) << 5) | (((u16)(b)) << 10))
#define s_bgPalette               ((vu16 *)0x05000000)
#define s_objPalette              ((vu16 *)0x05000200)
#define s_loadBgPalette(src)      s_dmaCopy3((void *)src, (void *)s_bgPalette, 128, BIT10 | BIT15)
#define s_loadObjPalette(src)     s_dmaCopy3((void *)src, (void *)s_objPalette, 128, BIT10 | BIT15)


#define SMC_DMA0_SRC    *((vu32 *)0x040000B0)
#define SMC_DMA1_SRC    *((vu32 *)0x040000BC)
#define SMC_DMA2_SRC    *((vu32 *)0x040000C8)
#define SMC_DMA3_SRC    *((vu32 *)0x040000D4)
#define SMC_DMA0_DST    *((vu32 *)0x040000B4)
#define SMC_DMA1_DST    *((vu32 *)0x040000C0)
#define SMC_DMA2_DST    *((vu32 *)0x040000CC)
#define SMC_DMA3_DST    *((vu32 *)0x040000D8)
#define SMC_DMA0_CTL    *((vu32 *)0x040000B8)
#define SMC_DMA0_CTH    *((vu32 *)0x040000BA)
#define SMC_DMA1_CTL    *((vu32 *)0x040000C4)
#define SMC_DMA1_CTH    *((vu32 *)0x040000C6)
#define SMC_DMA2_CTL    *((vu32 *)0x040000D0)
#define SMC_DMA2_CTH    *((vu32 *)0x040000D2)
#define SMC_DMA3_CTL    *((vu16 *)0x040000DC)
#define SMC_DMA3_CTH    *((vu16 *)0x040000DE)

#define memcpy(src, dst, bytes) s_dmaCopy3((void *)(src), (void *)(dst), (bytes)>>1, BIT15)

void s_dmaCopy0(const void *src, void *dst, u16 hWordCount, u16 mode)
{
	SMC_DMA0_SRC = (u32)src;
	SMC_DMA0_DST = (u32)dst;
	SMC_DMA0_CTL = hWordCount;
	SMC_DMA0_CTH = mode;
}

void s_dmaCopy1(const void *src, void *dst, u16 hWordCount, u16 mode)
{
	SMC_DMA1_SRC = (u32)src;
	SMC_DMA1_DST = (u32)dst;
	SMC_DMA1_CTL = hWordCount;
	SMC_DMA1_CTH = mode;
}

void s_dmaCopy2(const void *src, void *dst, u16 hWordCount, u16 mode)
{
	SMC_DMA2_SRC = (u32)src;
	SMC_DMA2_DST = (u32)dst;
	SMC_DMA2_CTL = hWordCount;
	SMC_DMA2_CTH = mode;
}

void s_dmaCopy3(const void *src, void *dst, u16 hWordCount, u16 mode)
{
	SMC_DMA3_SRC = (u32)src;
	SMC_DMA3_DST = (u32)dst;
	SMC_DMA3_CTL = hWordCount;
	SMC_DMA3_CTH = mode;
}

void memfill(u16 value, void *dst, u16 bytes)
{
	s_dmaCopy3((void *)&value, dst, bytes >> 1, BIT8 | BIT15);
}


void InitializeGBA()
{
	u16 i;

	// init interrupts
	REG_IE = 0;
	REG_IME = 1;
	
	// clear palettes
	u32 zero = 0;
	s_dmaCopy3((void *)&zero, (void *)0x05000000, 256, BIT8 | BIT10 | BIT15);
	
	// clear vram
	s_dmaCopy3((void *)&zero, (void *)0x06000000, 0x2000, BIT8 | BIT10 | BIT15);
	s_dmaCopy3((void *)&zero, (void *)0x06008000, 0x2000, BIT8 | BIT10 | BIT15);
	s_dmaCopy3((void *)&zero, (void *)0x06010000, 0x2000, BIT8 | BIT10 | BIT15);
	
	// clear oam
	s_dmaCopy3((void *)&zero, (void *)0x07000000, 256, BIT8 | BIT10 | BIT15);

	// set all sprite scale values to 1.0
	struct OAM_tag {
		vu16 attrib0;
		vu16 attrib1;
		vu16 attrib2;
		vu16 attrib3;
	} *OAM = (struct OAM_tag *)0x07000000;

	for (i = 0; i < 32; i++)
		OAM[i << 2].attrib3 = OAM[(i << 2) + 3].attrib3 = 0x0100;
	for (i = 0; i < 128; i++)
		OAM[i].attrib0 = 160;

	REG_DISPCNT = BIT6; // default to 1d sprite tiles
	REG_DISPSTAT = 0;
	REG_BG0CNT = REG_BG1CNT = REG_BG2CNT = REG_BG3CNT = BIT7;  // default to 8-bit colors
	REG_BG0HOFS = REG_BG0VOFS = 0;
	REG_BG1HOFS = REG_BG1VOFS = 0;
	REG_BG2HOFS = REG_BG2VOFS = 0;
	REG_BG3HOFS = REG_BG3VOFS = 0;
	REG_BG2PA = REG_BG2PD = REG_BG3PA = REG_BG3PD = 0x0100; // default to 1.0 scale
	REG_BG2PB = REG_BG2PC = REG_BG3PB = REG_BG3PC = 0;
	REG_BG2X = REG_BG3X = REG_BG2Y = REG_BG3Y = 0;
	REG_WIN0H = REG_WIN1H = REG_WIN0V = REG_WIN1V = 0;
	REG_WININ = REG_WINOUT = 0;
	REG_MOSAIC = 0x1111; // default to size 1 of mosaic
	REG_BLDMOD = 0;
	REG_COLEV = 0;
	REG_COLEY = 0;
	REG_SOUNDCNT_X = 0;
	REG_TM0D = REG_TM1D = REG_TM2D = REG_TM3D = 0;
	REG_TM0CNT = REG_TM1CNT = REG_TM2CNT = REG_TM3CNT = 0;
	REG_P1CNT = 0;
}


void SoftReset()
{
	u16 *multiboot = (u16 *)0x03007FFA;
	*multiboot = 0;
	asm volatile("swi 0x000000");
}

s32 Div(s32 top, s32 bot)
{
	register u32 r_num asm ("r0");
	register u32 r_den asm ("r1");
	r_num = top;
	r_den = bot;
	asm volatile("swi 0x060000");
	return r_num;
}

s32 Mod(s32 top, s32 bot)
{
	register u32 r_num asm ("r0");
	register u32 r_den asm ("r1");
	r_num = top;
	r_den = bot;
	asm volatile("swi 0x060000");
	return r_den;
}

s32 AbsDiv(s32 top, s32 bot)
{
	register u32 r_num asm ("r0");
	register u32 r_den asm ("r1");
	register u32 r_abs asm ("r3");
	r_num = top;
	r_den = bot;
	asm volatile("swi 0x060000");
	return r_abs;
}

u32 Sqrt(u32 num)
{
	register u32 r_num asm("r0");
	r_num = num;
	asm volatile("swi 0x080000");
	return r_num;
}


struct s_oamMemory_tag {
	u16 attrib0;
	u16 attrib1;
	u16 attrib2;
	u16 attrib3;
};

#ifdef SHADOW_OAM
struct s_oamMemory_tag *s_realOamMemory = (struct s_oamMemory_tag *)0x07000000;
struct s_oamMemory_tag s_oamMemory[128];
#define s_updateOam() s_dmaCopy3((void *)s_oamMemory, (void *)s_realOamMemory, 256, BIT10 | BIT15)
#else
struct s_oamMemory_tag *s_oamMemory = (struct s_oamMemory_tag *)0x07000000;
#define s_updateOam()
#endif

u8 *s_nextSpriteTile = (u8 *)0x06010000;
u8 s_nextSpriteOam = 0;

u8 s_mirrorSprite(u8 set)
{
	s_oamMemory[s_nextSpriteOam].attrib0 = s_oamMemory[set].attrib0;
	s_oamMemory[s_nextSpriteOam].attrib1 = s_oamMemory[set].attrib1;
	s_oamMemory[s_nextSpriteOam].attrib2 = s_oamMemory[set].attrib2;
	return s_nextSpriteOam++;
}

u8 s_loadSprite(void *data, u16 length)
{
	u16 *data16 = (u16 *)data;
	u32 tile = (u32)s_nextSpriteTile;
	tile -= 0x06010000;
	tile >>= 5;
	s_oamMemory[s_nextSpriteOam].attrib0 = data16[0] | 160;
	s_oamMemory[s_nextSpriteOam].attrib1 = data16[1];
	s_oamMemory[s_nextSpriteOam].attrib2 = data16[2] | tile;
	memcpy(&data16[3], s_nextSpriteTile, length - 6);
	s_nextSpriteTile += length - 6;
	return s_nextSpriteOam++;
}

void s_setOamRs(u8 set, sfp16 scalex, sfp16 scaley, sfp16 shearx, sfp16 sheary)
{
	set <<= 2;
	s_oamMemory[set    ].attrib3 = (u16)scalex;
	s_oamMemory[set + 1].attrib3 = (u16)shearx;
	s_oamMemory[set + 2].attrib3 = (u16)sheary;
	s_oamMemory[set + 3].attrib3 = (u16)scaley;
}

void s_getOamRs(u8 set, sfp16 *scalex, sfp16 *scaley, sfp16 *shearx, sfp16 *sheary)
{
	set <<= 2;
	*scalex = (sfp16)s_oamMemory[set    ].attrib3;
	*shearx = (sfp16)s_oamMemory[set + 1].attrib3;
	*sheary = (sfp16)s_oamMemory[set + 2].attrib3;
	*scaley = (sfp16)s_oamMemory[set + 3].attrib3;
}

void s_setOamY(u8 sprite, u8 y)
{
	s_oamMemory[sprite].attrib0 &= 0xFF00;
	s_oamMemory[sprite].attrib0 |= y;
}

void s_setOamIsRotateScale(u8 sprite, u8 yes)
{
	if (yes == 0)
		s_oamMemory[sprite].attrib0 &= NOT_BIT8;
	else
		s_oamMemory[sprite].attrib0 |= BIT8;
}

void s_setOamIsDoubleSize(u8 sprite, u8 yes)
{
	if (yes == 0)
		s_oamMemory[sprite].attrib0 &= NOT_BIT9;
	else
		s_oamMemory[sprite].attrib0 |= BIT9;
}

#define SOF_NORMAL           0
#define SOF_SEMITRANSPARENT  1
#define SOF_OBJWINDOW        2

void s_setOamFilter(u8 sprite, u8 filter)
{
	s_oamMemory[sprite].attrib0 &= (NOT_BIT10 & NOT_BIT11);
	s_oamMemory[sprite].attrib0 |= (filter & 3) << 10;
}

void s_setOamMosaic(u8 sprite, u8 yes)
{
	if (yes == 0)
		s_oamMemory[sprite].attrib0 &= NOT_BIT12;
	else
		s_oamMemory[sprite].attrib0 |= BIT12;
}

#define SOS_SIZE_8x8    0x0
#define SOS_SIZE_16x16  0x1
#define SOS_SIZE_32x32  0x2
#define SOS_SIZE_64x64  0x3
#define SOS_SIZE_16x8   0x4
#define SOS_SIZE_32x8   0x5
#define SOS_SIZE_32x16  0x6
#define SOS_SIZE_64x32  0x7
#define SOS_SIZE_8x16   0x8
#define SOS_SIZE_8x32   0x9
#define SOS_SIZE_16x32  0xA
#define SOS_SIZE_32x64  0xB

void s_setOamSize(u8 sprite, u8 size)
{
	u16 a0 = (size & 0x3) << 14;
	u16 a1 = (size & 0xC) << 12;
	s_oamMemory[sprite].attrib0 &= (NOT_BIT15 & NOT_BIT14);
	s_oamMemory[sprite].attrib0 |= a0;
	s_oamMemory[sprite].attrib1 &= (NOT_BIT15 & NOT_BIT14);
	s_oamMemory[sprite].attrib1 |= a1;
}

void s_setOamX(u8 sprite, u16 x)
{
	s_oamMemory[sprite].attrib1 &= 0xFE00;
	s_oamMemory[sprite].attrib1 |= (x & 0x1FF);
}

void s_setOamFlipH(u8 sprite, u8 yes)
{
	if (yes == 0)
		s_oamMemory[sprite].attrib1 &= NOT_BIT12;
	else
		s_oamMemory[sprite].attrib1 |= BIT12;
}

void s_setOamFlipV(u8 sprite, u8 yes)
{
	if (yes == 0)
		s_oamMemory[sprite].attrib1 &= NOT_BIT13;
	else
		s_oamMemory[sprite].attrib1 |= BIT13;
}

void s_setOamRsSet(u8 sprite, u8 set)
{
	s_oamMemory[sprite].attrib1 &= 0xC1FF;
	s_oamMemory[sprite].attrib1 |= (set << 9);
}

void s_setOamTile(u8 sprite, u16 tile)
{
	s_oamMemory[sprite].attrib2 &= 0xFC00;
	s_oamMemory[sprite].attrib2 |= (tile & 0x03FF);
}

void s_setOamPriority(u8 sprite, u8 priority)
{
	s_oamMemory[sprite].attrib2 &= 0xF3FF;
	s_oamMemory[sprite].attrib2 |= (priority << 10);
}

void s_setOamPalette(u8 sprite, u8 palette)
{
	s_oamMemory[sprite].attrib2 &= 0x0FFF;
	s_oamMemory[sprite].attrib2 |= (((u16)palette) << 12);
}

#define s_setOamPosition(spr, x, y) s_setOamY((u8)(spr), (u8)(y)); s_setOamX((u8)(spr), (u16)(x))


u8 *s_Sram = (u8 *)0x0E000000;

const u8 s_byteTrig[] = {
  0x00,0x00,0x06,0x00,0x0D,0x00,0x13,0x00,0x19,0x00,0x1F,0x00,0x26,0x00,0x2C,
  0x00,0x32,0x00,0x38,0x00,0x3E,0x00,0x44,0x00,0x4A,0x00,0x50,0x00,0x56,0x00,
  0x5C,0x00,0x62,0x00,0x68,0x00,0x6D,0x00,0x73,0x00,0x79,0x00,0x7E,0x00,0x84,
  0x00,0x89,0x00,0x8E,0x00,0x93,0x00,0x98,0x00,0x9D,0x00,0xA2,0x00,0xA7,0x00,
  0xAC,0x00,0xB1,0x00,0xB5,0x00,0xB9,0x00,0xBE,0x00,0xC2,0x00,0xC6,0x00,0xCA,
  0x00,0xCE,0x00,0xD1,0x00,0xD5,0x00,0xD8,0x00,0xDC,0x00,0xDF,0x00,0xE2,0x00,
  0xE5,0x00,0xE7,0x00,0xEA,0x00,0xED,0x00,0xEF,0x00,0xF1,0x00,0xF3,0x00,0xF5,
  0x00,0xF7,0x00,0xF8,0x00,0xFA,0x00,0xFB,0x00,0xFC,0x00,0xFD,0x00,0xFE,0x00,
  0xFF,0x00,0xFF,0x00,0x00,0x01,0x00,0x01,0x00,0x01,0x00,0x01,0x00,0x01,0xFF,
  0x00,0xFF,0x00,0xFE,0x00,0xFD,0x00,0xFC,0x00,0xFB,0x00,0xFA,0x00,0xF8,0x00,
  0xF7,0x00,0xF5,0x00,0xF3,0x00,0xF1,0x00,0xEF,0x00,0xED,0x00,0xEA,0x00,0xE7,
  0x00,0xE5,0x00,0xE2,0x00,0xDF,0x00,0xDC,0x00,0xD8,0x00,0xD5,0x00,0xD1,0x00,
  0xCE,0x00,0xCA,0x00,0xC6,0x00,0xC2,0x00,0xBE,0x00,0xB9,0x00,0xB5,0x00,0xB1,
  0x00,0xAC,0x00,0xA7,0x00,0xA2,0x00,0x9D,0x00,0x98,0x00,0x93,0x00,0x8E,0x00,
  0x89,0x00,0x84,0x00,0x7E,0x00,0x79,0x00,0x73,0x00,0x6D,0x00,0x68,0x00,0x62,
  0x00,0x5C,0x00,0x56,0x00,0x50,0x00,0x4A,0x00,0x44,0x00,0x3E,0x00,0x38,0x00,
  0x32,0x00,0x2C,0x00,0x26,0x00,0x1F,0x00,0x19,0x00,0x13,0x00,0x0D,0x00,0x06,
  0x00,0x00,0x00,0xFA,0xFF,0xF3,0xFF,0xED,0xFF,0xE7,0xFF,0xE1,0xFF,0xDA,0xFF,
  0xD4,0xFF,0xCE,0xFF,0xC8,0xFF,0xC2,0xFF,0xBC,0xFF,0xB6,0xFF,0xB0,0xFF,0xAA,
  0xFF,0xA4,0xFF,0x9E,0xFF,0x98,0xFF,0x93,0xFF,0x8D,0xFF,0x87,0xFF,0x82,0xFF,
  0x7C,0xFF,0x77,0xFF,0x72,0xFF,0x6D,0xFF,0x68,0xFF,0x63,0xFF,0x5E,0xFF,0x59,
  0xFF,0x54,0xFF,0x4F,0xFF,0x4B,0xFF,0x47,0xFF,0x42,0xFF,0x3E,0xFF,0x3A,0xFF,
  0x36,0xFF,0x32,0xFF,0x2F,0xFF,0x2B,0xFF,0x28,0xFF,0x24,0xFF,0x21,0xFF,0x1E,
  0xFF,0x1B,0xFF,0x19,0xFF,0x16,0xFF,0x13,0xFF,0x11,0xFF,0x0F,0xFF,0x0D,0xFF,
  0x0B,0xFF,0x09,0xFF,0x08,0xFF,0x06,0xFF,0x05,0xFF,0x04,0xFF,0x03,0xFF,0x02,
  0xFF,0x01,0xFF,0x01,0xFF,0x00,0xFF,0x00,0xFF,0x00,0xFF,0x00,0xFF,0x00,0xFF,
  0x01,0xFF,0x01,0xFF,0x02,0xFF,0x03,0xFF,0x04,0xFF,0x05,0xFF,0x06,0xFF,0x08,
  0xFF,0x09,0xFF,0x0B,0xFF,0x0D,0xFF,0x0F,0xFF,0x11,0xFF,0x13,0xFF,0x16,0xFF,
  0x19,0xFF,0x1B,0xFF,0x1E,0xFF,0x21,0xFF,0x24,0xFF,0x28,0xFF,0x2B,0xFF,0x2F,
  0xFF,0x32,0xFF,0x36,0xFF,0x3A,0xFF,0x3E,0xFF,0x42,0xFF,0x47,0xFF,0x4B,0xFF,
  0x4F,0xFF,0x54,0xFF,0x59,0xFF,0x5E,0xFF,0x63,0xFF,0x68,0xFF,0x6D,0xFF,0x72,
  0xFF,0x77,0xFF,0x7C,0xFF,0x82,0xFF,0x87,0xFF,0x8D,0xFF,0x93,0xFF,0x98,0xFF,
  0x9E,0xFF,0xA4,0xFF,0xAA,0xFF,0xB0,0xFF,0xB6,0xFF,0xBC,0xFF,0xC2,0xFF,0xC8,
  0xFF,0xCE,0xFF,0xD4,0xFF,0xDA,0xFF,0xE1,0xFF,0xE7,0xFF,0xED,0xFF,0xF3,0xFF,
  0xFA,0xFF,0x00,0x00,0x06,0x00,0x0D,0x00,0x13,0x00,0x19,0x00,0x1F,0x00,0x26,
  0x00,0x2C,0x00,0x32,0x00,0x38,0x00,0x3E,0x00,0x44,0x00,0x4A,0x00,0x50,0x00,
  0x56,0x00,0x5C,0x00,0x62,0x00,0x68,0x00,0x6D,0x00,0x73,0x00,0x79,0x00,0x7E,
  0x00,0x84,0x00,0x89,0x00,0x8E,0x00,0x93,0x00,0x98,0x00,0x9D,0x00,0xA2,0x00,
  0xA7,0x00,0xAC,0x00,0xB1,0x00,0xB5,0x00,0xB9,0x00,0xBE,0x00,0xC2,0x00,0xC6,
  0x00,0xCA,0x00,0xCE,0x00,0xD1,0x00,0xD5,0x00,0xD8,0x00,0xDC,0x00,0xDF,0x00,
  0xE2,0x00,0xE5,0x00,0xE7,0x00,0xEA,0x00,0xED,0x00,0xEF,0x00,0xF1,0x00,0xF3,
  0x00,0xF5,0x00,0xF7,0x00,0xF8,0x00,0xFA,0x00,0xFB,0x00,0xFC,0x00,0xFD,0x00,
  0xFE,0x00,0xFF,0x00,0xFF,0x00,0x00,0x01,0x00,0x01};

const sfp16 *s_cosine = (const sfp16 *)&s_byteTrig[128];
const sfp16 *s_sine = (const sfp16 *)&s_byteTrig[0];


void s_calculateRs(u16 xscale, u16 yscale, u8 angle, sfp16 *scalex, sfp16 *scaley, sfp16 *shearx, sfp16 *sheary)
{
	*scalex = ((sfp32)xscale * (sfp32)s_cosine[angle]) >> 8;
	*shearx = ((sfp32)yscale * (sfp32)s_sine[angle]) >> 8;
	*sheary = ((sfp32)xscale * (sfp32)-s_sine[angle]) >> 8;
	*scaley = ((sfp32)yscale * (sfp32)s_cosine[angle]) >> 8;
}

#ifndef INT_VBLANK_FUNC
	#define INT_VBLANK_FUNC
#endif
#ifndef INT_HBLANK_FUNC
	#define INT_HBLANK_FUNC
#endif
#ifndef INT_VCOUNT_FUNC
	#define INT_VCOUNT_FUNC
#endif
#ifndef INT_TIMER0_FUNC
	#define INT_TIMER0_FUNC
#endif
#ifndef INT_TIMER1_FUNC
	#define INT_TIMER1_FUNC
#endif
#ifndef INT_TIMER2_FUNC
	#define INT_TIMER2_FUNC
#endif
#ifndef INT_TIMER3_FUNC
	#define INT_TIMER3_FUNC
#endif
#ifndef INT_SERIAL_FUNC
	#define INT_SERIAL_FUNC
#endif
#ifndef INT_DMA0_FUNC
	#define INT_DMA0_FUNC
#endif
#ifndef INT_DMA1_FUNC
	#define INT_DMA1_FUNC
#endif
#ifndef INT_DMA2_FUNC
	#define INT_DMA2_FUNC
#endif
#ifndef INT_DMA3_FUNC
	#define INT_DMA3_FUNC
#endif
#ifndef INT_KEYPAD_FUNC
	#define INT_KEYPAD_FUNC
#endif
#ifndef INT_CASSETTE_FUNC
	#define INT_CASSETTE_FUNC
#endif

#define INT_VBLANK 0x0001
#define INT_HBLANK 0x0002
#define INT_VCOUNT 0x0004
#define INT_TIMER0 0x0008
#define INT_TIMER1 0x0010
#define INT_TIMER2 0x0020
#define INT_TIMER3 0x0040
#define INT_SERIAL 0x0080
#define INT_DMA0   0x0100
#define INT_DMA1   0x0200
#define INT_DMA2   0x0400
#define INT_DMA3   0x0800
#define INT_KEYPAD 0x1000
#define INT_CASSETTE 0x2000

void _IH_VBLANK()
{
	INT_VBLANK_FUNC;
	REG_IF |= INT_VBLANK;
}

void _IH_HBLANK()
{
	INT_HBLANK_FUNC;
	REG_IF |= INT_HBLANK;
}

void _IH_VCOUNT()
{
	INT_VCOUNT_FUNC;
	REG_IF |= INT_VCOUNT;
}

void _IH_TIMER0()
{
	INT_TIMER0_FUNC;
	REG_IF |= INT_TIMER0;
}

void _IH_TIMER1()
{
	INT_TIMER1_FUNC;
	REG_IF |= INT_TIMER1;
}

void _IH_TIMER2()
{
	INT_TIMER2_FUNC;
	REG_IF |= INT_TIMER2;
}

void _IH_TIMER3()
{
	INT_TIMER3_FUNC;
	REG_IF |= INT_TIMER3;
}

void _IH_SERIAL()
{
	INT_SERIAL_FUNC;
	REG_IF |= INT_SERIAL;
}

void _IH_DMA0()
{
	INT_DMA0_FUNC;
	REG_IF |= INT_DMA0;
}

void _IH_DMA1()
{
	INT_DMA1_FUNC;
	REG_IF |= INT_DMA1;
}

void _IH_DMA2()
{
	INT_DMA2_FUNC;
	REG_IF |= INT_DMA2;
}

void _IH_DMA3()
{
	INT_DMA3_FUNC;
	REG_IF |= INT_DMA3;
}

void _IH_KEYPAD()
{
	INT_KEYPAD_FUNC;
	REG_IF |= INT_KEYPAD;
}

void _IH_CASSETTE()
{
	INT_CASSETTE_FUNC;
	REG_IF |= INT_CASSETTE;
}

void (*IntrTable[])()  =
{
	_IH_VBLANK,
	_IH_HBLANK,
	_IH_VCOUNT,
	_IH_TIMER0,
	_IH_TIMER1,
	_IH_TIMER2,
	_IH_TIMER3,
	_IH_SERIAL,
	_IH_DMA0,
	_IH_DMA1,
	_IH_DMA2,
	_IH_DMA3,
	_IH_KEYPAD,
	_IH_CASSETTE
};

void EnableInterrupt(u16 intr)
{
	REG_IME = 0;

	if (intr | INT_VBLANK)
		REG_DISPSTAT |= BIT3;
	if (intr | INT_HBLANK)
		REG_DISPSTAT |= BIT4;
	if (intr | INT_VCOUNT)
		REG_DISPSTAT |= BIT5;
	if (intr | INT_TIMER0)
		REG_TM0CNT |= BIT7;
	if (intr | INT_TIMER1)
		REG_TM1CNT |= BIT7;
	if (intr | INT_TIMER2)
		REG_TM2CNT |= BIT7;
	if (intr | INT_TIMER3)
		REG_TM3CNT |= BIT7;
	if (intr | INT_SERIAL)
		REG_SCCNT_L |= BIT14;
	if (intr | INT_DMA0)
		REG_DMA0CNT_H |= BIT14;
	if (intr | INT_DMA1)
		REG_DMA1CNT_H |= BIT14;
	if (intr | INT_DMA2)
		REG_DMA2CNT_H |= BIT14;
	if (intr | INT_DMA3)
		REG_DMA3CNT_H |= BIT14;
		
	// If you're generating a Keypad interrupt, take a look at
	// REG_P1CNT (0x04000132) stuff for setting the control to it.

	REG_IE |= intr;
	REG_IME = 1;
}

void DisableInterrupt(u16 intr)
{
	REG_IE &= (!intr);
}

#endif

