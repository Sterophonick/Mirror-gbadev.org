/*******************************************************************************
 *
 *  colorDemo.cpp
 *
 *  colorDemo : A simple demo for checking out the color capabilities of
 *              the GBA.
 *
 *  Copyright 2002+ by Sean Connelly (aka Peebrain) http://www.pbwhere.com
 *  All Rights Reserved.
 *
 *  Created with DevKitAdv gcc 3.0.2 and ConTEXT v0.97.2a
 ******************************************************************************/

//#define SHADOW_OAM

// Interrupt Functions
#define INT_VBLANK_FUNC
#define INT_HBLANK_FUNC
#define INT_VCOUNT_FUNC
#define INT_TIMER0_FUNC
#define INT_TIMER1_FUNC
#define INT_TIMER2_FUNC
#define INT_TIMER3_FUNC
#define INT_SERIAL_FUNC
#define INT_DMA0_FUNC
#define INT_DMA1_FUNC
#define INT_DMA2_FUNC
#define INT_DMA3_FUNC
#define INT_KEYPAD_FUNC
#define INT_CASSETTE_FUNC

#include "pwgba.cpp"
#include "font.cpp"

#define IF_KEY_HIT(k) 		if (s_key##k) { if (o_key##k) {
#define END_KEY_HIT(k) 		} o_key##k = 0;	} else { o_key##k = 1; }

#define IF_KEY_DRAG(k)              if (s_key##k) { if (o_key##k <= 1) {
#define END_KEY_DRAG(k, one, two)   if (o_key##k == 0) o_key##k = one; else o_key##k = two; } else o_key##k--; } else o_key##k = 0;

u16 *map = (u16 *)0x6008000;
u16 posx = 7;
u16 posy = 1;

char nibbleToHex(int h)
{
	h = h & 0xF;
	if (h == 1) return '1';
	if (h == 2) return '2';
	if (h == 3) return '3';
	if (h == 4) return '4';
	if (h == 5) return '5';
	if (h == 6) return '6';
	if (h == 7) return '7';
	if (h == 8) return '8';
	if (h == 9) return '9';
	if (h ==10) return 'A';
	if (h ==11) return 'B';
	if (h ==12) return 'C';
	if (h ==13) return 'D';
	if (h ==14) return 'E';
	if (h ==15) return 'F';
	return '0';
}

void printAt(int x, int y, int pal, char *str)
{
	do {
		int p = pal;
		if (x == posx && y == posy)
			p = 1;
		map[(x++) + (y << 5)] = (*str - 32) | (p << 12);
	} while (*(++str));
}

char getChar(char c)
{
	if (c < 32)
		return '.';
	if (c > 127)
		return '.';
	return c;
}

int main()
{
	REG_DISPCNT = 0x0100; // Mode 0, Bg 0
	REG_BG0CNT = 0x1000; // Data 0x6000000, Map 0x6008000
	s_dmaCopy3(font, (void *)0x6000000, FONT_DWORDS, BIT10 | BIT15);
	s_bgPalette[0x00] = s_color( 0, 0, 0);
	s_bgPalette[0x01] = s_color( 0, 0, 0);
	s_bgPalette[0x02] = s_color(31,31,31);
	s_bgPalette[0x10] = s_color( 0, 0, 0);
	s_bgPalette[0x11] = s_color(31,31, 0);
	s_bgPalette[0x12] = s_color( 0, 0, 0);
	s_bgPalette[0x20] = s_color( 0, 0, 0);
	s_bgPalette[0x21] = s_color(31, 0, 0);
	s_bgPalette[0x22] = s_color(31,31,31);

	printAt(0, 0, 2, "SRAM Hex Editor    pbwhere.com");

	u16 address = 0;
	char line[32];
	u16 drawline, lineaddy, pal;
	u16 mode = 0;
	u16 o_keyA = 1;
	u16 o_keyB = 1;
	u16 o_keyUp = 1;
	u16 o_keyDown = 1;
	u16 o_keyLeft = 1;
	u16 o_keyRight = 1;
	u16 o_keySelect = 1;
	u16 o_keyStart = 1;
	u16 o_keyL = 1;
	
	int hitstart = 0;

	while(1)
	{
		while (!(REG_DISPSTAT & 1));

		hitstart = 0;
		IF_KEY_HIT(Start)
			hitstart = 1;
		END_KEY_HIT(Start)

		if (hitstart)
		{
			int opt = 0;
			int oldpx = posx;
			int oldpy = posy;
			int breakit = 0;
			posx = 0;
			posy = 0;
			printAt(0, 1, 0, "                              ");
			printAt(0, 2, 0, "          Functions           ");
			printAt(0, 3, 0, "                              ");
			printAt(0, 4, 0, "                              ");
			printAt(0, 5, 0, "                              ");
			printAt(0, 6, 0, "                              ");
			printAt(0, 7, 0, "                              ");
			printAt(0, 8, 0, "                              ");
			printAt(0, 9, 0, "                              ");
			printAt(0,10, 0, "  Page 1 is the memory from   ");
			printAt(0,11, 0, "   0x0E000000 to 0x0E007FFF   ");
			printAt(0,12, 0, "                              ");
			printAt(0,13, 0, "  Page 2 is the memory from   ");
			printAt(0,14, 0, "   0x0E008000 to 0x0E00FFFF   ");
			printAt(0,15, 0, "                              ");
			printAt(0,16, 0, "The concept is that most games");
			printAt(0,17, 0, "use less than 32k,so the extra");
			printAt(0,18, 0, "32k left can be used for more ");
			printAt(0,19, 0, "saves or for backup.          ");

			while(breakit == 0)
			{
				while (!(REG_DISPSTAT & 1));
				IF_KEY_HIT(Up)
					if (opt > 0)
						opt--;
				END_KEY_HIT(Up)
				
				IF_KEY_HIT(Down)
					if (opt < 4)
						opt++;
				END_KEY_HIT(Down)
				
				IF_KEY_HIT(B)
					breakit = 1;
				END_KEY_HIT(B)

				IF_KEY_HIT(Start)
					breakit = 1;
				END_KEY_HIT(Start);
				
				IF_KEY_HIT(A)
					if (opt == 0)
					{
						for (u32 i = 0; i < 0x8000; i++)
							s_Sram[i + 0x8000] = s_Sram[i];
					}
					else if (opt == 1)
					{
						for (u32 i = 0; i < 0x8000; i++)
							s_Sram[i] = s_Sram[i + 0x8000];
					}
					else if (opt == 2)
					{
						for (u32 i = 0; i < 0x8000; i++)
						{
							char read = s_Sram[i];
							s_Sram[i] = s_Sram[i + 0x8000];
							s_Sram[i + 0x8000] = read;
						}
					}
					else if (opt == 3)
					{
						for (u32 i = 0; i < 0x8000; i++)
							s_Sram[i] = 0xFF;
					}
					else if (opt == 4)
					{
						for (u32 i = 0; i < 0x8000; i++)
							s_Sram[i + 0x8000] = 0xFF;
					}
					breakit = 1;
				END_KEY_HIT(A)

				printAt(3, 4, opt == 0 ? 1 : 0, " COPY Page 1 TO Page 2 ");
				printAt(3, 5, opt == 1 ? 1 : 0, " COPY Page 2 TO Page 1 ");
				printAt(3, 6, opt == 2 ? 1 : 0, " SWAP Page 1 `N Page 2 ");
				printAt(3, 7, opt == 3 ? 1 : 0, " FILL Page 1 WITH 0xFF ");
				printAt(3, 8, opt == 4 ? 1 : 0, " FILL Page 2 WITH 0xFF ");
			}

			while(s_keyB);
			while(s_keyStart);
			while(s_keyA);

			posx = oldpx;
			posy = oldpy;
		}

		IF_KEY_HIT(Select)
			if (mode == 0)
			{
				mode = 1;
				posx = 5;
			}
			else
			{
				mode = 0;
				posx = 7;
			}
		END_KEY_HIT(Select)
		
		IF_KEY_HIT(L)
			address += 0x8000;
		END_KEY_HIT(L)

		IF_KEY_DRAG(Right)
			posx++;
			if (mode == 0)
			{
				if (posx ==  9) posx = 10;
				if (posx == 12) posx = 13;
				if (posx == 15) posx = 16;
				if (posx == 18) posx = 19;
				if (posx == 21) posx = 22;
				if (posx == 24) posx = 25;
				if (posx == 27) posx = 28;
				if (posx == 30) posx = 29;
				if (s_keyR)
					posx = 29;
			}
			else
			{
				if (posx == 21) posx = 20;
				if (s_keyR)
					posx = 20;
			}
		END_KEY_DRAG(Right, 40, 8)

		IF_KEY_DRAG(Left)
			posx--;
			if (mode == 0)
			{
				if (posx ==  6) posx = 7;
				if (posx ==  9) posx = 8;
				if (posx == 12) posx = 11;
				if (posx == 15) posx = 14;
				if (posx == 18) posx = 17;
				if (posx == 21) posx = 20;
				if (posx == 24) posx = 23;
				if (posx == 27) posx = 26;
				if (s_keyR)
					posx = 7;
			}
			else
			{
				if (posx == 4) posx = 5;
				if (s_keyR)
					posx = 5;
			}
		END_KEY_DRAG(Left, 40, 8)
		
		IF_KEY_DRAG(Down)
			if (s_keyR)
				address += 152;
			else
			{
				if (posy < 19)
					posy++;
				else
					address += 8;
			}
		END_KEY_DRAG(Down, 40, 8)

		IF_KEY_DRAG(Up)
			if (s_keyR)
				address -= 152;
			else
			{
				if (posy > 1)
					posy--;
				else
					address -= 8;
			}
		END_KEY_DRAG(Up, 40, 8)
		
		u16 keyhit = 0;

		IF_KEY_DRAG(A)
			keyhit = 1;
		END_KEY_DRAG(A, 40, 8)
		
		IF_KEY_DRAG(B)
			keyhit = 2;
		END_KEY_DRAG(B, 40, 8)
		
		if (keyhit > 0)
		{
			int offset = (posy - 1) * 8;
			if (mode == 0)
			{
				int over = posx - 7;
				int byte = over / 3;
				int lowb = over % 3;
				u16 addy = address + offset + byte;
				char read = s_Sram[addy];
				if (lowb == 0)
				{
					int v = read >> 4;
					if (keyhit == 1)
						v = (v + 1) & 0xF;
					else
						v = (v + 15) & 0xF;
					read = (v << 4) | (read & 0xF);
				}
				else
				{
					int v = read;
					if (keyhit == 1)
						v = (v + 1) & 0xF;
					else
						v = (v + 15) & 0xF;
					read = v | (read & 0xF0);
				}
				s_Sram[addy] = read;
			}
			else
			{
				int over = posx - 5;
				int byte = over / 2;
				int lowb = over % 2;
				u16 addy = address + offset + byte;
				char read = s_Sram[addy];
				if (lowb == 0)
				{
					int v = read >> 4;
					if (keyhit == 1)
						v = (v + 1) & 0xF;
					else
						v = (v + 15) & 0xF;
					read = (v << 4) | (read & 0xF);
				}
				else
				{
					int v = read;
					if (keyhit == 1)
						v = (v + 1) & 0xF;
					else
						v = (v + 15) & 0xF;
					read = v | (read & 0xF0);
				}
				s_Sram[addy] = read;
			}
		}

		lineaddy = address;
		for (drawline = 1; drawline < 20; drawline++)
		{
			line[ 0] = nibbleToHex(lineaddy >> 12);
			line[ 1] = nibbleToHex(lineaddy >>  8);
			line[ 2] = nibbleToHex(lineaddy >>  4);
			line[ 3] = nibbleToHex(lineaddy      );

			if (mode == 0)
			{
				line[ 4] = ' ';
				line[ 5] = ':';
				line[ 6] = ' ';
				line[ 7] = nibbleToHex(s_Sram[lineaddy    ] >> 4);
				line[ 8] = nibbleToHex(s_Sram[lineaddy    ]     );
				line[ 9] = ' ';
				line[10] = nibbleToHex(s_Sram[lineaddy + 1] >> 4);
				line[11] = nibbleToHex(s_Sram[lineaddy + 1]     );
				line[12] = ' ';
				line[13] = nibbleToHex(s_Sram[lineaddy + 2] >> 4);
				line[14] = nibbleToHex(s_Sram[lineaddy + 2]     );
				line[15] = ' ';
				line[16] = nibbleToHex(s_Sram[lineaddy + 3] >> 4);
				line[17] = nibbleToHex(s_Sram[lineaddy + 3]     );
				line[18] = ' ';
				line[19] = nibbleToHex(s_Sram[lineaddy + 4] >> 4);
				line[20] = nibbleToHex(s_Sram[lineaddy + 4]     );
				line[21] = ' ';
				line[22] = nibbleToHex(s_Sram[lineaddy + 5] >> 4);
				line[23] = nibbleToHex(s_Sram[lineaddy + 5]     );
				line[24] = ' ';
				line[25] = nibbleToHex(s_Sram[lineaddy + 6] >> 4);
				line[26] = nibbleToHex(s_Sram[lineaddy + 6]     );
				line[27] = ' ';
				line[28] = nibbleToHex(s_Sram[lineaddy + 7] >> 4);
				line[29] = nibbleToHex(s_Sram[lineaddy + 7]     );
			}
			else
			{
				line[ 4] = ':';
				line[ 5] = nibbleToHex(s_Sram[lineaddy    ] >> 4);
				line[ 6] = nibbleToHex(s_Sram[lineaddy    ]     );
				line[ 7] = nibbleToHex(s_Sram[lineaddy + 1] >> 4);
				line[ 8] = nibbleToHex(s_Sram[lineaddy + 1]     );
				line[ 9] = nibbleToHex(s_Sram[lineaddy + 2] >> 4);
				line[10] = nibbleToHex(s_Sram[lineaddy + 2]     );
				line[11] = nibbleToHex(s_Sram[lineaddy + 3] >> 4);
				line[12] = nibbleToHex(s_Sram[lineaddy + 3]     );
				line[13] = nibbleToHex(s_Sram[lineaddy + 4] >> 4);
				line[14] = nibbleToHex(s_Sram[lineaddy + 4]     );
				line[15] = nibbleToHex(s_Sram[lineaddy + 5] >> 4);
				line[16] = nibbleToHex(s_Sram[lineaddy + 5]     );
				line[17] = nibbleToHex(s_Sram[lineaddy + 6] >> 4);
				line[18] = nibbleToHex(s_Sram[lineaddy + 6]     );
				line[19] = nibbleToHex(s_Sram[lineaddy + 7] >> 4);
				line[20] = nibbleToHex(s_Sram[lineaddy + 7]     );
				line[21] = ':';
				line[22] = getChar(s_Sram[lineaddy    ]);
				line[23] = getChar(s_Sram[lineaddy + 1]);
				line[24] = getChar(s_Sram[lineaddy + 2]);
				line[25] = getChar(s_Sram[lineaddy + 3]);
				line[26] = getChar(s_Sram[lineaddy + 4]);
				line[27] = getChar(s_Sram[lineaddy + 5]);
				line[28] = getChar(s_Sram[lineaddy + 6]);
				line[29] = getChar(s_Sram[lineaddy + 7]);
			}
			line[30] = 0;
			printAt(0, drawline, 0, line);
			lineaddy += 8;
		}
	}
	return 0;
}
