// Donald Peeke-Vout
// background256.cpp

#include "gba.h"
#include "background256.h"
#include "screenmode.h"

bg::bg(u8 charBase, u8 screenBase, u8 prior, u8 bgNum) {
  mosaic = 0;
  colorMode = 0;
  size = 0;
  charBaseBlock = charBase;
  screenBaseBlock = screenBase;
  priority = prior;
  wrapAround = 0;
  x_scroll = 0;
  y_scroll = 0;
  DX = 0;  DY = 0;
  number = bgNum;
}

void bg::EnableBackground() {
  u16 temp;   // Saves typing  :)

  tileData = (u16*)CharBaseBlock(charBaseBlock);    // Compute proper mem address
  mapData = (u16*)ScreenBaseBlock(screenBaseBlock); // Same thing for screen base

  // Create a BGxCNT register setting and put into temp
  temp = priority | (charBaseBlock << CHAR_SHIFT) | mosaic | colorMode | 
         (screenBaseBlock << SCREEN_SHIFT) | wrapAround | size;

  switch(number) {
  case 0: {
    REG_BG0CNT = temp;
    REG_DISPCNT |= BG0_ENABLE;
  } break;
  case 1: {
    REG_BG1CNT = temp;
    REG_DISPCNT |= BG1_ENABLE;
  } break;
  case 2: {
    REG_BG2CNT = temp;
    REG_DISPCNT |= BG2_ENABLE;
  } break;
  case 3: {
    REG_BG3CNT = temp;
    REG_DISPCNT |= BG3_ENABLE;
  } break;

  default: break;
  }
}

void bg::UpdateBackground() {
  switch(number) {
  case 0: {
    REG_BG0HOFS = x_scroll;
    REG_BG0VOFS = y_scroll;
  } break;
  case 1: {
    REG_BG1HOFS = x_scroll;
    REG_BG1VOFS = y_scroll;
  } break;
  case 2: {
    if (!(REG_DISPCNT & MODE_0)) {  // Mode 0 is the only mode where bg2 & 3 are text bg's
      REG_BG2X = DX;
      REG_BG2Y = DY;

      REG_BG2PA = PA;
      REG_BG2PB = PB;
      REG_BG2PC = PC;
      REG_BG2PD = PD;
    }
    else {
      REG_BG2HOFS = x_scroll;
      REG_BG2VOFS = y_scroll;
    }
  } break;
  case 3: {
    if (!(REG_DISPCNT & MODE_0)) {
      REG_BG3X = DX;
      REG_BG3Y = DY;

      REG_BG3PA = PA;
      REG_BG3PB = PB;
      REG_BG3PC = PC;
      REG_BG3PD = PD;
    }
    else {
      REG_BG3HOFS = x_scroll;
      REG_BG3VOFS = y_scroll;
    }
  } break;

  default: break;
  }
}

void bg::setColorMode(u16 color) {
  colorMode = color;
}

void bg::setMosaic(u16 mos) {
  mosaic = mos;
}

void bg::setWrapAround(u16 wrap) {
  wrapAround = wrap;
}

void bg::setSize(u16 sizeMode) {
  size = sizeMode;
}

void bg::setCoord(s16 x, s16 y) {
  x_scroll = x;
  y_scroll = y;
}

void bg::LoadPaletteEntry(u16 location, u16 paletteEntry) {
  u16 *palPtr = TilePaletteMem;
  palPtr[location] = paletteEntry;
}

void bg::LoadPalette(u16* paletteData) {
  for (u8 i = 0; i < 255; i++)
    LoadPaletteEntry(i, paletteData[i]);
}
