// Donald Peeke-Vout
// background256.h

#ifndef BACKGROUND_H
#define BACKGROUND_H

#include "gba.h"

// Background (BGxCNT) properties

#define BG_MOSAIC_ENABLE 0x40
#define BG_COLOR_256 0x80
#define BG_COLOR_16 0x0

#define TEXTBG_SIZE_256x256 0x0
#define TEXTBG_SIZE_256x512 0x8000
#define TEXTBG_SIZE_512x256 0x4000
#define TEXTBG_SIZE_512x512 0xC000

#define ROTBG_SIZE_128x128 0x0
#define ROTBG_SIZE_256x256 0x4000
#define ROTBG_SIZE_512x512 0x8000
#define ROTBG_SIZE_1024x1024 0xC000

#define BG_WRAPAROUND 0x2000

#define CharBaseBlock(n) (((n)*0x4000)+0x6000000)
#define ScreenBaseBlock(n) (((n)*0x800)+0x6000000)
#define CHAR_SHIFT 2
#define SCREEN_SHIFT 8

#define TilePaletteMem (u16*)0x5000000  // Beginning of tile palette memory

class bg {
 public:
  bg(u8 charBase, u8 screenBase, u8 prior, u8 bgNum);
  void EnableBackground();
  void UpdateBackground();
  void LoadPaletteEntry(u16 location, u16 paletteEntry);
  void LoadPalette(u16* paletteData);
  void setColorMode(u16 color);
  void setMosaic(u16 mos);
  void setWrapAround(u16 wrap);
  void setSize(u16 sizeMode);
  void setCoord(s16 x, s16 y);
  // void RotateBackground(int angle, int centre_x, int centre_y, FIXED zoom);

 private:
  u16 *tileData;
  u16 *mapData;
  u8 mosaic;
  u8 colorMode;  // 256 or 16 colors
  u8 priority;   // priority (0-3)
  u16 size;      // size of the background
  u8 charBaseBlock;       // (0-3)
  u8 number;              // (0-3)
  u8 screenBaseBlock;     // (0-31)
  u8 wrapAround;          // Wrap around flag
  s16 x_scroll, y_scroll; // Horiz & Vert offsets
  s32 DX, DY;             // Scroll for rotations screens
  s16 PA, PB, PC, PD;     // hold rotation attributes for the background
};

#endif
