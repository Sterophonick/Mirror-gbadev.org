// Donald Peeke-Vout
// spritemgr256.h
// This is the header file for the spriteMgr class.  The spriteMgr class is
// used for sprite manipulation and management for gameboy advance applications. 

#include "gba.h"  // Include gba types (u8, u16, etc.)

#ifndef SPRITEMGR256_H
#define SPRITEMGR256_H

// There are 128 entries in the Object Attribute Memory, each has 3 16-bit fields
// Attribute0, Attribute1 and Attribute2 which define the properties of up to
// 128 sprites.  The size and shape of a sprite is defined by the shape bits in
// Attribute0 (14-15) and the size bits in Attribute1 (14-15).

// Table 1
//              ____________________________________________________________
//              | SIZE_8 (00) | SIZE_16 (01) | SIZE_32 (10) | SIZE_64 (11)  |
// +------------+-------------+--------------+--------------+---------------+
// |SQUARE (00) |    8 x 8    |   16 x 16    |   32 x 32    |   64 x 64     |
// |WIDE   (01) |   16 x 8    |   32 x 8     |   32 x 16    |   64 x 32     |
// |TALL   (10) |   8 x 16    |   8 x 32     |   16 x 32    |   32 x 64     |
// +------------+-------------+--------------+--------------+---------------+

// Attribute0 bits
// ____________________________________________________________________________________
// |    bits    | 15 | 14 | 13 | 12 | 11 | 10 |  9 | 8 | 7 | 6 | 5 | 4 | 3 | 2 | 1 | 0 |
// +------------+----+----+----+----+----+----+----+---+---+---+---+---+---+---+---+---+
// | attribute0 |  shape  |  C |  M |  Mode   | SD | R |         Y-coordinate          |
// -------------------------------------------------------------------------------------

//  bits 0-7   :The y coordinate of the object, value between 0 and 255.  To draw a sprite
//              half off the screen (at the top) then the value 255 + y works properly
//              (where y is negative).
//  bit 8      :The rotation/scaling flag.  If set, the sprite will be drawn with the
//              rotation/scaling parameters specified.
//  bit 9      :The size double flag will increase the size of the individual sprites
//              drawing area x 2.
//  bits 10-11 :The mode flags deal with alpha blending.
//  bit 12     :The mosaic flag.  When set, the sprite will have the mosaic value applied
//              to it.
//  bit 13     :Color mode.  If set, it defines the sprite as 256 colors.  Cleared, it is
//              a 16 color sprite.
//  bits 14-15 :The object shape.  (see table 1)
		 

#define SPR_ROTATION_FLAG 0x100
#define SPR_SIZE_DOUBLE 0x200
#define SPR_MODE_NORMAL 0x0
#define SPR_MODE_TRANSPARENT 0x400
#define SPR_MODE_WINDOWED 0x800
#define SPR_MOSAIC 0x1000
#define SPR_COLOR_16 0x0000
#define SPR_COLOR_256 0x2000
#define SPR_SQUARE 0x0
#define SPR_WIDE 0x4000
#define SPR_TALL 0x8000

// Attribute1 bits
// ____________________________________________________________________________________
// |    bits    | 15 | 14 | 13 | 12 | 11 | 10 |  9 | 8 | 7 | 6 | 5 | 4 | 3 | 2 | 1 | 0 |
// +------------+----+----+----+----+----+----+----+---+---+---+---+---+---+---+---+---+
// | attribute1 |  size   | VF | HF | RotDataIndex |          X-coordinate             |
// -------------------------------------------------------------------------------------

//  bits 0-8   :The x coordinate of the object.  To draw a sprite half off the screen 
//              (at the left) then the value 512 + x works properly (where x is negative).
//  bits 9-13  :If the rotation/scaling flag is set in Attribute0, then bits 9-13 are the
//              index of the sprites rotation/scaling parameters.  If rotation/scaling bit
//              is not set, bits 9-11 are not used and 12 when set will horizontally flip
//              the sprite, 13 when set will vertically flip the sprite.
//  bits 14-15 :The object size (see table 1)


#define SPR_ROTDATA(n) ((n) << 9)
#define SPR_HORIZONTAL_FLIP 0x1000
#define SPR_VERTICAL_FLIP 0x2000
#define SPR_SIZE_8 0x0
#define SPR_SIZE_16 0x4000
#define SPR_SIZE_32 0x8000
#define SPR_SIZE_64 0xC000

// Attribute2 bits
// ____________________________________________________________________________________
// |    bits    | 15 | 14 | 13 | 12 | 11 | 10 |  9 | 8 | 7 | 6 | 5 | 4 | 3 | 2 | 1 | 0 |
// +------------+----+----+----+----+----+----+----+---+---+---+---+---+---+---+---+---+
// | attribute2 |  Palette number   | Priority|              Character Name            |
// -------------------------------------------------------------------------------------

//  bits 0-9   :Index into sprite character memory of the first 8x8 tile of the sprite.
//  bits 10-11 :Sets the priority (0-3). A higher priority sprite will be drawn on top
//              of a sprite with a lower priority.
//  bits 12-15 :Sets the palette number in 16 color mode.  These bits are ignored for
//              256 color sprites.

#define SPR_PRIORITY(n) ((n) << 10)
#define SPR_PALETTE(n) ((n) << 12)

// Other useful #defines...

#define PI 3.14159
#define FIXED s16  // Used for calculating floating point numbers
#define RADIAN(n) (((float)n)/(float)180 * PI)
#define CharMem (u16*)0x6010000        // Beginning of sprite character memory
#define OBJPaletteMem (u16*)0x5000200  // Beginning of sprite palette memory
#define OAM (u16*)0x7000000            // Beginning of object attribute memory

// Classes

//  OAMEntry Defines 64 bits for a single object attribute entry.  Contains Attribute0,
//  Attribute1 and Attribute2 as described above.  Attribute3 contains rotation
//  and scaling data.

class OAMEntry {
 public:
  u16 attribute0;
  u16 attribute1;
  u16 attribute2;
  u16 attribute3;
};

// rotData is mapped onto the Object Attribute Memory and is used to control the rotation
// and scaling entries.  Each rotation/scaling entry spans 4 OAMEntry's, the fillers
// essentially 'skip-over' the attribute 0 - 2.

class rotData {
 public:
  u16 filler1[3];
  u16 pa;
  u16 filler2[3];
  u16 pb;
  u16 filler3[3];
  u16 pc;
  u16 filler4[3];
  u16 pd;
};

// spriteMgr class contains all the useful functions for sprite manipulation.  See
// spritemgr256.cpp for definitions of each function.

class spriteMgr {
 public:
  spriteMgr();
  void sprLoadGraphic(u16 location, u16 size, u16* imageData);
  void sprLoadPaletteEntry(u16 location, u16 paletteEntry);
  void sprLoadPalette(u16* paletteData);
  void sprCopyOAM(void);
  void sprInitializeSprites();
  void sprCreateSprite(u16 number, u16 graphicLocation, u16 attrib0, u16 attrib1, u16 attrib2);
  void sprMoveSprite(u16 number, int x, int y);
  void sprInitRotation();
  void sprRotate(int rotIndex, int angle, FIXED x_scale, FIXED y_scale);

 private:
  OAMEntry sprites[128];  // 128 Object Attribute entries maps onto physical OAM of the GBA.
  rotData *rotSprites;    // Maps onto the physcial OAM of the GBA.

  FIXED COS[360];
  FIXED SIN[360];
};


#endif
