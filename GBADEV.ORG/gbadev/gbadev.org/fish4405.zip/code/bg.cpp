// Donald Peeke-Vout
// bg.cpp
//  My first adventure with tile backgrounds! Yay!  Looks like a bad
//  case of parallax scrolling to me...

#include "gba.h"
#include "keypad.h"
#include "stdlib.h"
#include "background256.h"
#include "spritemgr256.h"
#include "screenmode.h"
#include "bg_back.h"
#include "bg_front.h"
#include "bg_blue.h"
#include "fish.h"
#include "bubble.h"

#define ScanReg (volatile u16*)0x4000006  // Define the "scanline" register as volatile.
                                          // (i.e. changes outside the scope of the program)

void WaitForVblank() {  // Function loops until screen is finished being drawn to.
  u8 x = 0;
  while(*ScanReg < 160)   // Dummy loop
    x++;   
}

int main(void) {
  // If it's interactive, we need the awesome kaypad class.
  keypad *keys = new keypad();

  // sprite manager extraordinaire!
  spriteMgr *sprites = new spriteMgr();
  sprites->sprInitializeSprites();

  // Screen mode 0, enable sprites (why not?!) and 1D sprite mapping.
  SetMode(MODE_0 | OBJ_ENABLE | OBJ_MAP_1D);

  // Load tile map for front background into memory (screen base 0) 
  u16* ScrBlock = (u16*)0x6000000;
  for (int i = 0; i < 1024; i++)
    ScrBlock[i] = bg_front_map[i];

  // Load tile map for back background into memory (screen base 1)
  ScrBlock = (u16*)0x6000800;
  for (int i = 0; i < 1024; i++)
    ScrBlock[i] = bg_back_map[i];

  // Load tile map for blue background into memory (screen base 2)
  ScrBlock = (u16*)0x6001000;
  for (int i = 0; i < 1024; i++)
    ScrBlock[i] = bg_blue_map[i];

  // Load front background tile graphics into memory (char base 1)
  u16 *chrBlock = (u16*)0x6004000;
  for (u16 i = 0; i < 2688; i++)
    chrBlock[i] = bg_front_gfx[i];

  // load back background tile graphics into memory (char base 2)
  chrBlock = (u16*)0x6008000;
  for (u16 i = 0; i < 6464; i++)
    chrBlock[i] = bg_back_gfx[i];

  // load back background tile graphics into memory (char base 3)
  chrBlock = (u16*)0x600C000;
  for (u16 i = 0; i < 6464; i++)
    chrBlock[i] = bg_blue_gfx[i];

  // Create bg object for Front background with char base block 1,
  // screen base block 0, priority 0 and background num 0.
  bg *BGFront = new bg(1, 0, 0, 0);

  // Create bg object for Back background with char base block 2,
  // screen base block 1, priority 1 and background num 1.
  bg *BGBack = new bg(2, 1, 1, 1);

 // Create bg object for Blue background with char base block 3,
  // screen base block 2, priority 2 and background num 2.
  bg *BGBlue = new bg(3, 2, 2, 2);

  // Load up the tile map palette
  BGFront->LoadPalette(bg_front_pal);

  // Set all bg's to 256 color mode
  BGFront->setColorMode(BG_COLOR_256);
  BGBack->setColorMode(BG_COLOR_256);
  BGBlue->setColorMode(BG_COLOR_256);

  // set all bg's to size 256x256
  BGFront->setSize(TEXTBG_SIZE_256x256);
  BGBack->setSize(TEXTBG_SIZE_256x256);
  BGBlue->setSize(TEXTBG_SIZE_256x256);

  // enable wrap around on all bg's
  BGFront->setWrapAround(BG_WRAPAROUND);
  BGBack->setWrapAround(BG_WRAPAROUND);
  BGBlue->setWrapAround(BG_WRAPAROUND);
  
  // lastly, enable all the bg's
  BGFront->EnableBackground();
  BGBack->EnableBackground();
  BGBlue->EnableBackground();

  // Sprite stuff
  sprites->sprLoadPalette(fish_pal);

  sprites->sprLoadGraphic(0, 512, fish_gfx);
  sprites->sprLoadGraphic(32, 32, bubble_gfx); 

  sprites->sprCreateSprite(0, 0, SPR_COLOR_256 | SPR_SQUARE, 
		          SPR_SIZE_32, 
			  SPR_PRIORITY(0));

  sprites->sprCreateSprite(1, 64, SPR_COLOR_256 | SPR_SQUARE,
			  SPR_SIZE_8,
			  SPR_PRIORITY(0));

  sprites->sprCreateSprite(2, 64, SPR_COLOR_256 | SPR_SQUARE,
			  SPR_SIZE_8,
			  SPR_PRIORITY(0));

  sprites->sprCreateSprite(3, 64, SPR_COLOR_256 | SPR_SQUARE,
			  SPR_SIZE_8,
			  SPR_PRIORITY(0));

  sprites->sprMoveSprite(0, 103, 63);

  WaitForVblank();
  sprites->sprCopyOAM();

  s16 x = 0;
  s16 y = 0;
  
  s16 fishY = 63;

  s16 bubbleX[3] = {115, 115, 115};
  s16 bubbleY[3] = {55, 37, 19};
  s8 bubbleVX[3] = {3, -3, 0};
  s8 bubbleAX[3] = {-1, 1, -1};
  s8 bubbleLife[3] = {60, 42, 24};

  u8 timer = 0;

  while(1) {
    if (timer == 0) {
      keys->update();
      if (keys->hold(KEY_UP)) {
	if (fishY == 63)
	  for (int i = 0; i < 3; i++)
	    bubbleY[i]++;

	if (y == -40) {
	  fishY--;
	}
	else if (y == 0 && fishY > 63) {
	  fishY--;
	}
	else {
	  y--;
	  if (y < -40)
	    y = -40;
	}
	  if (fishY < 0)
	    fishY = 0;
      }
      if (keys->hold(KEY_DOWN)) {
	if (fishY == 63)
	  for (int i = 0; i < 3; i++)
	    bubbleY[i]--;
	
	if (y == 0) {
	  fishY++;
	}
	else if (y == -40 && fishY < 63) {
	  fishY++;
	}
	else {
	  y++;
	  if (y > 0)
	    y = 0;
	}
	if (fishY > 128)
	  fishY = 128;
      }
      if (keys->hold(KEY_LEFT) || keys->hold(KEY_L)) {
	for (int i = 0; i < 3; i++)
	  bubbleX[i]++;
	x--;
	sprites->sprCreateSprite(0, 0, SPR_COLOR_256 | SPR_SQUARE, 
				 SPR_SIZE_32 | SPR_HORIZONTAL_FLIP, 
				 SPR_PRIORITY(0));
      }
      if (keys->hold(KEY_RIGHT) || keys->hold(KEY_R)) {
	for (int i = 0; i < 3; i++)
	  bubbleX[i]--;
      	x++;
	sprites->sprCreateSprite(0, 0, SPR_COLOR_256 | SPR_SQUARE, 
				 SPR_SIZE_32, 
				 SPR_PRIORITY(0));
      }

      for (int i = 0; i < 3; i++) {
	bubbleY[i]--;
	if (bubbleY[i] < -8)
	  bubbleY[i] = -8;
	bubbleLife[i]--;

	if (bubbleLife[i] == 0) {
	  bubbleY[i] = fishY - 5;
	  bubbleX[i] = 115;
	  bubbleLife[i] = 60;
	}

	bubbleX[i] += bubbleVX[i];
	bubbleVX[i] += bubbleAX[i];
	
	if (bubbleVX[i] == -3)
	  bubbleAX[i] = 1;
	if (bubbleVX[i] == 3)
	  bubbleAX[i] = -1;

	sprites->sprMoveSprite(i + 1, bubbleX[i], bubbleY[i]);
      }

      sprites->sprMoveSprite(0, 103, fishY);
      WaitForVblank();
      sprites->sprCopyOAM();
    }
    timer++;

    if (timer == 75)
      timer = 0;

    BGFront->setCoord(2 * x, 2 * y);
    BGBack->setCoord(x, y);
    WaitForVblank();
    BGFront->UpdateBackground();
    WaitForVblank();
    BGBack->UpdateBackground();
  }
}
