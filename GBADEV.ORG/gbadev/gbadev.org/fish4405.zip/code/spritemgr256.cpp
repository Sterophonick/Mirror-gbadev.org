// Donald Peeke-Vout
// spritemgr256b.cpp
// This file contains functions that manage 256 color sprites for GBA code.

#include "gba.h"
#include "spritemgr256.h"
#include "math.h"

spriteMgr::spriteMgr () {
  rotSprites = (rotData*) sprites;
}

void spriteMgr::sprLoadGraphic(u16 location, u16 size, u16* imageData) {
  u16 *charPtr = CharMem;
  for (u16 i = 0; i < size; i++)
    charPtr[i + 32 * location] = imageData[i];
}

void spriteMgr::sprLoadPaletteEntry(u16 location, u16 paletteEntry) {
  u16 *palPtr = OBJPaletteMem;
  palPtr[location] = paletteEntry;
}

void spriteMgr::sprLoadPalette(u16* paletteData) {
  for (u8 i = 0; i < 255; i++)
    sprLoadPaletteEntry(i, paletteData[i]);
}

void spriteMgr::sprCopyOAM(void) {
  u16* temp = (u16*)sprites;
  u16* OAMPtr = OAM;
  for(u16 loop = 0; loop < 128*4; loop++)
      OAMPtr[loop] = temp[loop];
}

void spriteMgr::sprInitializeSprites() {
  for (int i = 0; i < 128; i++) {
    sprites[i].attribute0 = 160;
    sprites[i].attribute1 = 240;
  }
}

void spriteMgr::sprCreateSprite(u16 number, u16 graphicLocation, u16 attrib0, u16 attrib1, u16 attrib2) {
  sprites[number].attribute0 = attrib0;
  sprites[number].attribute1 = attrib1;
  sprites[number].attribute2 = attrib2 | graphicLocation;
}

void spriteMgr::sprMoveSprite(u16 number, int x, int y) {
  if (x < 0)
    x = 512 + x;
  if (y < 0)
    y = 256 + y;

  sprites[number].attribute1 = sprites[number].attribute1 & 0xFE00;
  sprites[number].attribute1 = sprites[number].attribute1 | x;

  sprites[number].attribute0 = sprites[number].attribute0 & 0xFF00;
  sprites[number].attribute0 = sprites[number].attribute0 | y;
}

void spriteMgr::sprInitRotation() {
  for (int i = 0; i < 360; i++) {
    SIN[i] = (FIXED)(sin(RADIAN(i)) * (1<<8));
    COS[i] = (FIXED)(cos(RADIAN(i)) * (1<<8));
  }
}

void spriteMgr::sprRotate(int rotIndex, int angle, FIXED x_scale, FIXED y_scale) {
  FIXED pa, pb, pc, pd;

  pa = ((x_scale) * COS[angle])>>8;
  pb = ((y_scale) * SIN[angle])>>8;
  pc = ((x_scale) * -SIN[angle])>>8;
  pd = ((y_scale) * COS[angle])>>8;

  rotSprites[rotIndex].pa = pa;
  rotSprites[rotIndex].pb = pb;
  rotSprites[rotIndex].pc = pc;
  rotSprites[rotIndex].pd = pd;
}
