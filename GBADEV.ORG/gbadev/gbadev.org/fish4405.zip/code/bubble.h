// bubble.h
//   Converted by gfx2gba (v1.03, Nov 28 2001) - www.gbacode.net
//
// Original file   :  bubble.bmp, BMP (Windows or OS/2 Bitmap)
// Original size   :  8 x 8 pixels
// Output format   :  256 color sprite
// Converted on    :  Wed Feb 20 22:45:18 2002
//
// FreeImage image library (v2.4.2)
// FreeImage is an open source image library supporting all common
// bitmap formats. See http://www.6ixsoft.com for more details.

u16 bubble_gfx[] =
{ 0x0000, 0xd7d7, 0xd7d7, 0x0000, 0xd700, 0x0000, 0x0000, 0x00d7,
  0x00d7, 0x00cb, 0x0000, 0xd700, 0x00d7, 0x0000, 0x0000, 0xd7cb,
  0x00d7, 0x0000, 0x0000, 0xd7cb, 0x00d7, 0x0000, 0xcb00, 0xd7cb,
  0xd700, 0xcb00, 0xcbcb, 0x00d7, 0x0000, 0xd7d7, 0xd7d7, 0x0000 };

