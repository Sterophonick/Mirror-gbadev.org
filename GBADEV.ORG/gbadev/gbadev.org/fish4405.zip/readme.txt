Don Peeke-Vout - GBA fish demo (July 11/2003)

zip file includes:
 - readme.txt
 - bin (directory contains program binary)
 - code (directory contains code)

This is my 1st attempt using multiple backgrounds to produce
that parallax SNES effect.  Use the D-pad to move the fish
around.

I used DEvKitAdvance to compile the code.  Feel free to use 
the code for whatever you want.  My apologies for lack of
comments, documentation and efficient code. 

Thanks to Dovoto for the GBA tutorials!  They are very helpful.

comments & questions can be directed to narfkoo@hotmail.com
