PONG! Advance
-------------

A very simple game indeed :) I only 
started learning C two days ago, the
same time I decided to write games for
GBA...

This is mainly thanks to the tutorials
and tools by dovoto :

  http://www.thepernproject.com

Controls :
* up/down for up/down :)
* 'A' for continueing after ball goes
  out of play
* 'Start' to start (on title screen)

So there you go :)

I will release sources (assuming 
someone wants them) when I've tidied it
up a bit.

Mat Scales (pornstar@myrealbox.com)
22/08/2002