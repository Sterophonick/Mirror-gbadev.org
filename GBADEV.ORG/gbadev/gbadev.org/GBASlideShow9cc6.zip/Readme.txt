GBASlideShow v0.1
By Darrell Blake

Just a small program I think people may be interested in. Originally I wasn't going to post it because it's such a simple program but I decided to because I intend to extend it dramatically. I created it to show some friends some holiday pics (very small holiday pics now though) and my theory was that it would be easier to write a small program like this than to print them off (I had no ink in the printer).


Instructions
------------

So far the program accepts 10 images called image1.h, image2.h... image10.h. Use whichever program you wish to create the header files (or stick them all in one header file if you wish) and then run make.bat. Once you have your glorious rom run it in your emulator or GBA and use the A button to go to the next picture and the B button to go to the previous picture. I originally created this program in linux but I have noticed that there aren't many people supplying makefile files for linux so I havn't. I just wrote one for windows. If anyone would like a makefile let me know and I'll include it.


If anyone wants to help with this program feel free. I would like to make this a really cool program with lots of functionality. I'm currently working on a QT GUI for linux (I will port it to windows) to create the rom. All it will do really is convert the pictures to header files and then create a rom.
