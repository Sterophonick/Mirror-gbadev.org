//GBASlideShow v0.1
//Darrell Blake

#include "gba.h"
#include "keypad.h"
#include "screenmode.h"
#include "image1.h"
#include "image2.h"
#include "image3.h"
#include "image4.h"
#include "image5.h"
#include "image6.h"
#include "image7.h"
#include "image8.h"
#include "image9.h"
#include "image10.h"

int changepic(int piccount, int x, int y, int loop)
{

	if (piccount == 1)
	{
		SetMode(MODE_4|BG2_ENABLE);
		for(loop = 0; loop < 256; loop++)
			theScreenPalette[loop] = image1Palette[loop];
		for(x=0; x < 120; x++)
			for(y=0; y < 160; y++)
				PlotPixel(x,y,120,(image1Data[y*120+x]));
	}	
	if (piccount == 2)
	{
		SetMode(MODE_4|BG2_ENABLE);
		for(loop = 0; loop < 256; loop++)
			theScreenPalette[loop] = image2Palette[loop];
		for(x=0; x < 120; x++)
			for(y=0; y < 160; y++)
				PlotPixel(x,y,120,(image2Data[y*120+x]));
	}
	if (piccount == 3)
	{
		SetMode(MODE_4|BG2_ENABLE);
		for(loop = 0; loop < 256; loop++)
			theScreenPalette[loop] = image3Palette[loop];
		for(x=0; x < 120; x++)
			for(y=0; y < 160; y++)
				PlotPixel(x,y,120,(image3Data[y*120+x]));
	}
	if (piccount == 4)
	{
		SetMode(MODE_4|BG2_ENABLE);
		for(loop = 0; loop < 256; loop++)
			theScreenPalette[loop] = image4Palette[loop];
		for(x=0; x < 120; x++)
			for(y=0; y < 160; y++)
				PlotPixel(x,y,120,(image4Data[y*120+x]));
	}
	if (piccount == 5)
	{
		SetMode(MODE_4|BG2_ENABLE);
		for(loop = 0; loop < 256; loop++)
			theScreenPalette[loop] = image5Palette[loop];
		for(x=0; x < 120; x++)
			for(y=0; y < 160; y++)
				PlotPixel(x,y,120,(image5Data[y*120+x]));
	}
	if (piccount == 6)
	{
		SetMode(MODE_4|BG2_ENABLE);
		for(loop = 0; loop < 256; loop++)
			theScreenPalette[loop] = image6Palette[loop];
		for(x=0; x < 120; x++)
			for(y=0; y < 160; y++)
				PlotPixel(x,y,120,(image6Data[y*120+x]));
	}
	if (piccount == 7)
	{
		SetMode(MODE_4|BG2_ENABLE);
		for(loop = 0; loop < 256; loop++)
			theScreenPalette[loop] = image7Palette[loop];
		for(x=0; x < 120; x++)
			for(y=0; y < 160; y++)
				PlotPixel(x,y,120,(image7Data[y*120+x]));
	}
	if (piccount == 8)
	{
		SetMode(MODE_4|BG2_ENABLE);
		for(loop = 0; loop < 256; loop++)
			theScreenPalette[loop] = image8Palette[loop];
		for(x=0; x < 120; x++)
			for(y=0; y < 160; y++)
				PlotPixel(x,y,120,(image8Data[y*120+x]));
	}
	if (piccount == 9)
	{
		SetMode(MODE_4|BG2_ENABLE);
		for(loop = 0; loop < 256; loop++)
			theScreenPalette[loop] = image9Palette[loop];
		for(x=0; x < 120; x++)
			for(y=0; y < 160; y++)
				PlotPixel(x,y,120,(image9Data[y*120+x]));
	}
	if (piccount == 10)
	{
		SetMode(MODE_4|BG2_ENABLE);
		for(loop = 0; loop < 256; loop++)
			theScreenPalette[loop] = image10Palette[loop];
		for(x=0; x < 120; x++)
			for(y=0; y < 160; y++)
				PlotPixel(x,y,120,(image10Data[y*120+x]));
	}
}

int main()
{
	int x,y,loop,piccount;
	piccount = 0;
	while(1)
	{
		if (!(*KEYS & KEY_A))
		{
			piccount = piccount + 1;
			if (piccount > 10)
				piccount = 10;
			changepic(piccount, x, y, loop);
		}
		if (!(*KEYS & KEY_B))
		{
			piccount = piccount - 1;
			if (piccount < 1)
				piccount = 1;
			changepic(piccount, x, y, loop);
		}
	}
}
