GBA Visual VRAM manager v 1.0
-----------------------------

for Microsoft Windows 9x/Me/2000/XP, coded by Kay / Aphasia.


This tool is based on PeeBrain's "VRAM MEMORY v1.0" work (see more at http://www.pbwhere.com ).

This freeware tool is intended to provide Nintendo GameBoy Advance VRAM visual management and clearly understand (and see :) what and where is free space left in VRAM.

You need a basic knowledge of GBA VRAM structure and video hardware in order to understand use of this tool.
May be some user will find it usefull for learning purpose.
I hope you'll appreciate it ...


You can submit bugs report and/or suggestions to: <aphasia@libertysurf.fr>



We provide NO ADDITIONAL SUPPORT for this free software.



[Juily 17, 2004]




To do list:
	- Output BGs code setup to assembly / C / C++