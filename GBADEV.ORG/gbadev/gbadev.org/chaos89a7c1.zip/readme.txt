Chaos89 demo for Gameboy Advance by Charles Doty (cdoty@netzero.net), with
asm source.

Here's is a Mode 4 demo that I wrote for the GBA. It's a fairly simple demo,
and only uses Mode 4 for graphics (no sprites). It does do double buffering.
I've included my source code (all asm). I've tried to comment the code as
much as possible. This is the first time I've ever written code for an ARM
processor. The ARM processor is just amazing. It's pretty cool being able
to conditionally execute code based on the Status register.

If anyone has any suggestion about getting this to work on the real
hardware (assuming it doesn't currently), please send them to me. It
currently doesn't have a correct header on it.

Thanks to Marat, all the people contributing demos to
http://www.gbadev.org, and Simon B for keeping it all up to date.

