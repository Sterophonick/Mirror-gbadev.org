Yet Another Pong Demo - Javaspot.net
.coded by visage (Corey)
.dated 22 May 2003

http://gba.javaspot.net

Keys
====
Up: Move paddle up
Down: Move paddle down
R+L: Toggle AI
A: Serve after point against player
Start: Pause

Features
========
(i) Smiley face Pong Ball tells you whether you are winning or losing
(ii) Four forms of AI
      a) First form (0) does not move
      b) Second form (1) simply moves up and down
      c) Third form (2) follows the ball when the ball is going at 
         the paddle.  Otherwise returns to a central position.
      d) Fourth form (3) follows the ball no matter what.



Thanks to everyone who made fun of me and told me I was worthless.  This one goes out to you.

