Hello again. Well uh... yeah. I kept working on the other 'on-the-fly' S3M player and
came up with a converter and voila: we have a new S3M player. Lol. So far, it still has
a bit further to go (eg. stereo, etc) which is why I won't release the source and/or the
library yet. I put 2 songs in it which are controlled like this:

UP:   Play (an incomplete) 'Fight 1' (DON'T PRESS FIRST! I have to find the bug lol!)
DOWN: Play 'Fight 2'
A:    Play a hi hat sample

And that's it for now. When this is finished, I'll release the library, includes, etc.
Until then, happy coding and enjoy! =)

Aiken/Ruben
rubenn93@iprimus.com.au