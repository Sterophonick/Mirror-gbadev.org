Multiboot Menu
Copyright 2002 Damian Yerrick


Multiboot Menu lets you put several GBA multiboot (.mb) programs
into one ROM for use on a flash cartridge, etc. Because it uses
GBFS technology to locate the programs, the programs can be any
size, up to 256 KB (the maximum size of a .mb program).


=== Notes ===

There is an empty file called delete.me in the roms/ folder.
I put it there because some unzip programs won't create a folder
unless it contains at least one file.  Please delete it before
using Multiboot Menu.  Otherwise, running it from the menu will
freeze the GBA.


=== To use Multiboot Menu ===

1. Place the .mb files in the roms/ folder
2. Run mkr.bat


=== To recompile it on Windows ===

1. Put your native compiler (DJGPP or MinGW) at the front of the
   PATH.  Make sure that it includes GNU Make.
2. C:\...\mbmenu\tools\make
3. Put Devkit Advance at the front of the PATH.
4. Place the .mb files in the roms/ folder
5. C:\...\mbmenu\mk


=== To use it on UNIX ===

The scripts are designed for Windows tools (DJGPP or MinGW as
the native compiler and Devkit Advance as the cross compiler).
They should be relatively easy to adapt to UNIX systems.  I
don't currently have a machine that runs Linux or BSD to develop
on; donations of working scripts and makefiles for UNIX system
users would be appreciated.


=== text.chr ===

This is an 8x8 font designed to look slightly "cutesy" like hand
printing.  It's based loosely on fonts such as Ziggy Zoe, Kristen,
and the font used on the boxes of Precious Moments(R) merchandise.
Use it freely.


=== To redistribute this package ===

This package as a whole is licensed under the GNU General Public
License.  See the comments at the beginning of each source code
file for details on the redistribution of parts of the package.
