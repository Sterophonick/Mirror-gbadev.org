/* gbfs.c
   create a GBFS file

Copyright (C) 2002  Damian Yerrick

This program is free software; you can redistribute it and/or
modify it under the terms of the GNU General Public License
as published by the Free Software Foundation; either version 2
of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to 
  Free Software Foundation, Inc., 59 Temple Place - Suite 330,
  Boston, MA  02111-1307, USA.
GNU licenses can be viewed online at http://www.gnu.org/copyleft/

In addition, Damian Yerrick grants you permission to freely use
and distribute programs combined with this stub (including
commercial ones), subject to the following restrictions:

 1. You must combine your program with a completely unmodified mbmenu
    version; either with our precompiled version, or (at your option)
    with a self compiled version of the unmodified mbmenu sources as
    distributed by us.
 2. This also implies that the mbmenu stub must be completely unmodfied,
    that is, the stub imbedded in your compressed program must be
    byte-identical to the stub that is produced by the official
    unmodified mbmenu version.
 3. The menu, font, and any other code from the stub must exclusively
    get used by the unmodified mbmenu stub for loading your program
    at program startup.  No portion of the stub may get read, copied,
    called or otherwise get used or accessed by your program.

Visit http://www.pineight.com/ for more information.

*/

#include "pin8gba.h"
#include "gbfs.h"
#include <stdlib.h>

#include "chr.h"

#define FILES_PER_PAGE 16
#define SCR_MAP 4

static const GBFS_FILE *dat;
static unsigned int n_pages;
static unsigned char repeats[10];


const char kyodaku[] =
"\n\nThe mbmenu stub loader is Copyright (C) 2002 Damian Yerrick.\n"
"Permission is granted to use the stub (but not necessarily\n"
"the whole program) for any purpose provided the stub\n"
"remains present and unmodified.\n\n";


/* clear_keybuf() **********************
   Clear the autorepeats.
*/
static void clear_keybuf(void)
{
  int i;

  for(i = 0; i < 10; i++)
    repeats[i] = 1;
}


/* make_repeats() **********************
   Handle auto-repeat for ten-bit joypad.
*/
static void make_repeats(u32 keys)
{
  unsigned int i;

  for(i = 0;
      i < 10;
      keys >>= 1, i++)
  {
    if(keys & 1)
    {
      repeats[i]++;
      if(repeats[i] >= 18)
        repeats[i] = 16;
    }
    else
      repeats[i] = 0;
  }
}


/* dma_memcpy() ************************
   Copy a region of memory to VRAM or any other area of memory
   using the GBA hardware.  It needs a 2-cycle wait after writing
   to the control register; making this a non-inline function
   introduces the proper rest time.
*/
static void dma_memcpy(void *dst, const void *src, size_t len)
{
  DMA[3].src = src;
  DMA[3].dst = dst;
  DMA[3].count = len >> 2;
  DMA[3].control = DMA_ENABLE | DMA_COPYNOW | DMA_U32 | DMA_SRCINC | DMA_DSTINC;
}


/* nttextout() *************************
   Write the given text to a nametable.
*/
static void nttextout(u32 nt, u32 x, u32 y, u32 c, const char *str)
{
  while(*str)
    MAP[nt][y][x++] = (*str++ & 0xff) | c;
}


/* die() *******************************
   Write an error message and halt the CPU.
*/
static void die(const char *str)
{
  u32 x;

  while(LCD_Y != 160) ;

  for(x = 0; x < 1024; x++)
    MAP[SCR_MAP][0][x] = ' ';

  nttextout(SCR_MAP, 0, 9, 0, str);

  BGSCROLL[0].x = 0;
  BGSCROLL[0].y = 0;
  BGCTRL[0] = BGCTRL_PAT(0) | BGCTRL_16C | BGCTRL_NAME(SCR_MAP) |
              BGCTRL_H32 | BGCTRL_V32;
  LCDMODE = 0 | LCDMODE_BG0;

  while(1);
}


/* itoa_lpad() *********************
   Convert n into a string of len characters, left-padded with
   lpad_chr.  buf points to a buffer of at least (len + 1) chars.
*/
void itoa_lpad(char *buf, size_t len, unsigned int n, int lpad_chr)
{
  buf[len] = 0;
  if(n == 0)
    n = 0;

  /* extract each digit */
  do {
    /* assumes compiler can optimize n % 10 and n / 10 into one op
       also assumes digits appear consecutively in 0123456789 order
       (this is true of ascii) */
    buf[--len] = (n % 10) + '0';
    n = n / 10;
  } while(n && len);

  /* left pad */
  while(len)
    buf[--len] = lpad_chr;
}


/* ntclrline() *************************
   Clear a line of the map.
*/
void ntclrline(u32 nt, u32 y, u32 c)
{
  u32 x;
  u32 *here = (u32 *)(MAP[nt][y]);
  
  /* duplicate c into the high word */
  c &= 0x0000ffff;
  c |= c << 16;

  /* clear the line 2 characters at a time */
  for(x = 0; x < 16; x++)
    *here++ = c;
}


void draw_menu_page(u32 page)
{
  u32 n_files = dat->dir_nmemb;
  GBFS_ENTRY *dir_ent = (GBFS_ENTRY *)((unsigned char *)dat + dat->dir_off);
  u32 y;

  {
    /*              0123456789012345678901234567 */
    char top[32] = "Multiboot Menu   Pg xx of xx";

    itoa_lpad(top + 19, 3, page + 1, ' ');
    top[22] = ' ';  /* clear out the null */
    itoa_lpad(top + 25, 3, n_pages, ' ');
    nttextout(SCR_MAP, 1, 1, 0, top);
  }

  page *= FILES_PER_PAGE;  /* now page is an offset */
  dir_ent += page;         /* now dir_ent points to the current file */

  for(y = 0; y < 16; y++)
  {
    ntclrline(SCR_MAP, y + 3, ' ');

    /* if it's within the menu, draw it */
    if(page < n_files)
    {
      unsigned int x;

      for(x = 0; x < 24 && dir_ent->name[x]; x++)
      {
        MAP[SCR_MAP][y + 3][x + 4] = dir_ent->name[x];
      }
    }
    page++;
    dir_ent++;
  }

}


/* upcvt_4bit() ************************
   Convert a 1-bit font to GBA 4-bit format.
*/
void upcvt_4bit(void *dst, const u8 *src, size_t len)
{
  u32 *out = dst;

  for(; len > 0; len--)
  {
    u32 dst_bits = 0;
    u32 src_bits = *src++;
    u32 x;

    for(x = 0; x < 8; x++)
    {
      dst_bits |= src_bits & 1;
      dst_bits <<= 4;
      src_bits >>= 1;
    }
    *out++ = dst_bits;
  }
}


/* init_all() **************************
   Set up the display.

   VRAM:
     0000  font (16-bit, 256 tiles)
     2000  map (32x32 tiles)

*/
void init_all(void)
{
  SNDSTAT = 0;  /* to save batteries, turn off sound in menus */
  LCDMODE = 0 | LCDMODE_BLANK;
  BGCTRL[0] = BGCTRL_PAT(0) | BGCTRL_16C | BGCTRL_NAME(SCR_MAP) |
              BGCTRL_H32 | BGCTRL_V32;
  BGCTRL[1] = BGCTRL[2] = BGCTRL[3] = 0;
  PALRAM[0] = RGB(31, 31, 31);
  PALRAM[1] = RGB(0, 0, 0);

  /* load pattern table */
  upcvt_4bit(VRAM, text_chr, text_chr_len);

  /* clear nametable */
  {
    u32 x;

    for(x = 0; x < 1024; x++)
      MAP[SCR_MAP][0][x] = ' ';
  }

  dat = find_first_gbfs_file(find_first_gbfs_file);
  if(!dat)
    die(" No GBFS file found.");
  if(dat->dir_nmemb == 0)
    die(" GBFS file is empty.");
  n_pages = (dat->dir_nmemb - 1 + FILES_PER_PAGE) / FILES_PER_PAGE;

  /* clear OAM and set up a single sprite image */
  {
    const struct OAM_SPRITE hidden = {160, 20, 0, 0};
    u32 x;
    const u32 arrow[8] =
    {
      0x00000000,
      0x00010000,
      0x00100000,
      0x01111111,
      0x00100000,
      0x00010000,
      0x00000000,
      0x00000000
    };
    u32 *spr_vram = (u32 *)0x06010000;

    for(x = 0; x < 128; x++)
      OAM[x] = hidden;
    for(x = 0; x < 8; x++)
      spr_vram[x] = arrow[x];
  }

  while(LCD_Y != 160);
  LCDMODE = 0 | LCDMODE_BG0 | LCDMODE_SPR;
}


/* go_arm() ****************************
   Execute the multiboot binary that has been loaded into EWRAM.
*/
void go_arm(void)
{
  asm volatile
  (
    "ldr r0, =0x02000000\n"
    "mov lr, r0\n"
    "bx lr\n"
    :/* No output. Heck, it doesn't even return. */
    :/* no inputs */
    :"r0"  /* clobbered */
  );
}


int main(void)
{
  char done = 0;
  u32 sel = 1;
  u32 last_page = 0xdeadbeef;  /* bogus value to force a redraw */

  init_all();
  clear_keybuf();

  while(!done)
  {
    u32 page = sel / FILES_PER_PAGE;

    while(LCD_Y < 160);

    if(page != last_page)
    {
      last_page = page;
      draw_menu_page(page);
    }
    OAM[0].y = (sel % FILES_PER_PAGE) * 8 + 24;

    while(LCD_Y >= 160);

    make_repeats((JOY & 0x3ff) ^ 0x3ff);
    if(repeats[0] == 1 || repeats[3] == 1)  /* A or Start */
      done = 1;
    else if(repeats[4] == 1 || repeats[4] == 17)  /* right */
    {
      sel += FILES_PER_PAGE;
      page = sel / FILES_PER_PAGE;

      /* handle moving to a nonexistent page */
      if(page >= n_pages)
      {
        sel %= FILES_PER_PAGE;  /* move to the first page */
      }
      /* handle moving to a blank space in a page */
      else if(sel >= dat->dir_nmemb)
      {
        sel = dat->dir_nmemb - 1;
      }
    }
    else if(repeats[5] == 1 || repeats[5] == 17)  /* left */
    {
      /* if going off the first page, go to the last page */
      if(sel < FILES_PER_PAGE)
      {
        sel += (n_pages - 1) * FILES_PER_PAGE;
        if(sel >= dat->dir_nmemb)
          sel = dat->dir_nmemb - 1;
      }
      else
        sel -= FILES_PER_PAGE;
    }
    else if(repeats[6] == 1 || repeats[6] == 17)  /* up */
    {
      if(sel == 0)
        sel = dat->dir_nmemb - 1;
      else
        sel--;
    }
    else if(repeats[7] == 1 || repeats[7] == 17)  /* down */
    {
      if(++sel >= dat->dir_nmemb)
        sel = 0;
    }
  }

  {
    GBFS_ENTRY *dirbase = (GBFS_ENTRY *)((char *)dat + dat->dir_off);
    unsigned char *src = (unsigned char *)dat + dirbase[sel].data_offset;

    dma_memcpy(EWRAM, src, dirbase[sel].len);
  }

  while((JOY & 0x3ff) != 0x3ff);  /* wait for all keys to be released */
  go_arm();
  return 0;
}
