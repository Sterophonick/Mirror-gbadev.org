////////////////////////////////////////////////////////////////////////////////
// 3D vector cube sample in plain C code :-)                                  //
// Code by Hugo Smits, I used it to learn 3D                                  //
// so it's not top-notch code.. but it does the trick ;-)                     //
////////////////////////////////////////////////////////////////////////////////
// for GCC-Devkit Adv, GameBoy Advance. Code tested on Hardware and emulator  //
////////////////////////////////////////////////////////////////////////////////
#include "sincosrad.h"

unsigned short *v_frame;    // buffer switch
int cframe=1;               // buffer inc.

// for making the screen clean.
void FillScreen(unsigned long color, unsigned short *target); 
// this plots a pixel on the screen.
void PlotPixel(int x2,int y2, unsigned short int c) {((unsigned short*)v_frame)[(y2) * 120 + (x2)] = (c); }

//setting up the Vectors
typedef struct TVector3
{
    int x, y, z;
}TVector3, *PVector3;


#define  vector_point_max   (100)
TVector3 vector_point[vector_point_max];
PVector3 vector_point_first = &vector_point[0];

int vector_x =0;
int vector_y =0;
int vector_z =0;

int x, y;

void buffer(void)
{
    if (cframe == 1){ v_frame = (unsigned short*)0x6000000;
    } else {
    v_frame = (unsigned short*)0x600A000;
    }
    *(unsigned short*)0x4000000=0x0404 | (cframe<<4) | 0x1000 | 0x40;
    cframe = 1-cframe; 
}

void vector(vector_x,vector_y,vector_z)
{
    vector_point_first = &vector_point[0];

    vector_point->x = vector_x;
    vector_point->y = vector_y;
    vector_point->z = vector_z;
    
    // Simple basic math ,  world x / world z + screenwidth/2
    // Simple basic math ,  world y / world z + screenwidth/2
    x   = (vector_point->x * 8 / vector_point->z + 8) + (64 - 8); 
    y   = (vector_point->y * 8 / vector_point->z + 8) + (80 - 8);

    PlotPixel(x, y, 0xFFFF);
}

void rotate(int x,int y,int z,int rotatie)
{

int xrotatie = 0;
int yrotatie = 0;
int zrotatie = rotatie;

// rotation stuff, I don't know why the x and y rotation doesn't work correctly wierd :S
int nx = x * ((COS[yrotatie] * COS[zrotatie])  + (SIN[xrotatie] * SIN[yrotatie] * SIN[zrotatie])) -
         y * ((COS[xrotatie] * SIN[zrotatie])) +
         z * ((-SIN[yrotatie] * COS[zrotatie]) + (SIN[xrotatie] * COS[yrotatie] * SIN[zrotatie]));



int ny = x * ((COS[yrotatie] * SIN[zrotatie]) - (SIN[xrotatie] * SIN[yrotatie] * COS[zrotatie])) +
         y * (COS[xrotatie] * COS[zrotatie]) -
         z * ((SIN[yrotatie] * SIN[zrotatie]) + (SIN[xrotatie] * COS[yrotatie] * COS[zrotatie]));


int nz = x * (COS[xrotatie] * SIN[yrotatie]) +
         y * (SIN[xrotatie]) +
	     z * (COS[xrotatie] * COS[yrotatie]);

	vector(nx,ny,nz);
}

void cube(int i)
{

               // cube figure
               rotate(-15,-15,8,i);//1
               rotate( 15,-15,8,i);//2
               rotate(-15, 15,8,i);//3
               rotate( 15, 15,8,i);//4
    
               rotate(-15,-15,6,i);//5 
               rotate( 15,-15,6,i);//6 
               rotate(-15, 15,6,i);//7
               rotate( 15, 15,6,i);//8
                
               buffer();
}



// main function
void AgbMain(void)
{
  // setting up bgmode, standard stuff.
  *(unsigned short*)0x4000000=0x04 | (cframe<<4) | 0x1000 | 0x40;
  cframe = 1-cframe; 

  int p;
  for (p = 0; p < 255; p++) ((unsigned short *)0x5000000)[p] = 0x7FFF;
  
  int i=0;
  
  while(1)
  {
  
  i++;if(i>359){i=0;}
  cube(i);

  FillScreen(160,((unsigned short*)v_frame)); 
  
  while((*((unsigned int volatile *) 0x04000006))!=159);
  while((*((unsigned int volatile *) 0x04000006))==159);
  }
}

 asm ( ".include \"fillscreen.s\"\n" );
