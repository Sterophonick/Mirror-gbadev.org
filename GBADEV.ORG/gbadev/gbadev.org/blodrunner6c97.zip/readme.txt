Twenty years ago, as a first attempt to make my own game, I tried to build a version of
the classic game "Loderunner" on my 4.77 MHz IBM PC clone.  I didn't get very far.

I've been having a lot of fun playing around with the GBA lately, and I decided to try
again.  Blodrunner is the result.  It took me the majority of a weekend (using code from
my previous minigame, Starshot) to build.  The artwork is all mine (Run! Its programmer
art!), and the gameplay is pretty simple, but I had fun putting it together.

On my webpage (www.opusgames.com) you can find complete source code for the game.  I used
an old version of GCC (also available on my webpage) to compile it, and tUME to create
all the game levels.

There are still some things I want to do to this game (levels that are larger than
a single screen, moving platforms, possibly an in-game level editor that can save
off to the battery backup RAM)... I just need to find the time!

-Opus
