*** Hackpal v0.2 Read-Me ***

Synopsis:
 A nice little command line tool to rip a palette from a source file
 and convert it to a 5:5:5 raw palette sutiable for GBA coding.

 Usage:
  hackpal srcfile.ext destfile.pal

 Where:
  srcfile = the source image/palette, see below for supported formats.
  destfile = the destination file

 Or:
  type hackpal with no arguments to see the same text as above.

Details:
 The source file can be one of:
  o 256 color PCX Image
  o 256 color BMP Image
  o 256 color Microsoft RIFF Palette
  o 256 color Jasc v0100 Palette

 The destination is a 512 byte file with each 16-bit word consisting
 of [0:4] = red, [5:9] = green, [10:14] = blue.

 The destination file will be overwriten, whether or not the program
 executed successfully.  Live with it.

 If enough peeps want it to support more formats or 16 color palettes
 or something, I'll make a new version. I like feedback.

 My e-mail is michael@auia.net, if I'm in #gbadev, my nick is Joat.