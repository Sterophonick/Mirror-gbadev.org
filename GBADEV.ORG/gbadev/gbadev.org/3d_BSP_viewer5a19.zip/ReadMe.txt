3d BSP Viewer

by Andrew H. Cox

Contact:

	<andy4294967296@hotmail.com>
or:
	<andrew.h.cox@btinternet.com>

Come see my 3d stuff for the GBA here:
	http://www.btinternet.com/~andrew.h.cox/GBA/index.html

Controls:
    Start: Change model.
    Select: Change control system (automatic or manual model orbiting).

    Joypad: Orbit left-right, approach and retreat from model.
    Shoulder buttons: up-down.
    B: Go faster.
    A: Control modifier that when held down makes pad and shoulder buttons move the rotation centre.

    Hold Start, depress B: Change poly mode between points, lines and solid.
    Hold Select, depress Shoulder buttons: Toggle red and green lights.
    Both Shoulder buttons: Display greeting from me.
