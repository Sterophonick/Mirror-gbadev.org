Negative Space

Originally made by MIA for the Nintendo DS using PALib.
http://http://beyondds.free.fr/index.php?Negative-space

Ported to GBA using HAM SDK v2.8 by Gener S. Gabasa
http://genergabasa.php0h.com
