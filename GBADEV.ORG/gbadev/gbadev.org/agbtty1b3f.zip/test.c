/* test.c
   test agbtty functions

Copyright 2003 Damian Yerrick

Permission is hereby granted, free of charge, to any person obtaining
a copy of this software and associated documentation files (the
"Software"), to deal in the Software without restriction, including
without limitation the rights to use, copy, modify, merge, publish,
distribute, sublicense, and/or sell copies of the Software, and to
permit persons to whom the Software is furnished to do so, subject to
the following conditions:

The above copyright notice and this permission notice shall be
included in all copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND,
EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES
OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND
NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS
BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN
AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF
OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS
IN THE SOFTWARE.

*/

#include "pin8gba.h"
#include "agbtty.h"
MULTIBOOT

void wait4vbl(void)
{
  /* FIXME: should set up an ISR and use BIOS vblankintrwait() */
  while(LCD_Y == 160);
  while(LCD_Y != 160);
}

void press_A(void)
{
  while(!(JOY & JOY_A))
    wait4vbl();
  while(JOY & JOY_A)
    wait4vbl();
}

void demo_scrollback(void)
{
  int i, j;

  for(i = 0; i <= 25; i++)
  {
    int j;

    for(j = 5; j > 0; j--)
      wait4vbl();
    agbtty_scrollback(i);
  }

  for(j = 150; j > 0; j--)
    wait4vbl();

  for(i = 24; i >= 8; i--)
  {
    for(j = 7; j > 0; j--)
      wait4vbl();
    agbtty_scrollback(i);
  }
  for(j = 150; j > 0; j--)
    wait4vbl();
  agbtty_putc('\n');
}

void demo_gotoxy(void)
{
  int i;

  for(i = 0; i <= 10; i++)
  {
    agbtty_gotoxy(i + 2, 10);
    agbtty_putc('-');
    agbtty_gotoxy(7, i + 5);
    agbtty_putc('|');
    agbtty_gotoxy(i + 17, i + 5);
    agbtty_putc('\\');
    agbtty_gotoxy(27 - i, i + 5);
    agbtty_putc('/');
  }
}


int main(void)
{
  agbtty_init();
  agbtty_init_cursor();

  LCDMODE = 0 | LCDMODE_BG0 | LCDMODE_SPR;
  PALRAM[  0] = RGB(31,31,31);
  PALRAM[  1] = RGB( 0, 0, 0);
  PALRAM[257] = RGB(16,16, 0);

  /* Demonstrate most term features ********************************/
  agbtty_puts("hello world\n\n"
              "this is being written to the\n"
              "agbtty console.  do long lineswrap?\n"

              "can i bacc\bkspace?\n"
              "fucki return and overwrite?\rcan \n"
              "tab\t1\t2\t3\t4\t5\n"

              "vtab currently acts like \v"
              "a newline\n");
  agbtty_write("write() and all other unix calls suck", 8);
  agbtty_puts("works.\n"
              "\npress A");
  press_A();

  /* Demonstrate form feed, positioning, and beeping ***************/
  agbtty_puts("\fform feed fed.\n"
              "\abeep!\n");
  demo_gotoxy();
  agbtty_puts("\npress A");
  press_A();

  /* Demonstrate scrollback buffer *********************************/
  agbtty_puts("\r"
"On reaching home, he found the"
"house door half open.  He\n"
"slipped into the room, locked\n"
"the door, and threw himself on"
"the floor, happy at his\n"
"escape.  But his happiness\n"
"lasted only a short time, for\n"
"just then he heard someone\n"
"saying:\n\n"
"\"Cri-cri-cri!\"\n\n"
"\"Who is calling me?\" asked\n"
"Pinocchio, greatly frightened.\n"
"\"I am!\"\n\n"
"Pinocchio turned and saw a\n"
"large cricket crawling slowly\n"
"up the wall.\n\n"
"\"Tell me, Cricket, who are\n"
"you?\"\n\n"
"\"I am the Talking Cricket and\n"
"I have been living in this\n"
"room for more than one hundred"
"years.\"\n\n"
"\"Today, however, this room is\n"
"mine,\" said the puppet, \"and\n"
"if you wish to do me a favor,\n"
"get out now, and don't turn\n"
"around even once.\"\n\n"
"\"I refuse to leave this spot,\""
"answered the Cricket, \"until I"
"have told you a great truth.\"\n\n"
"\"Tell it, then, and hurry.\"\n"
              "\n"
              "\n"
              "feel left behind?\n"
              "press A to demo scrollback");
  press_A();
  agbtty_puts("\r                          ");
  demo_scrollback();
  agbtty_puts("press A to finish");
  press_A();

  /* Debrief *******************************************************/
  agbtty_puts("\f\n"
              "AGBTTY 0.1\n"
              "Minimal video terminal\n"
              "implementation for the\n"
              "Game Boy Advance system\n"
              "\n"
              "� 2003 Damian Yerrick\n"
              "Subject to licensing terms in\n"
              "agbtty.c\n");
  while(1);
}
