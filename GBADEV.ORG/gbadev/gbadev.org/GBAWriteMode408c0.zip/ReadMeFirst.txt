Hi everyone.
This is my first demo for GBA, and it is structured as an include that easily allows
anyone to include a customized font into a GBA program and show it in mode 4.
The program and all the steps to obtain the effect are all commented, so will be easy
to modify it and support other bitmapped modes, etc...

Here's what you'll find in the archive:

main.c              the main program (and example of how to call the function)
main.h              a common header with declarations
write.h             the funciton
palete.pal          a palette (in PAL mode, to be loaded in PSP)
palette.inc         the same palette as a C array to be included in the program
char.inc            the chars images include 
char.bmp            the chars image as a BMP
makefile            script for compiling under GCC
makedepend              "
lnkscript               "
main.bin            the result :D So you can test it immediately

I tought to give this demo out because it handles all the infos (palette, char images) as includes,
so can be easily compiled anywhere.
You can also improve it much and I hinted in the source where it would better to be done.

I also would like to remind that when we converted the BMP to INC (see HowTo... file) we took with us alot 
of unnecessary info.
This is due to the fact that we converted the whole 240x160 image, while we needed a much
smaller area to keep info on the chars.
Just open the char.inc and you can truncate the array where it don't contain anymore data about the chars.

I also haven't been able to use the palette data that comes out from Hackit. I tryed convertin into
C source code but had problems importing it. This is why I decided to build a good common-purpose
palette in PSP, export it in ascii mode (.PAL), and then including it after fixing the syntax in the .PAL file.
The palette right now has just some shades of grey and yellow, but I just wanted to show how I planned
to built a general purpose palette.


At the end, sorry for my english, but I'm Italian. :oD

If you wanna ask any other info,
just go at www.FrobozzMagicCo.com and post your questions in the GBA DEV area of the forum.
Cheers,
McValdemar


LastMinuteNOte:It also brings with it the references to the GFXLIB. It is not required in the demo, but I started
building this demo on a skeleton that used that library.
So, be sure that you have the lib, or just keep away any reference to it!