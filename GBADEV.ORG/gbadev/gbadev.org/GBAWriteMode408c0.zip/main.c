
#include <math.h>
#include "main.h"


#include "C:\GBA\ARMGCC\gfxlib\subs\jpeg5.c" 

   
#include "char.inc"    
#include "Palette.inc"  

#include "write.h"
   
#define _VRAM (u8 *)0x6000000

void AgbMain(void)
{
	u32 i=0;

   //Loads the palette values from the palette array (caled colori) and puts em in the PALETTE address in RGB mode
   for (i=0; i<40*2; i=i+2)
   *(u16 *)(PALETTE + i) = RGB((colori[(i/2) * 3]),(colori[(i/2) * 3+1]),(colori[(i/2) * 3+2]));
   
   //Sets BA display in Mode 4
   *(u16 *)DISPLAY = MODE_4 | BG2_ON;
   *(u16 *)REG_STAT = 0;
   
   WriteMode4 ("mcvaldemar",0,0);
   WriteMode4 ("cheers",30,10);
   WriteMode4 ("every",50,25);
   WriteMode4 ("gba",60,40);
   WriteMode4 ("newbie",100,50);
   WriteMode4 ("like",130,70);
   WriteMode4 ("me",160,85);
   WriteMode4 ("hola",200,95);
   WriteMode4 ("to",190,105);
   WriteMode4 ("gfxman",170,115);
   while (1)
   {
	//Keeps looping forever
   }
}

