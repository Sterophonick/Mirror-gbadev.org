
typedef     unsigned char           u8;
typedef     unsigned short int      u16;
typedef     unsigned int            u32;
typedef     unsigned long long int  u64;

typedef     signed char             s8;
typedef     signed short int        s16;
typedef     signed int              s32;
typedef     signed long long int    s64;

#define LCD_OFF  0x80
#define MODE_0    0
#define MODE_1    1
#define MODE_2    2
#define MODE_3    3
#define MODE_4    4
#define MODE_5    5
#define BG2_ON    0x0400

#define REG_BASE    0x4000000
#define PALETTE	    0x5000000
#define DISPLAY     (REG_BASE + 0x0)
#define REG_STAT    (REG_BASE + 0x4)
#define VRAM        0x6000000
#define MOSAIC		*(u16*)0x0400000C

#define KEYS		*(u16*)0x04000130
#define J_A		0x0001
#define J_B		0x0002
#define J_SELECT	0x0004
#define J_START		0x0008
#define J_RIGHT		0x0010
#define J_LEFT		0x0020
#define J_UP		0x0040
#define J_DOWN		0x0080
#define J_R		0x0100
#define J_L		0x0200

#define BIT00 1
#define BIT01 2
#define BIT02 4
#define BIT03 8
#define BIT04 16
#define BIT05 32
#define BIT06 64
#define BIT07 128
#define BIT08 256
#define BIT09 512
#define BIT10 1024
#define BIT11 2048
#define BIT12 4096
#define BIT13 8192
#define BIT14 16384
#define BIT15 32768



#define RGB(r,g,b) ((((b)>>3)<<10)+(((g)>>3)<<5)+((r)>>3))

extern void gfxPixel(u8 px, u8 py, u16 colr, u32 addr);
extern void gfxLine(u8 x1, u8 y1, u8 x2, u8 y2, u16 colr, u32 addr);
extern void gfxFill(u8 x, u8 y, u16 fc, u16 bc, u32 addr);
extern void gfxEllipse(u8 x, u8 y, u8 xr, u8 yr, u16 color, u32 addr);





