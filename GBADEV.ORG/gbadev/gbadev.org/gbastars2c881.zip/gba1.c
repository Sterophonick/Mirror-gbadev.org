// GBA test prog 2
// "real programmers comment their stuff"
//
#include <stdlib.h>
#include "GBASystem.h"
#include "fixed.h"
#include "math3d.h"

// font bitmap & palette
//#include "titleraw.c"
//#include "titlepal.c"

// Hardware registers
// need to use volatile for the registers we read, otherwise
// the compiler tries to be clever.
#define PALETTE		((unsigned short *)0x05000000)
#define SCREEN		((unsigned char *)0x06000000)
#define MOSAIC		((unsigned short *)0x0400004C)
#define BG2CNT		((unsigned short *)0x0400000C)
#define WIDTH		240
#define HEIGHT		160

// simple 3D point struct
typedef struct {
	fixed x;
	fixed y;
	fixed z;
	int sx;
	int sy;
} PT_3D;

// simple line struct
typedef struct {
	short p1;
	short p2;
	unsigned char colour;
	unsigned char pad;
} LINE_3D;

MATRIX mx1;
MATRIX mx2;
MATRIX mx_final;

PT_3D pt[32];
LINE_3D line[32];

fixed xout, yout, zout;
fixed xscreen, yscreen;

// screen clear (writes words)
// fairly fast - check out the asm generated
void clear(void) {
	// clear screen
	unsigned long *p;
	int i;
	
	p = (unsigned long *)SCREEN;
	for(i=9600; i;i--) *p++ = 0;
}

// DMA screen clear
// "blitzvinnig"
void DMAclear(void) {
	REG_DM3SAD = 0x08010000;		// src addr (gulp!)
	REG_DM3DAD = 0x06000000;		// dest addr
	REG_DM3CNT = 0x84002580;		// 9600 bytes?
}

// load picture and palette to VRAM
void LoadPic(unsigned char *pic, short x, short y, short w, short h, unsigned short *pal) {
	int i, j;
	unsigned char *p;

	// copy palette
	for(i=0; i<256; i++) {
		PALETTE[i] = pal[i];
	}
	// copy picture
	for(i=0; i<h; i++) {
		p = SCREEN + x + (y+i)*240;
		for(j=w; j; j--) {
			*p++ = *pic++;
		}
	}

}

void DrawLine(int x0, int y0, int x1, int y1, unsigned char colour) {
	
	int dx, dy, x_inc, y_inc; 
	int i;
	int error = 0;

	unsigned char *pbuf;

	// pre-calc first pixel addr in buffer
	pbuf = SCREEN;
	pbuf += (x0 + y0 * WIDTH);
	
	// calc vert and horiz deltas
	dx = x1 - x0;
	dy = y1 - y0;

	// which direction is slope?
	if (dx >= 0)
		x_inc = 1;				
	else {
		 x_inc = -1;
		 dx = -dx;		// need abs val for dx
	}
	
	// y component of slope?
	if (dy >= 0)
		y_inc = WIDTH;			// 240 bytes per line
	else {
		y_inc = -WIDTH;
		dy = -dy;	// need abs val for dy
	}
	
	// draw line based on which delta is greater
	if (dx > dy) {
		// draw line
		for(i=0; i<=dx; i++) {
			// set the pixel
			*pbuf = colour;
			// adjust error term
			error += dy;
			// has error overflowed?
			if (error > dx) {
				error -= dx;
				// move to next line (row)
				pbuf += y_inc;
			}
			// move to next pixel
			pbuf += x_inc;
		} // next
	}
	else {
		// draw line # 2
		for(i=0; i<=dy; i++) {
			// set the pixel
			*pbuf = colour;
			// adjust error term
			error += dx;
			// test for error overflow
			if(error > 0) {
				error -= dy;
				// move to next line (column)
				pbuf += x_inc;
			}
			// move to next pixel
			pbuf += y_inc;
		} // next
	}
}

// ************************** MAIN ***************************
// start.asm jumps to here
int C_entry(void) {
	int i, j, dist;
	unsigned char *p;
	unsigned char *q;
	unsigned short *ppal;
	unsigned short mm;
	short t1, t2;

	int x[200], y[200], z[200];		// stars coords
	int sx, sy;

	// set DISPCNT for BG mode = 4, BG2 screen disp on
	REG_DISPCNT = 0x0404;

	// load picture
	//LoadPic(titleraw, 0, 0, 240, 127, (unsigned short *)titlepal);

	//for(i=0; i<120; i++) { WaitVerticalRetrace(); WaitVBL2(); }

/*
	// mosaic out
	for(mm=0; mm<256; mm += 17) {
    	*MOSAIC = mm;
    	*BG2CNT = 0x0040;		// BG2 Mosaic bit
		for(j=0; j<3; j++) { WaitVerticalRetrace(); WaitVBL2(); }
	}
*/
	// create palette
	// 15-bit, BGR
	ppal = PALETTE;
	// first, 32 shades of grey
	for(i=0; i<32; i++) {
		*ppal++ = (i & 0x1F) | ((i & 0x1F) << 5) | ((i & 0x1F) << 10);
	}
	// then, 32 shades of red
	for(i=0; i<32; i++) {
		*ppal++ = (i & 0x1F);
	}
	// then, 32 shades of green
	for(i=0; i<32; i++) {
		*ppal++ = (i & 0x1F) << 5;
	}
	
	// set up stars
	for(i=0; i<200; i++) {
		x[i] = rand() % 2000 - 1000;
		y[i] = rand() % 2000 - 1000;
		z[i] = rand() % 200 + 8;
	}

	// pt's of object
	// (all y-values inverted)
	pt[0].x = itofix(25); pt[0].y = itofix(0); pt[0].z = itofix(0);
	pt[1].x = itofix(5); pt[1].y = itofix(0); pt[1].z = itofix(-6);
	pt[2].x = itofix(5); pt[2].y = itofix(-3); pt[2].z = itofix(-3);
	pt[3].x = itofix(11); pt[3].y = itofix(-4); pt[3].z = itofix(0);
	pt[4].x = itofix(6); pt[4].y = itofix(-6); pt[4].z = itofix(0);
	pt[5].x = itofix(2); pt[5].y = itofix(-5); pt[5].z = itofix(0);
	pt[6].x = itofix(5); pt[6].y = itofix(-3); pt[6].z = itofix(3);
	pt[7].x = itofix(5); pt[7].y = itofix(0); pt[7].z = itofix(6);
	pt[8].x = itofix(-13); pt[8].y = itofix(-9); pt[8].z = itofix(-9);
	pt[9].x = itofix(-15); pt[9].y = itofix(0); pt[9].z = itofix(-6);
	pt[10].x = itofix(-16); pt[10].y = itofix(-4); pt[10].z = itofix(-2);
	pt[11].x = itofix(-16); pt[11].y = itofix(-4); pt[11].z = itofix(2);
	pt[12].x = itofix(-15); pt[12].y = itofix(0); pt[12].z = itofix(6);
	pt[13].x = itofix(-13); pt[13].y = itofix(-9); pt[13].z = itofix(9);

	// lines
	line[0].p1 = 0; line[0].p2 = 1; line[0].colour = 95;
	line[1].p1 = 0; line[1].p2 = 7; line[1].colour = 95;
	line[2].p1 = 0; line[2].p2 = 3; line[2].colour = 95;
	line[3].p1 = 3; line[3].p2 = 4; line[3].colour = 63;
	line[4].p1 = 3; line[4].p2 = 6; line[4].colour = 63;
	line[5].p1 = 3; line[5].p2 = 2; line[5].colour = 63;
	line[6].p1 = 2; line[6].p2 = 4; line[6].colour = 63;
	line[7].p1 = 4; line[7].p2 = 6; line[7].colour = 63;
	line[8].p1 = 4; line[8].p2 = 5; line[8].colour = 63;
	line[9].p1 = 2; line[9].p2 = 5; line[9].colour = 63;
	line[10].p1 = 5; line[10].p2 = 6; line[10].colour = 63;
	line[11].p1 = 5; line[11].p2 = 10; line[11].colour = 95;
	line[12].p1 = 5; line[12].p2 = 11; line[12].colour = 95;
	line[13].p1 = 1; line[13].p2 = 2; line[13].colour = 95;
	line[14].p1 = 6; line[14].p2 = 7; line[14].colour = 95;
	line[15].p1 = 1; line[15].p2 = 8; line[15].colour = 95;
	line[16].p1 = 7; line[16].p2 = 13; line[16].colour = 95;
	line[17].p1 = 1; line[17].p2 = 9; line[17].colour = 95;
	line[18].p1 = 7; line[18].p2 = 12; line[18].colour = 95;
	line[19].p1 = 8; line[19].p2 = 9; line[19].colour = 95;
	line[20].p1 = 13; line[20].p2 = 12; line[20].colour = 95;
	line[21].p1 = 9; line[21].p2 = 12; line[21].colour = 95;
	line[22].p1 = 9; line[22].p2 = 10; line[22].colour = 95;
	line[23].p1 = 10; line[23].p2 = 11; line[23].colour = 95;
	line[24].p1 = 11; line[24].p2 = 12; line[24].colour = 95;
	line[25].p1 = 1; line[25].p2 = 7; line[25].colour = 95;
	
	// set projection viewport (int x, int y, int w, int h);
	set_projection_viewport(0, 0, 240, 160);		// upside-down

	p = SCREEN;							// p points to start of screen
	q = SCREEN + 19200 + 120;			// q points to middle of screen
	j = 0; dist = 1000;
	while(1) {
		// get translation matrix (MATRIX *m, fixed x, fixed y, fixed z);
		get_translation_matrix(&mx2, itofix(0), itofix(0), itofix(dist));

		// get rotation matrix (MATRIX *m, fixed x, fixed y, fixed z);
		get_rotation_matrix(&mx1, itofix(j), itofix(j), itofix(j));

		// matrix multiply (MATRIX *m1, MATRIX *m2, MATRIX *out);
		matrix_mul(&mx1, &mx2, &mx_final);

		// wait for VBL and clear screen
		WaitVerticalRetrace();
		DMAclear();

		// draw and update stars
		for(i=0; i<200; i++) {
			sx = x[i] / z[i];			// perspective projection
			sy = y[i] / z[i];
			//sx = x[i];
			//sy = y[i];
			*(q + sx + sy * 240) = 31 - (z[i] >> 3);
			z[i]--;
			if(z[i] < 8) z[i] += 200;
		}

		// transform objects points from object space to world space
		for(i=0; i<14; i++) {
			//apply_matrix(MATRIX *m, fixed x, fixed y, fixed z, fixed *xout, fixed *yout, fixed *zout);
			apply_matrix(&mx_final, pt[i].x, pt[i].y, pt[i].z, &xout, &yout, &zout);

			persp_project(xout, yout, zout, &xscreen, &yscreen);
			pt[i].sx = fixtoi(xscreen);
			pt[i].sy = fixtoi(yscreen);
			*(p + pt[i].sx + pt[i].sy * 240) = 63;
		}

		// draw lines
		for(i=0; i<25; i++) {
			t1 = line[i].p1;
			t2 = line[i].p2;
			DrawLine(pt[t1].sx, pt[t1].sy, pt[t2].sx, pt[t2].sy, line[i].colour);
		}

		j = (j+2) % 256;				// update rotation value
		if (dist > 40) dist--;			// update dist to ship

	} // wend
	
	return 0;
}


