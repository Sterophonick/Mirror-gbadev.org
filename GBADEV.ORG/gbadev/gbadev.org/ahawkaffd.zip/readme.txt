On running the program you can select a difficulty level between 1 (easy) and 10 (hard).
You can also specify how many background layers are displayed. This might be useful if emulating on a slow PC.
Use d-pad left & right to increase & decrease the values, press the A button when done.


Use the d-pad to control both the direction and thrust of the ship. Without touching the d-pad, use the top left & right buttons to rotate the ship. Press the A button to fire.
The ship is equipped with different missiles and shields. When you collect power-ups, the missile or shield is automatically selected if it is better than the current selection.


You can manually select by holding down the select button and pressing the top left & right buttons.
Status displays for the ship, missiles and shields are displayed on the left of the screen.
The status levels decrease when you are hit by an asteroid, fire a missile or use the shield against an asteroid. They increase when you collect the appropriate power-up.


The score is displayed at the bottom left of the screen and increases whenever you shoot an asteroid.
The game gets progressively harder the more asteroids you destroy.
When the game is over, press the start button to continue.
Most of the testing has been done on hardware using the Flash Linker. It has also been run on the BoycottAdvance emulator.