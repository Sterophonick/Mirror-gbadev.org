**************************
*The Adventures of Kaotik*
**************************

This is a (demo??) (game??) thing, made in a hurry the weeks before Dreamhack 2001 (29 Nov - 2 Dec).

Graphics:
Mikael "Lysekoid" Lysek
welcome.to/megaland.com

Programming (and hardware):
Timmy "AmPz" Brolin
www.hh.se/stud/d99tibr

The music is the great old tune "Banana Split" by Juha "dizzy" Kujanpaa,
played using the AFM mod player by Silpheed/hitmen.