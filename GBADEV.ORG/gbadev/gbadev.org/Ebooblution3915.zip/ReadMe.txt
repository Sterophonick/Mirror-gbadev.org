

	Ebooblution - Version 0.1


	What is?

	Ebooblution is a freeware game for the Gameboy Advance(tm). It features an easy and addictive gameplay, graphics taken from real characters, sound, and two players simultaneously with only one GBA.

	The objective of the game is simple: destroy all the balls on the stage and avoid being touched by them or you'll die. In one player mode, move left or right with the pad and shoot with the A or B buttons. In Two player mode, the first player uses the pad and the B button, and the second player uses L and R to move and A to shoot.



	Who made it?

	The concept and code author is Hector Zapata. The graphics have been designed by Yolanda Cabrera. The game has been produced by Tetravol S.L.



	How can I play it?

	You can play it on your PC through an emulator. I recommend Visualboy Advance.  (vboy.emuhq.com)

	If you want to play on your GBA you'll need a flash card and writer. You can get them at Lik Sang. (www.liksang.com)



	Credits:

	Ebooblution has been created using HAM, a great Gameboy Advance Development Kit by Emanuel Schleussinger. (www.ngine.de)

	Graphics have been converted to GBA format using Gfx2GBA, a great tool by Markus.



	Special thanks to:

	Emanuel for his great development environment, wich made things really easy.

	Dovoto (www.thepernproject.com) and Aaron Rogers (www.aaronrogers.com/ham/) for their great tutorials.

	Everyone at the hamdev group for their help.

	Nintendo for their great console.



	Contact:

	If you want to contact the authors send an e-mail to hector.zapata@terra.es 


	