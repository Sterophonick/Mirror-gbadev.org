///////////////////////////////////////////////////////////////////////////////
// render.h / by Hugo Smits / 02.06.04  ///////////////////////////////////////
///////////////////////////////////////////////////////////////////////////////
// file contains the drawline function and the render function               //
///////////////////////////////////////////////////////////////////////////////

IN_IWRAM void drawvline(int x,int y,int length,int color) 
{
  unsigned short *offset =  (unsigned short*)v_frame+x*160+y;

// jumptable, note, the line can't be longer then 128 pixels.
// if you need more then 128 pixels, then just change the jumptable.
  switch(length) {
    case 128: *offset = color; offset++;
    case 127: *offset = color; offset++;
    case 126: *offset = color; offset++;
    case 125: *offset = color; offset++;
    case 124: *offset = color; offset++;
    case 123: *offset = color; offset++;
    case 122: *offset = color; offset++;
    case 121: *offset = color; offset++;
    case 120: *offset = color; offset++;
    case 119: *offset = color; offset++;
    case 118: *offset = color; offset++;
    case 117: *offset = color; offset++;
    case 116: *offset = color; offset++;
    case 115: *offset = color; offset++;
    case 114: *offset = color; offset++;
    case 113: *offset = color; offset++;
    case 112: *offset = color; offset++;
    case 111: *offset = color; offset++;
    case 110: *offset = color; offset++;
    case 109: *offset = color; offset++;
    case 108: *offset = color; offset++;
    case 107: *offset = color; offset++;
    case 106: *offset = color; offset++;
    case 105: *offset = color; offset++;
    case 104: *offset = color; offset++;
    case 103: *offset = color; offset++;
    case 102: *offset = color; offset++;
    case 101: *offset = color; offset++;
    case 100: *offset = color; offset++;
    case 99: *offset = color; offset++;
    case 98: *offset = color; offset++;
    case 97: *offset = color; offset++;
    case 96: *offset = color; offset++;
    case 95: *offset = color; offset++;
    case 94: *offset = color; offset++;
    case 93: *offset = color; offset++;
    case 92: *offset = color; offset++;
    case 91: *offset = color; offset++;
    case 90: *offset = color; offset++;
    case 89: *offset = color; offset++;
    case 88: *offset = color; offset++;
    case 87: *offset = color; offset++;
    case 86: *offset = color; offset++;
    case 85: *offset = color; offset++;
    case 84: *offset = color; offset++;
    case 83: *offset = color; offset++;
    case 82: *offset = color; offset++;
    case 81: *offset = color; offset++;
    case 80: *offset = color; offset++;
    case 79: *offset = color; offset++;
    case 78: *offset = color; offset++;
    case 77: *offset = color; offset++;
    case 76: *offset = color; offset++;
    case 75: *offset = color; offset++;
    case 74: *offset = color; offset++;
    case 73: *offset = color; offset++;
    case 72: *offset = color; offset++;
    case 71: *offset = color; offset++;
    case 70: *offset = color; offset++;
    case 69: *offset = color; offset++;
    case 68: *offset = color; offset++;
    case 67: *offset = color; offset++;
    case 66: *offset = color; offset++;
    case 65: *offset = color; offset++;
    case 64: *offset = color; offset++;
    case 63: *offset = color; offset++;
    case 62: *offset = color; offset++;
    case 61: *offset = color; offset++;
    case 60: *offset = color; offset++;
    case 59: *offset = color; offset++;
    case 58: *offset = color; offset++;
    case 57: *offset = color; offset++;
    case 56: *offset = color; offset++;
    case 55: *offset = color; offset++;
    case 54: *offset = color; offset++;
    case 53: *offset = color; offset++;
    case 52: *offset = color; offset++;
    case 51: *offset = color; offset++;
    case 50: *offset = color; offset++;
    case 49: *offset = color; offset++;
    case 48: *offset = color; offset++;
    case 47: *offset = color; offset++;
    case 46: *offset = color; offset++;
    case 45: *offset = color; offset++;
    case 44: *offset = color; offset++;
    case 43: *offset = color; offset++;
    case 42: *offset = color; offset++;
    case 41: *offset = color; offset++;
    case 40: *offset = color; offset++;
    case 39: *offset = color; offset++;
    case 38: *offset = color; offset++;
    case 37: *offset = color; offset++;
    case 36: *offset = color; offset++;
    case 35: *offset = color; offset++;
    case 34: *offset = color; offset++;
    case 33: *offset = color; offset++;
    case 32: *offset = color; offset++;
    case 31: *offset = color; offset++;
    case 30: *offset = color; offset++;
    case 29: *offset = color; offset++;
    case 28: *offset = color; offset++;
    case 27: *offset = color; offset++;
    case 26: *offset = color; offset++;
    case 25: *offset = color; offset++;
    case 24: *offset = color; offset++;
    case 23: *offset = color; offset++;
    case 22: *offset = color; offset++;
    case 21: *offset = color; offset++;
    case 20: *offset = color; offset++;
    case 19: *offset = color; offset++;
    case 18: *offset = color; offset++;
    case 17: *offset = color; offset++;
    case 16: *offset = color; offset++;
    case 15: *offset = color; offset++;
    case 14: *offset = color; offset++;
    case 13: *offset = color; offset++;
    case 12: *offset = color; offset++;
    case 11: *offset = color; offset++;
    case 10: *offset = color; offset++;
    case 9: *offset = color; offset++;
    case 8: *offset = color; offset++;
    case 7: *offset = color; offset++;
    case 6: *offset = color; offset++;
    case 5: *offset = color; offset++;
    case 4: *offset = color; offset++;
    case 3: *offset = color; offset++;
    case 2: *offset = color; offset++;
    case 1: *offset = color; offset++;
    case 0: *offset = color; offset++;
    default: break;
  }
}

IN_IWRAM void voxel(int voxelWidth,int voxelHeight,int zView,int rayStep)
{
    int vz,vx = 25;
    int traingle = zView;
    int calcData,VoxelFull,Xstart,Xend,texture,Xdraw,Ydraw,Ldraw,YstartCheck,Ystart,screenXstart,screenXend,Ydone,Xdone,Zcheck;
    int playerHeight = (( Heightmap [ (pXpos) + (pZpos+3) <<8 ] - 62) << (voxelHeight - 1));
    
    for(vz=pZpos+zView; vz>pZpos; vz-=rayStep)
    {
        if(traingle>15){traingle-=rayStep;}
        
        Zcheck = (vz - pZpos) <<3;
        YstartCheck = vz - pZpos;
        Ystart = 0 / (YstartCheck+256) - YstartCheck;
        
        for(vx=mapXend+traingle; vx>mapXstart-traingle; vx--)
        {
                calcData = ( pXpos + vx ) + (vz << 8);
                Ydone = (((Heightmap[calcData] - 62) << voxelHeight) << 8) / (Zcheck + 256);

                Xstart = ( vx << voxelWidth );
                Xend = ( Xstart + ( 1 << voxelWidth ));
				                                            
                screenXstart = (( (Xstart - 128) << 8 ) / (Zcheck + 256))+64;
                screenXend = (((Xend - 128) << 8 ) / (Zcheck + 256))+64;    
           
                texture = Colormap[ calcData ] ;    
           
                for(VoxelFull = screenXstart; VoxelFull < screenXend; VoxelFull++)
                { 
                       Xdone = VoxelFull;
                       Xdraw = Xdone;
                       Ydraw = (0 - Ystart ) + 14;
                       Ldraw = (0 - ( Ystart - Ydone) ) + 14;

                       if(Xdraw > 0 && Xdraw < screenWidth )
                       {
                             if(Ydraw > 0 && Ydraw < screenHeight )
                             {	
                                  drawvline(Xdraw ,Ydraw ,Ldraw - playerHeight ,texture);
                             }
                       }
                } 
         }  
    }
} 
////////////////////////////////////////////////////////////////////////////////
//end of render.h //////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////
