////////////////////////////////////////////////////////////////////////////////
// Voxel demo -- By Hugo Smits                                                //
//----------------------------------------------------------------------------//
// I made it to learn myself 3D programming, before this I didn't know        //
// anything about 3D. So some things look down right stupid. But that's       //
// because I didn't know better, I release it anyway, maybe some newbie       //
// just like myself, can use it to learn 3d :-)                               //
//                                                                            //
// In my quest for 3D Xvoid, Lordgraga and ravity saved my life a few times!  //
// so thank you guys for all your help :-)                                    //
////////////////////////////////////////////////////////////////////////////////
// If you have any questions , email me at : smits9 "at" xs4all "dot" nl      //
////////////////////////////////////////////////////////////////////////////////

#define CODE_IN_IWRAM __attribute__ ((section (".iwram")))
#define CODE_IN_ROM __attribute__ ((section (".text")))
#define IN_IWRAM __attribute__ ((section (".iwram")))
#define IN_EWRAM __attribute__ ((section (".ewram"))
#define vram 0x06000000
#define TRACE		1<<22
#define VIEWANGLE	8192

int pXpos =80;          	// player x
int pZpos =0;               // player z 
int mapXstart=10;           // X view
int mapXend=15;            // X view
int Ystart=8;  	           // start y , for perspective
int screenWidth=128;       // screen width
int screenHeight=160;      // screen height
	
unsigned short *v_frame;    // buffer switch
int cframe=1;               // buffer inc.

#include "GFX\sky.c"
#include "CMS\CM1.c"
#include "HMS\HM1.c"
#include "REN\render.h"




IN_IWRAM void quickbg(void)
{
int i;
for(i=0;i<sizeof(skyBitmap)/2;i++) v_frame[i] = skyBitmap[i];
}

// main function
IN_IWRAM void AgbMain()
{
  // setting up the mode5 gba screen, and rotate it
  // 128x120
//	SetMode(MODE_5 | OBJ_ENABLE | OBJ_MAP_1D | (cframe<<4));
  
  *(unsigned short*)0x4000000=0x0405 | (cframe<<4) | 0x1000 | 0x40;
  cframe = 1-cframe; 
  
  *(unsigned short*)0x4000020 = 0;
  *(unsigned short*)0x4000022 = -256;
  *(unsigned short*)0x4000024 = 137;  
  *(unsigned short*)0x4000026 = 0;
  *(unsigned short*)0x4000028 = 40704;


  while(1)

  {
       
      quickbg();
      voxel(3,3,32,2);
      pZpos++;
 
    if (cframe == 1){ v_frame = (unsigned short*)0x6000000;
    } else {
    v_frame = (unsigned short*)0x600A000;
    }
    *(unsigned short*)0x4000000=0x0405 | (cframe<<4) | 0x1000 | 0x40;
    cframe = 1-cframe; 
	   
	  while((*((unsigned int volatile *) 0x04000006))!=159);
	  while((*((unsigned int volatile *) 0x04000006))==159);
  }
}
