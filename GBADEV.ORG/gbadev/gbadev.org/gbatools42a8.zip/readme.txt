Brought to you by Zenith(Matt Griffith)
zenith@crosslink.net
written in Blitzbasic

NOTE:
make sure to create a .bat to input files, because my parser parses out anything with a
space, so if your folder has spaces in it, it'll thing that, that was a file :) (sorry my
own stupidity :))

Readme for GFX.EXE
-------------------------------
Input Example:
gfx.exe color.pal image0.pcx image1.png image2.bmp image3.jpg iamge4.tga
Output:
o_[paletteNAME$.pal] (should always come out as 768 bytes)
[imageNAME$].raw (1 byte per pixel)

Description:
    Whenever I get into something, I believe in reinventing the wheel - I never like
relying on other peoples tools, so I make my own. What this does, is take a Windows RIFF
Palette file, and a selected amount of images. It Converts the images to useful GBA raw
file using the pallete(color.pal) for refrence to color data. It then outputs a Pallete
GBA can use :) (R,G,B - 1 byte each) The raw file is 1 byte per pixel, 0-255 index to the
output pallete.

Image Files that can be read in: BMP,JPG,PNG,TGA,PCX

Readme for PAL.EXE
--------------------------------
Input Example:
pal.exe o_color.pal image0.raw image1.raw

Description:
    This tool will read in a pallete, and show each color, afterwards - you can then look at
any raw files using that pallete for the color table to check it. - This was just a tool to
test to see if my raw files and o_ pallete's would output right :)