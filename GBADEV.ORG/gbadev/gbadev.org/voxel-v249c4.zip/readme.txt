 Voxel demo v.2
----------------

Just a small tech demo... 
It runs better on real hardware or No$Gba.
You can find some others demos and projects on my web site ( http://fray999.free.fr/GBA/ ).

Thanks !
-Goldohulk-

