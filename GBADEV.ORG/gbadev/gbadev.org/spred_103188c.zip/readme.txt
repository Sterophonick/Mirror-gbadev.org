Spred, GBA tile/sprite editor
Tom St Denis
tomstdenis@yahoo.com
version 1.03 [fourth release!]

This program lets you make sprites/tiles that are well suited for use in GBA games.  The editor is very simple to use which
means getting down to business is easy.  

The way the system works is that it will pack upto 256 sprites/tiles into a single file.  Then you can export the file
to a C source code file where the bitmaps/sizes/offsets are precomputed.  The bitmaps are exported in 1D mode which means
you can easily dump the tile data straight to map data or sprite data [in 1D mode].

Some basics... getting going, type something like

C:\>spred myfile

That will launch spred and tell it to read and output to myfile.  The editor will load any sprite/palette data that is
in the file or nothing if the file is not found [e.g. its new].

The keys inside the system

PAGE UP/DOWN              Change sprite you are editing [+/- 25 locations]
UP/DOWN                   Change which sprite you are editing
N                         Make a new image, after hitting N you must hit a number [1,2,3,4] for the size
                               1 - 8x8
                               2 - 16x16
                               3 - 32x32
                               4 - 64x64
                               5 - 8x16
                               6 - 16x32
                               7 - 32x64
                               8 - 16x8
                               9 - 32x8
                               0 - 32x16
S                         Save the file
Q                         Quit and Save
W                         Quit without saving
Z                         Undo last change [e.g. before mouseup]
C                         Copy the image
V                         Paste the copied image [e.g. for re-using tiles]
P                         Fill an area (upto the second color) with the first color
I                         Grab color (off bitmap) and put it in the first color [eyedropper]
O                         Grab color and put in second color [eyedropper]
H                         Flip horizontally 
J                         Flip vertically


To change your colors you can right/left click on palette at the bottom.  A yellow box will surround the color you are
currently using.  To edit a color middle click on it then use the smooth palette to change it.  Hit F when you are done
editing the color.

To export a set type something like

C:\>spred -export myfile

That will make "myfile.c" with some goodies.  the variable "myfile_pak[]" will be the tile data.  Each sprite is broken
down into 8x8's and exported so you can do a linear copy into 1D memory [or map data memory].  The variable
"myfile_ofs" will be pointers [inside myfile_pak[]] to the beginning of the various sprites.  The variable
"myfile_sizes" will be the # of 8x8 tiles each sprite uses.  Finally "myfile_pal[]" is the palette in a format ready to
copy to 0x5000000 or 0x50000200