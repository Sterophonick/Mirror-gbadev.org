#include <stdio.h>
#include <allegro.h>

#define RGB(r,g,b) ((r)+((g)<<5)+((b)<<10))    //Macro to build a color from its parts

// the user palette/color
struct {
   unsigned char *data;
   int width, height, used;
} images[256];
int pal[256][3];

int cur_img, cur_fg, cur_bg, copy_from=0, qs=1;
BITMAP *fb;
char undo[4096];

volatile int counter;
void my_timer_handler()
{
   counter = 1;
}
END_OF_FUNCTION(my_timer_handler);

void load_pack(char *name)
{
   FILE *in;
   int i;

   in = fopen(name, "rb");
   i = 0;
   if (in != NULL) {
      // read palette
      fread(pal, 1, sizeof(pal), in);

      // sprites
      while (fread(&images[i].width, 1, 4, in) == 4) {
         fread(&images[i].height, 1, 4, in);
         images[i].data = malloc(images[i].height * images[i].width);
         fread(images[i].data, 1, images[i].height * images[i].width, in);
         images[i++].used = 1;
      }
      fclose(in);
   }
}

void save_pack(char *name)
{
   FILE *out;
   int x;

   out = fopen(name, "wb");
   fwrite(pal, 1, sizeof(pal), out);
   for (x = 0; x < 256; x++) {
       if (images[x].used == 1) {
          fwrite(&images[x].width, 1, 4, out);   
          fwrite(&images[x].height, 1, 4, out);   
          fwrite(images[x].data, 1, images[x].height * images[x].width, out);
       }
   }
   fclose(out);
}

void setup(char *argv)
{
   int x;
   allegro_init();
   set_color_depth(24);
   set_gfx_mode(GFX_AUTODETECT_WINDOWED, 640, 480, 0, 0);
   install_timer();
   install_keyboard();
   install_mouse();
   show_mouse(screen);

   install_int_ex(&my_timer_handler, BPS_TO_TIMER(30));

   fb = create_bitmap(640, 480);
   clear(fb);
   cur_img = cur_fg = cur_bg = 0; cur_fg = 255;
   memset(images, 0, sizeof(images));
   for (x = 0; x < 256; x++) {
       pal[x][0]=(x&7)*32;
       pal[x][1]=((x>>3)&7)*32;
       pal[x][2]=((x>>6)&3)*64;
   }

   load_pack(argv);
}

void draw_screen(void)
{
   int i, x, y;
   float wx, wy;
   clear(fb);

//   while (!counter) yield_timeslice(); counter = 0;

   // draw sprite if any
   if (images[cur_img].used == 1) {
      wx = 400/images[cur_img].width;
      wy = 300/images[cur_img].height;
      for (y = 0; y < images[cur_img].height; y++)
      for (x = 0; x < images[cur_img].width;  x++) {
          rectfill(fb, x*wx, y*wy, x*wx+wx, y*wy+wy, 
           makecol(pal[images[cur_img].data[y * images[cur_img].width + x]][0], 
                   pal[images[cur_img].data[y * images[cur_img].width + x]][1], 
                   pal[images[cur_img].data[y * images[cur_img].width + x]][2]));
      }
   }
   // draw preview on side
   stretch_blit(fb, fb, 0, 0, wx * images[cur_img].width, wy * images[cur_img].height, 410, 0, images[cur_img].width, images[cur_img].height);
   rect(fb, 0, 0, images[cur_img].width*wx-1, images[cur_img].height*wy-1, makecol(255, 255, 0));

   // draw palette
   wx = 640 / 64;
   wy = 180  / 4;
   for (y = 0; y < 4; y++)
   for (x = 0; x < 64; x++) {
       rectfill(fb, x*wx, 300 + y * wy, x*wx+wx, 300 + y * wy + wy, 
           makecol(pal[x+64*y][0], 
                   pal[x+64*y][1], 
                   pal[x+64*y][2]));
   }

   // put markers around our two colors
   rect(fb, ((cur_fg)%64) * wx, 300 + ((cur_fg/64))*wy, ((cur_fg)%64) * wx + wx, 300 + ((cur_fg/64))*wy + wy, makecol(255, 255, 0));
   rect(fb, ((cur_bg)%64) * wx, 300 + ((cur_bg/64))*wy, ((cur_bg)%64) * wx + wx, 300 + ((cur_bg/64))*wy + wy, makecol(255, 255, 0));

   // draw palette
   for (x = 0; x < 64; x++)
       rectfill(fb, 400+x*3, 240, 400+x*3+3,260, makecol(4*x, 0, 0));
   for (x = 0; x < 64; x++)
       rectfill(fb, 400+x*3, 260, 400+x*3+3,280, makecol(0, 4*x, 0));
   for (x = 0; x < 64; x++)
       rectfill(fb, 400+x*3, 280, 400+x*3+3,300, makecol(0, 0, 4*x));

   if (images[cur_img].used)
      textprintf(fb, font, 400, 220, makecol(255,255,255), "IMG #: %3d (%2d by %2d)", cur_img, images[cur_img].width, images[cur_img].height);
   else 
      textprintf(fb, font, 400, 220, makecol(255,255,255), "IMG #: %3d (unused)", cur_img);

   scare_mouse();
   vsync();
   blit(fb, screen, 0, 0, 0, 0, 640, 480);
   unscare_mouse();
}

void make_new(int x, int y)
{
   int z;
   for (z = 0; z < 256; z++) {
       if (images[z].used == 0) {
          images[z].width = x;
          images[z].height = y;
          images[z].data = calloc(x*y, 1);
          images[z].used = 1;
          cur_img = z;
          return ;
       }
   }
}

void quick_save(void)
{
   if (images[cur_img].used)
      memcpy(undo, images[cur_img].data, images[cur_img].width * images[cur_img].height);
}

void quick_load(void)
{
   char temp[4096];
   if (images[cur_img].used) {
      memcpy(temp, images[cur_img].data, images[cur_img].width * images[cur_img].height);
      memcpy(images[cur_img].data, undo, images[cur_img].width * images[cur_img].height);
      memcpy(undo, temp, 4096);
   }
}

unsigned char fill_scratch[64][64];

void fillarea(int x, int y)
{
   int i, j;

   if (fill_scratch[x][y]) return;
   fill_scratch[x][y] = 1;

   // scan to left on this line
   while (x > 0 && images[cur_img].data[(y * images[cur_img].width) + x] != cur_bg) --x;
   if (images[cur_img].data[(y * images[cur_img].width) + x] == cur_bg) ++x;

   // now move to left checking up/down 
   while (x < images[cur_img].width && images[cur_img].data[(y * images[cur_img].width) + x] != cur_bg) {
       images[cur_img].data[(y * images[cur_img].width) + x] = cur_fg;
       if (y > 0 && (images[cur_img].data[((y-1) * images[cur_img].width) + x] != cur_bg))
          fillarea(x,y-1);
       if (y < (images[cur_img].height-1) && (images[cur_img].data[((y+1) * images[cur_img].width) + x] != cur_bg))
          fillarea(x,y+1);
       ++x;
   }
}

void flip_h(void)
{
   int x, y, i, j;
   unsigned char t;

   if (!images[cur_img].used) return;
   for (y = 0; y < images[cur_img].height; y++) {
       i = 0; j = images[cur_img].width - 1;
       for (x = 0; x < (images[cur_img].width / 2); x++) {
           t = images[cur_img].data[y*images[cur_img].width + i];
           images[cur_img].data[y*images[cur_img].width + i] = images[cur_img].data[y*images[cur_img].width + j];
           images[cur_img].data[y*images[cur_img].width + j] = t;
           ++i; --j;
       }
   }
}

void flip_v(void) 
{
   int x, y, i, j;
   unsigned char t;

   if (!images[cur_img].used) return;
   for (x = 0; x < images[cur_img].width; x++) {
       i = 0; j = images[cur_img].height - 1;
       for (y = 0; y < (images[cur_img].height/2); y++) {
           t = images[cur_img].data[i*images[cur_img].width + x];
           images[cur_img].data[i*images[cur_img].width + x] = images[cur_img].data[j*images[cur_img].width + x];
           images[cur_img].data[j*images[cur_img].width + x] = t;
           ++i; --j;
       }
   }
}

void handleinput(char *argv)
{
   int wx, wy, x, y, col;

   for (;;) {
       clear_keybuf();
       if (key[KEY_N]) {
          do {
             clear_keybuf(); x = 0;
               if (key[KEY_1]) { make_new(8, 8);   x = 1; }
          else if (key[KEY_2]) { make_new(16, 16); x = 1; }
          else if (key[KEY_3]) { make_new(32, 32); x = 1; }
          else if (key[KEY_4]) { make_new(64, 64); x = 1; }
          else if (key[KEY_5]) { make_new(8,  16); x = 1; }
          else if (key[KEY_6]) { make_new(16, 32); x = 1; }
          else if (key[KEY_7]) { make_new(32, 64); x = 1; }
          else if (key[KEY_8]) { make_new(16, 8);  x = 1; }
          else if (key[KEY_9]) { make_new(32, 8);  x = 1; }
          else if (key[KEY_0]) { make_new(32, 16); x = 1; }
          } while (x == 0);
          clear_keybuf();
          return;
       }

       if (key[KEY_PGUP]) { cur_img += 25; if (cur_img > 255) cur_img = 255; rest(150); return; }
       if (key[KEY_PGDN]) { cur_img -= 25; if (cur_img < 0)   cur_img = 0; rest(150); return; }
       if (key[KEY_W])    { exit(0); return; }
       if (key[KEY_Q])    { save_pack(argv); exit(0); return; }
       if (key[KEY_S])    { save_pack(argv); rest(150); return; }
       if (key[KEY_DOWN]) { if (cur_img > 0) --cur_img; rest(100); return; }
       if (key[KEY_UP])   { if (cur_img < 255) ++cur_img; rest(100); return; }
       if (key[KEY_X])    { if (images[cur_img].used == 1) memset(images[cur_img].data, 0, images[cur_img].width * images[cur_img].height); return; }
       
       if (key[KEY_D])    { if (images[cur_img].used == 1) { free(images[cur_img].data); images[cur_img].used = 0; } return; }

       if (key[KEY_C])    { copy_from = cur_img; return; }
       if (key[KEY_V])    { if (images[cur_img].used && images[copy_from].used) {
                               if (images[cur_img].width == images[copy_from].width) 
                               if (images[cur_img].height == images[copy_from].height) 
                                  memcpy(images[cur_img].data, images[copy_from].data, images[cur_img].width * images[cur_img].height);
                            }
                            return;
                          }
       if (key[KEY_Z])    { quick_load(); rest(150); return; }
       if (key[KEY_P])    { 
           quick_save(); 
           memset(fill_scratch, 0, sizeof(fill_scratch)); 
           wx = 400/images[cur_img].width;
           wy = 300/images[cur_img].height;
           x = mouse_x / wx;
           y = mouse_y / wy;
           fillarea(x, y); rest(250); return; 
       }
       if (key[KEY_I])    { 
          if (images[cur_img].used) {
             wx = 400/images[cur_img].width;
             wy = 300/images[cur_img].height;
             x = mouse_x / wx;
             y = mouse_y / wy;
             cur_fg = images[cur_img].data[y * images[cur_img].width + x];
             rest(150);
             return;
          }
       }
       if (key[KEY_O])    { 
          if (images[cur_img].used) {
             wx = 400/images[cur_img].width;
             wy = 300/images[cur_img].height;
             x = mouse_x / wx;
             y = mouse_y / wy;
             cur_bg = images[cur_img].data[y * images[cur_img].width + x];
             rest(150);
             return;
          }
       }
       if (key[KEY_H]) { flip_h(); rest(150); return; }
       if (key[KEY_J]) { flip_v(); rest(150); return; }

       if (!mouse_b) { qs = 0; }

       if (mouse_b) {
          // mouse

          // within the image area?
          if (images[cur_img].used)
          if (mouse_x > 0 && mouse_x < 400 && mouse_y > 0 && mouse_y < 300) {
             if (qs == 0) {
                quick_save();
                qs = 1;
             }

             wx = 400/images[cur_img].width;
             wy = 300/images[cur_img].height;
             x = mouse_x / wx;
             y = mouse_y / wy;
             if (x < images[cur_img].width && y < images[cur_img].height)
                images[cur_img].data[y * images[cur_img].width + x] = mouse_b & 1 ? cur_fg : cur_bg;
             return;
          }

          if (mouse_b == 1|2) {
             if (mouse_x > 400 && mouse_x < 640 && mouse_y > 240 && mouse_y < 300) {
                wx = mouse_x - 400; 
                wy = mouse_y - 240;
                x  = (wx / 3) * 4;
                y  = (wy / 20);
                pal[mouse_b==1?cur_fg:cur_bg][y] = x;
                draw_screen();
             }
          }

          if (mouse_y > 300 && mouse_y < 480) {
             // figure out which color is picked
             wy = mouse_y - 300;
             y  = wy / 45;
             x  = mouse_x / 10;
             col = y * 64 + x;

             if (mouse_b == 1) { cur_fg = col; return; }
             if (mouse_b == 2) { cur_bg = col; return; }
           }
       }
   }
}

void export(char *name)
{
   unsigned char buf[128], tmp[4096];
   int poses[256], sizes[256];
   FILE *out;
   int x, y, z, t, i, j, u, v, k, tt;

   setup(name );
   load_pack(name);
   sprintf(buf, "%s.c", name);

   tt = z = 0;

   memset(poses, 0, sizeof(poses));
   memset(sizes, 0, sizeof(sizes));

   out = fopen(buf, "w");
   fprintf(out, "const unsigned short %s_pak[] = {\n", name);
   for (x = 0; x < 256; x++) {
       if (images[x].used) {
          // copy it as a series of 8x8 tiles to temp in row major order
          k = 0;
          for (j = 0; j < images[x].height; j += 8) //y
          for (i = 0; i < images[x].width;  i += 8) //x
            for (v = 0; v < 8; ++v) //y
            for (u = 0; u < 8; ++u) //x
                tmp[k++] = images[x].data[((j + v) * images[x].width) + i + u];

          poses[x] = z;
          for (y = 0; y < k; y += 2) {
              t = ((unsigned)tmp[y+1] << 8) | (unsigned)tmp[y+0];
              fprintf(out, "0x%04x,", t);
              if (!((++tt) % 12)) fprintf(out, "\n");
          }
          t = (images[x].width / 8) * (images[x].height / 8);
          z += t;
          sizes[x] = t;
       }
   }
   fprintf(out, "};\n\nconst unsigned short *%s_ofs[] = {\n", name);
   for (x = 0; x < 256; ) {
       fprintf(out, "&%s_pak[%lu]", name, (poses[x] * 64) / 2);
       if (x < 255) fprintf(out, ",");
       if (!(++x % 6)) fprintf(out, "\n");
   }
   fprintf(out, "};\n\nconst unsigned char %s_sizes[] = {\n", name);
   for (x = 0; x < 256; ) {
       fprintf(out, "0x%02x", sizes[x]);
       if (x < 255) fprintf(out, ",");
       if (!(++x % 12)) fprintf(out, "\n");
   }
   fprintf(out, "};\n\n");
  
   fprintf(out, "const unsigned short %s_pal[] = {\n", name);
   for (x = 0; x < 256; ) {
       fprintf(out, "0x%04x", RGB(pal[x][0]>>2,pal[x][1]>>2,pal[x][2]>>2));
       if (x < 255) fprintf(out, ",");
       if (!(++x % 12)) fprintf(out, "\n");
   }
   fprintf(out, "};\n\n");

   fclose(out);
}
          
int main(int argc, char **argv)
{
   if (argc == 3) { export(argv[2]); return 0; }
   if (argc != 2) { printf("Usage:\n%s packfile\n%s -export pack_file\n\n", argv[0], argv[0]); return 0; }
   setup(argv[1]);
   for (;;) {
       draw_screen();
       handleinput(argv[1]);
   }
}

END_OF_MAIN();