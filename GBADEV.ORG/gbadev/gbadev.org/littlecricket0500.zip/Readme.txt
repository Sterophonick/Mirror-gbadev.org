Little Cricket Advance
by Griever308
/////////////////////////

Hey folks! I hope you have as much fun playing this 
as I had making it! This game didn't turn out how I
first had in mind, but I guess I'm still proud of it.
(It was originally a racing game, haha!)
You play the Little Cricket, a poor little ship with the 
duty of keeping a massive bomb from going off your home planet.
Use any means neccessary to keep the enemy away - 
ram them, shoot them, whatever. Just keep an eye on your health
and the bomb's health!

Use [R] and [L] to rotate
Press[A] to accelerate
Hold [B] to fire.

Have fun, peeps! 
Email me at Griever308@yahoo.com.
Source availabe upon request...