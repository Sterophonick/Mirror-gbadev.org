"Very hard" level, uncomletly done. But you can play on "Medium" level.
From Belarus with GDE_Hearts.