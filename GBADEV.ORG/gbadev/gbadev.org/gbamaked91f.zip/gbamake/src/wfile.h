/* ****************************************************************	*/
/*																	*/
/*	class WFile														*/
/*		standard file class											*/
/*																	*/
/*		by Warp - realwarp@caramail.com								*/
/*																	*/
/* ****************************************************************	*/
#ifndef WFILE_H
#define WFILE_H

#include <string>
typedef std::string WString;


class WFile {

	FILE	*handle;
	WString name;
	
	char *buf;
	int   buflen;
	int   bufsize;
	
	long size;
	long pos;

public:

	long Size()
	{
		return size;
	}

	long Pos()
	{
		return pos;
	}

	bool Eof()
	{
		return (pos >= size);
	}

	void Close()
	{
		if( handle != NULL )
		{
			fclose(handle);
			handle = NULL;
		}
	}

	bool Open()
	{
		Close();
		handle=fopen(name.c_str(),"rb");
		if( handle != NULL )
		{
			fseek( handle, 0, 2 );
			size = ftell(handle);
			fseek( handle, 0, 0 );
		}
		else
		{
			size = 0;
			pos = 0;
		}
		return ( handle != NULL );
	}

	bool Append()
	{
		Close();
		handle=fopen(name.c_str(),"ab");
		if( handle != NULL )
		{
			size = ftell(handle);
			pos = size;
		}
		else
		{
			size = 0;
			pos = 0;
		}
		return ( handle != NULL );
	}

    bool SetPos( int p )
    {
        if( handle == NULL || p > size || p < 0 )
            return false;
        fseek( handle, p, 0 );
        return true;
    }

    int Seek( int p, int mode )
    {
        if( handle != NULL )
            return fseek( handle, p, mode );
        return 0;
    }

	bool Create()
	{
		Close();
		size = 0;
		pos = 0;
		return ((handle=fopen(name.c_str(),"wb")) != NULL );
	}
		
	int Read( void *rbuf, int maxlen )
	{
		int l = 0;
		if( maxlen <= buflen )
		{
			memcpy( rbuf, buf+bufsize-buflen, maxlen );
			buflen-=maxlen;
			pos+=maxlen;
			return maxlen;
		}
		while( maxlen > buflen )
		{
			memcpy( rbuf, buf+bufsize-buflen, buflen );
			maxlen-=buflen;
			l+=buflen;
			rbuf=(char*)rbuf+buflen;
			bufsize = fread( buf, 1, bufsize, handle );
			buflen = bufsize;
			if( buflen == 0 )
			{
				pos+=l;
				return l;
			}
		}
		memcpy( rbuf, buf+bufsize-buflen, maxlen );
		buflen-=maxlen;
		l+=maxlen;
		pos+=l;
		return l;
	}

	bool ReadLine( WString *string, const WString stopchars = "\r\n" )
	{
        int p = 0;
        bool r = true;
		char c;

		string->resize(0);		
        while(1)
        {			
            if( Read( &c, 1 ) == 0 )
            {
                if( p == 0 )
                    r = false;
                break;
            }
			pos++;
			if( strchr(stopchars.c_str(),c) != NULL )
				break;
			*string += c;
            p++;
        }		    
		return r;
	}

	bool ReadString( WString *string )
	{		
        int p = 0;
        bool r = true;
		char c;

        while(1)
        {			
            if( Read( &c, 1 ) == 0 )
            {
                if( p == 0 )
                    r = false;
                break;
            }			
			pos++;
            if( c == 0 )
                break;
			*string += c;
            p++;			
        }
		return r;
	}

    void Write( const void *buffer, int len )
    {
        fwrite( (char*)buffer,1,len, handle );
		size += len;
    }

	void Write( const WString string )
	{
		fputs( string.c_str(), handle );
		size +=string.length();
	}

	void WriteLine( const WString string )
	{
		fputs( string.c_str(), handle );
		fputs( "\r\n", handle );
		size +=string.length()+2;
	}

	void WriteString( const WString string )
	{
		fputs( string.c_str(), handle );
		fputs( "\0", handle );
		size +=string.length()+1;
	}

	WFile( WString Name, int BufferSize = 1024 )
	{
		handle = NULL;
		name = Name;		
		size = 0;
		pos = 0;
		bufsize = BufferSize;
		buf = new char[bufsize];
		buflen = 0;
	}

	~WFile()
	{
		Close();
		delete buf;
	}
};

#endif
/* ****************************************************************	*/
