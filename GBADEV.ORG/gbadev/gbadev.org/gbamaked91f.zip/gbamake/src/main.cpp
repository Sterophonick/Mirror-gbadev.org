/* ****************************************************************	*/
/*																	*/
/*	GBAmake v1.0													*/
/*																	*/
/*		by Warp - realwarp@caramail.com								*/
/*																	*/
/* ****************************************************************	*/
// includes

#include <stdio.h>
#include "wfile.h"
#include <windows.h>

/* ************************************************************************************* */
// consts

#define GBA_OUT "gba_out.log"

#define CC	"zarmcc.exe"
#define CPPC "zarmcpp.exe"
#define ASMC "zarmasm.exe"

#define LINKER "zarmlink.exe"

#define AFLAGS " -Littleend -cpu ARM7TDMI "
#define CFLAGS " -c -Wall -Otime  -fpu none -Littleend -cpu ARM7TDMI "
#define LFLAGS " -bin -first boot.o -map -ro-base 0x08000000 -rw-base 0x3000600 "

#define DSP_FBEGIN "SOURCE="

#define C_COMPILE(x)	b = launch(	CC,		CFLAGS+x+" -o " +shiftTo(x,"o"),shiftTo(x,"o") )
#define CPP_COMPILE(x)	b = launch(	CPPC,	CFLAGS+x+" -o " +shiftTo(x,"o"),shiftTo(x,"o") )
#define ASM_COMPILE(x)	b = launch(	ASMC,	AFLAGS+x+" -o " +shiftTo(x,"o"),shiftTo(x,"o") )

#define LINK(prj,files)			launch( LINKER, LFLAGS+files+" -o "+shiftTo(prj,"bin"),shiftTo(prj,"bin"));

/* ************************************************************************************* */
// globals

HANDLE output;
WString files_to_link;

// params

bool ignore_badfiles	= false;
bool ignore_lines		= true;
bool cleanup			= true;
WString ARM_PATH		= "";

/* ************************************************************************************* */

bool launch( WString cmd, WString params, WString file ) {
	
	PROCESS_INFORMATION pinf;
	STARTUPINFO sinf;
	
	// set output...
	memset(&sinf,0,sizeof(sinf));
	sinf.cb = sizeof(sinf);
	sinf.dwFlags = STARTF_USESTDHANDLES;
	sinf.hStdInput = NULL;
	sinf.hStdOutput = output;
	sinf.hStdError = output;
	
	// print interval
	WString interval = "***["+file+"]***\n";
	DWORD c;
	WriteFile(output,interval.c_str(),interval.length(),&c,NULL);
	
	// launch compilation
	if( ! CreateProcess((ARM_PATH+cmd).c_str(),
		(char*)params.c_str(),
		NULL,
		NULL,
		TRUE,
		DETACHED_PROCESS,
		NULL,
		NULL,
		&sinf,
		&pinf) ) {
		printf("ERROR : failed to launch %s\n",cmd.c_str());
		return false;
	}
	
	// wait for terminaison
	WaitForSingleObject(pinf.hProcess,INFINITE);
	GetExitCodeProcess(pinf.hProcess,&c);
	
	if( strcmp(cmd.c_str(),LINKER) != 0 )
		files_to_link += file+" ";
	
	return (c == 0);
}

/* ************************************************************************************* */

// transform a .xxx file into a .yyy
WString shiftTo( WString file, WString ext ) {
	WString O = file;
	int i = file.rfind('.');
	if( i != -1 )
		O = file.substr(0,i+1);	
	return O+ext;
}


/* ************************************************************************************* */
// create a handle for redirecting compilation output (for post-processing)

bool outRedirect() {
	SECURITY_ATTRIBUTES saAttr;
	
	// Set the bInheritHandle flag so pipe handles are inherited.
	saAttr.nLength = sizeof(SECURITY_ATTRIBUTES);
	saAttr.bInheritHandle = TRUE;
	saAttr.lpSecurityDescriptor = NULL;
	
	output = CreateFile( GBA_OUT, GENERIC_WRITE, 0, &saAttr, CREATE_ALWAYS, 0, NULL );
	
	return (output != NULL);
}

/* ************************************************************************************* */
// post-process compilation output to VC++ format

void postProcess() {
	WFile f(GBA_OUT);
	if( !f.Open() ) {
		printf("ERROR, cannot make postProcess\n");
		return;
	}
	WString line;
	while( f.ReadLine(&line) ) {
		if( line.find("-bin output file format") == -1 && line.length() > 0 ) {
			if( line.c_str()[0] == '"' ) {
				line = line.substr(1);
				int p = line.find('"');
				WString file = line.substr(0,p);
				line = line.substr(p+1);
				p = line.find(":");
				WString lnb = line.substr(7,p-7);
				line = line.substr(p+1);
				printf("%s(%s) :",file.c_str(),lnb.c_str());
				printf("%s\n",line.c_str());
			}
			else
			{
				if( line.c_str()[0] == '*' || memcmp(line.c_str(),"Error",5) == 0 || !ignore_lines )
					printf("%s\n",line.c_str());
			}
		}
	}
	f.Close();
}

/* ************************************************************************************* */
// print usage, version, etc...

void usage() {
printf("\
		  Usage : gbamake [-pARM_PATH] [-v] [-noclean] Project.dsp\n\
		  gbamake v1.0 *03/30/01* - coded by Warp for VC++ users\n\
		  realwarp@caramail.com\n\
		  \n\
		  -i : ignore bad files extensions\n\
		  -v : verbose mode, print all output lines\n\
		  -p : set the path to find ARM compile tools\n\
		  -noclean : disable auto-delete of .o files\n\
		  \n\
		  ");
}

/* ************************************************************************************* */
// main

int main( int argc, char *argv[] ) {
	if( argc < 2 ) {
		usage();
	}
	else {
		
		// argument processing
		if( argc > 2 ) {
			int i;
			for(i=1;i<argc-1;i++) {
				if( strcmp(argv[i],"-noclean") == 0 )
					cleanup = false;
				if( strcmp(argv[i],"-v") == 0 )
					ignore_lines = false;
				if( strcmp(argv[i],"-i") == 0 )
					ignore_badfiles = true;
				if( memcmp(argv[i],"-p",2) == 0 ) {
					ARM_PATH = argv[i]+2;
					if( ARM_PATH.rfind('\\') != ARM_PATH.length()-1 && 
						ARM_PATH.rfind('/') != ARM_PATH.length()-1 )
						ARM_PATH+="\\";
				}
			}
		}
		
		
		const char *DSP_FILE = argv[argc-1];
		
		// check DSP Existence
		WFile dsp(DSP_FILE);
		if( ! dsp.Open() ) {
			printf("ERROR, cannot open %s\n",DSP_FILE);
			return 0;
		}
		
		
		// redirect output
		if( !outRedirect() ) {
			printf("ERROR, cannot redirect output\n");
			return 0;
		}
		
		// read DSP Lines
		WString line;
		bool allowLink = true;	
		
		while( dsp.ReadLine(&line) ) {
			if( memcmp(line.c_str(),DSP_FBEGIN,strlen(DSP_FBEGIN)) == 0 ) {
				line = line.substr(7);
				bool b = false;		
				// launch compilers
				switch( line.c_str()[line.length()-1] ) {
				case 'c': // .c
					C_COMPILE(line);
					break;
				case 'p': // .cpp
					CPP_COMPILE(line);
					break;
				case 'h': // .h										
					b = true;
					break;
				case 's': // .s
				case 'm': // .asm
					ASM_COMPILE(line);
					break;
				default:
					if( ! ignore_badfiles )
						printf("ERROR, cannot compile %s : unknown file format\n",line.c_str());
					else
						b = true;
					break;
				}
				if( !b )
					allowLink = false;
			}
		}
		
		// process link
		if( allowLink )
			LINK(((WString)DSP_FILE),files_to_link);
		
		// close
		dsp.Close();
		CloseHandle(output);
		
		// post-compilation string processing
		postProcess();
		
		// clean-up
		if( cleanup ) {			
			DeleteFile(GBA_OUT);
			
			int p;
			while( (p=files_to_link.find(' ')) != -1 ) {
				DeleteFile( files_to_link.substr(0,p).c_str() );
				files_to_link = files_to_link.substr(p+1);
			}
		}
	}
	return 0;
}

/* ************************************************************************************* */
