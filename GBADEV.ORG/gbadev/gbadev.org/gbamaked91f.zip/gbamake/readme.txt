gbamake v1.0 *03/30/01* - coded by Warp for VC++ users
realwarp@caramail.com

Usage : gbamake [-pARM_PATH] [-v] [-noclean] Project.dsp

	-i : ignore bad files extensions
	-v : verbose mode, print all output lines
	-p : set the path to find ARM compile tools
	-noclean : disable auto-delete of .o files

What does it do ?
-----------------
GBAMAKE takes a DSP ( Visual C++ Project File ) and scan it for files.
then it compile every C,CPP,ASM,S file with ARM Tools and process the output
to make errors "clickable" ( click on the error to go to the current file/line ).

How to install it ?
-------------------
First, copy GBAMAKE in your VC++ BIN Directory
( usually Program Files/Microsoft Visual Studio/VC98/Bin )
Then, create a new MakeFile project, and copy the joined MakeFile (default.mak)
into your Project dir.

rename it, edit it, and change :
- the project name to yours
- cflags (gbamake arguments) if you want.
- DON'T FORGET TO SET THE APPROPRIATE ARM_PATH !

You can now add your files to your project : 
DON'T FORGET TO SAVE THE PROJECT FILE (SaveAll) BEFORE COMPILING !
Just compile under VC++ with F7.

Warp

