/* GBA CONSOLE V1.0 by Hu YingHao (hyinghao@hotmail.com) */

#ifndef CONSOLE_H
#define CONSOLE_H
#include <CsAgb.h>

/*******************************************************************************
  USAGE OF gets() :

     1) stage 0 (gets())
     Press A to activate IME bar.
     Press LEFT to delete the char you just input.
     
     Press START to accept the string you just inputed. just like "ENTER".
     (Note: When you press START you should quit IME bar)
     
     2) stage 1
     When you activate IME bar, you can press UP/DOWN/LEFT/RIGHT to select char table.
     Press A to confirm your select     
     Press R to toggle uppercase/lowercase
     
     Press B to return to gets (stage 0)
     (Note: When you press START in stage 0 ,you should quit IME bar)
     
     3) stage 2
     Press LEFT/RIGHT to move the current char.
     Press UP/DOWN to locate the first Letter/symbol
     Presss R to toggle uppercase/lowercase
     Press A to confirm your select, this char will be recorded
     Press B to return to stage 1
     
*******************************************************************************/


//get an zero-terminal string at(col,row)
char* gets(int col, int row);
//put an zero-terminal string at(col,row)
void puts(int col, int row, char* s);
//clear screen
void clrscr();


//ps: Chinese is not supported in this version.


//convert the pad input to standard IME key code
int translateIME();
//display the ime pad.
void drawIME();
//initialize the ime system.
void initIME(void (*_IMEGetChar)(char ch), void (*_IMEEnd)());
//process the ime state according to the standard IME key code
int processIME(int ch);
//launch the ime bar
void mainIME();


//invoked when the user select a char.
void (*IMEGetChar)(char ch);
//invoked when the user exit the IME (stage1)
void (*IMEEnd)();


#endif
