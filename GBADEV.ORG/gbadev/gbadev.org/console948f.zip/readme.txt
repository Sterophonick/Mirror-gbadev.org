GBA IME 


About
    This demo is an input method engine program for gba. You can use it to select and input some chars. This IME program is created with csagvlib(http://www.loveu.cn/hdxc/fenye/youxi.htm). It is only a concept model for gba development. This program shows that gba can be used for some simple text programs such as console program. It will greatly extend capability of the gba program.



Author
Hu YingHao (Eric)
Email hyinghao@hotmail.com



Copyright
This is a freeware. You can use it freely in non-commercial program.



Usage
1) stage 0 (gets())
Press A to activate IME bar.
Press LEFT to delete the char you just input.

Press START to accept the string you just inputed. just like "ENTER".
(Note: When you press START you should quit IME bar)


2) stage 1
When you activate IME bar, you can press UP/DOWN/LEFT/RIGHT to select char table.
Press A to confirm your select
Press R to toggle uppercase/lowercase

Press B to return to gets (stage 0)
(Note: When you press START in stage 0 ,you should quit IME bar)

3) stage 2
Press LEFT/RIGHT to move the current char.
Press UP/DOWN to locate the first Letter/symbol
Presss R to toggle uppercase/lowercase
Press A to confirm your select, this char will be recorded
Press B to return to stage 1
(When you press START in stage 0 ,you should quit IME bar)



Source Code
The followings are some console functions. These functions are easy to use. I don't want to make any explanations here.

//get an zero-terminal string at(col,row)
char* gets(int col, int row);
//put an zero-terminal string at(col,row)
void puts(int col, int row, char* s);
//clear screenvoid clrscr();

    I'll explain the IME functions here. I defined 5 functions in the file. They are:

int translateIME(); //convert the pad input to standard IME key code
void displayIME();  //display the ime pad.
void initIME();     //initialize the ime system.
int processIME();   //process the ime state according to the standard IME key code
void mainIME();     //launch the ime bar

processIME() is an automata. It will process according to the standard IME Key code. It is an enclosed. Only "IME key" can affect the program. This function only updates the state of the automata.

    displayIME() displays the IME Pad real time. It can be overridden using object/tile mode.
mainIME() to launch the IME bar and accept input. you can define your own mainIME() according to your requirement.

    To use IME in your own code. you should define 2 callback function. They are:
void (*IMEGetChar)(char ch); //is called when the user select a char.
void (*IMEEnd)();            //is invoked when the user exit the IME (stage1)

These 2 functions are set in initIME().
You can use char* gets(int column, int row) to get a string from the screen. It's really work.




Enjoy it!
