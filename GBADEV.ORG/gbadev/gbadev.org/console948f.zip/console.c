/* GBA CONSOLE V1.0 by Hu YingHao (hyinghao@hotmail.com) */
#ifndef CONSOLE_C
#define CONSOLE_C

#include "console.h"

#define UP 0
#define DOWN 1
#define LEFT 2
#define RIGHT 3
#define A 4
#define B 5
#define R 6
#define NONE 7

#define STAGE1 1
#define STAGE2 2

/*----------------------------------------------------------------------------*/
/*                  Definitions of IME bar                                    */
/*----------------------------------------------------------------------------*/
static char * IMEChars[] = {
 "ABC012\0",    "DEF345\0",   "GHI6789\0",
 "JKL .,<>_\0", "MNO;()|&\0", "PQR+-*/=`\0",
 "STU!{}\\^\0", "VWX?[]\"'\0","YZ:@#$%~\0",
};
static int IMEflag = 0;
static int IMECharLength [] = { 6,6,7,  9,8,9,  8,8,8, };
static u16 normalColor = RGB(24,24,24), highlightColor = RGB(31,31,31), bgColor = RGB(0,0,0);

static int stage,    /* select chars or select a single char */
           lowercase,/* is it lower case */
           pPos,     /* position of pad */
           chPos;    /* position of chars*/
/*----------------------------------------------------------------------------*/
/*                  Definitions of Console                                    */
/*----------------------------------------------------------------------------*/
static char buffer [31];
static int p,X,Y;
/*----------------------------------------------------------------------------*/
/*                  Implementations of IME bar                                */
/*----------------------------------------------------------------------------*/
void drawSelected(char* s, int x,int y, int p) {
   char c,i=0;

   while( s[0] != 0 ) {
      /* translate lowercase */
      c = s[0];
      c = (lowercase && c>=65 && c<=90)? c+32:c;

      /* text it out according to the (p)osition */
      CS_OutText( &gScreen, x+i*8, y,
                  (i==p)?highlightColor:normalColor,
                  HZK_10, "%c", c);

      /* shift the pointer */
      i++; s++;
   }
}
/*----------------------------------------------------------------------------*/
void drawIME() {
    CS_FillRect(&gScreen,0,149,239,159,RGB(0,0,0));
    CS_Line(&gScreen,0,148,239,148,normalColor);
    //draw state
    CS_OutText(&gScreen,2,150,(stage==STAGE1)?normalColor:highlightColor,HZK_10,"%d",pPos+1);
    CS_Line(&gScreen,11,150,11,159,normalColor);

    //draw selected
    drawSelected(IMEChars[pPos],18,150,(stage==STAGE1)?200:chPos);

    //draw uppercase/lowercase
    CS_Line(&gScreen,229,150,229,159,normalColor);
    CS_OutText(&gScreen,232,150,normalColor,HZK_10,"%c",(lowercase)?'a':'A');
}
/*----------------------------------------------------------------------------*/
/* translate the key state to Macro for quick easy processing */
int translateIME() {
  if (CS_IsKeyDown(KEY_R))     return R;
  if (CS_IsKeyDown(KEY_A))     return A;
  if (CS_IsKeyDown(KEY_B))     return B;
  if (CS_IsKeyDown(KEY_UP))    return UP;
  if (CS_IsKeyDown(KEY_DOWN))  return DOWN;
  if (CS_IsKeyDown(KEY_RIGHT)) return RIGHT;
  if (CS_IsKeyDown(KEY_LEFT))  return LEFT;
  return NONE;
}
/*----------------------------------------------------------------------------*/
void initIME(void (*_IMEGetChar)(char ch),void (*_IMEEnd)()) {
  IMEGetChar = _IMEGetChar;
  IMEEnd = _IMEEnd;
  lowercase = 0;
  stage = STAGE1;
  pPos  = 0;
  chPos = 0;
}
/*----------------------------------------------------------------------------*/
int processIME(int ch) {
  char c,changed=0;

  switch (stage) {

    case STAGE1: {
      switch(ch) {
        case UP:   if (pPos>=3 ) {pPos-=3; changed=1;}break;
        case DOWN: if (pPos<=5 ) {pPos+=3; changed=1;}break;
        case LEFT: if (pPos%3>0) {pPos--;  changed=1;}break;
        case RIGHT:if (pPos%3<2) {pPos++;  changed=1;}break;
        case R:    {lowercase = !lowercase;changed=1;}break;
        case A:    {stage=STAGE2; chPos=0; changed=1;} break;
        case B:IMEEnd();break;
      }
    } break;

    case STAGE2: {
      switch(ch) {
        case UP:    {chPos = 0;changed=1;}break;             /* to letter */
        case DOWN:  {chPos = (pPos!=8)?3:2;changed=1;}break; /* to symbol */
        case LEFT:  {chPos = (chPos>0)?(chPos-1):chPos;changed=1;}break;
        case RIGHT: {chPos = (chPos<IMECharLength[pPos]-1)?(chPos+1):chPos;changed=1;}break;
        case R:     {lowercase = !lowercase;changed=1;}break;
        case A:     { stage = STAGE1; c = IMEChars[pPos][chPos];
                      IMEGetChar( (lowercase && c>=65 && c<=90)? c+32:c );changed=1;}break;
        case B: {stage = STAGE1;changed=1;}break;
      }

    } break;
  }
  return changed;
}
/*----------------------------------------------------------------------------*/
//launch the IME for input
void mainIME() {
   IMEflag = 1;
   drawIME();

   while(IMEflag)
	{
      CS_ReadKey();
      if (processIME(translateIME())) drawIME();
   }
}
/*----------------------------------------------------------------------------*/
/*                  Implementations of console                                */
/*----------------------------------------------------------------------------*/
void drawCaret(int x, int y,u16 color) {
   CS_Line(&gScreen,x*8+2,(y+1)*8-1,(x+1)*8-2,(y+1)*8-1,color);
}
/*----------------------------------------------------------------------------*/
// this function is used internal, display string according to p
void putsp(int col, int row, char* s) {
   int i;
   CS_FillRect(&gScreen,col*8+1,row*8,(col+p+1)*8+1,(row+1)*8,bgColor);
   for(i=0;i<p;i++) {
      if (s[i]=='\0') break;
      CS_OutText(&gScreen,(col+i)*8+1,row*8,normalColor,HZK_10,"%c",s[i]);
   }
}
/*----------------------------------------------------------------------------*/
void puts(int col, int row, char* s) {
   int i,j;
   
   for(i=0;i+col<30;i++) {
      if (s[i]=='\0') break;
      CS_FillRect(&gScreen,(col+i)*8+1,row*8,(col+i+1)*8+1,(row+1)*8,bgColor);
      CS_OutText(&gScreen,(col+i)*8+1,row*8,normalColor,HZK_10,"%c",s[i]);
   }
}
/*----------------------------------------------------------------------------*/
//internal GetChar hook function
void consoleIMEGetChar(char ch){
  buffer[p] = ch;
  buffer[p+1] = '\0';
  if (p+X<29) p++;
  putsp(X,Y,buffer);
  if (p+X<29)
  drawCaret(X+p,Y,highlightColor);
}
/*----------------------------------------------------------------------------*/
//internal End hook function
void consoleIMEEnd(){
  IMEflag = 0;
}
/*----------------------------------------------------------------------------*/
char* gets(int col, int row) {
   int flag = 1;
   X = col; Y = row; p = 0;
   buffer[0] = '\0';
   buffer[1] = '\0';
   initIME(consoleIMEGetChar,consoleIMEEnd);
   drawCaret(X+p,Y,highlightColor);

   while (flag) {
      CS_ReadKey();
      /* backspace */
      if (CS_IsKeyDown(KEY_LEFT) && p>0) {
         CS_FillRect(&gScreen,(col+p-1)*8,row*8,(col+p)*8,(row+1)*8,bgColor);
         drawCaret(X+p,Y,bgColor);
         buffer[p] = '\0';
         p--;
         drawCaret(X+p,Y,highlightColor);
      }
      /* start IME get a char */
      else if (CS_IsKeyDown(KEY_A)) {
         mainIME();
         CS_FillRect(&gScreen,0,148,239,159,bgColor);
      }
      /* get the whole string */
      else if (CS_IsKeyDown(KEY_START)) {
         drawCaret(X+p,Y,bgColor);
         return buffer;
      }
   }
}
/*----------------------------------------------------------------------------*/
void clrscr() {
   CS_CopyOAM();
   CS_Clear(&gScreen,bgColor);
}
/*----------------------------------------------------------------------------*/
#endif
