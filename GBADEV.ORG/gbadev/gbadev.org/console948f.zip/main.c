/* GBA CONSOLE V1.0 by Hu YingHao (hyinghao@hotmail.com) */

#include "console.h"


void VBlank();

static char* got = 0;

void AgbMain(void)
{

	CS_InitGBA();
	CS_InitSRAM();

	_DEBUG_SHOW_VERSION

	CS_SetVideoMode(MODE_3 | DISP_OBJ_ON | DISP_OBJ_CHAR_2D_MAP | BG2_ENABLE);
	CS_SetIntrFunc(V_BLANK_INTR_FLAG,VBlank);
	_M_SETHZK_10;
   CS_OpenVBlank();
   




   puts(0,0,"Your name :\0");
   puts(7,5,"GBA Console Demo\0");
   puts(7,7,"Created by Eric\0");
   puts(5,8,"hyinghao@hotmail.com\0");
	got = gets(11,0);
	puts(5,11,"Your name is \0");
   puts(18,11,got);






   while(1);
}


void VBlank() {}
