//------------------------------------------------------------------------

// rnd : Random number generation
// Rich Heasman April 2002

//------------------------------------------------------------------------

#include	"mygba.h"
#include 	"rnd.h"

//------------------------------------------------------------------------

#define	RND_MAX_SEED	2097152

//------------------------------------------------------------------------

static	unsigned int	uRndSeed;

//------------------------------------------------------------------------

void	Rnd_Init(void)
{
	uRndSeed = 0;
}

//------------------------------------------------------------------------

void	Rnd_SeedSet(unsigned int uSeed)
{
	uRndSeed=uSeed;
}

//------------------------------------------------------------------------

unsigned int 	Rnd(unsigned int uRange)
{
	unsigned int	uRandomVal;

	uRndSeed = (uRndSeed*1021+1) % RND_MAX_SEED;
	uRandomVal = uRndSeed*uRange/RND_MAX_SEED;

	return(uRandomVal);
}

//------------------------------------------------------------------------
