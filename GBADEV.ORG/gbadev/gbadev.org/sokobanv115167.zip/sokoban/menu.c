//------------------------------------------------------------------------------------

// Menu
// Rich Heasman April 2002

//------------------------------------------------------------------------------------

#include "mygba.h"
#include "menu.h"

#include "vblank.h"
#include "map.h"
#include "button.h"
#include "game.h"
#include "dsprintf.h"
#include "gfx.h"
#include "gfxdata1.h"
#include "interrupt.h"
#include "background.h"

#define	MENU_DEV_AVAILABLE	FALSE

enum
{
	MENU_INIT,
	MENU_PRE_GAME_INIT,
	MENU_PRE_GAME,
	MENU_DORMANT,
	MENU_INGAME,
	MENU_DEV,
	MENU_INFO
};

enum
{
	MENU_IG_RESTART,
	MENU_IG_QUIT,

	MENU_IG_MAX
};

enum
{
	MENU_DEV_RESET,					// to save the on/off switch�

	MENU_DEV_MAX
};

static	uint		uMenuState;
static	uint		uMenuLevelMax;
static	uint		uMenuLevel;
static	uint		uMenuIGOption;
static 	uint		uMenuDevOption;

static	uint		uMenuLevelTimer;
static	uint		uMenuLevelTimerLen;
static	const uint	uMenuLevelTimerInit = 20;
static	const uint	uMenuLevelTimerDec = 4;

static	uint		uMenuInfoTimer;
static	const uint	uMenuInfoTimerLen = 120;

#define	MENU_INFO_STRING	"v1.1 by Rich Heasman"

//------------------------------------------------------------------------------------

void	Menu_Init(void)
{
	uMenuLevel = 0;
	uMenuLevelMax = Map_NumLevelsGet()-1;

	uMenuIGOption = MENU_IG_RESTART;
	uMenuDevOption = MENU_DEV_RESET;
	uMenuState = MENU_INIT;

	uMenuLevelTimer = 0;
	uMenuLevelTimerLen = uMenuLevelTimerInit;

   	VBlank_TimerSet(&uMenuInfoTimer, uMenuInfoTimerLen);
}

//------------------------------------------------------------------------------------

void	Menu_Update(void)
{
	BOOL	boRequest;
	BOOL	boChange;

    switch(uMenuState)
	{
		case MENU_INIT :
		{
			uMenuState = MENU_PRE_GAME_INIT;
			break;
		}
		case MENU_PRE_GAME_INIT:
		{
			uMenuState = MENU_PRE_GAME;
			break;
		}
		case MENU_PRE_GAME :
		{
			if (Button_PressedDebounced(BUTTON_A)
			 || Button_PressedDebounced(BUTTON_START))
			{
				Game_StateSet(GAME_INGAME_PRE_INIT);
				uMenuState = MENU_DORMANT;
			}

			boRequest = FALSE;
			boChange = FALSE;
			if (Button_Pressed(BUTTON_UP))
			{
				if (uMenuLevel < uMenuLevelMax)
				{
					if (uMenuLevelTimer == 0)
					{
						uMenuLevel++;
						boChange = TRUE;
					}
				}
				boRequest = TRUE;
			} 	
			if (Button_Pressed(BUTTON_DOWN))
			{
				if (uMenuLevel > 0)
				{
					if (uMenuLevelTimer == 0)
					{
						uMenuLevel--;
						boChange = TRUE;
					}
				}
				boRequest = TRUE;
			} 
			if (boChange)
			{
				uMenuLevelTimer = uMenuLevelTimerLen;
				if (uMenuLevelTimerLen >= uMenuLevelTimerDec)
				{
					uMenuLevelTimerLen -= uMenuLevelTimerDec;
				}
			}
			if (boRequest)
			{
				if (uMenuLevelTimer > 0)
				{
					uMenuLevelTimer--;
				}
			}
			else
			{
				uMenuLevelTimerLen = uMenuLevelTimerInit;
				uMenuLevelTimer = 0;
			}

			break;
		}
		case MENU_DORMANT :
		{
			if (Game_StateGet() == GAME_INGAME)
			{
				if (Button_PressedDebounced(BUTTON_START))
				{
					Game_StateSet(GAME_DORMANT);
					uMenuState = MENU_INGAME;
				}
			}
			if (MENU_DEV_AVAILABLE)
			{
				if (Button_PressedDebounced(BUTTON_SELECT))
				{
					Game_StateSet(GAME_DORMANT);
					uMenuState = MENU_DEV;
				}
			}
			break;
		}
		case MENU_INGAME :
		{
			if (Button_PressedDebounced(BUTTON_START))
			{
				Game_StateSet(GAME_INGAME);
				uMenuState = MENU_DORMANT;
			}

			if (Button_PressedDebounced(BUTTON_DOWN))
			{
				if (uMenuIGOption < MENU_IG_MAX-1)
				{
					uMenuIGOption++;
				}
			} 
			if (Button_PressedDebounced(BUTTON_UP))
			{
				if (uMenuIGOption > 0)
				{
					uMenuIGOption--;
				}
			} 

			if (Button_Pressed(BUTTON_A))
			{
				switch (uMenuIGOption)
				{
					case MENU_IG_RESTART:
					{
						Game_StateSet(GAME_INGAME_INIT);
			            uMenuState=MENU_DORMANT;
						break;
					}
					case MENU_IG_QUIT:
					{
						Game_StateSet(GAME_EXIT);
			            uMenuState=MENU_PRE_GAME_INIT;
						break;
					}
				}
			}
			break;
		}
		case MENU_DEV :
		{
			if (Button_PressedDebounced(BUTTON_SELECT))
			{
				Game_StateSet(GAME_INGAME);
				uMenuState = MENU_DORMANT;
			}

			if (Button_PressedDebounced(BUTTON_DOWN))
			{
				if (uMenuDevOption < MENU_DEV_MAX-1)
				{
					uMenuDevOption++;
				}
			} 
			if (Button_PressedDebounced(BUTTON_UP))
			{
				if (uMenuDevOption > 0)
				{
					uMenuDevOption--;
				}
			} 

			if (Button_Pressed(BUTTON_A))
			{
				switch (uMenuDevOption)
				{
					case MENU_DEV_RESET:
					{
						Interrupt_HWReset();
						break;
					}
				}
			}
			break;
		}
	}
}


//------------------------------------------------------------------------------------

void	Menu_Render(void)
{
	char	szMessage[STRING_LEN_MAX];

    switch(uMenuState)
	{
		case MENU_DORMANT :
		{
			break;
		}
		case MENU_PRE_GAME_INIT:
		{
			Background_FlipBufferWrite(BACKGROUND_MAP);
			Background_SetAll(BACKGROUND_MAP, GFX_EARTH);
			Background_FlipBufferView(BACKGROUND_MAP);
			break;
		}
		case MENU_PRE_GAME :
		{
		    Background_TextPrint(BACKGROUND_TEXT, 7,2, 	"Sokoban Advanced");
		    Background_TextPrint(BACKGROUND_TEXT, 7,3, 	"----------------");
			if (VBlank_TimerMature(&uMenuInfoTimer))
			{
			    Background_TextPrint(BACKGROUND_TEXT, 8,18, 	"Start to Play");
			}
			else
			{
			    Background_TextPrint(BACKGROUND_TEXT, 5,18, 	MENU_INFO_STRING);
			}


			dsprintf(szMessage,	"Level %d", uMenuLevel + 1);
		    Background_TextPrint(BACKGROUND_TEXT, 11,10,	szMessage);
			if (Map_Done(uMenuLevel))
			{
		    	Background_TextPrint(BACKGROUND_TEXT, 5 ,10, "Done");
		    	Background_TextPrint(BACKGROUND_TEXT, 21 ,10, "Done");
			}

			break;
		}
		case MENU_INGAME :
		{
		    Background_TextPrint(BACKGROUND_TEXT, 12,7, 	"Paused");
		    Background_TextPrint(BACKGROUND_TEXT, 12,8, 	"------");
		    Background_TextPrint(BACKGROUND_TEXT, 12,10, 	"Restart");
		    Background_TextPrint(BACKGROUND_TEXT, 12,11, 	" Quit");

		    Background_TextPrint(BACKGROUND_TEXT, 10, 10 + uMenuIGOption, ">");

			break;
		}
		case MENU_DEV :
		{
		    Background_TextPrint(BACKGROUND_TEXT, 9,7, 	"Development");
		    Background_TextPrint(BACKGROUND_TEXT, 9,8, 	"-----------");
		    Background_TextPrint(BACKGROUND_TEXT, 9,10, 	"HW Reset");

		    Background_TextPrint(BACKGROUND_TEXT, 7, 10 + uMenuDevOption, ">");

			break;
		}
	}
}

//------------------------------------------------------------------------------------

unsigned int	Menu_LevelGet(void)
{
	return(uMenuLevel);
}

//------------------------------------------------------------------------------------

void			Menu_LevelIncrement(void)
{
	if (uMenuLevel < uMenuLevelMax)
	{
		uMenuLevel++;
	}
}

//------------------------------------------------------------------------------------
