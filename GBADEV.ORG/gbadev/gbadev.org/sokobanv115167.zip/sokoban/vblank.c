//------------------------------------------------------------------------------------

// vblank
// Rich Heasman April 2002

//------------------------------------------------------------------------------------

#include "mygba.h"
#include "vblank.h"

#include "interrupt.h"

// Todo:
//	overflows int timer not dealt with

//------------------------------------------------------------------------------------

volatile	u32		uFrameCounter;

//------------------------------------------------------------------------------------

void	VBlank_Init(void)
{
	uFrameCounter = 0;
    Interrupt_HandlerSet(INT_TYPE_VBL, VBlank_Handler);

    // Turn the VBL interrupt on in DISPCNT and INTENA
    M_DISSTAT_VBLIRQR_ON
    M_INTENA_VBL_ENABLE
}

//------------------------------------------------------------------------------------

// VBL IRQ handler : is invoked by the system on every VBLIRQ

void 	VBlank_Handler(void)
{
	uFrameCounter++;
}

//------------------------------------------------------------------------------------

void 	VBlank_Wait(void)
{
	u32	uFrameCounterPrevious;

	uFrameCounterPrevious =	uFrameCounter;
	while (	uFrameCounterPrevious == uFrameCounter);
}

//------------------------------------------------------------------------------------

u32 	VBlank_FrameCounterGet(void)
{
	return(uFrameCounter);
}

//------------------------------------------------------------------------------------

void	VBlank_TimerSet(u32 *uTimer, u32 uLength)
{
	*uTimer = (uFrameCounter + uLength);
}

//------------------------------------------------------------------------------------

BOOL	VBlank_TimerMature(u32 *uTimer)
{
	BOOL	boMature;

	boMature = FALSE;
	if (uFrameCounter >= *uTimer)
	{
		boMature = TRUE;
	}

	return(boMature);
}

//------------------------------------------------------------------------------------
