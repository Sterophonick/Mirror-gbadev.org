//------------------------------------------------------------------------------------

// profile
// Rich Heasman April 2002

//------------------------------------------------------------------------------------

#include	"mygba.h"
#include	"profile.h"

#include	"gfx.h"
#include	"dsprintf.h"
#include	"vblank.h"
#include	"button.h"
#include	"background.h"

#define	PROFILE_LIST_ENABLED			FALSE
#define	PROFILE_TOTAL_ENABLED			FALSE

#define	PROFILE_MARK_MAX			10

#define	PROFILE_HBL_PER_FRAME		227			// horizontal blanks per frame
#define	PROFILE_HBL_FOR_VBLANK 		160			// line at which vblank occurs

typedef struct
{
	char	*szMessage;
	u32		uFrameTime;
} PROFILE_MARK;

static	PROFILE_MARK	ProfileMark[PROFILE_MARK_MAX+1];

static	int	nProfileMarkCount;

//------------------------------------------------------------------------------------

void	Profile_Init(void)
{
	nProfileMarkCount = 0;
}

//------------------------------------------------------------------------------------

// renders and restarts profile for next frame

void	Profile_Render(void)
{
	int		nLoop;
	char	szMessage[STRING_LEN_MAX];
	u32		uFrameTimeLast;
	int		nFramePercentage;

	uFrameTimeLast = ProfileMark[0].uFrameTime;
	if (PROFILE_LIST_ENABLED)
	{
		for (nLoop = 1; nLoop < nProfileMarkCount; nLoop++)
		{
			nFramePercentage = ProfileMark[nLoop].uFrameTime - uFrameTimeLast;
			nFramePercentage = (nFramePercentage * 100)/PROFILE_HBL_PER_FRAME;
			dsprintf(szMessage,	"%s %d%%", ProfileMark[nLoop].szMessage, nFramePercentage);
		    Background_TextPrint(BACKGROUND_TEXT, 12, 17 - nProfileMarkCount + nLoop, szMessage);
			uFrameTimeLast = ProfileMark[nLoop].uFrameTime;
		}
	}

	Profile_Mark("Frame Time");
	if (PROFILE_LIST_ENABLED)
	{
		nFramePercentage = ProfileMark[nProfileMarkCount-1].uFrameTime - ProfileMark[nProfileMarkCount-2].uFrameTime;
		nFramePercentage = (nFramePercentage * 100)/PROFILE_HBL_PER_FRAME;
		dsprintf(szMessage,	"%s %d%%", "Profile", nFramePercentage);
	    Background_TextPrint(BACKGROUND_TEXT, 12, 17, szMessage);
	}

	if (PROFILE_TOTAL_ENABLED)
	{
		nFramePercentage = ProfileMark[nProfileMarkCount-1].uFrameTime - ProfileMark[0].uFrameTime;
		nFramePercentage = (nFramePercentage * 100)/PROFILE_HBL_PER_FRAME;
		dsprintf(szMessage,	"%s %d%%", ProfileMark[nProfileMarkCount-1].szMessage, nFramePercentage);
	    Background_TextPrint(BACKGROUND_TEXT, 12, 19, szMessage);
	}

	nProfileMarkCount = 0;
}

//------------------------------------------------------------------------------------


void	Profile_Point(char *szMessage)
{
	if (nProfileMarkCount < PROFILE_MARK_MAX)
	{
		Profile_Mark(szMessage);
	}
}

//------------------------------------------------------------------------------------

void	Profile_Mark(char *szMessage)
{
	u32	uFrameTime;
	u32 uScanLine;

	ProfileMark[nProfileMarkCount].szMessage = szMessage;
	uFrameTime = VBlank_FrameCounterGet() * PROFILE_HBL_PER_FRAME;
	uScanLine = F_VCNT_CURRENT_SCANLINE;
	uFrameTime += uScanLine;
	if (uScanLine >= PROFILE_HBL_FOR_VBLANK)
	{
		uFrameTime -= PROFILE_HBL_PER_FRAME;
	}
	ProfileMark[nProfileMarkCount].uFrameTime = uFrameTime;
	nProfileMarkCount++;
}

//------------------------------------------------------------------------------------

