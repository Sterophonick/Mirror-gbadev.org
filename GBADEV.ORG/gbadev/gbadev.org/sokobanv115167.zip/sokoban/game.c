//------------------------------------------------------------------------------------

// Game
// Rich Heasman April 2002

//------------------------------------------------------------------------------------

#include "mygba.h"
#include "game.h"

#include "map.h"
#include "menu.h"
#include "gfx.h"
#include "gfxdata1.h"
#include "button.h"
#include "vblank.h"
#include "dsprintf.h"
#include "background.h"

//------------------------------------------------------------------------------------

static	unsigned int		uGameState;

static	BOOL				boGameManWaiting;
static	unsigned int		uGameManControlTimer;
static	const unsigned int	uGameManControlDelay = 6;

static	unsigned int		uGameDoneTimer;
static	const unsigned int	uGameDoneWaitLen = 80;

static	BOOL				boGameStartMessageDisplay;
static	unsigned int		uGameStartMessageTimer;
static	const unsigned int	uGameStartMessageLen = 80;

//------------------------------------------------------------------------------------

void	Game_Init(void)
{
	Map_Init();

	boGameStartMessageDisplay = FALSE;
	uGameState = GAME_DORMANT;
	boGameManWaiting = FALSE;
}

//------------------------------------------------------------------------------------

void	Game_Update(void)
{
	int	nDeltaX;
	int	nDeltaY;
	int	nMoveType;

    switch(uGameState)
    {
        case GAME_DORMANT:
		{
            break;
		}
		case GAME_INGAME_PRE_INIT:
		{
			uGameState=GAME_INGAME_INIT;
            break;
		}
        case GAME_INGAME_INIT:
		{
			Map_Begin(Menu_LevelGet());
			Map_ScrollInit();
			boGameStartMessageDisplay = TRUE;
        	VBlank_TimerSet(&uGameStartMessageTimer, uGameStartMessageLen);
			uGameState=GAME_INGAME_GFX_INIT;
            break;
		}
        case GAME_INGAME_GFX_INIT:
		{
			uGameState=GAME_INGAME;
            break;
		}
        case GAME_INGAME:
		{
			nDeltaX = 0;
			nDeltaY = 0;

			if (Button_Pressed(BUTTON_UP)) 		nDeltaY = -1;
			if (Button_Pressed(BUTTON_DOWN)) 	nDeltaY = 1;
			if (Button_Pressed(BUTTON_LEFT)) 	nDeltaX = -1;
			if (Button_Pressed(BUTTON_RIGHT))	nDeltaX = 1;

			// don't allow diagonals
			if (nDeltaX != 0)	nDeltaY = 0; 

			Map_ManUpdate(nDeltaX, nDeltaY);

			if (!boGameManWaiting)
			{
				if (nDeltaX != 0 || nDeltaY != 0)
				{
					nMoveType = Map_ManCanMove(nDeltaX, nDeltaY);	
					if (nMoveType != MAP_MAN_CANNOT_MOVE)
					{
						Map_ManMove(nDeltaX, nDeltaY);
			        	VBlank_TimerSet(&uGameManControlTimer, uGameManControlDelay);
						boGameManWaiting = TRUE;

						if (nMoveType == MAP_MAN_PUSH_HOME)
						{
							if (Map_Finished())
							{
								Map_MarkAsDone(Menu_LevelGet());
								uGameState=GAME_DONE_INIT;
							}
						}
					}
				}
				else
				{
					if (Button_Pressed(BUTTON_B))
					{
						Map_UndoMove();
			        	VBlank_TimerSet(&uGameManControlTimer, uGameManControlDelay);
						boGameManWaiting = TRUE;
					}
				}
			}
			else	// waiting for move pause to expire
			{
				if (VBlank_TimerMature(&uGameManControlTimer))
				{
					boGameManWaiting = FALSE;
				}
			}

			if (boGameStartMessageDisplay)
			{
				if (VBlank_TimerMature(&uGameStartMessageTimer))
				{
					boGameStartMessageDisplay = FALSE;
				}
			}

            break;
		}
		case GAME_DONE_INIT:
		{
		   	VBlank_TimerSet(&uGameDoneTimer, uGameDoneWaitLen);
			uGameState=GAME_DONE_WAIT;
            break;
		}
		case GAME_DONE_WAIT:
		{
			if (VBlank_TimerMature(&uGameDoneTimer))
			{
				Menu_LevelIncrement();
				uGameState=GAME_INGAME_INIT;
			}
            break;
		}
		case GAME_EXIT:
		{
			Map_Exit();
			uGameState=GAME_DORMANT;
            break;
		}
    }
}

//------------------------------------------------------------------------------------

void	Game_Render(void)
{
	char	szMessage[STRING_LEN_MAX];

    switch(uGameState)
    {
        case GAME_DORMANT:
		{
            break;
		}
        case GAME_INGAME_PRE_INIT:
		{
			break;
		}
        case GAME_INGAME_INIT:
		{
			Background_FlipBufferWrite(BACKGROUND_MAP);
			Background_SetAll(BACKGROUND_MAP, GFX_BLANK);
			Background_FlipBufferView(BACKGROUND_MAP);
			break;
		}
        case GAME_INGAME_GFX_INIT:
		{
			Background_FlipBufferWrite(BACKGROUND_MAP);
			Map_DrawAll();
			Background_FlipBufferView(BACKGROUND_MAP);
			break;
		}
        case GAME_INGAME:
		case GAME_DONE_INIT:
		{
			Map_Scroll();
			Map_Render();

			if (boGameStartMessageDisplay)
			{
			    Background_TextPrint(BACKGROUND_TEXT, 10,2, "Entering");
				dsprintf(szMessage,	"Level %d", Menu_LevelGet() + 1);
			    Background_TextPrint(BACKGROUND_TEXT, 10,3, szMessage);
			}
            break;
		}
		case GAME_DONE_WAIT:
		{
			Map_Scroll();
			Map_Render();

		    Background_TextPrint(BACKGROUND_TEXT, 10,2, "Hurrah");
			dsprintf(szMessage,	"Level %d ", Menu_LevelGet() + 1);
		    Background_TextPrint(BACKGROUND_TEXT, 10,3, szMessage);
		    Background_TextPrint(BACKGROUND_TEXT, 10,4, "Complete");
			break;
		}
		case GAME_EXIT:
		{
			break;
		}
    }
}

//------------------------------------------------------------------------------------

void	Game_StateSet(unsigned int uState)
{
	uGameState = uState;
}

//------------------------------------------------------------------------------------

unsigned int	Game_StateGet(void)
{
	return(uGameState);
}

//------------------------------------------------------------------------------------
