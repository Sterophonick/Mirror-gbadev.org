//------------------------------------------------------------------------------------

// background
// Rich Heasman May 2002

//------------------------------------------------------------------------------------

#include "mygba.h"
#include "background.h"

#include "gfxdata1.h"
#include "vblank.h"
#include "profile.h"
#include "sprite.h"

//------------------------------------------------------------------------------------

static	BACKGROUND_TYPE		Background[BACKGROUND_NUM_MAX];

static	const unsigned int uBackground_MapLength[4] = { 1024, 2048, 2048, 4096 };

//------------------------------------------------------------------------------------

void	Background_Init(void)
{
	memset(MEM_BG_MODE0_PTR,0x00,MEM_BG_SIZE);	// clear background memory
									   
	M_DISCNT_BGMODE_SET(0)						// set background display mode

	// set up backgrounds
	Background_LoadVram();

	// text layer
	Background[BACKGROUND_TEXT].uPriority = 0;		// on top
	Background[BACKGROUND_TEXT].uCbb = 0;
	Background[BACKGROUND_TEXT].uSbbBase = 10;
	Background[BACKGROUND_TEXT].uColmode = 1;
	Background[BACKGROUND_TEXT].uMapsize = C_BGXCNT_SCRSIZE_256X256;
	Background_Setup(BACKGROUND_TEXT);
	Background_FlipBufferWrite(BACKGROUND_TEXT);			// get buffers out of sync

	// main tile layer
	Background[BACKGROUND_MAP].uPriority = 1;
	Background[BACKGROUND_MAP].uCbb = 0;
	Background[BACKGROUND_MAP].uSbbBase = 12;
	Background[BACKGROUND_MAP].uColmode = 1;
	Background[BACKGROUND_MAP].uMapsize = C_BGXCNT_SCRSIZE_512X512;
	Background_Setup(BACKGROUND_MAP);
}

//------------------------------------------------------------------------------------

void 	Background_Setup(int nBackground)
{
	BACKGROUND_TYPE	*pBg;

	pBg = &Background[nBackground];

	pBg->uActive = 1;
	pBg->uMosaic = 0;
	pBg->uMapLength = uBackground_MapLength[pBg->uMapsize];

	pBg->uBufferView = 0;
	pBg->uBufferWrite = 0;
	pBg->uSbb =	pBg->uSbbBase;
	pBg->boFlipView = FALSE;

    M_DISCNT_BGX_SET(nBackground, pBg->uActive)
    M_BGXCNT_PRIO_SET(nBackground, pBg->uPriority)
    M_BGXCNT_CHRBB_SET(nBackground, pBg->uCbb)
    M_BGXCNT_SCRBB_SET(nBackground, pBg->uSbbBase)
    M_BGXCNT_COLMODE_SET(nBackground, pBg->uColmode)
    M_BGXCNT_SCRSIZE_SET(nBackground, pBg->uMapsize)
    M_BGXCNT_MOSAIC_SET(nBackground, pBg->uMosaic)
}

//------------------------------------------------------------------------------------ 

void	Background_Update(int nBackground)
{
	BACKGROUND_TYPE	*pBg;
	u32			uSbb;

	pBg = &Background[nBackground];

	R_BGXSCRLX(nBackground) = pBg->nScrollX;
	R_BGXSCRLY(nBackground) = pBg->nScrollY;

	if (pBg->boFlipView)
	{
	    pBg->uBufferView = 1 - pBg->uBufferView;
		uSbb = pBg->uSbbBase + (pBg->uMapLength>>10) * pBg->uBufferView;
	    M_BGXCNT_SCRBB_SET(nBackground, uSbb);
		pBg->boFlipView = FALSE;
	}
}

//------------------------------------------------------------------------------------ 

void 	Background_FlipBufferWrite(int nBackground)
{
	BACKGROUND_TYPE	*pBg;

	pBg = &Background[nBackground];

    pBg->uBufferWrite = 1 - pBg->uBufferWrite;
	pBg->uSbb = pBg->uSbbBase + (pBg->uMapLength>>10) * pBg->uBufferWrite;
}

//------------------------------------------------------------------------------------ 

void 	Background_FlipBufferView(int nBackground)
{
	BACKGROUND_TYPE	*pBg;

	pBg = &Background[nBackground];
	pBg->boFlipView = TRUE;
}

//------------------------------------------------------------------------------------ 

void	Background_SetAll(int nBackground, u16 nTileIndex)
{
	BACKGROUND_TYPE	*pBg;
	u32 		uCount;
	u16			*pDest;

	pBg = &Background[nBackground];
	pDest = MEM_SCR_BB_PTR(pBg->uSbb);
	uCount = (pBg->uMapLength);
	while (uCount > 0)
	{
		*pDest++ = (u16) nTileIndex;
		uCount--;
	}
}

//------------------------------------------------------------------------------------ 

void	Background_SetScreen(int nBackground, u16 nTileIndex)
{
	BACKGROUND_TYPE	*pBg;
	u32 		uCount;
	u16			*pDest;

	pBg = &Background[nBackground];
	pDest = MEM_SCR_BB_PTR(pBg->uSbb);
	uCount = 32*20;
	while (uCount > 0)
	{
		*pDest++ = (u16) nTileIndex;
		uCount--;
	}
}
//------------------------------------------------------------------------------------ 

u16		*Background_SbbPtrGet(int nBackground)
{
	BACKGROUND_TYPE	*pBg;
	u16	   		*pDest;
	
	pBg = &Background[nBackground];
	pDest = MEM_SCR_BB_PTR(pBg->uSbb);

	return(pDest);
}

//------------------------------------------------------------------------------------ 

BACKGROUND_TYPE	*Background_PtrGet(int nBackground)
{
	BACKGROUND_TYPE	*pBg;
	
	pBg = &Background[nBackground];

	return(pBg);
}

//------------------------------------------------------------------------------------ 


void	Background_LoadVram(void)
{
    memcpy(MEM_PAL_BG_PTR, gfxdata1_Palette, GFXDATA1_PALETTE_SIZE);
	memset(MEM_PAL_BG_PTR, 0, 6);	// set transparent colour to black
    memcpy(MEM_CHR_BB_PTR(0), gfxdata1_Tiles, GFXDATA1_TILE_SIZE);
}

//------------------------------------------------------------------------------------ 

void	Background_TextPrint(int nBackground, int nXCo, int nYCo, char *szMessage)
{
	BACKGROUND_TYPE	*pBg;
	int	nIndex;
	u16	*pDest;

	pBg = &Background[nBackground];

	pDest = MEM_SCR_BB_PTR(pBg->uSbb) + (nYCo<<5) + nXCo;
	nIndex = 0;	
	while (szMessage[nIndex] != STRING_TERMINATOR)
	{
		*pDest++ = szMessage[nIndex] - GFX_TEXT_START_CHAR;
		nIndex++;
	}
}

//------------------------------------------------------------------------------------ 
