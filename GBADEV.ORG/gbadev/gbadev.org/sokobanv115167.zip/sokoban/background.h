//------------------------------------------------------------------------------------

// background
// Rich Heasman May 2002

//------------------------------------------------------------------------------------

#include	"agbtypes.h"

// background layers

enum
{
	BACKGROUND_TEXT,		
	BACKGROUND_MAP,

	BACKGROUND_NUM_MAX
};

//------------------------------------------------------------------------------------

typedef struct
{
    u32  	uActive;     			// tells if BG should be active (0=off)
    u32  	uPriority;    			// priority of BG screen (0=highest,3=lowest)
    u32  	uCbb;        			// character base block of this bg
    u32  	uBufferWrite;			// current buffer view 0/1
    u32  	uBufferView;			// current buffer write 0/1
    u32  	uSbbBase;      			// screen base block of this bg
    u32  	uSbb;   	   			// current screen base to write to
    u32  	uColmode;    			// color mode of this bg, 0=16 pals 1=1 pal
    u32  	uMapsize;    			// size of map data in x direction
    u32  	uMosaic;     			// mosaic stat (0=off)
	u32		uMapLength;				// map length in words
	int		nScrollX;				// scroll position
	int		nScrollY;				// scroll position
	BOOL	boFlipView;				// screen flip required this frame
} BACKGROUND_TYPE;

//------------------------------------------------------------------------------------

void			Background_Init(void);

void 			Background_Setup(int nBackground);
u16				*Background_SbbPtrGet(int nBackground);
BACKGROUND_TYPE	*Background_PtrGet(int nBackground);
void			Background_SetScreen(int nBackground, u16 nTileIndex);
void			Background_SetAll(int nBackground, u16 nTileIndex);

void			Background_Update(int nBackground);
void			Background_FlipBufferWrite(int nBackground);
void			Background_FlipBufferView(int nBackground);
void			Background_LoadVram(void);

void			Background_TextPrint(int nBackground, int nXCo, int nYCo, char *szMessage);

//------------------------------------------------------------------------------------
