// MapC.cpp : Defines the entry point for the console application.
//

#include	<stdio.h>
#include	<string.h>
#include	<stdlib.h>

//----------------------------------------------------------------------------

#define	STRING_LEN_MAX			256
#define	STRING_TERMINATOR		'\0'

//----------------------------------------------------------------------------

void	MapC_Init(int argc, char* argv[]);
void	MapC_Exit(void);
void	MapC_Read(void);
void	MapC_Write(void);
void	MapC_Test(void);

void	ErrorFatal(char *szMessage);

//----------------------------------------------------------------------------

char	szInFileName[STRING_LEN_MAX];
char	szOutFileName[STRING_LEN_MAX];

FILE	*pInFile;
FILE	*pOutFile;

bool	boMapCTest;

//----------------------------------------------------------------------------

#define	MAZE_X_MAX				20
#define	MAZE_Y_MAX				20
#define	MAZE_NUM_MAX			500

struct MazeStruct
{
	char	szLine[MAZE_Y_MAX][MAZE_X_MAX+1];	
};

typedef	struct MazeStruct MazeType;

MazeType	Maze[MAZE_NUM_MAX];
int			nMazeNum;

//----------------------------------------------------------------------------

int main(int argc, char* argv[])
{
	printf("MapC source-file : Convert sokoban map into C file\n");
	MapC_Init(argc, argv);

	if (boMapCTest)
	{
		MapC_Test();
	}
	else
	{
		MapC_Read();
		MapC_Write();
		MapC_Exit();
	}

	return 0;
}

//----------------------------------------------------------------------------

void	MapC_Init(int argc, char* argv[])
{
	int		nDotIndex;
	char	szMessage[STRING_LEN_MAX];

	boMapCTest = false;
	if (argc != 2)
	{
		ErrorFatal("Not enough params");
	}
	if (!strcmp(argv[1],"test"))
	{
		boMapCTest = true;
	}
	else // normal operation
	{
		strcpy(szInFileName, argv[1]);
		nDotIndex=strcspn(szInFileName,".");
		strncpy(szOutFileName, szInFileName, nDotIndex);
		szOutFileName[nDotIndex] = STRING_TERMINATOR;
		strcat(szOutFileName, ".c");

		pInFile = fopen(szInFileName, "rt");
		if (!pInFile)
		{
			sprintf(szMessage,"Can't open in-file %s", szInFileName);
			ErrorFatal(szMessage);
		}

		pOutFile = fopen(szOutFileName, "wt");
		if (!pOutFile)
		{
			sprintf(szMessage,"Can't open out-file %s", szOutFileName);
			ErrorFatal(szMessage);
		}
	}
}

//----------------------------------------------------------------------------

void	MapC_Exit(void)
{
	if (pInFile)
	{
		fclose(pInFile);
	}
	if (pOutFile)
	{
		fclose(pOutFile);
	}
}

//----------------------------------------------------------------------------

enum
{
	READ_SEARCHING,
	READ_MAZE,
	READ_DONE
};

void	MapC_Read(void)
{
	int		nState;
	int		nLine;
	char	szInLine[STRING_LEN_MAX];
	char	szMessage[STRING_LEN_MAX];
	
	nState = READ_SEARCHING;
	nMazeNum = 0;
	nLine = 0;
	while (nState != READ_DONE)
	{
		if (fgets(szInLine,STRING_LEN_MAX,pInFile) == NULL)
		{
			nState = READ_DONE;
		}
		else // not end
		{
			if (nState == READ_MAZE)
			{
				if (szInLine[0]=='>')
				{
					nState = READ_SEARCHING;
					nMazeNum++;
					if (nMazeNum >= MAZE_NUM_MAX)
					{
						sprintf(szMessage,"Number of mazes exceeded maximum of %d",MAZE_NUM_MAX);
						ErrorFatal(szMessage);
					}
				}
				else	// normal maze line
				{
					strncpy(Maze[nMazeNum].szLine[nLine], szInLine, MAZE_X_MAX);
					nLine++;
					if (nLine >= MAZE_Y_MAX)
					{
						sprintf(szMessage,"Too many lines on Maze %d",nMazeNum);
						ErrorFatal(szMessage);
					}
				}
			}

			if (nState == READ_SEARCHING)
			{
				if (szInLine[0]=='>')
				{
					nLine = 0;
					nState = READ_MAZE;
				}
			}
		}
	}
	printf("%d Mazes read\n",nMazeNum);
}

//----------------------------------------------------------------------------

void	MapC_Write(void)
{
	int				nMaze;
	int				nLine;
	int				nCol;
	int				nLen;
	char			*pLine;
	unsigned int	uSum;
	char			cThis;
	unsigned int	nCode;
	int				nCount;
	int				nXCo;
	int				nYCo;

	nMaze = 0;
	nXCo = -1;
	nYCo = -1;
	fprintf(pOutFile,"// Auto generated Maze data, created using MapC\n");
	fprintf(pOutFile,"unsigned int\tMazeData[%d][%d]={\n",nMazeNum, 27);
	while (nMaze < nMazeNum)
	{
		fprintf(pOutFile,"{");
		uSum = 0;
		nCount = 0;
		for (nLine=0; nLine<MAZE_Y_MAX; nLine++)
		{
			pLine = Maze[nMaze].szLine[nLine];
			nLen = strlen(pLine);
		
			for (nCol=0; nCol<MAZE_X_MAX; nCol++)
			{
				cThis = ' ';
				nCode = 0;
				if (nCol < nLen) cThis = pLine[nCol];
				if (cThis == ' ') nCode = 0;
				if (cThis == '#') nCode = 1;
				if (cThis == '$') nCode = 2;
				if (cThis == '.') nCode = 3;
				if (cThis == '@')
				{
					nXCo = nCol;
					nYCo = nLine;
				}
				uSum = uSum << 2;
				uSum += nCode;
				nCount++;
				if (nCount >= 16)
				{
					fprintf(pOutFile,"0x%x,",uSum);
					nCount = 0;
					uSum = 0;
				}
			}
		}
		if (nXCo == -1 || nYCo == -1)
		{
			ErrorFatal("No start position found\n");
		}
		fprintf(pOutFile,"%d,%d",nXCo,nYCo);
		fprintf(pOutFile,"}");
		if (nMaze < nMazeNum-1)
		{
			fprintf(pOutFile,",");
		}
		fprintf(pOutFile,"\n");
		nMaze++;
	} 
	fprintf(pOutFile,"};\n");
	printf("Written out file\n");
}
 
//----------------------------------------------------------------------------

extern unsigned int	MazeData[][27];

void	MapC_Test(void)
{
	int				nMaze;
	int				nLine;
	int				nCol;
	unsigned int	uSum;
	char			szLine[STRING_LEN_MAX];
	char			cThis;
	unsigned int	nCode;
	int				nCount;
	int				nIndex;
	int				nXCo;
	int				nYCo;
	unsigned int	*pData;

	nMaze = 0;
	szLine[MAZE_X_MAX] = STRING_TERMINATOR;

	pData = &MazeData[nMaze][0];
	nCount = 0; 
	for (nLine=0; nLine<MAZE_Y_MAX; nLine++)
	{
		nIndex = 0;
		for (nCol=0; nCol<MAZE_X_MAX; nCol++)
		{
			if (nCount == 0)
			{
				uSum = *pData++;
			}
			nCode = uSum >> 30;
			uSum = uSum << 2;
	
			cThis = '?';
			if (nCode == 0) cThis = ' ';
			if (nCode == 1) cThis = '*';
			if (nCode == 2) cThis = 'o';
			if (nCode == 3) cThis = 'H';
			szLine[nIndex] = cThis;

			nIndex++;
			nCount = (nCount + 1) % 16;
		}
		printf("<%s>\n",szLine);
	} 
	nXCo = *pData++;
	nYCo = *pData++;
	printf("Start at %d %d\n",nXCo,nYCo);
}

//----------------------------------------------------------------------------

void	ErrorFatal(char *szMessage)
{
	printf(szMessage);
	printf("\n");
	MapC_Exit();
	exit(-1);
}

//----------------------------------------------------------------------------
