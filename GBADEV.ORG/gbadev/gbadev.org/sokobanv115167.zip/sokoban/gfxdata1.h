//------------------------------------------------------------------------------------

// graphics data

//------------------------------------------------------------------------------------

#include "mygba.h"

//------------------------------------------------------------------------------------

#define	GFX_TEXT_START_CHAR		' '	// start character in font

// tiles description (0 - 90 = text, starting at ' ')

enum
{
	GFX_BLOCK 			= 92,
	GFX_BOULDER 		= GFX_BLOCK + 4,
	GFX_EARTH	 		= GFX_BOULDER + 4,
	GFX_BLANK 			= GFX_EARTH + 4,
	GFX_BOULDER_HOME 	= GFX_BLANK + 4,
	GFX_HOME 			= GFX_BOULDER_HOME + 4
};
//------------------------------------------------------------------------------------

#define	GFXDATA1_TILE_SIZE			(120 * 8 * 8)
#define	GFXDATA1_PALETTE_SIZE		(512)

extern	const u8 gfxdata1_Palette[GFXDATA1_PALETTE_SIZE];
extern	const u8 gfxdata1_Tiles[GFXDATA1_TILE_SIZE];

//------------------------------------------------------------------------------------
