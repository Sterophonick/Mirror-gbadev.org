//------------------------------------------------------------------------------------

// button
// Rich Heasman April 2002

//------------------------------------------------------------------------------------

#include	"agbtypes.h"

enum
{
	BUTTON_A,
	BUTTON_B,
	BUTTON_SELECT,
	BUTTON_START,
	BUTTON_RIGHT,
	BUTTON_LEFT,
	BUTTON_UP,
	BUTTON_DOWN,
	BUTTON_R,
	BUTTON_L
};

//------------------------------------------------------------------------------------

void	Button_Init(void);
void	Button_Update(void);
BOOL	Button_Pressed(int nButton);
BOOL	Button_PressedDebounced(int nButton);

//------------------------------------------------------------------------------------
