//------------------------------------------------------------------------------------

// agbtypes

//------------------------------------------------------------------------------------

#ifndef _AGBTYPES_H
#define _AGBTYPES_H

typedef     unsigned char           u8;
typedef     unsigned short int      u16;
typedef     unsigned int            u32;
typedef     unsigned long long int  u64;

typedef     unsigned int            uint;
typedef     unsigned char           uchar;
typedef		unsigned int			BOOL;

// boolean defines

#define TRUE 1
#define FALSE 0


// string defs

#define	STRING_LEN_MAX		64
#define	STRING_TERMINATOR	'\0'

#endif // _AGBTYPES

//------------------------------------------------------------------------------------
