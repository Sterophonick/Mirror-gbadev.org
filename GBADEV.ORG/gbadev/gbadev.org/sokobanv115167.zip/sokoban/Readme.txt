
---------------------------

Sokoban Advanced 
----------------

v1.1 : 6 May 2002 	: Bug fix > 300 Undos, changed to gfx2gba, man now sprite, info added
v1.0 : 30 April 2002	: First issue

A demo by Rich Heasman (richardheasman@hotmail.com)

What? 	Push all the boulders home
How? 	Move - Dpad; B - Undo; Start - Pause menu

---------------------------

Thanks to:

Paul Connell            : for getting me started
tubooboo                : for HAM (v1.40)
Jeff Frohwein           : for MultiBoot, crt0, lnkscript
Gollum                  : for BoycottAdvance
Markus                  : for Gfx2Gba
Linus Torvalds          : for sprintf
gbadev.org              : for various info
Tom Happ                : for Cowbite spec

Bjorn Kallmark          : for level compilation
Jack Duthen             : for level design
Phil Shapiro            : for level design
Yoshio Murase           : for level design
J Franklin Mentzer      : for level design
Joseph L Traub          : for level design
Thinking Rabbit         : for level design

VICE team               : for VICE c64 emulation
cia.c64.org             : for c64 bins
First Star Software     : for Boulder Dash Graphics

Additional thanks to:
Jesder, Tom St Denis

---------------------------




