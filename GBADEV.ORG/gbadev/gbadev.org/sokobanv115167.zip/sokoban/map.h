//----------------------------------------------------------------------------

// map
// Rich Heasman April 2002

//----------------------------------------------------------------------------

#include	"agbtypes.h"

enum
{
	MAP_MAN_CANNOT_MOVE,
	MAP_MAN_STANDARD_MOVE,
	MAP_MAN_PUSH,
	MAP_MAN_PUSH_FROM_HOME,
	MAP_MAN_PUSH_HOME,
	MAP_MAN_PUSH_FROM_HOME_TO_HOME,

	MAP_MAN_INVALID_MOVE
};

void			Map_Init(void);
void			Map_Begin(unsigned int nLevel);
unsigned int	Map_NumLevelsGet(void);
void			Map_Exit(void);

void			Map_Render(void);
void			Map_ManRender(void);
void			Map_ManUpdate(int nDeltaX, int nDeltaY);
void			Map_DrawAll(void);
void 			Map_TileDraw(int nXCo, int nYCo, int nTileIndex);

void			Map_ScrollInit(void);
void 			Map_Scroll(void);

int				Map_ManCanMove(int nDeltaX, int nDeltaY);
void			Map_ManMove(int nDeltaX, int nDeltaY);
BOOL			Map_Finished(void);
void			Map_MarkAsDone(int nMap);
BOOL			Map_Done(int nMap);

void			Map_UndoMove(void);

//----------------------------------------------------------------------------
