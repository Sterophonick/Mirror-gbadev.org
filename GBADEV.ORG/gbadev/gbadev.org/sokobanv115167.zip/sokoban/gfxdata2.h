//------------------------------------------------------------------------------------

// graphics data

//------------------------------------------------------------------------------------

#include "mygba.h"

//------------------------------------------------------------------------------------

enum
{
	GFX_MAN,
	GFX_MAN_BLINK1	= GFX_MAN + 2,
	GFX_MAN_BLINK2	= GFX_MAN_BLINK1 + 2,
	GFX_MAN_TAP1	= GFX_MAN_BLINK2 + 2,
	GFX_MAN_TAP2	= GFX_MAN_TAP1 + 2,
	GFX_MAN_LEFT1	= GFX_MAN_TAP2 + 2,
	GFX_MAN_LEFT2	= GFX_MAN_LEFT1 + 2,	
	GFX_MAN_LEFT3	= GFX_MAN_LEFT2	+ 2,
			
	GFX_MAN_LEFT4	= 32
};

//------------------------------------------------------------------------------------

#define	GFXDATA2_TILE_SIZE			(64 * 8 * 8)
#define	GFXDATA2_PALETTE_SIZE		(512)

extern	const u8 gfxdata2_Palette[GFXDATA2_PALETTE_SIZE];
extern	const u8 gfxdata2_Tiles[GFXDATA2_TILE_SIZE];

//------------------------------------------------------------------------------------
