//------------------------------------------------------------------------------------

// graphics 
// Rich Heasman April 2002

//------------------------------------------------------------------------------------

#include "mygba.h"
#include "gfx.h"

#include "gfxdata1.h"
#include "vblank.h"
#include "profile.h"
#include "sprite.h"
#include "background.h"

//------------------------------------------------------------------------------------

// VRAM Memory map : blocks x800 (slots 0 to 29)
// 0 - 4 		 : tiles
// 10,11 		 : front and back for bg 0
// 12-15, 16-19	 : 2 buffers for bg 1, only when changing whole screen

//------------------------------------------------------------------------------------

void	Gfx_Init(void)
{
	
	M_DISCNT_FRCBLK_ENA

    M_DISCNT_BG0_OFF							// turn everything off
    M_DISCNT_BG1_OFF
    M_DISCNT_BG2_OFF
    M_DISCNT_BG3_OFF
    M_MOSAIC_SET(0,0,0,0)

	Background_Init();
	Sprite_Init();

	M_DISCNT_FRCBLK_DIS
}

//------------------------------------------------------------------------------------

void	Gfx_Update(void)
{
	VBlank_Wait();
	Profile_Point("Post VBlank");

 	Background_FlipBufferView(BACKGROUND_TEXT);		// always flip text
	Background_Update(BACKGROUND_TEXT);
	Background_FlipBufferWrite(BACKGROUND_TEXT);
	Background_Update(BACKGROUND_MAP);

	Sprite_Update();
}

//------------------------------------------------------------------------------------
