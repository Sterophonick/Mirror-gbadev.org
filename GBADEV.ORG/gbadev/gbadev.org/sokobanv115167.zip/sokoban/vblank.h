//------------------------------------------------------------------------------------

// vblank
// Rich Heasman April 2002

//------------------------------------------------------------------------------------

#include	"agbtypes.h"

void	VBlank_Init(void);
void 	VBlank_Handler(void);
void 	VBlank_Wait(void);
u32 	VBlank_FrameCounterGet(void);
void	VBlank_TimerSet(u32 *uTimer, u32 uLength);
BOOL	VBlank_TimerMature(u32 *uTimer);

//------------------------------------------------------------------------------------
