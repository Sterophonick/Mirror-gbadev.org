//----------------------------------------------------------------------------

// map
// Rich Heasman April 2002

//----------------------------------------------------------------------------

#include 	"mygba.h"
#include	"map.h"

#include	"mapdata.h"
#include	"gfx.h"
#include	"gfxdata1.h"
#include	"gfxdata2.h"
#include 	"rnd.h"
#include 	"sprite.h"
#include 	"background.h"

//----------------------------------------------------------------------------

#define	MAP_X_MAX				20
#define	MAP_Y_MAX				20

// map types
enum
{
	MAP_BLANK,				
	MAP_BLOCK,				
	MAP_BOULDER,			
	MAP_HOME,				
	MAP_BOULDER_HOME,		

	MAP_TYPES_MAX
};

char				cMap[MAP_Y_MAX][MAP_X_MAX];

static const int	nMapDataNumMax = 452;
static	BOOL		boMapDone[452];

//----------------------------------------------------------------------------

typedef struct
{
	int		nDeltaX;
	int		nDeltaY;
	int		nMoveType;	
} MAP_UNDO;

#define	MAP_UNDO_MAX	1000

MAP_UNDO	Map_Undo[MAP_UNDO_MAX];
int			nMapUndo;

//----------------------------------------------------------------------------

enum 
{
	MAP_MAN,
	MAP_MAN_BLINK1,
	MAP_MAN_BLINK2,
	MAP_MAN_TAP1,
	MAP_MAN_TAP2,	
	MAP_MAN_LEFT1,	
	MAP_MAN_LEFT2,	
	MAP_MAN_LEFT3,	
	MAP_MAN_LEFT4,	
	MAP_MAN_RIGHT1,
	MAP_MAN_RIGHT2,
	MAP_MAN_RIGHT3,
	MAP_MAN_RIGHT4,

	MAN_TYPES_MAX
};

#define	MAP_MAN_WALK_ANIMS	4

unsigned	int	nMapManX;
unsigned	int	nMapManY;

unsigned	int	nMapManGfxCount;
unsigned	int	nMapManTimer;

BOOL  	boMapRenderUpdate;

int		nMapManDeltaX;	 		// man moved deltas
int		nMapManDeltaY;

int		nMapManRequestX;		// man request deltas (for gfx)
int		nMapManRequestY;
int		nMapManRequestPrevX;
int		nMapManRequestPrevY;

int		nMapManLastDirection;
int		nMapManSpecial;

//----------------------------------------------------------------------------

const u16	Map_Graphic[MAP_TYPES_MAX] = 
{
	GFX_BLANK, 
	GFX_BLOCK, 
	GFX_BOULDER, 
	GFX_HOME, 
	GFX_BOULDER_HOME
};

const int 	nMapScreenMidX = GFX_SCREEN_WIDTH/2;
const int 	nMapScreenMidY = GFX_SCREEN_HEIGHT/2;
const int 	nMapCentreRate = 1;

unsigned	int	nMapPixelMinX;				// extremes of map
unsigned	int	nMapPixelMaxX;
unsigned	int	nMapPixelMinY;
unsigned	int	nMapPixelMaxY;

//----------------------------------------------------------------------------

const u16	Man_Graphic[MAN_TYPES_MAX] = 
{
	GFX_MAN,			//	MAP_MAN,
	GFX_MAN_BLINK1,		//	MAP_MAN_BLINK1,
	GFX_MAN_BLINK2,		//	MAP_MAN_BLINK2,
	GFX_MAN_TAP1,		//	MAP_MAN_TAP1,
	GFX_MAN_TAP2,		//	MAP_MAN_TAP2,	
	GFX_MAN_LEFT1,		//	MAP_MAN_LEFT1,	
	GFX_MAN_LEFT2,		//	MAP_MAN_LEFT2,	
	GFX_MAN_LEFT3,		//	MAP_MAN_LEFT3,	
	GFX_MAN_LEFT4,		//	MAP_MAN_LEFT4,	
	GFX_MAN_LEFT1,		//	MAP_MAN_RIGHT1,
	GFX_MAN_LEFT2,		//	MAP_MAN_RIGHT2,
	GFX_MAN_LEFT3,		//	MAP_MAN_RIGHT3,
	GFX_MAN_LEFT4		//	MAP_MAN_RIGHT4
};

//----------------------------------------------------------------------------

void			Map_Init(void)
{
	int				nMap;

	for (nMap = 0; nMap < nMapDataNumMax; nMap++)
	{
		boMapDone[nMap] = FALSE;
	}
}

//----------------------------------------------------------------------------

void			Map_Begin(unsigned int nLevel)
{
	int				nLine;
	int				nCol;
	unsigned int	uSum;
	unsigned int	*pData;
	char 			*pDest;
	unsigned int	nCode;
	int				nCount;
	int				nIndex;
	int				nMinX;
	int				nMaxX;
	int				nMinY;
	int				nMaxY;

	// load up map 

	pData = &MazeData[nLevel][0];
	pDest = &cMap[0][0];
	nCount = 0; 
	for (nLine=0; nLine<MAP_Y_MAX; nLine++)
	{
		nIndex = 0;
		for (nCol=0; nCol<MAP_X_MAX; nCol++)
		{
			if (nCount == 0)
			{
				uSum = *pData++;
			}
			nCode = uSum >> 30;
			uSum = uSum << 2;
			*pDest++ = (char) nCode;
			nIndex++;
			nCount = (nCount + 1) % 16;
		}
	} 
	nMapManX = *pData++;
	nMapManY = *pData++;

	// find edges for scrolling

	nMinX = MAP_X_MAX-1;
	nMaxX = 0;
	nMinY = MAP_Y_MAX-1;
	nMaxY = 0;
	for (nLine=0; nLine<MAP_Y_MAX; nLine++)
	{
		for (nCol=0; nCol<MAP_X_MAX; nCol++)
		{
			if (cMap[nLine][nCol] != MAP_BLANK)
			{
				if (nCol < nMinX) nMinX = nCol;
				if (nCol > nMaxX) nMaxX = nCol;
				if (nLine < nMinY) nMinY = nLine;
				if (nLine > nMaxY) nMaxY = nLine;
			}
		}
	} 
	nMapPixelMinX = nMinX * 8 * 2;
	nMapPixelMaxX = (nMaxX + 1) * 8 * 2;
	nMapPixelMinY = nMinY * 8 * 2;
	nMapPixelMaxY = (nMaxY + 1) * 8 * 2;

	// prepare man for first render

	nMapManDeltaX = 1;
	nMapManDeltaY = 0;
	nMapManRequestX = 0;
	nMapManRequestY = 0;
	nMapManGfxCount = 0;

	nMapManSpecial = MAP_MAN;
	nMapManLastDirection = MAP_MAN_LEFT1;
	boMapRenderUpdate = TRUE;

	nMapUndo = 0;
	Map_Undo[nMapUndo].nMoveType = MAP_MAN_INVALID_MOVE;
}

//----------------------------------------------------------------------------

void			Map_Exit(void)
{
	SPRITE_TYPE	*pSprite;

	pSprite = Sprite_PtrGet(SPRITE_MAN);
	pSprite->uX = GFX_SCREEN_WIDTH;
}	

//----------------------------------------------------------------------------

unsigned int	Map_NumLevelsGet(void)
{
	return(nMapDataNumMax);
}

//----------------------------------------------------------------------------

void			Map_Render(void)
{
	int	nTileIndex;
	int	nXCo;
	int	nYCo;

	if (boMapRenderUpdate)
	{
		// draw 2 behind man (in case of undo)
		nXCo = nMapManX - nMapManDeltaX - nMapManDeltaX;
		nYCo = nMapManY - nMapManDeltaY - nMapManDeltaY;
		nTileIndex = cMap[nYCo][nXCo];
		Map_TileDraw( nXCo, nYCo, nTileIndex);
		// draw behind man
		nXCo = nMapManX - nMapManDeltaX;
		nYCo = nMapManY - nMapManDeltaY;
		nTileIndex = cMap[nYCo][nXCo];
		Map_TileDraw( nXCo, nYCo, nTileIndex);
		// draw behind of man
		nXCo = nMapManX;
		nYCo = nMapManY;
		nTileIndex = cMap[nYCo][nXCo];
		Map_TileDraw( nXCo, nYCo, nTileIndex);
		// draw infront of man
		nXCo = nMapManX + nMapManDeltaX;
		nYCo = nMapManY + nMapManDeltaY;
		nTileIndex = cMap[nYCo][nXCo];
		Map_TileDraw( nXCo, nYCo, nTileIndex);

		boMapRenderUpdate = FALSE;
	}
	
	Map_ManRender();
}

//----------------------------------------------------------------------------

void			Map_ManRender(void)
{
	BACKGROUND_TYPE	*pBg;
	SPRITE_TYPE	*pSprite;
	uint		uHFlip;

	int		nTileIndex;
	int		nWalkCount;

	pSprite = Sprite_PtrGet(SPRITE_MAN);
	uHFlip = 0;

	if (nMapManRequestX == nMapManRequestPrevX && nMapManRequestY == nMapManRequestPrevY)
	{
		nMapManGfxCount++;
	}
	else
	{
		nMapManSpecial = MAP_MAN;
		nMapManGfxCount = 0;
	}

	nTileIndex = MAP_MAN;

	if (nMapManRequestX > 0) 	nTileIndex = MAP_MAN_RIGHT1;
	if (nMapManRequestX < 0) 	nTileIndex = MAP_MAN_LEFT1;
	if (nMapManRequestY > 0)	nTileIndex = nMapManLastDirection;
	if (nMapManRequestY < 0)	nTileIndex = nMapManLastDirection;

	if (nTileIndex != MAP_MAN)
	{
		nMapManLastDirection = nTileIndex;
		nWalkCount = (nMapManGfxCount % (MAP_MAN_WALK_ANIMS * 2))/2;

		// cycle the walk anim
		if (nWalkCount >= MAP_MAN_WALK_ANIMS) 
			nTileIndex += MAP_MAN_WALK_ANIMS*2 - 1 - nWalkCount;
		else
			nTileIndex += nWalkCount;
	}
	else // man not moving
	{
		if (nMapManSpecial == MAP_MAN)
		{
			nMapManGfxCount = 0;
			if (Rnd(100)<1)		nMapManSpecial = MAP_MAN_TAP1;
			if (Rnd(100)<1)		nMapManSpecial = MAP_MAN_BLINK1;
		}
		if (nMapManSpecial == MAP_MAN_BLINK1)
		{
			nTileIndex = MAP_MAN_BLINK1 + (nMapManGfxCount % 4) / 2;
			if ((nMapManGfxCount % 4) == 3)
			{
				nMapManSpecial = MAP_MAN;
			}
		}

		if (nMapManSpecial == MAP_MAN_TAP1)
		{
			nTileIndex = MAP_MAN_TAP1 + (nMapManGfxCount % 16) / 8;
			if (Rnd(100)<2) 
			{
				nMapManSpecial = MAP_MAN;
			}
		}
	}

	if (nTileIndex >= MAP_MAN_RIGHT1 && nTileIndex <= MAP_MAN_RIGHT4)
	{
		uHFlip = 1;
	}

	pBg = Background_PtrGet(BACKGROUND_MAP);
	pSprite->uX = nMapManX * 16 - pBg->nScrollX;
	pSprite->uY = nMapManY * 16 - pBg->nScrollY;
	pSprite->uHFlip = uHFlip;
	pSprite->uChar = Man_Graphic[nTileIndex];

	nMapManRequestPrevX = nMapManRequestX;
	nMapManRequestPrevY = nMapManRequestY;
}

//----------------------------------------------------------------------------

void			Map_ManUpdate(int nDeltaX, int nDeltaY)
{
	nMapManRequestX = nDeltaX;
	nMapManRequestY = nDeltaY;
}

//----------------------------------------------------------------------------

void			Map_DrawAll(void)
{
	int				nLine;
	int				nCol;
	u16				nTileIndex;

	for (nLine=0; nLine<MAP_Y_MAX; nLine++)
	{
		for (nCol=0; nCol<MAP_X_MAX; nCol++)
		{
			nTileIndex = cMap[nLine][nCol];
			Map_TileDraw(nCol, nLine, nTileIndex);
		}
	}
}

//----------------------------------------------------------------------------

void 			Map_TileDraw(int nXCo, int nYCo, int nTileIndex)
{
	u16				*pDestStart;
	int				nZone;
	u16				*pDest;
	u16				nGraphic;

	nXCo *= 2;
	nYCo *= 2;

	nZone = 0;
	if (nXCo >=32 ) nZone += 1;
	if (nYCo >=32 ) nZone += 2;
	nZone = nZone * 32 * 32;

	pDestStart = Background_SbbPtrGet(BACKGROUND_MAP);
	pDest = pDestStart + ((nYCo&31)<<5) + ((nXCo&31)) + (nZone);

	nGraphic = Map_Graphic[nTileIndex];
	*pDest = nGraphic;
	*(pDest+1) = nGraphic + 1;
	*(pDest+32) = nGraphic + 2;
	*(pDest+33) = nGraphic + 3;
}

//----------------------------------------------------------------------------

void			Map_ScrollInit(void)
{
	BACKGROUND_TYPE		*pBg;

	pBg = Background_PtrGet(BACKGROUND_MAP);

	pBg->nScrollX = (nMapPixelMaxX - nMapPixelMinX)/2 + nMapPixelMinX- nMapScreenMidX;
	pBg->nScrollY = (nMapPixelMaxY - nMapPixelMinY)/2 + nMapPixelMinY- nMapScreenMidY;
}

//----------------------------------------------------------------------------

void			Map_Scroll(void)
{
	BACKGROUND_TYPE	*pBg;
	int				nManPixelPosX;
	int				nManPixelPosY;

	pBg = Background_PtrGet(BACKGROUND_MAP);
	nManPixelPosX = nMapManX * 2 * 8 + 8 - pBg->nScrollX;
	nManPixelPosY = nMapManY * 2 * 8 + 8 - pBg->nScrollY;

	if ((nManPixelPosX > nMapScreenMidX + nMapCentreRate) 
	 && (GFX_SCREEN_WIDTH + pBg->nScrollX < nMapPixelMaxX))
	{
		pBg->nScrollX += nMapCentreRate;
	}

	if ((nManPixelPosX < nMapScreenMidX - nMapCentreRate) 
	 && (pBg->nScrollX > nMapPixelMinX))
	{
		pBg->nScrollX -= nMapCentreRate;
	}

	if ((nManPixelPosY > nMapScreenMidY + nMapCentreRate) 
	 && (GFX_SCREEN_HEIGHT + pBg->nScrollY < nMapPixelMaxY))
	{
		pBg->nScrollY += nMapCentreRate;
	}

	if ((nManPixelPosY < nMapScreenMidY - nMapCentreRate) 
	 && (pBg->nScrollY > nMapPixelMinY))
	{
		pBg->nScrollY -= nMapCentreRate;
	}
}

//----------------------------------------------------------------------------

int				Map_ManCanMove(int nDeltaX, int nDeltaY)
{
	int		nMoveType;
	char	cManTarget;
	char	cBoulderTarget;
	int		nManNewX;
	int		nManNewY;

	nManNewX = nMapManX + nDeltaX;
	nManNewY = nMapManY + nDeltaY;
	cManTarget = cMap[nManNewY][nManNewX];

	nMoveType = MAP_MAN_CANNOT_MOVE;

	if (cManTarget == MAP_BLANK || cManTarget == MAP_HOME)
	{
		nMoveType = MAP_MAN_STANDARD_MOVE;
	}

	if (cManTarget == MAP_BOULDER || cManTarget == MAP_BOULDER_HOME)
	{
		cBoulderTarget = cMap[nManNewY+nDeltaY][nManNewX+nDeltaX];
	
		if (cManTarget == MAP_BOULDER)
		{
			if (cBoulderTarget == MAP_BLANK) 	nMoveType = MAP_MAN_PUSH;
			if (cBoulderTarget == MAP_HOME) 	nMoveType = MAP_MAN_PUSH_HOME;
		}
		if (cManTarget == MAP_BOULDER_HOME)
		{
			if (cBoulderTarget == MAP_BLANK) 	nMoveType = MAP_MAN_PUSH_FROM_HOME;
			if (cBoulderTarget == MAP_HOME) 	nMoveType = MAP_MAN_PUSH_FROM_HOME_TO_HOME;
		}
	}

	return(nMoveType);
}

//----------------------------------------------------------------------------

void			Map_ManMove(int nDeltaX, int nDeltaY)
{
	int		nMoveType;
	int		nBoulderNewX;
	int		nBoulderNewY;
	char	cManTarget;
	char	cBoulderTarget;
	int		nNextUndo;

	nMoveType = Map_ManCanMove(nDeltaX, nDeltaY);
	if (nMoveType != MAP_MAN_CANNOT_MOVE)
	{
		nMapManX += nDeltaX;
		nMapManY += nDeltaY;

		if (nMoveType >= MAP_MAN_PUSH && nMoveType <= MAP_MAN_PUSH_FROM_HOME_TO_HOME)
		{
			nBoulderNewX = nMapManX + nDeltaX;
			nBoulderNewY = nMapManY + nDeltaY;

			if (nMoveType == MAP_MAN_PUSH)	
			{
				cManTarget = MAP_BLANK;	
				cBoulderTarget = MAP_BOULDER;
			}
			if (nMoveType == MAP_MAN_PUSH_HOME)
			{
				cManTarget = MAP_BLANK;
				cBoulderTarget = MAP_BOULDER_HOME;
			}
			if (nMoveType == MAP_MAN_PUSH_FROM_HOME)
			{
				cManTarget = MAP_HOME;
				cBoulderTarget = MAP_BOULDER;
			}
			if (nMoveType == MAP_MAN_PUSH_FROM_HOME_TO_HOME)
			{
				cManTarget = MAP_HOME;
				cBoulderTarget = MAP_BOULDER_HOME;
			}
			cMap[nMapManY][nMapManX] = cManTarget;
			cMap[nBoulderNewY][nBoulderNewX] = cBoulderTarget;
		}

		nMapManDeltaX = nDeltaX;
		nMapManDeltaY = nDeltaY;
		boMapRenderUpdate = TRUE;

		// store move for undo

		nMapUndo++;
		if (nMapUndo >= MAP_UNDO_MAX)
		{
			nMapUndo = 0;
		}
		Map_Undo[nMapUndo].nDeltaX = -nDeltaX;
		Map_Undo[nMapUndo].nDeltaY = -nDeltaY;
		Map_Undo[nMapUndo].nMoveType = nMoveType;

		nNextUndo = nMapUndo + 1;
		if (nNextUndo >= MAP_UNDO_MAX)
		{
			nNextUndo = 0;
		}
		Map_Undo[nNextUndo].nMoveType = MAP_MAN_INVALID_MOVE;
	}
}

//----------------------------------------------------------------------------

BOOL			Map_Finished(void)
{
	int			nLine;
	int			nCol;
	BOOL		boFinished;

	boFinished = TRUE;
	for (nLine=0; nLine<MAP_Y_MAX; nLine++)
	{
		for (nCol=0; nCol<MAP_X_MAX; nCol++)
		{
			if (cMap[nLine][nCol] == MAP_HOME)
			{
				boFinished = FALSE;	
			}
		}
	}

	return(boFinished);
}

//----------------------------------------------------------------------------

void			Map_UndoMove(void)
{
	int		nMoveType;
	int		nDeltaX;
	int		nDeltaY;
	int		nBoulderNewX;
	int		nBoulderNewY;
	char	cManTarget;
	char	cBoulderTarget;

	nMoveType = Map_Undo[nMapUndo].nMoveType;

	if (nMoveType != MAP_MAN_INVALID_MOVE)
	{
		nDeltaX	= Map_Undo[nMapUndo].nDeltaX;	
		nDeltaY = Map_Undo[nMapUndo].nDeltaY;
		nMoveType = Map_Undo[nMapUndo].nMoveType;

		if (nMoveType >= MAP_MAN_PUSH && nMoveType <= MAP_MAN_PUSH_FROM_HOME_TO_HOME)
		{
			nBoulderNewX = nMapManX - nDeltaX;
			nBoulderNewY = nMapManY - nDeltaY;

			if (nMoveType == MAP_MAN_PUSH)	
			{
				cManTarget = MAP_BOULDER;	
				cBoulderTarget = MAP_BLANK;
			}
			if (nMoveType == MAP_MAN_PUSH_HOME)
			{
				cManTarget = MAP_BOULDER;
				cBoulderTarget = MAP_HOME;
			}
			if (nMoveType == MAP_MAN_PUSH_FROM_HOME)
			{
				cManTarget = MAP_BOULDER_HOME;
				cBoulderTarget = MAP_BLANK;
			}
			if (nMoveType == MAP_MAN_PUSH_FROM_HOME_TO_HOME)
			{
				cManTarget = MAP_BOULDER_HOME;
				cBoulderTarget = MAP_HOME;
			}
			cMap[nMapManY][nMapManX] = cManTarget;
			cMap[nBoulderNewY][nBoulderNewX] = cBoulderTarget;
		}

		nMapManX += nDeltaX;
		nMapManY += nDeltaY;

		nMapManDeltaX = nDeltaX;
		nMapManDeltaY = nDeltaY;
		boMapRenderUpdate = TRUE;

		nMapUndo--;
		if (nMapUndo < 0)
		{
			nMapUndo = MAP_UNDO_MAX-1;
		}			   
	}
}

//----------------------------------------------------------------------------

void			Map_MarkAsDone(int nMap)
{
	boMapDone[nMap] = TRUE;
}	

//----------------------------------------------------------------------------

BOOL			Map_Done(int nMap)
{
	return(boMapDone[nMap]);
}	

//----------------------------------------------------------------------------
