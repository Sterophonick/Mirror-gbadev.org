//------------------------------------------------------------------------------------

// Game
// Rich Heasman April 2002

//------------------------------------------------------------------------------------

enum
{
	GAME_DORMANT,
	GAME_INGAME_PRE_INIT,
	GAME_INGAME_INIT,
	GAME_INGAME_GFX_INIT,
	GAME_INGAME,
	GAME_DONE_INIT,
	GAME_DONE_WAIT,
	GAME_EXIT
};

//------------------------------------------------------------------------------------

void			Game_Init(void);
void			Game_Update(void);
void			Game_Render(void);
void			Game_StateSet(unsigned int uState);
unsigned int	Game_StateGet(void);

//------------------------------------------------------------------------------------

