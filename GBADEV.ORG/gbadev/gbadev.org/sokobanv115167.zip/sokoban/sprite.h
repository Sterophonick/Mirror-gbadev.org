//------------------------------------------------------------------------

// sprite
// Rich Heasman May 2002

//------------------------------------------------------------------------

typedef struct
{
    uint  	uY:8;					// 0 to 255
    uint  	uRotation:1;			// 1 = on
    uint  	uDoubleSize:1;			// 1 = on (for rotation)
    uint  	uMode:2;				// 0 = normal object, 1 = use transparency, 2 = OBJ window style
    uint  	uMosaic:1;				// 1 = do
    uint  	uColMode:1;				// 0 = 16 cols, 16 palettes, 1 = 256 cols, 1 palette
    uint  	uShape:2;				// 0 = square, 1 = horizontal rectangle, 2 = vertical rectangle

    uint  	uX:9;					// 0 to 512
    uint  	uUnused_a:3;			   
    uint  	uHFlip:1;				// 1 = flip
    uint  	uVFlip:1;				// 1 = flip
    uint  	uSize:2;				// shape:0 0: 8*8, 1: 16*16, 2: 32*32, 3: 64*64 
									// shape:1 0:16*8, 1: 32*8,  2: 32*16, 3: 64*32        
									// shape:2 0:8*16,	1: 8*32,  2: 16*32, 3: 32*64
    uint  	uUnused_b:1;
    uint  	uChar:9;				// 0 to 1024 tile index
    uint  	uPriority:2;			// 0 (highest) - 3 (lowest)
    uint  	uPalette:4;				// 0-15 (only in 16 col mode)

} SPRITE_TYPE;


//------------------------------------------------------------------------

enum
{
	SPRITE_MAN,

	SPRITE_MAX
};

//------------------------------------------------------------------------

void		Sprite_Init(void);
void		Sprite_Update(void);
SPRITE_TYPE	*Sprite_PtrGet(uint nSprite);

//------------------------------------------------------------------------
