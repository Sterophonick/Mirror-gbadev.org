//------------------------------------------------------------------------

// sprite
// Rich Heasman May 2002

//------------------------------------------------------------------------

#include	"mygba.h"
#include	"sprite.h"

#include	"gfx.h"
#include	"gfxdata1.h"
#include	"gfxdata2.h"
#include	"dsprintf.h"

//------------------------------------------------------------------------

#define	SPRITE_TOTAL_MAX		128

SPRITE_TYPE	Sprite[SPRITE_MAX];

//------------------------------------------------------------------------

void	Sprite_Init(void)
{
	int			nSprite;
	SPRITE_TYPE	*pSprite;
	u16			*pDest;
	u16			*pSrc;

	// blank down sprite info
	pSprite = &Sprite[0];

	pSprite->uChar = 0;
	pSprite->uX = 0;
	pSprite->uY = 0;
	pSprite->uMode = 0;
	pSprite->uShape =	0;
	pSprite->uSize = 0;
	pSprite->uColMode = 0;
	pSprite->uPalette = 0;
	pSprite->uPriority = 0;
	pSprite->uVFlip = 0;
	pSprite->uHFlip = 0;
	pSprite->uMosaic = 0;
	pSprite->uRotation = 0;		
	pSprite->uDoubleSize = 1;			// Rot = 0, DoubleSize = 1 means sprite off

	pDest = (u16 *) MEM_OAM;
	pSrc = (u16 *) Sprite;
	for (nSprite = 0; nSprite < SPRITE_TOTAL_MAX; nSprite++)
	{
		*pDest++ = *pSrc;
		*pDest++ = *(pSrc + 1);
		*pDest++ = *(pSrc + 2);
		*pDest++ = 0;					// blank rotation part
	}

	// load	vram
	memcpy(MEM_PAL_OBJ_PTR, gfxdata2_Palette, GFXDATA2_PALETTE_SIZE);
    memcpy(MEM_OBJ_PTR, gfxdata2_Tiles, GFXDATA2_TILE_SIZE);

	// enable sprites
	M_DISCNT_OBJ_ON
	M_DISCNT_OBJMAP_2D

	// set up game sprites
	Sprite[SPRITE_MAN].uChar = 0;
	Sprite[SPRITE_MAN].uX = GFX_SCREEN_WIDTH;
	Sprite[SPRITE_MAN].uY = 0;
	Sprite[SPRITE_MAN].uMode = 0;
	Sprite[SPRITE_MAN].uShape =	0;
	Sprite[SPRITE_MAN].uSize = 1;
	Sprite[SPRITE_MAN].uColMode = 1;
	Sprite[SPRITE_MAN].uPalette = 0;
	Sprite[SPRITE_MAN].uPriority = 1;
	Sprite[SPRITE_MAN].uVFlip = 0;
	Sprite[SPRITE_MAN].uHFlip = 0;
	Sprite[SPRITE_MAN].uMosaic = 0;
	Sprite[SPRITE_MAN].uRotation = 0;
	Sprite[SPRITE_MAN].uDoubleSize = 0;
}	

//------------------------------------------------------------------------

void	Sprite_Update(void)
{
	int			nSprite;
	u16			*pDest;
	u16			*pSrc;

	pDest = (u16 *) MEM_OAM;
	pSrc = (u16 *) Sprite;
	for (nSprite = 0; nSprite < SPRITE_MAX; nSprite++)
	{
		*pDest++ = *pSrc++;
		*pDest++ = *pSrc++;
		*pDest++ = *pSrc++;
		pDest++; 				// skip rotation regs
	}
}	

//------------------------------------------------------------------------

SPRITE_TYPE	*Sprite_PtrGet(uint nSprite)
{
	return(&Sprite[nSprite]);
}

//------------------------------------------------------------------------


