//------------------------------------------------------------------------------------

// main
// Rich Heasman April 2002

//------------------------------------------------------------------------------------

#include "mygba.h"
#include "main.h"

#include "game.h"
#include "vblank.h"
#include "button.h"
#include "interrupt.h"
#include "gfx.h"
#include "gfxdata1.h"
#include "menu.h"
#include "profile.h"
#include "rnd.h"
#include "background.h"

MULTIBOOT

//------------------------------------------------------------------------------------

// Program entry point

void AgbMain(void)
{
	Gfx_Init();
	Interrupt_Init();
	VBlank_Init();
	Button_Init();
	Profile_Init();
	Rnd_Init();

	Menu_Init();
    Game_Init();

	Interrupt_Enable();

	while (TRUE)
	{
		Button_Update();

		Menu_Update();
		Game_Update();

		Profile_Point("Updates");

		Background_SetScreen(BACKGROUND_TEXT, GFX_BLANK);
		Profile_Point("Text Clear");

		Game_Render();
		Profile_Point("Game Render");

		Menu_Render();
		Profile_Point("Menu Render");

		Profile_Render();
		Gfx_Update();
	}		
}

//------------------------------------------------------------------------------------

