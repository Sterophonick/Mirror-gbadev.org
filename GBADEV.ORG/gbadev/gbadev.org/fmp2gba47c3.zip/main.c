#include "sys.h"

#include "output.c"

static u16 pack(int a,int b) {
	return a | (b << 8);
}

void AgbMain() {
	u16 *charBase = (u16*) (VRAM_ADDR + 0x4000);
	u16 *tileBase = (u16*) (VRAM_ADDR + 0x0000);
	int i, j;

	scr_init(1 | DISP_CR_BG2_ENA);	// 2 Text + 1 Rot/Scale
	scr_palette(0,Test_colormap,256);

	BG2_CR = BG_CHAR_BASE_0x4000 | BG_SCREEN_BASE_0x0000 | // BG_OVERFLOW_WRAP |
		BG_COLOR_MODE_256 | BG_ROTSCALE_SS_512_512;

	scr_copy(charBase,(u16*)Test_graphics,sizeof(Test_graphics) / 2);

	for (i=0; i<32; i++) {
		for (j=0; j<32; j++) {
			u8 cell = Test_map[i * 32 + j];
			tileBase[j+i*64+0] = pack(cell*4+0,cell*4+1);
			tileBase[j+i*64+32] = pack(cell*4+2,cell*4+3);
		}
	}

	while (1) {
		s16 p[4];
		s32 c[2];
		for (i=0; i<256; i++) {
			scr_rotate(c,p,i,768,768,120,80,256,256);
			BG2_DU_DX = p[0];
			BG2_DV_DX = p[1];
			BG2_DU_DY = p[2];
			BG2_DV_DY = p[3];
			BG2_ROTSCALE_X = c[0];
			BG2_ROTSCALE_Y = c[1];
			while (!(DISP_SR & DISP_SR_IN_VBLANK));
			while (DISP_SR & DISP_SR_IN_VBLANK);
		}
	}
}

