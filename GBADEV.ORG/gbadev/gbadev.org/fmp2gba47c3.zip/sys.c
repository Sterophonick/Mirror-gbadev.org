#include "sys.h"
#include "trig.h"

///// KEY SUBROUTINES /////

u16 key_current, key_last;

void key_update() {
	key_last = key_current;
	key_current = ~KEY & 0x3FF;
}


///// SCREEN SUBROUTINES /////
static u16 scr_mode_reg;
u16 *scr_base;

void scr_init(int mode) {
	scr_mode_reg = DISP_CR = mode;
	DISP_SR = 0;
	if ((mode & 7) == 4)
		scr_base = (u16*) (VRAM_ADDR + VRAM_PAGE_SIZE);
	else
		scr_base = (u16*) VRAM_ADDR;
}

void scr_swap() {
	scr_base = (u16*) ((u32)scr_base ^ VRAM_PAGE_SIZE);
	DISP_CR = (scr_mode_reg ^= DISP_CR_PAGE);
}

void scr_copy(u16 *dest,const u16 *src,int count) {
	while (count--)
		*dest++ = *src++;
}

void scr_palette(int offset,const u16 *palette,int count) {
	u16 *dest = PALETTE;
	do *dest++ = *palette++;
	while (--count);
}

void scr_clear() {
	u32 *ptr = (u32*) scr_base;
	u32 count = 240 * 80;
	while (--count) *ptr++ = 0;
}

void scr_wait() {
	__asm__("swi 5");	// BIOS_VBlankIntrWait
}


void scr_rotate(s32 offs[2],s16 rot[4],int theta,
	int invScaleX, int invScaleY,
	int screenX,int screenY,
	int worldX,int worldY) {

	// invScaleX and invScaleY are .8, and output is .8.
	// screen[XY] and world[XY] are integers
	rot[0] = (invScaleX * fcos(theta)) >> cos_fbits;
	rot[1] = (invScaleX * fsin(theta)) >> cos_fbits;
	rot[2] = (-invScaleY * fsin(theta)) >> cos_fbits;
	rot[3] = (invScaleY * fcos(theta)) >> cos_fbits;

	// Compute final offset
	offs[0] = (worldX << 8) + (rot[0] * -screenX + rot[1] * -screenY);
	offs[1] = (worldY << 8) + (rot[2] * -screenX + rot[3] * -screenY);
}


///// HIGH-LEVEL ROUTINES /////
void sys_update() {
	key_update();
	scr_swap();
}



