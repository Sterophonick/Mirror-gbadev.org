// pseudo degrees go from 0 to 255

extern short cos_table[256];
extern __inline int fcos(int x) { return cos_table[x & 255]; }
extern __inline int fsin(int x) { return cos_table[(x - 64) & 255]; }

// number of fractional bits; allows 1.0 to be exact, and leave room for sign.
#define cos_fbits 14
