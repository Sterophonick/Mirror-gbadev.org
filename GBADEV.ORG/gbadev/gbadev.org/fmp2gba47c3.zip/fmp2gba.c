// FMP2GBA
// Dave Etherton
// etherton@pacbell.net
// Version 1.0 - first public release

#include <stdio.h>
#include <stdlib.h>

#define FOURCC(a,b,c,d) (((a) << 24) | ((b) << 16) | ((c) << 8) | (d))

// borrowed from mappy:
typedef struct {	/* Structure for data blocks */
	int bgoff, fgoff;	/* offsets from start of graphic blocks */
	int fgoff2, fgoff3; /* more overlay blocks */
	unsigned int user1, user2;	/* user long data */
	unsigned short int user3, user4;	/* user short data */
	unsigned char user5, user6, user7;	/* user byte data */
	unsigned char tl : 1;	/* bits for collision detection */
	unsigned char tr : 1;
	unsigned char bl : 1;
	unsigned char br : 1;
	unsigned char trigger : 1;	/* bit to trigger an event */
	unsigned char unused1 : 1;
	unsigned char unused2 : 1;
	unsigned char unused3 : 1;
} BLKSTR;

typedef struct { /* Animation control structure */
	signed char antype;	/* Type of anim, AN_? */
	signed char andelay;	/* Frames to go before next frame */
	signed char ancount;	/* Counter, decs each frame, till 0, then resets to andelay */
	signed char anuser;	/* User info */
	int ancuroff;	/* Points to current offset in list */
	int anstartoff;	/* Points to start of blkstr offsets list, AFTER ref. blkstr offset */
	int anendoff;	/* Points to end of blkstr offsets list */
} ANISTR;

typedef struct {	/* Map header structure */
	/* char M,P,H,D;	4 byte chunk identification. */
	/* long int mphdsize;	size of map header. */
	char mapverhigh;	/* map version number to left of . (ie X.0). */
	char mapverlow;		/* map version number to right of . (ie 0.X). */
	char lsb;		/* if 1, data stored LSB first, otherwise MSB first. */
	char bodytype;	/* 0 for 32 offset still, -16 offset anim shorts in BODY */
	short int mapwidth;	/* width in blocks. */
	short int mapheight;	/* height in blocks. */
	short int reserved1;
	short int reserved2;
	short int blockwidth;	/* width of a block (tile) in pixels. */
	short int blockheight;	/* height of a block (tile) in pixels. */
	short int blockdepth;	/* depth of a block (tile) in planes (ie. 256 colours is 8) */
	short int blockstrsize;	/* size of a block data structure */
	short int numblockstr;	/* Number of block structures in BKDT */
	short int numblockgfx;	/* Number of 'blocks' in graphics (BODY) */
	unsigned char ckey8bit, ckeyred, ckeygreen, ckeyblue; /* colour key values */
} MPHD;

static char *SymName;
static FILE *Output;
static MPHD *Header;
static BLKSTR *Blocks;

static void DecodeMPHD(MPHD *block,int tagLen) {
	if (block->mapverhigh != 1 || block->mapverlow != 0)
		fprintf(stderr,"Expecting version 1.0 header, might not work (re-save after editing map properties)\n");
	Header = block;
}

static void DecodeCMAP(unsigned char *rgb,int tagLen) {
	int i;
	fprintf(Output,"unsigned short %s_colormap[] = {\n\t",SymName);
	for (i=0; i<tagLen; i += 3) {
		int p = (rgb[i] >> 3) | ((rgb[i+1]>>3) << 5) | ((rgb[i+2]>>3) << 10);
		fprintf(Output,"0x%04x,%s",p,i % 24 == 21? "\n\t" : "");
	}
	fprintf(Output,"};\n");
	free(rgb);
}

static void DecodeBKDT(BLKSTR *str,int tagLen) {
	Blocks = str;
}

static void DecodeBGFX(unsigned char *bits,int tagLen) {
	int i, j;
	int area = Header->blockwidth * Header->blockheight;

	if (!Header) {
		fprintf(stderr,"got BGFX before header!\n");
		return;
	}

	fprintf(Output,"unsigned char %s_graphics[] = {\n",SymName);
	tagLen /= area;

	while (tagLen) {
		for (i=0; i<Header->blockheight; i+=8) {
			for (j=0; j<Header->blockwidth; j+=8) {
				unsigned char *base = bits + j + i * Header->blockwidth;
				int m, n;
				fprintf(Output,"\t");
				for (m=0; m<8; m++,base += Header->blockwidth) {
					for (n=0; n<8; n++)
						fprintf(Output,"%3d,",base[n]);
				}
				fprintf(Output,"\n");		
			}
		}
		tagLen--;
		bits += area;
	}
	fprintf(Output,"};\n");	
}

static int first_nonzero(int a,int b) {
	return a? a : b;
}

static void DecodeBODY(short *body,int tagLen) {
	int i;
	if (!Header || !Blocks) {
		fprintf(stderr,"got BODY before header and BKDT!\n");
		return;
	}

	tagLen >>= 1;
	fprintf(Output,"unsigned char %s_map[] = {\n\t",SymName);
	for (i=0; i<tagLen; i++) {
		if (body[i] >= 0)
			fprintf(Output,"%3d,",first_nonzero(
				Blocks[body[i]].bgoff,
				Blocks[body[i]].fgoff
				));
		else
			fprintf(Output,"  0,");
		if ((i & 15) == 15)
			fprintf(Output,"\n\t");
	}
	fprintf(Output,"};\n");
}

static int GetWord(FILE *f) {	// big-endian word
	int w = fgetc(f) << 24;
	w |= fgetc(f) << 16;
	w |= fgetc(f) << 8;
	w |= fgetc(f);
	return w;
}

static int Decode(const char *filename,const char *outname) {
	FILE *f = fopen(filename,"rb");
	int totalSize;
	int tag;

	if (!f) {
		fprintf(stderr,"'%s' - file not found\n",filename);
		return -1;
	}

	if (GetWord(f) != FOURCC('F','O','R','M')) {
		fclose(f);
		fprintf(stderr,"'%s' - not a IFF format file\n",filename);
		return -1;
	}

	totalSize = GetWord(f) - 4;	// form type is counted here

	if (GetWord(f) != FOURCC('F','M','A','P')) {
		fclose(f);
		fprintf(stderr,"'%s' - not an FMAP file\n",filename);
		return -1;
	}

	Output = fopen(outname,"w");
	if (!Output) {
		fclose(f);
		fprintf(stderr,"%s' - cannot create file\n",outname);
	}
		

	while ((tag = GetWord(f)) != -1) {
		int tagLen = GetWord(f);
		void *block = malloc(tagLen);
		fread(block,tagLen,1,f);

		totalSize -= 8 + tagLen;
		if (tag == FOURCC('M','P','H','D'))
			DecodeMPHD(block,tagLen);
		else if (tag == FOURCC('C','M','A','P'))
			DecodeCMAP(block,tagLen);
		else if (tag == FOURCC('B','K','D','T'))
			DecodeBKDT(block,tagLen);
		else if (tag == FOURCC('B','G','F','X'))
			DecodeBGFX(block,tagLen);
		else if (tag == FOURCC('B','O','D','Y'))
			DecodeBODY(block,tagLen);
		else {
			fprintf(stderr,"code %x (%d bytes) skipped\n",tag,tagLen);
			free(block);
		}
	}

	if (totalSize)
		fprintf(stderr,"'%s' - warning - %d bytes after IFF\n",totalSize);

	fclose(f);
	fclose(Output);

	return 0;
}


void main(int argc,char **argv) {
	if (argc == 4) {
		SymName = argv[3];
		Decode(argv[1],argv[2]);
	}
	else
		fprintf(stderr,"usage: fmp2gba input.fmp output.c SymbolName\n");
}
