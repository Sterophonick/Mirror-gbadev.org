#ifndef SYS_H
#define SYS_H

///// BASIC TYPES /////
typedef unsigned char u8;
typedef unsigned short u16;
typedef unsigned int u32;

typedef signed char s8;
typedef signed short s16;
typedef signed int s32;

///// HARDWARE ADDRESSES /////
#define EXT_RAM_ADDR	0x02000000		// 256K
#define INT_RAM_ADDR	0x03000000		// 32K
#define PALETTE		((u16*)0x05000000)
#define VRAM_ADDR	0x06000000
#define VRAM_PAGE_SIZE	0x0000A000

// Register names borrowed from Mappy VM
#define DISP_CR			(*(volatile u16*)0x04000000)
	#define DISP_CR_PAGE		0x0010
	#define DISP_CR_HBLANK_OAM_ENA	0x0020
	#define DISP_CR_USE_1D_MAPPING	0x0040
	#define DISP_CR_FORCED_BLANK	0x0080
	#define DISP_CR_BG0_ENA		0x0100
	#define DISP_CR_BG1_ENA		0x0200
	#define DISP_CR_BG2_ENA		0x0400
	#define DISP_CR_BG3_ENA		0x0800
	#define DISP_CR_OBJ_ENA		0x1000
	#define DISP_CR_WIN0_ENA	0x2000
	#define DISP_CR_WIN1_ENA	0x4000
	#define DISP_CR_WINOBJ_ENA	0x8000

#define DISP_SR	(*(volatile u16*)0x04000004)
	#define DISP_SR_IN_VBLANK	0x0001
	#define DISP_SR_IN_HBLANK	0x0002
	#define DISP_SR_Y_TRIGGERED	0x0004
	#define DISP_SR_VBLANK_INT_ENA	0x0008
	#define DISP_SR_HBLANK_INT_ENA	0x0010
	#define DISP_SR_VMATCH_INT_ENA	0x0020

	#define DISP_SR_Y_TRIGGER_S	8
	#define DISP_SR_Y_TRIGGER_M	0x00FF

#define DISP_Y		(*(volatile u16*)0x04000006)

#define BG0_CR		(*(volatile u16*)0x04000008)
#define BG1_CR		(*(volatile u16*)0x0400000A)
#define BG2_CR		(*(volatile u16*)0x0400000C)
#define BG3_CR		(*(volatile u16*)0x0400000E)

	#define BG_PRIORITY_0		0x0000		// highest
	#define BG_PRIORITY_1		0x0001
	#define BG_PRIORITY_2		0x0002
	#define BG_PRIORITY_3		0x0003		// lowest

	#define BG_CHAR_BASE_0x0000	0x0000		// 16K increments
	#define BG_CHAR_BASE_0x4000	0x0004
	#define BG_CHAR_BASE_0x8000	0x0008
	#define BG_CHAR_BASE_0xC000	0x000C

	#define BG_MOSAIC_ENA		0x0040

	#define BG_COLOR_MODE_16	0x0000
	#define BG_COLOR_MODE_256	0x0080

	#define BG_SCREEN_BASE_S	8		// 2K increments
	#define BG_SCREEN_BASE_M	0x001F

	#define BG_SCREEN_BASE_0x0000	0x0000
	#define BG_SCREEN_BASE_0x0800	0x0100
	#define BG_SCREEN_BASE_0x1000	0x0200
	#define BG_SCREEN_BASE_0x1800	0x0300

	#define BG_SCREEN_BASE_0x2000	0x0400
	#define BG_SCREEN_BASE_0x2800	0x0500
	#define BG_SCREEN_BASE_0x3000	0x0600
	#define BG_SCREEN_BASE_0x3800	0x0700

	#define BG_SCREEN_BASE_0x4000	0x0800
	#define BG_SCREEN_BASE_0x4800	0x0900
	#define BG_SCREEN_BASE_0x5000	0x0A00
	#define BG_SCREEN_BASE_0x5800	0x0B00

	#define BG_SCREEN_BASE_0x6000	0x0C00
	#define BG_SCREEN_BASE_0x6800	0x0D00
	#define BG_SCREEN_BASE_0x7000	0x0E00
	#define BG_SCREEN_BASE_0x7800	0x0F00

	#define BG_SCREEN_BASE_0x8000	0x1000
	#define BG_SCREEN_BASE_0x8800	0x1100
	#define BG_SCREEN_BASE_0x9000	0x1200
	#define BG_SCREEN_BASE_0x9800	0x1300

	#define BG_SCREEN_BASE_0xA000	0x1400
	#define BG_SCREEN_BASE_0xA800	0x1500
	#define BG_SCREEN_BASE_0xB000	0x1600
	#define BG_SCREEN_BASE_0xB800	0x1700

	#define BG_SCREEN_BASE_0xC000	0x1800
	#define BG_SCREEN_BASE_0xC800	0x1900
	#define BG_SCREEN_BASE_0xD000	0x1A00
	#define BG_SCREEN_BASE_0xD800	0x1B00

	#define BG_SCREEN_BASE_0xE000	0x1C00
	#define BG_SCREEN_BASE_0xE800	0x1D00
	#define BG_SCREEN_BASE_0xF000	0x1E00
	#define BG_SCREEN_BASE_0xF800	0x1F00

	#define BG_OVERFLOW_TRANSPARENT	0x0000
	#define BG_OVERFLOW_WRAP	0x2000

	#define BG_TEXT_SS_256_256	0x0000	// 2K
	#define BG_ROTSCALE_SS_128_128	0x0000	// 256 bytes

	#define BG_TEXT_SS_512_256	0x4000	// 4K
	#define BG_ROTSCALE_SS_256_256	0x4000	// 1K

	#define BG_TEXT_SS_256_512	0x8000	// 4K
	#define BG_ROTSCALE_SS_512_512	0x8000	// 4K

	#define BG_TEXT_SS_512_512	0xC000	// 8K
	#define BG_ROTSCALE_SS_1K_1K	0xC000	// 16K

#define BG0_TEXT_X	(*(volatile u16*)0x04000010)	// Text mode only
#define BG0_TEXT_Y	(*(volatile u16*)0x04000012)
#define BG1_TEXT_X	(*(volatile u16*)0x04000014)	// Text mode only
#define BG1_TEXT_Y	(*(volatile u16*)0x04000016)
#define BG2_TEXT_X	(*(volatile u16*)0x04000018)	// Text mode only
#define BG2_TEXT_Y	(*(volatile u16*)0x0400001A)
#define BG3_TEXT_X	(*(volatile u16*)0x0400001C)	// Text mode only
#define BG3_TEXT_Y	(*(volatile u16*)0x0400001E)

#define BG2_DU_DX	(*(volatile s16*)0x04000020)	// du/dx
#define BG2_DV_DX	(*(volatile s16*)0x04000022)	// dv/dx
#define BG2_DU_DY	(*(volatile s16*)0x04000024)	// du/dy
#define BG2_DV_DY	(*(volatile s16*)0x04000026)	// dv/dy

#define BG2_ROTSCALE_X	(*(volatile s32*)0x04000028)	
#define BG2_ROTSCALE_Y	(*(volatile s32*)0x0400002C)	

#define BG3_DU_DX	(*(volatile s16*)0x04000030)	// du/dx
#define BG3_DV_DX	(*(volatile s16*)0x04000032)	// dv/dx
#define BG3_DU_DY	(*(volatile s16*)0x04000034)	// du/dy
#define BG3_DV_DY	(*(volatile s16*)0x04000036)	// dv/dy

#define BG3_ROTSCALE_X	(*(volatile s32*)0x04000038)	
#define BG3_ROTSCALE_Y	(*(volatile s32*)0x0400003C)	

#define WIN0_H		(*(volatile u16*)0x04000040)
#define WIN1_H		(*(volatile u16*)0x04000042)
#define WIN0_V		(*(volatile u16*)0x04000044)
#define WIN1_V		(*(volatile u16*)0x04000046)
#define WIN_IN		(*(volatile u16*)0x04000048)
#define WIN_OUT		(*(volatile u16*)0x0400004A)

#define MOSAIC		(*(volatile u16*)0x0400004C)
	#define MOSAIC_BG_WIDTH_S	0
	#define MOSAIC_BG_WIDTH_M	0x000F
	#define MOSAIC_BG_HEIGHT_S	4
	#define MOSAIC_BG_HEIGHT_M	0x000F
	#define MOSAIC_OBJ_WIDTH_S	8
	#define MOSAIC_OBJ_WIDTH_M	0x000F
	#define MOSAIC_OBJ_HEIGHT_S	12
	#define MOSAIC_OBJ_HEIGHT_M	0x000F

#define BLEND_CR	(*(volatile u16*)0x04000050)
#define BLEND_AB	(*(volatile u16*)0x04000052)
#define BLEND_Y		(*(volatile u16*)0x04000054)

#define DMA0_SRC	(*(volatile u32*)0x040000B0)
#define DMA0_DEST	(*(volatile u32*)0x040000B4)
#define DMA0_SIZE	(*(volatile u16*)0x040000B8)
#define DMA0_CR		(*(volatile u16*)0x040000BA)

#define DMA1_SRC	(*(volatile u32*)0x040000BC)
#define DMA1_DEST	(*(volatile u32*)0x040000C0)
#define DMA1_SIZE	(*(volatile u16*)0x040000C4)
#define DMA1_CR		(*(volatile u16*)0x040000C6)

#define DMA2_SRC	(*(volatile u32*)0x040000C8)
#define DMA2_DEST	(*(volatile u32*)0x040000CC)
#define DMA2_SIZE	(*(volatile u16*)0x040000D0)
#define DMA2_CR		(*(volatile u16*)0x040000D2)

#define DMA3_SRC	(*(volatile u32*)0x040000D4)
#define DMA3_DEST	(*(volatile u32*)0x040000D8)
#define DMA3_SIZE	(*(volatile u16*)0x040000DC)
#define DMA3_CR		(*(volatile u16*)0x040000DE)

#define		DMACR			0x0000
#define		DMACR_32		0x0400

#define KEY		(*(volatile u16*)0x04000130)
	// ZERO if the button is pressed
	#define KEY_A		0x0001
	#define KEY_B		0x0002
	#define KEY_SELECT	0x0004
	#define KEY_START	0x0008
	#define KEY_RIGHT	0x0010
	#define KEY_LEFT	0x0020
	#define KEY_UP		0x0040
	#define KEY_DOWN	0x0080
	#define KEY_RSH		0x0100
	#define KEY_LSH		0x0200

#define KEYCNT		(*(volatile u16*)0x4000132)
	#define KEY_INT_ANY	0x0000	// Interrupt if any keys pressed
	#define KEY_INT_ALL	0x8000	// Interrupt if all keys pressed

	#define KEY_INT_ENA	0x4000

///// UTILITY MACROS /////
#define PACKRGB(r,g,b)	((u16) ( ((r)>>3) | (((g)>>3)<<5) | (((b)>>3)<<10) ))

///// ENTRY POINT /////
extern void AgbMain(void);

///// KEY SUBROUTINES /////
void key_update();
extern u16 key_current, key_last;
static __inline int key_get_pressed() { return (key_current ^ key_last) & key_current; }
static __inline int key_get_released() { return (key_current ^ key_last) & key_last; }
static __inline int key_get_status() { return key_current; }

///// SCREEN SUBROUTINES /////
void scr_init(int mode);
void scr_swap();
void scr_palette(int offset,const u16 *palette,int count);
void scr_clear();
void scr_copy(u16 *dest,const u16 *src,int wordCount);
extern u16 *scr_base;
void scr_rotate(s32 offs[2],s16 rot[4],int theta,int invScaleX,int invScaleY,
	int screenX,int screenY,int worldX,int worldY);

///// HIGH-LEVEL ROUTINES /////
void sys_update();
void sys_reset();

#endif
