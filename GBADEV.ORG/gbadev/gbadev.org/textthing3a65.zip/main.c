#include "screen_data.h"
#include "registros.h"

#define TILE_DATA_MEM    ((u16*)0x6000000)
#define SCREEN_DATA_MEM1 ((u8*)0x6004000)
#define SCREEN_DATA_MEM2 ((u8*)0x6004800)
#define PALETTE_MEM      ((u16*)0x5000000)

#define OAM		((Sprite*)0x07000000)

#define OBJ_VRAM	((u8*)0x06010000)
#define OBJ_PLTT	((u16*)0x05000200)

#define ANCHO_LETRA	8

typedef unsigned char u8;
typedef unsigned short u16;
typedef unsigned long u32;
typedef signed short s16;

typedef struct _Sprite { u16 Attrib0, Attrib1, Attrib2, RotateScale; } Sprite;

extern u32 tile_data;
extern u32 palette;

extern u32 obj_data;
extern u32 obj_pal;

extern u16 screen_data1[];
extern u16 screen_data2[];

void DMA3(u32 src, u32 dst, u32 cnt)
{
	DMA3SAD=src;
	DMA3DAD=dst;
	DMA3CNT=cnt;
}

void Muestra_Sprite(u16 bx, u16 by, u16 tile, u16 sitio)
{
	OAM[sitio].Attrib0 = 0x2000 +by;
	OAM[sitio].Attrib1 = 0x0000 +bx;
	OAM[sitio].Attrib2 = 0x0000 +tile;
}

void Limpia_OAM(void)
{
	u16 i,*oam;
	oam=(u16 *)0x07000000;
	for (i=0;i<1024/2;i++,oam++)
	*oam=0x0200;
}

void Carga_Sprite(void)
{
	DMA3((u32)&obj_data, (u32)OBJ_VRAM, 0x84000000 + (0x40*83));
	DMA3((u32)&obj_pal, (u32)OBJ_PLTT, 0x84000040);
}

void init(void)
{
	DISPCNT = 0x3340;
	BG0CNT  = 0x0883;
	BG1CNT  = 0x0980;
	
	BLDCNT=0x142;
	BLDALPHA=0x606;
	
	WIN0H=0x14DC;
	WIN0V=0x8296;
	WININ=0x32;
	WINOUT=0x1;
	
	Limpia_OAM();
	Carga_Sprite();
}

void WaitForVSync()
{
	__asm
   	{
		mov 	r0, #0x4000006
    		scanline_wait:
    		ldrh	r1, [r0]
     		cmp	r1, #160
    		bne 	scanline_wait
  	 }
}


void Haz_Todo(u16 *pos_actual1, u16 *SCR_NUM_CHAR1, u16 *sitio_libre1,u16 *x1, u16 *y1, u16 *flag1, u16 *NUM_CHAR1)
{
	u16 tile_actual=0;
	int i,k;
	u16 pos_actual=*pos_actual1;
	u16 SCR_NUM_CHAR=*SCR_NUM_CHAR1;
	u16 sitio_libre=*sitio_libre1;
	u16 x=*x1;
	u16 y=*y1;
	u16 flag=*flag1;
	u16 NUM_CHAR = *NUM_CHAR1;
	
	char texto[]="Hi Everyone! I'm Javi (a.k.a. Taiyou) from Spain! This is just a glimpse of what I'll be able to do in the future when I learn some more coding, :D. Maybe the source code can help someone to start from zero, cause it's very simple (and so very uneffective XD). Just say hello world! I'm here! :D                            ";
	char ref[]="0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz.,:;()[]@_+-*/!#=?^�&";
	
	NUM_CHAR=0;
	
	while(texto[NUM_CHAR]!='\0'){
		NUM_CHAR++;
	}
	
	if (flag !=8)
	{
		x++;y++;
		BG0HOFS=(u16)x;
		BG0VOFS=(u16)y;
		
		for(i=0;i<SCR_NUM_CHAR;i++){
			OAM[i].Attrib1--;
		}
		
		flag++;
	
		
	}else{
		x++;y++;
		BG0HOFS=(u16)x;
		BG0VOFS=(u16)y;
		
		
		if (SCR_NUM_CHAR<23){
						
			
			for(tile_actual=0;tile_actual<83;tile_actual++){
				if(texto[pos_actual]==ref[tile_actual]) break;
			}
			Muestra_Sprite(220,138,tile_actual*2,sitio_libre);
			for(i=0;i<SCR_NUM_CHAR;i++){
				OAM[i].Attrib1--;
			}
		
			flag=0;pos_actual++;
			sitio_libre++;
			SCR_NUM_CHAR++;
		
		}else{
			
			if (sitio_libre<22){
				sitio_libre++;
			}else{
				sitio_libre=0;
			}
			for(tile_actual=0;tile_actual<83;tile_actual++){
				if(texto[pos_actual]==ref[tile_actual]) break;
			}
			Muestra_Sprite(220,138,tile_actual*2,sitio_libre);
					
			for(i=0;i<SCR_NUM_CHAR;i++){
				OAM[i].Attrib1--;
			}
			
			
			flag=0;pos_actual++;
			
		}
	}

	*pos_actual1=pos_actual;
	*SCR_NUM_CHAR1=SCR_NUM_CHAR;
	*sitio_libre1=sitio_libre;
	*x1=x;
	*y1=y;
	*flag1= flag;
	*NUM_CHAR1 = NUM_CHAR;
	
}


void C_Entry(void)
{
	u16 pos_actual=0;
	u16 SCR_NUM_CHAR=0;
	u16 sitio_libre=0;
	u16 x=0,y=0;
	u16 NUM_CHAR;
	u16 flag=0;
		
	DMA3((u32)&tile_data,(u32)TILE_DATA_MEM,0x84000000+(0x40*5));
	DMA3((u32)&palette,  (u32)PALETTE_MEM,  0x84000080);

	DMA3((u32)&screen_data1,(u32)SCREEN_DATA_MEM1,0x84000000+(sizeof(screen_data1)/sizeof(u32)));
	DMA3((u32)&screen_data2,(u32)SCREEN_DATA_MEM2,0x84000000+(sizeof(screen_data2)/sizeof(u32)));
	
	init();
	
	while(1)
	{
		Haz_Todo(&pos_actual,&SCR_NUM_CHAR,&sitio_libre,&x,&y,&flag,&NUM_CHAR);
		WaitForVSync();
		if (pos_actual==NUM_CHAR){
			pos_actual=0;
			SCR_NUM_CHAR=0;
			sitio_libre=0;
			Limpia_OAM();
		}

	}
}