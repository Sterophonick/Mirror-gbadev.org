This is just my first "demo" if you want to call it that way. My lack of experience coding maybe maked the source code a little unreadable (a bit more because its in spanish) but I hope it can help someone to start like I did in my time. 

The demo itself features a scrolling Background (in mode 0), a window that contains another background that makes alpha blending againts the first one, and a chain of text that scrolls inside that translucent rectangle from right to left. Not a great thing but good to start experimenting.

Just say hello to everyone, I'm Javi (a.k.a.) Taiyou, from Spain, and I only want you all to know that I'm alive and I hope to progress well until I make something useful. I'll be informing you of the progress of my little experiences with GBA ok?

Bye bye!
