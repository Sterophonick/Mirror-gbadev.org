// 4 LCD
#define VCOUNT       *(u16*)0x04000006
#define DISPSTAT     *(u16*)0x04000004

// 5 Image System
#define DISPCNT      *(u16*)0x04000000

// 6 Rendering Functions
#define BG0CNT       *(u16*)0x04000008
#define BG1CNT       *(u16*)0x0400000A
#define BG2CNT       *(u16*)0x0400000C
#define BG3CNT       *(u16*)0x0400000E
#define MOSAIC       *(u16*)0x0400004C
#define BG2X_L       *(u16*)0x04000028
#define BG3X_L       *(u16*)0x04000038
#define BG2X_H       *(u16*)0x0400002A
#define BG3X_H       *(u16*)0x0400003A
#define BG2X         *(u32*)0x04000028
#define BG3X         *(u32*)0x04000038

#define BG2Y_L       *(u16*)0x0400002C
#define BG3Y_L       *(u16*)0x0400003C
#define BG2Y_H       *(u16*)0x0400002E
#define BG3Y_H       *(u16*)0x0400003E
#define BG2Y         *(u32*)0x0400002C
#define BG3Y         *(u32*)0x0400003C

#define BG2PA        *(u16*)0x04000020
#define BG3PA        *(u16*)0x04000030
#define BG2PB        *(u16*)0x04000022
#define BG3PB        *(u16*)0x04000032
#define BG2PC        *(u16*)0x04000024
#define BG3PC        *(u16*)0x04000034
#define BG2PD        *(u16*)0x04000026
#define BG3PD        *(u16*)0x04000036

#define BG0HOFS	     *(u16*)0x04000010
#define BG0VOFS	     *(u16*)0x04000012
#define BG1HOFS	     *(u16*)0x04000014
#define BG1VOFS	     *(u16*)0x04000016
#define BG2HOFS	     *(u16*)0x04000018
#define BG2VOFS	     *(u16*)0x0400001A
#define BG3HOFS	     *(u16*)0x0400001C
#define BG3VOFS	     *(u16*)0x0400001E

// 8 Window Feature
#define WIN0H        *(u16*)0x04000040
#define WIN1H        *(u16*)0x04000042
#define WIN0V        *(u16*)0x04000044
#define WIN1V        *(u16*)0x04000046
#define WININ        *(u16*)0x04000048
#define WINOUT       *(u16*)0x0400004A

// 9 Color Special Effects
#define BLDCNT       *(u16*)0x04000050
#define BLDALPHA     *(u16*)0x04000052
#define BLDY         *(u16*)0x04000054

// 10 Sound
#define FIFO_A_L     *(u16*)0x040000A0
#define FIFO_B_L     *(u16*)0x040000A4
#define FIFO_A_H     *(u16*)0x040000A2
#define FIFO_B_H     *(u16*)0x040000A6
#define FIFO_A       *(u32*)0x040000A0
#define FIFO_B       *(u32*)0x040000A4
#define SOUND1CNT_L  *(u16*)0x04000060
#define SOUND1CNT_H  *(u16*)0x04000062
#define SOUND1CNT    *(u32*)0x04000060
#define SOUND1CNT_X  *(u16*)0x04000064
#define SOUND2CNT_L  *(u16*)0x04000068
#define SOUND2CNT_H  *(u16*)0x0400006C
#define SOUND2CNT    *(u32*)0x04000068
#define SOUND3CNT_L  *(u16*)0x04000070
#define SOUND3CNT_H  *(u16*)0x04000072
#define SOUND3CNT    *(u32*)0x04000070
#define SOUND3CNT_X  *(u16*)0x04000074
#define WAVE_RAM0_L  *(u16*)0x04000090
#define WAVE_RAM0_H  *(u16*)0x04000092
#define WAVE_RAM0    *(u32*)0x04000090
#define WAVE_RAM1_L  *(u16*)0x04000094
#define WAVE_RAM1_H  *(u16*)0x04000096
#define WAVE_RAM1    *(u32*)0x04000094
#define WAVE_RAM2_L  *(u16*)0x04000098
#define WAVE_RAM2_H  *(u16*)0x0400009A
#define WAVE_RAM2    *(u32*)0x04000098
#define WAVE_RAM3_L  *(u16*)0x0400009C
#define WAVE_RAM3_H  *(u16*)0x0400009E
#define WAVE_RAM3    *(u32*)0x0400009C
#define SOUND4CNT_L  *(u16*)0x04000078
#define SOUND4CNT_H  *(u16*)0x0400007C
#define SOUND4CNT    *(u32*)0x04000078
#define SOUNDCNT_L   *(u16*)0x04000080
#define SOUNDCNT_H   *(u16*)0x04000082
#define SOUNDCNT     *(u32*)0x04000080
#define SOUNDCNT_X   *(u16*)0x04000084
#define SOUNDBIAS    *(u16*)0x04000088

// 11 Timer
#define TM0CNT_L     *(u16*)0x04000100
#define TM0CNT_H     *(u16*)0x04000102
#define TM0CNT       *(u32*)0x04000100
#define TM1CNT_L     *(u16*)0x04000104
#define TM1CNT_H     *(u16*)0x04000106
#define TM1CNT       *(u32*)0x04000104
#define TM2CNT_L     *(u16*)0x04000108
#define TM2CNT_H     *(u16*)0x0400010A
#define TM2CNT       *(u32*)0x04000108
#define TM3CNT_L     *(u16*)0x0400010C
#define TM3CNT_H     *(u16*)0x0400010E
#define TM3CNT       *(u32*)0x0400010C

// 12 DMA
#define DMA0SAD_L    *(u16*)0x040000B0
#define DMA0SAD_H    *(u16*)0x040000B2
#define DMA0SAD      *(u32*)0x040000B0
#define DMA0DAD_L    *(u16*)0x040000B4
#define DMA0DAD_H    *(u16*)0x040000B6
#define DMA0DAD      *(u32*)0x040000B4
#define DMA0CNT_L    *(u16*)0x040000B8
#define DMA0CNT_H    *(u16*)0x040000BA
#define DMA0CNT      *(u32*)0x040000B8

#define DMA1SAD_L    *(u16*)0x040000BC
#define DMA1SAD_H    *(u16*)0x040000BE
#define DMA1SAD      *(u32*)0x040000BC
#define DMA1DAD_L    *(u16*)0x040000C0
#define DMA1DAD_H    *(u16*)0x040000C2
#define DMA1DAD      *(u32*)0x040000C0
#define DMA1CNT_L    *(u16*)0x040000C4
#define DMA1CNT_H    *(u16*)0x040000C6
#define DMA1CNT      *(u32*)0x040000C4

#define DMA2SAD_L    *(u16*)0x040000C8
#define DMA2SAD_H    *(u16*)0x040000CA
#define DMA2SAD      *(u32*)0x040000C8
#define DMA2DAD_L    *(u16*)0x040000CC
#define DMA2DAD_H    *(u16*)0x040000CE
#define DMA2DAD      *(u32*)0x040000CC
#define DMA2CNT_L    *(u16*)0x040000D0
#define DMA2CNT_H    *(u16*)0x040000D2
#define DMA2CNT      *(u32*)0x040000D0

#define DMA3SAD_L    *(u16*)0x040000D4
#define DMA3SAD_H    *(u16*)0x040000D6
#define DMA3SAD      *(u32*)0x040000D4
#define DMA3DAD_L    *(u16*)0x040000D8
#define DMA3DAD_H    *(u16*)0x040000DA
#define DMA3DAD      *(u32*)0x040000D8
#define DMA3CNT_L    *(u16*)0x040000DC
#define DMA3CNT_H    *(u16*)0x040000DE
#define DMA3CNT      *(u32*)0x040000DC

// 13 Communication Functions
#define SIODATA8     *(u16*)0x0400012A
#define SIODATA32_L  *(u16*)0x04000120
#define SIODATA32_H  *(u16*)0x04000122
#define SIODATA32    *(u32*)0x04000120
#define SIOCNT       *(u16*)0x04000128
#define SIOMLT_SEND  *(u16*)0x0400012A
#define SIOMULTI0    *(u16*)0x04000120
#define SIOMULTI1    *(u16*)0x04000122
#define SIOMULTI2    *(u16*)0x04000124
#define SIOMULTI3    *(u16*)0x04000126
#define RCNT         *(u16*)0x04000134
#define JOYCNT       *(u16*)0x04000140
#define JOY_RECV_L   *(u16*)0x04000150
#define JOY_RECV_H   *(u16*)0x04000152
#define JOY_RECV     *(u32*)0x04000150
#define JOY_TRANS_L  *(u16*)0x04000154
#define JOY_TRANS_H  *(u16*)0x04000156
#define JOY_TRANS    *(u32*)0x04000154
#define JOYSTAT      *(u16*)0x04000158

// 14 Key Input
#define KEYINPUT     *(u16*)0x04000130
#define KEYCNT       *(u16*)0x04000132

// 15 Interrupt Control
#define IME          *(u16*)0x04000208
#define IE           *(u16*)0x04000200
#define IF           *(u16*)0x04000202