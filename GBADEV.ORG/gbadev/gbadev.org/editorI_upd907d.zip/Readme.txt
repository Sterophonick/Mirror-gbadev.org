Map Editor for the GBA
Beta Version.

----------------------------------------------------------------------
Finally i have a beta version for proof of my map editor for the GBA,
I hope u enjoy it and if you find any bug (remember ys a proof version)
please tell me and I will try to fix it also if you have any idea tell
me and I'll add it.

----------------------------------------------------------------------
A little modification (3/27/02)

* Corrected a little problem, the whole eanglish version soon!

First version (18/02/02)

* Can make maps of 256x256 pixels (32x32 tiles).
* It handle four layers and can visualize all at the same time or
  individually.
* It have zoom in the tiles an in the map.
* You can use tiles of 8x8, 8x16, 16x32, etc.
* Export in ASCII code to a .h archive.
* You can select the layers to export.
* Also can choose the array type (Ej. cu16).
* An select the map array name.

And other cool features!!!

----------------------------------------------------------------------
Important Notes:

The bitmap must be in 24 bits, and the transparent color is the black
so make the first 8x8 tile all black for a best visualization.
Also the msvbvm50.dll i required you can download it from my hompage
in the seccion of Programas

----------------------------------------------------------------------
www.geocities.com/mafs_is
Or send me a e-mail a mafs_is@yahoo.com