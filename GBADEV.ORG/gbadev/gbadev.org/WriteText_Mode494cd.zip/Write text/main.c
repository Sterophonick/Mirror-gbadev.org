/******************************************************************
*  ____________WRITING TEXT EXAMPLE                               * 
*  BY:         MANULON                                            *
*  DATE:       25.06.03                                           *
*  THANKS TO:  DOVOTOS & GBAJUNKIE TUTORIALS                      *
*  E-MAIL:     CABRONELQUELOLEA@HOTMAIL.COM                       *
******************************************************************/

// Includes
#include "gba.h"
#include "screenmode.h"
#include "sprite.h"

#include "letras.h"	// Sprite with all letters

// Constants
#define  ALP_LETTERS  " ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789!\"#$%&'()*+,-./:;<=>?"
#define  NUM_LETTERS  85 		// Number of letters

OAMEntry Sprites[128];			// Sprites array
u16      LettersOffset[NUM_LETTERS];	// Letters position in memory
u16 	 ActualSprite = 0;		// Next sprite start position / Used sprites

// Waits for the screen stop painting
void WaitForVSync()
{
	while ((volatile u16)REG_VCOUNT != 160) {}
}

// Copies our sprites data to the gba oam
void CopyOAM()
{
	u16 i;
	u16 *temp;
	
	temp = (u16*)Sprites; 		// Point to the sprites
	for (i = 0; i < 128 * 4; i++)   // 128 sprites * 4 u16 attributes
	{
		OAMmem[i] = temp[i];	// Copy our sprites data to the oam
	}
}

// Set the 128 sprites off screen
void InitializeSprites()
{
	u16 i;
	
	for (i = 0; i < 128; i++)	
	{
		Sprites[i].attribute0 = 160;	// y = 160
		Sprites[i].attribute1 = 240;	// x = 240
	}
}

// Set each letter position in memory into the array
void InitializeLetters()
{
	u16 i;

	// In mode 4 the first sprite direction is in 512
	for (i = 0; i < NUM_LETTERS; i++)
		LettersOffset[i] = 512 + i * 2;	// 512 is the first letter direction
						// 514 is the second letter direcction
						// 516 is the third letter direcction...
						// why? well, we use 8x8 sprites (1 position)
						// but we are in 256 color mode, then
						// 1*2 = 2 positions for each letter
}

// Returns the letter position in the alphabet
u16 LetterPos(char letter)
{
	u16 i;
	
	for (i = 0; i < NUM_LETTERS; i++)
		if (letter == ALP_LETTERS[i]) return i;	// If letter = current alp. letter
							// then return that position
}

// Returns the text length	
u16 Length(char text[])
{
	u16 i;
	
	i = 0;
	while (text[i] != 0) i++;	
	
	return i;	// Return the total letters in the text 
}	

// Creates a sprite for each letter in the text and it puts them in the correct
// order to form the text
void WriteText(char *text, u16 x, u16 y)
{
	u16 i;
	
	for (i = 0; i < Length(text); i++)
	{
		if (ActualSprite + i == 128) break; // Stop writing if we've used all 
						    // disponible sprites (128)
		
		Sprites[ActualSprite + i].attribute0 = COLOR_256 | SQUARE | y;
		Sprites[ActualSprite + i].attribute1 = SIZE_8 | x + i * 8;
		Sprites[ActualSprite + i].attribute2 = LettersOffset[LetterPos(text[i])];
	}
	ActualSprite += Length(text);	// Update the position for the next text
}

// Main function
int main()
{
	u16 i;
	
	// Enable mode 4 and sprites in 1D
	SetMode(MODE_4 | OBJ_ENABLE | OBJ_MAP_1D);
	
	// Copy the letters palette to the sprites palette memory
	for (i = 0; i < 256; i++)
		OBJPaletteMem[i] = LETRASPalette[i];
	
	// Set all sprites off screen
	InitializeSprites();
	
	// Load the letters sprite data into the oam
	// In mode 4 the sprites data starts in the 0x2000 offset
	// of OAMdata
	for (i = 0; i < (LETRAS_WIDTH * LETRAS_HEIGHT) / 2; i++)
	{
		OAMdata[i + 0x2000] = LETRASData[i];
        }	
	
	// Initialize the letters offsets
	InitializeLetters();
	
	// Write some text ;)
	WriteText("WRITING TEXT EXAMPLE BY", 12, 12);
	WriteText("Manulon", 18, 24);
	
	WriteText("USED MODE", 12, 40);
	WriteText("Mode 4", 18, 52);
	
	WriteText("THANKS TO", 12, 68);
	WriteText("dovotos tutorials", 18, 80);
	WriteText("gbajunkie tutorials", 18, 92); 
	
	WriteText("DATE", 12, 108);
	WriteText("25/06/03", 18, 120);
	
	WriteText("MANULON 2003", 12, 140);
	
	// Main loop
	while (1)
	{
		WaitForVSync();		// Wait for screen stop drawing
		CopyOAM();		// Copy our sprites data into de OAM
	}	
}

