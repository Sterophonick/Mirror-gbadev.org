WRITE TEXT EXAMPLE BY MANULON (25/06/03)

It's only an example of writing text in the gba using mode 4
and one sprite with all letters.

It's written in C and compiled with devkitadvance.

cabronelquelolea@hotmail.com