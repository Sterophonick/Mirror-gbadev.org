////////////////////////////////////////////////////////////////////////////
//File:		sprites_priority.bin
//Date:		21 - 02 - 2003
//Program:	sprites and priority in mode 1
//Author:		Jenswa
//Thanks to:	gbajunkie, nokturn, dovoto
////////////////////////////////////////////////////////////////////////////

//general stuff and definitions
#include "gba.h"		//GBA register definitions
#include "dispcnt.h"		//REG_DISPCNT register #defines
#include "keypad.h"	//keypad definitions
#include "sprites.h"		//sprites defnitions

//gfx stuff
#include "objpalette.h"	//OBJPalette
#include "ball.h"		//ball sprite
#include "paddle.h"		//paddle sprite

//create an OAM variable and make it point to the address of OAM
u16* OAM = (u16*)0x7000000;

//create and array of sprites
OAMEntry sprites[128];

//some variables

int bx = 120;
int by = 80;
int px = 120;
int py = 80;

//wait for the screen to stop drawing
void WaitForVsync()
{
	while((volatile u16)REG_VCOUNT !=160){}
}

//Copy sprite array to OAM
void CopyOAM()
{
	int x;
	u16* temp;
	temp = (u16*)sprites;
	for(x=0; x < 128*4; x++){
		OAM[x] = temp[x];
	}
}

//set sprite off screen
void InitializeSprites()
{
	int x;
	for(x=0; x < 128; x++){
		sprites[x].attribute0 = 160;	//y > 159
		sprites[x].attribute1 = 240;	//x > 239
	}
}

//move the sprite
void MoveSprite(OAMEntry* sp, int x, int y)
{
	if(x < 0 ){
		x = 512 + x;
	}
	if(y < 0){
		y = 256 + y;
	}

	sp->attribute1 = sp->attribute1 & 0xFE00;		//clear old x value
	sp->attribute1 = sp->attribute1 | x;		//set new x value
	sp->attribute0 = sp->attribute0 & 0xFF00;		//clear old y value
	sp->attribute0 = sp->attribute0 | y;		//set new y value
}

//make sure all sprites are moved
void MoveAllSprites()
{
	MoveSprite(&sprites[0], bx, by);
	MoveSprite(&sprites[1], px, py);
}

//loads the palette of the objects
void LoadOBJPalette()
{
	int x;
	for(x=0; x < 256; x++){
		OBJPaletteMem[x] = OBJPalette[x];
	}
}

//read the gba keypad
void GetInput()
{
	if(KEY_DOWN(KEYLEFT)){
		px--;
		}
	if(KEY_DOWN(KEYRIGHT)){
		px++;
		}
	if(KEY_DOWN(KEYUP)){
		py--;
		}
	if(KEY_DOWN(KEYDOWN)){
		py++;
		}
	if( KEY_DOWN(KEYSTART) ){
		sprites[0].attribute2 = 0 | PRIORITY(1);
		sprites[1].attribute2 = 2| PRIORITY(0);
	}

	if( KEY_DOWN(KEYSELECT) ){
		sprites[0].attribute2 = 0 | PRIORITY(0);
		sprites[1].attribute2 = 2 | PRIORITY(1);
	}
}

int main()
{
	int x;

	SetMode(MODE_1 | OBJ_ENABLE | OBJ_MAP_1D);

	LoadOBJPalette();

	InitializeSprites();

	//ball sprite
	sprites[0].attribute0 = COLOR_256 | SQUARE;
	sprites[0].attribute1 = SIZE_8;
	sprites[0].attribute2 = 0;		//tile pointer

	for(x=0; x < 32; x++){
		OAMData[x] = ballData[x];
	}

	//paddle sprite
	sprites[1].attribute0 = COLOR_256 | TALL;
	sprites[1].attribute1 = SIZE_32;
	sprites[1].attribute2 = 2;		//tile pointer

	for(x=32; x < 288; x++){
		OAMData[x] = paddleData[x-32];
	}

	//main loop
	while(1){
		GetInput();
		MoveAllSprites();
		WaitForVsync();
		CopyOAM();
	}
}
