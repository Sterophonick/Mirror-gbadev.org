------------------------------
Sprites & Priorities
------------------------------

File:		sprites_priority.bin
Date:		21 - 02 - 2003
Program:		sprites and priority
Author:		Jenswa
Contact:		awsnej@hotmail.com
Site:		http://www.geocities.com/flashsite_jrj/gba
		

-----------------------------
About this bin-file:

This is my 9th gba demo,
I have made this file as an example
of setting the priorities of different sprites.


---------------
Features:
One 8x8 sprite,
one 32x16 sprite
and keypad detection


---------------
Controlls:

KEY RIGHT = paddle moves right
KEY LEFT = paddle moves left
KEY UP = paddle moves up
KEY DOWN = paddle moves down
KEY START = paddle in front
KEY SELECT = ball in front


------------------
Debugging:

This file is tested with VisualBoyAdvance
and BoycottAdvance, both work fine.
It has not been tested on hardware, if anyone does,
let me know.


----------------
Thanks to:

Forgotten (VisualBoyAdvance)
Jason Wilkins (Dev-Kit Advance)
Eloist (gba.h)
GBAjunkie
Dovoto
Nokturn
Brian Sowers


---------
Links:

http://www.gbadev.org
http://www.gbaemu.com
http://www.devrs.com/gba
http://www.gbajunkie.co.uk
http://www.loirak.com
http://www.gamedev.net
http://www.thepernproject.com
http://www.cs.rit.edu/~tjh8300/CowBite/CowBiteSpec.htm (CowBite Virtual Harware Specifications)
http://www.work.de/nocash/gbatek.htm - gbatek html version (GBATEK)
http://www.vboy.emuhq.com (VisualBoyAdvance)


------------
Jenswa


-----------------
Disclaimer:
This game is freeware. This software is provided 'as is' with no warranty or guarantees of
any kind, you use this software at your own risk. You accept all responsibility for any 
damage caused as a result of using this software. The author is not liable for any costs 
incurred as a result of using this software.

