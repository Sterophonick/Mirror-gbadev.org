_____________________________________________________________________
This is a simple program to test reading a regular controller and a
DK Bongos controller on the Game Boy Player.

To use the DK Bongos controller with Game Boy Player:
1. Insert Game Boy Player boot disc and supported game into GameCube.
2. Turn on GameCube.
3. Press Z to open the config menu.  Change the controller (third
   option) such that X and Y on the controller press L and R on the
   GBA. Press Z again to close the menu.


� Damian Yerrick
subject to copying conditions in the .c files.
