Asteriods
=-=-=-=-=

  By Chris Adams aka Lithium aka pluto9

Controls
=-=-=-=-

 In Game:

  Left/Right             -> Rotate ship
  Up                     -> Accelerate forward
  L/R                    -> Afterburner
  A                      -> Shoot

Contact
=-=-=-=

   ICQ: 58401399
   MSN: lithium_eadgbe@hotmail.com
   Emails: pluto9@rock.com && lithium@zext.net
   Website: http://lithium.zext.net