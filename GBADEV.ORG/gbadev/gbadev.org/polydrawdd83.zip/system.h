/*
 SYSTEM.H
*/

#ifndef SYSTEM_H
#define SYSTEM_H

//Keypad
#define REG_KEY                  (*(vu16*)0x4000130)
#define REG_P1CNT				 (*(vu16*)0x4000132)

#define KEY_A_PRESSED            (!((REG_KEY) & (1<<0)))
#define KEY_B_PRESSED            (!((REG_KEY) & (1<<1)))
#define KEY_SELECT_PRESSED       (!((REG_KEY) & (1<<2)))
#define KEY_START_PRESSED        (!((REG_KEY) & (1<<3)))
#define KEY_RIGHT_PRESSED        (!((REG_KEY) & (1<<4)))
#define KEY_LEFT_PRESSED         (!((REG_KEY) & (1<<5)))
#define KEY_UP_PRESSED           (!((REG_KEY) & (1<<6)))
#define KEY_DOWN_PRESSED         (!((REG_KEY) & (1<<7)))
#define KEY_R_PRESSED            (!((REG_KEY) & (1<<8)))
#define KEY_L_PRESSED            (!((REG_KEY) & (1<<9)))


//Timer
#define FREQUENCY_0				 0x0
#define FREQUENCY_64			 BIT0
#define FREQUENCY_256			 BIT1
#define FREQUENCY_1024			 BIT0 | BIT1

#define TIMER_CASCADE			 BIT2
#define TIMER_IRQ				 BIT6
#define TIMER_ENABLE			 BIT7
#define REG_TM0D				 (*(vu16*)0x4000100)
#define REG_TM0CNT				 (*(vu16*)0x4000102)
#define REG_TM1D				 (*(vu16*)0x4000104)
#define REG_TM1CNT				 (*(vu16*)0x4000106)
#define REG_TM2D				 (*(vu16*)0x4000108)
#define REG_TM2CNT				 (*(vu16*)0x400010A)
#define REG_TM3D				 (*(vu16*)0x400010C)
#define REG_TM3CNT				 (*(vu16*)0x400010E)


u32 seed=2; 

void InitRandom() {
  // Enable Timer #2 And Set The Increment Frequency To 256 Cycles //
  REG_TM2CNT = (TIMER_ENABLE | FREQUENCY_256);

  // Reset The Timers To 0 So Any Previous Use Of The Timers Are Cleared //
  REG_TM2D = 0;
}

void Randomize() {
  seed = REG_TM2D;
}

signed long rnd(s32 min, s32 max) 
{ 
seed *= 69069; 
return min + ((max - min + 1) * (seed >> 16)) / 0x10000; 
} 


//Interrupts
#define INT_VBLANK				 0x0001
#define INT_HBLANK				 0x0002
#define INT_VCOUNT				 0x0004
#define INT_TIMMER0				 0x0008
#define INT_TIMMER1			     0x0010
#define INT_TIMMER2				 0x0020
#define INT_TIMMER3				 0x0040
#define INT_COMUNICATION		 0x0080 //serial communication interupt
#define INT_DMA0				 0x0100
#define INT_DMA1				 0x0200
#define INT_DMA2				 0x0400
#define INT_DMA3				 0x0800
#define INT_KEYBOARD			 0x1000
#define INT_CART				 0x2000 //the cart can actually generate an interupt
#define INT_ALL					 0x4000 //this is just a flag we can set to allow the function to enable or disable all interrupts. Doesn't actually correspond to a bit in REG_IE

typedef void (*interrupt_handler_t)(); 
typedef interrupt_handler_t *interrupt_handler_ptr_t; 

#define REG_IME					 (*(vu16*)0x4000208) //Interrupt Master Enable
#define REG_IE					 (*(vu16*)0x4000200) //Interrupt Enable (Welche Interrupts sollen verarbeitet werden?)
#define REG_IF					 (*(vu16*)0x4000202) //Interrupt Flags (welcher Interrupt ausgel��t wurde, wichtig zur Auswertung)
#define REG_INTERUPT			 (*((interrupt_handler_ptr_t)0x03007FFC)) 


//Interruptfunktionen
void VBLANK(void);
void KEYBOARD(void);

//Das ist der Interrupt-Handler, vielleicht ist es besser ihn
//im Rom zu haben, da spart man sich immerhin einen long call
void HandleInterrupt() {
  if (REG_IF & INT_VBLANK) {
    VBLANK();
  }
  if (REG_IF & INT_KEYBOARD) {
    KEYBOARD();
  }
}


/*-------enable/disable interupt rutien---------------*/
void EnableInterrupt(u16 interrupt) {
  REG_IME = 0;  //probably not necessary but not a good idea to change interupt registers when an interupt is ocuring
	
  if(interrupt == INT_VBLANK)
	REG_DISP_STAT |= 0x8;
  else if(interrupt == INT_HBLANK)
	REG_DISP_STAT |= 0x10;
  else if(interrupt == INT_KEYBOARD) //Alle Tasten aktivieren
	REG_P1CNT |= BIT14 | BIT0 | BIT1 | BIT2 | BIT3 | BIT4 | BIT5 | BIT6 |  BIT7 | BIT8 | BIT9;

  REG_IE |= interrupt;
  REG_IME = 1;
}

void DissableInterrupts(u16 interrupts) {
  REG_IE &= ~interrupts;

  if(interrupts == INT_ALL) //this is were that ALL comes in
	REG_IME = 0;  //disable all interupts;
}


#endif
//EOF