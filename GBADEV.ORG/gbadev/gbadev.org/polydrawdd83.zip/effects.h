/*
 EFFECTS.H
*/

#ifndef EFFECTS_H
#define EFFECTS_H

//Mosaic effekt
#define REG_MOSAIC					(*(vu32*)0x400004C)
#define REG_MOSAIC_L				(*(vu32*)0x400004C)
#define REG_MOSAIC_H				(*(vu32*)0x400004E)

#define SetMosaic(bh,bv,oh,ov) ((bh)+(bv<<4)+(oh<<8)+(ov<<12))


//Blending effekt
#define REG_BLDMOD					(*(vu16*)0x4000050)
#define REG_COLEV					(*(vu16*)0x4000052)
#define REG_COLEY					(*(vu16*)0x4000054)

#define MODE_NONE			0x00
#define MODE_BLEND			0x01
#define MODE_FADE_IN		0x02
#define MODE_FADE_OUT		0x03

#define TARGET1_BG0			0x01
#define TARGET1_BG1			0x02
#define TARGET1_BG2			0x04
#define TARGET1_BG3			0x08
#define TARGET1_OBJ			0x10
#define TARGET1_BD			0x20

#define TARGET2_BG0			0x100
#define TARGET2_BG1			0x200
#define TARGET2_BG2			0x400
#define TARGET2_BG3			0x800
#define TARGET2_OBJ			0x1000
#define TARGET2_BD			0x2000
#define TARGET2_ALL			0x3F00

#define BlendMode(n)	(n<<6)	

#define Blend(a, b) (REG_COLEV=a|(b<<8))
#define Fade(y)		(REG_COLEY=y)

#endif
//EOF