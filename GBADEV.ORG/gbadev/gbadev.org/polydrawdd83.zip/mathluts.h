/*
 MATHLUTS.H
*/

#ifndef MATHLUTS_H
#define MATHLUTS_H

typedef struct tBGAffineSource { 
     s32 x;     //Original data's center X coordinate (8bit fractional portion) 
     s32 y;     //Original data's center Y coordinate (8bit fractional portion) 
     s16 tX;    //Display's center X coordinate
     s16 tY;    //Display's center Y coordinate 
     s16 sX;    //Scaling ratio in X direction (8bit fractional portion) 
     s16 sY;    //Scaling ratio in Y direction (8bit fractional portion) 
     u16 theta; //Angle of rotation (8bit fractional portion) Effective Range 0-FFFF 
} BGAffineSource; 

typedef struct tBGAffineDest { 
     s16 pa;  //Difference in X coordinate along same line 
     s16 pb;  //Difference in X coordinate along next line 
     s16 pc;  //Difference in Y coordinate along same line 
     s16 pd;  //Difference in Y coordinate along next line 
     s32 x;   //Start X coordinate 
     s32 y;   //Start Y coordinate 
} BGAffineDest; 

#define COS(x) (trigTable[x&255]) 
#define SIN(x) (trigTable[(x+64)&255]) 

FIXED trigTable[256]; 

void InitTrigTable(void) {
  BGAffineSource bgSrc; 
  BGAffineDest bgDest; 
  u16 i; 

  bgSrc.x = 0; 
  bgSrc.y = 0; 
  bgSrc.tX = 0; 
  bgSrc.tY = 0; 
  bgSrc.sX = 256; 
  bgSrc.sY = 256; 

  for(i = 0; i < 256; i++) { 
   bgSrc.theta = (u16)(i<<8); 
   
   asm volatile( "mov r0,%0\n"
	             "mov r1,%1\n"
				 "mov r2,%2\n"
				 "swi 0xe0000\n"
				 :
				 /* no output */
				 :
				 "r" (&bgSrc),
				 "r" (&bgDest),
				 "r" (1)
				 : 
				 "r0",
				 "r1",
				 "r2");
   
   //BgAffineSet(&bgSrc, &bgDest, 1); //use & because they're no longer arrays, so you need to get the address 
   trigTable[i] = bgDest.pa; 
  } 
}

#endif
//EOF