/*
 GBA.H
*/

#ifndef GBA_H
#define GBA_H

#include "general.h"
#include "screen.h"
#include "system.h"
#include "effects.h"
#include "mathluts.h"
#include "sprites.h"
#include "dma.h"

extern s32 fMul(s32 a, s32 b);
extern s32 iDiv(s32 a, s32 b);

#endif
//EOF