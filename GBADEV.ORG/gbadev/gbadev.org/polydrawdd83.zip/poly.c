//written by Marius Schmidt - lupin003[@]gmx[.]de

//Polygon drawing
//This code features
//-Hardware Sin/Cos
//-flipped mode 5
//-Random number generation
//-Polygon drawing
//-interrupts

#include "gba.h"

//comment this out to draw on every vblank
//#define DRAW_ON_KEYBOARD

//Structure for position vector
 typedef struct tvec2 {
   s32 X, Y;
 } vec2,*pvec2;

//////////////////////////////////////////////////////////////////////////

//Entry
void AgbMain(void) {
  InitRandom();
  InitTrigTable();

  //Interrupt stuff
  REG_INTERUPT = HandleInterrupt;
  EnableInterrupt(INT_VBLANK);
  EnableInterrupt(INT_KEYBOARD);

  m5setflip();

  Randomize();

  //Mainloop
  while(1) { /* nothing */ }
}

void polyc(u32 x1, u32 y1, u32 x2, u32 y2, u32 x3, u32 y3, u16 c) {
s32 p1x, p1y, p2x;

s32 d1xx, d1xS;
s32 d1xAbs, d1yAbs;

s32 d2xx, d2xS;
s32 d2xAbs, d2yAbs;

u32 i, p, swap;

  if(y2<y1) {
    swap=x2;
	x2=x1;
	x1=swap;

	swap=y2;
	y2=y1;
	y1=swap;
  }
  if(y3<y1) {
    swap=x3;
    x3=x1;
	x1=swap;

	swap=y3;
	y3=y1;
	y1=swap;
  }
  if(y3<y2) {
	swap=x3;
	x3=x2;
	x2=swap;

	swap=y3;
	y3=y2;
	y2=swap;
  }

  p2x=p1x=x1;
  p1y=y1;

  //first line
  d1xAbs = x2-x1;
  if (d1xAbs<0) {
    d1xAbs = -d1xAbs;
	d1xS=-1;
  } else {
	d1xS=1;
  }

  d1yAbs = y2-y1;
  if (d1yAbs<0)
	d1yAbs = -d1yAbs;

  d1xx = d1xAbs>>1;

  //second line
  d2xAbs = x3-x1;
  if (d2xAbs<0) {
    d2xAbs = -d2xAbs;
	d2xS=-1;
  } else {
	d2xS=1;
  }

  d2yAbs = y3-y1;
  if (d2yAbs<0)
	d2yAbs = -d2yAbs;

  d2xx = d2xAbs>>1;

  //draw first part of triangle
  for(i=0;i<d1yAbs;i++) {
    d1xx+=d1xAbs;
res1:
	if(d1xx>=d1yAbs) {
	  d1xx-=d1yAbs;
	  p1x+=d1xS;
	  if (((p1x<x2) && (d1xS>0)) || ((p1x>x2) && (d1xS<0)))
		  goto res1;
	}

    d2xx+=d2xAbs;
res2:
	if(d2xx>=d2yAbs) {
	  d2xx-=d2yAbs;
	  p2x+=d2xS;
	  if (((p2x<x3) && (d2xS>0)) || ((p2x>x3) && (d2xS<0)))
		  goto res2;
	}
	p1y+=1;
	
	for(p=p1x;p<p2x;p++)
	  VideoBuffer[p*160+p1y] = c;
  }


  //third line
  d1xAbs = x3-x2;
  if (d1xAbs<0) {
    d1xAbs = -d1xAbs;
	d1xS=-1;
  } else {
	d1xS=1;
  }

  d1yAbs = y3-y2;
  if (d1yAbs<0)
	d1yAbs = -d1yAbs;

  d1xx = d1xAbs>>1;


  //draw second part of triangle
  for(;i<d2yAbs;i++) {
    d1xx+=d1xAbs;
res3:
	if(d1xx>=d1yAbs) {
	  d1xx-=d1yAbs;
	  p1x+=d1xS;
	  if (((p1x<x3) && (d1xS>0)) || ((p1x>x3) && (d1xS<0)))
		  goto res3;
	}

    d2xx+=d2xAbs;
res4:
	if(d2xx>=d2yAbs) {
	  d2xx-=d2yAbs;
	  p2x+=d2xS;
	  if (((p2x<x3) && (d2xS>0)) || ((p2x>x3) && (d2xS<0)))
		  goto res4;
	}
	p1y+=1;
	
	for(p=p1x;p<p2x;p++)
	  VideoBuffer[p*160+p1y] = c;
  }

}



//Hier geht der Punk ab
void VBLANK() {
#ifndef DRAW_ON_KEYBOARD
  u32 vals[9];

  //Generate some random numbers
  vals[0] = rnd(0,120);
  vals[1] = rnd(0,160);
  vals[2] = rnd(0,120);
  vals[3] = rnd(0,160);
  vals[4] = rnd(0,120);
  vals[5] = rnd(0,160);
	
  vals[6] = rnd(0,31);
  vals[7] = rnd(0,31);
  vals[8] = rnd(0,31);
  
  //Draw the poly twice, because we want to see it on both buffers
  polyc(vals[0],vals[1],vals[2],vals[3],vals[4],vals[5],RGB(vals[6],vals[7],vals[8]));
  m5swap();
  polyc(vals[0],vals[1],vals[2],vals[3],vals[4],vals[5],RGB(vals[6],vals[7],vals[8]));
#else
  m5swap();
#endif
}

//Eingabe-Interrupt
void KEYBOARD(void) {
#ifdef DRAW_ON_KEYBOARD
  u32 vals[9];

  //Generate some random numbers
  vals[0] = rnd(0,120);
  vals[1] = rnd(0,160);
  vals[2] = rnd(0,120);
  vals[3] = rnd(0,160);
  vals[4] = rnd(0,120);
  vals[5] = rnd(0,160);
	
  vals[6] = rnd(0,31);
  vals[7] = rnd(0,31);
  vals[8] = rnd(0,31);
  
  //Draw the poly twice, because we want to see it on both buffers
  polyc(vals[0],vals[1],vals[2],vals[3],vals[4],vals[5],RGB(vals[6],vals[7],vals[8]));
  m5swap(); //Swap to other buffer
  polyc(vals[0],vals[1],vals[2],vals[3],vals[4],vals[5],RGB(vals[6],vals[7],vals[8]));
  m5swap(); //Swap to current buffer
#endif

//no specific keys
//  if (KEY_RIGHT_PRESSED) {
//  }
//  if (KEY_LEFT_PRESSED) {
//  }
//  if (KEY_UP_PRESSED) {
//  }
//  if (KEY_DOWN_PRESSED) {
//  }

REG_IF = INT_KEYBOARD;
Randomize(); //get a new seed
}


////