Tweakmode 3d Demo part II
Total rewrite in thumb/arm assembler
and shrunk down to 1024 bytes!
by MrMr[iCE]

Basically started out as a "what if" on cutting crt0.s and linkscrpt
down to bare minimal size, and then turned out rewriting the whole
thing in assembler. The final result fits in exactly 1024 bytes, with
a valid rom header. The rom generates a sin/cos and 1/z lookup tables
on the fly, does a copper effect to color the background, rotates 1000 
vectors per frame and renders them to a tweaked mode 4 bitmap, and does 
emu/hw detection to adjust palette for crt or gba lcd. Source and makefile 
included, enjoy. 


Details on the tweaked mode 4:
160x120 pixels, mode is rotated 90 degrees, flipped and scaled to fit
on the lcd. The rendering is all done in the backbuffer page of mode 4,
so you can do video mode splits and use first 38400 bytes of vram for 
tile graphic overlays, etc. Look for my first tweakmode release that
shows this technique with tile overlays on the top and bottom of the
screen.


NOTE: Please read the comments in crt0.s before attempting to modify
the code and recompiling, there are certain things to do to make the
rom work properly with a bios. The packed in rom works fine on vba,
mappy, and hardware.


Props to Joat for helping me optimize the demo!
