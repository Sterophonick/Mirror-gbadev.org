------------------------------------------------------------------------------
CowBite VIIa
CowBite Copyright 2002 Thomas Happ
SorcererXIII&yahoo.com
http://cowbite.emuunlim.com
------------------------------------------------------------------------------

Requirements:
-------------
- Windows 98/NT/2K/XP (untested on other windows)
- 16 bit (high color) display
- PII/PIII/Athlon CPU

Recommended:
- Windows 2K
- Resolution of 1024 x 768 or higher

ALSO NOTE:  
As you update CowBite, you may want to remove the old "CowBite.cfg" file
created by older versions of CowBite.  I have just added something that should
help prevent errors with this, but it won't work for anything older than
this pre alpha.


Usage:
------

CowBite [romname]
cowbite.sh [romname]	#For cygwin users


Instructions:
-------------
The Basics
To play a ROM, click the "load" button and choose a file.  Unless CowBite
is paused or in Debug mode, the ROM will begin playing.  You can set your
keyboard and joystick controls using the input menu.  There are a variety of 
other basic features like screen size (I, II, or III), interpolation
(using Kreed's Super Eagle or 2xSaI), frameskip, and save/load states.
Probably you can figure all of these out just by clicking around.  

Debugger
If you have the debugger open, you're in debug mode.  The main debugger
window has an ARM disassembler, a memory browser, a listing of registers,
and the means to set and remove breakpoints.

Dynamic Update
Choose whether and how often you want your debug views to refresh.  You'd
be surprised at how good your eye is at catching problems as code flashes past.
That is why this is here.

Source
If you open an ELF file that was compiled with the -gstabs option, CowBite
can load your source, allowing you to view it normally or mixed with Asm.
CowBite looks for the source relative to the directory the ELF file is in.
Let me know if you have issues with CowBite being unable to find or open source
files.

Variables
This allows you to browse local, static, and global variables, functions,
and any other ELF or stabs symbols embedded in your executable.

Console
This is a new feature.  You can view console output (dprint is now supported)
by choosing "View Console" from the debug menu.  Alternately, if you start
CowBite in cygwin using the "cowbite.sh" script, the output will also go to
stdout, which you can view in your cygwin window or pipe into other cygwin tools.

Conditional Breakpoints
In the Advanced Breakpoints dialog, you can set breakpoints on several
simple conditions like "register == register" or "*address == constant".

View Hardware Registers
This option lets you view the GBA registers in a fashion similar to Mappy's
register viewer.  In the future it will also provide additional information
specific to each individual register (i.e. the meaning of the various bit
flags, etc.)

View Statistics
As CowBite runs it collects statistics on interrupts, memory accesses,
DMA transfers, sound, etc.  This window is designed to present this information
in a concise format.


About ELF and stabs
-------------------
If you're using gcc, you can compile programs with the -gstabs option in order
to get stabs symbol support.  Probably you have gcc set up to create
ELF files by default and then convert it to raw binary format using "objcopy",
but you may need to edit your makefile so as not to delete the original ELF
after the conversion has been made.  ELF files made with -gstabs contain extra
information that allows CowBite to perform source level debugging.

There may be a problem with ELF files compiled for multiboot support.
I have implemented a fix to this problem that works in my own test cases, but
there may be an unforseen situation in which this fix does not work.  If you
encounter a situation where a program doesn't work when you compile for multiboot,
let me know so that I can ponder it some more.


Unimplemented:
-----------------------
- Many BIOS calls
- Alpha blends on anything other than semitransparent sprites, fades
- Sound 1 - 4
- Keyboard interrupts
- Anything to do with link cables
- Disallowing ROM writes
- EEPROM
- Correct CPU cycle timings


Known Bugs:
-----------------------
- Problems loading anything with a space in the path
- Sprite and background bugs (i.e. in some demos they update strangely
or just looked messed up.)  If you think you know why this is, let me know.
- Source windows sporadically stop working.  I have no clue why this is.

Suspected Bugs:
-----------------------
Flaws in DMA implementation?
Flaws in CPUSet and CPUFastSet



I might have forgotten something or just missed it altogether.
Let me know if you find other things that don't work.


Notice:
-------
Piracy is illegal.  I don't think CowBite can even run any commercial games,
but even so, don't bother trying.

Do NOT ask me for ROMs or where you can find them.

This version of CowBite is freeware.  In fact, all versions of CowBite will
most likely be free.  Distribute them as you see fit, but include this file.

(Far) In the future I will also be including the source (possibly under GPL).


Special Thanks (in no pariticular order):
---------------
- Kreed (Derek Liauw) for his SuperEagle and Super2xSaI engines
- Agent Q
- All those GBA demo authors. You rock!
- Every other emu author
- www.gbadev.org and everyone involved (Simon especially)
- The gbadev list on yahoo
- Dovoto and the PERN Project
- Jeff Frohwein and his Devrs.com site
- Nocturn and his tutorial
- Uze from BeLogic for all the great information on the GBA's sound!
- Nintendo 
- Costis (A variety of new info/corrections)
- Grauw (Info on forced blanking, hblank lenghths, and on the BIOS wait function.)
- Max
- Mike/gbcft (LOTS of info on interrupts and on windowing)
- Otaku
- Yarpen (Almost all the information on the timer registers and the keyboard control register. Thanks!)
- Eloist and the EloGBA emulator, for having open source.  CowBite's initial CPU core was
influenced by EloGBA r1.  Now of course it's nothing like it, but all the same, open
source is good, and I hope to release the CowBite source once it's coherent.
- Marat Fayzullin for having cool tutorials
- Stea Greene for helping me learn Xlib
- CoRE (Comptuers, Robotics, and Engineering) for a billion things
- Jim Heliotis for having such a cool computer architecture course
- Nick Wolven and Mike Kaplan for testing
