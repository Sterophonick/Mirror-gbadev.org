this is a little texturemapping-demo.
it demonstrate the difference bitween
linear- and perpective mapping.
just a test.

greatings.
