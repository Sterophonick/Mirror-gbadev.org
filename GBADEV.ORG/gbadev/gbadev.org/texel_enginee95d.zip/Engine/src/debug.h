#ifndef _incl_debug
#define _incl_debug
/////////////////////////////////

#ifdef WARNINGS
#define WARN(args...)	BEGIN dbg_showconsole(); printf(args); END
#else
#define WARN(args...)	DUMMY
#endif

#ifdef DEBUGGING
extern bool debug_malloc;
#endif

#define dtimer_num 12
#define dtimer_max (dtimer_num-1)

extern s8 dbg_screen_active;
extern int dbgobject_select;
////////////////////////////////
void dprint_prepare(void);

#ifndef DEBUGGING
#define printf(...)					DUMMY
#define dtstart(x)					DUMMY
#define dtstop(x)					DUMMY
#define dtstopa(x)					DUMMY
#define dtstopr(x,y)				DUMMY
#define dtstopar(x,y)				DUMMY
#define dtresetall()				DUMMY
#define dbg_screen()				DUMMY
#define dhalt(x)					DUMMY
#define debug_checkmemsize()		DUMMY
#define dbg_stackchk_init()			DUMMY
#define dbg_stackchk()				DUMMY

#define debugnum(n,x)				DUMMY
#define debugnuminc(n)				DUMMY
#define dbg_showconsole()			DUMMY
#define log_objecthdr(x,y)			DUMMY
#define log_object(x,y)				DUMMY

#define	dprint(x)					DUMMY

#else

#define debugnum(n,x)	({debug[(n)]=(x);})
#define debugnuminc(n)	({debug[(n)]++;})

void debug_checkmemsize(void);

void dbg_screen(int dif,PLAYERINFO *Player);
void dtstart(int nr);
void dtstopr(int nr, int ref);
void dtstopar(int nr, int ref);
void dtstop(int nr);
void dtstopa(int nr);
void dtresetall(void);

void dprint(char *s);

void dbg_stackchk_init(void);
void dbg_stackchk(void);

void dhalt(int color);

void dbg_showconsole(void);

#define debug_num 5
extern int debug[debug_num];

extern int dbg_selected_trigger;
extern int dbg_selected_trigger_activated;

void log_object(OBJECT *obj, char *hdr);

#include "debug_screens.h"

#endif

/////////////////////////////////
#endif
