#ifndef	__screen_H
#define	__screen_H
#include <agb.h>

void	Screen_init(int width,int height,int colors);
void	Screen_free();

void	Screen_setPalette(u16 *palette);
unsigned char *Screen_getBackBuffer();
int		*Screen_getPalette32();
short	*Screen_getPalette16();
int		Screen_getWidth();
int		Screen_getHeight();
void	Screen_activate(void (*routine)());

extern	void	(*Screen_looproutine)();
extern	int	Screen_Width,Screen_Height,Screen_Colors;
extern	short	*Screen_Palette16;
extern	int		*Screen_Palette32;
extern	u32		*Screen_BackBuffer;

#endif
