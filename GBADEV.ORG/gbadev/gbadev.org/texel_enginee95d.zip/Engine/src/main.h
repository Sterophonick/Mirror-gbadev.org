#ifndef _main_H
#define _main_H

#include <Agb.h>
#include <stdarg.h>
#include <stdlib.h>
#include <stdio.h>
#include <string.h>

#include "testswitches.h"
#include "typen.h"
#include "debug.h"
#include "malloc.h"

#define NULL 0

#define	GBA

#define BEGIN	do {
#define END		} while (0)
#define DUMMY BEGIN END

#define EWRAM __attribute__ ((section (".ewram"))) 
#define CODE_IN_ROM __attribute__ ((section (".text")))
#define CODE_IN_EWRAM __attribute__ ((section (".ewram"), long_call))
#define CODE_IN_IWRAM __attribute__ ((section (".iwram"), long_call))
#define VAR_IN_IWRAM __attribute__ ((section (".iwram"))) = {0}

#define newline "\x00A "

#define VCount_LimitLoop() ({if (!MultiplayerMode && VBlankIntr_happened) break; })


#define COPYn32(src,dest,size)		CpuCopy(src,dest,size,32)
#define FILLn32(data,dest,size)		CpuClear(data,dest,size,32)
#define ZEROn32(dest,size)			FILLn32(0,dest,size)

#define COPYa32(src,dest)			CpuArrayCopy(src,dest,32)
#define FILLa32(data,dest)			CpuArrayClear(data,dest,32)
#define ZEROa32(dest)				FILLa32(0,dest)

#define COPYn16(src,dest,size)		CpuCopy(src,dest,size,16)
#define FILLn16(data,dest,size)		CpuClear(data,dest,size,16)
#define ZEROn16(dest,size)			FILLn16(0,dest,size)

#define COPYa16(src,dest)			CpuArrayCopy(src,dest,16)
#define FILLa16(data,dest)			CpuArrayClear(data,dest,16)
#define ZEROa16(dest)				FILLa16(0,dest)

#define	COPYn256(src,dest,size)		CpuFastCopy(src,dest,size)
#define FILLn256(data,dest,size)	CpuFastClear(data,dest,size)
#define ZEROn256(dest,size)			FILLn256(0,dest,size)

#define COPYa256(src,dest)			CpuFastArrayCopy(src,dest)
#define FILLa256(data,dest)			CpuFastArrayClear(data,dest)
#define ZEROa256(dest)				FILLa256(0,dest)

//////////////////////////////////////////////////////////////////////////
extern volatile	bool videodata_ready;
extern volatile	bool videodata_missed;
extern volatile	bool VBlankIntr_happened;

//////////////////////////////////////////////////////////////////////////
extern bool show_debugpos;
extern int Counting;

#define limit(value,max)	BEGIN int _max= (max); if ((value)>_max) (value)= _max; END;

void	Sync(void);
extern u16 _Trg, _Cont;
int KeyReadDirect(void);


#define RandomRangeVar(base, variation)	((base) - (variation)/2 + Random()%(variation))
#define	Random()	rand()

u32		Sqrt32Fast(u32 ii);

extern	char const* Spiel_anhalten;
void	Spiel_Anhalten(PLAYERINFO *Player);

extern	int StartLevel; 
extern	u8	Menu_Stop;

void Make_Pal(u16 const* src,u16 * dest,int count);

//  !!!! niemals die Reihenfolge �ndern:	dir_up, dir_dn, dir_lf, dir_rg
#define dir_up -32
#define dir_dn +32
#define dir_lf -1
#define dir_rg +1

//  !!!! niemals die Reihenfolge �ndern:	dc_up, dc_dn, dc_lf, dc_rg
#define dc_up 0x00
#define dc_dn 0x01
#define dc_lf 0x02
#define dc_rg 0x03

#define	IdentifyFlash	IdentifyFlash_512K

//////////////////////////////////////////////////////////////////////////
// Includes, die man sowieso fast �berall braucht:

#endif

