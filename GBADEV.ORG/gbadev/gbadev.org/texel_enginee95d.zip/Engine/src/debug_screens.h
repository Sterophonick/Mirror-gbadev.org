#ifndef _inc_debug_screens_h
#define _inc_debug_screens_h

enum dbgscreens {
		dbg_screenid_gen
	,	dbg_screenid_obj
	,	dbg_screenid_ditem
	,	dbg_screenid_mem
	,	dbg_screenid_trigger
	,	dbg_screenid_collectors
	,	dbg_screenid_inventory
	,	dbg_screenid_werte
	,	dbg_screenid_attackplaces
	,	dbg_screenid_timer
	,	dbg_screenid_monsterpal
	,	dbg_screenid_monster

	,	dbg_screenid_test
	,	dbg_screenid_vram

,dbg_screen_num
};


#endif // _inc_debug_screens_h
