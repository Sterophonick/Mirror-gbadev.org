#ifndef _inc_bitfilds_h
#define _inc_bitfilds_h

#include <string.h>

#define BIT(x)	(1<<(x))
#define	b_set(b,x)		BEGIN (b)|= BIT(x); END
#define	b_clr(b,x)		BEGIN (b)&=~BIT(x); END
#define b_isset(b,x)	(((b)&BIT(x))!=0)

#define bf_u8size(bits)			(((bits)+7)/8)
#define bf_u32size(bits)		(((bits)+31)/32)
#define bf_alloc(bits)			(u32*)Malloc(bf_u8size(bits))
#define bf_init(bf)				BEGIN CpuArrayClear(0,bf,32); END
#define bf_initsize(bf, bits)	BEGIN memset(bf, 0, bf_u8size(bits)); END
#define bf_initdyn(bf, bits)	BEGIN if (bf) free(bf); bf=bf_alloc(bits); bf_initsize(bf,bits); RM_RETAGTHIS(bf); END
#define bf_isset(bf,x)			((((u32*)bf)[(x)/32]&   (1<<((x)%32)))!=0)
#define bf_set(bf,x)			BEGIN ((u32*)bf)[(x)/32]|=   1<<((x)%32); END
#define bf_clr(bf,x)			BEGIN ((u32*)bf)[(x)/32]&= ~(1<<((x)%32)); END
#define bf_setrange(bf,x0,x1)	BEGIN int i; for (x=x0; x<x1; x++) bf_set(bf,x); END

int		bf_compress(u32* bf, int bflen, u8 *buf, int max);	// buf==NULL -> Nur die ben�tigte Gr��e berechnen
int		bf_decompress(u32* bf, int bflen, u8 *buf);


extern u32 bit_seq_tbl[33];
// alle Bits von Bit b (unteres) bis EXKLUSIVE Bit a (oberes) setzen
#define bit_seq(a,b) ((a>=b)?(bit_seq_tbl[(a)-(b)]<<(b)):(~(bit_seq_tbl[(b)-(a)]<<(a))))
#define bit_seq_save(a,b)  ({int _a=(a)&31,_b=(b)&31;bit_seq(_a,_b);})
u32		bit_seq_save2(int a, int b);


#define bfc_nomax 0x7FFFFFFF

u8	*bf_save	(u32 *bf, int num);
void bf_restore	(u32 *bf, int num, u8 *buf);
u8	*df_save	(u32 *bf, int num);
void df_restore	(u32 *bf, int num, u8 *buf);

void bf_saveto(u32 *bf, int num, u8 *buf, int max);
void df_saveto(u32 *bf, int num, u8 *buf, int max);


int bf_compress(u32* bf, int bflen, u8 *buf, int max);
int bf_savesize(u32* bf, int bflen);
int df_savesize(u32* bf, int num);

int random_bit(u32 bits);	// w�hlt zuf�llig ein gesetztes Bit aus 'bits' und liefert dessen Bitnummer (0..32) oder -1, wenn keins gefunden
// (geht per Div.&Conquer durch bits, also max. log2(32)=5 Tests)


#endif
