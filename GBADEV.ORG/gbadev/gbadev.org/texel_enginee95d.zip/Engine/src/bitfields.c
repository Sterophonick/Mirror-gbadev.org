#include "main.h"

u32 bit_seq_tbl[33] = 
	{	0x00000000,
		0x00000001,0x00000003,0x00000007,0x0000000f,
		0x0000001f,0x0000003f,0x0000007f,0x000000ff,
		0x000001ff,0x000003ff,0x000007ff,0x00000fff,
		0x00001fff,0x00003fff,0x00007fff,0x0000ffff,
		0x0001ffff,0x0003ffff,0x0007ffff,0x000fffff,
		0x001fffff,0x003fffff,0x007fffff,0x00ffffff,
		0x01ffffff,0x03ffffff,0x07ffffff,0x0fffffff,
		0x1fffffff,0x3fffffff,0x7fffffff,0xffffffff
	};

u32 bit_seq_save2(int a, int b) 
{ 
	int d, al=a&31, bl=b&31;
	d=al-bl;

	if (d>=0)
	{	
		if (a>=b+32) return 0xFFFFFFFF;
		return	 bit_seq_tbl[+d]<<bl;
	} 
	else
	{	
		if (b>=a+32) return 0xFFFFFFFF;
		return ~(bit_seq_tbl[-d]<<al);
	}
}


//////////////////////////////////////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////////////////////////
int bf_compress(u32* bf, int bflen, u8 *buf, int max)
{
	int len=0;
	u32 data;
	u32 mask;
	bool storing_state= true;
	int count;

#define store(datax)	({if (buf) {if (len>=max) return -1; buf[len++]=datax;} else len++;})
	#define dumpc(datac)	({store(datac); count-=datac;})

	#define dump()	\
	({	\
		while (count>255)	{dumpc(255); store(0);}	\
		dumpc(count);	\
		storing_state= !storing_state;	\
	})


	count= 0;

	data= *bf;
	mask= 1;
	int acount=0;

	while (bflen>0)
	{
		bool state= (data&mask)!=0;
		
		if (state!=storing_state)	dump();		// bisherigen Counter ablegen und Zustand (0<->1) wechseln (inkl. count-Reset)
		count++;
		acount++;

		mask<<=1;
		if (!mask)	{bf++; data=*bf; mask=1;}
		bflen--;
	}
	dump();	// Restcounter ablegen

	return len;
}

int bf_savesize(u32* bf, int bflen)
{
	return bf_compress(bf, bflen, NULL, bfc_nomax);
}

int df_savesize(u32* bf, int num)
{
	return bf_compress(bf, num*8, NULL, bfc_nomax);
}

/*
//////////////////////////////////////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////////////////////////
int bf_compressdelta(u32* bfo, u32* bf, int bflen, u8 *buf, int max)
{
	int len=0;
	
	#define store(datax)	({if (len>=max) return -1; buf[len++]= datax|(current_state<<6);})
	#define dumpc(datac)	({store(datac); count-=datac;})

	#define dump()	\
	({	\
		while (count>63)	dumpc(63);\
		dumpc(count);	\
	})


	int count= 0;

	u32 data = *bf;
	u32 datao= *bfo;
	u32 mask= 1;

	StoringState current_state= sNop;

	while (bflen)
	{

		StoringState state;
		if		((data&mask) == (datao&mask))	state= sNop;
		else if  (data&mask)					state= sSet;
		else									state= sClr;

		
		if (state!=current_state)	dump();		// bisherigen Counter ablegen und Zustand (0<->1) wechseln (inkl. count-Reset)
		count++;

		mask<<=1;
		if (!mask)	{bf++; data=*bf; datao=*bfo; mask=1;}
		bflen--;
	}
	dump();	// Restcounter ablegen

	return len;
}

//////////////////////////////////////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////////////////////////
// �bertr�gt nur die �nderungen ins Bitfeld bf (zur statischen Variante)
// (statische Variante mu� bereits ins Bitfeld bf reinkopiert worden sein)
// (mu� mit compressdelta() erzeugt worden sein)
typedef enum {sSet,sClr,sNop} StoringState;
void bf_decompressdelta(u32* bf, int bflen, u8 *buf)
{
	int bf0= 0;
	int bf1= 32;
	while(bflen)
	{
		int count= *buf;
		buf++;

		StoringState state= count>>6;
		count&= 63;

		if (state==sNop)
		{
			bflen-= count;
			bf+= count/32;
			int n= count%32;
			bf0+= n;
			bf1-= n;
			continue;
		}

		bflen-= count;

		while (count)
		{
			int n;
			if (count>bf1)	n= bf1;
			else			n= count;

			u32 mask= bit_seq_tbl[n]<<bf0;
			if (state==sSet)	*bf|= mask;
			else				*bf&=~mask;

			bf0+=n;
			bf1-=n;
			if (bf1<=0)		{bf++;  bf1=32; bf0=0;}

			count-= n;
		}

	}
}
*/

//////////////////////////////////////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////////////////////////
int bf_decompress(u32* bf, int bflen, u8 *buf)
{
	u8 *buf_start= buf;

	bool storing_state= true;

	int bf0= 0;
	int bf1= 32;
	while(bflen>0)
	{
		int count= *buf;
		buf++;

		if (count>bflen)	
			WARN("WARNING: bf_decompress: count %i > %i bflen !"newline, count, bflen);

		while (count>0 && bflen>0)
		{
			int n;

			if (count>bf1)	n= bf1;
			else			n= count;

			if (bflen>=32)
			{
				if (storing_state)	*bf|= 0xFFFFFFFF<<bf0;
				else				*bf&= 0xFFFFFFFF>>bf1;
			}
			else
			{	// bflen<32
				int l= n;	if (l>bflen) l= bflen;
				u32 mask= bit_seq(bf0+l,bf0);

				if (storing_state)	*bf|= mask;
				else				*bf&= ~mask;
			}

			bf0+=n;
			bf1-=n;
			if (bf1<=0)		{bf++;  bf1=32; bf0=0;}

			count-= n;
			bflen-= n;
		}
		if (count!=0) 
			WARN("WARNING: bf_decompress: count=%i != 0 at end of iteration!"newline, count);

		storing_state= !storing_state;
	}
	if (bflen!=0) 
		WARN("WARNING: bf_decompress: bflen=%i != 0 at exit!"newline, bflen);

	return buf-buf_start;
}

//////////////////////////////////////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////////////////////////
u8 *bf_save(u32 *bf, int num)
{
	#define tempbufmax 512
	u8  tempbuf[tempbufmax];

	int len= bf_compress(bf, num, tempbuf, tempbufmax);
	if (len==-1)	
	{
		WARN("WARNING: bf_save failed!"newline); 
		return NULL;
	}
	else
	{
		u8 *data= (u8*)Malloc(len);
		memcpy(data, tempbuf, len);
		return data;
	}
}

//////////////////////////////////////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////////////////////////
void bf_saveto(u32 *bf, int num, u8 *buf, int max)
{
	int len= bf_compress(bf, num, buf, max);
	if (len==-1)	
		WARN("WARNING: bf_saveto failed!"newline); 
}

//////////////////////////////////////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////////////////////////
void df_saveto(u32 *bf, int num, u8 *buf, int max)
{
	int len= bf_compress(bf, num*8, buf, max);
	if (len==-1)	
		WARN("WARNING: df_saveto failed!"newline); 
}

//////////////////////////////////////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////////////////////////
void bf_restore(u32 *bf, int num, u8 *buf)
{
	if (!buf)	return;
	bf_decompress(bf, num, buf);
	free(buf);
}

//////////////////////////////////////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////////////////////////
u8 *df_save(u32 *df, int num)
{
	#define tempbufmax 512
	u8  tempbuf[tempbufmax];

	int len= bf_compress(df, num*8, tempbuf, tempbufmax);
	if (len==-1)	return NULL;
	else
	{
		u8 *data= (u8*)Malloc(len);
		memcpy(data, tempbuf, len);
		return data;
	}
}

//////////////////////////////////////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////////////////////////
void df_restore(u32 *df, int num, u8 *buf)
{
	if (!buf)	return;
	bf_decompress(df, num*8, buf);
	free(buf);
}

////////////////////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////////////////////
int random_bit(u32 bits)
{
	u32 control= Random();

	u32 basemask= 0xFFFFFFFF;
	int len= 32;
	int ofs= 0;

	while (bits && len>1)
	{
		len/=2;
		basemask>>=len;
		if (control&1)	
		{
			if (bits&(basemask<<(ofs+len)))	ofs+=len;
		}
		else
			if (!(bits&(basemask<<ofs)))	ofs+=len;

		control>>=1;
		
		bits&= basemask<<ofs;
	}

	return (len==1)?ofs:-1;
}
