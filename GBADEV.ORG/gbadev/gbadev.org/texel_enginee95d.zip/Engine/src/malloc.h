#ifndef _inc_malloc_h
#define _inc_malloc_h

#if 0
#include "slh_AllocGCC.h"
#define memmanager_init	slh_Alloc_Initialize
#define memallocate		slh_Alloc_Alloc
#define free			slh_Alloc_Free
#endif

#if 0
#include "SoMemManager.h"
#define memmanager_init		SoMemManagerInit
#define	memallocate			SoMemManagerAlloc
#define	free				SoMemManagerFree
#endif

#ifndef memmanager_init
#define memmanager_init()
#define	memallocate(x)			malloc(x)
#define msize(x)				malloc_usable_size(x)
#endif

////////////////////////////////////
#ifdef DEBUGGING
	#define MALLOC_DEBUG
	#include "rmalloc.h"
	extern int Malloc_num;
#else
	#include "rmalloc.h"
#endif
////////////////////////////////////

//////////////////////////////////////////////////////////////////////////
#ifdef MALLOC_DEBUG

u8	*Malloc_internal(u32 Mem, char *tag, bool Malloc_accept0);

extern u8*		Malloc_lastalloced;
//#define	Malloc(x) (Malloc_internal(x),RM_RETAG(Malloc_lastalloced),Malloc_lastalloced)
//#define	Mallocd(p,x) ({(u8*)p=Malloc_internal(x); RM_RETAGTHIS(p);})

#define	Malloc(x) Malloc_internal((x), RM_FILE_POS, false)
#define	Mallocd(p,x) ({(u8*)p=Malloc_internal((x), STRINGIZE(p), true); })
#define	Malloc0(x) Malloc_internal((x), RM_FILE_POS, false)
#define	Mallocd0(p,x) ({(u8*)p=Malloc_internal((x), STRINGIZE(p), true); })

#else

u8*		Malloc_internal(u32	Mem, bool Malloc_accept0);
#define	Malloc(x) Malloc_internal(x, false)
#define	Mallocd(p,x) ({(u8*)p=Malloc_internal(x,true); })
#define	Malloc0(x) Malloc_internal(x, false)
#define	Mallocd0(p,x) ({(u8*)p=Malloc_internal(x,true); })
#define RM_RETAGTHIS(p)
#define RM_RETAGS(x,y)
#define RM_RETAGS2(x,y,z)

#endif
//////////////////////////////////////////////////////////////////////////


#endif // _inc_malloc_h
