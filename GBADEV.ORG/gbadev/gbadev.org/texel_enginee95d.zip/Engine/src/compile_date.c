#include "main.h"

#define FUNCTIONIZE(a,b)  a(b) 
#define STRINGIZE(a)      #a
#define INT2STRING(i)     FUNCTIONIZE(STRINGIZE,i)

char const *compile_date_string= __DATE__ ", " __TIME__;
char const *version_code_string= INT2STRING(versioncode);

char const *header_string=
		"Demon Hunter (VCode: %s)"newline
		   "- Compiled: %s"newline
//		   "- Timestamp of " __FILE__ ": " INT2STRING(__TIMESTAMP__) newline
			#ifdef FINAL
		   "- FINAL"
			#else
				"- TestVersion"
				",\tDebugging "
				#ifdef DEBUGGING
				"ON"
				#else
				"OFF\t"
				#endif

				",\tMemDebugging "
				#ifdef MALLOC_DEBUG
				"ON"
				#else
				"OFF\t"
				#endif

				",\tWarnings "
				#ifdef WARNINGS
				"ON"
				#else
				"OFF"
				#endif

				",\tLevelImport "
				#ifdef FINAL_LEVELS
				"OFF"
				#else
				"ON"
				#endif

				",\tMonsterstop "
				#ifdef DEBUGGINGMONSTER
				"ON"
				#else
				"OFF"
				#endif
			#endif
			newline;
