long fastdiv(long a, unsigned long b)
{
	if ((*(long*)&a)<0)
	{
		unsigned long bit = 1;
		unsigned long res = 0;

		(*(long*)&a)=-(*(long*)&a);

		while (b<a && bit && !(b & (1L<<31)))
		{
		  b   <<=1;
		  bit <<=1;
		}

		while (bit)
		{
			if (a>=b)	{  a-=b;  res|=bit; }
			bit >>=1;
			b	>>=1;
		}

		return -(*(long*)&res);
	} 
	else
	{
		unsigned long bit = 1;
		unsigned long res = 0;

		while (b<a && bit && !(b & (1L<<31)))
		{
		  b   <<=1;
		  bit <<=1;
		}

		while (bit)
		{
			if (a>=b)	{  a-=b;  res|=bit; }
			bit >>=1;
			b	>>=1;
		}

		return res;
	} 
}
