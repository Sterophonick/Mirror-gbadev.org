#ifndef _interrupt_H
#define _interrupt_H

void	Init_irq(void);
void	Stop_irq(void);

void	(*Virqfuntion)();

#endif
