#include "../../main.h"
#include "../../Images/sincos.h"
#include "vertex.h"
#include "../math/matrizen.h"

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
void	vec3dMultiplyMatrix(VERTEX3D *vOut,VERTEX3D *vIn,MATRIX4x4 *pIn)
{
	VERTEX3D v;

	v.x= (pIn->_00*vIn->x+pIn->_10*vIn->y+pIn->_20*vIn->z+pIn->_30*vIn->w)>>SINCOSMAX;
	v.y= (pIn->_01*vIn->x+pIn->_11*vIn->y+pIn->_21*vIn->z+pIn->_31*vIn->w)>>SINCOSMAX;
	v.z= (pIn->_02*vIn->x+pIn->_12*vIn->y+pIn->_22*vIn->z+pIn->_32*vIn->w)>>SINCOSMAX;
	v.w= (pIn->_03*vIn->x+pIn->_13*vIn->y+pIn->_23*vIn->z+pIn->_33*vIn->w)>>SINCOSMAX;
	*vOut= v;
}
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
void	vec3dSub(VERTEX3D *vOut,VERTEX3D *vIn0,VERTEX3D *vIn1)
{
	vOut->x= vIn0->x-vIn1->x;
	vOut->y= vIn0->y-vIn1->y;
	vOut->z= vIn0->z-vIn1->z;
}
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
void	vec2dSub(VERTEX2D *vOut,VERTEX2D *vIn0,VERTEX2D *vIn1)
{
	vOut->x= vIn0->x-vIn1->x;
	vOut->y= vIn0->y-vIn1->y;
}
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
void	vec3dCross(VERTEX3D *vOut,VERTEX3D *vIn0,VERTEX3D *vIn1)
{
	VERTEX3D v;

	v.x= (vIn0->y*vIn1->z-vIn0->z*vIn1->y)>>(SINCOSMAX/4);
	v.y= (vIn0->z*vIn1->x-vIn0->x*vIn1->z)>>(SINCOSMAX/4);
	v.z= (vIn0->x*vIn1->y-vIn0->y*vIn1->x)>>(SINCOSMAX/4);
//	v.x= vIn0->y*vIn1->z-vIn0->z*vIn1->y;
//	v.y= vIn0->z*vIn1->x-vIn0->x*vIn1->z;
//	v.z= vIn0->x*vIn1->y-vIn0->y*vIn1->x;

	*vOut= v;
}
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
s32	vec3dDot(VERTEX3D *vIn0,VERTEX3D *vIn1)
{
	return((vIn0->x*vIn1->x+vIn0->y*vIn1->y+vIn0->z*vIn1->z)>>SINCOSMAX);
}
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
