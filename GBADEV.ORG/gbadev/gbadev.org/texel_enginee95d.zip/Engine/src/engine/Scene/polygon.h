#ifndef	__polygon_H
#define	__polygon_H
#include "vertex.h"
#include "scene.h"

typedef	struct
{
	int		VNum;
	VERTEX	*vertex;
}POLYGON;

#endif
