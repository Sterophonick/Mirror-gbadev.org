#ifndef	__scene_H
#define	__scene_H

#define	OBJECT_MODEL	1
#define	OBJECT_NULL		2
#define	OBJECT_ROOT		3

typedef	struct
{
	int	Typ;
}NODE;

int	sceneLoad(char *dotXSI_ASCII_File,NODE *Scene);

#endif
