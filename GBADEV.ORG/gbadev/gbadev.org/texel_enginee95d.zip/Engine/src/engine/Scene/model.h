#ifndef	__model_H
#define	__model_H
#include "../math/matrizen.h"
#include "polygon.h"

typedef	struct
{
	int	Typ;

	MATRIX4x4	Matrix;
	VERTEX3D	*Vertex3D;
	int			Vertex3DNum;
	POLYGON		*Polygon;
	int			PolygonNum;
	NODE		*Child;
	int			ChildNum;
}MODEL;

#endif
