#include <stdio.h>
#include "scene.h"
#include "model.h"

#define	X_DEF	240*2
#define	Y_DEF	160*2
#define	Z_DEF	32*2
const	VERTEX3D	Vertex3D[8]= {{-X_DEF,-Y_DEF,-Z_DEF},{ X_DEF,-Y_DEF,-Z_DEF},{ X_DEF, Y_DEF,-Z_DEF},{-X_DEF, Y_DEF,-Z_DEF},{-X_DEF,-Y_DEF, Z_DEF},{ X_DEF,-Y_DEF, Z_DEF},{ X_DEF, Y_DEF, Z_DEF},{-X_DEF, Y_DEF, Z_DEF}};
#undef	X_DEF
#undef	Y_DEF

const	VERTEX		Poly1[4]= {{0,   0<<4,   0<<4,0},{1, 239<<4,   0<<4,0},{2, 239<<4, 159<<4,0},{3,   0<<4, 159<<4,0}};
const	VERTEX		Poly2[4]= {{7,   0<<4, 176<<4,0},{6, 127<<4, 175<<4,0},{5, 127<<4, 255<<4,0},{4,   0<<4, 255<<4,0}};

const	VERTEX		Poly3[4]= {{1, 240<<4,   0<<4,0},{5, 255<<4,   0<<4,0},{6, 255<<4, 159<<4,0},{2, 240<<4, 159<<4,0}};
const	VERTEX		Poly4[4]= {{4, 240<<4,   0<<4,0},{0, 255<<4,   0<<4,0},{3, 255<<4, 159<<4,0},{7, 240<<4, 159<<4,0}};
const	VERTEX		Poly5[4]= {{4,   0<<4, 160<<4,0},{5, 239<<4, 160<<4,0},{1, 239<<4, 175<<4,0},{0,   0<<4, 175<<4,0}};
const	VERTEX		Poly6[4]= {{3,   0<<4, 160<<4,0},{2, 239<<4, 160<<4,0},{6, 239<<4, 175<<4,0},{7,   0<<4, 175<<4,0}};

const	POLYGON		Polys[6]= {	{4,Poly1},{4,Poly2},{4,Poly3},{4,Poly4},{4,Poly5},{4,Poly6} };

const	MODEL	Object= {OBJECT_MODEL,
				(MATRIX4x4){4096,0,0,0,0,4096,0,0,0,0,4096,0,0,0,0,4096},
				Vertex3D,8,
				Polys,
				6,
				0,
				0
};
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
/*int	sceneLoad(char *dotXSI_ASCII_File,SCENE *Scene)
{
	char	text[256];

//	printf("%s",dotXSI_ASCII_File);
	return(1);
}
*/
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
