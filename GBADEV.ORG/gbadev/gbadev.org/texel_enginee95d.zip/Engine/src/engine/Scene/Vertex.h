#ifndef	__vertex_H
#define	__vertex_H
#include "../math/matrizen.h"

typedef	struct
{
	s32	x,y,z,w;
}VERTEX3D;
typedef	struct
{
	short	x,y;
	int		z;
}VERTEX2D;

typedef	struct
{
	short		VertexIdx;
	int			UT,VT;
	char		Color;
}VERTEX;

void	vec3dMultiplyMatrix(VERTEX3D *vOut,VERTEX3D *vIn,MATRIX4x4 *pIn);
void	vec3dSub(VERTEX3D *vOut,VERTEX3D *vIn0,VERTEX3D *vIn1);
void	vec3dCross(VERTEX3D *vOut,VERTEX3D *vIn0,VERTEX3D *vIn1);
s32		vec3dDot(VERTEX3D *vIn0,VERTEX3D *vIn1);
void	vec2dSub(VERTEX2D *vOut,VERTEX2D *vIn0,VERTEX2D *vIn1);

typedef	struct
{
	s32	x;
	s32	z;
	s32	u;
	s32	v;
}LEFT_RIGHT_BUFFER;

#endif
