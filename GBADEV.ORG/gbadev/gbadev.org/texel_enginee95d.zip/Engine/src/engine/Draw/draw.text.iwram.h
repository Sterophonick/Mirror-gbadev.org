#ifndef	__draw_H
#define	__draw_H
#include "../math/matrizen.h"
#include "../scene/vertex.h"
#include "../scene/model.h"

#define	BUFFER3D_MAX_SIZE	4096

#define	VP_VERT_BACKCAM		1	// Vertex ist hinter der Camera
#define	VP_VERT_LEFTCAM		2	// Vertex ist links von der Camera
#define	VP_VERT_RIGHTCAM	4	// Vertex ist rechts von der Camera
#define	VP_VERT_UPCAM		8	// Vertex ist �ber der Camera
#define	VP_VERT_DOWNCAM		16	// Vertex ist unter von der Camera

extern	int	Screen_Height2D;
extern	int	Screen_Width2D;
extern	int	Screen_Depth3D;

extern	u32	TextureMappingPers;

void	drawSetVertexBuffer(VERTEX3D *VBuffer3D,int len,MATRIX4x4 *matrix);
void	drawPrimitive(POLYGON *priBuffer,int Anzahl,int Flags);
void	drawSetTextur(u8 *textur);

void	drawInit();
void	drawFree();

#endif
