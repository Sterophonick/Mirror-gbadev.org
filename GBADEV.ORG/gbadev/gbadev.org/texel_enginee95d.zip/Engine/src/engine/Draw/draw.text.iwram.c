#include <stdio.h>
#include "../../main.h"
#include "../../screen.h"
#include "draw.text.iwram.h"
#include "../scene/vertex.h"
#include "../misc/misc.h"

///////////////////////////////////////////////////////////////////////////////////////// 
u32	TextureMappingPers= 1;
#define	REZ_Z	0x1000000
#define	GEN1	0x10000
///////////////////////////////////////////////////////////////////////////////////////// 
///////////////////////////////////////////////////////////////////////////////////////// 
int			VertexBuffer3DUseBits[BUFFER3D_MAX_SIZE/32] EWRAM;
VERTEX3D	VertexBuffer3D[4096] EWRAM;
int			VertexBuffer3D_Len= 0;
VERTEX2D	VertexBuffer2D[BUFFER3D_MAX_SIZE] EWRAM;
int			VertexBuffer2D_Len= 0;
int			Screen_Height2D;
int			Screen_Width2D;
int			Screen_Depth3D;
int			Vertex3DViewPortBits[BUFFER3D_MAX_SIZE] EWRAM;
int			ClipDepth= 16;
unsigned char *Textur;// EWRAM;
/////////////////////////////////////////////////////////////////////////////////////////
#ifdef	GBA
LEFT_RIGHT_BUFFER	Left_Buffer[160] EWRAM;
LEFT_RIGHT_BUFFER	Right_Buffer[160] EWRAM;
#else
LEFT_RIGHT_BUFFER	*Left_Buffer;
LEFT_RIGHT_BUFFER	*Right_Buffer;
#endif
s32			Left_Right_oben;
s32			Left_Right_unten;
/////////////////////////////////////////////////////////////////////////////////////////
void	drawInit()
{
#ifndef	GBA
	Left_Buffer= (LEFT_RIGHT_BUFFER*)malloc(sizeof(LEFT_RIGHT_BUFFER)*Screen_Width);
	Right_Buffer= (LEFT_RIGHT_BUFFER*)malloc(sizeof(LEFT_RIGHT_BUFFER)*Screen_Width);
#endif
}
/////////////////////////////////////////////////////////////////////////////////////////
void	drawFree()
{
#ifndef	GBA
	free(Left_Buffer);
	free(Right_Buffer);
#endif
}
/////////////////////////////////////////////////////////////////////////////////////////
void	drawSpan_Color(int xLinks,int xRechts,u32 *Buffer,unsigned char color)
{
	int i;
	if(xRechts<xLinks)
	{
		i= xLinks;
		xLinks= xRechts;
		xRechts= i;
	}

	if(xLinks>=Screen_Width2D*2 || xRechts<0) return;
	if(xLinks<0) xLinks= 0;
	if(xRechts>Screen_Width2D*2) xRechts= Screen_Width2D*2;
	for(i=xLinks;i<xRechts;i++)
	{
		Buffer[i]|= color;
	}
}
/////////////////////////////////////////////////////////////////////////////////////////
inline void	drawSpan_ColorGouraud(int xLinks,int xRechts,u32 *Buffer,int colorL,int colorR)
{
	int i;
	int	colorST;
	if(xRechts==xLinks) return;
	if(xRechts<xLinks)
	{
		i= xLinks;
		xLinks= xRechts;
		xRechts= i;
		i= colorL;
		colorL= colorR;
		colorR= i;
	}

	if(xLinks>=Screen_Width2D*2 || xRechts<0) return;
	colorST= (colorR-colorL)/(xRechts-xLinks);
	if(xLinks<0)
	{
		colorL+= colorST*-xLinks;
		xLinks= 0;
	}
	if(xRechts>Screen_Width2D*2) xRechts= Screen_Width2D*2;
	for(i=xLinks;i<xRechts;i++)
	{
		Buffer[i]= colorL/0x10000;
		colorL+= colorST;
	}
}
/////////////////////////////////////////////////////////////////////////////////////////
inline	u32	drawGetTexelAdrPers(u32 tmp)
{
	return(((tmp)&0xff00)+(tmp>>24));
}
/////////////////////////////////////////////////////////////////////////////////////////
inline	void	drawSpan_TexturPersp(int xLinks,int xRechts,u32 *Buffer,int zrezL,int zrezR,int UL,int UR,int VL,int VR)
{
#define	GETTEXEL(buf,TexAdr,tmp,Textur,schift)	{ if(!(buf&(0xff<<(schift)))) { TexAdr= drawGetTexelAdrPers(tmp);buf|= (Textur[TexAdr]<<schift);} }
#define	GET4PIXELS(buf,TexAdr,tmp,Textur) { GETTEXEL(buf,TexAdr,tmp,Textur,0) \
											tmp+=tmpadd; \
											GETTEXEL(buf,TexAdr,tmp,Textur,8) \
											tmp+=tmpadd; \
											GETTEXEL(buf,TexAdr,tmp,Textur,16) \
											tmp+=tmpadd; \
											GETTEXEL(buf,TexAdr,tmp,Textur,24) \
											}

	int i= 0,j= 0,k= 0,l;
	int	zrezST;
	int	uadd,vadd;
	int	dist;
	int	uofs,vofs;
	int	u0= 0,v0= 0;
	u32	buf= 0;
	int	rez1= 0;
	int	zrezLtmp= 0;
	int	uf1= 0;
	int	vf1= 0;
	int	u1= 0;
	int	v1= 0;
	int	TexAdr= 0xffff;

	xLinks/= GEN1;
	xRechts/= GEN1;
	if(xRechts==xLinks) return;
	if(xRechts<xLinks)
	{
		i= xLinks;
		xLinks= xRechts;
		xRechts= i;
		i= zrezL;
		zrezL= zrezR;
		zrezR= i;
		i= UL;
		UL= UR;
		UR= i;
		i= VL;
		VL= VR;
		VR= i;
	}

#define	GENAU	4
	if(xLinks>=Screen_Width2D*2 || xRechts<0) return;
	zrezL*=GENAU;
	zrezR*=GENAU;
	uofs= UL;
	vofs= VL;
	UL= UR-UL;
	VL= VR-VL;
	dist= (xRechts-xLinks);
	zrezST= fastdiv((zrezR-zrezL)*4,dist);
	uadd= fastdiv((UL*GENAU),dist);
	vadd= fastdiv((VL*GENAU),dist);
	UL= 0;
	VL= 0;
	if(xLinks<0)
	{
		zrezLtmp+= zrezST*-xLinks;
		UL+= uadd*-xLinks;
		VL+= vadd*-xLinks;
		xLinks= 0;
	}
	if(xRechts>Screen_Width2D*2) xRechts= Screen_Width2D*2;
	if((xRechts-xLinks)<12)
	{
		if((xRechts-xLinks)==0) return;
		rez1= zrezL+zrezLtmp/4;
		uf1= uofs*GENAU+UL;
		vf1= vofs*GENAU+VL;
		u1= fastdiv(uf1<<1,rez1);
		v1= fastdiv(vf1<<1,rez1);
		u0= u1;
		v0= v1;
		zrezLtmp+= zrezST*(xRechts-xLinks);
		UL+= uadd*(xRechts-xLinks);
		VL+= vadd*(xRechts-xLinks);
		rez1= zrezL+zrezLtmp/4;
		uf1= uofs*GENAU+UL;
		vf1= vofs*GENAU+VL;
		u1= fastdiv(uf1<<1,rez1);
		v1= fastdiv(vf1<<1,rez1);
		int	ua= (u1-u0)*8/(xRechts-xLinks);
		int	va= (v1-v0)*8/(xRechts-xLinks);
		u0<<=3;
		v0<<=3;
		u32	tmp= (u0<<16)|(v0&0xffff);
		u32	tmpadd= (ua<<16)|(va&0xffff);

		buf= Buffer[xLinks>>2];
		for(i=xLinks;i<xRechts;i++)
		{
			GETTEXEL(buf,TexAdr,tmp,Textur,(8*(i&3)))
			tmp+=tmpadd;
			if(!((i+1)&3)) 
			{
				Buffer[i>>2]= buf;
				buf= Buffer[(i+1)>>2];
			}
		}
		Buffer[i>>2]= buf;
	}
	else
	{
		i= xLinks;
		i>>= 2;

		if(xLinks&3)
		{
			rez1= zrezL+zrezLtmp/4;
			uf1= uofs+(UL/GENAU);
			vf1= vofs+(VL/GENAU);
			u1= fastdiv(uf1<<3,rez1);
			v1= fastdiv(vf1<<3,rez1);
			u0= u1;
			v0= v1;
			zrezLtmp+= zrezST*(4-(xLinks&3));
			UL+= uadd*(4-(xLinks&3));
			VL+= vadd*(4-(xLinks&3));
			rez1= zrezL+zrezLtmp/4;
			uf1= uofs*GENAU+UL;
			vf1= vofs*GENAU+VL;
			u1= fastdiv(uf1<<1,rez1);
			v1= fastdiv(vf1<<1,rez1);
			int	ua= (u1-u0);
			int	va= (v1-v0);
			u0<<=3;
			v0<<=3;
			u32	tmp= (u0<<16)|(v0&0xffff);
			u32	tmpadd= (ua<<16)|(va&0xffff);
			buf= Buffer[i];
			for(j=xLinks;j<(xLinks&~3)+4;j++)
			{
				GETTEXEL(buf,TexAdr,tmp,Textur,(8*(j&3)))
				tmp+=tmpadd;
			}
			Buffer[i]= buf;
			i++;
		}

		rez1= zrezL+zrezLtmp/4;
		uf1= uofs*GENAU+UL;
		vf1= vofs*GENAU+VL;
		u1= fastdiv(uf1<<1,rez1);
		v1= fastdiv(vf1<<1,rez1);
		zrezST<<= 2;
		uadd<<= 2;
		vadd<<= 2;

		j= (xRechts>>2)-i;

		if((i&1) && (j>>1))
		{
			u0= u1;
			v0= v1;
			zrezLtmp+= zrezST;
			UL+= uadd;
			VL+= vadd;
			rez1= zrezL+zrezLtmp/4;
			uf1= uofs*GENAU+UL;
			vf1= vofs*GENAU+VL;
			u1= fastdiv(uf1<<1,rez1);
			v1= fastdiv(vf1<<1,rez1);
			int	ua= (u1-u0);
			int	va= (v1-v0);
			u0<<=3;
			v0<<=3;
			u32	tmp= (u0<<16)|(v0&0xffff);
			u32	tmpadd= (ua<<16)|(va&0xffff);
			buf= Buffer[i];
			GET4PIXELS(buf,TexAdr,tmp,Textur)
			Buffer[i]= buf;
			i++;
		}

		j= (xRechts>>2)-i;
		zrezST<<= 1;
		uadd<<= 1;
		vadd<<= 1;

		if((j>>3) && (abs(zrezST>>2)<1024*3))
		{
			for(k=0;k<j>>3;k++)
			{
				u0= u1;
				v0= v1;
				zrezLtmp+= zrezST;
				zrezLtmp+= zrezST;
				zrezLtmp+= zrezST;
				zrezLtmp+= zrezST;
				UL+= uadd;
				UL+= uadd;
				UL+= uadd;
				UL+= uadd;
				VL+= vadd;
				VL+= vadd;
				VL+= vadd;
				VL+= vadd;
				rez1= zrezL+zrezLtmp/4;
				uf1= uofs*GENAU+UL;
				vf1= vofs*GENAU+VL;
				u1= fastdiv(uf1<<1,rez1);
				v1= fastdiv(vf1<<1,rez1);
				int	ua= (u1-u0)>>2;
				int	va= (v1-v0)>>2;
				u0<<=3;
				v0<<=3;
				u32	tmp= (u0<<16)|(v0&0xffff);
				u32	tmpadd= (ua<<16)|(va&0xffff);
				for(l=0;l<8;l++)
				{
					buf= Buffer[i];
					GET4PIXELS(buf,TexAdr,tmp,Textur)
					Buffer[i]= buf;
					i++;
					buf= Buffer[i];
					tmp+=tmpadd;
				}
			}
		}

		j= (xRechts>>2)-i;
//		zrezST>>= 1;
//		uadd>>= 1;
//		vadd>>= 1;

		if((j>>2) && (abs(zrezST>>2)<1024*4))
		{
			for(k=0;k<j>>2;k++)
			{
				u0= u1;
				v0= v1;
				zrezLtmp+= zrezST;
				zrezLtmp+= zrezST;
				UL+= uadd;
				UL+= uadd;
				VL+= vadd;
				VL+= vadd;
				rez1= zrezL+zrezLtmp/4;
				uf1= uofs*GENAU+UL;
				vf1= vofs*GENAU+VL;
				u1= fastdiv(uf1<<1,rez1);
				v1= fastdiv(vf1<<1,rez1);
				int	ua= (u1-u0)>>1;
				int	va= (v1-v0)>>1;
				u0<<=3;
				v0<<=3;
				u32	tmp= (u0<<16)|(v0&0xffff);
				u32	tmpadd= (ua<<16)|(va&0xffff);
				for(l=0;l<4;l++)
				{
					buf= Buffer[i];
					GET4PIXELS(buf,TexAdr,tmp,Textur)
					Buffer[i]= buf;
					i++;
					buf= Buffer[i];
					tmp+=tmpadd;
				}
			}
		}

		j= (xRechts>>2)-i;
//		zrezST>>= 1;
//		uadd>>= 1;
//		vadd>>= 1;
		if((j>>1) && (abs(zrezST>>2)<1024*6))
		{
			for(k=0;k<(j>>1);k++)
			{
				u0= u1;
				v0= v1;
				zrezLtmp+= zrezST;
				UL+= uadd;
				VL+= vadd;
				rez1= zrezL+zrezLtmp/4;
				uf1= uofs*GENAU+UL;
				vf1= vofs*GENAU+VL;
				u1= fastdiv(uf1<<1,rez1);
				v1= fastdiv(vf1<<1,rez1);
				int	ua= (u1-u0);
				int	va= (v1-v0);
				u0<<=3;
				v0<<=3;
				u32	tmp= (u0<<16)|(v0&0xffff);
				u32	tmpadd= (ua<<16)|(va&0xffff);
				buf= Buffer[i];
				GET4PIXELS(buf,TexAdr,tmp,Textur)
				Buffer[i]= buf;
				i++;
				buf= Buffer[i];
				tmp+=tmpadd;
				GET4PIXELS(buf,TexAdr,tmp,Textur)
				Buffer[i]= buf;
				i++;
			}
		}

		
		j= (xRechts>>2)-i;
		zrezST>>= 1;
		uadd>>= 1;
		vadd>>= 1;
		if(j>0)
		{
			for(k=0;k<j;k++)
			{
				u0= u1;
				v0= v1;
				zrezLtmp+= zrezST;
				UL+= uadd;
				VL+= vadd;
				rez1= zrezL+zrezLtmp/4;
				uf1= uofs*GENAU+UL;
				vf1= vofs*GENAU+VL;
				u1= fastdiv(uf1<<1,rez1);
				v1= fastdiv(vf1<<1,rez1);
				int	ua= (u1-u0)<<1;
				int	va= (v1-v0)<<1;
				u0<<=3;
				v0<<=3;
				u32	tmp= (u0<<16)|(v0&0xffff);
				u32	tmpadd= (ua<<16)|(va&0xffff);
				buf= Buffer[i];
				GET4PIXELS(buf,TexAdr,tmp,Textur)
				Buffer[i]= buf;
				i++;
			}
		}

		j= (xRechts>>2)-i;
		zrezST>>= 1;
		uadd>>= 1;
		vadd>>= 1;

		if(xRechts&3)
		{
			zrezST>>= 2;
			uadd>>= 2;
			vadd>>= 2;
			zrezST*= xRechts&3;
			uadd*= xRechts&3;
			vadd*= xRechts&3;
			u0= u1;
			v0= v1;
			zrezLtmp+= zrezST;
			UL+= uadd;
			VL+= vadd;
			rez1= zrezL+zrezLtmp/4;
			uf1= uofs*GENAU+UL;
			vf1= vofs*GENAU+VL;
			u1= fastdiv(uf1<<1,rez1);
			v1= fastdiv(vf1<<1,rez1);
			int	ua= (u1-u0);
			int	va= (v1-v0);
			u0<<=3;
			v0<<=3;
			u32	tmp= (u0<<16)|(v0&0xffff);
			u32	tmpadd= (ua<<16)|(va&0xffff);
			buf= Buffer[i];
			for(k=0;k<(xRechts&3);k++)
			{
				GETTEXEL(buf,TexAdr,tmp,Textur,(8*k))
				tmp+=tmpadd;
			}
			Buffer[i]= buf;
		}

	}
/**/

#undef	GETTEXEL
}
/////////////////////////////////////////////////////////////////////////////////////////
inline	u32	drawGetTexelAdrLinear(s32 ua,s32 va)
{
	int	u= ua>>20;
	int	v= va>>12;
	return((v&0xff00)+(u&255));
}
/////////////////////////////////////////////////////////////////////////////////////////
inline void	drawSpan_TexturLinear(int xLinks,int xRechts,u32 *Buffer,int UL,int UR,int VL,int VR)
{
#define	GETTEXEL(buf,oldtex,TexAdr,u,v,Textur,schift)	{TexAdr= drawGetTexelAdrLinear(u,v);oldtex= Textur[TexAdr];buf|= oldtex<<schift;} \

	int i;
	int	uadd,vadd;
	int	dist;
	int	uofs,vofs;
	u32	buf= 0;
	int	pos= 0;
	u32	oldtex= 0;
	int	TexAdr= 0xffff;

	xLinks>>= 16;
	xRechts>>= 16;
	if(xRechts==xLinks) return;
	if(xRechts<xLinks)
	{
		i= xLinks;
		xLinks= xRechts;
		xRechts= i;
		i= UL;
		UL= UR;
		UR= i;
		i= VL;
		VL= VR;
		VR= i;
	}

	if(xLinks>=Screen_Width2D*2 || xRechts<0) return;
	uofs= UL;
	vofs= VL;
	UL= UR-UL;
	VL= VR-VL;
	dist= (xRechts-xLinks);
	uadd= fastdiv(UL,dist);
	vadd= fastdiv(VL,dist);
	UL= 0;
	VL= 0;
	if(xLinks<0)
	{
		UL+= uadd*-xLinks;
		VL+= vadd*-xLinks;
		xLinks= 0;
	}
	if(xRechts>Screen_Width2D*2) xRechts= Screen_Width2D*2;
	pos= xLinks>>2;
	if(xLinks&3)
	{
		buf= Buffer[pos];
		if((xRechts>>2)==(xLinks>>2))
		{
			int	schift= (xLinks&3)*8;
			for(i=0;i<xRechts-xLinks;i++,schift*=2)
			{
				GETTEXEL(buf,oldtex,TexAdr,(uofs+UL),(vofs+VL),Textur,schift);
				UL+= uadd;
				VL+= vadd;
			}
			Buffer[pos]= buf;
			return;
		}
		else
		{
			switch(xLinks&3)
			{
			case 1:
				{
					GETTEXEL(buf,oldtex,TexAdr,(uofs+UL),(vofs+VL),Textur,8);
					if(xLinks==xRechts)
					{
						Buffer[pos]= buf;
						return;
					}
					UL+= uadd;
					VL+= vadd;
				}
			case 2:
				{
					GETTEXEL(buf,oldtex,TexAdr,(uofs+UL),(vofs+VL),Textur,16);
					if(xLinks==xRechts)
					{
						Buffer[pos]= buf;
						return;
					}
					UL+= uadd;
					VL+= vadd;
				}
			case 3:
				{
					GETTEXEL(buf,oldtex,TexAdr,(uofs+UL),(vofs+VL),Textur,24);
					if(xLinks==xRechts)
					{
						Buffer[pos]= buf;
						return;
					}
					UL+= uadd;
					VL+= vadd;
				}
			}
			Buffer[pos]= buf;
			pos++;
		}
	}

	while(pos<(xRechts>>2))
	{
		buf= 0;
		GETTEXEL(buf,oldtex,TexAdr,(uofs+UL),(vofs+VL),Textur,0);
		UL+= uadd;
		VL+= vadd;
		GETTEXEL(buf,oldtex,TexAdr,(uofs+UL),(vofs+VL),Textur,8);
		UL+= uadd;
		VL+= vadd;
		GETTEXEL(buf,oldtex,TexAdr,(uofs+UL),(vofs+VL),Textur,16);
		UL+= uadd;
		VL+= vadd;
		GETTEXEL(buf,oldtex,TexAdr,(uofs+UL),(vofs+VL),Textur,24);
		UL+= uadd;
		VL+= vadd;
		Buffer[pos]= buf;
		pos++;
	}
	if(xRechts&3)
	{
		buf= 0;
		for(i=0;i<(xRechts&3);i++)
		{
			GETTEXEL(buf,oldtex,TexAdr,(uofs+UL),(vofs+VL),Textur,(i*8));
			UL+= uadd;
			VL+= vadd;
		}
		Buffer[pos]|= buf;
	}
#undef	GETTEXEL
}
/////////////////////////////////////////////////////////////////////////////////////////
extern	s32	add_Z;
void	drawSetVertexBuffer(VERTEX3D *VBuffer3D,int len,MATRIX4x4 *matrix)
{
	int	i;
	COPYn32(VBuffer3D,VertexBuffer3D,sizeof(VERTEX3D)*len);
	VertexBuffer3D_Len= len;

	for(i=0;i<VertexBuffer3D_Len;i++)
	{
		VERTEX3D	v= VertexBuffer3D[i];
		vec3dMultiplyMatrix(&v,&v,matrix);
		v.z+= add_Z;
		VertexBuffer3D[i]= v;
	}

}
/////////////////////////////////////////////////////////////////////////////////////////
void	drawSetTextur(u8 *textur)
{
//	COPYn32(textur,Textur,65536);
	Textur= textur;
}
/////////////////////////////////////////////////////////////////////////////////////////
void	drawTrianglePersp(VERTEX *a,VERTEX *b,VERTEX *c)
{
	u32 *backbuffer= Screen_BackBuffer;
	int	y;
	u32 *buf;
	int	Hab= 0,Hbc= 0,Hac= 0;
	int	XSab= 0,XSbc= 0,XSac= 0,XAB= 0,XAC= 0,XBC= 0;
	int	CSab= 0,CSbc= 0,CSac= 0,CAB= 0,CAC= 0,CBC= 0;
	int	ZSab= 0,ZSbc= 0,ZSac= 0,ZAB= 0,ZAC= 0,ZBC= 0,ZABtmp= 0,ZACtmp= 0,ZBCtmp= 0;
	int	USab= 0,USbc= 0,USac= 0,UAB= 0,UAC= 0,UBC= 0,UABtmp= 0,UACtmp= 0,UBCtmp= 0;
	int	VSab= 0,VSbc= 0,VSac= 0,VAB= 0,VAC= 0,VBC= 0,VABtmp= 0,VACtmp= 0,VBCtmp= 0;
	int	UAz= 0,UBz= 0,UCz= 0;
	int	VAz= 0,VBz= 0,VCz= 0;
	int	Ay= 0,By= 0,Cy= 0;

	if(VertexBuffer2D[b->VertexIdx].y<VertexBuffer2D[a->VertexIdx].y)
	{
		VERTEX *tmp= a;
		a= b;
		b= tmp;
	}
	if(VertexBuffer2D[c->VertexIdx].y<VertexBuffer2D[a->VertexIdx].y)
	{
		VERTEX *tmp= a;
		a= c;
		c= tmp;
	}
	if(VertexBuffer2D[c->VertexIdx].y<VertexBuffer2D[b->VertexIdx].y)
	{
		VERTEX *tmp= b;
		b= c;
		c= tmp;
	}

	Hab= (VertexBuffer2D[b->VertexIdx].y-VertexBuffer2D[a->VertexIdx].y);
	Hbc= (VertexBuffer2D[c->VertexIdx].y-VertexBuffer2D[b->VertexIdx].y);
	Hac= (VertexBuffer2D[c->VertexIdx].y-VertexBuffer2D[a->VertexIdx].y);

	UAz= a->UT*VertexBuffer2D[a->VertexIdx].z;
	UBz= b->UT*VertexBuffer2D[b->VertexIdx].z;
	UCz= c->UT*VertexBuffer2D[c->VertexIdx].z;
	VAz= a->VT*VertexBuffer2D[a->VertexIdx].z;
	VBz= b->VT*VertexBuffer2D[b->VertexIdx].z;
	VCz= c->VT*VertexBuffer2D[c->VertexIdx].z;

#define	Z_GEN	8
#define	UV_GEN	8

	if(Hab!=0) 
	{
		XSab= fastdiv(GEN1*(VertexBuffer2D[b->VertexIdx].x-VertexBuffer2D[a->VertexIdx].x),Hab);
		XAB= GEN1*(VertexBuffer2D[a->VertexIdx].x+Screen_Width2D);
		CSab= fastdiv(GEN1*(b->Color-a->Color),Hab);
		CAB= GEN1*a->Color;
		ZSab= fastdiv((VertexBuffer2D[b->VertexIdx].z-VertexBuffer2D[a->VertexIdx].z)*Z_GEN,Hab);
		ZAB= VertexBuffer2D[a->VertexIdx].z;
		USab= fastdiv((UBz-UAz)*UV_GEN,Hab);
		UAB= UAz;
		VSab= fastdiv((VBz-VAz)*UV_GEN,Hab);
		VAB= VAz;
	}
	if(Hbc!=0) 
	{
		XSbc= fastdiv(GEN1*(VertexBuffer2D[c->VertexIdx].x-VertexBuffer2D[b->VertexIdx].x),Hbc);
		XBC= GEN1*(VertexBuffer2D[b->VertexIdx].x+Screen_Width2D);
		CSbc= fastdiv(GEN1*(c->Color-b->Color),Hbc);
		CBC= GEN1*b->Color;
		ZSbc= fastdiv((VertexBuffer2D[c->VertexIdx].z-VertexBuffer2D[b->VertexIdx].z)*Z_GEN,Hbc);
		ZBC= VertexBuffer2D[b->VertexIdx].z;
		USbc= fastdiv((UCz-UBz)*UV_GEN,Hbc);
		UBC= UBz;
		VSbc= fastdiv((VCz-VBz)*UV_GEN,Hbc);
		VBC= VBz;
	}
	if(Hac!=0) 
	{
		XSac= fastdiv(GEN1*(VertexBuffer2D[c->VertexIdx].x-VertexBuffer2D[a->VertexIdx].x),Hac);
		XAC= GEN1*(VertexBuffer2D[a->VertexIdx].x+Screen_Width2D);
		CSac= fastdiv(GEN1*(c->Color-a->Color),Hac);
		CAC= GEN1*a->Color;
		ZSac= fastdiv((VertexBuffer2D[c->VertexIdx].z-VertexBuffer2D[a->VertexIdx].z)*Z_GEN,Hac);
		ZAC= VertexBuffer2D[a->VertexIdx].z;
		USac= fastdiv((UCz-UAz)*UV_GEN,Hac);
		UAC= UAz;
		VSac= fastdiv((VCz-VAz)*UV_GEN,Hac);
		VAC= VAz;
	}

	Ay= VertexBuffer2D[a->VertexIdx].y+Screen_Height2D;
	By= VertexBuffer2D[b->VertexIdx].y+Screen_Height2D;

	if(Ay<0)
	{
		XAB+= XSab*-Ay;
		XAC+= XSac*-Ay;
		CAB+= CSab*-Ay;
		CAC+= CSac*-Ay;
		ZABtmp+= ZSab*-Ay;
		ZACtmp+= ZSac*-Ay;
		UABtmp+= USab*-Ay;
		UACtmp+= USac*-Ay;
		VABtmp+= VSab*-Ay;
		VACtmp+= VSac*-Ay;
		Hab+= Ay;
		Ay= 0;
	}
	Cy= Screen_Height2D*2-Ay;
	if(Cy>Screen_Height2D*2) Cy= Screen_Height2D*2;

	if(By>=0)
	{
		Cy-= Hab;
		if(Cy<0) Hab+= Cy;
		buf= &backbuffer[Ay*Screen_Width2D/2];
		for(y=0;y!=Hab;y++)
		{
//			drawSpan_Color(XAB/GEN1,XAC/GEN1,buf,color);
//			drawSpan_ColorGouraud(XAB/GEN1,XAC/GEN1,buf,CAB,CAC);
			drawSpan_TexturPersp(XAB,XAC,buf,ZAB+ZABtmp/Z_GEN,ZAC+ZACtmp/Z_GEN,UAB+UABtmp/UV_GEN,UAC+UACtmp/UV_GEN,VAB+VABtmp/UV_GEN,VAC+VACtmp/UV_GEN);
			buf+= Screen_Width2D/2;
			XAB+= XSab;
			XAC+= XSac;
			CAB+= CSab;
			CAC+= CSac;
			ZABtmp+= ZSab;
			ZACtmp+= ZSac;
			UABtmp+= USab;
			UACtmp+= USac;
			VABtmp+= VSab;
			VACtmp+= VSac;
		}
	}
	else
	{
		XBC+= XSbc*-By;
		CBC+= CSbc*-By;
		ZBCtmp+= ZSbc*-By;
		UBCtmp+= USbc*-By;
		VBCtmp+= VSbc*-By;
		Hbc+= By;
		By= 0;
	}
	if(Cy>0)
	{
		Cy-= Hbc;
		if(Cy<0) Hbc+= Cy;
		buf= &backbuffer[By*Screen_Width2D/2];
		for(y=0;y!=Hbc;y++)
		{
//			drawSpan_Color(XBC/GEN1,XAC/GEN1,buf,color);
//			drawSpan_ColorGouraud(XBC/GEN1,XAC/GEN1,buf,CBC,CAC);
			drawSpan_TexturPersp(XBC,XAC,buf,ZBC+ZBCtmp/Z_GEN,ZAC+ZACtmp/Z_GEN,UBC+UBCtmp/UV_GEN,UAC+UACtmp/UV_GEN,VBC+VBCtmp/UV_GEN,VAC+VACtmp/UV_GEN);
			buf+= Screen_Width2D/2;
			XBC+= XSbc;
			XAC+= XSac;
			CBC+= CSbc;
			CAC+= CSac;
			ZBCtmp+= ZSbc;
			ZACtmp+= ZSac;
			UBCtmp+= USbc;
			UACtmp+= USac;
			VBCtmp+= VSbc;
			VACtmp+= VSac;
		}
	}
}
/////////////////////////////////////////////////////////////////////////////////////////
void	drawPolyPersp(VERTEX **Vertexes,s32 polyNum)
{
#define	Z_GEN	8
#define	UV_GEN	8

	u32 *backbuffer= Screen_BackBuffer;
	int	i,j;
	int	addsub= 0;
	u32 *buf;
	int	Hab= 0;
	int	XSab= 0,XAB= 0;
	int	ZSab= 0,ZAB= 0,ZABtmp= 0;
	int	USab= 0,UAB= 0,UABtmp= 0;
	int	VSab= 0,VAB= 0,VABtmp= 0;
	int	UAz= 0,UBz= 0;
	int	VAz= 0,VBz= 0;
	int	Ay= 0,By= 0;


	Left_Right_oben= 160;
	Left_Right_unten= 0;
	for(i=0;i<polyNum;i++)
	{
		VERTEX *a= Vertexes[i];
		j= i+1;
		if(j==polyNum) j= 0;
		VERTEX *b= Vertexes[j];

		Hab= (VertexBuffer2D[b->VertexIdx].y-VertexBuffer2D[a->VertexIdx].y);

		UAz= a->UT*VertexBuffer2D[a->VertexIdx].z;
		UBz= b->UT*VertexBuffer2D[b->VertexIdx].z;
		VAz= a->VT*VertexBuffer2D[a->VertexIdx].z;
		VBz= b->VT*VertexBuffer2D[b->VertexIdx].z;

		if(Hab!=0) 
		{
			ZABtmp= 0;
			UABtmp= 0;
			VABtmp= 0;

			XSab= fastdiv(GEN1*(VertexBuffer2D[b->VertexIdx].x-VertexBuffer2D[a->VertexIdx].x),Hab);
			XAB= GEN1*(VertexBuffer2D[a->VertexIdx].x+Screen_Width2D);
			ZSab= fastdiv((VertexBuffer2D[b->VertexIdx].z-VertexBuffer2D[a->VertexIdx].z)*Z_GEN,Hab);
			ZAB= VertexBuffer2D[a->VertexIdx].z;
			USab= fastdiv((UBz-UAz)*UV_GEN,Hab);
			UAB= UAz;
			VSab= fastdiv((VBz-VAz)*UV_GEN,Hab);
			VAB= VAz;

			Ay= VertexBuffer2D[a->VertexIdx].y+Screen_Height2D;
			By= VertexBuffer2D[b->VertexIdx].y+Screen_Height2D;

			if(!((Ay<0 && By<0) || (Ay>=Screen_Height2D*2 && By>=Screen_Height2D*2))) 
			{
				if(Ay<0)
				{
					XAB+= XSab*-Ay;
					ZABtmp+= ZSab*-Ay;
					UABtmp+= USab*-Ay;
					VABtmp+= VSab*-Ay;
					Ay= 0;
				}
				if(Ay>=Screen_Height2D*2)
				{
					XAB-= XSab*(Ay-Screen_Height2D*2);
					ZABtmp-= ZSab*(Ay-Screen_Height2D*2);
					UABtmp-= USab*(Ay-Screen_Height2D*2);
					VABtmp-= VSab*(Ay-Screen_Height2D*2);
					Ay= Screen_Height2D*2;
				}

				if(By<0)
				{
					By= 0;
				}
				if(By>=Screen_Height2D*2)
				{
					By= Screen_Height2D*2;
				}

				if(Ay!=By)
				{
					LEFT_RIGHT_BUFFER	*Buffer;
					if(Ay<Left_Right_oben) Left_Right_oben= Ay;
					if(By<Left_Right_oben) Left_Right_oben= By;
					if(Ay>Left_Right_unten) Left_Right_unten= Ay;
					if(By>Left_Right_unten) Left_Right_unten= By;
					if(Ay<By) 
					{
						Buffer= Left_Buffer;
						addsub= 1;
						By++;
					}
					else 
					{
						Buffer= Right_Buffer;
						addsub= -1;
						By--;
						XSab= -XSab;
						ZSab= -ZSab;
						USab= -USab;
						VSab= -VSab;
					}
					while(Ay!=By)
					{
						Buffer[Ay].x= XAB;
						Buffer[Ay].z= ZAB+ZABtmp/Z_GEN;
						Buffer[Ay].u= UAB+UABtmp/UV_GEN;
						Buffer[Ay].v= VAB+VABtmp/UV_GEN;
						XAB+= XSab;
						ZABtmp+= ZSab;
						UABtmp+= USab;
						VABtmp+= VSab;
						Ay+= addsub;
					}
				}
			}
		}
	}

	buf= &backbuffer[Left_Right_oben*Screen_Width2D/2];
	for(i=Left_Right_oben+1;i<Left_Right_unten;i++)
	{
//		drawSpan_TexturPersp(XAB,XAC,buf,ZAB+ZABtmp/Z_GEN,ZAC+ZACtmp/Z_GEN,UAB+UABtmp/UV_GEN,UAC+UACtmp/UV_GEN,VAB+VABtmp/UV_GEN,VAC+VACtmp/UV_GEN);
		drawSpan_TexturPersp(Left_Buffer[i].x,Right_Buffer[i].x,buf,Left_Buffer[i].z,Right_Buffer[i].z,Left_Buffer[i].u,Right_Buffer[i].u,Left_Buffer[i].v,Right_Buffer[i].v);
		buf+= Screen_Width2D/2;
	}
}
/////////////////////////////////////////////////////////////////////////////////////////
void	drawTriangleLinear(VERTEX *a,VERTEX *b,VERTEX *c)
{
#define	MAX_DIST	1024
#define	MAX_DIST2	MAX_DIST*MAX_DIST

	int	xa,ya,xb,yb,xc,yc;
	xa= VertexBuffer2D[a->VertexIdx].x;
	xb= VertexBuffer2D[b->VertexIdx].x;
	xc= VertexBuffer2D[c->VertexIdx].x;
	ya= VertexBuffer2D[a->VertexIdx].y;
	yb= VertexBuffer2D[b->VertexIdx].y;
	yc= VertexBuffer2D[c->VertexIdx].y;
	int	len_ab= (xa-xb)*(xa-xb)+(ya-yb)*(ya-yb);
	int	len_ac= (xa-xc)*(xa-xc)+(ya-yc)*(ya-yc);
	int	len_bc= (xc-xb)*(xc-xb)+(yc-yb)*(yc-yb);
	if(len_ab<MAX_DIST2 && len_ac<MAX_DIST2 && len_bc<MAX_DIST2)
	{
		u32 *backbuffer= (u32*)Screen_BackBuffer;
		int	y;
		u32 *buf;
		int	Hab= 0,Hbc= 0,Hac= 0;
		int	XSab= 0,XSbc= 0,XSac= 0,XAB= 0,XAC= 0,XBC= 0;
		int	USab= 0,USbc= 0,USac= 0,UAB= 0,UAC= 0,UBC= 0;
		int	VSab= 0,VSbc= 0,VSac= 0,VAB= 0,VAC= 0,VBC= 0;
		int	UA= 0,UB= 0,UC= 0;
		int	VA= 0,VB= 0,VC= 0;
		int	Ay= 0,By= 0,Cy= 0;

		if(VertexBuffer2D[b->VertexIdx].y<VertexBuffer2D[a->VertexIdx].y)
		{
			VERTEX *tmp= a;
			a= b;
			b= tmp;
		}
		if(VertexBuffer2D[c->VertexIdx].y<VertexBuffer2D[a->VertexIdx].y)
		{
			VERTEX *tmp= a;
			a= c;
			c= tmp;
		}
		if(VertexBuffer2D[c->VertexIdx].y<VertexBuffer2D[b->VertexIdx].y)
		{
			VERTEX *tmp= b;
			b= c;
			c= tmp;
		}

		Hab= (VertexBuffer2D[b->VertexIdx].y-VertexBuffer2D[a->VertexIdx].y);
		Hbc= (VertexBuffer2D[c->VertexIdx].y-VertexBuffer2D[b->VertexIdx].y);
		Hac= (VertexBuffer2D[c->VertexIdx].y-VertexBuffer2D[a->VertexIdx].y);

		UA= a->UT;
		UB= b->UT;
		UC= c->UT;
		VA= a->VT;
		VB= b->VT;
		VC= c->VT;

		UA<<= 16;
		UB<<= 16;
		UC<<= 16;
		VA<<= 16;
		VB<<= 16;
		VC<<= 16;

		if(Hab!=0) 
		{
			XSab= fastdiv(0x10000*(VertexBuffer2D[b->VertexIdx].x-VertexBuffer2D[a->VertexIdx].x),Hab);
			XAB= 0x10000*(VertexBuffer2D[a->VertexIdx].x+Screen_Width2D);
			USab= fastdiv((UB-UA),Hab);
			UAB= UA;
			VSab= fastdiv((VB-VA),Hab);
			VAB= VA;
		}
		if(Hbc!=0) 
		{
			XSbc= fastdiv(0x10000*(VertexBuffer2D[c->VertexIdx].x-VertexBuffer2D[b->VertexIdx].x),Hbc);
			XBC= 0x10000*(VertexBuffer2D[b->VertexIdx].x+Screen_Width2D);
			USbc= fastdiv((UC-UB),Hbc);
			UBC= UB;
			VSbc= fastdiv((VC-VB),Hbc);
			VBC= VB;
		}
		if(Hac!=0) 
		{
			XSac= fastdiv(0x10000*(VertexBuffer2D[c->VertexIdx].x-VertexBuffer2D[a->VertexIdx].x),Hac);
			XAC= 0x10000*(VertexBuffer2D[a->VertexIdx].x+Screen_Width2D);
			USac= fastdiv((UC-UA),Hac);
			UAC= UA;
			VSac= fastdiv((VC-VA),Hac);
			VAC= VA;
		}

		Ay= VertexBuffer2D[a->VertexIdx].y+Screen_Height2D;
		By= VertexBuffer2D[b->VertexIdx].y+Screen_Height2D;

		if(Ay<0)
		{
			XAB+= XSab*-Ay;
			XAC+= XSac*-Ay;
			UAB+= USab*-Ay;
			UAC+= USac*-Ay;
			VAB+= VSab*-Ay;
			VAC+= VSac*-Ay;
			Hab+= Ay;
			Ay= 0;
		}
		Cy= Screen_Height2D*2-Ay;
		if(Cy>Screen_Height2D*2) Cy= Screen_Height2D*2;

		if(By>=0)
		{
			Cy-= Hab;
			if(Cy<0) Hab+= Cy;
			if(Ay>=Screen_Height*2) return;
			buf= &backbuffer[Ay*Screen_Width2D/2];
			for(y=0;y!=Hab;y++)
			{
	//			drawSpan_Color(XAB/0x10000,XAC/0x10000,buf,color);
	//			drawSpan_ColorGouraud(XAB/0x10000,XAC/0x10000,buf,CAB,CAC);
				drawSpan_TexturLinear(XAB,XAC,buf,UAB,UAC,VAB,VAC);
				buf+= Screen_Width2D/2;
				XAB+= XSab;
				XAC+= XSac;
				UAB+= USab;
				UAC+= USac;
				VAB+= VSab;
				VAC+= VSac;
			}
		}
		else
		{
			XBC+= XSbc*-By;
			UBC+= USbc*-By;
			VBC+= VSbc*-By;
			Hbc+= By;
			By= 0;
		}
		if(Cy>0)
		{
			Cy-= Hbc;
			if(Cy<0) Hbc+= Cy;
			if(By>=Screen_Height*2) return;
			buf= &backbuffer[By*Screen_Width2D/2];
			for(y=0;y!=Hbc;y++)
			{
	//			drawSpan_Color(XBC/0x10000,XAC/0x10000,buf,color);
	//			drawSpan_ColorGouraud(XBC/0x10000,XAC/0x10000,buf,CBC,CAC);
				drawSpan_TexturLinear(XBC,XAC,buf,UBC,UAC,VBC,VAC);
				buf+= Screen_Width2D/2;
				XBC+= XSbc;
				XAC+= XSac;
				UBC+= USbc;
				UAC+= USac;
				VBC+= VSbc;
				VAC+= VSac;
			}
		}
	}
	else
	{
		if(len_ac>len_ab)
		{
			VERTEX *tmp= b;
			b= c;
			c= tmp;
		}
		if(len_bc>len_ab)
		{
			VERTEX *tmp= a;
			a= c;
			c= tmp;
		}
		VERTEX	d;

		VertexBuffer2D[VertexBuffer2D_Len].x= (VertexBuffer2D[a->VertexIdx].x+VertexBuffer2D[b->VertexIdx].x)>>1;
		VertexBuffer2D[VertexBuffer2D_Len].y= (VertexBuffer2D[a->VertexIdx].y+VertexBuffer2D[b->VertexIdx].y)>>1;
		VertexBuffer2D[VertexBuffer2D_Len].z= (VertexBuffer2D[a->VertexIdx].z+VertexBuffer2D[b->VertexIdx].z)>>1;
		d.VertexIdx= VertexBuffer2D_Len;
		Vertex3DViewPortBits[d.VertexIdx]= 0;
		if(VertexBuffer2D[d.VertexIdx].x<-Screen_Width2D) Vertex3DViewPortBits[d.VertexIdx]|= VP_VERT_LEFTCAM;
		if(VertexBuffer2D[d.VertexIdx].x>=Screen_Width2D) Vertex3DViewPortBits[d.VertexIdx]|= VP_VERT_RIGHTCAM;
		if(VertexBuffer2D[d.VertexIdx].y<-Screen_Height2D) Vertex3DViewPortBits[d.VertexIdx]|= VP_VERT_UPCAM;
		if(VertexBuffer2D[d.VertexIdx].y>=Screen_Height2D) Vertex3DViewPortBits[d.VertexIdx]|= VP_VERT_DOWNCAM;
		int	az= VertexBuffer2D[a->VertexIdx].z;
		int	bz= VertexBuffer2D[b->VertexIdx].z;
		int	dz= VertexBuffer2D[d.VertexIdx].z;
		int	au= a->UT*az;
		int	bu= b->UT*bz;
		int	av= a->VT*az;
		int	bv= b->VT*bz;
		d.UT= fastdiv((au+bu),dz*2);
		d.VT= fastdiv((av+bv),dz*2);
		VertexBuffer2D_Len++;

		int	bitsa= (Vertex3DViewPortBits[a->VertexIdx] & Vertex3DViewPortBits[d.VertexIdx] & Vertex3DViewPortBits[c->VertexIdx]);
		int	bitsb= (Vertex3DViewPortBits[c->VertexIdx] & Vertex3DViewPortBits[d.VertexIdx] & Vertex3DViewPortBits[b->VertexIdx]);
		if(bitsa==0)
			drawTriangleLinear(a,c,&d);
		if(bitsb==0)
			drawTriangleLinear(c,b,&d);
		VertexBuffer2D_Len--;
	}
}
/////////////////////////////////////////////////////////////////////////////////////////
void	drawPolyLinear(VERTEX **Vertexes,s32 polyNum)
{
#define	MAX_DIST	1024
#define	MAX_DIST2	MAX_DIST*MAX_DIST

	u32 *backbuffer= (u32*)Screen_BackBuffer;
	int	i,j;
	u32 *buf;
	int	Hab= 0;
	int	XSab= 0,XAB= 0;
	int	USab= 0,UAB= 0;
	int	VSab= 0,VAB= 0;
	int	UA= 0,UB= 0;
	int	VA= 0,VB= 0;
	int	Ay= 0,By= 0;
	int	addsub= 0;

	Left_Right_oben= 160;
	Left_Right_unten= 0;
	for(i=0;i<polyNum;i++)
	{
		VERTEX *a= Vertexes[i];
		j= i+1;
		if(j==polyNum) j= 0;
		VERTEX *b= Vertexes[j];

		Hab= (VertexBuffer2D[b->VertexIdx].y-VertexBuffer2D[a->VertexIdx].y);

		UA= a->UT;
		UB= b->UT;
		VA= a->VT;
		VB= b->VT;
		UA<<= 16;
		UB<<= 16;
		VA<<= 16;
		VB<<= 16;

		if(Hab!=0) 
		{
			XSab= fastdiv(0x10000*(VertexBuffer2D[b->VertexIdx].x-VertexBuffer2D[a->VertexIdx].x),Hab);
			XAB= 0x10000*(VertexBuffer2D[a->VertexIdx].x+Screen_Width2D);
			USab= fastdiv((UB-UA),Hab);
			UAB= UA;
			VSab= fastdiv((VB-VA),Hab);
			VAB= VA;

			Ay= VertexBuffer2D[a->VertexIdx].y+Screen_Height2D;
			By= VertexBuffer2D[b->VertexIdx].y+Screen_Height2D;

			if(!((Ay<0 && By<0) || (Ay>=Screen_Height2D*2 && By>=Screen_Height2D*2))) 
			{
				if(Ay<0)
				{
					XAB+= XSab*-Ay;
					UAB+= USab*-Ay;
					VAB+= VSab*-Ay;
					Ay= 0;
				}
				if(Ay>=Screen_Height2D*2)
				{
					XAB-= XSab*(Ay-Screen_Height2D*2);
					UAB-= USab*(Ay-Screen_Height2D*2);
					VAB-= VSab*(Ay-Screen_Height2D*2);
					Ay= Screen_Height2D*2;
				}

				if(By<0)
				{
					By= 0;
				}
				if(By>=Screen_Height2D*2)
				{
					By= Screen_Height2D*2;
				}

				if(Ay!=By)
				{
					LEFT_RIGHT_BUFFER	*Buffer;
					if(Ay<Left_Right_oben) Left_Right_oben= Ay;
					if(By<Left_Right_oben) Left_Right_oben= By;
					if(Ay>Left_Right_unten) Left_Right_unten= Ay;
					if(By>Left_Right_unten) Left_Right_unten= By;
					if(Ay<By) 
					{
						Buffer= Left_Buffer;
						addsub= 1;
						By++;
					}
					else 
					{
						Buffer= Right_Buffer;
						addsub= -1;
						By--;
						XSab= -XSab;
						USab= -USab;
						VSab= -VSab;
					}
					while(Ay!=By)
					{
						Buffer[Ay].x= XAB;
						Buffer[Ay].u= UAB;
						Buffer[Ay].v= VAB;
						XAB+= XSab;
						UAB+= USab;
						VAB+= VSab;
						Ay+= addsub;
					}
				}
			}
		}
	}

	buf= &backbuffer[Left_Right_oben*Screen_Width2D/2];
	for(i=Left_Right_oben+1;i<Left_Right_unten;i++)
	{
		drawSpan_TexturLinear(Left_Buffer[i].x,Right_Buffer[i].x,buf,Left_Buffer[i].u,Right_Buffer[i].u,Left_Buffer[i].v,Right_Buffer[i].v);
		buf+= Screen_Width2D/2;
	}
}
/////////////////////////////////////////////////////////////////////////////////////////
void	drawPrimitive(POLYGON *priBuffer,int Anzahl,int Flags)
{
	int	i;
	VERTEX *a,*b,*c,*d;
	VERTEX *pri[4];

	miscClearBuffer(VertexBuffer3DUseBits,sizeof(int)*BUFFER3D_MAX_SIZE/32);
	miscClearBuffer(Vertex3DViewPortBits,sizeof(int)*BUFFER3D_MAX_SIZE);

//	for(i=0;i<3*Anzahl;i++) 
//	{
//		BF_SET(VertexBuffer3DUseBits,priBuffer[i].VertexIdx);
//	}

	for(i=0;i<VertexBuffer3D_Len;i++)
	{
//		if(BF_ISSET(VertexBuffer3DUseBits,i))
		{
			VERTEX3D	v= VertexBuffer3D[i];
			if(v.z<ClipDepth)
			{
				Vertex3DViewPortBits[i]|= VP_VERT_BACKCAM;
			}
			else
			{
				VertexBuffer2D[i].x= fastdiv(v.x*Screen_Depth3D,v.z);
				VertexBuffer2D[i].y= fastdiv(v.y*Screen_Depth3D,v.z);
				VertexBuffer2D[i].z= fastdiv(REZ_Z,v.z);
				if(VertexBuffer2D[i].x<-Screen_Width2D) Vertex3DViewPortBits[i]|= VP_VERT_LEFTCAM;
				if(VertexBuffer2D[i].x>=Screen_Width2D) Vertex3DViewPortBits[i]|= VP_VERT_RIGHTCAM;
				if(VertexBuffer2D[i].y<-Screen_Height2D) Vertex3DViewPortBits[i]|= VP_VERT_UPCAM;
				if(VertexBuffer2D[i].y>=Screen_Height2D) Vertex3DViewPortBits[i]|= VP_VERT_DOWNCAM;
			}
		}
	}
	VertexBuffer2D_Len= i;

	for(i=0;i<Anzahl;i++)
	{
		a= &priBuffer[i].vertex[0];
		b= &priBuffer[i].vertex[1];
		c= &priBuffer[i].vertex[2];
		d= &priBuffer[i].vertex[3];
		if((Vertex3DViewPortBits[a->VertexIdx]&Vertex3DViewPortBits[b->VertexIdx]&Vertex3DViewPortBits[c->VertexIdx])==0)
		{
			VERTEX3D v0= VertexBuffer3D[a->VertexIdx];
			VERTEX3D v1= VertexBuffer3D[b->VertexIdx];
			VERTEX3D v2= VertexBuffer3D[c->VertexIdx];

			vec3dSub(&v1,&v1,&v0);
			vec3dSub(&v2,&v2,&v0);
			vec3dCross(&v1,&v2,&v1);
			v0.x= -v0.x;
			v0.y= -v0.y;
			v0.z= -v0.z;
			v0.w= -v0.w;

			if(vec3dDot(&v0,&v1)>1)
			{
/*				VERTEX2D v0= VertexBuffer2D[a->VertexIdx];
				VERTEX2D v1= VertexBuffer2D[b->VertexIdx];
				VERTEX2D v2= VertexBuffer2D[c->VertexIdx];

				vec2dSub(&v1,&v1,&v0);
				vec2dSub(&v2,&v2,&v0);
				vec2dSub(&v0,&v2,&v1);

				int	len0= v0.x*v0.x+v0.y*v0.y;
				int	len1= v1.x*v1.x+v1.y*v1.y;
				int	len2= v2.x*v2.x+v2.y*v2.y;

				if((len0+len1+len2)>(32*32*3))
					drawTrianglePersp(a,b,c);
				else 
					drawTriangleLinear(a,b,c);
*/
//				if(TextureMappingPers) drawTrianglePersp(a,b,c);
//				else drawTriangleLinear(a,b,c);

				pri[0]= a;
				pri[1]= b;
				pri[2]= c;
				pri[3]= d;
				if(TextureMappingPers) drawPolyPersp((VERTEX**)&pri,4);
				else drawPolyLinear((VERTEX**)&pri,4);
				
//				drawTrianglePersp(a,b,c);
			}
		}
	}
}
/////////////////////////////////////////////////////////////////////////////////////////
