#ifndef	__misc_H
#define	__misc_H

#define	BF_SET(a,b) a[b>>5]|=(1<<(b&31))
#define	BF_CLR(a,b) a[b>>5]&|=~(1<<(b&31))
#define	BF_ISSET(a,b) a[b>>5]&(1<<(b&31))

void	miscClearBuffer(void *buffer,int len);

#endif
