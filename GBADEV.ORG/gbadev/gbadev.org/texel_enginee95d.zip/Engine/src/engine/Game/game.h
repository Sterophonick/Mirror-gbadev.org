#ifndef	__game_H
#define	__game_H

#define	Z_ENDE	1024
#define	FRAMES	256

extern	s32		add_Z;
extern	int		zz0game;
extern	int		zz1game;
extern	int		zz2game;
extern	int		zz3game;

void	gameLoop();
void	gameInit();
void	gameVIrq();

#endif
