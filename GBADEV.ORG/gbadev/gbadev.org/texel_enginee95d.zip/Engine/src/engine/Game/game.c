#include "../../main.h"
#ifdef	GBA
#include "../../interrupt.h"
#endif
#include "../../screen.h"
#include "../../Images/sincos.h"
#include "../../Images/textures.h"
#include "game.h"
#include "../scene/Vertex.h"
#include "../draw/draw.text.iwram.h"
#include "../math/matrizen.h"
#include "../scene/model.h"

void	gameVIrq();
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
void	gameInit()
{
	Screen_setPalette((u16*)IAS_Logo_Palette);

	Virqfuntion= gameVIrq;
}
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
VERTEX3D	*Vertex;
POLYGON		*Dreieck;
s32		add_Z= Z_ENDE;
int		zz0game= 0;//(-6*FRAMES)&SINCOSTAB;
int		zz1game= 0;//(-4*FRAMES)&SINCOSTAB;
int		zz2game= 0;//(-2*FRAMES)&SINCOSTAB;
int		zz3game= 0;

extern	MODEL	Object;

void	gameLoop()
{
	MATRIX4x4	mat;
	MATRIX4x4	matX,matY,matZ;
/*	int	i;

#define	SIZE	256
#define	MAKE_QUADRAT(a,b,c,d,ua,va,ub,vb,uc,vc,ud,vd) { \
	Dreieck[i].VertexIdx= a;Dreieck[i].Color= 0;Dreieck[i].UT= ua;  Dreieck[i].VT= va;i++; \
	Dreieck[i].VertexIdx= b;Dreieck[i].Color= 0;Dreieck[i].UT= ub;	Dreieck[i].VT= vb;i++; \
	Dreieck[i].VertexIdx= c;Dreieck[i].Color= 0;Dreieck[i].UT= uc;  Dreieck[i].VT= vc;i++; \
	Dreieck[i].VertexIdx= d;Dreieck[i].Color= 0;Dreieck[i].UT= ud;  Dreieck[i].VT= vd;i++; \
								}
	Vertex[0].x= -SIZE;Vertex[0].y= -SIZE;Vertex[0].z=  -SIZE;
	Vertex[1].x=  SIZE;Vertex[1].y= -SIZE;Vertex[1].z=  -SIZE;
	Vertex[2].x=  SIZE;Vertex[2].y=  SIZE;Vertex[2].z=  -SIZE;
	Vertex[3].x= -SIZE;Vertex[3].y=  SIZE;Vertex[3].z=  -SIZE;

	Vertex[4].x= -SIZE;Vertex[4].y= -SIZE;Vertex[4].z=  SIZE;
	Vertex[5].x=  SIZE;Vertex[5].y= -SIZE;Vertex[5].z=  SIZE;
	Vertex[6].x=  SIZE;Vertex[6].y=  SIZE;Vertex[6].z=  SIZE;
	Vertex[7].x= -SIZE;Vertex[7].y=  SIZE;Vertex[7].z=  SIZE;

	i= 0;

	MAKE_QUADRAT(0,1,2,3,   0<<4,  0<<4, 128<<4,  0<<4, 128<<4,128<<4,   0<<4,128<<4)
	MAKE_QUADRAT(7,6,5,4, 128<<4,  0<<4, 256<<4,  0<<4, 256<<4,128<<4, 128<<4,128<<4)
	MAKE_QUADRAT(1,5,6,2,   0<<4,128<<4, 128<<4,128<<4, 128<<4,256<<4,   0<<4,256<<4)
	MAKE_QUADRAT(4,0,3,7, 128<<4,128<<4, 256<<4,128<<4, 256<<4,256<<4, 128<<4,256<<4)
	MAKE_QUADRAT(4,5,1,0,   0<<4,  0<<4, 128<<4,  0<<4, 128<<4,128<<4,   0<<4,128<<4)
	MAKE_QUADRAT(3,2,6,7, 128<<4,128<<4, 256<<4,128<<4, 256<<4,256<<4, 128<<4,256<<4)
*/
	matrixRotationX(&matX,zz0game);
	matrixRotationY(&matY,zz1game);
	matrixRotationZ(&matZ,zz2game);
	matrixMultiply(&matX,&matX,&matY);
	matrixMultiply(&matX,&matX,&matZ);
	mat= Object.Matrix;
	matrixMultiply(&mat,&matX,&mat);

	int	VNum= Object.Vertex3DNum;
	int	PNum= Object.PolygonNum;
	Vertex= Object.Vertex3D;
	Dreieck= Object.Polygon;
	drawSetVertexBuffer(Vertex,VNum,&mat);
	drawSetTextur((u8*)IAS_Logo_Map);
	drawPrimitive(Dreieck,PNum,0);
/**/
}
//////////////////////////////////////////////////////////////////////////////////////////////////
void	gameVIrq()
{
//	if(add_Z>Z_ENDE)
	{
//		add_Z-= 16;
		zz0game+=3;
		zz1game+=2;
		zz2game+=1;
	//	zz3game+=8;
		zz0game&= SINCOSTAB;
		zz1game&= SINCOSTAB;
		zz2game&= SINCOSTAB;
		zz3game&= SINCOSTAB;
	}
}
//////////////////////////////////////////////////////////////////////////////////////////////////
