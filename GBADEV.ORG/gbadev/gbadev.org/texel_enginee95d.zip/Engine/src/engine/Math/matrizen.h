#ifndef	__matrizen_H
#define	__matrizen_H
#include "../../main.h"
/*
	Werte der Matrizen werden immer mit SINCOSMAX (sincos.h) multipliziert.
	Der Angle-Wert muss immer ein Wert zwischen 0 und SINCOSTAB (sincos.h) sein.
*/

typedef	struct
{
	s32	_00,_01,_02,_03;
	s32	_10,_11,_12,_13;
	s32	_20,_21,_22,_23;
	s32	_30,_31,_32,_33;
}MATRIX4x4;

void	matrixIdentity(MATRIX4x4 *pOut);
void	matrixRotationZ(MATRIX4x4 *pOut,s32 Angle);
void	matrixRotationY(MATRIX4x4 *pOut,s32 Angle);
void	matrixRotationX(MATRIX4x4 *pOut,s32 Angle);
void	matrixMultiply(MATRIX4x4 *pOut,MATRIX4x4 *pIn0,MATRIX4x4 *pIn1);

#endif
