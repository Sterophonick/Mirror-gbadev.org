#include "../../main.h"
#include "../../Images/sincos.h"
#include "../scene/vertex.h"
#include "matrizen.h"

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
void	matrixIdentity(MATRIX4x4 *pOut)
{
	ZEROn32(pOut,sizeof(MATRIX4x4));
	pOut->_00= 1<<SINCOSMAX;
	pOut->_11= 1<<SINCOSMAX;
	pOut->_22= 1<<SINCOSMAX;
	pOut->_33= 1<<SINCOSMAX;
}
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
void	matrixRotationZ(MATRIX4x4 *pOut,s32 Angle)
{
	ZEROn32(pOut,sizeof(MATRIX4x4));
	pOut->_00= cosTab[Angle];
	pOut->_11= pOut->_00;
	pOut->_01= sinTab[Angle];
	pOut->_10= -pOut->_01;
	pOut->_22= 1<<SINCOSMAX;
	pOut->_33= 1<<SINCOSMAX;
}
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
void	matrixRotationY(MATRIX4x4 *pOut,s32 Angle)
{
	ZEROn32(pOut,sizeof(MATRIX4x4));
	pOut->_00= cosTab[Angle];
	pOut->_22= pOut->_00;
	pOut->_02= -sinTab[Angle];
	pOut->_20= -pOut->_02;
	pOut->_11= 1<<SINCOSMAX;
	pOut->_33= 1<<SINCOSMAX;
}
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
void	matrixRotationX(MATRIX4x4 *pOut,s32 Angle)
{
	ZEROn32(pOut,sizeof(MATRIX4x4));
	pOut->_00= 1<<SINCOSMAX;
	pOut->_11= cosTab[Angle];
	pOut->_22= pOut->_11;
	pOut->_12= -sinTab[Angle];
	pOut->_21= -pOut->_12;
	pOut->_33= 1<<SINCOSMAX;
}
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
void	matrixMultiply(MATRIX4x4 *pOut,MATRIX4x4 *pIn0,MATRIX4x4 *pIn1)
{
#define	MADD(i,j,a) pIn0->_##i##a*pIn1->_##a##j
#define	MULT_C(M,i,j) { M._##i##j= (MADD(i,j,0)+MADD(i,j,1)+MADD(i,j,2)+MADD(i,j,3))>>SINCOSMAX;}
	MATRIX4x4	M;

	MULT_C(M,0,0);
	MULT_C(M,0,1);
	MULT_C(M,0,2);
	MULT_C(M,0,3);
	MULT_C(M,1,0);
	MULT_C(M,1,1);
	MULT_C(M,1,2);
	MULT_C(M,1,3);
	MULT_C(M,2,0);
	MULT_C(M,2,1);
	MULT_C(M,2,2);
	MULT_C(M,2,3);
	MULT_C(M,3,0);
	MULT_C(M,3,1);
	MULT_C(M,3,2);
	MULT_C(M,3,3);
	COPYn32(&M,pOut,sizeof(MATRIX4x4));
}
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
