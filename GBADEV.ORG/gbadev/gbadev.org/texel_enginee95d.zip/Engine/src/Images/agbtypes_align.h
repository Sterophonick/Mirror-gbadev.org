#ifndef _incl_agbtypes_align_h
#define _incl_agbtypes_align_h

#define u16 u16_
#define u8 u8_
#include <agbtypes.h>
#undef u16
#undef u8

typedef u16_ u16 __attribute__ ((aligned (4)));
typedef u8_  u8  __attribute__ ((aligned (4)));


#endif
