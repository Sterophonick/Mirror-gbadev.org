#ifndef	__IAS_Logo_H
#define	__IAS_Logo_H

extern	const u16 IAS_Logo_Palette[256];
extern	const u8 IAS_Logo_Map[65536];

#endif
