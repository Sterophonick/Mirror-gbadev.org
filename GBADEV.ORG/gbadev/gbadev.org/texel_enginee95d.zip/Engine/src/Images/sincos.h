#ifndef __sincosTab_H
#define __sincosTab_H
#define	SINCOSTAB	1023
#define	SINCOSMAX	12	// (1<<SINCOSMAX)
extern const s32 sinTab[1024];
extern const s32 cosTab[1024];
#endif
