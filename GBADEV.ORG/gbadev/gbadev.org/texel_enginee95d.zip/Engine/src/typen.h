#ifndef _typen_H
#define _typen_H

//#define	CHEAT

#ifndef _WIN32
typedef enum {false=0, true=1} bool;
#endif

typedef s16 PERSID;
#define persid_void -1

typedef enum {CS_NONE, CS_ICE, CS_FIRE, CS_POISON, CS_FLASH, CS_LIGHT} CONTSCHADEN;

typedef enum {ATT_NONE, ATT_HAND, ATT_BOW, ATT_ELEMENT, ATT_DEMON, ATT_WHITE} ATTACKTYPE;

/////////////////////////////////////////////////////////////////////////
#define	GEGNER_FACT		19
#define	GEGNER_STR_ADD	5
#define	GEGNER_DEX_ADD	5
#define	GEGNER_INT_ADD	5
#define	GEGNER_HP_ADD	10
#define	GEGNER_VW_ADD	10

#define	MAGIE_EXP_DURCH_INT_STEIGERUNG	100
#define	PLAYER_STR_ADD	4
#define	PLAYER_DEX_ADD	4
#define	PLAYER_INT_ADD	4
#define	PLAYER_HP_ADD	5
#define	PLAYER_MP_ADD	5
#define	PLAYER_VW_ADD	3


#define	PLAYER_STR_START	10
#define	PLAYER_DEX_START	10
#define	PLAYER_INT_START	10
#define	PLAYER_HP_START		30
#define	PLAYER_MP_START		20
#define	PLAYER_VW_START		10

#define	PLAYER_RENNEN_TIMER	30
#define	TRUHEN_FALLEN_WAHRSCHEINLICHKEIT 10
#define	FALLEN_WAHRSCHEINLICHKEIT 100
#define	RUNEN_FALLEN_WAHRSCHEINLICHKEIT 100

#define	EMOTICON_Y_POS	56

#define	ITEM_BLINK_ZEIT	60 * 4
#define	PLAYER_SAMMELRADIUS 16 * 16
#define	PLAYER_ATTACKRADIUS 28 * 28

#define	PLAYER_MOVE_SPEED_SCHLEICHEN	0
#define	PLAYER_MOVE_SPEED_GEHEN			1
#define	PLAYER_MOVE_SPEED_RENNEN		2
#define PLAYER_MOVE_SPEED_MIN			0
#define PLAYER_MOVE_SPEED_MAX			2

#define	PLAYER_OPEN_DOOR_SPEED			6
/////////////////////////////////////////////////////////////////////////
typedef	struct
{
	u32	Attr_0_1;
	u32	Attr_2_3;
} OAMBAKATTR;
/////////////////////////////////////////////////////////////////////////
#define fxp_to_int(value)	(((value) /* + (((value)>0)?128:-128)*/ )/256)
// Das "+ (((value)>0)?128:-128)" w�rde daf�r sorgen, da� Werte korrekt gerundet werden.
// Leider w�ren dann Positions-Spr�nge m�glich, die die derzeitige Methode zum L�schen
// von rausgescrollten Positionen (in darst_background()) nicht verkraften w�rde.
/////////////////////////////////////////////////////////////////////////
typedef	enum	{WAFFEN_CLASS_NONE,WAFFEN_CLASS_WAFFEN,WAFFEN_CLASS_RUESTUNG,WAFFEN_CLASS_ITEMS,WAFFEN_CLASS_BUCHWEISS,WAFFEN_CLASS_BUCHELEMENT,WAFFEN_CLASS_BUCHDEMON} WAFFEN_CLASS;
typedef	enum	{	WAFFEN_TYP_NONE,
					WAFFEN_TYP_SCHWERTER0,WAFFEN_TYP_SCHWERTER1,WAFFEN_TYP_SCHWERTER2,WAFFEN_TYP_SCHWERTER3,
					WAFFEN_TYP_AEXTE0,WAFFEN_TYP_AEXTE1,WAFFEN_TYP_AEXTE2,WAFFEN_TYP_AEXTE3,
					WAFFEN_TYP_KEULE0,WAFFEN_TYP_KEULE1,WAFFEN_TYP_KEULE2,
					WAFFEN_TYP_ZEPTER0,WAFFEN_TYP_ZEPTER1,
					WAFFEN_TYP_BOGEN0,WAFFEN_TYP_BOGEN1,WAFFEN_TYP_BOGEN2,WAFFEN_TYP_BOGEN3,
					WAFFEN_TYP_RUESTUNG0,WAFFEN_TYP_RUESTUNG1,WAFFEN_TYP_RUESTUNG2,WAFFEN_TYP_RUESTUNG3,
					WAFFEN_TYP_SCHILD0,WAFFEN_TYP_SCHILD1,WAFFEN_TYP_SCHILD2,WAFFEN_TYP_SCHILD3,
					WAFFEN_TYP_HP_TRANK_STARK,WAFFEN_TYP_HP_TRANK_MITTEL,WAFFEN_TYP_HP_TRANK_SCHWACH,
					WAFFEN_TYP_MP_TRANK_STARK,WAFFEN_TYP_MP_TRANK_MITTEL,WAFFEN_TYP_MP_TRANK_SCHWACH,
					WAFFEN_TYP_GIFT,WAFFEN_TYP_EXPLO,WAFFEN_TYP_ANTIDOTE,
					WAFFEN_TYP_RING,WAFFEN_TYP_AMULETT,WAFFEN_TYP_RUNE,WAFFEN_TYP_ROLLE,
					WAFFEN_TYP_TRAEHNE,WAFFEN_TYP_PERLE,WAFFEN_TYP_KRISTALL,
					WAFFEN_TYP_SCHLUESSEL,WAFFEN_TYP_SCHLUESSEL_ROT,WAFFEN_TYP_SCHLUESSEL_GRUEN,WAFFEN_TYP_SCHLUESSEL_BLAU,
					WAFFEN_TYP_BUCH_HEILUNG,WAFFEN_TYP_BUCH_GENESUNG,WAFFEN_TYP_BUCH_MUT,WAFFEN_TYP_BUCH_ABWEHR,
					WAFFEN_TYP_BUCH_SCHUTZ,WAFFEN_TYP_BUCH_MEDITATION,WAFFEN_TYP_BUCH_LEBENSFUNKE,WAFFEN_TYP_BUCH_VERWIRRUNG,
					WAFFEN_TYP_BUCH_FEUERKUGEL,WAFFEN_TYP_BUCH_FLAMMENWAND,WAFFEN_TYP_BUCH_FROSTBEULE,WAFFEN_TYP_BUCH_MORGENTAU,
					WAFFEN_TYP_BUCH_FLASH,WAFFEN_TYP_BUCH_COMBOFLASH,WAFFEN_TYP_BUCH_BEBEN,WAFFEN_TYP_BUCH_STORM,WAFFEN_TYP_BUCH_LICHTKUGEL,
					WAFFEN_TYP_BUCH_LEBENSRAUB,WAFFEN_TYP_BUCH_MAGIERAUB,WAFFEN_TYP_BUCH_HERBEIRUFUNG,WAFFEN_TYP_BUCH_FURCHT,
					WAFFEN_TYP_BUCH_EXPLOSION,WAFFEN_TYP_BUCH_GIFTWOLKE,WAFFEN_TYP_BUCH_HOELLENGLUT} WAFFEN_TYP;

#define	WAFFEN_SPECIALS_AW_FIRE		0x01
#define	WAFFEN_SPECIALS_AW_ICE		0x02
#define	WAFFEN_SPECIALS_AW_POISON	0x04
#define	WAFFEN_SPECIALS_LIGHT		0x08
#define	WAFFEN_SPECIALS_SPEEDUP		0x10

#define Cont_Schaden_Freeze			Cont_Schaden_AW_MIN
#define Cont_Schaden_Freeze_Timer	Cont_Schaden_AW_MAX
typedef struct
{
	float	Magic_Exp,Magic_Next_Exp;
	u16		AW_MIN,AW_MAX;			// Waffen , Ring
    s16		Cont_Schaden_AW_MIN, Cont_Schaden_AW_MAX;

    s8	ZauberSpruch_idx;			// Ring, Amulett, Rollen, B�cher
	u8	Objekt_Typ;
	WAFFEN_TYP	Waffen_Typ;
	u8	ZauberSpruchStufe;			// Ring, Amulett, Rollen, B�cher

    u8	Str;						// Amulett
    u8	Dex;						// Amulett
    u8	Int;						// Amulett
    s8	Num;						// Items

    s8 	SPEED_UP;                   // Amulett, Waffen, R�STUNG, SCHILD, Ring
	u8	Name;
    u8	Cont_Schaden_Typ;			// Waffen 1 - Eis , 2 - Feuer , 3 - Gift, 4 - Light, 5 - Flash
    u8 	RES_LIGHT;                  // R�stung, Schild, Amulett, Ring

    u8 	RES_FIRE;					// R�stung, Schild, Amulett, Ring
    u8 	RES_ICE;                    // R�stung, Schild, Amulett, Ring
    u8 	RES_POISON;                 // R�stung, Schild, Amulett, Ring
    u8 	RES_FLASH;                  // R�stung, Schild, Amulett, Ring

	u16	ShieldVW;

}WAFFEN;
/////////////////////////////////////////////////////////////////////////

typedef	struct
{
	//////////////////////////////////////////////////////////////////////////
	s32	Real_x_pos,Real_y_pos;
	s16	Movement_x,Movement_y;

	//////////////////////////////////////////////////////////////////////////
	union{
	struct	// Monster & Player
	{
		s32 VW;
		s32	HP;
		s32 MP;

		s16	TargetPos_x, TargetPos_y;
		s16	TargetNext_x,TargetNext_y;
		u32 path;				// kodiert Pfadelemente und einige andere Daten -> Makros aus KI_intern.h verwenden

		s16 target_room;		// TargetRoom im OffScreen-Modus; Timer u.a. im Onscreen-Modus (s. Macros)
		u8  path_len;			// b0..b3 kodieren Pfadl�nge, Rest kodiert andere Daten -> Makros aus KI_intern.h verwenden
		s8  UpdateCounter;		// 

		PERSID	target;			// (s16) -> die persid-Macros aus 'object_pers.h' verwenden
		u16		target_dist;		// mu� in jeder neuen Frame aktualisiert werden ( MonsterUpdateTarget() )
		PERSID	spawner;		// (s16) ... (f�r Confusion/Herbeirufung)
		PERSID	last_attacker;	// (s16) ... (bei wem sich das Monster f�r einen Angriff r�chen m�chte)

		u8		target_objnr;		// mu� in jeder neuen Frame aktualisiert werden ( MonsterUpdateTarget() )
		s8		attackplace;		//  0..7 = Positionen um den Player herum, die zum (Nah-)Angriff angesteuert werden; -1= keine Pos.; -2= blockiert
		u8		flags;					// Macros aus 'object_pers.h' verwenden
		u8		monster_update_timer;

		s16		Aura_Counter;
		u8		Aura_ObjTyp;
		u8		Aura_Level;
		u8		Aura_Anim;
		s8		MonsterSpeedVar;
	};

	//////////////////////////////////////////////////////////////////////////
	struct	// Items
	{
		WAFFEN *Werte_Zeiger;	
		s16 ObjTempNum;			// Items (im Editor gesetzt) speichern hier vor�bergehend ihren Subtype
		u8	ZauberSpruchStufe;
		u8	item_kill_timer;
	};

	//////////////////////////////////////////////////////////////////////////
	struct	// Attacks
	{
		s16	Zusatz_Schaden;
		s16	Counter_org;
		s16	height;
		s16	height_speed;
		u8	Mutant;
		u8	Mutant_Time;
		s8	MagicFromBook;	
		u8  owner;
		s8	powerup;
		s16	origin_x;
		s16	origin_y;
	};
	//////////////////////////////////////////////////////////////////////////
	};	// end: union

	// (Monster,Player,Attacks)
	u16	AW_MIN;
	u16 AW_MAX;

	s16	Cont_Schaden_Typ_Counter;	// (Monster,Player,Attacks)
	s16	Cont_Schaden_AW_MIN;		// (Monster,Player,Attacks)
	s16 Cont_Schaden_AW_MAX;		// (Monster,Player,Attacks)
	u8	Cont_Schaden_Typ;			// (Monster,Player,Attacks)		CS_NONE, CS_ICE, CS_FIRE, CS_POISON, CS_LIGHT, CS_FLASH

	s32	Anim_Count;
	u8	Anim_Pos;
	u8  Aktion;
	s8	Richtung;

	u8	level;
	u8	type;
	s8  classtype;
	s8	objclass;

	/////////////////////////////////////////////////////////////////
	s16 trigger_id;
	u16 trigger_rid;
	/////////////////////////////////////////////////////////////////
	s16 id;
	u16	collision_gid;

	u8	debugflags;
	u8	collision_front;

	//////////////////////////////////////////////////////////////////////////
	u8  NEXT;
	u8  PREV;

	s16	Cell;	// ehemals 'Raum'
	s16	Counter;
}OBJECT;
/////////////////////////////////////////////////////////////////////////

#define	DefaultPlayerName	"Hero"

/////////////////////////////////////////////////////////////////////////
#define	OBJ_OBJ_TYP_DYN		1
#define	OBJ_OBJ_TYP_STAT	2
#define	OBJ_OBJ_TYP_ITEM	3
#define	OBJ_OBJ_TYP_SHA		4
#define	OBJ_OBJ_TYP_FAL		5
#define	OBJ_OBJ_TYP_ATT		6
#define	OBJ_OBJ_TYP_EMO		7
#define	OBJ_OBJ_TYP_BAL		8
#define	OBJ_OBJ_TYP_AUG		8
#define	OBJ_OBJ_TYP_POR		9

#define OBJ_AKTION_WARTEN			0x00
#define OBJ_AKTION_LAUFEN			0x01
#define OBJ_AKTION_ANGRIFF1			0x02
#define OBJ_AKTION_ANGRIFF2			0x03
#define OBJ_AKTION_TREFFER			0x04
#define OBJ_AKTION_STERBEN			0x05
#define OBJ_AKTION_SPECIAL			0x06

#define OBJ_AKTION_ITEM_ENSTEHEN	0x00
#define OBJ_AKTION_ITEM_BLINKEN		0x01
#define OBJ_AKTION_ITEM_LIEGEN		0x02

#define OBJ_AKTION_ATT_ENTSTEHEN	0x00
#define OBJ_AKTION_ATT_FLIEGEN		0x01
#define OBJ_AKTION_ATT_VERSCHWINDEN	0x02

#define OBJ_AKTION_STAT_ZU			0x00
#define OBJ_AKTION_STAT_OFFNEN		0x01
#define OBJ_AKTION_STAT_OFFEN		0x02

#define OBJ_AKTION_STAT_ENTSTEHEN	 0x00
#define OBJ_AKTION_STAT_BLEIBEN		 0x01
#define OBJ_AKTION_STAT_VERSCHWINDEN 0x02
/////////////////////////////////////////////////////////////////////////
typedef struct
{
    u16	Wand;
}RAUM;
/////////////////////////////////////////////////////////////////////////
#define	WAND_OBEN				0x1
#define	WAND_LINKS				0x2
#define	WAND_UNTEN				0x4
#define	WAND_RECHTS				0x8
#define	TUER_OBEN				0x10
#define	TUER_LINKS				0x20
#define	TUER_OBEN_OFFEN			0x40
#define	TUER_LINKS_OFFEN		0x80
#define	TUER_OBEN_WILL_OPEN		0x100
#define	TUER_LINKS_WILL_OPEN	0x200

/////// Neu (Tobias - 2002-05-03)
#define TUER_OBEN_UND_OFFEN		(TUER_OBEN |TUER_OBEN_OFFEN)
#define TUER_LINKS_UND_OFFEN	(TUER_LINKS|TUER_LINKS_OFFEN)
#define tuer_obenoffen(wand)	((wand&TUER_OBEN_UND_OFFEN)  == TUER_OBEN_UND_OFFEN)
#define tuer_linksoffen(wand)	((wand&TUER_LINKS_UND_OFFEN) == TUER_LINKS_UND_OFFEN)
//////////////////////////////////////////

/*
#define	TRUHE_OBEN				0x01
#define	TRUHE_UNTEN				0x02
#define	TRUHE_LINKS				0x04
#define	TRUHE_RECHTS			0x08
#define	TRUHE_OBEN_OFFEN		0x10
#define	TRUHE_UNTEN_OFFEN		0x20
#define	TRUHE_LINKS_OFFEN		0x40
#define	TRUHE_RECHTS_OFFEN		0x80
*/

#define	KOLLISION_OBEN      0x01
#define	KOLLISION_UNTEN 	0x02
#define	KOLLISION_LINKS     0x04
#define	KOLLISION_RECHTS	0x08
/////////////////////////////////////////////////////////////////////////
typedef	struct
{
	u8	Aktion;
	u8	pos;
    u8	Function;
    u8	Welches_Menu;
}INTERFACE;
/////////////////////////////////////////////////////////////////////////
#define	INTERFACE_AKTION_WARTEN			0
#define	INTERFACE_AKTION_HOCHFAHREN		3
#define	INTERFACE_AKTION_MENU			2																
#define	INTERFACE_AKTION_RUNTERFAHREN	1

#define	INTERFACE_MENU_OPTIONS			0
#define	INTERFACE_MENU_SAMMELN			1
#define	INTERFACE_MENU_WAFFEN			2
#define	INTERFACE_MENU_RUESTUNG			3
#define	INTERFACE_MENU_ITEM				4
#define	INTERFACE_MENU_MAGIE_WEISS		5
#define	INTERFACE_MENU_MAGIE_ELEMENT	6
#define	INTERFACE_MENU_MAGIE_DEMON		7

#define	INTERFACE_MENU_PFEIL_LEFT		1
#define	INTERFACE_MENU_PFEIL_RIGHT		2
#define	INTERFACE_MENU_PFEIL_UP			4
#define	INTERFACE_MENU_PFEIL_DOWN		8

/////////////////////////////////////////////////////////////////////////
typedef struct
{
	char	*name;
	u8		ObjTyp;
	int		HP, MP;
	u16		AW_MIN, AW_MAX;
	int		VW, SPEED;
	u8		PATHMAX;
	int		REFR, ACHI /* 1 - Demon */, IMMUN, EXP;
	u8		MENU;
    u8		*GFX;
    u16		*PAL;
    int		SH, BOX_X, BOX_Y;
	u8		ATTACKDIST;
	int		DYN_STAT;
	u8		SFX_Treffer,SFX_Sterben;
	int		ATTACK;
}ATTR;
/////////////////////////////////////////////////////////////////////////
#define	ATTR_ATTACK_PHYSISCH			0x1
#define	ATTR_ATTACK_FEUER				0x2
#define	ATTR_ATTACK_EIS					0x4

#define	ATTR_ACHI_UNTOTER				0x01
#define	ATTR_ACHI_FIRE					0x02
#define	ATTR_ACHI_ICE					0x04
#define	ATTR_ACHI_POISON				0x08
#define	ATTR_ACHI_FLASH					0x10
#define	ATTR_ACHI_LIGHT					0x20
/////////////////////////////////////////////////////////////////////////
typedef	struct
{
	u8	Left_Gfx,Right_Gfx;
	WAFFEN	Left,Right;
}HANDS;
/////////////////////////////////////////////////////////////////////////
typedef	struct
{
	u8	Left_Gfx,Right_Gfx;
	WAFFEN	Left,Right;
}RUESTUNG;
/////////////////////////////////////////////////////////////////////////
#define	RUNEN_FELD_SONNE	0
#define	RUNEN_FELD_MOND	1
#define	RUNEN_FELD_STERNE	2
#define	RUNEN_FELD_FEUER	3
#define	RUNEN_FELD_WASSER	4
#define	RUNEN_FELD_ERDE	5
#define	RUNEN_FELD_WIND	6
#define	RUNEN_FELD_HOLZ	7

#define	RUNEN_FEUER				0
#define	RUNEN_WASSER			1
#define	RUNEN_WIND				2
#define	RUNEN_ERDE				3
#define	RUNEN_HOLZ				4
#define	RUNEN_SONNE				5
#define	RUNEN_MOND				6
#define	RUNEN_STERNE			7
#define	RUNEN_VERGANGENHEIT		9
#define	RUNEN_JETZT				10
#define	RUNEN_ZUKUNFT			11
#define	RUNEN_GLUECK			12
#define	RUNEN_COURAGE			13
#define	RUNEN_STAERKE			14
#define	RUNEN_WEISHEIT			15
#define	RUNEN_MONOLITH			16
/////////////////////////////////////////////////////////////////////////
typedef struct
{
	u8	Objekt_Typ;
	u8	Waffen_Typ;
	u16	AW_MIN,AW_MAX;				// Waffen , Ring
    s8 	SPEED_UP;                   // Amulett, Waffen, R�STUNG, SCHILD, Ring
    u8	Cont_Schaden_Typ;			// Waffen 1 - Eis , 2 - Feuer , 3 - Gift, 4 - Light
    s16	Cont_Schaden_AW_MIN,Cont_Schaden_AW_MAX;
	u8	Name;
    s8	Num;					// Items
}SAVEWAFFEN;
/////////////////////////////////////////////////////////////////////////
typedef struct
{
	u8	Objekt_Typ;
	u8	Waffen_Typ;
    u16	ShieldVW;					// R�stung, Schild, Ring, Amulett
    u8 	RES_FIRE;					// R�stung, Schild, Amulett, Ring
    u8 	RES_ICE;                    // R�stung, Schild, Amulett, Ring
    u8 	RES_POISON;                 // R�stung, Schild, Amulett, Ring
    u8 	RES_FLASH;                  // R�stung, Schild, Amulett, Ring
    u8 	RES_LIGHT;                  // R�stung, Schild, Amulett, Ring
    s8 	SPEED_UP;                   // Amulett, Waffen, R�STUNG, SCHILD, Ring
	u8	Name;
}SAVERUESTUNGEN;
/////////////////////////////////////////////////////////////////////////
typedef struct
{
	u8	Objekt_Typ;
	u8	Waffen_Typ;
    u16	Str,Dex,Int;				// Amulett
	u16	AW_MIN,AW_MAX;				// Waffen , Ring
    u8 	RES_FIRE;					// R�stung, Schild, Amulett, Ring
    u8 	RES_ICE;                    // R�stung, Schild, Amulett, Ring
    u8 	RES_POISON;                 // R�stung, Schild, Amulett, Ring
    u8 	RES_FLASH;                  // R�stung, Schild, Amulett, Ring
    u8 	RES_LIGHT;                  // R�stung, Schild, Amulett, Ring
    s8 	SPEED_UP;                   // Amulett, Waffen, R�STUNG, SCHILD, Ring
    s8	ZauberSpruch_idx;			// Ring, Amulett, Rollen, B�cher
	u8	ZauberSpruchStufe;			// Ring, Amulett, Rollen, B�cher
    s8	Num;						// Items
}SAVEITEMS;
/////////////////////////////////////////////////////////////////////////
typedef struct
{
	u8	Objekt_Typ;
	u8	Waffen_Typ;
    s8	ZauberSpruch_idx;			// Ring, Amulett, Rollen, B�cher
	u8	ZauberSpruchStufe;			// Ring, Amulett, Rollen, B�cher
	u32	Magic_Exp,Magic_Next_Exp;
	s8	Num;
}SAVEBOOKS;
/////////////////////////////////////////////////////////////////////////

#define mbchar(c1,c2,c3,c4)	(c4<<24 | c3<<16 | c2<<8 | c1<<0)
#define PLAYERSAVE_KENNUNG mbchar('D','H','S','9')

#define Items_Max 33

typedef enum {
	pcGlobal=0, pcWarrior, pcHunter, pcMage
,PlayerClass_num} PlayerClass;


typedef	struct
{
	u32 Kennung;
	char Name[16];
	u32	Ges_Souls;
	u16	Str_Org,Dex_Org,Int_Org;
	int	HP_MAX,MP_MAX;
	int	HP,MP;
    float	Magie_Weiss_Next_Exp,Magie_Element_Next_Exp,Magie_Demon_Next_Exp,Waffen_Next_Exp,Bogen_Next_Exp,Next_Exp;
    float	Magie_Weiss_Exp,Magie_Element_Exp,Magie_Demon_Exp,Waffen_Exp,Bogen_Exp,Exp;
    u8	Magie_Weiss_Lvl,Magie_Element_Lvl,Magie_Demon_Lvl,Waffen_Lvl,Bogen_Lvl,Lvl;
	u8	LevelMax;
	u8	ChapterSeen;
	u16	chapters_unlocked;
	HANDS	Hands;
	RUESTUNG Ruestung;
	WAFFEN	Kiste[32];
	u8		Kiste_Num;
	SAVEWAFFEN	Waffen[9];
	u8		Waffen_Num;
	SAVERUESTUNGEN	Ruestungen[9];
	u8		Ruestungen_Num;
	SAVEITEMS	Items[Items_Max];
	u8		Items_Num;
	SAVEBOOKS	Magie_Weiss[9];
	u8		Magie_Weiss_Num;
	SAVEBOOKS	Magie_Element[9];
	u8		Magie_Element_Num;
	SAVEBOOKS	Magie_Demon[9];
	u8		Magie_Demon_Num;
	////////////////////////////////////////
	u8		PlayerLevel_Bases[32];
	////////////////////////////////////////
	bool	Sound_on_off;
	u8		Kontrast, Helligkeit;
	////////////////////////////////////////
	s8		ChapterLastLevel[8];
	s8		LevelQueue[32];
	s8		LevelQueue_top;
	////////////////////////////////////////
	PlayerClass		Class;
	u32		cheats;
	int		levelup_counter;
	s16		attackplaces[8];
	s32		VW;

	bool	portal_opened;
	int		portal_x, portal_y;
	u8		portal_level;
	s8		Portal_Anim_Count;
	s8		Portal_Anim_Pos;
	
	s16		Aura_Counter;
	u8		Aura_ObjTyp;
	u8		Aura_Level;
	u8		Aura_Anim;

	u8		Cont_Schaden_Typ;
	s16		Cont_Schaden_Typ_Counter;
	s16		Cont_Schaden_AW_MIN;
	s16		Cont_Schaden_AW_MAX;
	u16		collision_gid;

	s8		Richtung;
	int		Beben;
	int		Beben_counter;

}PLAYERSAVE;
/////////////////////////////////////////////////////////////////////////
typedef	enum enum_SCHWERTER {
  DAGGER,SHORT_SWORD,BLADE
 ,GLADIUS,TOOTH_SWORD,SABRE
 ,BROAD_SWORD,LONG_SWORD,BATTLE_SWORD
 ,GREAT_SWORD,DRAGONSLAYER,HERO_BLADE
}enum_SCHWERTER;
/////////////////////////////////////////////////////////////////////////
typedef	enum enum_AXT {
 WAR_HATCHET,HAND_AXE,COMBAT_AXE,
 AXE,BATTLE_AXE,CLEAVER,
 DOUBLE_AXE,BROAD_AXE,LARGE_AXE,
 BONEBREAKER,DWARF_AXE,GIANT_AXE
}enum_AXT;
/////////////////////////////////////////////////////////////////////////
typedef	enum enum_KEULE_ZEPTER {
 CLUB,SPIKED_CLUB,
 BATTLE_MACE,MORNING_STAR,
 BATTLE_MALLET,WAR_HAMMER,
 MAGIC_STAFF,SACRET_STAFF,WIZARDS_STAFF,
 SCEPTER,GRAND_SCEPTER,WAR_SCEPTER
}enum_KEULE_ZEPTER;
/////////////////////////////////////////////////////////////////////////
typedef	enum enum_BOGEN {
 SHORT_BOW,HUNT_BOW,
 LONG_BOW,BATTLE_BOW,
 AMAZON_BOW,ONYX_BOW,
 ELBISH_BOW,GREAT_WAR_BOW
}enum_BOGEN;
/////////////////////////////////////////////////////////////////////////
typedef	enum enum_SCHILD {
 DEFENDER,SMALL_SHIELD,WOODEN_SHIELD,
 SQUARE_SHIELD,LIGHT_SHIELD,IRON_SHIELD,
 LARGE_SHIELD,PLATIN_SHIELD,HERALD_SHIELD,
 KINGS_SHIELD,DRAGON_SHIELD,DIAMOND_SHIELD
}enum_SCHILD;
/////////////////////////////////////////////////////////////////////////
typedef	enum enum_RUESTUNG {
 VEST,RIVET_VEST,LEATHER_SUIT,
 CHAIN_MAIL,LIGHT_ARMOR,STEEL_SKIN,
 BREAST_PLATE,GRANITE_FLEECE,IRON_ARMOR,
 KINGS_ARMOR,WAR_PLATE,JEWEL_VEST
}enum_RUESTUNG;
/////////////////////////////////////////////////////////////////////////
/*typedef	enum enum_ZEPTER {
 "MAGIC STAFF","SACRET STAFF","WIZARDS STAFF",
 "SCEPTER","GRAND SCEPTER","WAR SCEPTER",
/////////////////////////////////////////////////////////////////////////
typedef	enum enum_BOGEN {
 "SHORT BOW","HUNT BOW",
 "LONG BOW","BATTLE BOW",
 "AMAZON BOW","ONYX BOW",
 "ELBISH BOW","GREAT WAR BOW",
*/

#define	HANDS_WAFFEN	0

typedef enum 
{
	pmStand, 
	pmSneak, 
	pmWalk, 
	pmRun, 
	pmJumping, 
	pmJumpingFast,
	pmJumped
} WALKMODE;

typedef	struct
{
	OBJECT *playerobj;
	int		id;

	//////////////////////////////////////////////////////////////////////////
	char Name[16];
	WAFFEN	Kiste[32];
	u32	Ges_Souls;
	u16	AW_MIN,AW_MAX,VW_MAX,VW_Org,AW_MIN_Org,AW_MAX_Org;
	u16	Str,Dex,Int;
	int	HP_MAX,MP_MAX;
    float	Magie_Weiss_Next_Exp,Magie_Element_Next_Exp,Magie_Demon_Next_Exp,Waffen_Next_Exp,Bogen_Next_Exp,Next_Exp;
    float	Magie_Weiss_Exp,Magie_Element_Exp,Magie_Demon_Exp,Waffen_Exp,Bogen_Exp,Exp;
    u8	Magie_Weiss_Lvl,Magie_Element_Lvl,Magie_Demon_Lvl,Waffen_Lvl,Bogen_Lvl,Lvl;
    s16	Agi;
	u16	Str_Org,Dex_Org,Int_Org;
    u8	Res_Fire,Res_Ice,Res_Poison,Res_Flash;
    s16	Sprung_Y,Sprung_Y_Add;
	s16	Emoticon;
    u8	Waffe,Burghof,ZigeunerMenu;
    u8	Speed;
	s8	AKT_LEVEL;
	u8	Kiste_Num;
	u8	LevelMax;

	//////////////////////////////////////////////////////////////////////////
	
	int 	Cont, Trg;					// Key input

	int		Rennen_Timer,Rennen;
	int		Angriffs_Button;

	int 	POWERUP;
	int		Richtung_tmp;

	int 	Player_x,Player_y;
	int		movement_x,movement_y;

	HANDS	Hands;
	WAFFEN	*AktionHand;	// Pointer auf Hand aus 'Hands', die zur aktuellen Aktion geh�rt
	RUESTUNG Ruestung;

	WAFFEN	Waffen[9];
	int		Waffen_Num;
	WAFFEN	Ruestungen[9];
	int		Ruestungen_Num;

	WAFFEN	Items[Items_Max];
	int		Items_Num;

	WAFFEN	Magie_Weiss[9];
	int		Magie_Weiss_Num;
	WAFFEN	Magie_Element[9];
	int		Magie_Element_Num;
	WAFFEN	Magie_Demon[9];
	int		Magie_Demon_Num;

	INTERFACE	Interface;
	s8	InterfaceFunction;
	u8	InterfaceFunctionPast;

	int				noiselevel;	// 0= Stille, 1= leises Ger�usch, 2= lautes Ger�usch
	WALKMODE		walkmode;
	PlayerClass		Class;

	int screencells_x0 , screencells_y0 ;
	int screencells_x1 , screencells_y1 ;
	int screencells_x0o, screencells_y0o;
	int screencells_x1o, screencells_y1o;
	int	screen_x0, screen_y0, screen_x1, screen_y1;

	bool	portal_opened;
	int		portal_x, portal_y;
	u8		portal_level;
	s8		Portal_Anim_Count;
	s8		Portal_Anim_Pos;

	int	special1;
	int special1_dir;
	int special1_dif;
	int special1_counter;

	int	special2;
	int	special2_dif_1;
	int	special2_dif_2;

	bool	cheat_annihilator;
	bool	cheat_invulnerable;
	bool	cheat_unlimammo;

	int		target_objnr;	// ehemals "Der_Gegner"
	s16		attackplaces[8];
	s8		attackplaces_allocated_num;	// wieviele Attackplaces durch Monster belegt sind (also grobe Ma�einheit, wie stark der Player gerade belagert wird)

	#define	triggersperobj_max 8
	s16		triggers_running[triggersperobj_max];	// Trigger, die dieser Player derzeit ausgel�st hat
	u16		triggers_running_r[triggersperobj_max];	// ...die zugeh�rigen reaction-ids

	int		levelup_counter;	// LevelUp-Aura aktiv, wenn >0

} PLAYERINFO;

#endif
