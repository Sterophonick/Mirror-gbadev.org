#ifndef _inc_dbgprint_h
#define _inc_dbgprint_h

#define printvi(x)	printf(#x"=%i"newline,x)

#endif // _inc_dbgprint_h
