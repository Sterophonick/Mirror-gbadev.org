#include <malloc.h>
#include "main.h"
#include "interrupt.h"
#ifdef DEBUGGING

#define VersionStr "--TestVersion--"
/**********************************************************************************************/
////////////////////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////////////////////
/**********************************************************************************************/

#define PRINT_TO_DEBUG_CONSOLE

char const map_dez2hex[16]={'0','1','2','3','4','5','6','7','8','9','A','B','C','D','E','F'};

int dprinthex(int v, int x, int y)
{
	char s[9];
	int i;
	for (i=7; i>=0; i--)
	{
		s[i]=map_dez2hex[v&15];
		v>>=4;
	}
	s[8]=0;
	return PrintStr(s,x,y);
}

void dprintbin(int v, int x, int y)
{
	int i;
	char s[33];
	s[32]=0;
	for (i=0; i<32; i++)	s[i]= '0'+(v>>(31-i)&1);
	PrintStr(s+2,x,y);
}

void dprintbin2(int v, int x, int y)
{
	int i;
	char s[33];
	s[32]=0;
	for (i=0; i<32; i++)	s[i]= (v>>(31-i)&1)?'1':' ';
	PrintStr(s+2,x,y);
}

int dprintl_int(int value, int x, int y, int len, int print_sign);
int dprintint(int v, int x, int y)
{
	return dprintl_int(v,x,y,0,false);
//	return PrintIntPM(v,x,y);
}

int dprintstr(char *s, int x, int y)
{
	return PrintStr(s,x,y);
}

#ifdef PRINT_TO_DEBUG_CONSOLE
char printfbuffer[2048] EWRAM;
int __wrap_printf( const char *s, ... )
{
	va_list arg_ptr;
	va_start(arg_ptr, s);

	int n= vsprintf(printfbuffer,s,arg_ptr);
	dprint(printfbuffer);

	return n;
}


int __wrap_fprintf( FILE *f, const char *s, ... )
{
	va_list arg_ptr;
	va_start(arg_ptr, s);

	int n= vsprintf(printfbuffer,s,arg_ptr);
	dprint(printfbuffer);

	return n;
}

#endif

void dprint(char *s)
{

#ifdef PRINT_TO_DEBUG_CONSOLE
	#ifdef __thumb__
	asm volatile("mov r0, %0;"
				"swi 0xff;"
				: // no ouput
				: "r" (s)
				: "r0");
	#endif
	////////////////////////////////////////////////////////////////////////////////////////////////
	#ifdef __arm__
	asm volatile(
				"mov r0, %0;"
				"swi 0xff0000;"
				: // no ouput
				: "r" (s)
				: "r0");
	#endif
////////////////////////////////////////////////////////////////////////////////////////////////
#else
////////////////////////////////////////////////////////////////////////////////////////////////
	PrintStr(s,0,0,(u16*)0x2800);
////////////////////////////////////////////////////////////////////////////////////////////////
#endif
}				

void dbg_showconsole()
{
	#ifdef __thumb__
	asm volatile("swi 0xfa;");
	#endif

	#ifdef __arm__
	asm volatile("swi 0xfa0000;");
	#endif
}

/**********************************************************************************************/
////////////////////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////////////////////
/**********************************************************************************************/
u32 dtimer_cycles[dtimer_num+1] EWRAM;
u32 dtimer_cycles_start[dtimer_num+1] EWRAM;
u16 dtimer_lines[dtimer_num+1] EWRAM;
u16 dtimer_lines_start[dtimer_num+1] EWRAM;
u32 dtimer_history_cycles[dtimer_num] EWRAM;
u16 dtimer_history_lines[dtimer_num] EWRAM;
u16 dtimer_history_rel[dtimer_num] EWRAM;

s8 dtimer_ref[dtimer_num] EWRAM={-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1} ;
////////////////////////////////////////////////////////////////////////////////////////////////
void dtstart(int nr)
{
	if (nr<0 || nr>dtimer_num) return;

	dtimer_lines_start[nr] =*(vu16*)REG_VCOUNT;
	*(vu16*)REG_TM2CNT_H = 0x81;	// TimerActive (b7=1), NoIRQ (b6=0), NoCountUp	(b2=0), SystemClock/64 (b1+b0=01)
	*(vu16*)REG_TM3CNT_H = 0x84;	// TimerActive (b7=1), NoIRQ (b6=0),   CountUp	(b2=1)

	dtimer_cycles_start[nr] = (*(vu16*)REG_TM2CNT_L) | ((*(vu16*)REG_TM3CNT_L)<<16);
}

void dtstopr(int nr, int ref)
{
	if (nr<0 || nr>dtimer_num) return;
	dtimer_ref[nr]=ref;

	u16 now_l=	*(vu16*)REG_VCOUNT;
	u32 now_c= (*(vu16*)REG_TM2CNT_L) | ((*(vu16*)REG_TM3CNT_L)<<16);

	if (now_l<dtimer_lines_start[nr]) now_l+=228;	// overflow at 228 lines

	dtimer_lines [nr] = now_l - dtimer_lines_start[nr];
	dtimer_cycles[nr] = now_c - dtimer_cycles_start[nr];
}

void dtstopar(int nr, int ref)
{
	if (nr<0 || nr>dtimer_num) return;
	dtimer_ref[nr]=ref;

	u16 now_l=	*(vu16*)REG_VCOUNT;
	u32 now_c= (*(vu16*)REG_TM2CNT_L) | ((*(vu16*)REG_TM3CNT_L)<<16);

	if (now_l<dtimer_lines_start[nr]) now_l+=228;	// overflow at 228 lines

	dtimer_lines [nr] += now_l - dtimer_lines_start[nr] ;
	dtimer_cycles[nr] += now_c - dtimer_cycles_start[nr];
}

void dtstop(int nr)
{
	dtstopr(nr, -1);
}

void dtstopa(int nr)
{
	dtstopar(nr, -1);
}


/**********************************************************************************************/
////////////////////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////////////////////
/**********************************************************************************************/

s8 dbg_screen_active=0;
u8 history_cur=0;

extern u16 FrameData_first, FrameData_end;
extern int freecount;
extern u8 __iheap_start, __eheap_start;

int dtimer_history_nr_old=-1;
int dtimer_hmax_cycles;
int dtimer_hmax_lines ;
int dtimer_hmax_rel   ;

int debug[debug_num];

/**********************************************************************************************/
////////////////////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////////////////////
/**********************************************************************************************/
int history_select=11;
void dbg_screen_gen(int dif)
{
#ifdef DEBUGGING
	u8 dummy[8];
	int i;

	history_select+=dif;

	if (history_select>dtimer_max) history_select=0;
	if (history_select<0         ) history_select=dtimer_max;

//	dtimer_lines[11]+= dtimer_lines[10];
//	dtimer_cycles[11]+= dtimer_cycles[10];

/*
	PrintInt(Der_Raum%32  ,7 ,0,0x2800);
	PrintInt(Der_Raum/32  ,11,0,0x2800);
	PrintInt(Get_Objekt_X_POS(Mein_Player)*8  ,17 ,0,0x2800);
	PrintInt(Get_Objekt_Y_POS(Mein_Player)*8  ,23 ,0,0x2800);
/**/
/*
	PrintInt(Screen_x0	,07 ,0,0x2800);
	PrintInt(Screen_x1	,11 ,0,0x2800);
	PrintInt(Screen_y0	,17 ,0,0x2800);
	PrintInt(Screen_y1	,23 ,0,0x2800);
/**/
/*
	dprintint(FrameData_first,10,0);
	dprintint(FrameData_end,20,0);
	dprintint(freecount,28,0);
*/
	for (i=0; i<debug_num; i++)
	{
		dprintint(debug[i],(i+1)*6-1,0);
	}


	///////////////////////////////////////
	PrintStr("NR LIN CYC %" ,0,2);
	
	for (i=0; i<dtimer_num; i++)
	{
		char s[5];
		s[1]=0;
		s[0]=map_dez2hex[i%16];
		dprintstr(s, 0,3+i);

		if (dtimer_lines [i]) PrintInt(dtimer_lines[i], 4,3+i);
		if (dtimer_cycles[i]) 
		{
			int ri=dtimer_ref[i];
			int r;
			PrintInt((dtimer_cycles[i]*64)/1024 ,8,3+i);

			if (ri!=-1)
			{
				s[0]='/';
				s[1]=map_dez2hex[ri%16];
				s[2]=0;
				dprintstr(s ,13,3+i);

				r=dtimer_cycles[ri];

				if (r)	PrintInt(dtimer_cycles[i]*100/r ,12,3+i);
				else {s[0]='-'; s[1]=0; dprintstr(s ,12,3+i); }
			}
		}
	}
	
	///////////////////////////////////////
	int sum;
	int x,y;
	char s[5];

	x=dprintstr("Timer ",17,2);
	s[0]=map_dez2hex[history_select%16];
	s[1]=0;
	dprintstr(s,x,2);

	if (history_select!=dtimer_history_nr_old)
	{
		dtimer_hmax_cycles=0;
		dtimer_hmax_lines =0;
		dtimer_hmax_rel   =0;
		dtimer_history_nr_old=history_select;
	}

	//////////////////////////
	y=3;
	x=dprintstr("A:",17,y);
	
	for (sum=0, i=0; i<dtimer_num; i++) sum+=dtimer_history_lines[i];
	dprintint(sum/dtimer_num,x+4,y);
	dprintstr("LINES",x+6,y);

	y++;

	for (sum=0, i=0; i<dtimer_num; i++) sum+=dtimer_history_cycles[i];
	dprintint(((sum*64)/1024)/dtimer_num,x+4,y);
	dprintstr("CYCLS",x+6,y);

	y++;

	for (sum=0, i=0; i<dtimer_num; i++) sum+=dtimer_history_rel[i];
	dprintint(sum/dtimer_num,x+4,y);
	dprintstr("%/",x+5,y);
	s[0]=map_dez2hex[dtimer_ref[history_select]%16];
	dprintstr(s,x+7,y);

	y+=2;
	//////////////////////////////
	x=dprintstr("M:",17,y);
	
	dprintint(dtimer_hmax_lines,x+4,y);
	dprintstr("LINES",x+6,y);

	y++;

	dprintint((dtimer_hmax_cycles*64)/1024,x+4,y);
	dprintstr("CYCLS",x+6,y);

	y++;

	dprintint(dtimer_hmax_rel,x+4,y);
	dprintstr("%/",x+5,y);
	s[0]=map_dez2hex[dtimer_ref[history_select]%16];
	dprintstr(s,x+7,y);

	y++;
	//////////////////////////////

	int x0=17;
	x=x0;
	dprintint(Object_num,x,y); x=dprintstr("OBJ",x+2,y); x+=2;
	dprintint(Akt_ATT_OBJEKTE_num,x,y); x=dprintstr("ATT",x+2,y);
	x=x0; y++;
	dprintint(Object_overflow,x,y); dprintstr("ERR",x+2,y);
	y++;

	x=x0;
	dprintint(vb_oams_num_prev,x,y); x=dprintstr("OAMS",x+2,y);
	x+=2;
	int savp=vb_transfer_save_prev*100/(vb_transfer_save_prev+vb_transfer_done_prev);
	dprintint(savp,x,y); x=dprintstr("%SAV",x+1,y); y++;


	

/*
	x=28;
	dprintint(vb_count_get,x,y); y++;
	dprintint(vb_count_free,x,y); y++;
	dprintint(vb_oam_num_prev,x,y); y++;
	dprintint(vb_toadd_num_prev,x,y); y++;
	dprintint(vb_free,x,y); y++;

	x=21;
	y-=5;
	dprintint(vb_count_getfailed,x,y); y++;
	dprintint(vb_count_getkicked,x,y); y++;
	dprintint(vb_count_getunused,x,y); y++;
	dprintint(vb_count_getnormal,x,y); y++;
	dprintint(vb_free_prev,x,y); y++;
/**/

	//////////////////////////////

	x=dtimer_lines[history_select];
	if (x>dtimer_hmax_lines) dtimer_hmax_lines=x;
	dtimer_history_lines[history_cur]=x;

	x=dtimer_cycles[history_select];
	if (x>dtimer_hmax_cycles) dtimer_hmax_cycles=x;
	dtimer_history_cycles[history_cur]=x;

	{
		int ri=dtimer_ref[history_select];
		if (ri!=-1)
		{
			int r;
			int x=dtimer_cycles[ri];
			r=(x) ? dtimer_cycles[history_select]*100/x : 100;
			if (r>dtimer_hmax_rel) dtimer_hmax_rel=r;
			dtimer_history_rel[history_cur]= r;
		}		
	}
	
	if (++history_cur>=dtimer_num) history_cur=0;

	
	//	PrintStr(VersionStr,(30-sizeof(VersionStr)+1)/2,15);
	
	x=0;
	x=PrintStr("RAMI:",x,15); 
	x=PrintInt2(((int)&dummy-(int)&__iheap_start) ,x,15);
	x=PrintStr("/",x,15); 
	x=PrintInt2(CPU_WRAM_SIZE-((int)&__iheap_start-CPU_WRAM) ,x,15);

	struct mallinfo info;
	int free, all, esize=(int)&__eheap_start-EX_WRAM;
	info=mallinfo();
	all =EX_WRAM_SIZE-esize;
	free=info.fordblks + (all-info.arena);

	x=PrintStr(" E:",x,15);	x=PrintInt2(free,x,15);
	
	x=PrintStr("/",x,15);	x=PrintInt2(all,x,15);

#endif
}

void dtresetall()
{
	int i;
	for (i=0; i<dtimer_num; i++)
	{
		dtimer_lines [i]=0;
		dtimer_cycles[i]=0;
	}
}

//////////////////////////////////////////////////////////////////////////////////////////////

int dprintl_int(int value, int x, int y, int len, int print_sign)
{
	u16 *vtmp= Text_Screen + y*32;
	int xo;
	u16 sign=0;

	if (value<0)	{value= -value; sign=Zeichensatz_Map['-'];}
	else			{value= +value; sign=print_sign?Zeichensatz_Map['+']:0;}
	//		ich wei� ^^^^^^^^^^^^^ ist ein Dummy - aber sieht besser aus ;)

	xo=x+1;
	x+=len;
	do
	{
		vtmp[x]	= (15<<12)|(118*2 + Zeichensatz_Map[ '0' + value%10]); 
		value/=10;
		x--;
	}
	while (value);
	if (sign && !print_sign) {vtmp[x]= (15<<12)|(118*2 + sign); x--;}

	while (x>=xo)
	{
		vtmp[x]	= (15<<12)|(118*2 + Zeichensatz_Map[' ']); 
		x--;
	}
	if (sign && print_sign) vtmp[x]	= (15<<12)|(118*2 + sign);

	return xo+len;
}
//////////////////////////////////////////////////////////////////////////////////////////////

#define PrintC(c,x,y) PrintChr(c, x,y);
#define PrintS(s,x,y) PrintStr(s, x,y);
#define PrintLabel(label)			({	x=PrintStr(label,x,y);})
#define PrintDataInt(label,data,w)	({	PrintLabel(label); x=dprintl_int( (data),x-1,y,w,0);})

int dprintl_fxp(int value, int x, int y, int len1, int len2, int print_sign)
{
	u16 *vtmp= Text_Screen + y*32;
	int xo, len;
	u16 sign=0;

	int i;
	int digits_val=1;
	for (i=0; i<len2; i++) digits_val*=10;

	value*=digits_val;
	value+=(value>0)?128:-128;	// zum korrekten Runden
	value/=256;

	if (value<0)	{value= -value; sign= Zeichensatz_Map['-'];}
	else			{value= +value; sign= print_sign?Zeichensatz_Map['+']:0;}
	//		ich wei� ^^^^^^^^^^^^^ ist ein Dummy - aber sieht besser aus ;)

	xo=x+1;
	len=len1+len2;
	if (len2) len++;	// f�r Komma
	
	x+=len;

	int c, zero=1;

	do
	{
		if (len2) len2--;

		int digit= value%10;
		c= (zero&&!digit) ? ' ' : ('0'+digit);

		vtmp[x]= (15<<12)|(118*2+Zeichensatz_Map[c]);

		if (digit) zero=0;

		value/=10;
		x--;
	} while (len2);

	c= (zero)? ' ' : ':';
	vtmp[x]= (15<<12)|(118*2+Zeichensatz_Map[c]); 
	x--;

	do
	{
		vtmp[x]= (15<<12)|(118*2+Zeichensatz_Map['0'+value%10]);
		value/=10;
		x--;
	} while (value);

	while (x>=xo)
	{
		vtmp[x]	= (15<<12)|(118*2 + Zeichensatz_Map[' ']);
		x--;
	}
	if (sign) vtmp[x]	= (15<<12)|(118*2 + sign);

	return xo+len;
}

#define PrintDataFxp(label,data,w,d)	({PrintLabel(label); x=dprintl_fxp(data,x-1,y,w,d,0);})
#define PrintDataFxpS(label,data,w,d)	({PrintLabel(label); x=dprintl_fxp(data,x-1,y,w,d,1);})

int dbgobject_select=0;
////////////////////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////////////////////
void dbg_screen_obj(int dif)
{
	if (dif)
	{
		int looped=3;
		do
		{
			dbgobject_select+=dif;
			if (dbgobject_select>Object_max-1)	{dbgobject_select=0;			looped--; }
			if (dbgobject_select<0)				{dbgobject_select=Object_max-1;	looped--; }
		} while (Object[dbgobject_select].type==255  &&  looped);
	}

	OBJECT *obj = obj_from_objnr(dbgobject_select);

	int x,y;

	y=0; x=4;
	PrintDataInt("O:", dbgobject_select,2); x++;
	PrintDataInt("L:", obj->level,2); x++;
	PrintDataInt("T:", obj->type,2); x++;
	PrintLabel(ATTRIBUTE[obj->type].name);
	y++;	// Balken...
	y++; x=0;
	PrintDataFxp(" X:", obj->Real_x_pos,4,3); x++;
	PrintDataFxp(" Y:", obj->Real_y_pos,4,3);
	PrintDataInt("", obj->Cell%32,2); PrintDataInt(":", obj->Cell/32,2);
	y++; x=0;
	PrintDataFxpS("+X:", obj->Movement_x,4,3); x++;
	PrintDataFxpS("+Y:", obj->Movement_y,4,3); x++;
	y++; x=0;
	PrintDataFxp("NX:", obj->TargetNext_x<<8,4,3); x++;
	PrintDataFxp("NY:", obj->TargetNext_y<<8,4,3);
	y++; x=0;
	PrintDataFxp("TX:", obj->TargetPos_x<<8,4,3); x++;
	PrintDataFxp("TY:", obj->TargetPos_y<<8,4,3);
	y++; x=0;

	OBJECT *target= NULL; if (ATTRIBUTE[obj->type].DYN_STAT==OBJ_OBJ_TYP_DYN && obj->target_objnr!=0xFF) target= obj_from_objnr(obj->target_objnr);
	if (target)
	{
		PrintDataFxp("EX:", target->Real_x_pos,4,3); x++;
		PrintDataFxp("EY:", target->Real_y_pos,4,3);
		PrintDataInt("", target->Cell%32,2); PrintDataInt(":", target->Cell/32,2);
	}
	y++; x=0;
/*
	PrintDataInt("PATH:", obj->path_len,1); x++;
	x=dprinthex(obj->path,x,y); x++;
*/
	PrintDataInt("Dir: ", obj->Richtung,1); x++;
	PrintDataInt(": ", get_targetdir(obj),1); x++;
	PrintDataInt("Cnt: ", obj->Counter,4); x++;
	y++; x=0;

	u32 path=obj->path;
	u32 plen=get_pathlen(obj);

	//						stopcode_targ	stopcode_door	stopcode_edge	stopcode_pos
	char stopcode_name[4] = {'T', 'D', 'E', 'P'};

	if (get_is_onscreen(obj))
	{
		PrintLabel("S1");
		//PrintC(, x,y); x++;
		char s[2];
		int code= get_stopcode(obj);
		s[0]= (code>=0 && code<4)? stopcode_name[code] : 0;
		s[1]= 0;
		PrintDataInt(s, code, 3); x+=2;

		PrintDataInt("O: ", get_sobjnr(obj),2); x++;
		if (get_stopcode(obj)==stopcode_edge)
		{
			PrintLabel("C:");
			char *corner_name[4] = {"TL", "TR", "BL", "BR"};
			PrintLabel(corner_name[get_corner(obj)]); x++;

			char *edgedir_name[4] = {"-", "L","R","!"};
			PrintLabel(edgedir_name[get_edgedir(obj)]); x++;
		}

		PrintDataInt("T: ", obj->UpdateCounter, 4);
	}
	else
	{
		PrintLabel("S0");
		PrintC(stopcode_name[get_stopcode(obj)], x,y);

		//					dc_up, dc_dn, dc_lf, dc_rg
		char dc_name[4] = {'U', 'D', 'L', 'R'};
		int i;
		for (i=0; i<plen; i++)
		{
			PrintC(path_is_free(path)?' ':':' , 28,2+i); 
			PrintC(dc_name[dc_from_path(path)], 29,2+i); 
			path>>=3;
		}
	}

	int type= ATTRIBUTE[obj->type].DYN_STAT;
/*
	y++;x=0;
	PrintLabel("Klasse: ");
	#define type_num 11
	char *type_name[type_num]= {"NULL", "Dynamisch", "Statisch", "Item", "Schatten", "Falle", "Projektil", "Emoticon", "Balken","Augen","Portal"};
	PrintLabel( (type<type_num)? type_name[type] : "UNBEKANNT" );
*/

	y++;x=0;
	PrintLabel("Aktion: ");
	char *Aktion_name_dyn []={"Warten", "Laufen", "Angriff1", "Angriff2", "Treffer", "Sterben", "Special"};
	char *Aktion_name_stat[]={"zu", "oeffnend", "auf"};
	char *Aktion_name_att []={"Entstehen", "Fliegen", "Verschwinden"};
	char *Aktion_name_item[]={"Entstehen", "Blinken", "Liegen"};

	char **name;
	int num;

	switch (type)
	{
	case OBJ_OBJ_TYP_DYN:	num=sizeof(Aktion_name_dyn ); name=Aktion_name_dyn ; break;
	case OBJ_OBJ_TYP_STAT:	num=sizeof(Aktion_name_stat); name=Aktion_name_stat; break;
	case OBJ_OBJ_TYP_ITEM:	num=sizeof(Aktion_name_item); name=Aktion_name_item; break;
	case OBJ_OBJ_TYP_ATT:	num=sizeof(Aktion_name_att ); name=Aktion_name_att ; break;
	default:	num=0; name=0;
	}
	num/=sizeof(char*);

	int aktion= obj->Aktion;

	if (type==OBJ_OBJ_TYP_DYN)	aktion&= 0x07;

	PrintLabel( (aktion<num)? name[aktion] : "UNBEKANNT");
	if (aktion>=num)	PrintDataInt(" ", aktion,3);

	if (type==OBJ_OBJ_TYP_DYN && aktion==OBJ_AKTION_ANGRIFF1)	
	{
		int attack= (obj->Aktion>>3);
		PrintDataInt(" Att:", attack, 3);
	}

	x++;
	PrintLabel("AttP: ");
	char *place_name[8]={"d","dl","l","ul","u","ur","r","dr"};
	int pos= obj->attackplace;
	if		(pos==-1)			PrintLabel("none");
	else if	(pos>=0 && pos<=7)	PrintLabel(place_name[pos]);
	else						PrintLabel("ERROR");

/*
	y++;x=10;
	if (type==OBJ_OBJ_TYP_DYN && (aktion==OBJ_AKTION_ANGRIFF1  || aktion==OBJ_AKTION_ANGRIFF2))	
	{
		char *s;

		int attack= (obj->Aktion>>3);
		switch(1<<attack)
		{
		case MAGIE_WEISS_HEILUNG		:	s= "MW-HEILUNG";break;
		case MAGIE_WEISS_GENESUNG		:	s= "MW-GENESUNG";break;
		case MAGIE_WEISS_MUT			:	s= "MW-MUT";break;
		case MAGIE_WEISS_TROTZ			:	s= "MW-TROTZ";break;
		case MAGIE_WEISS_SCHUTZ			:	s= "MW-SCHUTZ";break;
		case MAGIE_WEISS_MEDITATION		:	s= "MW-MEDITATION";break;
		case MAGIE_WEISS_LEBENSFUNKE	:	s= "MW-LEBENSFUNKE";break;
		case MAGIE_WEISS_VERWIRRUNG		:	s= "MW-VERWIRRUNG";break;
		case MAGIE_ELEMENT_FEUERKUGEL	:	s= "ME-FEUERKUGEL";break;
		case MAGIE_ELEMENT_FLAMMENWAND	:	s= "ME-FLAMMENWAND";break;
		case MAGIE_ELEMENT_FROSTBEULE	:	s= "ME-FROSTBEULE";break;
		case MAGIE_ELEMENT_MORGENTAU	:	s= "ME-MORGENTAU";break;
		case MAGIE_ELEMENT_FLASH		:	s= "ME-FLASH";break;
		case MAGIE_ELEMENT_COMBOFLASH	:	s= "ME-COMBOFLASH";break;
		case MAGIE_ELEMENT_BEBEN		:	s= "ME-BEBEN";break;
		case MAGIE_ELEMENT_STORM		:	s= "ME-STORM";break;
		case MAGIE_ELEMENT_LICHTKUGEL	:	s= "ME-LICHTKUGEL";break;
		case MAGIE_DEMON_LEBENSRAUB		:	s= "MD-LEBENSRAUB";break;
		case MAGIE_DEMON_MAGIERAUB		:	s= "MD-MAGIERAUB";break;
		case MAGIE_DEMON_HERBEIRUFUNG	:	s= "MD-HERBEIRUFUNG";break;
		case MAGIE_DEMON_FURCHT			:	s= "MD-FURCHT";break;
		case MAGIE_DEMON_EXPLOSION		:	s= "MD-EXPLOSION";break;
		case MAGIE_DEMON_GIFTWOLKE		:	s= "MD-GIFTWOLKE";break;
		case MAGIE_DEMON_HOELLENGLUT	:	s= "MD-HOELLENGLUT";break;
		case ATTR_ATTACK_BOGEN_SCHADEN	:	s= "AT-BOGEN";break;
		case ATTR_ATTACK_PHYSISCH_SCHADEN:	s= "AT-PHYSISCH";break;
		case ATTR_ATTACK_EIS_SCHADEN	:	s= "AT-EIS-SCHADEN";break;
		case ATTR_ATTACK_FEUER_SCHADEN	:	s= "AT-FEUER-SCHADEN";break;
		case ATTR_ATTACK_GIFT_SCHADEN	:	s= "AT-GIFT-SCHADEN";break;
		case ATTR_ATTACK_FLASH_SCHADEN	:	s= "AT-FLASH-SCHADEN";break;
		case MAGIE_ELEMENT_FLAMMENWAND1	:	s= "ME-FLAMMENWAND1";break;
		default:	s= "UNKN.ATTACK";
		}
		PrintLabel(s);
	}
*/

	y++; x=0;
	int id= obj->id;
	PrintDataInt("Id:", id,3); x++;
	if (id!=-1 && type==OBJ_OBJ_TYP_DYN)
	{
		ObjDPers *dp= &obj_dpers[id];
		if (dpers_is_active(id))	
		{
			PrintDataInt("D:", dp1id_getdist(id), 5);
			PrintDataInt("/", attack_dist_midrange, 5);
			PrintDataInt("/", attack_dist_shortrange, 4);
			PrintDataInt("/", attack_dist_contact   , 3);
		}
		else		
			PrintDataInt(" TId:",  dpers_get_timer(dp), 2);
	}
	else
		PrintDataInt("Counter:", obj->Counter, 5);

	y++; x=0;
	PrintDataFxp("VW:", obj->VW, 3,3);
	PrintDataInt("/", get_vw_max(obj)/256, 3);
	
	PrintDataInt(" AW:", obj->AW_MIN, 3);
	PrintDataInt("/", obj->AW_MAX, 3);

	y++; x=0;
	PrintDataFxp("HP:", obj->HP, 3,3);
	PrintDataInt("/", get_hp_max(obj)/256, 3);
	PrintDataFxp(" MP:", obj->MP, 3,3);
	PrintDataInt("/", get_mp_max(obj)/256, 3);

	if (type==OBJ_OBJ_TYP_DYN)
	{
#define print_pid(pid)	BEGIN	\
	if		(pers_is_player(pid))	{PrintDataInt("P",playerid_from_persid(pid),2);x++;}	\
	else if (pers_is_monster(pid))	{PrintDataInt("M",monsterid_from_persid(pid),3);}	\
	else							{PrintDataInt("",pid,4);}	\
	END


		y++; x=0;
		PrintLabel("LA:");	print_pid(obj->last_attacker);

		x++;
		PrintLabel("M:");
		switch(monster_getmode(obj))
		{
		case mm_normal:					PrintLabel("NOR"); break;
		case mm_confused:				PrintLabel("CON"); break;
		case mm_confused_aggressive:	PrintLabel("COA"); break;
		case mm_spawned:				
			{
				PrintLabel("SP");
				switch(monster_getsubmode(obj))
				{
				case mmsub_life:	PrintLabel("L"); break;	
				case mmsub_necro:	PrintLabel("N"); break;	
				default:			x++; break;
				}				
			} break;
		}

		x++;
		PrintLabel("O:");	print_pid(obj->spawner);

		x++;
		PrintLabel("T:");	print_pid(obj->target);

	}


#if 0	
	y++; x=0;
	char *cd_name[6]= {"NONE", "ICE", "FIRE", "POISON", "LIGHT","FLASH"};
	PrintLabel("CD: ");
	int cd= obj_get_contdamage(obj);
	if	(cd<5)	PrintLabel(cd_name[cd]);
	else		PrintLabel("ERROR");
	PrintDataInt(" C:",obj->Cont_Schaden_Typ_Counter,5);
	PrintDataInt(" AW:",obj->Cont_Schaden_AW_MIN,3);
	PrintDataInt("/",obj->Cont_Schaden_AW_MAX,3);
/*	y++; x=10;
	PrintDataInt("F:",obj->Cont_Schaden_Freeze,4);
	PrintDataInt(" FT:",obj->Cont_Schaden_Freeze_Timer,4);*/
#endif
	y++; x=0;
	PrintDataInt("UT:", get_update_timer(obj), 2);
	PrintDataInt(" Anim:", obj->Anim_Pos,2);
	PrintDataInt(" : ", obj->Anim_Count,5);
	y++; x=0;
	PrintDataInt("Collis:", obj->collision_gid&0x07,1);
	PrintDataInt(" ", (obj->collision_gid>>14),1);
	PrintDataInt(" ", (obj->collision_gid>>3)&((1<<11)-1),5);
	PrintDataInt(" ", obj->collision_gid,5);
}

////////////////////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////////////////////
void dbg_screen_monster(int dif)
{
	int x,x0,y;

	PrintStr("Monster Verwaltung",10,0);

	y=2; x0=22;
	x=x0; PrintDataInt("DP :", dpers0_num+dpers1_num,3); y++;
	x=x0; PrintDataInt("DP0:", dpers0_num,3); y++;
	x=x0; PrintDataInt("DP1:", dpers1_num,3); y++;
	x=x0; PrintDataInt("DPD:", dpdist_num,3); y++;
	x=x0; PrintDataInt("LH0:", dpers0_head,3); y++;
	x=x0; PrintDataInt("LH1:", dpers1_head,3); y++;

	y=2; x0=0;

	int i;
	for (i=0; i<dpdist_num; i++)
	{
		x=x0; 
		
		int id= dpd_getdpid(dpdist[i]);
		PrintDataInt("", obj_dpers[id].dpdist_idx,2);
		PrintDataInt(" ", id,3);
		PrintDataInt(" ", dpd_getdist(dpdist[i]),5);

		y++;
	}

	x0= 14;
	y= 2;
	int num= 0;

	int *head= &dpers1_head;
	int next= -1;
	int id= *head;
	while (next!=*head)
	{
		ObjDPers *dp= &obj_dpers[id];
		next= (dp->next)&0x7FFF;

		num++;

		x= x0;
		int didx= dp->dpdist_idx;
		if (didx<0)
		{
			PrintDataInt("", id,3);
			PrintDataInt(" ", -1,3);
			y++;
		}
		else if (dpd_getdpid(dpdist[didx]) != id)
		{
			PrintDataInt("", id,3);
			PrintDataInt(" ",dpd_getdpid(dpdist[didx]),3);
			PrintDataInt(" ",didx,2);
			y++;
		}
		else if (didx>=dpdist_num)
		{
			PrintDataInt("", id,3);
			PrintDataInt(" ", 255,3);
			y++;
		}

		id= next;
	}
	x= x0;
	PrintDataInt("num:", num,2);
}

////////////////////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////////////////////
int selected_player= 0;
void dbg_screen_werte(int dif)
{
	selected_player+= dif;
	if (selected_player<0)			selected_player= PlayerNum-1;
	if (selected_player>=PlayerNum)	selected_player= 0;

	PrintStr("Player",5,0);
	PrintInt(selected_player, 11, 0);
	PLAYERINFO *Player= player_from_playerid(selected_player);
	OBJECT *playerobj= obj_from_player(Player);

	int x,x0,y;
	y= 1;
	x0= 0;

	y++; x=x0;
	PrintDataInt("Level:", Player->AKT_LEVEL,2);
	PrintDataInt(" Agi :", Player->Agi,2);
	PrintDataInt(" Souls:", Player->Ges_Souls,3);

	y++; x=x0;
	PrintDataInt("AW :", Player->AW_MIN,2);  PrintDataInt("/", Player->AW_MAX,2);
	PrintDataInt("  VW:",playerobj->VW/256,2);	PrintDataInt("/", Player->VW_MAX,2);
	y++; x=x0;
	PrintDataInt("AWO:", Player->AW_MIN_Org,2); PrintDataInt("/", Player->AW_MAX_Org,2);
	PrintDataInt(" VWO:", Player->VW_Org,2);

	y++; x=x0;
	PrintDataInt("Str :", Player->Str,2);
	PrintDataInt(" Dex :", Player->Dex,2);
	PrintDataInt(" Int :", Player->Int,2);
	y++; x=x0;
	PrintDataInt("StrO:", Player->Str_Org,2);
	PrintDataInt(" DexO:", Player->Dex_Org,2);
	PrintDataInt(" IntO:", Player->Int_Org,2);

/*
	y++; x=x0;
	PrintDataInt("W :", Player->Waffen_Exp,2); PrintDataInt("/", Player->Waffen_Next_Exp,2); PrintDataInt("/", Player->Waffen_Lvl,2);
	y++; x=x0;
	PrintDataInt("ME:", Player->Magie_Element_Exp,2); PrintDataInt("/", Player->Magie_Element_Next_Exp,2); PrintDataInt("/", Player->Magie_Element_Lvl,2);
	y++; x=x0;
	PrintDataInt("MW:", Player->Magie_Weiss_Exp,2); PrintDataInt("/", Player->Magie_Weiss_Next_Exp,2); PrintDataInt("/", Player->Magie_Weiss_Lvl,2);
	y++; x=x0;
	PrintDataInt("MD:", Player->Magie_Demon_Exp,2); PrintDataInt("/", Player->Magie_Demon_Next_Exp,2); PrintDataInt("/", Player->Magie_Demon_Lvl,2);
*/
}

////////////////////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////////////////////
void print_item(int idx, WAFFEN *item, int *xo, int *yo)
{
	int type= item->Objekt_Typ;
	if (!type) return;

	int x=*xo, y=*yo;

	x= dprintint(idx,x,y);

	char s[128];
	strcpy(s, ATTRIBUTE[type].name);
	char *end= s+strlen(s)-1;
	while (end>=s && (*end==' ' || *end=='\t')) {*end='\0'; end--;}
	if (end<s)	return;
	end++;
	*end=':';
	
	int xnew= x+(end-s+1);
	if (xnew>=30)
	{
		x=0;
		y++;
	}

	PrintLabel(s);
	if (x>=30)
	{
		x=0;
		y++;
	}

	*xo=x;
	*yo=y;
}

////////////////////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////////////////////
void dbg_screen_inventory(int dif,PLAYERINFO *Player)
{
	PrintStr("Inventory",5,0);

	int x=0,y=2;
	int i;
	for (i=0; i<Player->Items_Num; i++)		if (i>9 || Player->Items[i].Num>0) print_item(i, &Player->Items[i] ,&x,&y);
	print_item(0, &Player->Hands.Left, &x,&y);
	print_item(0, &Player->Hands.Right, &x,&y);
	for (i=0; i<Player->Waffen_Num; i++)		print_item(i, &Player->Waffen[i] ,&x,&y);
	for (i=0; i<Player->Magie_Weiss_Num; i++)	print_item(i, &Player->Magie_Weiss[i] ,&x,&y);
	for (i=0; i<Player->Magie_Element_Num; i++)	print_item(i, &Player->Magie_Element[i] ,&x,&y);
	for (i=0; i<Player->Magie_Demon_Num; i++)	print_item(i, &Player->Magie_Demon[i] ,&x,&y);
	for (i=0; i<Player->Ruestungen_Num; i++)	print_item(i, &Player->Ruestungen[i] ,&x,&y);
}

////////////////////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////////////////////
void dbg_screen_collectors(int dif)
{
	PrintStr("Collectors",5,0);

	int x=0,y=2;
	int i;

	for (i=0; i<coll_num; i++)
	{
		Reaction *coll= &reactions[coll_reactions_base+i];
		int limit; 
		limit = (coll->actionofs_pos>>13);
		limit+= (coll->actionofs_neg>>13)<<3;
		PrintDataInt("C",i,2); 
		PrintDataInt(" ",limit-coll_counter[i],2);
		PrintDataInt("/",limit,2);
		x=0;
		y++;
	}
}

////////////////////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////////////////////
void dbg_screen_ditem(int dif)
{
	int x,x0,y;
	
	PrintStr("DItem",5,0);

	y= 2;
	x0= 21;

	x=x0; PrintDataInt("HU:", ditem_head,5); y++;
	x=x0; PrintDataInt("HF:", ditem_freehead,5); y++;
	x=x0; PrintDataInt("N :", ditem_num,2); y++;
	x=x0; PrintDataInt("NT:", Akt_ITEM_OBJEKTE_num,2); y++;

	int id= ditem_head;
	
	x0= 0;
	y= 2;
	if (id!=DItemInvalidI)
	do
	{
		ObjDItem *item= &ditem[id];

		x=x0;
		PrintDataInt("", item->type,2);
		y++;

		id= (item->next)&0x7FFF;
	} while (id!=ditem_head);


	y= 2;
	int i;
	for (i=0; i<Akt_ITEM_OBJEKTE_num; i++)
	{
		OBJECT *obj= obj_from_objnr( Akt_ITEM_OBJEKTE[i] );

		x=5;
		PrintDataInt("", Akt_ITEM_OBJEKTE[i],3);
		PrintDataInt(" ", obj->type,3);
		PrintDataInt(" ",  item_get_class(obj->id),1);
		PrintDataInt(" ", item_get_id(obj->id),3);
		y++;

	}
	
}

////////////////////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////////////////////
void dbg_screen_timer(int dif)
{
	int x,x0,y;
	
	PrintStr("Timer",5,0);

/*
	for (y= 2; y<15; y++)
		dprintbin(Random(), 0, y);	
*/

	y= 2;
	x0= 22;

	x=x0; PrintDataInt("HU:", timer_head_used,4); y++;
	x=x0; PrintDataInt("HF:", timer_head_free,4); y++;
	x=x0; PrintDataInt("T :", timer_cur,4); y++;


	int cur;

	y= 2;
	x0= 0;
	cur= timer_head_used;
	while (cur && y<16)
	{
		x=x0; 
		
		PrintDataInt("", cur,2);
		PrintDataInt(" ", timer_get_typ(cur),1);
		int val= timer_get_val(cur);
		if (val!=timer_val_void)	PrintDataInt(" ", val,3);
		else						PrintLabel("FREE");
		cur= timer_get_nex(cur);
		y++;
	}
	////////////////////////////////////////////////////

	y= 2;
	x0= 10;
	cur= timer_head_free;
	while (cur && y<16)
	{
		x=x0; 
		
		PrintDataInt("", cur,2);
		PrintDataInt(" ", timer_get_val(cur),4);
		cur= timer_get_nex(cur);
		y++;
	}
	////////////////////////////////////////////////////
}

////////////////////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////////////////////
extern u8 objtype_of_dynpalette[10];
void dbg_screen_monsterpal(int dif)
{
	int x,x0,y;

	PrintStr("Dyn.Paletten",5,0);

	y= 2;
	x0= 0;

	int i;
	for (i=0; i<10; i++)
	{
		x=x0;
		int type= objtype_of_dynpalette[i];
		if (type==0xFF)	PrintLabel("empty");
		else			PrintLabel(ATTRIBUTE[type].name);
		x=30-10; PrintDataInt("",Obj_Paletten[type],1);
		x=30- 8; dprinthex((int)ATTRIBUTE[type].PAL,x,y);
		y++;
	}
}


////////////////////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////////////////////
int tester= 0x07091980;
int testchar= 32;

int sfxid= 0;
int pitch= 50;

void dbg_screen_test(int dif)
{
	PrintStr("Test",5,0);


	int x= 0, y= 2;
	PrintDataInt("Sfx", sfxid, 3);
	if (musyxFXActive(Sfx_Sfx_id))	PrintLabel(" PLAYING");
	else							PrintLabel(" STOPPED");

	PrintDataInt("  Pitch", pitch, 3);

/*
	if (MyPlayer->Cont&U_KEY)	{pitch++; musyxFXSetPitch(Sfx_Sfx_id, pitch);}
	if (MyPlayer->Cont&D_KEY)	{pitch--; musyxFXSetPitch(Sfx_Sfx_id, pitch);}
*/

	if (MyPlayer->Cont&L_KEY)	sfxid--;
	if (MyPlayer->Cont&R_KEY)	sfxid++;
	if (MyPlayer->Cont&D_KEY)	pitch--;
	if (MyPlayer->Cont&U_KEY)	pitch++;

	y++;x=0;
	if (dif && (!Sound_on_off))
	{
		musyxFXKeyoff(Sfx_Sfx_id);
		Sfx_Sfx_id= musyxFXStart(sfxid, MUSYX_SFX_DEF_KEY, MUSYX_SFX_DEF_VEL, MUSYX_SFX_DEF_PAN);
		musyxFXSetPitch(Sfx_Sfx_id, pitch*256);
	}
}

////////////////////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////////////////////
void dbg_screen_vram(int dif)
{
#ifdef DEBUGGING
	PrintStr("VRAM-Map  L to toggle",5,0);
	
	int x,y,x0;

	x0= 11;
	y=2;

	x=x0; PrintDataInt("alloc free  :",vb_count_getnormal,5); y++;
	x=x0; PrintDataInt("recyc.unused:",vb_count_getunused,5); y++;
	x=x0; PrintDataInt("recycle used:",vb_count_getkicked,5); y++;
	x=x0; PrintDataInt("clean.needed:",vb_count_getcleanup,5); y++;
	x=x0; PrintDataInt("reset needed:",vb_count_getresetted,5); y++;
	x=x0; PrintDataInt("---failed---:",vb_count_getfailed,5); y++;


	if (dif)	ShowMapEnabled=!ShowMapEnabled;

	if (ShowMapEnabled)
	{
		y=8;
		x=0; PrintLabel("Yellow    : block-start");		y++;
		x=0; PrintLabel("Blue  Ligh: alloc used data");		y++;
		x=0; PrintLabel("Blue  Dark: alloc unused data");	y++;
		x=0; PrintLabel("Magen.Dark: alloc no data");		y++;
		x=0; PrintLabel("Magen.Ligh: free");			y++;
		x=0; PrintLabel("Red   Pale: recycled unused");	y++;
		x=0; PrintLabel("Red   Dark: recycled used");	y++;
		x=0; PrintLabel("Red Bright: ---GAP-ERROR---");	y++;
	}
#endif
}

////////////////////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////////////////////
extern int Malloc_num;
extern int ma_num;
extern int ma_time;

#ifdef DEBUGGING
bool debug_malloc= false;
#endif

void dbg_screen_mem(int dif)
{
#ifdef DEBUGGING
	PrintStr("Memory",5,0);

	if (dif==-1) 
	{
		RM_STAT;
	}

	if (dif==+1)	debug_malloc^=1;
	
	int x,y,x0;

	x0= 0;
	y=2;

	x=x0;
	struct mallinfo info;
	int free, all, esize=(int)&__eheap_start-EX_WRAM;
	info=mallinfo();
	all =EX_WRAM_SIZE-esize;
	free=info.fordblks + (all-info.arena);

	PrintDataInt("EWRAM:",free/1024,4);
	PrintDataInt("K/",(free+Frames_xlen)/1024,4);
	PrintDataInt("K/",all/1024,4);
	PrintLabel("K");

	y++; x=x0;
	PrintDataInt("Frames:", Frames_xlen/1024,3);
	PrintDataInt("K/",Frame_num,4);

	y++; x=x0;
	PrintDataInt("Get :", Get_Frame_added_num,6);
	PrintDataInt(" / All:", Get_Frame_num, 8);
	y++; x=x0;
	PrintDataInt("Free:", Free_Frame_num,6);
	y++; x=x0;
	PrintDataInt("Allc:", Malloc_num,6);
	y++; x=x0;
	PrintDataInt("AN:", ma_num,5);
	PrintDataInt(" AT:", ma_time,5);
	PrintDataInt(" ", ma_time*1000/ma_num,5);
	PrintLabel(" ml/ma");

	y++; x=x0;
	y++; x=x0;
	PrintLabel("---In Console:---");
	y++; x=x0;
	PrintLabel("Debugging : ");
	PrintLabel( (debug_malloc)?"On ":"Off");
	PrintLabel(" R-Button ");
	y++; x=x0;
	PrintLabel("Statistics:     L-Button");
#endif
}

////////////////////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////////////////////
void dbg_screen_attackplaces(int dif)
{
	PrintStr("Attack-Places",5,0);

	int x= 5, y=4;

	dprintint(MyPlayer->attackplaces[dir_u] ,x+10,y+2);
	dprintint(MyPlayer->attackplaces[dir_ul],x+ 7,y+4);
	dprintint(MyPlayer->attackplaces[dir_ur],x+13,y+4);
	dprintint(MyPlayer->attackplaces[dir_l] ,x+ 5,y+6);
	dprintint(MyPlayer->attackplaces[dir_r] ,x+15,y+6);
	dprintint(MyPlayer->attackplaces[dir_dl],x+ 7,y+8);
	dprintint(MyPlayer->attackplaces[dir_dr],x+13,y+8);
	dprintint(MyPlayer->attackplaces[dir_d] ,x+10,y+9);
}

////////////////////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////////////////////
int dbg_selected_trigger= 0;
int dbg_selected_trigger_activated= false;
void dbg_screen_trigger(int dif)
{
	dbg_selected_trigger+= dif;
	if (dbg_selected_trigger<0)	dbg_selected_trigger= triggers_num-1;
	if (dbg_selected_trigger>=triggers_num)	dbg_selected_trigger= 0;
	PrintStr("Trigger",5,0);
	PrintInt(dbg_selected_trigger, 14,0);

	int x=0, y=2;

	Trigger *trig= &triggers[dbg_selected_trigger];

	if (trig_is_monsterdeath(dbg_selected_trigger))
	{
		s16 *list= (s16*)trig;
		PrintDataInt("Reaction:", list[0],3);		y++; x=0;

		PrintLabel("Wanted:");	y++; x=0;
		int max= sizeof(Trigger)/sizeof(u16);
		int i;
		for (i=1; i<max; i++)
		{
			int pers_id= list[i];
			if (pers_id==-1) break;
			PrintDataInt("Id:",pers_id,3); x++;

			int type= objtype_pers[pers_id];
			char *name= (type)?ATTRIBUTE[type].name : "unknown";
			PrintLabel(name);
			x=12; 
			if (!(obj_pers[pers_id].flags&opf_deathtrigger))
				PrintLabel("NOFLAG");
			x=23;
			PrintLabel(objpers_isactive(pers_id)?":alive:" : ":dead:");
			y++; x=0;
		}
	}
	else
	{
		PrintDataInt("PlayerR:", trig->r_player,3);		y++; x=0;
		PrintDataInt("InvRM  :", trig->rm_inventory,3);	y++; x=0;
		PrintDataInt("MonstRM:", trig->rm_monster,3);	y++; x=0;
		PrintDataInt("ItemRM :", trig->rm_item,3);		y++; x=0;
		PrintDataInt("AttRM  :", trig->rm_attack,3);	y++; x=0;
		bool sleeping= !trig_is_active(dbg_selected_trigger);
		PrintLabel("Sleeping:");
		PrintLabel((sleeping)?"yes":"no");
		y++; x=0;

	}
	int i=0;
/*
	while (i<triggersperobj_max && playerobj->triggers_running[i]!=dbg_selected_trigger) i++;
	dbg_selected_trigger_activated= (i<triggersperobj_max);
	PrintLabel("Activated by Player: ");
	PrintLabel((dbg_selected_trigger_activated)?"yes":"no");
	y++; x=0;
*/
	for (i=0; i<triggersperobj_max; i++)
		PrintDataInt(" ", MyPlayer->triggers_running[i], 3);
}

////////////////////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////////////////////
void dbg_screen(int dif,PLAYERINFO *Player)
{
	ClearTextScreen();
	dprintint(dbg_screen_active,2,0);

	switch(dbg_screen_active)
	{
	case dbg_screenid_gen			: dbg_screen_gen(dif); break;
	case dbg_screenid_obj			: dbg_screen_obj(dif); break;
	case dbg_screenid_werte			: dbg_screen_werte(dif); break;
	case dbg_screenid_attackplaces	: dbg_screen_attackplaces(dif); break;
	case dbg_screenid_timer			: dbg_screen_timer(dif); break;
	case dbg_screenid_monsterpal	: dbg_screen_monsterpal(dif); break;
	case dbg_screenid_monster		: dbg_screen_monster(dif); break;
	case dbg_screenid_test			: dbg_screen_test(dif); break;
	case dbg_screenid_vram			: dbg_screen_vram(dif); break;
	case dbg_screenid_trigger		: dbg_screen_trigger(dif); break;
	case dbg_screenid_inventory		: dbg_screen_inventory(dif,Player); break;
	case dbg_screenid_collectors	: dbg_screen_collectors(dif); break;
	case dbg_screenid_ditem			: dbg_screen_ditem(dif); break;
	case dbg_screenid_mem			: dbg_screen_mem(dif); break;
	}
}


void debug_checkmemsize()
{
#define stack_min 2048
	int x;
	int isize=(int)&__iheap_start-CPU_WRAM;
	int esize=(int)&__eheap_start-EX_WRAM;

	if (isize>CPU_WRAM_SIZE)
	{
		dprint_prepare();
		PrintStr("FEHLER : IRAM-Overflow",3,1);
		x=PrintStr("Groesse: ",3,3);
		dprinthex(isize,x,3);
		x=PrintStr("Grenze : ",3,5);
		dprinthex(CPU_WRAM_SIZE,x,5);
		PrintStr("Zuviel : ",3,8);
		PrintInt(isize-CPU_WRAM_SIZE,19,8);
		PrintStr("Bytes",21,8);
		
		PrintStr("Programm angehalten.",4,12);
		while(1);
	}

	if (isize>CPU_WRAM_SIZE-stack_min)
	{
		dprint_prepare();
		PrintStr("FEHLER : IRAM: Stack zu klein",3,1);
		x=PrintStr("Groesse: ",3,3);
		dprinthex(isize,x,3);
		x=PrintStr("Grenze : ",3,5);
		dprinthex(CPU_WRAM_SIZE,x,5);
		PrintStr("�brig : ",3,8);
		PrintInt(CPU_WRAM_SIZE-isize,19,8);
		PrintStr("Bytes",21,8);
		


		PrintStr("Programm angehalten.",4,12);
		while(1);
	}

	if (esize>EX_WRAM_SIZE)
	{
		dprint_prepare();
		x=PrintStr("FEHLER : ERAM-Overflow",3,1);
		x=PrintStr("Groesse: ",3,3);
		x=dprinthex(esize,x,3);
		x=PrintStr("Grenze : ",3,5);
		x=dprinthex(EX_WRAM_SIZE,x,5);


		PrintStr("Programm angehalten.",4,12);
		while(1);
	}
}

int last_free=-1;
void dprint_mallocinfo()
{

	struct mallinfo info;
	int esize=(int)&__eheap_start-EX_WRAM;
	int x;
	int free,all;

	if (last_free==-1) last_free=EX_WRAM_SIZE-esize;

	info=mallinfo();

	all=EX_WRAM_SIZE-esize;
	free=info.fordblks + (all-info.arena);
	
	x=dprintstr("All :", 1,1);	dprintint(all, x+10,1);
	x=dprintstr("Max :", 1,2);	dprintint(info.arena, x+10,2);
	x=dprintstr("Used:", 1,3);	dprintint(info.uordblks, x+10,3);
	x=dprintstr("Free:", 1,4);	dprintint(free, x+10,4);
	x=dprintstr("New :", 1,5);	dprintint(last_free-free, x+10,5);

	last_free=free;
}

///////////////////////////////////////////////////////////////
#define dbg_stackchk_magic 0x42771980
#define dbg_stackchk_point *((u32*)&__iheap_start)
void dbg_stackchk_init()
{
	dbg_stackchk_point=dbg_stackchk_magic;
}

void dbg_stackchk()
{
	if (dbg_stackchk_point!=dbg_stackchk_magic)
	{
		dprint_prepare();
		PrintStr("PANIC! : MOEGLICHER STACK-OVERFLOW !!",3,1);

		PrintStr("Programm angehalten.",4,12);
		while(1);
	}
}
///////////////////////////////////////////////////////////////

void dhalt(int color)
{
	*(vu16 *)BG_PLTT	= color;
	while(1);
}


///////////////////////////////////////////////////////////////
void log_objecthdr(OBJECT *obj, char *hdr)
{
	if (!obj) 
	{
		printf("%s[Object: NONE!]"newline, hdr);
		return;
	}

	int objtype= obj->type;
	ATTR const *attr= &ATTRIBUTE[objtype];
	int objnr= objnr_from_obj(obj);
	printf("%s[Object %i/%i, id: %i, next: %i, prev: %i, type: %s (%i)]"newline,hdr, objnr, Object_num, obj->id, obj->NEXT, obj->PREV, attr->name, objtype);
}

void log_object(OBJECT *obj, char *hdr)
{
	int cell= obj->Cell;
	int cx= cell%32;
	int cy= cell/32;

	int x= obj->Real_x_pos/256;
	int y= obj->Real_y_pos/256;
	int dx= obj->Movement_x;
	int dy= obj->Movement_y;

	log_objecthdr(obj, hdr);

	printf("%s cell: %i,%i, pos: %i,%i, speed: %.2f,%.2f"newline, hdr,
			cx,cy, x,y, dx/256.0, dy/256.0);
	
	printf("%s action: %i, anim: %i (%i), ttl-counter: %i"newline, hdr,
		obj->Aktion, obj->Anim_Pos, obj->Anim_Count, obj->Counter);

	printf("%s hp: %.2f/%.2f, vw: %.2f/%.2f, mp: %.2f/%.2f"newline, hdr,
		obj->HP/256.0, get_hp_max(obj)/256.0, obj->VW/256.0, get_vw_max(obj)/256.0, obj->MP/256.0, get_mp_max(obj)/256.0);


}

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
#endif // DEBUGGING
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

////////////////////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////////////////////
void dprint_prepare()
{
	int	i;
	Stop_irq();
	ZEROn32(VRAM, VRAM_SIZE);

    *(vu16 *)REG_BG1CNT		= BG_COLOR_16 | BG_SCREEN_SIZE_0 | BG_PRIORITY_0 | BG_LOOP_ON | (5 << BG_SCREEN_BASE_SHIFT) | (0 << BG_CHAR_BASE_SHIFT);
	*(vu16 *)REG_DISPCNT	= DISP_MODE_0 | DISP_BG1_ON;
	*(u16 *)REG_BG1HOFS	= 0;
	*(u16 *)REG_BG1VOFS	= 0;

	*(u16*)BG_PLTT= 0x0000;
	for(i=1;i<256;i++) *((u16*)BG_PLTT+i)= 0x7fff;
//	COPYn32(Demon_Hunter_Title_Palette[0], BG_PLTT,512);
//	LadeZeichensatzinRam((u8*)Zeichensatz_Character,(u8*)(VRAM + 0x2800 - 64 * 42),sizeof(Zeichensatz_Character));

//	Text_Screen=(u16*)(VRAM+0x2800);
}

void dprint_stop()
{
	Stop();
}
