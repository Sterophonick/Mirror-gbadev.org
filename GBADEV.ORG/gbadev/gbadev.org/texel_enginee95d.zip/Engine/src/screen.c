#include "main.h"
#include "screen.h"
#include "engine/draw/draw.text.iwram.h"
#include "engine/game/game.h"
#include "images/sincos.h"

//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
void	(*Screen_looproutine)();
int	Screen_Width,Screen_Height,Screen_Colors;
short	*Screen_Palette16;
int		*Screen_Palette32;
u32		*Screen_BackBuffer;

extern	s32	add_Z;

void	DDrawRender();
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
void	Screen_init(int width,int height,int colors)
{
	Screen_Width= width;
	Screen_Height= height;
	Screen_Colors= colors;

	Screen_Height2D= Screen_Height/2;
	Screen_Width2D= Screen_Width/2;
	Screen_Depth3D= Screen_Height2D+Screen_Width2D;

	Screen_BackBuffer= (u32*)BG_BITMAP0_VRAM;
	Screen_Palette16= (u16*)PLTT;

	ZEROn32(Screen_BackBuffer,Screen_Width*Screen_Height);

	*(vu16 *)REG_BG2CNT 	= BG_COLOR_256 | BG_SCREEN_SIZE_0 | BG_PRIORITY_0 | BG_LOOP_ON | 0 << BG_SCREEN_BASE_SHIFT | 0 << BG_CHAR_BASE_SHIFT ;
	*(vu16 *)REG_DISPCNT	= DISP_MODE_4 | DISP_BG2_ON; // LCDC ON
	*(u16 *)REG_BLDCNT	= 0;
	*(u16 *)REG_BLDALPHA= 0x1f00;
	*(u16 *)REG_BLDY	= 0x00;

	drawInit();
}
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
void	Screen_free()
{
	drawFree();
}
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
const	u32 Sprite_L[]= {0x0,0x00100,0x00100,0x00100,0x00100,0x00100,0x00111100,0x0};
const	u32 Sprite_P[]= {0x0,0x11110,0x100010,0x100010,0x11110,0x10,0x10,0x0};
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
void	Screen_activate(void (*routine)())
{
	Screen_looproutine= routine;
	u16	k;
	int	screen= 0;

	u16	*oam= (u16*)(OAM);
	oam[0]= 10;
	oam[1]= 10;
	oam[2]= 512;
	oam[3]= 0;

	u32 *oam_ram= (u32*)(OBJ_MODE4_VRAM);

	*((u16*)OBJ_PLTT+1)= 0x7fff;

	if(TextureMappingPers)
		COPYn32((u32*)Sprite_P,oam_ram,32);
	else
		COPYn32((u32*)Sprite_L,oam_ram,32);

	while(1) 
	{
		KeyReadDirect();
		VBlankIntrWait();
/*		if(_Cont & L_BUTTON)
		{
			add_Z-= 4;
			if(add_Z<512) add_Z= 512;
		}
		else
		if(_Cont & R_BUTTON)
		{
			add_Z+= 4;
			if(add_Z>2048) add_Z= 2048;
		}
*/		if(_Trg==START_BUTTON) 
		{
			TextureMappingPers^= 1;
			if(TextureMappingPers)
				COPYn32((u32*)Sprite_P,oam_ram,32);
			else
				COPYn32((u32*)Sprite_L,oam_ram,32);
		}

/*		if(_Trg==SELECT_BUTTON)
		{
			add_Z= Z_ENDE;
			zz0game= (-6*FRAMES)&SINCOSTAB;
			zz1game= (-4*FRAMES)&SINCOSTAB;
			zz2game= (-2*FRAMES)&SINCOSTAB;
		}
*/
		*(vu16 *)REG_BG2CNT 	= BG_COLOR_256 | BG_SCREEN_SIZE_0 | BG_PRIORITY_1 | BG_LOOP_ON | 0 << BG_SCREEN_BASE_SHIFT | 0 << BG_CHAR_BASE_SHIFT ;
		*(vu16 *)REG_DISPCNT	= DISP_MODE_4 | DISP_BG2_ON | (screen<<4) | DISP_OBJ_ON | DISP_OBJ_CHAR_1D_MAP; // LCDC ON

		Screen_BackBuffer= (u32*)(BG_BITMAP0_VRAM+((screen+1)&1)*0xa000);
		ZEROn32(Screen_BackBuffer,Screen_Width*Screen_Height);
		Screen_looproutine();
		screen= (screen+1)&1;
//		*(u16*)BG_PLTT= k;
		k++;
	}
}
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
void	Screen_setPalette(u16 *palette)
{
	COPYn32(palette,Screen_Palette16,Screen_Colors*2);
}
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
