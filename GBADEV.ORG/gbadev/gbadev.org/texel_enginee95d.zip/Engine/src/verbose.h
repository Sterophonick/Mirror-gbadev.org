#ifndef _inc_verbose_h
#define _inc_verbose_h

/////////////////////////////////////////////////////////////////////////////
#ifndef VERBOSE
#define	VERBOSE 0
#endif

#if VERBOSE<1
#define dprint(x)		DUMMY
#define printf(x...)	DUMMY
#endif

#if VERBOSE>=1
#define dprint1(x)		dprint(x)
#define printf1(x...)	printf(x)
#else
#define dprint1(x)		DUMMY
#define printf1(x...)	DUMMY
#endif

#if VERBOSE>=2
#define dprint2(x)		dprint(x)
#define printf2(x...)	printf(x)
#else
#define dprint2(x)		DUMMY
#define printf2(x...)	DUMMY
#endif

#if VERBOSE>=3
#define dprint3(x)		dprint(x)
#define printf3(x...)	printf(x)
#else
#define dprint3(x)		DUMMY
#define printf3(x...)	DUMMY
#endif

#if VERBOSE>=4
#define dprint4(x)		dprint(x)
#define printf4(x...)	printf(x)
#else
#define dprint4(x)		DUMMY
#define printf4(x...)	DUMMY
#endif

#if VERBOSE>=5
#define dprint5(x)		dprint(x)
#define printf5(x...)	printf(x)
#else
#define dprint5(x)		DUMMY
#define printf5(x...)	DUMMY
#endif

#if VERBOSE>=6
#define dprint6(x)		dprint(x)
#define printf6(x...)	printf(x)
#else
#define dprint6(x)		DUMMY
#define printf6(x...)	DUMMY
#endif

#if VERBOSE>=7
#define dprint7(x)		dprint(x)
#define printf7(x...)	printf(x)
#else
#define dprint7(x)		DUMMY
#define printf7(x...)	DUMMY
#endif

#if VERBOSE>=8
#define dprint8(x)		dprint(x)
#define printf8(x...)	printf(x)
#else
#define dprint8(x)		DUMMY
#define printf8(x...)	DUMMY
#endif

#if VERBOSE>=9
#define dprint9(x)		dprint(x)
#define printf9(x...)	printf(x)
#else
#define dprint9(x)		DUMMY
#define printf9(x...)	DUMMY
#endif
/////////////////////////////////////////////////////////////////////////////
#endif // _inc_verbose_h
