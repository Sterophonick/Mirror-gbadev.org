Bobbletris is a tetris like game with graphics ripped from Bust a Move 2.
It's my first game, i hope you'll like it.

Bertil
abertil@iname.com