Here is a cool WaterFall effect using Interrupt:

Use A : Up the Height of the vison
B : to Down the Height of the vision
R & L : Upper and lower the width of the waterfall
Right and Left ! Change the Alpha-blending level
Up & Down : Level of Point of view ... strange effect 
Select : To make Bg0 scroll too

This effect use a Mode 7 effect and a  x�/y equation for the upper of the screen.
2 background are blended to simulated a move in the water
Thanks to the Pern Project for the Mode 7 source
The sound come from CodeWave witch is the better library i try to play mod.

I translate the source code in English and post it soon

thank you

mdebray@hotmail.com
matthieu_debray@hotmail.com
