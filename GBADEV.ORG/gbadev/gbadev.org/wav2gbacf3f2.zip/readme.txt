ok, this demonstrates the use of my tool, wav2gbac r3

in the last two releases, i fixed up the speed and interface, but the sound didnt convert properly. turns out, .wav uses pcm, while gba uses pwm. Stephen Stairs figured this out (http://www.gbdev.8k.com). so in this release, it works flawlessly.

It uses Staring Monkey's DirectSound lib.

full source is included (its in QuickBasic tho :P)

usage:

wav2gbac input.wav [output.c]

simple, simple, simple.

greetz: SlasherX, Stephen Stairs, John Sensebe, Staring Monkey

download this and many other wonderful things made by me from
http://www.theblackfrog.8m.com

-The Black Frog