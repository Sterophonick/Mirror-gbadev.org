GBA Xor - v1.03
===============

Changes
=======
Fixed three of the new Procyon's Mazes levels.  Two couldn't be completed and the third had map quadrants missing.  Also restored the password decryption clue on level 15 back to what it should be for the GBA version.  I managed to accidently restore it to the clue from the original version when adding the new levels.

Refer to www.gbagames.dsl.pipex.com for detailed instructions, latest versions and more game info.

Basic Instructions
==================
Move the two heros around the maze collecting all the masks.  Once all masks are collected, the door will open allowing you to exit the levels.

You are limited to 2000 moves per level.

Move the heros using the + D-Pad.

Swap between the heros using either the A or B buttons.

Access the in-game menu by pressing the Start button.


All game design is copyright Astral Software and Logotron.