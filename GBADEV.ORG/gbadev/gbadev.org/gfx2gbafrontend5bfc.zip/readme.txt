GFX2GBA Frontend for Version 0.13 - V.1.3
=========================================

This is a win32 GUI wrapper for the DOS GFX2GBA executable written by markus@console-dev.de.

All features are now supported from the DOS version.

Files included in this release:
-------------------------------

gfx2gba.exe - The original win32 dos version of GFX2GBA (markus@console-dev.de)

gfx2gba_readme.txt - The original readme that is packaged with the exe (markus@console-dev.de)

GFX2GBA Frontend.exe - The new win32 GUI wrapper for the original exe (joeybell10101@hotmail.com)

readme.txt - This file for the new wrapper

Useful features include:
------------------------

Added to 1.3
::::::::::::

- Preview of images and window resizing
- Extended error handling eg. Files with spaces in are asked to be replaced with underscores
- Other misc. changes thanks to Peter for suggesting them :)

Standard:

Smart selection of options - Depending on selections in the GUI other options will be toggled.
Easy selection of multiple files from multiple locations.

------------------------

Please send requests for the GUI version to joeybell10101@hotmail.com
And those for the actual executable that does the work to markus@console-dev.de

Yours, JoeyBell @ ngine.de ;)