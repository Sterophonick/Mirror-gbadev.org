1/19/03
--------
The latest addition to Starshot is smoke trails and other particle effects.
I came up with a way to do particles on a tile background, and then
added it in my old shooter.  Starshot now has missiles, engine trails,
and explosion sparks, using my nifty new system!

All the details are at http://www.opusgames.com/games/gbaDev.html

-Opus

