Savage PCX to Gameboy Advance Graphic Convertor            BETA 1.1
-------------------------------------------------------------------
Designed and Written By Matthew Tighe.
Copyright (C)Savage Development 2001.
All Rights Reserved.

THIS IS A BETA RELEASE AND HAS A KNOWN BUG IN THE ELF OUTPUT ROUTINES.
WHEN 2 ELF OBJECTS ARE LINKED INTO A PROJECT THE RESULTING ROM WILL
NOT RUN.  I AM NOT SURE WHY THIS IS UNTIL I GET SOME MORE INFO ON THE
ELF FORMAT.

THIS BETA IS RELEASED SO YOU CAN CONVERT YOUR OLD PROGRAMS TO USE
THE NEW HEADERS WHICH ARE ADDED ON TO THE RESOURCES PRODUCED.

TO PRODUCE .H FILES INSTEAD OF THE BUGGY ELF USE THE -H OPTION.  IF
ANYONE KNOWS WHY THIS HAPPENDS COULD YOU EMAIL ME?


Introduction
-------------------------------------------------------------------
This graphic convertor allows you to take PCX or PCC graphic files
and convert them into a format you can use on the gameboy advance.

This new release includes output as ELF object files which can be
linked straight in to your projects with LS.  No more dodgy and
wasteful .h files (alltough you can still output them, but why would
you want to?????).  Having said that the ELF still requires a small
header file to contain pointers to you data and type declarations.

The output has changed as I have decided that in the future PCX2GBA
will become a complete resource compiler for my GBA projects.

Therefore each resource (ie, blocks, maps, palettes ) has a header
structure instead of defines.  There quite simple and the definitions
are included.  It just means that some of your code may need to be
changed a little.

History
-------

BETA 1.1
* Added output as ELF object (default) -- Has funny bug??????
* Added headers for each resource ( blocks, map, palette )
* Added Flipped Tile Rationalisation ( saves more rom space!! )

Version 1.0
* Initial Release


Requirements
------------
Win32 Command Line.

Getting Started
-------------------------------------------------------------------
Usage
-----

PCX2GBA input.pcx array_name <options>

The PCX file is required, the array_name argument forms the base for
the array names eg:

	PCX2GBA mario.pcx mario

Output:

An ELF object module and or a C header file containing...

	BLKHEADER marioBlkHeader

	unsigned char marioBlk[...]

	MAPHEADER marioMapHeader

	unsigned char marioMap[...]

	PALHEADER marioPalHeader

	unsigned char marioPal[...]

If an ELF is output the header file is also created but the arrays
are not initialised as the data resides in the object file.

NOTE: THE ELF OUTPUT HAS A KNOWN BUG, SEE TOP OF THIS DOC FOR DETAILS.

For more info on the structures, check out the header file savage.h included in this zip.


Options
-------

-m	Don't remove similar & flipped tiles ( this will take up more memory in the cartridge ).
-g	Don't output the map data.
-p	Don't output the palette data.
-s  Graphic is a sprite (don't add a blank tile to the beginning).
-h  Output a header file instead of ELF object.


Planned Features
-------------------------------------------------------------------

* For Next Release
- In the Future

* FIX THE MULTI ELF BUG
* Transparency list ( Colours other than 0 transparent).
* Compressed output

- 16 Colour tiles.
- GIF input support.
- Script file support for cut-zones and input files
  thus creating a Complete Gameboy Resource Compiler!!

Links
-------------------------------------------------------------------

www.matt-tighe.co.uk/gba
			-	My web pages containing my gameboy advance demos,
			-	games, docs and tools.

www.gbadev.org
			-	SimonB's excellent page with all info on the GBA
			-	Demos, games, sources, docs EVERYTHING Check it out!

www.devrs.com
			-	Jeff Frowheins excellent development
			-	pages, loads of gameboy/ advance & neo-geo pocket
			-	info.
