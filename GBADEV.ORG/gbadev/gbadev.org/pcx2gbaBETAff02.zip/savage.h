// Savage.h - Main Include File
// -------------------------------------------
// PCX2GBA Structure Definitions
// Copyright (C)Savage Development
// By Matthew Tighe

typedef struct gbaBlockHeader
{
	BYTE dbType;		// Resource Type
	BYTE dbFormat;		// Resource Format Flags
	WORD dwSize;		// Header size including extra header
	DWORD ddLength;

	WORD dwWidth;		// Width of block (pixels)
	WORD dwHeight;		// Height
	WORD dwNumber;		// Number of blocks in resource
	WORD dwFlags;		// Flags ie colour depth

} BLKHEADER;

typedef struct gbaMapHeader
{
	BYTE dbType;		// Resource Type
	BYTE dbFormat;		// Resource Format Flags
	WORD dwSize;		// Header size including extra header.
	DWORD ddLength;

	WORD dwWidth;		// Width of map (blocks)
	WORD dwHeight;		// Height
	WORD dwBlockSize;	// Size of blocks
	WORD dwFlags;		// Flags ie colour depth

} MAPHEADER;

typedef struct gbaPalHeader
{
	BYTE dbType;		// Resource Type
	BYTE dbFormat;		// Resource Format Flags
	WORD dwSize;		// Header size including extra header.
	DWORD ddLength;		// Data length

	WORD dwColours;		// Number of colours in palette.

} PALHEADER;

#define RES_TYPE_BIN 0
#define RES_TYPE_BLOCKS 1
#define RES_TYPE_MAP 2
#define RES_TYPE_PALETTE 3

#define RES_FORMAT_RAW 0
#define RES_FORMAT_RLE 1

#define RES_PALLTTE_256 0
#define RES_PALETTE_16 1