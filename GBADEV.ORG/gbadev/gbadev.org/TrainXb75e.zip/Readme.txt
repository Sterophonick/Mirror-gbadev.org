[About]
This game is a clone of a windows game "Special Training" which is written by a Japanese. I don't know the author's name. Sorry.

[What Are Not My Works]
1. Many bmps is simply copied from original game, so thanks to the original "Special Training"'s author.
2. I used a thumb sound engine called "GBA MusicWave" developed by Sergej Kravcenko - sergej@codewaves.com
3. And the mod music is from www.modarchives.com, the sfx is morphed from windows xp media resouces, or my voice.

[How To Run]
Run in a Gameboy Advance emulator like VisualBoyAdvance,  or
Burn it into a flash card, and run in real GBA, or
Upload it to GBA's RAM (Multiboot) using GBALink. 

[How To Play]
Uses direction buttons to control the aircraft, and try to survive as long time as you can.


WHowe

MSN & EMail: whowe@21cn.com