Final Fantasy GBA v0.1

Code - Ethos
Graphics - Squaresoft


v0.1 - First Demo, can walk around in screen with a map transition 
       if you go through the upper exit.  Also there is an intro with
       a mode 4 text tool.