sgedit prototype readme


Use at your own risk.  If you don't like it, delete it.
Source will be made available if/when I see fit.

Make your gba gfx on your gba!
The controls can be improved and I intend to add a map
editor and a timer.  I have 15 minute breaks at work, that
is what the timer will be used for =)  This program was made
for me to create gfx on the bus.  Starting out with nothing
is no fun, I don't expect you to do that, so my sgedit.sav
is included as a demo of what the program can do.

Tile zero is special.  You can use it to make a grid, or to
complete-ly obscure vision.  Tile modification may not wrap
how you expect at the left edge of the tile selector.  You
can draw to tiles below the bottom of the tile selector, but
they will not be saved.


Welcome Message:
  eyes   - admire font =P
  start  - continue


Palette Editor:
  Pad    - select color in selector
           select/change component in RGB mixer
  A      - toggle RGB mixer <-> selector
  B      - toggle RGB mixer <-> selector
  L      - empty component in RGB mode
           jump to left side of line in selector
  R      - fill component in RGB mode
           jump to right side of line in selector
  start  - switch to tile editor
  select - hold for ascii save (see below)


Tile Editor:
  Palette Selector:
    Pad    - select color/palette
    A      - set A button color (if on color)
    B      - set B button color (if on color)
    start  - switch to palette editor
    select - switch to pixel editor
  Pixel Editor:
    Pad    - select pixel
    A      - change pixel to A color
    B      - change pixel to B color
    start  - switch to palette editor
    select - switch to palette selector
             hold for ascii save (see below)
    L      - switch to tile selector
  Tile Selector:
    Pad    - select tile
    start  - switch to palette editor
    R      - switch to pixel editor


Ascii Save-
  The screen will blank (turn white) when complete.
  Your palette or tile data will be written in SRAM in
  human and compiler readable format, starting at offset
  0x8000.  Just open you SRAM image (backup to your PC,
  and open the file) and look for your data.  Copy,
  paste into .c file, done.

  You'll need to turn your system off and back on again.


SRAM Usage  (from sgedit.c)
  If anybody is interested in SRAM usage.
  These are offsets from 0x0E000000.
  See above for ascii data.

/* Tiles, complete */
#define SAVE_TILE      0x0000  // ~ 0x1FFF
#define SAVE_TILE_OFF  0x0020  // per tile

/* For map editor maps, not done */
#define SAVE_MAP       0x2000  // ~ 0x6FFF
#define SAVE_MAP_OFF   0x0800  // per map

/* Not done. */
#define SAVE_FONT      0x7000  // ~ 0x77FF
#define SAVE_FONT_OFF  0x0008  // per character

/* Palettes, complete */
#define SAVE_PAL       0x7800  // ~ 0x79FF
#define SAVE_PAL_OFF   0x0020  // per palette

/* Not done. */
#define SAVE_BITM      0x7A00  // ~ 0x7DFF
#define SAVE_BITM_OFF  0x0001  // per eight tiles

/* Obsolete, will be removed during rewrite */
#define SAVE_TPAL      0x7F00  // ~ 0x7F7F
#define SAVE_TPAL_OFF  0x0001  // per two tiles

/* Current pallete in tile editor, etc. */
#define SAVE_MISC      0x7F80  // ~ 0x7FFF


/* The nicest version of main() I've written yet =) */
int main(void)
{
  void *(*fptr)(void) = &test_message;

  while (1)
  {
    fptr = fptr();
  }
  return (0);
}

EOF
