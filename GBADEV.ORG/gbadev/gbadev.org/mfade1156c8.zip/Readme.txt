
 Morph/fade v1.1

  This is my first effort after deciding to learn assembler on the GBA 2 days ago.
 What does it do?, well, it 'fades' one image onto another in GBA video mode 3 by
 comparing the BGR values in the video buffer at each pixel to those of the RAW image
 to be displayed and either increasing or decreasing them if there's a difference.

 Mike

