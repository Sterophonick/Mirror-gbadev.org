

                     Girlfriend Advance version 0.05
                      Website : http://chiungyi.net
                     Author : Vincent Cantin (karma)


I) About the author.

My name is Vincent Cantin, my nickname is karma. I am a french student in computer science (Information Technology) in Master degree in Grenoble (France). I actually look for a job in Taiwan (or else, in Japan). My skills are related to game development, computer graphics (Master degree's speciality), computer vision (Master degree's speciality), development in Java, ... etc ... etc ... please check my profil on my website (chiungyi.net). I speak french (native) english (fluent), chinese (beginner) and spanish (beginner). I which to learn more chinese and japanese, that's why I look for a job overthere. If you think you could give me a job, then contact me at karmarvl-gfa@altern.org .

II) About the Girlfriend Advance emulator.

This software is an Gameboy Advance emulator designed to help developers. You cannot seriously play with it, because :
- gfa (Girlfriend Advance) is too slow, even on a fast computer.
- gfa don't have sound.
- gfa don't have network.
- gfa don't support keyboard input (there are some checkbox for inputs instead).
- gfa don't have to be used like that.
- the gods will punish you if you do.

... So if you want to write me something like "where to find some games", "how can I play using gfa" or something else in the same spirit, press the 3 keys "Ctrl" + "Alt" + "Del" several times and perhaps you will find the secret tip to use gfa for playing games.

I made this software just for fun, and I don't want my hobby to ruin game developers (I am myself a game developer).

Gfa is actually not finished yet. The version 0.05 is a beta version. I don't know if I will finish it one day because I develop it during my free time, and I don't have a lot of it. If you are a java programmer and you want to contribute to the development, you can contact me (actually I am all alone on this project). The main thing to do is to track cpu bugs.

What is missing in my implementation :
- sound.
- network.
- blend of gfx.
- rotations of BG in gfx mode 4 and 5.
- keys interrupt handler.
- card interrupt handler (I actually don't know what it is).
- some few details.
- optimizations (It is wanted).

I prefer webmasters don't distribute the package of gfa, to avoid the persistence of oldest versions on the Internet. But if you want, you can put a direct link to the file on my website (and, why not, on my website).

III) Usage

For using gfa, you first need to have the Java Development Kit (you can find it freely on www.javasoft.com). Then, you need to have the gba rom file (put it in the roms/ directory, with the name "gba.rom" - Don't ask me where to find it, try google or dump it yourself from your own gameboy advance). And finally you need to be programmer and to have your own written program rom. You can program some gba roms by using the free gcc compiler (it is the one I use) which compile C/C++/Arm7Tdmi-Asm, or using the free goldroad assembler (I use it too) which compile pure Arm7Tdmi-Asm.

Then, to launch gfa, type :

    java Main myRomFile

If you want to modify the sources, you will have to compile it using :

    c.bat

If you find a bug in the cpu (I already know the little bugs of the UI and the gfx engine), then don't hesitate to contact me.

IV) The special features of Gfa

There is an undo button. It is actually not yet totally finished, because it have to use the save state commands that I haven't yet implemented. Actually, it reset the rom, and start the execution and stop 4 cycles before the previous state.

There is a conditional breakpoint. It able programmers to run their rom until a specified condition is true. Conditions are expression in a lisp-like format (I love scheme a lot) : (function argument1 argument2 ... argumentN) . Each argument can be another expression. Unlike lisp, my expressions have a strong type : they can be boolean or integer. Evidently, the type of the expression specified in the text area must be boolean.

Here is a sort list of some of the functions I implemented :

(and bool bool) -> bool
(or bool bool) -> bool
(= bool bool) -> bool
(not bool) -> bool
(+ int int) -> int
(- int int) -> int
(and int int) -> int
(or int int) -> int
(xor int int) -> int
(not int) -> int
(neg int) -> int
(= int int) -> bool
(< int int) -> bool
(> int int) -> bool
(s< int int) -> bool   (signed comparison)
(s> int int) -> bool   (signed comparison)
(mem32 int) -> int     (means : (mem32 adr) -> value)
(smem16 int) -> int    (means : (smem16 adr) -> sign-extended value)
(umem16 int) -> int    (means : (umem16 adr) -> value)
(smem8 int) -> int     (means : (smem8 adr) -> sign-extended value)
(umem8 int) -> int     (means : (umem8 adr) -> value)
(reg name) -> int      (default mode = supervisor)
(reg name mode) -> int
(mem8read int) -> bool
(mem16read int) -> bool
(mem32read int) -> bool
(mem8written int) -> bool
(mem16written int) -> bool
(mem32written int) -> bool
(time) -> int          (the current cycle number)

name can be in {r0, r1, ..., r15, sp, lr, pc, cpsr, spsr}.
mode can be in {usr, fiq, irq, svc, abt, und, sys}.

You can use "pc" directly instead of "(reg pc)", and it is the same
for others registers.

You can also use "#t" which is true and "#f" which is false.

In gfa, there is a conditional breakpoint which look in the past the last state where the specified condition is true. It is not totally finished because it should use save state commands. Actually, it reset the program state, and look for the last state where te condition is true until the state before pushing the button. Then, it comes back to the state it found by reseting the program state again, and running the program to the founded state.

Others commands are classical (reset, stop, run, screenshot, ...). You can change the language used by gfa to display the interface, but actually all the ressources are not present (they will come very quickly). There is a contextual menu on the dissaembler component (there is a dissaembler) which is usefull to see the differents parts of the memory. There is a little green button in the corner of the disassembler, it is used to make the disassembler component show the current instruction. I added a little memory viewer, it was just for my usage and will be replace later by another component more usefull and usable.

V) Future work

I will implement load/save state command as soon as I will have time (I have to finished my DEA (Master degree like). I surely will add a table to see the memory content on the left of the screen.

I remind you that in the end of junes, I will finish my studies and I will look for a job. Don't hesitate to contact me, even if your are not in Taiwan or in Japan. thanks.

VI) Greetings

I thank Nintendo, Visoly, Eloist, Joat, Libthium, Codac, Fr4nz, Krb, DevPsx, Voltarene, Kapy, Crashtest & Caffeine, the authors of the excellent emu visualboy advance, the goldroad assembler author, Darkfader, Dovoto, Nicoo, Lanza, Calvin, Hai, Annant, Morad, Beruh, !Pi, FuQinnan, Toyne, Jean-Marc Desperrier, etc ...
Particularly, I want to thank Eric Fichot (webmaster of http://www.emu-france.com) for hosting my website freely and without any banner or publicity.

Vincent Cantin, karma
karmarvl-gfa@altern.org
