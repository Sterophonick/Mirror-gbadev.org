package gfa.analysis;

public interface ReadRegListener
{
  public void notifyGetRequested();
}
