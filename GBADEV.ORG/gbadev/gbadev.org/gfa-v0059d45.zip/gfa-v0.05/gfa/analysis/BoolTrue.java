package gfa.analysis;

public class BoolTrue
    extends BoolExpr
{
    public BoolTrue()
    {
	super();
    }
    
    public boolean evaluation()
    {
	return true;
    }
}
