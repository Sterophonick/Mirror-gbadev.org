package gfa.analysis;

public class ParseException
  extends Exception
{
    public ParseException(String msg)
    {
      super(msg);
    }
}
