package gfa.analysis;

public interface WriteRegListener
{
  public void notifySetRequested(int value);
}
