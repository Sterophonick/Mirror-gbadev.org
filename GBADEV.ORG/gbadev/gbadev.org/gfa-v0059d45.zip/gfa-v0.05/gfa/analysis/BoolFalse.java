package gfa.analysis;

public class BoolFalse
    extends BoolExpr
{
    public BoolFalse()
    {
	super();
    }
    
    public boolean evaluation()
    {
	return false;
    }
}
