package gfa.ui;

public interface GfaStateChangeListener
{
    public void gfaStateChanged();
}
