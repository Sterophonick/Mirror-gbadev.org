package gfa.ui;

public interface CpuStateChangeListener
{
  public void cpuStateChanged();
}
