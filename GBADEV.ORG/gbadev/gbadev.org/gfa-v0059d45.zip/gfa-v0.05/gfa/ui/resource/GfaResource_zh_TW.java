package gfa.ui.resource;

import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import java.util.*;

public class GfaResource_zh_TW
    extends ListResourceBundle
{
    public Object[][] getContents()
    {
	return list;
    }
    
    static Object[][] list =
    {
	// The resources for menu titles in the menu bar.
	
	{"FileMenuAction.NAME",
	 "File"},
	
	{"ExecutionMenuAction.NAME",
	 "Execution"},
	
	{"InternationalMenuAction.NAME",
	 "\u570b\u969b\u7684\u8b6f\u672c"},
	
	{"HelpMenuAction.NAME",
	 "\u5e6b\u52a9"},
	
	// The resources for the various action of gfa.
	
	{"LoadRomAction.NAME",
	 "Load Rom ..."},
	{"LoadRomAction.SHORT_DESCRIPTION",
	 "Load a rom file into the memory and reset the cpu state."},
	{"LoadRomAction.LONG_DESCRIPTION",
	 "Open a file chooser frame in order the user to load " +
	 "a rom file into the memory and reset the cpu state."},
	{"LoadRomAction.ACCELERATOR_KEY",
	 KeyStroke.getKeyStroke(KeyEvent.VK_L, Event.CTRL_MASK)},
	
	{"ExitAction.NAME",
	 "\u51fa\u53bb"},
	{"ExitAction.SHORT_DESCRIPTION",
	 "Exit Girlfriend Advance."},
	
	{"ResetAction.NAME",
	 "Reset"},
	{"ResetAction.SHORT_DESCRIPTION",
	 "Reset the cpu."},
	{"ResetAction.ACCELERATOR_KEY",
	 KeyStroke.getKeyStroke(KeyEvent.VK_F2, Event.CTRL_MASK)},
	
	{"RunAction.NAME",
	 "Run"},
	{"RunAction.SHORT_DESCRIPTION",
	 "Start the execution of the program."},
	{"RunAction.ACCELERATOR_KEY",
	 KeyStroke.getKeyStroke(KeyEvent.VK_F3, 0)},
	
	{"StopAction.NAME",
	 "\u505c\u6b62"},
	{"StopAction.SHORT_DESCRIPTION",
	 "Stop the execution of the program."},
	{"StopAction.ACCELERATOR_KEY",
	 KeyStroke.getKeyStroke(KeyEvent.VK_F4, 0)},
	
	{"StepAction.NAME",
	 "Step"},
	{"StepAction.SHORT_DESCRIPTION",
	 "Execute the current instruction."},
	{"StepAction.ACCELERATOR_KEY",
	 KeyStroke.getKeyStroke(KeyEvent.VK_F5, 0)},
	
	{"UndoAction.NAME",
	 "Undo"},
	{"UndoAction.SHORT_DESCRIPTION",
	 "Undo the last executed instruction."},
	{"UndoAction.LONG_DESCRIPTION",
	 "Undo the last executed instruction. " +
	 "This option should be actived explicitly since it causes a lot of state backup " +
	 "and consequently makes the execution to slow down."},
	{"UndoAction.ACCELERATOR_KEY",
	 KeyStroke.getKeyStroke(KeyEvent.VK_F6, 0)},
	
	{"NextAction.NAME",
	 "Next"},
	{"NextAction.SHORT_DESCRIPTION",
	 "Run until not arrived to the following instruction."},
	{"NextAction.ACCELERATOR_KEY",
	 KeyStroke.getKeyStroke(KeyEvent.VK_F7, 0)},
	
	{"FrenchLanguageAction.NAME",
	 "\u6cd5\u6587"},
	
	{"TwChineseLanguageAction.NAME",
	 "BIG5\u4e2d\u6587"},
	
	{"JapaneseLanguageAction.NAME",
	 "\u65e5\u672c\u8a71"},
	
	{"VietnameseLanguageAction.NAME",
	 "\u8d8a\u5357\u8a9e"},
	
	{"ThaiLanguageAction.NAME",
	 "\u6cf0\u570b\u6587"},
	
	{"ChineseLanguageAction.NAME",
	 "GB\u4e2d\u6587"},
	
	{"EnglishLanguageAction.NAME",
	 "\u82f1\u6587"},
	
	{"DocumentationAction.NAME",
	 "Gfa Documentation"},
	{"DocumentationAction.SHORT_DESCRIPTION",
	 "The Girlfriend Advance documentation."},
	{"DocumentationAction.LONG_DESCRIPTION",
	 "Display the Girlfriend Advance documentation."},
	{"DocumentationAction.ACCELERATOR_KEY",
	 KeyStroke.getKeyStroke(KeyEvent.VK_F1, 0)},
	
	{"AboutAction.NAME",
	 "About"},
	{"AboutAction.SHORT_DESCRIPTION",
	 "Informations about Girlfriend Advance."},
	{"AboutAction.LONG_DESCRIPTION",
	 "Display informations about Girlfriend Advance and his author " +
	 "Vincent Cantin, also known as \"karma of revelation\"."},
	
	{"HomeDisasmAction.NAME",
	 "Home"},
	{"HomeDisasmAction.SHORT_DESCRIPTION",
	 "Back to current instruction."},
	{"HomeDisasmAction.LONG_DESCRIPTION",
	 "Cause the viewport of the disassembler componant to show the current instruction."},
	{"HomeDisasmAction.ACCELERATOR_KEY",
	 KeyStroke.getKeyStroke(KeyEvent.VK_HOME, Event.CTRL_MASK)},
	
	// The resources for tables.
	
	{"CodeViewerTable.column_0", "Offset"},
	{"CodeViewerTable.column_1", "Opcode"},
	{"CodeViewerTable.column_2", "Instruction"},
	
	{"RegisterViewerTable.column_0", "Name"},
	{"RegisterViewerTable.column_1", "Value"},
	
	// The resources for misc componants.
	
	{"InputPanel.up", "Up"},
	{"InputPanel.down", "Down"},
	{"InputPanel.left", "Left"},
	{"InputPanel.right", "Right"},
	{"InputPanel.select", "Select"},
	{"InputPanel.start", "Start"},
	{"InputPanel.a", "A"},
	{"InputPanel.b", "B"},
	{"InputPanel.l", "L"},
	{"InputPanel.r", "R"}
    };
}
