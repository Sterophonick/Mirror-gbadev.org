package gfa.ui.action;

import gfa.*;
import gfa.ui.*;

import java.awt.event.*;
import javax.swing.*;

public class LoadRomAction
    extends InternationalAction
{
    public LoadRomAction(UserInterface ui, GirlfriendAdvance gfa)
    {
	super(ui, "LoadRomAction");
    }
    
    public void actionPerformed(ActionEvent event)
    {
    }
}
