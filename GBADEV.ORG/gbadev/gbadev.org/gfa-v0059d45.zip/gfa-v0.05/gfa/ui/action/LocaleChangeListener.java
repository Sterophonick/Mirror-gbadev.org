package gfa.ui.action;

import java.util.ResourceBundle;

public interface LocaleChangeListener
{
    public void localeChanged(ResourceBundle resource);
}
