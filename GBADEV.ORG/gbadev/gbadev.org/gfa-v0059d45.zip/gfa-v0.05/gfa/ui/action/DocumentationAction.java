package gfa.ui.action;

import gfa.*;
import gfa.ui.*;

import java.awt.event.ActionEvent;
import javax.swing.AbstractAction;

public class DocumentationAction
    extends InternationalAction
{
    public DocumentationAction(UserInterface ui)
    {
	super(ui, "DocumentationAction");
    }
    
    public void actionPerformed(ActionEvent event)
    {
    }
}
