package gfa.ui.action;

import gfa.*;
import gfa.ui.*;

import java.awt.event.ActionEvent;
import javax.swing.AbstractAction;

public class AboutAction
    extends InternationalAction
{
    public AboutAction(UserInterface ui)
    {
	super(ui, "AboutAction");
    }
    
    public void actionPerformed(ActionEvent event)
    {
    }
}
