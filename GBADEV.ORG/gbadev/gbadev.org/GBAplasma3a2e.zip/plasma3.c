// Author:  Quinton Roberts
// Date:    02-19-02
// File:    plasma3.c
// Title: GBA Plasma
//
// Copyright (c) Quinton Roberts 2002

// Program Description -
//   Generates a plasma in Mode 4 (240x160x256) on the GBA, by adding 4
//   different cosine functions that change with time. Plasma resolution
//   is initially 120x60, but is later scaled up using the hardware, to
//   240x120. Since video memory must be accessed in 16bit words, each
//   set of two pixels share the same color.

//type definitions
  typedef unsigned char  u8;
  typedef unsigned short u16;
  typedef unsigned long  u32;

//Register Definitions
  #define REG_DISPCNT    *(u32*)0x4000000
  #define REG_BG2PA      *(u16*)0x4000020
  #define REG_BG2PB      *(u16*)0x4000022
  #define REG_BG2PC      *(u16*)0x4000024
  #define REG_BG2PD      *(u16*)0x4000026

//Register Flag Definitions
  #define BG0_ENABLE		0x100 
  #define BG1_ENABLE		0x200
  #define BG2_ENABLE		0x400
  #define BG3_ENABLE		0x800

  #define MODE0			0x0    
  #define MODE1			0x1
  #define MODE2			0x2
  #define MODE3			0x3
  #define MODE4			0x4
  #define MODE5			0x5

//Macros
  #define RGB16(r,g,b)  ((r)+((g)<<5)+((b)<<10))  //convert RGB to 15bit BGR format

//Constants
  const short cos16 [256] = { 31, 29, 26, 21, 15, 10, 5, 2, 1, 2, 5, 10, 16, 21, 26, 29, 30, 29, 26, 21, 15, 10, 5, 2, 1, 2, 5, 10, 16, 21, 26, 29, 30, 29, 26, 21, 15, 10, 5, 2, 1, 2, 5, 10, 16, 21, 26, 29, 30, 29, 26, 21, 15, 10, 5, 2, 1, 2, 5, 10, 16, 21, 26, 29, 30, 29, 26, 21, 15, 10, 5, 2, 1, 2, 5, 10, 16, 21, 26, 29, 30, 29, 26, 21, 15, 10, 5, 2, 1, 2, 5, 10, 16, 21, 26, 29, 30, 29, 26, 21, 15, 10, 5, 2, 1, 2, 5, 10, 16, 21, 26, 29, 30, 29, 26, 21, 15, 10, 5, 2, 1, 2, 5, 10, 16, 21, 26, 29, 30, 29, 26, 21, 15, 10, 5, 2, 1, 2, 5, 10, 16, 21, 26, 29, 30, 29, 26, 21, 15, 10, 5, 2, 1, 2, 5, 10, 16, 21, 26, 29, 30, 29, 26, 21, 15, 10, 5, 2, 1, 2, 5, 10, 16, 21, 26, 29, 30, 29, 26, 21, 15, 10, 5, 2, 1, 2, 5, 10, 16, 21, 26, 29, 30, 29, 26, 21, 15, 10, 5, 2, 1, 2, 5, 10, 16, 21, 26, 29, 30, 29, 26, 21, 15, 10, 5, 2, 1, 2, 5, 10, 16, 21, 26, 29, 30, 29, 26, 21, 15, 10, 5, 2, 1, 2, 5, 10, 16, 21, 26, 29, 30, 29, 26, 21, 15, 10, 5, 2, 1, 2, 5, 10, 16, 21, 26, 29};
  const short cos32 [256] = { 31, 30, 29, 28, 26, 24, 21, 18, 15, 13, 10, 7, 5, 3, 2, 1, 1, 1, 2, 3, 5, 7, 10, 13, 16, 18, 21, 24, 26, 28, 29, 30, 30, 30, 29, 28, 26, 24, 21, 18, 15, 13, 10, 7, 5, 3, 2, 1, 1, 1, 2, 3, 5, 7, 10, 13, 16, 18, 21, 24, 26, 28, 29, 30, 30, 30, 29, 28, 26, 24, 21, 18, 15, 13, 10, 7, 5, 3, 2, 1, 1, 1, 2, 3, 5, 7, 10, 13, 16, 18, 21, 24, 26, 28, 29, 30, 30, 30, 29, 28, 26, 24, 21, 18, 15, 13, 10, 7, 5, 3, 2, 1, 1, 1, 2, 3, 5, 7, 10, 13, 16, 18, 21, 24, 26, 28, 29, 30, 30, 30, 29, 28, 26, 24, 21, 18, 15, 13, 10, 7, 5, 3, 2, 1, 1, 1, 2, 3, 5, 7, 10, 13, 16, 18, 21, 24, 26, 28, 29, 30, 30, 30, 29, 28, 26, 24, 21, 18, 15, 13, 10, 7, 5, 3, 2, 1, 1, 1, 2, 3, 5, 7, 10, 13, 16, 18, 21, 24, 26, 28, 29, 30, 30, 30, 29, 28, 26, 24, 21, 18, 15, 13, 10, 7, 5, 3, 2, 1, 1, 1, 2, 3, 5, 7, 10, 13, 16, 18, 21, 24, 26, 28, 29, 30, 30, 30, 29, 28, 26, 24, 21, 18, 15, 13, 10, 7, 5, 3, 2, 1, 1, 1, 2, 3, 5, 7, 10, 13, 16, 18, 21, 24, 26, 28, 29, 30};
  const short cos64 [256] = { 31, 30, 30, 30, 29, 29, 28, 27, 26, 25, 24, 23, 21, 20, 18, 17, 15, 14, 13, 11, 10, 8, 7, 6, 5, 4, 3, 2, 2, 1, 1, 1, 1, 1, 1, 1, 2, 2, 3, 4, 5, 6, 7, 8, 10, 11, 13, 14, 16, 17, 18, 20, 21, 23, 24, 25, 26, 27, 28, 29, 29, 30, 30, 30, 30, 30, 30, 30, 29, 29, 28, 27, 26, 25, 24, 23, 21, 20, 18, 17, 15, 14, 13, 11, 10, 8, 7, 6, 5, 4, 3, 2, 2, 1, 1, 1, 1, 1, 1, 1, 2, 2, 3, 4, 5, 6, 7, 8, 10, 11, 13, 14, 16, 17, 18, 20, 21, 23, 24, 25, 26, 27, 28, 29, 29, 30, 30, 30, 30, 30, 30, 30, 29, 29, 28, 27, 26, 25, 24, 23, 21, 20, 18, 17, 15, 14, 13, 11, 10, 8, 7, 6, 5, 4, 3, 2, 2, 1, 1, 1, 1, 1, 1, 1, 2, 2, 3, 4, 5, 6, 7, 8, 10, 11, 13, 14, 16, 17, 18, 20, 21, 23, 24, 25, 26, 27, 28, 29, 29, 30, 30, 30, 30, 30, 30, 30, 29, 29, 28, 27, 26, 25, 24, 23, 21, 20, 18, 17, 15, 14, 13, 11, 10, 8, 7, 6, 5, 4, 3, 2, 2, 1, 1, 1, 1, 1, 1, 1, 2, 2, 3, 4, 5, 6, 7, 8, 10, 11, 13, 14, 16, 17, 18, 20, 21, 23, 24, 25, 26, 27, 28, 29, 29, 30, 30, 30};

//Globals
  u16* ScreenBuffer = (u16*)0x600A000; //video memory - start at backbuffer
  u16* screenPalette = (u16*)0x5000000; //background palette
  u16* iwram=(u16*)0x3000000; //IWRAM - Internal Work RAM

//Set Video Mode
  void SetMode(u16 mode)
  {
    REG_DISPCNT = mode;   
  }

//Wait For VSYNC
  void WaitForVBlank(void)
  {
    while (*(volatile u16*)0x4000006<160);
  }

//Flip Active/Visual Video Memory
  void Flip(void) 
  {
    if ((REG_DISPCNT&0x10)==0)
    {
      REG_DISPCNT |= 0x10;        
      ScreenBuffer=(u16*)0x6000000; 
    }
    else
    { 
      REG_DISPCNT &= 0xFFEF;
      ScreenBuffer=(u16*)0x600A000;
    }
  }

//Program Entry
  int main()
  {

    int i; //loop counter

  //Set Video Mode
    SetMode(MODE4 | BG2_ENABLE);  

  //Scale BG2
    REG_BG2PA = (128);
    REG_BG2PB = (0); 
    REG_BG2PC = (0); 
    REG_BG2PD = (128); 

    u16 red,grn,blu;

  //Generate Plasma Palette
    for (i=0; i<128; i++) 
    {
      red=(-cos16[i])&31;
      grn=(-cos32[i])&31;
      blu=0; 
      screenPalette[i]=RGB16(red,grn,blu);
    }
    for (i=128; i<256; i++)
    {
      red=0; 
      grn=(-cos32[i])&31;
      blu=(-cos16[i])&31;
      screenPalette[i]=RGB16(red,grn,blu);
    }

    u8  x,y;
    u8  c0,c1,c2,c3,c4;
    u16 a,b,c,d;
    u16 addr;    

  //Main Loop
    while(1)
    {
      a=(a+1)&255;
      b=(b+2)&255;
      addr=1200;
      for(y=0; y<60; y++)
      {
        for(x=0; x<60; x++)
        {    
           c=cos64[(y+a)&255];
           d=cos64[(x+a)&255];
          c1=cos64[(x+c)&255]<<1;
          c2=cos64[(y+d)&255]<<1;      
          c3=cos64[(x-a)&255]<<1;      
          c4=cos64[(y-b)&255]<<1;      
          c0=c1+c2+c3+c4;
          ScreenBuffer[addr+x]=(c0<<8)+c0;
        }
        addr+=120;
      } //end for
      WaitForVBlank();
      Flip();
    }

}
//end main



