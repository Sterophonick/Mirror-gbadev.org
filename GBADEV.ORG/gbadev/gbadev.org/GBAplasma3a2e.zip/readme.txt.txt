 Author:  Quinton Roberts (Eclipzer)
 Date:    02-19-02
 File:    plasma3.c
 Title:   GBA Plasma

 Copyright (c) Quinton Roberts 2002

 Program Description -
   Generates a plasma in Mode 4 (240x160x256) on the GBA, by adding 4
   different cosine functions that change with time. Plasma resolution
   is initially 120x60, but is later scaled up using the hardware, to
   240x120. Since video memory must be accessed in 16bit words, each
   set of two pixels share the same color.

 Source Code -
   The source code has been included, and may be used however freely
   so long as credit is given where credit is due.

 Special Thanks
   Dovoto, Costis, Nate405, Liquidex