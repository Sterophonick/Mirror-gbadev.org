void InitGfx()
{
	DISPCNT = 0; // Set the video mode to mode 0: Tile mode
	DISPCNT |= BIT06; // 2 Dimensional mapping for sprite data
	DISPCNT |= BIT12; 
	// Setup the BG0: The playing area
	BG0CNT  = 0 | BIT01;        // Size = 256*256 , Character base block = 0, Second Priority
	BG0CNT |= BIT07;    // Colormode = 256 colors * 1 palette
	//BG0CNT |= ( 0<<2 ); // Screen base block = 7
	BG0CNT |= BIT06;    

	// Setup background 1: The clouds

	BG1CNT  = 1<<2;        // Size = 256*256 , Character base block = 0, First Priority
	BG1CNT |= BIT07;    // Colormode = 256 colors * 1 palette
	// BG1CNT |= ( 7<<8 ); // Screen base block = 15
	BG1CNT |= BIT06;  

}




