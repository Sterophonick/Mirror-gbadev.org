Hello!

I'm Raistlin and this is my first demo at all.
It's also my first program written in C. (i'm a newbie)

When i saw MType by Marsu, i decided to create something similar.
So i coded a remake of a classic AMIGA Shoot'em Up (APYDIA).

The gfx is ripped by me, using Winuae end Psp.

The code is a mix of the : 	- " Flower " demo by Richard "Ries" van der Brugge
				- " Dscan " demo (for the input)
				- " ABG DEV Tutorial Part 2 " by Nokturn (very helpful)
				- " Odd World " (for the sprite)
				- and various hints provided by the numerous demos sources

This demo is in a very early stage of developement, but someone tells the scene is dying...

The source code is a very mess, but it's my first program

And last but not least,sorry for my poor english but i'm italian ;)

This is the second release.
I've removed the code for the shoot of the enemy, because don't work.
So,good luck!