// +--------------------------------------------------+
// |                                                  |
// |                 Adydia ADVANCE                   |
// |                    Ver 0.09                      |
// +--------------------------------------------------+
// | By Raistlin                           24/05/2001 |
// +--------------------------------------------------+


//*******************************************************************************
//*                            include standard routines                        * 
//*******************************************************************************

#include "AGBLib.h"
#include "GFX.h"
#include "GBADinput.h"





#define DMA3SAD		*(u32*)0x040000d4			//setups up all display variables. 
#define DMA3DAD		*(u32*)0x040000d8
#define DMA3CNT		*(u32*)0x040000dc
#define OAM		((Sprite*)0x07000000)
#define OBJCHARDATA	((u8*)0x06010000)
#define OBJ_PLTT	((u16*)0x05000200)


#define J_A		0x0001
#define J_B		0x0002
#define J_SELECT	0x0004
#define J_START		0x0008
#define J_RIGHT		0x0010
#define J_LEFT		0x0020
#define J_UP		0x0040
#define J_DOWN		0x0080
#define J_R		0x0100
#define J_L		0x0200



u16 joypad() 		//joypad checking routine.  
{
	u16 j=P1;
	P1 |= 0x03FF;
	return j;
}














//*******************************************************************************
//*  some stuff needed to setup the picture display such as mem. adrr. of the   * 
//*                     palette, tile data and tile map                         *
//*******************************************************************************

u16 *pal=(u16*)0x5000000;
u16 *tmp_pal;
u8 *tiles=(u8*)0x6004000;
u8 *bg_data;
u16 *m0=(u16*)0x6000000;

u16 PadState; 

int Speed,p1x,p1y,Frame,xEs,yEs,FrameEs,Nrg,Shoot,Lives,Sync,Score,incxEs,incyEs,Es;

int xe[5],ye[5],FrameE[5],EnemyNrg[5];
int incx[5],incy[5];
int p1xs[10],p1ys[10];
int xExp[5],yExp[5],FrameExp[5];
u32 btn;

//*******************************************************************************
//*    external ref. to tell the compiler that the picture and sprite data is   *
//*          coming from an external source in this case data.asm               *
//*******************************************************************************

extern u8 title;		//adds the Title BG from data.asm
extern u8 title_pal;		//adds the Title BG palette from data.asm

extern u8 level01;		//adds the Level1 BG from data.asm
extern u8 level01_pal;		//adds the Level1 BG palette from data.asm

extern u32 sprite;		//adds the sprite from data.asm
extern u32 sprite_palette;	//adds the sprite palette from data.asm



typedef struct _Sprite { u16 Attrib0, Attrib1, Attrib2, RotateScale; } Sprite;	//define a sprite as a structure



//*******************************************************************************
//*										*
//*          			PLAYER 1 FRAMES					*
//*			      PLAYER 1 Matrix 4*4				*
//*				   3 Frames					*
//*******************************************************************************

void Player1 (u16 p1x,u16 p1y,u16 Frame)
{
int i;

if (Frame == 0) 		// Draw the frame 0
	{
	for (i=0;i<4;i++)
		{
		OAM[i].Attrib0 = 0x2000+p1y; 
		OAM[i].Attrib1 = p1x+(8*i);  
		OAM[i].Attrib2 = (2*i);	   
		}
	for (i=0;i<4;i++)
		{
		OAM[4+i].Attrib0 = 0x2000+p1y+8;
		OAM[4+i].Attrib1 = p1x+(8*i);	
		OAM[4+i].Attrib2 = 8+(2*i);	
		}

	for (i=0;i<4;i++)
		{
		OAM[8+i].Attrib0 = 0x2000+p1y+16;
		OAM[8+i].Attrib1 = p1x+(8*i);	
		OAM[8+i].Attrib2 = 16+(2*i);	
		}

	for (i=0;i<4;i++)
		{
		OAM[12+i].Attrib0 = 0x2000+p1y+24;
		OAM[12+i].Attrib1 = p1x+(8*i);	
		OAM[12+i].Attrib2 = 24+(2*i);	
		}
	}

if ((Frame == 1)||(Frame == 3))		// Draw the frame 2
	{
	for (i=0;i<4;i++)
		{
		OAM[i].Attrib0 = 0x2000+p1y;
		OAM[i].Attrib1 = p1x+(8*i);
		OAM[i].Attrib2 = 64+(2*i);
		}

	for (i=0;i<4;i++)
		{
		OAM[4+i].Attrib0 = 0x2000+p1y+8;
		OAM[4+i].Attrib1 = p1x+(8*i);
		OAM[4+i].Attrib2 =64+8+(2*i);
		}

	for (i=0;i<4;i++)
		{
		OAM[8+i].Attrib0 = 0x2000+p1y+16;
		OAM[8+i].Attrib1 = p1x+(8*i);
		OAM[8+i].Attrib2 = 64+16+(2*i);
		}

	for (i=0;i<4;i++)
		{
		OAM[12+i].Attrib0 = 0x2000+p1y+24;
		OAM[12+i].Attrib1 = p1x+(8*i);
		OAM[12+i].Attrib2 = 64+24+(2*i);
		}

	}

if (Frame == 2) 	// Draw the frame 1
	{
	for (i=0;i<4;i++)
		{
		OAM[i].Attrib0 = 0x2000+p1y;
		OAM[i].Attrib1 = p1x+(8*i);
		OAM[i].Attrib2 = 32+(2*i);
		}

	for (i=0;i<4;i++)
		{
		OAM[4+i].Attrib0 = 0x2000+p1y+8;
		OAM[4+i].Attrib1 = p1x+(8*i);
		OAM[4+i].Attrib2 =32+8+(2*i);
		}

	for (i=0;i<4;i++)
		{
		OAM[8+i].Attrib0 = 0x2000+p1y+16;
		OAM[8+i].Attrib1 = p1x+(8*i);
		OAM[8+i].Attrib2 = 32+16+(2*i);
		}

	for (i=0;i<4;i++)
		{
		OAM[12+i].Attrib0 = 0x2000+p1y+24;
		OAM[12+i].Attrib1 = p1x+(8*i);
		OAM[12+i].Attrib2 =32+24+(2*i);
		}

	}


}

//***************************************************************
//*		PROCEDURE TO CREATE 5 ENEMY			*
//***************************************************************

void Zanzara (int xe[5],int ye[5],int FrameE[5])
{
int i;
for (k=0;k<5;k++)
	{
	if (FrameE[k] == 0) 				// Draw the frame 0
		{
		for (i=0;i<2;i++)
			{
			OAM[16+i+k*6].Attrib0 = 0x2000+ye[k];
			OAM[16+i+k*6].Attrib1 = xe[k]+(8*i);
			OAM[16+i+k*6].Attrib2 = 96+(2*i);
			}
	
		for (i=0;i<2;i++)
			{
			OAM[18+i+k*6].Attrib0 = 0x2000+ye[k]+8;
			OAM[18+i+k*6].Attrib1 = xe[k]+(8*i);
			OAM[18+i+k*6].Attrib2 = 96+4+(2*i);
			}

		for (i=0;i<2;i++)
			{
			OAM[20+i+k*6].Attrib0 = 0x2000+ye[k]+16;
			OAM[20+i+k*6].Attrib1 = xe[k]+(8*i);
			OAM[20+i+k*6].Attrib2 = 96+8+(2*i);
			}

		}

	if ((FrameE[k] == 1)||(FrameE[k] == 3))  	// Draw the frame 1 OR Draw the frame 3
		{
		for (i=0;i<2;i++)
			{
			OAM[16+i+k*6].Attrib0 = 0x2000+ye[k];
			OAM[16+i+k*6].Attrib1 = xe[k]+(8*i);
			OAM[16+i+k*6].Attrib2 = 108+(2*i);
			}

		for (i=0;i<2;i++)
			{
			OAM[18+i+k*6].Attrib0 = 0x2000+ye[k]+8;
			OAM[18+i+k*6].Attrib1 = xe[k]+(8*i);
			OAM[18+i+k*6].Attrib2 = 112+(2*i);
			}

		for (i=0;i<2;i++)
			{
			OAM[20+i+k*6].Attrib0 = 0x2000+ye[k]+16;
			OAM[20+i+k*6].Attrib1 = xe[k]+(8*i);
			OAM[20+i+k*6].Attrib2 = 116+(2*i);
			}
		}

	if (FrameE[k] == 2) 				// Draw the frame 2
		{
		for (i=0;i<2;i++)
			{
			OAM[16+i+k*6].Attrib0 = 0x2000+ye[k];
			OAM[16+i+k*6].Attrib1 = xe[k]+(8*i);
			OAM[16+i+k*6].Attrib2 = 120+(2*i);
			}

		for (i=0;i<2;i++)
			{
			OAM[18+i+k*6].Attrib0 = 0x2000+ye[k]+8;
			OAM[18+i+k*6].Attrib1 = xe[k]+(8*i);
			OAM[18+i+k*6].Attrib2 = 124+(2*i);
			}

		for (i=0;i<2;i++)
			{
			OAM[20+i+k*6].Attrib0 = 0x2000+ye[k]+16;
			OAM[20+i+k*6].Attrib1 = xe[k]+(8*i);
			OAM[20+i+k*6].Attrib2 = 128+(2*i);
			}
		}
	}

}

//***************************************************************
//*		PROCEDURE TO CREATE 10 SHOTS			*
//***************************************************************

void P1Shoots (int p1xs[10],int p1ys[10])
{

for(k=0;k<10;k++)
	{
	for (i=0;i<2;i++)
		{
		OAM[52+i+k*2].Attrib0 = 0x2000+p1ys[k];
		OAM[52+i+k*2].Attrib1 = p1xs[k]+(8*i);
		OAM[52+i+k*2].Attrib2 = 132+(2*i);
		}
	}
}


//***************************************************************
//*		PROCEDURE TO CREATE 5 EXPLOSION			*
//***************************************************************

void Esplosione(int xExp[5],int yExp[5],int FrameExp[5])
{

int i;
for (k=0;k<5;k++)
	{
	if (FrameExp[k] == 0) 				// Draw the frame 0
		{
		for (i=0;i<2;i++)
			{
			OAM[74+i+k*4].Attrib0 = 0x2000+yExp[k];
			OAM[74+i+k*4].Attrib1 = xExp[k]+(8*i);
			OAM[74+i+k*4].Attrib2 = 142+(2*i);
			}
			for (i=0;i<2;i++)
			{
			OAM[76+i+k*4].Attrib0 = 0x2000+8+yExp[k];
			OAM[76+i+k*4].Attrib1 = xExp[k]+(8*i);
			OAM[76+i+k*4].Attrib2 = 146+(2*i);
			}

		}

	if (FrameExp[k] == 1) 				// Draw the frame 1
		{
		for (i=0;i<2;i++)
			{
			OAM[74+i+k*4].Attrib0 = 0x2000+yExp[k];
			OAM[74+i+k*4].Attrib1 = xExp[k]+(8*i);
			OAM[74+i+k*4].Attrib2 = 150+(2*i);
			}
		for (i=0;i<2;i++)
			{
			OAM[76+i+k*4].Attrib0 = 0x2000+8+yExp[k];
			OAM[76+i+k*4].Attrib1 = xExp[k]+(8*i);
			OAM[76+i+k*4].Attrib2 = 154+(2*i);
			}
		}

	if (FrameExp[k] == 2) 				// Draw the frame 2
		{
		for (i=0;i<2;i++)
			{
			OAM[74+i+k*4].Attrib0 = 0x2000+yExp[k];
			OAM[74+i+k*4].Attrib1 = xExp[k]+(8*i);
			OAM[74+i+k*4].Attrib2 = 158+(2*i);
			}
		for (i=0;i<2;i++)
			{
			OAM[76+i+k*4].Attrib0 = 0x2000+8+yExp[k];
			OAM[76+i+k*4].Attrib1 = xExp[k]+(8*i);
			OAM[76+i+k*4].Attrib2 = 162+(2*i);
			}
		}

	if (FrameExp[k] == 3) 				// Draw the frame 3
		{
		for (i=0;i<2;i++)
			{
			OAM[74+i+k*4].Attrib0 = 0x2000+yExp[k];
			OAM[74+i+k*4].Attrib1 = xExp[k]+(8*i);
			OAM[74+i+k*4].Attrib2 = 166+(2*i);
			}
		for (i=0;i<2;i++)
			{
			OAM[76+i+k*4].Attrib0 = 0x2000+8+yExp[k];
			OAM[76+i+k*4].Attrib1 = xExp[k]+(8*i);
			OAM[76+i+k*4].Attrib2 = 170+(2*i);
			}
		}

	if (FrameExp[k] == 4) 				// Draw the frame 4
		{
		for (i=0;i<2;i++)
			{
			OAM[74+i+k*4].Attrib0 = 0x2000+yExp[k];
			OAM[74+i+k*4].Attrib1 = xExp[k]+(8*i);
			OAM[74+i+k*4].Attrib2 = 174+(2*i);
			}
		for (i=0;i<2;i++)
			{
			OAM[76+i+k*4].Attrib0 = 0x2000+8+yExp[k];
			OAM[76+i+k*4].Attrib1 = xExp[k]+(8*i);
			OAM[76+i+k*4].Attrib2 = 178+(2*i);
			}
		}

	if (FrameExp[k] == 5) 				// Draw the frame 5
		{
		for (i=0;i<2;i++)
			{
			OAM[74+i+k*4].Attrib0 = 0x2000+yExp[k];
			OAM[74+i+k*4].Attrib1 = xExp[k]+(8*i);
			OAM[74+i+k*4].Attrib2 = 182+(2*i);
			}
		for (i=0;i<2;i++)
			{
			OAM[76+i+k*4].Attrib0 = 0x2000+8+yExp[k];
			OAM[76+i+k*4].Attrib1 = xExp[k]+(8*i);
			OAM[76+i+k*4].Attrib2 = 184+(2*i);
			}
		}
	}

}

//*******************************************************************************
//*			PROCEDURE TO CREATE THE SCORE TABLE			*
//*******************************************************************************
void CreateScoreTable()
{
OAM[98].Attrib0 = 0x2000+0;
OAM[98].Attrib1 = 8;
OAM[98].Attrib2 = 188+26*2;

OAM[99].Attrib0 = 0x2000+0;
OAM[99].Attrib1 = 16;
OAM[99].Attrib2 = 188+22*2;

OAM[100].Attrib0 = 0x2000+0;
OAM[100].Attrib1 = 24;
OAM[100].Attrib2 = 188+11*2;

OAM[101].Attrib0 = 0x2000+0;
OAM[101].Attrib1 = 32;
OAM[101].Attrib2 = 188+35*2;

OAM[102].Attrib0 = 0x2000+0;
OAM[102].Attrib1 = 40;
OAM[102].Attrib2 = 188+15*2;

OAM[103].Attrib0 = 0x2000+0;
OAM[103].Attrib1 = 48;
OAM[103].Attrib2 = 188+28*2;

OAM[104].Attrib0 = 0x2000+0;
OAM[104].Attrib1 = 56;
OAM[104].Attrib2 = 188+2*2;

OAM[105].Attrib0 = 0x2000+0;
OAM[105].Attrib1 = 72;
OAM[105].Attrib2 = 188+34*2;

OAM[106].Attrib0 = 0x2000+0;
OAM[106].Attrib1 = 80;
OAM[106].Attrib2 = 188+6*2;

OAM[107].Attrib0 = 0x2000+0;
OAM[107].Attrib1 = 199;
OAM[107].Attrib2 = 188+1*2;

OAM[108].Attrib0 = 0x2000+0;
OAM[108].Attrib1 = 207;
OAM[108].Attrib2 = 188+1*2;

OAM[109].Attrib0 = 0x2000+0;
OAM[109].Attrib1 = 215;
OAM[109].Attrib2 = 188+1*2;

OAM[110].Attrib0 = 0x2000+0;
OAM[110].Attrib1 = 223;
OAM[110].Attrib2 = 188+1*2;

OAM[111].Attrib0 = 0x2000+0;
OAM[111].Attrib1 = 231;
OAM[111].Attrib2 = 188+1*2;

}

//*******************************************************************************
//*										*
//*          			ENEMY SHOOT FRAMES				*
//*			      ENEMY SHOOT Matrix 1*1				*
//*				   3 FRAMES					*
//*******************************************************************************

void Enemy1Shoot(int xEs,int yEs,int FrameEs)
{
if (FrameEs == 0) 			// Draw the frame 0
	{
	OAM[112].Attrib0 = 0x2000+yEs;
	OAM[112].Attrib1 = xEs+8;
	OAM[112].Attrib2 = 136;
	}

if ((FrameEs == 1)||(FrameEs == 3))	// Draw the frame 2
	{
	OAM[112].Attrib0 = 0x2000+yEs;
	OAM[112].Attrib1 = xEs+8;
	OAM[112].Attrib2 = 138;

	}
if (FrameEs == 2) 			// Draw the frame 2
	{
	OAM[112].Attrib0 = 0x2000+yEs;
	OAM[112].Attrib1 = xEs+8;
	OAM[112].Attrib2 = 140;

	}
}



//***************************************************************
//*		PROCEDURE TO INIZIALIZE 1 ENEMY SHOT		*
//***************************************************************


//void InitEnemyShot ()	// PROCEDURE TO INIZIALIZE 1 SHOT
//{
// 
//xEs=240;
//yEs=10 ;
//incxEs = 0;
//incyEs = 0;
//Es = 0;
//FrameEs = 0;
//}

//void UpdatEnemyShot ()	// PROCEDURE TO UPDATE 1 SHOT
//{
// 
//if (xEs>0)
//	{
//	if (yEs<160)
//		if(yEs>0)
//			{
//			xEs=xEs-5;
			//yEs=yEs+incxEs ;
//			}
//	}
//else 
//	{
//	Es = 0;
//	Enemy1Shoot(xEs,yEs,FrameEs);
//	InitEnemyShot ();
//	}
//Enemy1Shoot(xEs,yEs,FrameEs);
//FrameEs = FrameEs +1;
//if (FrameEs==4) FrameEs = 0;

//}



//***************************************************************
//*		PROCEDURE TO INIZIALIZE 5 EXPLOSION		*
//***************************************************************


void InitExp()
{

for (i=0;i<5;i++)
	FrameExp[i] = 0;
for (i=0;i<5;i++)
	xExp[i] = 240;
for (i=0;i<5;i++)
	yExp[i] =10 ;
}


//***************************************************************
//*		PROCEDURE TO UPDATE 5 EXPLOSION			*
//***************************************************************
void UpdateExp()
{

for (i=0;i<5;i++)
	{
	if (xExp[i] < 240)
		{
		Esplosione(xExp,yExp,FrameExp);
		FrameExp[i] = FrameExp[i]+1 ;
		if (FrameExp[i] > 5) 
			{
			FrameExp[i] =0;	
			xExp[i] = 241;			
			Esplosione(xExp,yExp,FrameExp);
			}
		}
	//else FrameExp[i] =0;
	}
}
//***************************************************************
//*		PROCEDURE TO INIZIALIZE 10 ENEMY		*
//***************************************************************

void InitZanzara()
{

for (i=0;i<5;i++)
	FrameE[i] = 0;

for (i=0;i<5;i++)
	EnemyNrg[i] = 1;

for (i=0;i<5;i++)
	xe[i] = 140 +16*i ;

for (i=0;i<5;i++)
	ye[i] = 10 +24*i ;

for (i=0;i<5;i++)
	incx[i] = -1 ;

for (i=0;i<5;i++)
	incy[i] = -1 ;



}



//***************************************************************
//*		PROCEDURE TO UPDATE 10 ENEMY			*
//***************************************************************

void UpdateZanzara()
{
for (i=0;i<5;i++)
	{
	if (xe[i]<240)
		{
		if (xe[i]+16>=240)  incx[i] = -1;
		if (xe[i]<1)  incx[i] = +1;

		if (ye[i]+24>=160) incy[i] = -1;
		if (ye[i]<8)  incy[i] = +1;

		xe[i] = xe[i] + incx[i];
		ye[i] = ye[i] + incy[i];
		}
	}
Zanzara (xe,ye,FrameE);

for (i=0;i<5;i++)
	{
	FrameE[i] =FrameE[i]+1;
	if (FrameE[i] == 4)
		FrameE[i] = 0;
	}


//if (Es == 0)
//	{
//for (i=0;i<5;i++)
//	if (p1y==ye[i])
//		{
//		Es= 1;
//		xEs = xe[i];
//		yEs = ye[i];
//		incyEs= 0;
//		if (xe[i]<p1x)
//			incxEs = 1;
//		else incxEs = -1;
//		}
//	}

}

//***************************************************************
//*	PROCEDURE TO CONTROL THE SHOTS OF THE PLAYER1 		*
//***************************************************************

void InitP1Shoots ()	// PROCEDURE TO INIZIALIZE 10 SHOTS
{
 for (i=0;i<10;i++)
	p1xs[i]=240;
 for (i=0;i<10;i++)
	p1ys[i]=10 ;
}

void UpdateP1Shoots()	// UPDATE 10 SHOTS
{
for (i=0;i<10;i++)
	{
	if (p1xs[i]<240)
		p1xs[i]=p1xs[i]+5;
	}
P1Shoots (p1xs,p1ys);
}


//***************************************************************
//*		PROCEDURE TO UPDATE THE PLAYER 1 		*
//***************************************************************

void Update1Up()
{
 Player1 (p1x, p1y,Frame);  
 Frame = Frame+1;
 if (Frame == 4) Frame = 0; 
}




//***************************************************************
//*		PROCEDURE TO INIZIALIZE THE GAME		*
//***************************************************************

void InitGame()
{
Lives = 5;
Frame = 0;
Nrg = 1;
p1x = 2;
p1y = 80;
Speed = 1;
Sync = 0;
Shoot = 0;
Score = 0;
InitZanzara();
InitP1Shoots();
InitExp();
//InitEnemyShot ();
}


void P1Died()
{

xExp[0] = p1x;
yExp[0] = p1y+16;
xExp[1] = p1x+16;
yExp[1] = p1y+16;
xExp[2] = p1x+32;
yExp[2] = p1y+16;

p1x = 240;
Update1Up();

FrameExp[0] = 0;
FrameExp[1] = 0;
FrameExp[2] = 0;

for (k=0;k<6;k++)
	{
	for (i=0;i<3;i++)
		{
		Esplosione(xExp,yExp,FrameExp);
		FrameExp[i] = FrameExp[i]+1 ;
		Wait(2);
		}
	}

InitExp();
for (i=0;i<3;i++)
	Esplosione(xExp,yExp,FrameExp);

for (i=0;i<5;i++)
	{
	xe[i] = 240;
	ye[i] = 240;
	Zanzara (xe,ye,FrameE);
	}



Wait( 10 );
FadeOut(3);
InitGame();
Wait( 10 );
FadeIn(3);

}




//***************************************************************
//*		PROCEDURE TO CHECK THE COLLISION		*
//***************************************************************

void CheckForCollision()
{
for (i=0;i<10;i++)
	{
	for (k=0;k<5;k++)
		{
		if ((xe[k]<p1xs[i])&&(p1xs[i]<xe[k]+16))
			if ((ye[k]<p1ys[i])&&(p1ys[i]<ye[k]+24))
			if (FrameExp[k] ==0)
				{
				 xExp[k] = xe[k];
				 yExp[k] = ye[k]+8;
				 xe[k] = 240;
				 p1xs[i] = 240;
				 Score = Score +10;
				}
		}
	}
for (i=0;i<5;i++)
	{
	if ((p1x>xe[i])&&(p1x<xe[i]+16)&&(p1y+8>ye[i])&&(p1y+8<ye[i]+24)||(p1x+32>xe[i])&&(p1x+32<xe[i]+16)&&(p1y+8>ye[i])&&(p1y+8<ye[i]+24)||(p1x>xe[i])&&(p1x<xe[i]+16)&&(p1y+32>ye[i])&&(p1y+32<ye[i]+24)||(p1x+32>xe[i])&&(p1x+32<xe[i]+16)&&(p1y+32>ye[i])&&(p1y+32<ye[i]+24))
		{
		P1Died();
		}

	}


}

//***************************************************************
//*		PROCEDURE TO SCROLL THE BG1			*
//***************************************************************

void DoScroll()
{
BG1HOFS=BG1HOFS+1;
}





//***************************************************************
//*		PROCEDURE TO REFRESH THE SCREEN 		*
//***************************************************************


void ScreenUpdate()
{
Update1Up();
UpdateZanzara();
UpdateP1Shoots();
DoScroll();
CheckForCollision();
UpdateExp();
if ((xe[0]+xe[1]+xe[2]+xe[3]+xe[4] == 240*5)&&(FrameExp[0]+FrameExp[1]+FrameExp[2]+FrameExp[3]+FrameExp[4] == 0))
	{
	InitZanzara();
	InitExp();
	}	
//UpdatEnemyShot ();
CreateScoreTable();	
WaitForVSync();
}








//*******************************************************************************
//*			fast DMA transfer of data				*
//*******************************************************************************


void DMA3Call(u32 Src,u32 Dst,u32 Cnt)	//used to load our sprite info into vram			
{
	DMA3SAD = Src;	//where the data is
	DMA3DAD = Dst;	//where the data goes
	DMA3CNT = Cnt;	//how much data should be loaded
}



void AssignSprite()
{
	DMA3Call((u32)&sprite_palette, (u32)OBJ_PLTT, 0x84000080);	// Setup the sprites palette
	DMA3Call((u32)&sprite, (u32)OBJCHARDATA, 0x84004000);		// Copy Sprites Character Bloc to VRAM
}





//*******************************************************************************
//*			thanx to warder1 for this routine			*
//*  what you do is save a 240x160 256color BMP run it thru spritestripper and  *
//*   then tru hackit to get the pal and raw data for inclusion in the data.asm *
//*  spritestripper creates the 8colums you need for mode0 and hackit converts  *
//*                            it into raw data                                 *
//*******************************************************************************


void ShowTitle()
{
   u16 x,y,i;




   bg_data = (u8*)(&title);			//
   for(i=0;i<38400;i++) tiles[i]=bg_data[i];	//load tiles from data to vram				

   tmp_pal = (u16*)(&title_pal);		//
   for (i=0;i<256;i++) pal[i]=tmp_pal[i];	//load palette to vram

   for (y=0;y<20;y++)				//
       for (x=0;x<30;x++) {			// draw tiles on screen
           m0[y*32+x]=y*30+x;			//
       }					//
}


void ShowBG()
{
 u16 y,i;

 bg_data = (u8*)(&level01);			//
 for(i=0;i<40960;i++) tiles[i]=bg_data[i];	//load tiles from data to vram				

 tmp_pal = (u16*)(&level01_pal);		//
 for (i=0;i<256;i++) pal[i]=tmp_pal[i];		//load palette to vram

 for (y=0;y<640;y++) m0[y]=y;			// draw tiles on screen

}



void Game()
{


		AssignSprite();
		btn=(joypad());		//set our variable btn to be the value in the joypad register
		ScreenUpdate();
		if (btn)
			{
			if (!(btn & J_LEFT))
				{
				p1x = p1x-Speed;
				if (p1x <= 0) p1x =0 ;
				ScreenUpdate();
				}
			if (!(btn & J_RIGHT))	
				{				
				p1x=p1x+Speed;			
				if (p1x >= 240-32) p1x =240-32 ;
				ScreenUpdate();
				}
			if (!(btn & J_UP))
				{
				p1y=p1y-Speed;
				if (p1y <= 8) p1y =8 ;
				ScreenUpdate();
				}		
			if (!(btn & J_DOWN))
				{		
				p1y=p1y+Speed;	
				if (p1y >= 160-32) p1y =160-32 ;
				ScreenUpdate();
				}		
			if (!(btn & J_A))
				{		
				Sync = Sync+1;
				if (Sync == 2)
					{		
					p1xs[Shoot]=p1x+32;
					p1ys[Shoot]=p1y+16;		
					Shoot = Shoot + 1;
					if (Shoot == 9)
						Shoot=0;
					}		
				if (Sync == 2) Sync = 0;
				ScreenUpdate();	
				}		
			if (!(btn & J_B))
				{		
				Speed = Speed +1;
				if (Speed > 5) Speed = 5;
				}		

			}	


}





//*******************************************************************************
//*										*
//*          			MAIN CODE					*
//*										*
//*******************************************************************************

void StartHere()
{	




	InitGfx(); 

	DISPCNT |= BIT09;   // Enable Background 1: The clouds
	ShowTitle();

	// Video_PressStartScreen()
	while(1)
		{
		 ClearPad();
		 ReadPad(&PadState);
		 switch(PadState)
			{
			 case KEY_START:
				Wait( 5 );
				FadeOut(1);
				ShowBG();
				Wait( 5 );
				FadeIn(1);
				InitGame();
				AssignSprite();
				while(1)
					{
					Game();
					}
				ClearPad();
				break;	
			};
		}
 

}
