// +--------------------------------------------------+
// |                                                  |
// |                 Adydia ADVANCE                   |
// |                    Ver 0.05                      |
// +--------------------------------------------------+
// | By Raistlin                           14/05/2001 |
// +--------------------------------------------------+


//*******************************************************************************
//*                            include standard routines                        * 
//*******************************************************************************

#include "AGBLib.h"
#include "GFX.h"
#include "GBADinput.h"





#define DMA3SAD		*(u32*)0x040000d4			//setups up all display variables. 
#define DMA3DAD		*(u32*)0x040000d8
#define DMA3CNT		*(u32*)0x040000dc
#define OAM		((Sprite*)0x07000000)
#define OBJCHARDATA	((u8*)0x06010000)
#define OBJ_PLTT	((u16*)0x05000200)



//*******************************************************************************
//*  some stuff needed to setup the picture display such as mem. adrr. of the   * 
//*                     palette, tile data and tile map                         *
//*******************************************************************************

u16 *pal=(u16*)0x5000000;
u16 *tmp_pal;
u8 *tiles=(u8*)0x6004000;
u8 *bg_data;
u16 *m0=(u16*)0x6000000;

u16 PadState; 

//*******************************************************************************
//*    external ref. to tell the compiler that the picture and sprite data is   *
//*          coming from an external source in this case data.asm               *
//*******************************************************************************

extern u8 title;			//adds the Title BG from data.asm
extern u8 title_pal;		//adds the Title BG palette from data.asm

extern u8 level01;		//adds the Level1 BG from data.asm
extern u8 level01_pal;		//adds the Level1 BG palette from data.asm

extern u32 sprite;		//adds the sprite from data.asm
extern u32 sprite_palette;	//adds the sprite palette from data.asm



typedef struct _Sprite { u16 Attrib0, Attrib1, Attrib2, RotateScale; } Sprite;	//define a sprite as a structure

//*******************************************************************************
//*										*
//*          			TEXT SPRITES					*
//*			      							*
//*				 42 Sprites					*
//*******************************************************************************
void TextSprite(u16 xT,u16 yT)
{
int i;

for (i=0;i<42;i++)
		{
		OAM[28+i].Attrib0 = 0x2000+yT;
		OAM[28+i].Attrib1 = xT;	
		OAM[28+i].Attrib2 = 188+(2*i);	
		}
}

//*******************************************************************************
//*										*
//*          			PLAYER 1 FRAMES					*
//*			      PLAYER 1 Matrix 4*4				*
//*				   3 Frames					*
//*******************************************************************************

void Player1 (u16 p1x,u16 p1y,u16 Frame)
{
int i;

if (Frame == 0) 		// Draw the frame 0
	{
	for (i=0;i<4;i++)
		{
		OAM[i].Attrib0 = 0x2000+p1y; 
		OAM[i].Attrib1 = p1x+(8*i);  
		OAM[i].Attrib2 = (2*i);	   
		}
	for (i=0;i<4;i++)
		{
		OAM[4+i].Attrib0 = 0x2000+p1y+8;
		OAM[4+i].Attrib1 = p1x+(8*i);	
		OAM[4+i].Attrib2 = 8+(2*i);	
		}

	for (i=0;i<4;i++)
		{
		OAM[8+i].Attrib0 = 0x2000+p1y+16;
		OAM[8+i].Attrib1 = p1x+(8*i);	
		OAM[8+i].Attrib2 = 16+(2*i);	
		}

	for (i=0;i<4;i++)
		{
		OAM[12+i].Attrib0 = 0x2000+p1y+24;
		OAM[12+i].Attrib1 = p1x+(8*i);	
		OAM[12+i].Attrib2 = 24+(2*i);	
		}
	}

if ((Frame == 1)||(Frame == 3))		// Draw the frame 2
	{
	for (i=0;i<4;i++)
		{
		OAM[i].Attrib0 = 0x2000+p1y;
		OAM[i].Attrib1 = p1x+(8*i);
		OAM[i].Attrib2 = 64+(2*i);
		}

	for (i=0;i<4;i++)
		{
		OAM[4+i].Attrib0 = 0x2000+p1y+8;
		OAM[4+i].Attrib1 = p1x+(8*i);
		OAM[4+i].Attrib2 =64+8+(2*i);
		}

	for (i=0;i<4;i++)
		{
		OAM[8+i].Attrib0 = 0x2000+p1y+16;
		OAM[8+i].Attrib1 = p1x+(8*i);
		OAM[8+i].Attrib2 = 64+16+(2*i);
		}

	for (i=0;i<4;i++)
		{
		OAM[12+i].Attrib0 = 0x2000+p1y+24;
		OAM[12+i].Attrib1 = p1x+(8*i);
		OAM[12+i].Attrib2 = 64+24+(2*i);
		}

	}

if (Frame == 2) 	// Draw the frame 1
	{
	for (i=0;i<4;i++)
		{
		OAM[i].Attrib0 = 0x2000+p1y;
		OAM[i].Attrib1 = p1x+(8*i);
		OAM[i].Attrib2 = 32+(2*i);
		}

	for (i=0;i<4;i++)
		{
		OAM[4+i].Attrib0 = 0x2000+p1y+8;
		OAM[4+i].Attrib1 = p1x+(8*i);
		OAM[4+i].Attrib2 =32+8+(2*i);
		}

	for (i=0;i<4;i++)
		{
		OAM[8+i].Attrib0 = 0x2000+p1y+16;
		OAM[8+i].Attrib1 = p1x+(8*i);
		OAM[8+i].Attrib2 = 32+16+(2*i);
		}

	for (i=0;i<4;i++)
		{
		OAM[12+i].Attrib0 = 0x2000+p1y+24;
		OAM[12+i].Attrib1 = p1x+(8*i);
		OAM[12+i].Attrib2 =32+24+(2*i);
		}

	}


}


//*******************************************************************************
//*										*
//*          			ENEMY 1 FRAMES					*
//*			      Zanzara Matrix 2*3				*
//*				   3 Frames 					*
//*******************************************************************************

void Enemy1 (u16 xz,u16 yz,u16 FrameE1)
{
int i;

if (FrameE1 == 0) 				// Draw the frame 0
	{
	for (i=0;i<2;i++)
		{
		OAM[16+i].Attrib0 = 0x2000+yz;
		OAM[16+i].Attrib1 = xz+(8*i);
		OAM[16+i].Attrib2 = 96+(2*i);
		}

	for (i=0;i<2;i++)
		{
		OAM[18+i].Attrib0 = 0x2000+yz+8;
		OAM[18+i].Attrib1 = xz+(8*i);
		OAM[18+i].Attrib2 = 96+4+(2*i);
		}

	for (i=0;i<2;i++)
		{
		OAM[20+i].Attrib0 = 0x2000+yz+16;
		OAM[20+i].Attrib1 = xz+(8*i);
		OAM[20+i].Attrib2 = 96+8+(2*i);
		}

	}

if ((FrameE1 == 1)||(FrameE1 == 3))  		// Draw the frame 1
	{
	for (i=0;i<2;i++)
		{
		OAM[16+i].Attrib0 = 0x2000+yz;
		OAM[16+i].Attrib1 = xz+(8*i);
		OAM[16+i].Attrib2 = 108+(2*i);
		}

	for (i=0;i<2;i++)
		{
		OAM[18+i].Attrib0 = 0x2000+yz+8;
		OAM[18+i].Attrib1 = xz+(8*i);
		OAM[18+i].Attrib2 = 112+(2*i);
		}

	for (i=0;i<2;i++)
		{
		OAM[20+i].Attrib0 = 0x2000+yz+16;
		OAM[20+i].Attrib1 = xz+(8*i);
		OAM[20+i].Attrib2 = 116+(2*i);
		}
	}

if (FrameE1 == 2) 				// Draw the frame 2
	{
	for (i=0;i<2;i++)
		{
		OAM[16+i].Attrib0 = 0x2000+yz;
		OAM[16+i].Attrib1 = xz+(8*i);
		OAM[16+i].Attrib2 = 120+(2*i);
		}

	for (i=0;i<2;i++)
		{
		OAM[18+i].Attrib0 = 0x2000+yz+8;
		OAM[18+i].Attrib1 = xz+(8*i);
		OAM[18+i].Attrib2 = 124+(2*i);
		}

	for (i=0;i<2;i++)
		{
		OAM[20+i].Attrib0 = 0x2000+yz+16;
		OAM[20+i].Attrib1 = xz+(8*i);
		OAM[20+i].Attrib2 = 128+(2*i);
		}
	}

}


//*******************************************************************************
//*										*
//*          			PLAYER 1 SHOOT FRAME				*
//*				 PLAYER 1 SHOOT 1*2				*
//*				     1 FRAME					*
//*******************************************************************************

void P1Shoot(int xs,int ys)
{
int i;

	for (i=0;i<2;i++)
	{
	OAM[22+i].Attrib0 = 0x2000+ys;
	OAM[22+i].Attrib1 = xs+(8*i);
	OAM[22+i].Attrib2 = 132+(2*i);
	}
}


//*******************************************************************************
//*										*
//*          			ENEMY SHOOT FRAMES				*
//*			      ENEMY SHOOT Matrix 1*1				*
//*				   3 FRAMES					*
//*******************************************************************************

void Enemy1Shoot(int xes,int yes,int FrameEs)
{
if (FrameEs == 0) 			// Draw the frame 0
	{
	OAM[24].Attrib0 = 0x2000+yes;
	OAM[24].Attrib1 = xes+8;
	OAM[24].Attrib2 = 136;
	}

if ((FrameEs == 1)||(FrameEs == 3))	// Draw the frame 2
	{
	OAM[24].Attrib0 = 0x2000+yes;
	OAM[24].Attrib1 = xes+8;
	OAM[24].Attrib2 = 138;

	}
if (FrameEs == 2) 			// Draw the frame 2
	{
	OAM[24].Attrib0 = 0x2000+yes;
	OAM[24].Attrib1 = xes+8;
	OAM[24].Attrib2 = 140;

	}
}



//*******************************************************************************
//*										*
//*          			EXPLOSION FRAMES 				*
//*			      EXPLOSION Matrix 2*2				*
//*				  6 Frames					*
//*******************************************************************************

void Explosion(int xex,int yex,int FrameEx)
{
int i;
if (FrameEx == 0) 				// Draw the frame 0
	{
	for (i=0;i<2;i++)
		{
		OAM[25+i].Attrib0 = 0x2000+yex;
		OAM[25+i].Attrib1 = xex+(8*i);
		OAM[25+i].Attrib2 = 142+(2*i);
		}
		for (i=0;i<2;i++)
		{
		OAM[27+i].Attrib0 = 0x2000+8+yex;
		OAM[27+i].Attrib1 = xex+(8*i);
		OAM[27+i].Attrib2 = 146+(2*i);
		}

	}

if (FrameEx == 1) 				// Draw the frame 1
	{
	for (i=0;i<2;i++)
		{
		OAM[25+i].Attrib0 = 0x2000+yex;
		OAM[25+i].Attrib1 = xex+(8*i);
		OAM[25+i].Attrib2 = 150+(2*i);
		}
	for (i=0;i<2;i++)
		{
		OAM[27+i].Attrib0 = 0x2000+8+yex;
		OAM[27+i].Attrib1 = xex+(8*i);
		OAM[27+i].Attrib2 = 154+(2*i);
		}
	}

if (FrameEx == 2) 				// Draw the frame 2
	{
	for (i=0;i<2;i++)
		{
		OAM[25+i].Attrib0 = 0x2000+yex;
		OAM[25+i].Attrib1 = xex+(8*i);
		OAM[25+i].Attrib2 = 158+(2*i);
		}
	for (i=0;i<2;i++)
		{
		OAM[27+i].Attrib0 = 0x2000+8+yex;
		OAM[27+i].Attrib1 = xex+(8*i);
		OAM[27+i].Attrib2 = 162+(2*i);
		}
	}

if (FrameEx == 3) 				// Draw the frame 3
	{
	for (i=0;i<2;i++)
		{
		OAM[25+i].Attrib0 = 0x2000+yex;
		OAM[25+i].Attrib1 = xex+(8*i);
		OAM[25+i].Attrib2 = 166+(2*i);
		}
	for (i=0;i<2;i++)
		{
		OAM[27+i].Attrib0 = 0x2000+8+yex;
		OAM[27+i].Attrib1 = xex+(8*i);
		OAM[27+i].Attrib2 = 170+(2*i);
		}
	}

if (FrameEx == 4) 				// Draw the frame 4
	{
	for (i=0;i<2;i++)
		{
		OAM[25+i].Attrib0 = 0x2000+yex;
		OAM[25+i].Attrib1 = xex+(8*i);
		OAM[25+i].Attrib2 = 174+(2*i);
		}
	for (i=0;i<2;i++)
		{
		OAM[27+i].Attrib0 = 0x2000+8+yex;
		OAM[27+i].Attrib1 = xex+(8*i);
		OAM[27+i].Attrib2 = 178+(2*i);
		}
	}

if (FrameEx == 5) 				// Draw the frame 5
	{
	for (i=0;i<2;i++)
		{
		OAM[25+i].Attrib0 = 0x2000+yex;
		OAM[25+i].Attrib1 = xex+(8*i);
		OAM[25+i].Attrib2 = 182+(2*i);
		}
	for (i=0;i<2;i++)
		{
		OAM[27+i].Attrib0 = 0x2000+8+yex;
		OAM[27+i].Attrib1 = xex+(8*i);
		OAM[27+i].Attrib2 = 184+(2*i);
		}
	}
}

































void InitGame()
{

int p1x,p1y,xz,yz,xs,ys,xEs,yEs,xEx,yEx,Nrg,Shoot,Lives,EnemyLive,Frame,FrameE1,FrameEs,FrameEx;

Lives = 5;
Frame = 0;
FrameE1 = 0;
FrameEs = 0;
FrameEx = 0;
EnemyLive = 1;
Nrg = 1;
p1x = 2;
p1y = 80;
xz = 200;
yz = 10;
xs = 241;
ys = 10;
xEs = 241;
yEs = 10;
xEx = 241;
yEx = 10;
}

void CheckForCollision()
{
int p1x,p1y,xz,yz,xs,ys,xEs,yEs,xEx,yEx,Nrg,Shoot,Lives,EnemyLive,Frame,FrameE1,FrameEs,FrameEx;
if (Nrg == 0) 
	{
	xEx = p1x;
	yEx = p1y;
	p1x = 241; 				// Draw the sprite outside the screen
	while (FrameEx < 6)
		{
		Explosion(xEx,yEx,FrameEx);
		WaitForVSync();
		FrameEx = FrameEx + 1;
		}
	xEs = 241;				// Draw the sprite outside the screen
	Lives = Lives - 1;
	}

}

void DoScroll()
{
BG1HOFS=BG1HOFS+1;
}

void UpdateScreen()
{
int p1x,p1y,xz,yz,xs,ys,xEs,yEs,xEx,yEx,Nrg,Shoot,EShoot,Lives,EnemyLive,Frame,FrameE1,FrameS,FrameEs,FrameEx;

if (Lives > 0) 
	{
	Player1 (p1x,p1y,Frame);
	Enemy1 (xz,yz,FrameE1);
	Frame = Frame+1;
	FrameE1 = FrameE1+1;
	if (Frame> 3) Frame = 0;			// if frame>3 reset the animation of the sprite
	if (FrameE1 > 3) FrameE1 = 0;			// if frame>3 reset the animation of the sprite

	if ((Shoot>0)&&(xs<240)) xs = xs+1; 		// Increase the value of xs until it is visible on screen
		else xs = 241;
	        
	if ((EShoot>0)&&(EShoot>0)) xEs = xEs-1;		// Decrease the value of xEs until it is visible on screen
		else xEs = 241;

	DoScroll();
	CheckForCollision();




	}

}









void SetPrincipalActorInfo(u16 x,u16 y,u16 xz,u16 yz)	//sets the sprite data at the x and y coordinates and tells what 
{							//tile # to use
//Frame1(x,y);
//Zanzara1(xz,yz);
//DoScroll();
//Frame2(x,y);
//Zanzara2(xz,yz);
//DoScroll();
//Frame3(x,y);
//Zanzara3(xz,yz);
//DoScroll();
//Frame2(x,y);
//Zanzara2(xz,yz);
//DoScroll();

}


void LoadSprite(u16 x,u16 y,u16 xz,u16 yz)
{	
	SetPrincipalActorInfo(x,y,xz,yz);	//load the sprite in at coordianates x, y
}


//*******************************************************************************
//*			fast DMA transfer of data				*
//*******************************************************************************


void DMA3Call(u32 Src,u32 Dst,u32 Cnt)	//used to load our sprite info into vram			
{
	DMA3SAD = Src;	//where the data is
	DMA3DAD = Dst;	//where the data goes
	DMA3CNT = Cnt;	//how much data should be loaded
}


void AssignSprite()
{
	DMA3Call((u32)&sprite_palette, (u32)OBJ_PLTT, 0x84000080);	// Setup the sprites palette
	DMA3Call((u32)&sprite, (u32)OBJCHARDATA, 0x84004000);		// Copy Sprites Character Bloc to VRAM
}





//*******************************************************************************
//*			thanx to warder1 for this routine			*
//*  what you do is save a 240x160 256color BMP run it thru spritestripper and  *
//*   then tru hackit to get the pal and raw data for inclusion in the data.asm *
//*  spritestripper creates the 8colums you need for mode0 and hackit converts  *
//*                            it into raw data                                 *
//*******************************************************************************


void ShowTitle()
{
   u16 x,y,i;

//*******************************************************************************
//*			load tiles from data to vram				*
//*******************************************************************************
   bg_data = (u8*)(&title);
   for(i=0;i<38400;i++) tiles[i]=bg_data[i];

//*******************************************************************************
//*				load palette to vram				*
//*******************************************************************************
   tmp_pal = (u16*)(&title_pal);
   for (i=0;i<256;i++) pal[i]=tmp_pal[i];

//*******************************************************************************
//*				draw tiles on screen				*
//*******************************************************************************
   for (y=0;y<20;y++)
       for (x=0;x<30;x++) {
           m0[y*32+x]=y*30+x;
       }
}


void ShowBG()
{
 u16 y,i;
//*******************************************************************************
//*			load tiles from data to vram				*
//*******************************************************************************
 bg_data = (u8*)(&level01);
 for(i=0;i<40960;i++) tiles[i]=bg_data[i];

//*******************************************************************************
//*				load palette to vram				*
//*******************************************************************************
 tmp_pal = (u16*)(&level01_pal);
 for (i=0;i<256;i++) pal[i]=tmp_pal[i];

//*******************************************************************************
//*				draw tiles on screen				*
//*******************************************************************************
 for (y=0;y<640;y++) m0[y]=y;

}



void MoveSprite()
{
	u16 x,xz,y,yz,xs,ys,xes,yes,shoot;	
	y = 80;
	x = 20;

	yz = 40;
	xz = 120;
	

	yes = 40;
	xes = 120;
	
	AssignSprite();
	ClearPad();
	while(1)
		{
		 ReadPad(&PadState);
		 LoadSprite(x,y,xz,yz);
		 DoScroll();
		 switch(PadState)
			{
			 case KEY_LEFT:
					x = x - 3;
					xz = xz + 3;
					if (x<3) x = 3;
					LoadSprite(x,y,xz,yz);
					//DoScroll();
					ClearPad();
					break;
			case KEY_UP:
					y = y - 3;
					if (y<3) y = 3;
					yz = yz +3;
					LoadSprite(x,y,xz,yz);
					//DoScroll();
					ClearPad();
					break;
		
			case KEY_RIGHT:
					x = x + 3;
					xz = xz - 3;
					if (x>240-32) x = 240-32;
					LoadSprite(x,y,xz,yz);
					//DoScroll();
					ClearPad();
					break;

			case KEY_DOWN:
					y = y + 3;
					yz = yz - 3;
					if (y>160-32) y =160-32; 
					LoadSprite(x,y,xz,yz);
					//DoScroll();		
					ClearPad();
					break;
			case KEY_A:

					xs = x;
					ys = y+16;
		//			Shoot(xs,ys);
		//			shoot = 1;
					ClearPad();
					break;
			};
			xes =xes-1;
//			EnemyShootFrame1(xes,yes);
			if (shoot > 0)
				{
				if (xs <256 )
					{
					xs=xs+6;
					//Shoot(xs,ys);
					}
				}
		}





























}





//*******************************************************************************
//*										*
//*          			MAIN CODE					*
//*										*
//*******************************************************************************

void StartHere()
{	
int p1x,p1y,Frame,xz,yz,FrameE1,xex,yex,FrameEx,xes,yes,FrameEs,Sync;        
	
 	InitGfx();
AssignSprite();
p1x=120;
p1y=80;
Frame=0;   

xz=180;
yz=80;
FrameE1=0;   

xex=20;
yex=80;
FrameEx=0;

xes=40;
yes=80;
FrameEs=0;
DISPCNT |= BIT09;   // Enable Background 1: The clouds
ShowBG();
Sync=0;
while (1)
	{
BG1HOFS=BG1HOFS+2;
	Enemy1 (xz,yz,FrameE1);	    
	Player1(p1x,p1y,Frame);
	Explosion(xex,yex,FrameEx),
	Enemy1Shoot(xes,yes,FrameEs);
	if (Sync==4) FrameEs=FrameEs+1;
	if (FrameEs==4) FrameEs=0;
	Frame=Frame+1;
	if (Frame==4) Frame=0;
	FrameE1=FrameE1+1;
	if (FrameE1==4) FrameE1=0;          
	FrameEx=FrameEx+1;
	if (FrameEx==6) FrameEx=0;
WaitForVSync();
Sync = Sync +1;
if (Sync == 5) Sync=0;
	}

        
        

	DISPCNT |= BIT09;   // Enable Background 1: The clouds
	ShowTitle();

	// Video_PressStartScreen()
	while(1)
		{
		 ClearPad();
		 ReadPad(&PadState);
		 switch(PadState)
			{
			 case KEY_START:
				Wait( 5 );
				FadeOut(1);
				ShowBG();
				Wait( 5 );
				FadeIn(1);
				MoveSprite();
				ClearPad();
				break;	
			};
		}
 


}
