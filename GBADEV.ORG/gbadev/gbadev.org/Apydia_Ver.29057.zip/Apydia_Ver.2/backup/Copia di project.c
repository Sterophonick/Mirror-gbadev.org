// +--------------------------------------------------+
// |                                                  |
// |                 Adydia ADVANCE                   |
// |                    Ver 0.05                      |
// +--------------------------------------------------+
// | By Raistlin                           12/05/2001 |
// +--------------------------------------------------+



//include standard routines
#include "AGBLib.h"
#include "GFX.h"
#include "GBADinput.h"

#define DMA3SAD		*(u32*)0x040000d4			//setups up all display variables. 
#define DMA3DAD		*(u32*)0x040000d8
#define DMA3CNT		*(u32*)0x040000dc
#define OAM		((Sprite*)0x07000000)
#define OBJCHARDATA	((u8*)0x06010000)
#define OBJ_PLTT	((u16*)0x05000200)




//some stuff needed to setup the picture display
//such as mem. adrr. of the palette, tile data and tile map
//man, this reminds me of GBC coding ...

u16 *pal=(u16*)0x5000000;
u16 *tmp_pal;
u8 *tiles=(u8*)0x6004000;
u8 *bg_data;
u16 *m0=(u16*)0x6000000;

unsigned short	PadState; 


// external ref. to tell the compiler that the picture and sprite data is coming from an external source
//in this case data.asm

	extern u8 background;     //adds the Title BG from data.asm
	extern u8 background_pal; //adds the Title BG palette from data.asm

	extern u8 level01;     //adds the Level1 BG from data.asm
	extern u8 level01_pal; //adds the Level1 BG palette from data.asm

	extern u32 sprite;	   //adds the sprite from data.asm
	extern u32 sprite_palette; //adds the sprite palette from data.asm




typedef struct _Sprite { u16 Attrib0, Attrib1, Attrib2, RotateScale; } Sprite;	//define a sprite as a structure











//********************************************************************************
//
//          			PLAYER 1 FRAMES
//			      PLAYER 1 Matrix 4*4
//********************************************************************************



void Frame1(u16 x,u16 y)
{
int i;


for (i=0;i<4;i++)
	{
	OAM[i].Attrib0 = 0x2000+y; //loads sprite 0 at y coordinate.  the 0x2000 tells it to use a 256 color palette
	OAM[i].Attrib1 = x+(8*i);  //loads sprite 0 at x coordinate
	OAM[i].Attrib2 = (2*i);	   //sets up sprite 0 as tile # 0
	}

for (i=0;i<4;i++)
	{
	OAM[4+i].Attrib0 = 0x2000+y+8;	//loads sprite 0 at y coordinate.  the 0x2000 tells it to use a 256 color palette
	OAM[4+i].Attrib1 = x+(8*i);	//loads sprite 0 at x coordinate
	OAM[4+i].Attrib2 = 8+(2*i);	//sets up sprite 0 as tile # 0
	}

for (i=0;i<4;i++)
	{
	OAM[8+i].Attrib0 = 0x2000+y+16;	//loads sprite 0 at y coordinate.  the 0x2000 tells it to use a 256 color palette
	OAM[8+i].Attrib1 = x+(8*i);	//loads sprite 0 at x coordinate
	OAM[8+i].Attrib2 = 16+(2*i);	//sets up sprite 0 as tile # 0
	}

for (i=0;i<4;i++)
	{
	OAM[12+i].Attrib0 = 0x2000+y+24; //loads sprite 0 at y coordinate.  the 0x2000 tells it to use a 256 color palette
	OAM[12+i].Attrib1 = x+(8*i);	 //loads sprite 0 at x coordinate
	OAM[12+i].Attrib2 = 24+(2*i);	 //sets up sprite 0 as tile # 0
	}

}


void Frame2(u16 x,u16 y)
{
int i;

for (i=0;i<4;i++)
	{
	OAM[i].Attrib0 = 0x2000+y;						//loads sprite 0 at y coordinate.  the 0x2000 tells it to use a 256 color palette
	OAM[i].Attrib1 = x+(8*i);								//loads sprite 0 at x coordinate
	OAM[i].Attrib2 = 32+(2*i);								//sets up sprite 0 as tile # 0
	}

for (i=0;i<4;i++)
	{
	OAM[4+i].Attrib0 = 0x2000+y+8;						//loads sprite 0 at y coordinate.  the 0x2000 tells it to use a 256 color palette
	OAM[4+i].Attrib1 = x+(8*i);								//loads sprite 0 at x coordinate
	OAM[4+i].Attrib2 =32+8+(2*i);								//sets up sprite 0 as tile # 0
	}

for (i=0;i<4;i++)
	{
	OAM[8+i].Attrib0 = 0x2000+y+16;						//loads sprite 0 at y coordinate.  the 0x2000 tells it to use a 256 color palette
	OAM[8+i].Attrib1 = x+(8*i);								//loads sprite 0 at x coordinate
	OAM[8+i].Attrib2 = 32+16+(2*i);								//sets up sprite 0 as tile # 0
	}

for (i=0;i<4;i++)
	{
	OAM[12+i].Attrib0 = 0x2000+y+24;						//loads sprite 0 at y coordinate.  the 0x2000 tells it to use a 256 color palette
	OAM[12+i].Attrib1 = x+(8*i);								//loads sprite 0 at x coordinate
	OAM[12+i].Attrib2 =32+24+(2*i);								//sets up sprite 0 as tile # 0
	}

}

void Frame3(u16 x,u16 y)
{
int i;

for (i=0;i<4;i++)
	{
	OAM[i].Attrib0 = 0x2000+y;						//loads sprite 0 at y coordinate.  the 0x2000 tells it to use a 256 color palette
	OAM[i].Attrib1 = x+(8*i);								//loads sprite 0 at x coordinate
	OAM[i].Attrib2 = 64+(2*i);								//sets up sprite 0 as tile # 0
	}

for (i=0;i<4;i++)
	{
	OAM[4+i].Attrib0 = 0x2000+y+8;						//loads sprite 0 at y coordinate.  the 0x2000 tells it to use a 256 color palette
	OAM[4+i].Attrib1 = x+(8*i);								//loads sprite 0 at x coordinate
	OAM[4+i].Attrib2 =64+8+(2*i);								//sets up sprite 0 as tile # 0
	}

for (i=0;i<4;i++)
	{
	OAM[8+i].Attrib0 = 0x2000+y+16;						//loads sprite 0 at y coordinate.  the 0x2000 tells it to use a 256 color palette
	OAM[8+i].Attrib1 = x+(8*i);								//loads sprite 0 at x coordinate
	OAM[8+i].Attrib2 = 64+16+(2*i);								//sets up sprite 0 as tile # 0
	}

for (i=0;i<4;i++)
	{
	OAM[12+i].Attrib0 = 0x2000+y+24;						//loads sprite 0 at y coordinate.  the 0x2000 tells it to use a 256 color palette
	OAM[12+i].Attrib1 = x+(8*i);								//loads sprite 0 at x coordinate
	OAM[12+i].Attrib2 = 64+24+(2*i);							//sets up sprite 0 as tile # 0
	}

}

//********************************************************************************
//
//          			ENEMY 1 FRAMES
//			      Zanzara Matrix 2*3
//********************************************************************************


void Zanzara1(u16 xz,u16 yz)
{
int i;

for (i=0;i<2;i++)
	{
	OAM[16+i].Attrib0 = 0x2000+yz;						//loads sprite 0 at y coordinate.  the 0x2000 tells it to use a 256 color palette
	OAM[16+i].Attrib1 = xz+(8*i);								//loads sprite 0 at x coordinate
	OAM[16+i].Attrib2 = 96+(2*i);								//sets up sprite 0 as tile # 0
	}

for (i=0;i<2;i++)
	{
	OAM[18+i].Attrib0 = 0x2000+yz+8;						//loads sprite 0 at y coordinate.  the 0x2000 tells it to use a 256 color palette
	OAM[18+i].Attrib1 = xz+(8*i);								//loads sprite 0 at x coordinate
	OAM[18+i].Attrib2 = 96+4+(2*i);								//sets up sprite 0 as tile # 0
	}

for (i=0;i<2;i++)
	{
	OAM[20+i].Attrib0 = 0x2000+yz+16;						//loads sprite 0 at y coordinate.  the 0x2000 tells it to use a 256 color palette
	OAM[20+i].Attrib1 = xz+(8*i);								//loads sprite 0 at x coordinate
	OAM[20+i].Attrib2 = 96+8+(2*i);								//sets up sprite 0 as tile # 0
	}
}


void Zanzara2(u16 xz,u16 yz)
{
int i;

for (i=0;i<2;i++)
	{
	OAM[16+i].Attrib0 = 0x2000+yz;						//loads sprite 0 at y coordinate.  the 0x2000 tells it to use a 256 color palette
	OAM[16+i].Attrib1 = xz+(8*i);								//loads sprite 0 at x coordinate
	OAM[16+i].Attrib2 = 108+(2*i);								//sets up sprite 0 as tile # 0
	}

for (i=0;i<2;i++)
	{
	OAM[18+i].Attrib0 = 0x2000+yz+8;						//loads sprite 0 at y coordinate.  the 0x2000 tells it to use a 256 color palette
	OAM[18+i].Attrib1 = xz+(8*i);								//loads sprite 0 at x coordinate
	OAM[18+i].Attrib2 = 112+(2*i);								//sets up sprite 0 as tile # 0
	}

for (i=0;i<2;i++)
	{
	OAM[20+i].Attrib0 = 0x2000+yz+16;						//loads sprite 0 at y coordinate.  the 0x2000 tells it to use a 256 color palette
	OAM[20+i].Attrib1 = xz+(8*i);								//loads sprite 0 at x coordinate
	OAM[20+i].Attrib2 = 116+(2*i);								//sets up sprite 0 as tile # 0
	}
}


void Zanzara3(u16 xz,u16 yz)
{
int i;

for (i=0;i<2;i++)
	{
	OAM[16+i].Attrib0 = 0x2000+yz;						//loads sprite 0 at y coordinate.  the 0x2000 tells it to use a 256 color palette
	OAM[16+i].Attrib1 = xz+(8*i);								//loads sprite 0 at x coordinate
	OAM[16+i].Attrib2 = 120+(2*i);								//sets up sprite 0 as tile # 0
	}

for (i=0;i<2;i++)
	{
	OAM[18+i].Attrib0 = 0x2000+yz+8;						//loads sprite 0 at y coordinate.  the 0x2000 tells it to use a 256 color palette
	OAM[18+i].Attrib1 = xz+(8*i);								//loads sprite 0 at x coordinate
	OAM[18+i].Attrib2 = 124+(2*i);								//sets up sprite 0 as tile # 0
	}

for (i=0;i<2;i++)
	{
	OAM[20+i].Attrib0 = 0x2000+yz+16;						//loads sprite 0 at y coordinate.  the 0x2000 tells it to use a 256 color palette
	OAM[20+i].Attrib1 = xz+(8*i);								//loads sprite 0 at x coordinate
	OAM[20+i].Attrib2 = 128+(2*i);								//sets up sprite 0 as tile # 0
	}
}

void Shoot(int xs,int ys)
{
int i;

	for (i=0;i<2;i++)
	{
	OAM[22+i].Attrib0 = 0x2000+ys;						//loads sprite 0 at y coordinate.  the 0x2000 tells it to use a 256 color palette
	OAM[22+i].Attrib1 = xs+(8*i);								//loads sprite 0 at x coordinate
	OAM[22+i].Attrib2 = 132+(2*i);								//sets up sprite 0 as tile # 0
	}
}


void DoScroll()
{
BG1HOFS=BG1HOFS+3;
Wait(1);		
}




void SetPrincipalActorInfo(u16 x,u16 y,u16 xz,u16 yz)	//sets the sprite data at the x and y coordinates and tells what 
{							//tile # to use
Frame1(x,y);
Zanzara1(xz,yz);
Frame2(x,y);
Zanzara2(xz,yz);
Frame3(x,y);
Zanzara3(xz,yz);
Frame2(x,y);
Zanzara2(xz,yz);

}


void LoadSprite(u16 x,u16 y,u16 xz,u16 yz)
{	
	SetPrincipalActorInfo(x,y,xz,yz);	//load the sprite in at coordianates x, y
}


//fast DMA transfer of data
void DMA3Call(u32 Src,u32 Dst,u32 Cnt)	//used to load our sprite info into vram			
{
	DMA3SAD = Src;	//where the data is
	DMA3DAD = Dst;	//where the data goes
	DMA3CNT = Cnt;	//how much data should be loaded
}

void AssignSprite()
{
	DMA3Call((u32)&sprite_palette, (u32)OBJ_PLTT, 0x84000080);	// Setup the sprites palette
	DMA3Call((u32)&sprite, (u32)OBJCHARDATA, 0x84004000);		// Copy Sprites Character Bloc to VRAM
}






//thanx to warder1 for this routine
//what you do is save a 240x160 256color BMP run it thru spritestripper and then tru hackit to get the pal and raw data for inclusion in the data.asm
//spritestripper creates the 8colums you need for mode0 and hackit converts it into raw data

void ShowTitle()
{
   u16 x,y,i;

   //load tiles from data to vram
   bg_data = (u8*)(&background);
   for(i=0;i<38400;i++) tiles[i]=bg_data[i];

   //load palette to vram
   tmp_pal = (u16*)(&background_pal);
   for (i=0;i<256;i++) pal[i]=tmp_pal[i];

  //draw tiles on screen
   for (y=0;y<20;y++)
       for (x=0;x<30;x++) {
           m0[y*32+x]=y*30+x;
       }
}

void ShowBG()
{
 u16 y,i;
  
 //load tiles from data to vram
 bg_data = (u8*)(&level01);
 for(i=0;i<40960;i++) tiles[i]=bg_data[i];

 //load palette to vram
 tmp_pal = (u16*)(&level01_pal);
 for (i=0;i<256;i++) pal[i]=tmp_pal[i];

 //draw tiles on screen
 for (y=0;y<640;y++) m0[y]=y;
}



void MoveSprite()
{
	u16 x,xz,y,yz,xs,ys,shoot;	
	y = 80;
	x = 20;

	yz = 40;
	xz = 120;
	
	AssignSprite();
	ClearPad();
	while(1)
		{
		 ReadPad(&PadState);
		 LoadSprite(x,y,xz,yz);
		 DoScroll();
		 switch(PadState)
			{
			 case KEY_LEFT:
					x = x - 3;
					xz = xz + 3;
					if (x<3) x = 3;
					LoadSprite(x,y,xz,yz);
					DoScroll();
					ClearPad();
					break;
			case KEY_UP:
					y = y - 3;
					if (y<3) y = 3;
					yz = yz +3;
					LoadSprite(x,y,xz,yz);
					DoScroll();
					ClearPad();
					break;
		
			case KEY_RIGHT:
					x = x + 3;
					xz = xz - 3;
					if (x>240-32) x = 240-32;
					LoadSprite(x,y,xz,yz);
					DoScroll();
					ClearPad();
					break;

			case KEY_DOWN:
					y = y + 3;
					yz = yz - 3;
					if (y>160-32) y =160-32; 
					LoadSprite(x,y,xz,yz);
					DoScroll();		
					ClearPad();
					break;
			case KEY_A:

					xs = x;
					ys = y+16;
					Shoot(xs,ys);
					shoot = 1;
					ClearPad();
					break;
			};

			if (shoot > 0)
				{
				if (xs <256 )
					{
					xs=xs+15;
					Shoot(xs,ys);
					}
				}
		}



























//
//		LoadSprite(x,y,xz,yz);
//		DoScroll();
//		while( !( P1 & KEY_A ) )
//			{
//			xs = x;
//			ys = y+16;
//			Shoot(xs,ys);
//			shoot = 1;
//			}
//		
//		while( !( P1 & KEY_UP ) )
//			{
//			y = y - 3;
//			if (y<3) y = 3;
//			yz = yz +3;
//			LoadSprite(x,y,xz,yz);
//			DoScroll();
//			}
//	
//		while( !( P1 & KEY_DOWN ) )
//			{
//			y = y + 3;
//			yz = yz - 3;
//			if (y>160-32) y =160-32; 
//			LoadSprite(x,y,xz,yz);
//			DoScroll();		
//			}
//		while( !( P1 & KEY_RIGHT ) )
//			{
//			x = x + 3;
//			xz = xz - 3;
//			if (x>240-32) x = 240-32;
//			LoadSprite(x,y,xz,yz);
//			DoScroll();
//			}
//		while( !( P1 & KEY_LEFT ) )
//			{
//			x = x - 3;
//			xz = xz + 3;
//			if (x<3) x = 3;
//			LoadSprite(x,y,xz,yz);
//			DoScroll();
//			}
//
//		if (shoot > 0)
//			{
//			xs=xs+6;
//			Shoot(xs,ys);
//			}
//		}



}





//********************************************************************************
//
//          			MAIN CODE
//
//********************************************************************************

void StartHere()
{	
        
	
 	InitGfx();

	DISPCNT |= BIT09;   // Enable Background 1: The clouds
	
	ShowTitle();

	// Video_PressStartScreen()
 
	while(1)
		{
		 ClearPad();
		 ReadPad(&PadState);
		 switch(PadState)
			{
			 case KEY_START:
				Wait( 5 );
				FadeOut(1);
				ShowBG();
				Wait( 5 );
				FadeIn(1);
				MoveSprite();
				ClearPad();
				break;	
			};
		}
 


}
