// +--------------------------------------------------+
// |                                                  |
// |                 Adydia ADVANCE                   |
// |                    Ver 0.00                      |
// +--------------------------------------------------+
// | By Raistlin                           30/04/2001 |
// +--------------------------------------------------+



//include standard routines
#include "AGBLib.h"
//#include "rieslib.h"




//some stuff needed to setup the picture display
//such as mem. adrr. of the palette, tile data and tile map
//man, this reminds me of GBC coding ...
u16 *pal=(u16*)0x5000000;
u16 *tmp_pal;
u8 *tiles=(u8*)0x6004000;
u8 *bg_data;
u16 *m0=(u16*)0x6000000;

// external ref. to tell the compiler that the picture and sprite data is coming from an external source
//in this case data.asm

extern u8 background;
extern u8 background_pal;

extern u8 level01;
extern u8 level01_pal;

extern u8 level1_c;



//fast DMA transfer of data
//void DMA3Call(u32 Src,u32 Dst,u32 Cnt)              //used to load our sprite info into vram
//{
//	REG_DM3SAD = Src;									//where the data is
//	REG_DM3DAD = Dst;									//where the data goes
//	REG_DM3CNT = Cnt;									//how much data should be loaded
//}




//thanx to warder1 for this routine
//what you do is save a 240x160 256color BMP run it thru spritestripper and then tru hackit to get the pal and raw data for inclusion in the data.asm
//spritestripper creates the 8colums you need for mode0 and hackit converts it into raw data

void ShowTitle()
{
   u16 x,y,i;

   //load tiles from data to vram
   bg_data = (u8*)(&background);
   for(i=0;i<38400;i++) tiles[i]=bg_data[i];

   //load palette to vram
   tmp_pal = (u16*)(&background_pal);
   for (i=0;i<256;i++) pal[i]=tmp_pal[i];

  //draw tiles on screen
   for (y=0;y<20;y++)
       for (x=0;x<30;x++) {
           m0[y*32+x]=y*30+x;
       }
}

void ShowBG()
{
   u16 y,i;

   //load tiles from data to vram
   bg_data = (u8*)(&level01);
   for(i=0;i<40960;i++) tiles[i]=bg_data[i];

   //load palette to vram
   tmp_pal = (u16*)(&level01_pal);
   for (i=0;i<256;i++) pal[i]=tmp_pal[i];

  //draw tiles on screen
   for (y=0;y<640;y++)
//       for (x=0;x<30;x++) {
           m0[y]=y;
  //     }

}

void DoScroll()
{
	while(1)
		{
		BG1HOFS=BG1HOFS+2;
		Wait(1);
		}
}



//********************************************************************************
//entry from startup asm code, probably the only original bit in this source all others use c_entry :)))
//this is the replacement for the main() stuff you find in other C programs
//********************************************************************************
void StartHere()
{	
        
	
 DISPCNT = 0; // Set the video mode to mode 0: Tile mode

	 DISPCNT |= BIT06; // 2 Dimensional mapping for sprite data
	 
	 // Setup the BG0: The playing area

	 BG0CNT  = 0 | BIT01;        // Size = 256*256 , Character base block = 0, Second Priority
	 BG0CNT |= BIT07;    // Colormode = 256 colors * 1 palette
	 //BG0CNT |= ( 0<<2 ); // Screen base block = 7
	 BG0CNT |= BIT06;    

	 // Setup background 1: The clouds

	 BG1CNT  = 1<<2;        // Size = 256*256 , Character base block = 0, First Priority
	 BG1CNT |= BIT07;    // Colormode = 256 colors * 1 palette
	// BG1CNT |= ( 7<<8 ); // Screen base block = 15
	 BG1CNT |= BIT06;  


//clear the VRAM screendisplay as defined in rieslib.h

//DMAClearScreen();
//ClearScreen();





//DISPCNT |= BIT08;   // Enable Background 0: The map
DISPCNT |= BIT09;   // Enable Background 1: The clouds
ShowTitle();


// Video_PressStartScreen()
 
while(1)
	{
	while( !( P1 & KEY_START ) )
		{
		Wait( 10 );
		FadeOut(1);
		ShowBG();
		Wait( 10 );
		FadeIn(1);
		DoScroll();

		}
	}
 




}
