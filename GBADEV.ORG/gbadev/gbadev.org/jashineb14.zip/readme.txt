    Jashin (wicked heart)
-=-=-=-=-=-=-=-=-=-=-=-=-=-=-
           Credits
-=-=-=-=-=-=-=-=-=-=-=-=-=-=-
Code: Costis & BigRedPimp
Graphics: BigRedPimp
Music: Alex Ojideagu
Special Credits
Music Player (GBA Music Wave) by Sergej Kravcenko
 - http://www.codewaves.com/

-=-=-=-=-=-=-=-=-=-=-=-=-=-=-
          Controls
-=-=-=-=-=-=-=-=-=-=-=-=-=-=-
A - (De)selects Cards
Start - Finishes 3 card passing phase

-=-=-=-=-=-=-=-=-=-=-=-=-=-=-
            End
-=-=-=-=-=-=-=-=-=-=-=-=-=-=-
Sorry about the quick & simple readme, just wanted to get the basics in here and ship this out.
Took us long enough. :)