WonkieGuy by Sean Reid
======================

Date: August 17, 2002


About the Demo
==============

This is my first real GBA project which is a simple side-scrolling
platform game.  It is built on top of an engine that I am currently
producing.  Basically, as I program this game, I am programming
the engine.


Playing the Game
================

D-Pad - Move Wonkie, the main player
Start - Pause
A     - Jump
B     - Toss Head

Be sure to collect your head after you toss it.  You have a limited 
amount to get your head before you die.  The amount of time you have 
remaining is shown in the top-right corner of the screen, named the 
headless meter.

Your health meter is denoted by the 5 boxes next to the headless
meter.  When your health is depleted, you will die and have to start 
at the beginning of the level.

If you happen to throw your head down the pit, you will eventually 
die since you can no longer collect your head.  You might as well 
collect as many gems on the screen while you can.

A portal is at the end of each level.  If you lose your head near 
the end of the level, don't assume that you can make a run for the 
portal.  You must have your head to proceed.


For the Future
==============

It looks like I will be stopping work on this game.  I am always 
wanting to add more, but there just isn't any time.  Looks like 
this will be the definitive first installment for Wonkie Guy's 
adventures.


Emulators and GBA Hardware
==========================

I haven't tested this demo on real hardware.  If someone can test it,
please email me.  I tested this mostly on VisualBoy Advance.  However,
as of now, it does not run on Boycott Advance Online--the Java port of
Boycott Advance.  Let's hope that the issue is remedied soon.


Contact and Links
=================

The sound system in this game is powered by Krawall Advance.  Please
visit the homepage for this great, easy-to-use sound engine.

    http://mind.riot.org/krawall

Background music created by Jessie Tracer / Electronic Keet.

    http://menagerie.tf/~tracerj

For updates on this project, please visit:

    http://www.seanreid.ca/project/WonkieGuy

TileMax is extremely useful for this demo:

    http://www.seanreid.ca/project/TileMax

If you want to email me, my address is:

    email@seanreid.ca

My resume is located online at:

    http://www.seanreid.ca/resource/sean_reid_resume.html
