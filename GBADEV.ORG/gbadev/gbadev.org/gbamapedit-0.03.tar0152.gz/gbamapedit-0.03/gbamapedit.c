/*
 * gbamapedit
 *
 * Copyright (C) 2003, 2004 Stephen Strowes (sdstrowes@gmail.com)
 * Modified by Boin Francois, 2004/2005 to handle GIMP header file formats.
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 *
 */
#include <stdlib.h>
#include <gtk/gtk.h>
#include "gba_data_io.h"

static int            current_selection= 0;
gba_map					MainMapping;

static GtkWidget      *map_table;            /* Table governing layout of map.                         */
static GtkWidget      **map_tile;            /* Array of tiles for the map, to be placed in the table. */
static GdkPixbuf      **pixbuf1;             /* The pixbuf the image data is first loaded into         */
static GtkWidget      *statusimage;
static GtkWidget      *status_hbox;
static GtkWidget      *about;


static GtkWidget *window,                           /* The main window, into which everything is placed.      */
		*h_box,                                    /* Horizontal box for map + tiles.                        */
		*v_box,                                    /* The vertical box for main window elements.             */
		*map_scrolled_window,                      /* The scrollpane that the map itself is placed in.       */
		*tiles_scrolled_window,                    /* The scrollpane that the available tiles are placed in. */
		*tiles_table,                              /* The table into which the tiles are placed.             */
		*tiles_table_event_box,                    /* The event box into which the tiles table is placed     */
		*map_table_event_box,                      /* The event box into which the map table is placed       */
		**image,                                   /* The image data itself                                  */
		*menubar,                                  /* The menu bar.                                          */
		*statusfield;




/* ########################################################################## */
/* pre declarations for callbacks*/
int LoadDataFiles(pgba_map pMapping);
int initGTKInterface(pgba_map pMapping);
void destroyGTKInterface();
/* ########################################################################## */
/** Callback functions **/
static void MappingFile_ok(GtkWidget        *w,GtkFileSelection *fs )
{
	strncpy(MainMapping.strMapFile,gtk_file_selection_get_filename(GTK_FILE_SELECTION(fs)),254);
	gtk_widget_destroy(((w->parent)->parent)->parent);

	printf( "Loading Mapping file : %s ...\n",MainMapping.strMapFile );
	destroyGTKInterface();
	
	if(LoadDataFiles(&MainMapping) != 0)
		printf("Error Loading files !!!\n");

	initGTKInterface(&MainMapping);
}
static void HeaderFile_ok(GtkWidget        *w,GtkFileSelection *fs )
{
	strncpy(MainMapping.strHeaderFile,gtk_file_selection_get_filename(GTK_FILE_SELECTION(fs)),254);
	MainMapping.yHeaderFormat = 1;
	gtk_widget_destroy(((w->parent)->parent)->parent);

	printf( "Loading Header file : %s ...\n",MainMapping.strHeaderFile );
	destroyGTKInterface();
	
	if(LoadDataFiles(&MainMapping) != 0)
		printf("Error Loading files !!!\n");

	initGTKInterface(&MainMapping);
}
static void PaletteFile_ok(GtkWidget        *w,GtkFileSelection *fs )
{
	strncpy(MainMapping.strPaletteFile,gtk_file_selection_get_filename(GTK_FILE_SELECTION(fs)),254);
	gtk_widget_destroy(((w->parent)->parent)->parent);

	printf( "Loading files Tile : %s, Palette : %s ...\n",MainMapping.strTileFile,MainMapping.strPaletteFile );
	destroyGTKInterface();
	
	if(LoadDataFiles(&MainMapping) != 0)
		printf("Error Loading files !!!\n");

	initGTKInterface(&MainMapping);
}
static void TileFile_ok(GtkWidget        *w,GtkFileSelection *fs )
{
	GtkWidget *wPaletteFile;
	
	strncpy(MainMapping.strTileFile,gtk_file_selection_get_filename(GTK_FILE_SELECTION(fs)),254);
	MainMapping.yHeaderFormat = 0;
	gtk_widget_destroy(((w->parent)->parent)->parent);
	
	wPaletteFile = gtk_file_selection_new("Choose an Palette File to Load :");
	g_signal_connect (G_OBJECT (wPaletteFile), "destroy",G_CALLBACK (gtk_widget_destroy), NULL);
    g_signal_connect (G_OBJECT (GTK_FILE_SELECTION (wPaletteFile)->ok_button),"clicked", G_CALLBACK (PaletteFile_ok), (gpointer) wPaletteFile);
    g_signal_connect_swapped (G_OBJECT (GTK_FILE_SELECTION (wPaletteFile)->cancel_button),"clicked", G_CALLBACK (gtk_widget_destroy),G_OBJECT (wPaletteFile));
    gtk_file_selection_set_filename (GTK_FILE_SELECTION(wPaletteFile),MainMapping.strPaletteFile);
    
	gtk_widget_show(wPaletteFile);
}

static void load_header()
{
	GtkWidget* wFile = gtk_file_selection_new("Choose an Header File to Load :");
	g_signal_connect (G_OBJECT (wFile), "destroy",G_CALLBACK (gtk_widget_destroy), NULL);
    g_signal_connect (G_OBJECT (GTK_FILE_SELECTION (wFile)->ok_button),"clicked", G_CALLBACK (HeaderFile_ok), (gpointer) wFile);
    g_signal_connect_swapped (G_OBJECT (GTK_FILE_SELECTION (wFile)->cancel_button),"clicked", G_CALLBACK (gtk_widget_destroy),G_OBJECT (wFile));
    gtk_file_selection_set_filename (GTK_FILE_SELECTION(wFile),MainMapping.strHeaderFile);
    
	gtk_widget_show(wFile);
}

static void load_tilepalette()
{
	GtkWidget *wTileFile;
	
	wTileFile = gtk_file_selection_new("Choose an Tile File to Load :");
	g_signal_connect (G_OBJECT (wTileFile), "destroy",G_CALLBACK (gtk_widget_destroy), NULL);
    g_signal_connect (G_OBJECT (GTK_FILE_SELECTION (wTileFile)->ok_button),"clicked", G_CALLBACK (TileFile_ok), (gpointer) wTileFile);
    g_signal_connect_swapped (G_OBJECT (GTK_FILE_SELECTION (wTileFile)->cancel_button),"clicked", G_CALLBACK (gtk_widget_destroy),G_OBJECT (wTileFile));
    gtk_file_selection_set_filename (GTK_FILE_SELECTION(wTileFile),MainMapping.strTileFile);
    
	gtk_widget_show(wTileFile);
}

static void load_mapping()
{
	GtkWidget* wFile;
	
	if(MainMapping.yLoaded != 1)
	{
		GtkWidget* dlg;
		GtkWidget* label1;
		
		dlg= gtk_dialog_new( );
		label1= gtk_label_new( "Please load Image first(Header or Tile/Palette)" );
		
		gtk_box_pack_start( GTK_BOX( GTK_DIALOG( dlg )->vbox ), label1, TRUE, TRUE, 0 );
		
		gtk_widget_show( label1 );
		gtk_widget_show( dlg );
		return;
	}
	wFile = gtk_file_selection_new("Choose an Mapping File to Load :");
	g_signal_connect (G_OBJECT (wFile), "destroy",G_CALLBACK (gtk_widget_destroy), NULL);
    g_signal_connect (G_OBJECT (GTK_FILE_SELECTION (wFile)->ok_button),"clicked", G_CALLBACK (MappingFile_ok), (gpointer) wFile);
    g_signal_connect_swapped (G_OBJECT (GTK_FILE_SELECTION (wFile)->cancel_button),"clicked", G_CALLBACK (gtk_widget_destroy),G_OBJECT (wFile));
    gtk_file_selection_set_filename (GTK_FILE_SELECTION(wFile),MainMapping.strMapFile);
    
	gtk_widget_show(wFile);
}

static void save_map()
{
	printf( "Saving file: %s...", MainMapping.strMapFile);
	write_new_file( &MainMapping.map,MainMapping.strMapFile);
	printf( "done.\n" );
}

static void set_map32()
{
	int count;
	printf( "Changing map size to 32...\n" );
	
	if(MainMapping.yLoaded != 1)
	{
		GtkWidget* dlg;
		GtkWidget* label1;
		
		dlg= gtk_dialog_new( );
		label1= gtk_label_new( "Please load Image first(Header or Tile/Palette)" );
		
		gtk_box_pack_start( GTK_BOX( GTK_DIALOG( dlg )->vbox ), label1, TRUE, TRUE, 0 );
		
		gtk_widget_show( label1 );
		gtk_widget_show( dlg );
		return;
	}
	MainMapping.strMapFile[0] = 0;
    MainMapping.map.width= 32;
    MainMapping.map.size= ( MainMapping.map.width * MainMapping.map.width );
    MainMapping.map.data= (int*)malloc( sizeof(int) * MainMapping.map.size );

    for ( count= 0; count<(MainMapping.map.size); count++ )
		MainMapping.map.data[count]= 0;
	
	destroyGTKInterface();
	
	if(LoadDataFiles(&MainMapping) == 0)
		initGTKInterface(&MainMapping);
	else
		printf("Error ReinitMapping\n");
}

static void set_map64()
{
	int count;
	printf( "Changing map size to 64...\n" );
	
	if(MainMapping.yLoaded != 1)
	{
		GtkWidget* dlg;
		GtkWidget* label1;
		
		dlg= gtk_dialog_new( );
		label1= gtk_label_new( "Please load Image first(Header or Tile/Palette)" );
		
		gtk_box_pack_start( GTK_BOX( GTK_DIALOG( dlg )->vbox ), label1, TRUE, TRUE, 0 );
		
		gtk_widget_show( label1 );
		gtk_widget_show( dlg );
		return;
	}
	
    MainMapping.map.width= 64;
    MainMapping.map.size= ( MainMapping.map.width * MainMapping.map.width );
    MainMapping.map.data= (int*)malloc( sizeof(int) * MainMapping.map.size );

    for ( count= 0; count<(MainMapping.map.size); count++ )
		MainMapping.map.data[count]= 0;
	
	destroyGTKInterface();
	
	if(LoadDataFiles(&MainMapping) == 0)
		initGTKInterface(&MainMapping);
	else
		printf("Error ReinitMapping\n");
}

static void set_map128()
{
	int count;
	printf( "Changing map size to 128...\n" );
	
	if(MainMapping.yLoaded != 1)
	{
		GtkWidget* dlg;
		GtkWidget* label1;
		
		dlg= gtk_dialog_new( );
		label1= gtk_label_new( "Please load Image first(Header or Tile/Palette)" );
		
		gtk_box_pack_start( GTK_BOX( GTK_DIALOG( dlg )->vbox ), label1, TRUE, TRUE, 0 );
		
		gtk_widget_show( label1 );
		gtk_widget_show( dlg );
		return;
	}
	
    MainMapping.map.width= 128;
    MainMapping.map.size= ( MainMapping.map.width * MainMapping.map.width );
    MainMapping.map.data= (int*)malloc( sizeof(int) * MainMapping.map.size );

    for ( count= 0; count<(MainMapping.map.size); count++ )
		MainMapping.map.data[count]= 0;
	
	destroyGTKInterface();
	
	if(LoadDataFiles(&MainMapping) == 0)
		initGTKInterface(&MainMapping);
	else
		printf("Error ReinitMapping\n");
}


/* ########################################################################## */

static gint map_button_press_event( GtkWidget *widget, GdkEventButton *event )
{
  int xc= ((int)event->x)/34;
  int yc= ((int)event->y)/34;

	if((yc>=MainMapping.map.width) || (xc>=MainMapping.map.width))
		return TRUE;
	
  if ( event->button == 1 ) { /* Respond to left mouse button */ 
    if ( DEBUG ) 
      printf( "DEBUG: MAP_PANE:   Tile clicked on: %d, %d\n", xc, yc );
    
    /* Set corresponding map element to be 'current_selection' */
    MainMapping.map.data[yc*MainMapping.map.width + xc]= current_selection;
    
    if ( DEBUG )
      printf( "DEBUG: MAP_PANE:   map.data[%d*%d + %d] == %d.\n", yc, MainMapping.map.width, xc, (MainMapping.map.data[yc*MainMapping.map.width + xc]) );
    
    /* Destroy existing tile and create new one */
    gtk_widget_destroy ( map_tile[yc*MainMapping.map.width + xc] );
    map_tile[yc*MainMapping.map.width + xc]= gtk_image_new_from_pixbuf( pixbuf1[MainMapping.map.data[yc*MainMapping.map.width + xc]] );
    
    /* Attach it to the table, and display it */
    gtk_table_attach( GTK_TABLE( map_table ), map_tile[yc*MainMapping.map.width + xc], xc, xc+1, yc, yc+1, GTK_FILL, GTK_FILL, 1, 1 );
    gtk_widget_show( map_tile[yc*MainMapping.map.width + xc] );
  }

  return TRUE;
}

/* ########################################################################## */

static gint tiles_button_press_event( GtkWidget *widget, GdkEventButton *event )
{
  int yc= (int)event->y;

  if ( event->button == 1 ) { /* Respond to left mouse button */
    current_selection= yc/34;
	if(current_selection >= MainMapping.tile.count)
		return TRUE;
    if ( DEBUG )
      printf( "DEBUG: TILES_PANE: Current selection now: %d\n", current_selection );

    gtk_widget_destroy ( statusimage );
    statusimage= gtk_image_new_from_pixbuf( pixbuf1[current_selection] );
    gtk_box_pack_start( GTK_BOX(status_hbox), statusimage, FALSE, FALSE, 0 );
    gtk_widget_show( statusimage );
  }

  return TRUE;
}

/* ########################################################################## */
static void destroy_about()
{
  if (about)
    gtk_widget_destroy(about);
  about = NULL;
}

void about_menu(GtkWidget *w, void *data)
{
  GtkWidget* button;
  GtkWidget* label1, *label2, *label3;

  about= gtk_dialog_new( );
  button= gtk_button_new_from_stock( GTK_STOCK_OK );
  label1= gtk_label_new( "GBAMapEdit" );
  label2= gtk_label_new( "Gameboy Advance Map Editor written in C using GTK+" );
  label3= gtk_label_new( "Released under the GPL by Stephen Strowes, 2003 (Modifications François BOIN 2004/2005)" );

  gtk_box_pack_start( GTK_BOX( GTK_DIALOG( about )->vbox ), label1, TRUE, TRUE, 0 );
  gtk_box_pack_start( GTK_BOX( GTK_DIALOG( about )->vbox ), label2, TRUE, TRUE, 0 );
  gtk_box_pack_start( GTK_BOX( GTK_DIALOG( about )->vbox ), label3, TRUE, TRUE, 0 );
  gtk_box_pack_start( GTK_BOX( GTK_DIALOG( about )->action_area ), button, TRUE, TRUE, 0 );
  
  g_signal_connect( G_OBJECT (button), "clicked", G_CALLBACK (destroy_about), (gpointer) about);

  gtk_widget_show( label1 );
  gtk_widget_show( label2 );
  gtk_widget_show( label3 );
  gtk_widget_show( button );
  gtk_widget_show( about );
}

/* ########################################################################## */

/* Our menu, an array of GtkItemFactoryEntry structures that defines each menu item */
static GtkItemFactoryEntry menu_items[] = {
	{ "/_File",						NULL,			NULL,				0, "<Branch>" },
	{ "/File/_Load Header",			"<control>L",	load_header,		0, "<StockItem>", GTK_STOCK_OPEN },
	{ "/File/Load _Tile&Palette",	"<control>T",	load_tilepalette,	0, "<StockItem>", GTK_STOCK_OPEN },
	{ "/File/Load _Map",			"<control>M",	load_mapping,		0, "<StockItem>", GTK_STOCK_OPEN },
	{ "/File/_Save",				"<control>S",	save_map,			0, "<StockItem>", GTK_STOCK_SAVE },
	{ "/File/sep1",					NULL,			NULL,				0, "<Separator>" },
	{ "/File/_Quit",				"<control>Q",	gtk_main_quit,		0, "<StockItem>", GTK_STOCK_QUIT },
	{ "/_Mapping",					NULL,			NULL,				0, "<LastBranch>" },
	{ "/Mapping/32x32 Map",			NULL,			set_map32,			0, "<StockItem>", GTK_STOCK_CONVERT },
	{ "/Mapping/64x64 Map",			NULL,			set_map64,			0, "<StockItem>", GTK_STOCK_CONVERT },
	{ "/Mapping/128x128 Map",		NULL,			set_map128,			0, "<StockItem>", GTK_STOCK_CONVERT },
	{ "/_Help",						NULL,			NULL,				0, "<LastBranch>" },
	{ "/Help/About",				NULL,			about_menu,			0, "<StockItem>", GTK_STOCK_HELP },
};
static gint nmenu_items= sizeof( menu_items )/sizeof( menu_items[0] );

/* Returns a menubar widget made from the above menu */
GtkWidget *get_menubar_menu( GtkWidget  *window )
{
  GtkItemFactory *item_factory;
  GtkAccelGroup  *accel_group;

  /* Make and attach an accelerator group (shortcut keys) */
  accel_group= gtk_accel_group_new ();
  gtk_window_add_accel_group( GTK_WINDOW (window), accel_group );

  /* Make an ItemFactory (that makes a menubar) */
  item_factory= gtk_item_factory_new( GTK_TYPE_MENU_BAR, "<main>", accel_group );

  /* Generate the menu items. */
  gtk_item_factory_create_items( item_factory, nmenu_items, menu_items, NULL );

  return gtk_item_factory_get_widget( item_factory, "<main>" );
}

/* ########################################################################## */
void UnloadDataFiles(pgba_map pMapping)
{
	if(pMapping->yHeaderFormat == 1)
		destroy_xpmHeader(&(pMapping->xpm_Header),&(pMapping->tile));
	else
		destroy_xpm_data(&(pMapping->xpm_TilePalette));
	
	destroy_palette_data( &(pMapping->palette) );
	destroy_tile_data( &(pMapping->tile) );
	pMapping->yLoaded = 0;
	printf("Unload OK\n");
}

int LoadDataFiles(pgba_map pMapping)
{
	UnloadDataFiles(pMapping);
	
	if(pMapping->yHeaderFormat == 1)
	{
		if(get_HeaderFormat_data(&(pMapping->tile),&(pMapping->palette),pMapping->strHeaderFile)==0)
		{
			get_map_data( &pMapping->map, pMapping->strMapFile );
			get_Headerxpm_data( &(pMapping->xpm_Header), &(pMapping->tile), &(pMapping->palette) );
			pMapping->yLoaded = 1;
		}
		else
			return -1;
	}
	else
	{
		get_tile_data( &(pMapping->tile), pMapping->strTileFile );
		get_palette_data( &(pMapping->palette), pMapping->strPaletteFile );
		get_map_data( &pMapping->map, pMapping->strMapFile );
		get_xpm_data( &(pMapping->xpm_TilePalette), &(pMapping->tile), &(pMapping->palette) );
		pMapping->yLoaded = 1;
	}

	return 0;
}

/* ########################################################################## */
/* For Map and Tiles windows */
int initGTKInterface(pgba_map pMapping)
{
	char* xpm_temp[19];
	int i, j;

	if(pMapping->yLoaded != 1)
		return -2;
	
	image=    (GtkWidget **) malloc( sizeof(GtkWidget*)*(pMapping->tile.count) );
	pixbuf1=  (GdkPixbuf **) malloc( sizeof(GdkPixbuf*)*(pMapping->tile.count) );
	
	map_tile= (GtkWidget **) malloc( sizeof(GtkWidget*) * pMapping->map.size );
	
	map_table=              gtk_table_new( pMapping->map.width, pMapping->map.width, FALSE );
	tiles_table=            gtk_table_new( 1, (pMapping->tile.size/pMapping->tile.area), FALSE );
	tiles_scrolled_window=  gtk_scrolled_window_new( NULL, NULL );
	map_scrolled_window=    gtk_scrolled_window_new( NULL, NULL );
	
	if(pMapping->yHeaderFormat == 1)
	{
		for ( i= 0; i<(pMapping->tile.count); i++ )
		{
			pxpm_elt pCurrent = (pxpm_elt)pMapping->xpm_Header.pElements[i];
			j=0;
			
			while(pCurrent != NULL)
			{
				xpm_temp[j]= pCurrent->strLine;
				pCurrent = (pxpm_elt)pCurrent->pNext;
				/*printf("Tile %d l%d : \"%s\"\n",i,j,xpm_temp[j]);*/
				j++;
			}
			pixbuf1[i]= gdk_pixbuf_new_from_xpm_data ( xpm_temp );
			
			pixbuf1[i]= gdk_pixbuf_scale_simple( pixbuf1[i], 32, 32, GDK_INTERP_NEAREST );
			image[i]= gtk_image_new_from_pixbuf(pixbuf1[i]);
			
			gtk_table_attach( GTK_TABLE (tiles_table), image[i], 0, 1, i, i+1, GTK_FILL, GTK_FILL, 1, 1 );
			gtk_widget_show (image[i]);
		}
	}	
	else
	{
		for ( i= 0; i<((pMapping->tile.size)/pMapping->tile.area); i++ )
		{
			/* Extract one XPM image from xpm_data */    
			for ( j= 0; j<(pMapping->palette.count + 1 + 8); j++)
			  xpm_temp[j]= pMapping->xpm_TilePalette.data[i*(pMapping->palette.count + 1 + 8) + j];
			
			pixbuf1[i]= gdk_pixbuf_new_from_xpm_data ( xpm_temp );
			
			/* Set zoom level (so the tiles are clearly visible) */
			pixbuf1[i]= gdk_pixbuf_scale_simple( pixbuf1[i], 32, 32, GDK_INTERP_NEAREST );
			/* Create the image from the pixmap */
			image[i]= gtk_image_new_from_pixbuf(pixbuf1[i]);
			
			gtk_table_attach( GTK_TABLE (tiles_table), image[i], 0, 1, i, i+1, GTK_FILL, GTK_FILL, 1, 1 );
			gtk_widget_show (image[i]);
		}
		destroy_xpm_data( &pMapping->xpm_TilePalette );
	}

  /* Done with the tiles and the palette now, it's all stored in the pixbuffer and map data structure
     Free up the malloc()'ed data.    */
  destroy_palette_data( &pMapping->palette );

  statusimage= gtk_image_new_from_pixbuf( pixbuf1[0] ); /* Default selection */
  gtk_box_pack_start( GTK_BOX(status_hbox), statusimage, FALSE, FALSE, 0 );
  gtk_widget_show( statusimage );

  gtk_box_pack_start( GTK_BOX(h_box), map_scrolled_window,   TRUE,  TRUE,  0 );
  gtk_box_pack_start( GTK_BOX(h_box), tiles_scrolled_window, FALSE, FALSE, 0 );
  gtk_widget_set_size_request (tiles_scrolled_window, 60, 0);

	/* The map images */
	for ( i= 0; i<pMapping->map.width; i++ )
	{
		for ( j= 0; j<pMapping->map.width; j++ )
		{
			/* Set the tile to represent the tile in the map data structure */
			if(pMapping->map.data[i*pMapping->map.width + j] >= ((pMapping->tile.size)/pMapping->tile.area))
			{
				printf("ERROR a map element point to an unexistant tile !!!!Nb tiles %d tile needed %d(at %dx%d)\n",((pMapping->tile.size)/pMapping->tile.area),pMapping->map.data[i*pMapping->map.width + j],i+1,j+1);
				/*exit(0);*/
				pMapping->map.data[i*pMapping->map.width + j] = 0;
			}
			map_tile[i*pMapping->map.width + j]= gtk_image_new_from_pixbuf(pixbuf1[pMapping->map.data[i*pMapping->map.width + j]]);
			
			gtk_table_attach( GTK_TABLE (map_table), map_tile[i*pMapping->map.width + j], j, j+1, i, i+1, GTK_FILL, GTK_FILL, 1, 1 );
			gtk_widget_show( map_tile[i*pMapping->map.width + j] );
		}
	}
	
  destroy_tile_data( &pMapping->tile );

  /* Create the drawing area */
  map_table_event_box= gtk_event_box_new ();

  gtk_scrolled_window_set_policy (GTK_SCROLLED_WINDOW (map_scrolled_window), GTK_POLICY_AUTOMATIC, GTK_POLICY_AUTOMATIC);
  gtk_scrolled_window_add_with_viewport (GTK_SCROLLED_WINDOW (map_scrolled_window), map_table_event_box);
  gtk_container_add( GTK_CONTAINER (map_table_event_box), map_table );

  g_signal_connect (G_OBJECT (map_table_event_box), "button_press_event", G_CALLBACK (map_button_press_event), NULL);
  gtk_widget_show (map_table_event_box);
  gtk_widget_show (map_table);
  gtk_widget_show (map_scrolled_window);

  /* Create the tiles selection window */
  tiles_table_event_box= gtk_event_box_new ();

  gtk_scrolled_window_set_policy (GTK_SCROLLED_WINDOW (tiles_scrolled_window), GTK_POLICY_AUTOMATIC, GTK_POLICY_AUTOMATIC);
  gtk_scrolled_window_add_with_viewport (GTK_SCROLLED_WINDOW (tiles_scrolled_window), tiles_table_event_box);
  gtk_container_add( GTK_CONTAINER (tiles_table_event_box), tiles_table );  /* Add the tiles table to the event box */

  g_signal_connect (G_OBJECT (tiles_table_event_box), "button_press_event", G_CALLBACK (tiles_button_press_event), NULL);
  gtk_widget_show (tiles_table_event_box);
  gtk_widget_show (tiles_table);
  gtk_widget_show (tiles_scrolled_window);

	return 0;
}

void destroyGTKInterface()
{
	
	if(tiles_table)				{	gtk_widget_destroy(tiles_table);			tiles_table = NULL;	}
	if(tiles_table_event_box)	{	gtk_widget_destroy(tiles_table_event_box);	tiles_table_event_box = NULL;	}
	if(tiles_scrolled_window)	{	gtk_widget_destroy(tiles_scrolled_window);	tiles_scrolled_window = NULL;	}

	if(map_table)				{	gtk_widget_destroy(map_table);				map_table = NULL;	}
	if(map_table_event_box)		{	gtk_widget_destroy(map_table_event_box);	map_table_event_box = NULL;	}
	if(map_scrolled_window)		{	gtk_widget_destroy(map_scrolled_window);	map_scrolled_window = NULL;	}

	if(statusimage)				{	gtk_widget_destroy(statusimage);			statusimage = NULL;	}
	/* Clean up */
	free( image );
	free( map_tile );
	free( pixbuf1 );
}
/* ########################################################################## */

int main( int argc, char *argv[] )
{
	gtk_init( &argc, &argv );
	
	initGbaMap(&MainMapping);
	
	if(argc == 4)
	{
		MainMapping.yHeaderFormat = 0;
		strncpy(MainMapping.strTileFile,argv[1],254);
		strncpy(MainMapping.strPaletteFile,argv[2],254);
		strncpy(MainMapping.strMapFile,argv[3],254);
		if(LoadDataFiles(&MainMapping) != 0)
		{
			printf("Error reading the files.\n");
			exit(0);
		}
	}		
	else if(argc == 3)
	{
		MainMapping.yHeaderFormat = 1;
		strncpy(MainMapping.strHeaderFile,argv[1],254);
		strncpy(MainMapping.strMapFile,argv[2],254);
		if(LoadDataFiles(&MainMapping) != 0)
		{
			printf("Error reading the files.\n");
			exit(0);
		}
	}
	else if (argc > 4)
	{
		printf("Far, far too many arguments!\n");
		exit(0);
	}

	window=   gtk_window_new (GTK_WINDOW_TOPLEVEL);

	h_box= gtk_hbox_new( FALSE, 0 );
	v_box= gtk_vbox_new( FALSE, 0 );
	
	menubar=                get_menubar_menu (window);
	statusfield=            gtk_entry_new( );
	
	gtk_entry_set_text( statusfield, "Current selection: " );
	gtk_editable_set_editable( statusfield, FALSE );
	status_hbox= gtk_hbox_new( FALSE, 0 );
	gtk_box_pack_start( GTK_BOX(status_hbox), statusfield, TRUE,  TRUE,  0 );
	gtk_widget_show( statusfield );
	gtk_widget_show( status_hbox );

	gtk_box_pack_start( GTK_BOX(v_box), menubar,       FALSE, FALSE, 0 );
	gtk_box_pack_start( GTK_BOX(v_box), h_box,         TRUE,  TRUE,  0 );
	gtk_box_pack_start( GTK_BOX(v_box), status_hbox,   FALSE, FALSE, 0 );
	gtk_widget_show( menubar );
	gtk_widget_show( v_box );
	gtk_container_add ( GTK_CONTAINER (window), v_box );
	gtk_widget_show( h_box );

	/* Event signals */
	g_signal_connect (G_OBJECT (window), "destroy", G_CALLBACK( gtk_main_quit ), NULL);
	
	/* Housekeeping */
	gtk_widget_set_name (window, "Test Input");
	gtk_widget_set_size_request (window, 800, 600);
	gtk_widget_show (window);
	

	initGTKInterface(&MainMapping);
	
	
	/* Enter main gtk loop */
	gtk_main ();
	
	UnloadDataFiles(&MainMapping);
	destroyGTKInterface();

  return 0;
}
