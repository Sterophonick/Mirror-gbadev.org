/*
 * gbamapedit
 *
 * Copyright (C) 2003, 2004 Stephen Strowes (sdstrowes@gmail.com)
 * Modified by Boin Francois, 2004/2005 to handle GIMP header file formats.
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 *
 */

#include <math.h>
#include "gba_data_io.h"

static int data_start_found= 0;
static int data_end_found  = 0;

/* ############################################################# */

int hex2int( char* hex ) {
  int i, temp, out= 0;

  for ( i= 0; hex[i] != '\0'; i++ ) {
    /* Get the integer the character represents */
    temp= hex[i] - '0';

    /* This line need to handle (A-F)|(a-f) */
    if ( temp>22 ) temp-= 39;
    else if ( temp>9 ) temp-= 7;

    /* Add onto existing total */
    out= out*16 + temp;
  }

  return out;
}

/* ############################################################# */

int dec2int( char* dec )
{
	int i, out= 0;

	for ( i= 0; dec[i] != '\0'; i++ )
	{
	/* Get the integer the character represents and add onto existing total */
		if(dec[i] != ' ')
			out= out*10 + dec[i] - '0';
	}
	return out;
}

/* ############################################################# */

int get_file_size( FILE* fp )
{
  int i;
  char ch[6];

  while ( (ch[0]= getc(fp)) != 'S' );
  /* Assume this is SIZE. Can't be bothered doing it properly just now :) */
  for ( i= 0; i<4; i++ ) getc(fp);

  /* Now get the value itself */
  i= -1;
  do {
    i++;
    ch[i]= getc(fp);
  } while ( (ch[i] != EOF) && (ch[i] != '\n') && (ch[i] != ' ') && (ch[i] != 13) ); /* 13 == CR */
  ch[i]= '\0';

  return( dec2int( ch ) );
}

/* ############################################################# */

void get_token( FILE *fp, char *c )
{
  int str_len= 0;
  char ch;

  /* Deal with boundaries first */
  while ( !data_start_found ) {
    if ( (ch= getc(fp)) == '{' )
      data_start_found= 1;
  }

  while ( (ch= getc(fp))!= EOF && !data_end_found ) {
    if ( data_start_found && ch == '}' ) {
      data_end_found= 1;
      break;
    }

    /* Here's the real data */
    else if ( (data_start_found && !data_end_found && ch == '0') ) {
      /* Gobble up the "0x" */
      ch= getc(fp); ch= getc(fp);

      c[0]= ch;
      /* We've found a token, scan up to comma, new line, space or '}' */
      do
	c[++str_len]= getc(fp);
      while ( c[str_len] != ',' &&  c[str_len] != '\n' &&  c[str_len] != ' ' &&  c[str_len] != '}' );
      
      c[str_len]= '\0';
      /* Break loop */
      break;
    }
    else c[0]= '\0';
  }
}

/* ############################################################# */

void write_new_file( map_data* map, char* strFileName )
{
	char str[256];
	char strFile[256];
	FILE *fp;
	int i,i2,iPos=0;
	
	strncpy(strFile,strFileName,255);
	if(strFile[0] == 0)
	{
		strcpy(strFile,"map.h");
	}

	if((fp = fopen( strFile, "w" )) == NULL)
		return;
	
	/* remove path */
	for( i= strlen(strFile); (i>=0) && (iPos==0); i--);
	{
		if(strFile[i] == '/')
		{
			for ( i2= i+1; i2<strlen(strFile) && strFile[i2] != '.'; i2++ );
			{
				str[iPos]= strFile[i2];
				iPos++;
			}
			str[iPos] = '\0';
		}
	}
	if (i<0)
	{/* Create array name as filename up to first '.'. This normally would be the filename minus ".h" extension. */
		strcpy( str, strFile );
		for ( i= 0; i<strlen(str) && str[i] != '.'; i++ );
		str[i]= '\0';
	}
  fprintf( fp, "#ifndef __%s_H_\n",       str );
  fprintf( fp, "#define __%s_H_\n\n\n",   str );
  fprintf( fp, "#define %sSIZE %d\n\n",   str, map->size );
  fprintf( fp, "const u8 %sMAP[] = {\n", str );
  
  /* Now out put map_width*map_width '0x00's */
  for ( i= 1; i<=map->size; i++ ) {
    if ( map->data[i-1] < 0x10 )
      fprintf( fp, "0x0%x, ", map->data[i-1] );
    else
      fprintf( fp, "0x%x, ", map->data[i-1] );

    if ( !(i % map->width) )
      fprintf( fp, "\n" );
  }
  
  fprintf( fp, "};\n" );
  fprintf( fp, "\n#endif\n" );

  free( str );
  fclose( fp );
}

/* ############################################################# */

void get_xpm_data( xpm_TPdata* xpm, tiles_data* dat, palette_data* palette )
{
	int i, j, k;
	char str[128];
	char str_temp[128];
	int temp;
	int num_tiles= (dat->size)/dat->area;
	
	xpm->data= (char **) malloc( sizeof(char*) * dat->count * (palette->count + 1 + 8) ); 
	xpm->size= dat->count * (palette->count + 1 + 8);
	
	for ( i= 0; i < num_tiles*(palette->count + 1 + 8); )
	{
		if ( DEBUG )
		  printf( "DEBUG: Processing tile number: %d.\n", i/(palette->count + 1 + 8) );
		
		sprintf( str, "8 8 %d 1", palette->count );
		xpm->data[i]= (char *) malloc( strlen(str)+1 );
		strcpy( xpm->data[i], str );
		i++;
		
		if ( DEBUG )
		  printf( "DEBUG: Added(%d): %s\n", i-1, xpm->data[i-1] );
		
		for ( j= 0; j<palette->count; j++ )
		{
			int temp_R= ( palette->data[j]&0x00001F );
			int temp_G= ( palette->data[j]&0x0003E0 );
			int temp_B= ( palette->data[j]&0x007C00 );
			int colour;
			int str_len;
			
			colour= RGB( temp_R, temp_G, temp_B );
			sprintf( str, "%x", colour );
			str_len= strlen( str );
			
			if ( str_len < 6 )
			{
				str[6]= '\0';
				for ( temp= str_len; temp>=0; temp-- )
				{
					str[6-(str_len-temp)]= str[temp];
				}
				
				for ( temp= 0; temp < 6-str_len; temp++ )
				{
					str[temp]= '0';
				}
			}
	 
			sprintf( str_temp, "%c c #%s", (j+'0'), str );
			xpm->data[i]= (char *) malloc( strlen(str_temp)+1 );
			strcpy( xpm->data[i], str_temp );
			
			if ( DEBUG )
				printf( "DEBUG: Added(%d): %s\n", i, xpm->data[i] );
			
			i++;
		}
	
		for ( j= 0; j<8; j++ )
		{
			strcpy( str, "\0" );
			for ( k= 0; k<8; k++ )
			{
				sprintf( str_temp, "%d", dat->data[(i/(palette->count + 1 + 8))*dat->area + (j*8)+k] );
				strcat( str, str_temp );
			}
		strcat( str, "\0");
		
		xpm->data[i]= (char *) malloc( strlen(str)+1 );
		strcpy( xpm->data[i], str );
		i++;
		
		if ( DEBUG )
			printf( "DEBUG: Added(%d): %s\n", i-1, xpm->data[i-1] );
		
		}
	}
}

void destroy_xpm_data( xpm_TPdata* xpm )
{
	int i;
	
	if(xpm->data == NULL)
		return;
	
	for ( i= 0; i<xpm->size; i++ )
		free( xpm->data[i] );
}

/* ## FB Modif START #################################### */

void get_Headerxpm_data( xpm_Hdata* xpm, tiles_data* dat, palette_data* palette )
{
	int i, j, k;
	char str[128];
	char str_temp[128];
	
	int iColourNeeded[255];
	int iNumColoursNeeded = 0;
	
	xpm->pElements = (unsigned long *) malloc( sizeof(unsigned long) * (dat->count) );
	
	for ( i= 0; i < (dat->count);i++ )
	{
		pxpm_elt pCurrent;
		xpm->pElements[i] = (unsigned long) malloc( sizeof(xpm_elt) );
		pCurrent = (pxpm_elt)xpm->pElements[i];
		
		if ( DEBUG )
		  printf( "DEBUG: Processing tile number: %d.\n", i );

		/* First of all we have to analyze and take the only colours we need */
		for ( j= 0; j<8; j++ )
		{
			for ( k= 0; k<8; k++ )
			{
				int iBcl = 0;
				for(iBcl=0;iBcl<iNumColoursNeeded;iBcl++)
				{
					if (iColourNeeded[iBcl] == (dat->data[(i*dat->area) + (j*8)+k]))
						break;
				}
				if(iBcl == iNumColoursNeeded)
				{
					iColourNeeded[iNumColoursNeeded] = dat->data[(i*dat->area) + (j*8)+k];
					if(DEBUG)
						printf("Adding new palette elt %d used %d\n",iColourNeeded[iNumColoursNeeded],iNumColoursNeeded);
					iNumColoursNeeded++;
				}
			}
		}
		if(DEBUG)
			printf("Found %d colors needed\n",iNumColoursNeeded);

		/* Values */
		sprintf( str, "8 8 %d 1", iNumColoursNeeded );
		strcpy( pCurrent->strLine, str );
		pCurrent->pNext = (unsigned long)malloc(sizeof(xpm_elt));
		pCurrent = (pxpm_elt)pCurrent->pNext;
		pCurrent->pNext = 0;
		
		/* Colours */
		for ( j= 0; j<iNumColoursNeeded; j++ )
		{
			int temp_R= ( palette->data[iColourNeeded[j]]&0x00001F );
			int temp_G= ( palette->data[iColourNeeded[j]]&0x0003E0 );
			int temp_B= ( palette->data[iColourNeeded[j]]&0x007C00 );
			int colour;
			int str_len;
			
			colour= RGB( temp_R, temp_G, temp_B );
			sprintf( str, "%06x", colour );
			str_len= strlen( str );

			sprintf( str_temp, "%c c #%s", (j+'0'), str );
			strcpy( pCurrent->strLine, str_temp );
			pCurrent->pNext = (unsigned long)malloc(sizeof(xpm_elt));
			pCurrent = (pxpm_elt)pCurrent->pNext;
			pCurrent->pNext = 0;
		}
	
		/* Pixels */
		for ( j= 0; j<8; j++ )
		{
			strcpy( str, "\0" );
			for ( k= 0; k<8; k++ )
			{
				int iBcl=0;
				for (iBcl = 0;iBcl<iNumColoursNeeded;iBcl++)
				{
					if(iColourNeeded[iBcl] == dat->data[(i*dat->area) + (j*8)+k])
					{
						sprintf( str_temp, "%d", iBcl );
						strcat( str, str_temp );
						break;
					}
				}
				if (iBcl == iNumColoursNeeded)
				{
					/* ERROR !! */
					int iBoucle;
					printf("Error in getting colour Map :\n");
					for(iBoucle=0;iBoucle<iNumColoursNeeded;iBoucle++)
						printf(" palette elt %d -> used as %d\n",iColourNeeded[iBoucle],iBoucle);
					printf("Map :\n");
					for ( j= 0; j<8; j++ )
					{
						for ( k= 0; k<8; k++ )
						{
							printf(" %d",dat->data[(i*dat->area) + (j*8)+k]);
						}
						printf("\n");
					}
					exit(0);
				}
			}
			strcat( str, "\0");
			
			strcpy( pCurrent->strLine, str );
			pCurrent->pNext = (unsigned long)malloc(sizeof(xpm_elt));
			pCurrent = (pxpm_elt)pCurrent->pNext;
			pCurrent->pNext = 0;
		}
		
		iNumColoursNeeded = 0;
	}
}

/* ## FB Modif END ###################################### */
/* WARNING ! YOU MUST NOT DESTROY THE num_tiles VALUE*/
void destroy_xpmHeader( xpm_Hdata* xpmH, tiles_data* dat)
{
	int i;
	
	if((xpmH->pElements == NULL) || (dat->data == NULL))
		return;
	
	for ( i= 0; i<(dat->count); i++ )
	{
		pxpm_elt pCurrent = (pxpm_elt)xpmH->pElements[i];
		while(pCurrent != 0)
		{
			pxpm_elt pNext = (pxpm_elt)pCurrent->pNext;
			free(pCurrent);
			pCurrent = pNext;
		}
	}
  
	free( xpmH->pElements );
}

/* ############################################################# */

int get_tile_data( tiles_data* tile, char* filename )
{
  int count= 0;
  char c[12];
  FILE* fp= fopen( filename, "r" );

  if ( fp == NULL ) {
    printf( "%s does not exist!!\n", filename );
    return -1;
  }

  tile->size= get_file_size( fp );
  tile->data= (int *) malloc( sizeof(int) * tile->size );

  /* Reset for the next file */
  data_start_found= 0;
  data_end_found= 0;

  get_token( fp, c );
  while ( !data_end_found ) {
    char temp[3];

    /* First 'half' of pixel */
    temp[0]= c[2];
    temp[1]= c[3];
    temp[2]= '\0';
    tile->data[count]= hex2int( temp );
    count++;

    /* Second half of pixel */
    temp[0]= c[0];
    temp[1]= c[1];
    temp[2]= '\0';
    tile->data[count]= hex2int( temp );
    count++;

    get_token( fp, c );
  }
  
  tile->area= 64;
  tile->count= tile->size / tile->area;

  fclose( fp );
  return 0;
}

/* ############################################################# */

void destroy_tile_data( tiles_data* tile )
{
	if(tile->data)
	{
		free( tile->data );
		tile->data = NULL;
	}
}
/* ############################################################# */

int get_palette_data( palette_data* palette, char* filename )
{
  int count= 0;
  char c[12];
  FILE* fp= fopen( filename, "r" );

  if ( fp == NULL ) {
    printf( "%s does not exist!!\n", filename );
    return -1;
  }

  /* Read input size from file */
  palette->size= get_file_size( fp );
  palette->data= (int *) malloc( sizeof(int) * palette->size );

  /* Reset for the next file */
  data_start_found= 0;
  data_end_found= 0;

  get_token( fp, c );
  while ( !data_end_found ) {
    
    palette->data[count]= hex2int( c );
    count++;

    get_token( fp, c );
  }
  
  /* Count the colours */
  for ( count= 1; ; count++ )
    if ( palette->data[count] == 0x0000 )
      break;
  palette->count= count;

  if ( DEBUG )
    printf( "DEBUG: Colour count: %d\n", palette->count );

  fclose( fp );
  return 0;
}

/* ############################################################# */

void destroy_palette_data( palette_data* palette )
{
	if(palette->data)
	{
		free( palette->data );
		palette->data = NULL;
	}
}

/* ############################################################# */

void get_map_data( map_data* map, char* filename )
{
  int count= 0;
  char c[12];
  FILE* fp= fopen( filename, "r" );

  if ( fp == NULL ) {
	  return;
   }
  else {

    /* Reset for the next file */
    data_start_found= 0;
    data_end_found= 0;
  
    map->size=  get_file_size( fp );
    map->width= (int)sqrt(map->size);
    map->data=  (int*)malloc( sizeof(int) * map->size );

    get_token( fp, c );
    
    while ( !data_end_found ) {
      map->data[count]= hex2int( c );
      count++;
      
      get_token( fp, c );
    }
  
    fclose( fp );
  }

}

/* ############################################################# */

void destroy_map_data( map_data* map )
{
	if(map->data)
	{
		free( map->data );
		map->data = NULL;
	}
}


/* ############################################################# */

/* ## FB ####################################################### */

/* Line by line reading ... */
/* new format made by Gimp (Header) */

int get_file_header( FILE* fp, int* pwidth , int* pheight )
{
	char chLine[255];
	char strTemp[255];
	
	/*the first line must be like "/ *  GIMP header image file format (INDEXED): ... */
	if(fgets(chLine,255,fp) == NULL)
	{
		printf("Read error bad format !!(Header)\n");
		return -2;
	}
	if(sscanf(chLine,"/*  GIMP header image file format (INDEXED): %s  */\n",strTemp)== 0)
	{
		if (DEBUG)
			printf("This is not a Header file\n");
		return -1;
	}
		
	do{
		if(fgets(chLine,255,fp) == NULL)
		{
			printf("Read error bad format !!(Header width reading)\n");
			return -1;
		}
	}while((sscanf(chLine,"static unsigned int width = %d;\n",pwidth)== 0) && (sscanf(chLine,"const static unsigned int width = %d;\n",pwidth)== 0));

	do{
		if(fgets(chLine,255,fp) == NULL)
		{
			printf("Read error bad format !!(Header height reading)\n");
			return -1;
		}
	}while((sscanf(chLine,"static unsigned int height = %d;\n",pheight)== 0) && (sscanf(chLine,"const static unsigned int height = %d;\n",pheight)== 0));
	
	return 0;
}

/* ## ####################################################### */

int get_PaletteLine( FILE *fp, int *psRed, int *psGreen, int *psBlue )
{
	char chLine[255];
	
	do{
		if(fgets(chLine,255,fp) == NULL)
		{
			printf("Read error bad format !!(Palette reading)\n");
			return -1;
		}
	}while (sscanf(chLine,"\t{%d,%d,%d},\n",psRed,psGreen,psBlue)== 0);
	
	return 0;
}

/* ## ####################################################### */

int get_HeaderFormat_data( tiles_data* tile, palette_data* palette, char* filename )
{
	int count= 0,w,h;
	char chLine[255];
	char c[12];
	
	FILE* fp= fopen( filename, "r" );
	
	if ( fp == NULL )
	{
		printf( "%s does not exist!!\n", filename );
		return -1;
	}
		
	if(get_file_header(fp,&w,&h) == 0)
		printf("Header (GIMP) File format found (%dx%d).\n",w,h);
	else
		return -1;
	
/* PALETTE *************************/
	do{
		if(fgets(chLine,255,fp) == NULL)
		{
			printf("Read error bad format !!(Palette size reading)\n");
			return -1;
		}
	}while((sscanf(chLine,"static char header_data_cmap[%d][3] = {\n",&(palette->size))== 0) && (sscanf(chLine,"const static char header_data_cmap[%d][3] = {\n",&(palette->size))== 0));

	if ( DEBUG )
		printf("Palette size : %d colours\n",palette->size);
	
	palette->data= (int *) malloc( sizeof(int) * palette->size );
	
	/*read the palette*/
	for(count = 0;count<palette->size;count++)
	{
		int sR,sG,sB;		
		get_PaletteLine( fp, &sR, &sG, &sB );
		palette->data[count]= ((sB/8)<<10) + ((sG/8)<<5) + (sR/8);
		if (DEBUG) printf("Palette Elt %d : R:%d G:%d B:%d -> 0x%X\n",count,sR,sG,sB,palette->data[count]);
	}
	
  /* Count the colours */
	for ( count= 1; ; count++ )
	{
		if(( palette->data[count] == 0x7FFF ) && (palette->data[count+1] == 0x7FFF ))
	  		break;
	}
	palette->count= count + 1;	/*warning we are keeping the last 'white' just in case .....*/
	
	
	if ( DEBUG )
		printf( "DEBUG: Colour count: %d\n", palette->count );
	

	/* Read the last line (should be '/t};\n'*/
	if(fgets(chLine,255,fp) == NULL)
	{
		printf("Read error bad format !!(Palette size reading)\n");
		return -1;
	}
	if(strcmp(chLine,"	};\n") != 0)
	{
		printf("Last palette Line( sould be '	};\\n' ) : %s\n",chLine);
		printf("Read error bad format !!(Palette size not good)\n");
		return -1;
	}

/* MAP DATAS *************************/
	count= 0;
	
	tile->size= w*h;
	tile->data= (int *) malloc( sizeof(int) * tile->size );
	
	/* Read Map datas from file */
	do{
		if(fgets(chLine,255,fp) == NULL)
		{
			printf("Read error bad format!!(Map reading)\n");
			return -1;
		}
	}while((strcmp(chLine,"static char header_data[] = {\n")!= 0) && (strcmp(chLine,"const static char header_data[] = {\n")!= 0));

	
	while(chLine[0] != '}')
	{
		if((chLine[0]=getc(fp)) == EOF)
		{
			printf("Read error bad format !!(Map Datas reading)\n");
			return -1;
		}
		
		if((chLine[0]<= '9') && (chLine[0]>= '0'))
		{
			short iElt = 0;
			do{
				c[iElt] = chLine[0];
				iElt++;
				if((chLine[0]=getc(fp)) == EOF)
				{
					printf("Read error bad format !!(Map Datas element reading)\n");
					return -1;
				}
			}while((chLine[0] != ',') && (chLine[0] != '\n'));
			c[iElt] = '\0';
			if(DEBUG)
				printf("The number %d -> %s\n",count,c);
			
			tile->data[count] = dec2int(c);
			count++;
		}			
	}

	if(count != (w*h))
	{
		printf("Read error bad format !!(Data map reading not good number of elements read)\n");
		return -1;
	}
		
	/* Read the last line (should be '/t};\n'*/
	if(fgets(chLine,255,fp) == NULL)
	{
		printf("Read error bad format !!(Data map reading)\n");
		return -1;
	}
	if(strcmp(chLine,";\n") != 0)
	{
		printf("Last MapData Line( sould be ';\\n' ) : %s\n",chLine);
		printf("WARNING ! Read problem !!(Data map not good)\n");
		return 0; /* dont return -1 it's just a warning but it could be dangerous */
	}
	if(DEBUG)
		printf("End Reading HEADER File OK\n");

	tile->area= 64;
	tile->count= tile->size / tile->area;
	
	fclose( fp );
	
	return 0;
}
