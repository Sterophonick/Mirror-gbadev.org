/*
 * gbamapedit
 *
 * Copyright (C) 2003, 2004 Stephen Strowes (sdstrowes@gmail.com)
 * Modified by Boin Francois, 2004/2005 to handle GIMP header file formats.
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 *
 */

#ifndef __MAPEDIT_H
#define __MAPEDIT_H

#include <stdlib.h>
#include <stdio.h>
#include <string.h>

#define RGB(r,g,b) (((r)<<19)+((g)<<6)+((b)>>7))

static const int DEBUG= 0;

typedef struct xpmElt {
	char strLine[255];
	unsigned long pNext;
}xpm_elt,*pxpm_elt;

typedef struct xpm_Hdata_s {
  unsigned long *pElements;
} xpm_Hdata;

typedef struct xpm_TPdata_s {
  char** data; /* The data held in XPM format...    */
  int size;    /* The size of the data structure.   */
} xpm_TPdata;


typedef struct map_data_s {
  int* data;   /* The actual data values themselves */
  int size;    /* The size of the data structure.   */
  int width;   /* Width (& height) of map           */
} map_data;

typedef struct tiles_data_s {
  int* data;   /* The actual data values themselves */
  int size;    /* The size of the data structure.   */
  int area;    /* The area in pixels of one tile.   */
  int count;   /* The number of tiles stored.       */
} tiles_data;

typedef struct palette_data_s {
  int* data;   /* The actual data values themselves           */
  int size;    /* The size of the data structure.             */
  int count;   /* The number of colours stored in the palette */
} palette_data;


typedef struct gba_map_s
{
	unsigned char	yLoaded;		/* 1 If loaded else not loaded */
	unsigned char	yHeaderFormat;	/*Is header or Tile/Palette format */
	/* COMMON */	
	char			strMapFile[255];
	map_data		map;
	palette_data	palette;
	tiles_data		tile;
	/* FOR HEADER */
	char			strHeaderFile[255];
	xpm_Hdata		xpm_Header;
	/* FOR TILE/PALETTE */
	char			strTileFile[255];
	char			strPaletteFile[255];
	xpm_TPdata		xpm_TilePalette;
	
}gba_map,*pgba_map;

static void initGbaMap(pgba_map pGBA)
{
	pGBA->yLoaded = 0;
	pGBA->strMapFile[0] = 0;	pGBA->map.data = NULL;	pGBA->map.size = 0;			pGBA->map.width = 0;
	pGBA->palette.data = NULL;	pGBA->palette.size = 0;	pGBA->palette.count = 0;
	pGBA->tile.data = NULL;		pGBA->tile.size = 0;	pGBA->tile.count = 0;		pGBA->tile.area = 0;
	pGBA->strHeaderFile[0] = 0;	pGBA->xpm_Header.pElements = NULL;
	pGBA->strTileFile[0] = 0;	pGBA->strPaletteFile[0] = 0;	pGBA->xpm_TilePalette.data = NULL;
}


/* Convert a string containing valid hexadecimal characters to an int */
int hex2int( char* );

/* Convert a string containing valid decimal characters to an int */
int dec2int( char* );

/* Retrieves the size of the data to be retrieved from fp. */
int get_file_size( FILE* );

/* Returns a data 'token' from the file fp in 'c' */
void get_token( FILE*, char* );

/* Outputs a new map file */
void write_new_file( map_data*, char*);

/* Output's data & palette into an array containing XPM format elements */
void get_xpm_data( xpm_TPdata*, tiles_data*, palette_data* );
void destroy_xpm_data( xpm_TPdata* );

/* Retrieve tile data from the file specified */
int get_tile_data( tiles_data*, char* );
void destroy_tile_data( tiles_data* );

/* Retrieve palette data from the file specified */
int get_palette_data( palette_data*, char* );
void destroy_palette_data( palette_data* );

/* Retrieve map data from the file specified */
void get_map_data( map_data*, char* );
void destroy_map_data( map_data* );

/**************************************************/
/* Added by FB for new Header(GIMP) format */
void destroy_xpmHeader( xpm_Hdata* xpmH, tiles_data* dat);
void get_Headerxpm_data( xpm_Hdata* xpm, tiles_data* dat, palette_data* palette );
int get_file_header( FILE* fp, int* pwidth , int* pheight );
void get_palettetoken( FILE *fp, char *c );
int get_HeaderFormat_data( tiles_data* tile, palette_data* palette, char* filename );


#endif
