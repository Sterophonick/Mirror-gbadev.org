//  Spriteric.h  ----------------------------------------------------------------// 

// (C) Copyright 2003 Linus Tan

//  Permission to copy, use, modify, sell and distribute this software
//  is granted provided this copyright notice appears in all copies.
//  This software is provided "as is" without express or implied
//  warranty, and with no claim as to its suitability for any purpose.

//  IMPORTANT: Note that UNLIKE the Spriteric application code, this 
//  header file is NOT covered under the GNU General Public License and
//  can therefore be safely incorporated into non-GPLed software.

//  If this file or any Spriteric generated file is used in an
//  application, the developer respectfully requests that the following
//  line be included in the credits section of the application:

//  [ Uses images exported by Spriteric v0.81a, developed by Linus Tan ]

//  Note this this is not mandatory, but would be greatly apprecated.

//----------------------------------------------------------------------------// 

#ifndef SPRITERIC_INCLUDED
#define SPRITERIC_INCLUDED

//----------------------------------------------------------------------------// 

typedef unsigned short SPRITERIC_BLOCK;
typedef unsigned short SPRITERIC_COLOR;
typedef unsigned short SPRITERIC_U16;
typedef unsigned short SPRITERIC_BOOL;

typedef struct 
{
	SPRITERIC_U16 nColors;
	const SPRITERIC_COLOR* pColors;
} SPRITERIC_PALETTE;

typedef struct
{
	SPRITERIC_U16 nFrames;
	const SPRITERIC_BLOCK* pFrames;
	SPRITERIC_U16 Shape;
	SPRITERIC_U16 Size;
} SPRITERIC_ANIMATION;

typedef struct
{
	SPRITERIC_U16 nAnimations;
	SPRITERIC_U16 palindex;
	const SPRITERIC_ANIMATION* pAnimations;
	SPRITERIC_BOOL Is256;
} SPRITERIC_SPRITE;

typedef struct
{
	SPRITERIC_U16 nSprites;
	const SPRITERIC_SPRITE* pSprites;
	SPRITERIC_U16 nPalettes;
	const SPRITERIC_PALETTE* pPalettes;
} SPRITERIC_ROOT;

#endif //SPRITERIC_INCLUDED
