---------+---------+---------+---------+---------+---------+---------+---------+
    Readme for Spriteric v0.81a
---------+---------+---------+---------+---------+---------+---------+---------+

    Spriteric is a tool that allows you to convert sprites into C code that can  
be compiled into most console game projects. It scans a user-specified 
directory for sprites, animations and palettes, and converts these into C arrays
wrapped a hierarchy of structures. 

    Spriteric is a command line tool, and is intended to be called from your
project's makefile. It generates three files, a C source file encapsulating the
converted data, a header file exposing the SPRITERIC_ROOT structure and another
containing the definitions for the spriteric structures.

---------+---------+---------+---------+---------+---------+---------+---------+
    How to use
---------+---------+---------+---------+---------+---------+---------+---------+

1. Prepare the directory containing your sprite animations in 8-bit or 4-bit 
   paletted bitmap format, as well as your palettes. See the TestSprites 
   directory for an example.

2. Run spriteric with your sprite directory and your desired output directory as
   arguments. e.g.

   spriteric ./YourSpriteDir -o=./TargetDir

3. The files YourSpriteDir.c and YourSpriteDir.h will be generated in TargetDir. 
   Simply add YourSpriteDir.c to your makefile and include YourSpriteDir.h 
   where you need to access the sprites.
   
---------+---------+---------+---------+---------+---------+---------+---------+
    Limitations
---------+---------+---------+---------+---------+---------+---------+---------+

Currently:
 - Only GBA format sprites can be exported.
 - Only .act (Adobe Color Table) format palettes are supported. 

Please lodge a feature request at http://www.sourceforge.net/projects/spriteric
or e-mail me directly if you'd like to see a particular console or format 
supported.

---------+---------+---------+---------+---------+---------+---------+---------+
    Contact
---------+---------+---------+---------+---------+---------+---------+---------+

    Please note that FontMapper is in a very early stage of development. You can 
help by sending me bug reports, suggestions and feature requests through 
Sourceforge (http://www.sourceforge.net/projects/spriteric) or via the e-mail
address below.

Linus Tan: 
    e-mail:     ltan AT epicentrix DOT net
    homepage:   www.epicentrix.net

---------+---------+---------+---------+---------+---------+---------+---------+
---------+---------+---------+---------+---------+---------+---------+---------+

Spriteric is Copyright (C) 2003 Linus Tan

Spriteric is distributed under the GNU General Public License (GPL)
Please see license.txt for details.

This software is OSI Certified Open Source Software.
OSI Certified is a certification mark of the Open Source Initiative.