//---------------------------------------------//
//  Oddworld by The_Letter_M                   //
//  Code borrowed from many                    //
//  www.gbadev.org sources                     //
//---------------------------------------------//

#include "gba.h"     // defines the GBA registers
#include "tile1.h" // contains all tile graphics
#include "sprite.h" // contains all sprite graphics
#include "disclaimer.h" // contains all disclaimer graphics

// instead of using RAW datafiles, I've stored all graphical data in an array.  It's easier
// to manipulate this way...  However, it has major downfalls when it comes to usage
// of DMA.  We'll see if I can figure this out, or I'll just have to write a tool to 
// convert these.
// Thanks again PCX2GBA.....


#define OAM     ((Sprite*)0x07000000)   // Setup pointer to OAM ram

typedef struct _Sprite { u16 Attrib0, Attrib1, Attrib2, RotateScale; } Sprite;

u8 letters[50] = {
11,11,11,11,11,11,11,11,11,11,11,11,11,11,11,11,11,11,0,0,0,1,2,3,4,5,6,7,1,8,9,2,11,11,11,11,11,11,11,11,11,11,11,11,11,11,11,11,11,11}; //www.gbadev.com

// VSYNC function by Eloist
void WaitForVSync()
{
  __asm
   {
    mov 	r0, #0x4000006
    scanline_wait:
     ldrh	r1, [r0]
     cmp	r1, #160
    bne 	scanline_wait
   }
}

void Draw_Abe(int x, int y, int frame, int direction)
{
  // abe is a 32x40 sprite drawn as 5 strips of 32x8
  // this is quite inefficient as if you look at the tiles, there is a huge number of 
  // blankies...  However, as it all fits (for now) there's no point going back over it.
  // 

  int tile;
  tile=(frame*20)+1;
  if (x < 0) x=x+512;

  OAM[0].Attrib0 = y | 0x2000 | 0x4000;  // 40 down, 32x8 sprite, 256 palette
  OAM[0].Attrib1 = x | 0x4000| (0x1000 * direction);   // 32x8 sprite
  OAM[0].Attrib2 = tile*2;

  OAM[1].Attrib0 = y+8 | 0x2000 | 0x4000;  // 40 down, 32x8 sprite, 256 palette
  OAM[1].Attrib1 = x | 0x4000| (0x1000 * direction);   // 32x8 sprite
  OAM[1].Attrib2 = (tile+4)*2;

  OAM[2].Attrib0 = y+16 | 0x2000 | 0x4000;  // 40 down, 32x8 sprite, 256 palette
  OAM[2].Attrib1 = x | 0x4000| (0x1000 * direction);   // 32x8 sprite
  OAM[2].Attrib2 = (tile+8)*2;

  OAM[3].Attrib0 = y+24 | 0x2000 | 0x4000;  // 40 down, 32x8 sprite, 256 palette
  OAM[3].Attrib1 = x | 0x4000 | (0x1000 * direction);   // 32x8 sprite
  OAM[3].Attrib2 = (tile+12)*2;

  OAM[4].Attrib0 = y+32 | 0x2000 | 0x4000;  // 40 down, 32x8 sprite, 256 palette
  OAM[4].Attrib1 = x | 0x4000 | (0x1000 * direction);   // 32x8 sprite
  OAM[4].Attrib2 = (tile+16)*2;

}



void Draw_Sign(int scroll)
{

  u8 i;

  for (i=0;i<20;i++) {

    OAM[5+i].Attrib0 = 13 | 0x2000;  // 40 down, 8x8 sprite, 256 palette
    OAM[5+i].Attrib1 = 40 + (8*i) - (scroll%8);   // 8x8 sprite
    OAM[5+i].Attrib2 = (381+letters[i+(scroll/8)])*2 | 0x0C00;   // sprite priority
  };

}


void disclaimer()
{

  // I've used tile mode, as I couldn't get bitmap mode to work..  Perhaps it was the tool
  // I was using.  I must try this again properly someday.  For now I just wanted to get
  // it out the door.

  int i, x, y, a;

  u16 *tpal=(u16*)0x05000000; // background palette pointer
  u8 *tiles=(u8*)0x06004000; // tiles pointer
  u16 *map0=(u16*)0x06000000; // tile map pointer


  REG_BG0CNT =  0x0084;      // tiles @ x6004000, map @ x6000000
  REG_DISPCNT = 0x1140;	     // mode 0, 32x32 tile map, display BG0 and sprites


  for (i=0;i<disclaimerpallen;i++) {
    tpal[i]=disclaimerpal[i];  // copy across backgroundpalette data
  }

  
  for (i=0;i<disclaimerdatalen;i++) {
    tiles[i]=disclaimerdata[i]; //load the bg tiles into the correct address
  }

  for (x=0;x<30;x++) {
    for (y=0;y<20;y++) {
      map0[y*32+x] = disclaimermap[y*30+x];
    }
  }


  
  a = 0;

  while (a==0) {
    
    
    if (!(REG_P1 & J_A))   
    {
      a=1;
      REG_P1 |= J_A;
    }


    WaitForVSync();

  };


  for (x=0;x<30;x++) {
    for (y=0;y<20;y++) {
      map0[y*32+x] = 0;
    }
  }


}

void C_Entry()
{



  u16 i,x,y;    
  int abex;      
  u8 abeframe;
  u8 stoptimer;
  u8 direction;
  u8 sign_scroll;
  int counter;
  

  u16 *tpal=(u16*)0x05000000; // background palette pointer
  u16 *spal=(u16*)0x5000200;  // sprite palette pointer
  u8 *tiles=(u8*)0x06004000; // tiles pointer
  u16 *map0=(u16*)0x06000000; // tile map pointer
  u8 *sprites=(u8*)0x06010000; // sprite tiles pointer


  disclaimer();
  

  REG_BG0CNT =  0x0084;      // tiles @ x6004000, map @ x6000000
  REG_DISPCNT = 0x1140;	     // mode 0, 32x32 tile map, display BG0 and sprites

  for (i=0;i<tile1pallen;i++) {
    tpal[i]=tile1pal[i];  // copy across backgroundpalette data
  }

  for (i=0;i<spritepallen;i++) {
    spal[i]=spritepal[i];  // copy across sprite palette data
  }
  
  for (i=0;i<tile1datalen;i++) {
    tiles[i]=tile1data[i]; //load the bg tiles into the correct address
  }


  for (i=0;i<spritedatalen;i++) {
    sprites[i]=spritedata[i]; //load the sprite tiles into the correct address
  }


  for (x=0;x<30;x++) {
    for (y=0;y<20;y++) {
      map0[y*32+x] = tile1map[y*30+x];
    }
  }


  abeframe = 0;
  stoptimer = 0;
  direction = 0;   // 0 = left, 1 = right...

  while (1) {

    i = 0;

    sign_scroll++;

    if (counter == 2) {
      counter=0;
    }
    else {
      counter++;
    };
    
    
    if (counter > 0) {

    if (!(REG_P1 & J_LEFT) & abex > 0)   
    {
      REG_P1 |= J_LEFT;
      i=1;    // this is the movement flag
      abex=abex-2;
      stoptimer = 0;
      if (abeframe == 0) abeframe = 4;
      direction = 0; //left
    };


    if (!(REG_P1 & J_RIGHT) & abex < 208)  
    {
      REG_P1 |= J_RIGHT;
      i=1;   // this is the movement flag
      abex=abex+2;
      stoptimer= 0;
      if (abeframe == 0) abeframe = 4;
      direction = 1; //right
    };




    if (i==1) {

      abeframe++;
      if (abeframe == 19) {
        abeframe = 4;
      }
    }
    else
    {
      if (stoptimer>2) {
        abeframe=0;
        stoptimer=0;
      }
      else {
        stoptimer++;
      };
    };

    };

    Draw_Abe(abex, 25, abeframe, direction);
    Draw_Sign(sign_scroll);

    WaitForVSync();



  }


   

}