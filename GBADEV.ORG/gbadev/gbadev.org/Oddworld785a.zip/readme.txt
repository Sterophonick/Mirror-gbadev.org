ODDWORLD ABE'S EXODDUS GRAPHICS TEST


This is my second GBA demo.

I was playing this brilliant game the other day and though that the GBA could do it, so I
decided to see how it would look.  As ODDWORLD are now affiliated with Microsoft, they
will probably not be doing any more GAME BOY Oddworld Products, but wouldn't it be amazing.

I'm really looking forward to Munch's Oddysee, it looks great!

All Graphics are Copyright Oddworld Inhabitants 1998.  I spent hours with a Screen Grabber
and cleaning these up by hand, they have not been extracted from the pak files.  Hence, the
slightly weird jumpy look on Abe's Head and Hands.  It took me forever to put all the frames in order as well.

It's been tested on the IGBA emulator.  I have no idea if it runs on real hardware.

Thanks to all source code contributors who I've borrowed lots of little pieces.  Thanks all.
Also thanks for the PCX2GBA program which was a HUGE help and also to AGENTQ for his
techincal documentation.  Even if it is a little out of date!

A game will be coming soon, I promise!


The_Letter_M
hallmb@yahoo.com