This Tetris for the GBA is a tribute to the excellent Commodore 64 version from Mirrorsoft in 1987.
Graphics are directly coming from this version. Unfortunately, the fantastic music from Wally Beben
in the original game can not be emulated with the SID player I use :O(
So the music you will listen is the one from the game "Dark Side" from Domark. It was also written
by Wally Beben and provides the same mood. And it is quite good as well !
If someone has a SID player which can emulate the original music or is ready to adapt it in a mod
format, feel free to contact me ! I would really like to integrate the original one.

It is my first GBA project. More will come :O)
This is version 1, I have lots of ideas in mind, but I want to release it now, so expect to see
new versions in the future (like a 2 players mode for example).
I put a lot of emphasis on the playability, I hope you'll enjoy it !
Anyway, feel free to send all your comments in order to enhance it.

At the intro screen, just press START to begin playing.
In game, you can move the falling shape with RIGHT and LEFT.
Using DOWN will accelerate the fall of the shape while pushing UP will make the shape go
directly to the bottom.
To turn the shapes, use A and B. A will turn counter clockwise while B will turn clockwise.
Pressing START during the game will pause, just press START again to resume.
When the game is over, just press A to come back to the intro screen.

I would like to thank Denis Bogatz for his excellent YASP SID player, dovoto for his fantastic
tutorials and all the people at gbadev.org.

michael.el-baki@laposte.net
My pseudo in the gbadev forum is bomberman.