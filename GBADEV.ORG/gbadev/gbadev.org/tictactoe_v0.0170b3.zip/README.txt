// Tic-Tac-Toe
// Michael Iedema
// iedemam@pluto.dsu.edu
// http://students.dsu.edu/iedemam/

Intro::

First HAM project.  I initially did a snake clone in assembly 
last semester as a final project for my Assembly class.  This
semester I took CPP2, and so I've ventured into a bit of C
coding.  As the changelog states, this took about 6 hours.
It works, but some of the code could definitely be cleaned up.

The source is included, and is heavily commented.  If anyone has
any comments on it, or spots some areas of complete stupidity 
please contact me.

I hope to eventually add some sound and some animation as I
learn some more.  I really enjoyed working on this, and thanks
to all of those out there working on the development tools for
this platform.


Instructions::

Two player tic-tac-toe....hit start and place your mark with A.
So far no AI, but .... coming soon.

