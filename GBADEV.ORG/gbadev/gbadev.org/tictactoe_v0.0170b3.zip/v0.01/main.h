// HAM library include
#include "mygba.h"

// palette includes
#include "gfx/sprites.pal.c"
#include "gfx/bg.pal.c"

// bg graphic include
#include "gfx/bg.raw.c"

// sprite includes
#include "gfx/blueblock.raw.c"
#include "gfx/redblock.raw.c"
#include "gfx/red.raw.c"
#include "gfx/red_outline.raw.c"
#include "gfx/blue.raw.c"
#include "gfx/blue_outline.raw.c"

// defines
#define X_DIFF          (35);
#define Y_DIFF          (35);

/* EOF */
