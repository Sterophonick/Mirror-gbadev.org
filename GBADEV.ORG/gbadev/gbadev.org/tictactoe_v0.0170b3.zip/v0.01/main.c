/*
 *  tictactoe - w/GFX
 *  Michael Iedmema (iedemam@pluto.dsu.edu)
 *
 *  an attempt at tic-tac-toe to utilize sprites, and some animation
 *  v0.01
 */

// main include
#include "main.h"

// function prototypes
void introSetup();          // prints the flashing start, version & game info
void gameSetup();           // sets up the graphics for gameplay and resets arrays
void playGame();            // the actual gameplay
void endGame();             // endgame message displaying appropriate winner, and restart

// globals
u16 sprites[20];            // array to hold sprites
u16 player = 1;             // current player
u16 occupied[10];           // layout of board holding occupation
u16 cursorPos;              // sprite cursor position (1-9)
u16 cursorX;                // x coordinate of cursor
u16 cursorY;                // y coordinate of cursor
u16 winner = 0;             // the winner

//********************************************************************
// main
//********************************************************************
int main(void)
{
    ham_Init();
    introSetup();
    while(1)
    {
        gameSetup();
        playGame();
        endGame();
    }
    return 0;
}


//********************************************************************
// introSetup
//   draws intro screen and flashing start message
//********************************************************************
void introSetup()
{
    // delay used in flahing start sign
    u16 delay = 20000;
    u16 tmpDelay = delay;

    // set background mode to 0 for text support
    ham_SetBgMode(0);

    // initialize text
    ham_InitText(0);
    
    // draw appropriate text
    ham_DrawText(0,7," player1              player2 ");
    ham_DrawText(0,8,"   red                  blue  ");
    ham_DrawText(0,17,"Tic-Tac-Toe");
    ham_DrawText(0,18,"v0.01");
    ham_DrawText(0,19,"Michael Iedema");

    // if the start button has not been pressed yet we flash the "press start" message
    while(!F_CTRLINPUT_START_PRESSED)
    {
        ham_DrawText(0,10,"          press start         ");
        while(tmpDelay>0)tmpDelay--;
        ham_DrawText(0,10,"                              ");
        tmpDelay = delay;
        while(tmpDelay>0)tmpDelay-=3;
        tmpDelay = delay;
    }
}

//********************************************************************
// gameSetup
//   loads graphics, clears arrays, resets gamestate
//********************************************************************
void gameSetup()
{
    u16 x = 0;

    ham_SetBgMode(4);

    // load up our background palette
    ham_LoadBGPal(&bg_Palette,SIZEOF_16BIT(bg_Palette));

    // load object palettes after they are combined via gfx2gba
    ham_LoadObjPal(&sprites_Palette,256);

    // transfer our background image
    TOOL_DMA1_SET(&bg_Bitmap, MEM_BG_PTR, SIZEOF_32BIT(bg_Bitmap),
                            DMA_TRANSFER_32BIT, DMA_STARTAT_NOW)

    // setup the red & blue block sprites
    sprites[0] = ham_CreateObj(&redblock_Bitmap,2,3,
                    OBJ_MODE_NORMAL,1,0,0,0,0,0,0,16,49);
    sprites[1] = ham_CreateObj(&blueblock_Bitmap,2,3,
                    OBJ_MODE_NORMAL,1,0,0,0,0,0,0,194,49);

    // setup red & blue outlines
    sprites[2] = ham_CreateObj(&red_outline_Bitmap,0,2,
                    OBJ_MODE_NORMAL,1,0,0,0,0,0,0,69,65);
    sprites[3] = ham_CreateObj(&blue_outline_Bitmap,0,2,
                    OBJ_MODE_NORMAL,1,0,0,0,0,0,0,139,65);
                    
    // setup red & blue fills offscreen for cloning later
    sprites[4] = ham_CreateObj(&red_Bitmap,0,2,
                    OBJ_MODE_NORMAL,1,0,0,0,0,0,0,240,160);
    sprites[5] = ham_CreateObj(&blue_Bitmap,0,2,
                    OBJ_MODE_NORMAL,1,0,0,0,0,0,0,240,160);

    // set everything invisible
    for(x=0;x<=6;x++)ham_SetObjVisible(x,0);
    
    // clear occupied array
    for(x=0; x<=9; x++)occupied[x]=0;

    // update hardware
    ham_CopyObjToOAM();
}


//********************************************************************
// playGame
//   the actual gameplay, dpad query and reaction
//********************************************************************
void playGame()
{
    // setup delay for endgame transfer
    int delay = 2500000;
    int tmpDelay = delay;

    // setup colored cursor outline for current player to center position
    ham_SetObjXY(player+1,104,65);

    // make visible the 1st player's "turn" block, and cursor outline
    ham_SetObjVisible(player+1,1);
    ham_SetObjVisible(player-1,1);

    // make center blocks ( "pieces" ) visible for cloning.
    ham_SetObjVisible(4,1);
    ham_SetObjVisible(5,1);

    // set cursor position to center, and also x,y coordinates
    cursorPos = 5;
    cursorX = 104;
    cursorY = 65;

    // update hardware display
    ham_CopyObjToOAM();

    while(1)
    {
        if(F_CTRLINPUT_UP_PRESSED)
        {
            // if we're not in the top row, we adjust cursor position
            if(cursorPos>3)
            {
                cursorY-=Y_DIFF;
                ham_SetObjY(player+1,cursorY);
                cursorPos-=3;
                ham_CopyObjToOAM();
            }
            // don't break out until button is released
            while(F_CTRLINPUT_UP_PRESSED);
        }

        if(F_CTRLINPUT_DOWN_PRESSED)
        {
            // if we're not in the bottom row, we adjust cursor position
            if(cursorPos<7)
            {
                cursorY+=Y_DIFF;
                ham_SetObjY(player+1,cursorY);
                cursorPos+=3;
                ham_CopyObjToOAM();
            }
            // don't break out until button is released
            while(F_CTRLINPUT_DOWN_PRESSED);
        }
        if(F_CTRLINPUT_RIGHT_PRESSED)
        {
            // if we're not on the right edge, we adjust cursor position
            if(cursorPos!=3 && cursorPos!=6 && cursorPos!=9)
            {
                cursorX+=X_DIFF;
                ham_SetObjX(player+1,cursorX);
                cursorPos++;
                ham_CopyObjToOAM();
            }
            // don't break out until button is released
            while(F_CTRLINPUT_RIGHT_PRESSED);
        }
        if(F_CTRLINPUT_LEFT_PRESSED)
        {
            // if we're not on the left edge, we adjust cursor position
            if(cursorPos!=1 && cursorPos!=4 && cursorPos!=7)
            {
                cursorX-=X_DIFF;
                ham_SetObjX(player+1,cursorX);
                cursorPos--;
                ham_CopyObjToOAM();
            }
            // don't break out until button is released
            while(F_CTRLINPUT_LEFT_PRESSED);
        }
        if(F_CTRLINPUT_A_PRESSED)
        {
            if(occupied[cursorPos] == 0)
            {
                // if unoccupied we clone offscreen center block to cursor position
                ham_CloneObj(player+3,cursorX,cursorY);

                // update our display
                ham_CopyObjToOAM();

                // now set the appropriate position in occupied array to player num.
                occupied[cursorPos]=player;

                // if any of the possible win scenarios are met we break to endgame
                if( (occupied[1] == player && occupied[2] == player && occupied[3] == player) ||
                    (occupied[4] == player && occupied[5] == player && occupied[6] == player) ||
                    (occupied[7] == player && occupied[8] == player && occupied[9] == player) ||
                    (occupied[1] == player && occupied[4] == player && occupied[7] == player) ||
                    (occupied[2] == player && occupied[5] == player && occupied[8] == player) ||
                    (occupied[3] == player && occupied[6] == player && occupied[9] == player) ||
                    (occupied[1] == player && occupied[5] == player && occupied[9] == player) ||
                    (occupied[3] == player && occupied[5] == player && occupied[7] == player)  )
                {
                    while(tmpDelay>0)tmpDelay--;
                    tmpDelay = delay;
                    winner = player;
                    break;
                }

                // now we check if the board is full with no win (cat)
                else if( occupied[1]!=0 && occupied[2]!=0 && occupied[3]!=0 &&
                         occupied[4]!=0 && occupied[5]!=0 && occupied[6]!=0 &&
                         occupied[7]!=0 && occupied[8]!=0 && occupied[9]!=0 )
                {
                    while(tmpDelay>0)tmpDelay--;
                    winner = 0;
                    tmpDelay = delay;
                    break;
                }

                // reset cursor outline to middle
                ham_SetObjXY(player+1,104,65);

                // set "turn" block, and player cursor invisible
                ham_SetObjVisible(player+1,0);
                ham_SetObjVisible(player-1,0);

                // reset cursor and x-y coordinates to center
                cursorPos = 5;
                cursorX = 104;
                cursorY = 65;

                // change player accordingly
                if(player==1)player=2;
                else player = 1;

                // reset cursor to middle for new player
                ham_SetObjXY(player+1,104,65);

                // set "turn" block, and player cursor visible for new player
                ham_SetObjVisible(player+1,1);
                ham_SetObjVisible(player-1,1);
                cursorPos = 5;
                cursorX = 104;
                cursorY = 65;

                // update display
                ham_CopyObjToOAM();
            }
            // don't break out until button is released
            while(F_CTRLINPUT_A_PRESSED);
        }
    }
}


//********************************************************************
// endGame
//   displays winning information, asks for restart
//********************************************************************
void endGame()
{
    u16 x;

    // delete all those object we've created
    for(x=0; x<=20; x++)ham_DeleteObj(x);

    // update our display
    ham_CopyObjToOAM();

    // set background mode to 0 to support text
    ham_SetBgMode(0);

    // initialize text again
    ham_InitText(0);

    // draw appropriate text for winner
    if(winner == 1)ham_DrawText(4,9,"the red knight wins");
    else if(winner == 2)ham_DrawText(4,9,"the blue knight wins");
    else if(winner == 0)ham_DrawText(4,9,"the cat has won again");
    ham_DrawText(3,11,"press start to restart");

    // don't break out until button is released
    while(!F_CTRLINPUT_START_PRESSED);
}

/* EOF */
