I've been working on this game for some time now...

Wanted to try and get it released but I never figured out how to do that...

SO, I'm giving it away for free right now. Please e-mail me with any questions or 
comments. 

I've found it to work best on a real cart, but it seems to be OK on Boycott Advance.

I'm not releasing the source code; it's very messy right now. 
I have written this in C on the gcc compiler, I plan to rewrite it in c++,
now that I am more familiar with it.

Still to come:

MORE Gadgets!
Variants on the modes of play
Animations & SFX
Music
More informative You Win Screen...
More informative You Player Select...
More intuitive Gadget Select Select...
Tutorials
Multi-Player (I've got parts of this worked out...)

For instructions as to how to play, check the .pdf file in this .zip!

Thanks for checking it out!
John Copic
stridor@hotmail.com