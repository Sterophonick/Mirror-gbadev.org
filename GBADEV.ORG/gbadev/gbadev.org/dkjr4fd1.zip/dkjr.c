/////////////////////////////////////////////////////////////////////////////
//
// Created by using Visual HAM
//
/////////////////////////////////////////////////////////////////////////////


/////////////////////////////////////////////////////////////////////////////
// I N C L U D E S

#include "mygba.h"


/////////////////////////////////////////////////////////////////////////////
// The GBA ROM you build will automatically be capable of running 
// both from FLA carts and in addition directly over the MBV2 cable. 
// If you do not need this, simply comment "MULTIBOOT" out.

MULTIBOOT


/////////////////////////////////////////////////////////////////////////////
// G L O B A L   V A R I A B L E S

bool g_bNewFrame=FALSE;
int  g_iActFrame=0; 


/////////////////////////////////////////////////////////////////////////////
// P R O T O T Y P E S

void  AgbMain        (void);
void  VblFunc        (void);




/////////////////////////////////////////////////////////////////////////////
// Program entry point

void AgbMain(void)
{
   // Initialize HAMlib
   ham_Init();

   // Set the Background to Mode 4
   ham_SetBgMode(4);

   // Start the so-called VBL handler
   ham_StartIntHandler(INT_TYPE_VBL,&VblFunc);

   // Loop  
   while(1)
   {
      if(g_bNewFrame)
      {
         // add more stuff here
         
         // Show this frame as processed
         // Will be set to TRUE in VBLhandler (VblFunc) again
         g_bNewFrame=FALSE;
      }
   }    
}

/////////////////////////////////////////////////////////////////////////////
// This function is called whenever the GBA is about 
// to draw a new picture onto the screen.

void VblFunc(void)
{
   // add more stuff here
   
   // Increase act frame
   g_iActFrame++;
   
   // Signify new frame
   g_bNewFrame=TRUE;
}


/* +++ EOF +++ */
