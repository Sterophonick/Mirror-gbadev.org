#include "mygba.h"

#include "gfx/palette2_raw.c";
#include "gfx/combinedgfx.c";
#define MODE_0 0x0
#define MODE_1 0x1
#define MODE_2 0x2
#define MODE_3 0x3
#define MODE_4 0x4
#define MODE_5 0x5

#define BACKBUFFER 0x10
#define H_BLANK_OAM 0x20

#define OBJ_MAP_2D 0x0
#define OBJ_MAP_1D 0x40

#define FORCE_BLANK 0x80

#define BG0_ENABLE 0x100
#define BG1_ENABLE 0x200 
#define BG2_ENABLE 0x400
#define BG3_ENABLE 0x800
#define OBJ_ENABLE 0x1000 
#define WIN1_ENABLE 0x2000 
#define WIN2_ENABLE 0x4000
#define WINOBJ_ENABLE 0x8000


#define SetMode(mode) REG_DISPCNT = (mode) 
u16* videoBuffer = (u16*)0x6000000;
u16* paletteMem = (u16*)0x5000000;
void PlotPixel(int x,int y, unsigned short int c) {videoBuffer[(y) *120 + (x)] = (c);}

//MULTIBOOT

//Global variables


u32   loopval=0;
u8 newframe=0;
u8 frames=0;
u16 my_x=36;
u16 my_y=87;
u8 dkjrpos=1;
u8 moved=0;
u16   jumpingaround=0;
u16   hangingaround=0;
u8 keyanimframe=0; u8 keyanimwait=25;
u8 jailpoint=0; u8 jailwait=50; u8 jailflash=0;
u8 plumshow=1; u32 plumwaitloop=0;
 
    sample_info *mysample[2];
	u8 mysprite[1];
   u8 jailsprite[3];
   u8 smilesprite[0];
   u8 keysprite[3];
   u8 plumsprite[0];
   u8 bellsprite[0];
   u8 mariosprite[0];
   u8 handsprite[0];
   u8 crocsprite[2];
//   u16 sound[1];


// Set the master mixer frequency (maximum bitrate)
// Note that not all values guarantee clickless playback
// please choose from one of these values:
// 5733  Hz   6689 Hz  10512 Hz   11467 Hz
// 13379 Hz  18157 Hz  20068 Hz   21024 Hz
// 26757 Hz  31536 Hz  36314 Hz   40136 Hz
// 42048 Hz  54471 Hz
#define MIXER_FREQ 13379 
extern const WaveData _binary_dkjrmove_raw_start;


int main()
{

   initialise(); 
   
    while(1) //Main game loop
    {
   
		if(newframe)
		{
          ham_UpdateMixer();  //do sound stuff
            ham_SetObjXY(mysprite[0],my_x,my_y);
               ham_CopyObjToOAM(); //update sprites
            
               jailstuff(); //make cage flash and donkey kong smile
               plumstuff(); //drop plum if hit by dkjr
               keymove(); //swing key
  
               check_gotkey(); //if got key, do key to cage anim
               check_hangingaround(); //check if on vine and drop if required
               check_jumpingaround(); //check if in air and drop if required
               keyboard_routine(); //check key input and update dkjr sprite 



    			newframe=0;
		}

    }    
}


//Functions
void hblFunc()
{
   ham_SyncMixer();
	//signify new frame
	newframe=1;
	frames++;
}


void jailstuff()
{
               //jail cage flash routine
             if (jailwait>0) { 
               jailwait--; 
             } else {
               jailwait=50;
               if (jailflash==0) { jailflash=1; } else { jailflash=0; }
               if (jailpoint==0) { 
                  ham_SetObjVisible(smilesprite[0],0);
                  ham_SetObjVisible(jailsprite[1],1);
                  ham_SetObjVisible(jailsprite[0],1);
                  ham_SetObjVisible(jailsprite[2],1);
                  ham_SetObjVisible(jailsprite[3],1);
               }
               if (jailpoint>0) { ham_SetObjVisible(jailsprite[1],jailflash); }
               if (jailpoint>1) { ham_SetObjVisible(jailsprite[0],jailflash); }
               if (jailpoint>2) { ham_SetObjVisible(jailsprite[2],jailflash); }
               if (jailpoint>3) { ham_SetObjVisible(jailsprite[3],jailflash); }
               if (jailpoint==4) { 
                  ham_SetObjVisible(smilesprite[0],jailflash);
                  ham_SetObjVisible(jailsprite[1],0);
                  ham_SetObjVisible(jailsprite[0],0);
                  ham_SetObjVisible(jailsprite[2],0);
                  ham_SetObjVisible(jailsprite[3],0);
               }
              
             }
}


void plumstuff()
{
         //Plum check routine
            if (dkjrpos==17 && plumshow==1) {

               plumwaitloop=3000;     
               while (plumwaitloop!=0) { 
               ham_UpdateMixer(); 
                  plumwaitloop--; }       
           
               ham_UpdateObjGfx(plumsprite[0],(void*)&SPECIALS_DAT[32*(32*17)]);
               ham_SetObjXY(plumsprite[0],126,68); 
               ham_CopyObjToOAM();
                if(!mysample[0]->playing) ham_PlaySample(mysample[0]);
               plumwaitloop=3000;     
               while (plumwaitloop!=0) { 
               ham_UpdateMixer();
               plumwaitloop--; }       
             
               ham_UpdateObjGfx(plumsprite[0],(void*)&SPECIALS_DAT[32*(32*18)]);
               ham_SetObjXY(plumsprite[0],126,100); 
               ham_CopyObjToOAM();
               plumwaitloop=3000;
                if(!mysample[0]->playing) ham_PlaySample(mysample[0]);     
               while (plumwaitloop!=0) { 
               ham_UpdateMixer();
               plumwaitloop--; }       
                    
               ham_UpdateObjGfx(plumsprite[0],(void*)&SPECIALS_DAT[32*(32*19)]);
               ham_SetObjXY(plumsprite[0],126,132); 
               ham_CopyObjToOAM();
               plumwaitloop=3000;
                if(!mysample[0]->playing) ham_PlaySample(mysample[0]);     
               while (plumwaitloop!=0) { 
               ham_UpdateMixer();
               plumwaitloop--; }       

                plumshow=0;
                ham_SetObjVisible(plumsprite[0],0);
            }

}

void keymove()
{
         //key move routine
            if (keyanimwait>0) { keyanimwait--; } else {
               //Wait frame over
               keyanimwait=25; //reset wait counter
               keyanimframe++; if (keyanimframe==6) { keyanimframe=0; }
               if (keyanimframe==0) { 
                  //Display key pos 1
                  ham_SetObjXY(keysprite[0],74,6);
               	ham_UpdateObjGfx(keysprite[0],(void*)&SPECIALS_DAT[32*(32*7)]);
               }
               if (keyanimframe==1 || keyanimframe==5) {
                  //Display key pos 2
                  ham_SetObjXY(keysprite[0],84,6);
               	ham_UpdateObjGfx(keysprite[0],(void*)&SPECIALS_DAT[32*(32*8)]);
               }
               if (keyanimframe==2 || keyanimframe==4) {
                  //Display key pos 3
                  ham_SetObjXY(keysprite[0],88,2);
               	ham_UpdateObjGfx(keysprite[0],(void*)&SPECIALS_DAT[32*(32*9)]);
               }
               if (keyanimframe==3) { 
                  //Display key pos 4
                  keyanimwait=50; //double wait on last frame of swing
                  ham_SetObjXY(keysprite[0],94,0);
               	ham_UpdateObjGfx(keysprite[0],(void*)&SPECIALS_DAT[32*(32*10)]);
               }
                               
            }

}

void initialise()
{
    // initialize HAMlib
    ham_Init();
    // set the new BGMode
 
     SetMode(MODE_3 | BG2_ENABLE | OBJ_ENABLE | OBJ_MAP_1D); 
      int x,y,loop;
        for(x = 0; x < 240; x++) //no loop through all x and y
        {
                for(y = 0; y < 320; y++)
                {
                        PlotPixel(x, y, (BACKDROP_32_DAT[y*120+x])); //testData contains the color values of your pict
                }
        }

  
 // init the Palettes for Sprite and BG Text
	ham_LoadBGPal(&BGPALETTE_DAT,sizeof(BGPALETTE_DAT));
	ham_LoadObjPal(&PALETTE_DAT,sizeof(PALETTE_DAT));
 
    // start hblFunc every frame
    ham_StartIntHandler(INT_TYPE_VBL,&hblFunc);


 	mysample[0] =  ham_InitSample((u8*)_binary_dkjrmove_raw_start.data,
               _binary_dkjrmove_raw_start.size,
               _binary_dkjrmove_raw_start.freq>>10);  
 ham_InitMixer(MIXER_FREQ);           
	mysprite[0] = ham_CreateObj((void*)&DKJRANIM_DAT[0],0,3,OBJ_MODE_NORMAL,1,0,0,0,0,0,0,0,0);
		
   jailsprite[0] = ham_CreateObj((void*)&SPECIALS_DAT[32*(32*0)],0,2,OBJ_MODE_NORMAL,1,0,0,0,0,0,0,5,5);
	jailsprite[1] = ham_CreateObj((void*)&SPECIALS_DAT[32*(32*1)],0,2,OBJ_MODE_NORMAL,1,0,0,0,0,0,0,27,5);
	jailsprite[2] = ham_CreateObj((void*)&SPECIALS_DAT[32*(32*2)],0,2,OBJ_MODE_NORMAL,1,0,0,0,0,0,0,5,18);
	jailsprite[3] = ham_CreateObj((void*)&SPECIALS_DAT[32*(32*3)],0,2,OBJ_MODE_NORMAL,1,0,0,0,0,0,0,27,18);
   smilesprite[0] = ham_CreateObj((void*)&SPECIALS_DAT[32*(32*4)],0,2,OBJ_MODE_NORMAL,1,0,0,0,0,0,0,18,18);
   ham_SetObjVisible(smilesprite[0],0);
   handsprite[0] = ham_CreateObj((void*)&SPECIALS_DAT[32*(32*6)],0,2,OBJ_MODE_NORMAL,1,0,0,0,0,0,0,75,20);
   ham_SetObjVisible(handsprite[0],0);
   
   keysprite[0] = ham_CreateObj((void*)&SPECIALS_DAT[32*(32*7)],0,2,OBJ_MODE_NORMAL,1,0,0,0,0,0,0,74,6);
   plumsprite[0] = ham_CreateObj((void*)&SPECIALS_DAT[32*(32*16)],0,2,OBJ_MODE_NORMAL,1,0,0,0,0,0,0,126,36);        
   bellsprite[0] = ham_CreateObj((void*)&SPECIALS_DAT[32*(32*15)],0,2,OBJ_MODE_NORMAL,1,0,0,0,0,0,0,28,42);        
   mariosprite[0] = ham_CreateObj((void*)&SPECIALS_DAT[32*(32*12)],0,2,OBJ_MODE_NORMAL,1,0,0,0,0,0,0,8,51);        

   crocsprite[0] = ham_CreateObj((void*)&BADDIES_DAT[32*(32*0)],0,2,OBJ_MODE_NORMAL,1,0,0,0,0,0,0,64,82);        
   crocsprite[1] = ham_CreateObj((void*)&BADDIES_DAT[32*(32*1)],0,2,OBJ_MODE_NORMAL,1,0,0,0,0,0,0,86,84);        
     
}

void check_gotkey()
{
         //check to see if monkey has collected key
         if (dkjrpos==20 && keyanimframe==0) {
            //Got Key!!
               plumwaitloop=250000;     //wait a while
               while (plumwaitloop!=0) { 
                  if (newframe) {
                   jailstuff();
                   ham_UpdateMixer(); 
                   ham_CopyObjToOAM(); 
                   newframe=0;
                  }
                  plumwaitloop--; 
               }   
          
            dkjrpos=21;
              my_x=57; my_y=19;
               	ham_UpdateObjGfx(0,(void*)&DKJRANIM_DAT[64*(64*20)]);
                  ham_SetObjXY(mysprite[0],my_x,my_y);
                  ham_SetObjVisible(keysprite[0],0); // remove key sprite
                  ham_SetObjVisible(handsprite[0],1); //show hand srpite pos 1
                  ham_SetObjXY(handsprite[0],65,4); //show hand sprite pos 2
               	ham_UpdateObjGfx(handsprite[0],(void*)&SPECIALS_DAT[32*(32*6)]);
                  ham_CopyObjToOAM(); //update srpites
               plumwaitloop=500000;     //wait a while
               while (plumwaitloop!=0) { 
                  if (newframe) {
                   jailstuff();
                   ham_UpdateMixer(); 
                   ham_CopyObjToOAM(); 
                   newframe=0;
                  }
                  plumwaitloop--; 
               }      
                 jailpoint++;
                  ham_SetObjXY(handsprite[0],47,5); //show hand sprite pos 2
               	ham_UpdateObjGfx(handsprite[0],(void*)&SPECIALS_DAT[32*(32*5)]);
                  ham_CopyObjToOAM(); //update srpites
                 plumwaitloop=750000;     //wait a while
               while (plumwaitloop!=0) { 
                  if (newframe) {
                   jailstuff();
                   ham_UpdateMixer(); 
                   ham_CopyObjToOAM(); 
                   newframe=0;
                  }
                  plumwaitloop--; 
               }  

               if (jailpoint==4) {
                  plumwaitloop=3000000;     //wait a while
                  while (plumwaitloop!=0) { 
                     if (newframe) {
                        jailstuff();
                        ham_UpdateMixer(); 
                        ham_CopyObjToOAM(); 
                        newframe=0; //see donkey kong smile!
                       } 
                    plumwaitloop--;
                  }      
                  jailpoint=0;
               }

               ham_SetObjVisible(handsprite[0],0); //hide hand sprite
               ham_CopyObjToOAM(); //update srpites

         }
}

void check_hangingaround()
{
            //Special - if hanging around then fall
                         if (hangingaround>0) { hangingaround--; }

            if (dkjrpos==2 && hangingaround==1) {
                  my_x=36; my_y=87;
               	ham_UpdateObjGfx(0,(void*)&DKJRANIM_DAT[64*(64*0)]);
                  dkjrpos=1;
                  hangingaround=0;
                                          if(!mysample[0]->playing) ham_PlaySample(mysample[0]);
            }            
            if (dkjrpos==6 && hangingaround==1) {
                  my_x=100; my_y=87;
                   ham_UpdateObjGfx(0,(void*)&DKJRANIM_DAT[64*(64*4)]);
                   dkjrpos=5;
                  hangingaround=0;
                                          if(!mysample[0]->playing) ham_PlaySample(mysample[0]);
            }            
            if (dkjrpos==8 && hangingaround==1) {
                 my_x=135; my_y=87;
                 ham_UpdateObjGfx(0,(void*)&DKJRANIM_DAT[64*(64*6)]);
                 dkjrpos=7;
                  hangingaround=0;
                                          if(!mysample[0]->playing) ham_PlaySample(mysample[0]);
            }            
            if (dkjrpos==12 && hangingaround==1) {
                  my_x=205; my_y=87;
                  ham_UpdateObjGfx(0,(void*)&DKJRANIM_DAT[64*(64*10)]);
                  dkjrpos=11;
                  hangingaround=0;
                                          if(!mysample[0]->playing) ham_PlaySample(mysample[0]);
            }            
            if (dkjrpos==15 && hangingaround==1) {
                  my_x=165; my_y=31;
                  ham_UpdateObjGfx(0,(void*)&DKJRANIM_DAT[64*(64*13)]);
                  dkjrpos=14;
                  hangingaround=0;
                                          if(!mysample[0]->playing) ham_PlaySample(mysample[0]);
            }            
}

void check_jumpingaround()
{
            //Special - if in air then fall 
            if (jumpingaround>0) { jumpingaround--; }
         
            if (dkjrpos==22 && jumpingaround==0) {
                  my_x=31; my_y=87;
               	ham_UpdateObjGfx(0,(void*)&DKJRANIM_DAT[64*(64*0)]);
                  dkjrpos=1;
                  ham_SetObjVisible(keysprite[0],1); //show key sprite
                  ham_SetObjXY(plumsprite[0],126,36); 
               	ham_UpdateObjGfx(plumsprite[0],(void*)&SPECIALS_DAT[32*(32*16)]);
                  plumshow=1; ham_SetObjVisible(plumsprite[0],1); // bring back plum

                                                if(!mysample[0]->playing) ham_PlaySample(mysample[0]);
            }      

            if (dkjrpos==21 && jumpingaround==0)
            {
                  my_x=55; my_y=20;
               	ham_UpdateObjGfx(0,(void*)&DKJRANIM_DAT[64*(64*21)]);
                  dkjrpos=22;
                  jumpingaround=50;
                                          if(!mysample[0]->playing) ham_PlaySample(mysample[0]);
            }      

            if (dkjrpos==20 && jumpingaround==0)
            {
                  my_x=25; my_y=45;
               	ham_UpdateObjGfx(0,(void*)&DKJRANIM_DAT[64*(64*22)]);
                  dkjrpos=23;
                  jumpingaround=50;
                                          if(!mysample[0]->playing) ham_PlaySample(mysample[0]);
            }      

            if (dkjrpos==23 && jumpingaround==0)
            {
                  my_x=5; my_y=82;
               	ham_UpdateObjGfx(0,(void*)&DKJRANIM_DAT[64*(64*23)]);
                  dkjrpos=24;
                  jumpingaround=50;
                                          if(!mysample[0]->playing) ham_PlaySample(mysample[0]);
            }      

            if (dkjrpos==24 && jumpingaround==0) {
                  my_x=31; my_y=87;
               	ham_UpdateObjGfx(0,(void*)&DKJRANIM_DAT[64*(64*0)]);
                  dkjrpos=1;
                                                if(!mysample[0]->playing) ham_PlaySample(mysample[0]);
            }      

            if (dkjrpos==4 && jumpingaround==0)
            {
                  my_x=70; my_y=87;
               	ham_UpdateObjGfx(0,(void*)&DKJRANIM_DAT[64*(64*2)]);
                  dkjrpos=3;
                                          if(!mysample[0]->playing) ham_PlaySample(mysample[0]);
            }      
            if (dkjrpos==10 && jumpingaround==0)
            {
                  my_x=165; my_y=87;
               	ham_UpdateObjGfx(0,(void*)&DKJRANIM_DAT[64*(64*8)]);
                  dkjrpos=9;
                                          if(!mysample[0]->playing) ham_PlaySample(mysample[0]);
            }      

            if (dkjrpos==17 && jumpingaround==0)
            {
                  my_x=135; my_y=31;
               	ham_UpdateObjGfx(0,(void*)&DKJRANIM_DAT[64*(64*15)]);
                  dkjrpos=16;
                                          if(!mysample[0]->playing) ham_PlaySample(mysample[0]);
            }      
            
            if (dkjrpos==19 && jumpingaround==0)
            {
                  my_x=100; my_y=31;
               	ham_UpdateObjGfx(0,(void*)&DKJRANIM_DAT[64*(64*17)]);
                  dkjrpos=18;
                                          if(!mysample[0]->playing) ham_PlaySample(mysample[0]);
            }      
}

void keyboard_routine()
{
        if (moved!=0) {
               if ( (F_CTRLINPUT_DOWN_PRESSED) || (F_CTRLINPUT_UP_PRESSED) || (F_CTRLINPUT_LEFT_PRESSED) || (F_CTRLINPUT_RIGHT_PRESSED) || (jumpingaround) ) { } else { moved=0; }         
            } else {
    
            if (F_CTRLINPUT_A_PRESSED && F_CTRLINPUT_LEFT_PRESSED) {
               if (dkjrpos==18 && moved==0) {
                my_x=75; my_y=10;
                ham_UpdateObjGfx(0,(void*)&DKJRANIM_DAT[64*(64*19)]);
                dkjrpos=20;
                moved=6;
                jumpingaround=25;
                     if(!mysample[0]->playing) ham_PlaySample(mysample[0]);

               } 
               
            }

   	  		if(F_CTRLINPUT_DOWN_PRESSED)
		    	{
               if (dkjrpos==2 && moved==0) {
                my_x=30; my_y=87;
                ham_UpdateObjGfx(0,(void*)&DKJRANIM_DAT[64*(64*0)]);
                dkjrpos=1;
                moved=2;
               if(!mysample[0]->playing) ham_PlaySample(mysample[0]);
               } 
               if (dkjrpos==6 && moved==0) {
                my_x=100; my_y=87;
                ham_UpdateObjGfx(0,(void*)&DKJRANIM_DAT[64*(64*4)]);
                dkjrpos=5;
                moved=2;
                              if(!mysample[0]->playing) ham_PlaySample(mysample[0]);
               } 
               if (dkjrpos==8 && moved==0) {
                my_x=135; my_y=87;
                ham_UpdateObjGfx(0,(void*)&DKJRANIM_DAT[64*(64*6)]);
                dkjrpos=7;
                moved=2;
                              if(!mysample[0]->playing) ham_PlaySample(mysample[0]);
               } 
	     		    if (dkjrpos==12 && moved==0) {
                my_x=205; my_y=87;
                ham_UpdateObjGfx(0,(void*)&DKJRANIM_DAT[64*(64*10)]);
                dkjrpos=11;
                moved=2;
                              if(!mysample[0]->playing) ham_PlaySample(mysample[0]);
               } 
	     		    if (dkjrpos==13 && moved==0) {
                my_x=200; my_y=66;
                ham_UpdateObjGfx(0,(void*)&DKJRANIM_DAT[64*(64*11)]);
                dkjrpos=12;
                moved=2;
                hangingaround=600;
                              if(!mysample[0]->playing) ham_PlaySample(mysample[0]);
               } 
	     		    if (dkjrpos==15 && moved==0) {
                my_x=165; my_y=31;
                ham_UpdateObjGfx(0,(void*)&DKJRANIM_DAT[64*(64*13)]);
                dkjrpos=14;
                moved=2;
                              if(!mysample[0]->playing) ham_PlaySample(mysample[0]);
               } 
 			   }
    
	  			if(F_CTRLINPUT_UP_PRESSED)
	     		{
		    	    if (dkjrpos==12 && moved==0) {
                my_x=198; my_y=31;
                ham_UpdateObjGfx(0,(void*)&DKJRANIM_DAT[64*(64*12)]);
                dkjrpos=13;
                moved=1;
                              if(!mysample[0]->playing) ham_PlaySample(mysample[0]);
               } 
 			                     
 	    		}

	  			if(F_CTRLINPUT_A_PRESSED)
	     		{
               if (dkjrpos==18 && moved==0) {
                my_x=100; my_y=10;
                ham_UpdateObjGfx(0,(void*)&DKJRANIM_DAT[64*(64*18)]);
                dkjrpos=19;
                moved=5;
                  jumpingaround=50;
                              if(!mysample[0]->playing) ham_PlaySample(mysample[0]);
               } 

               if (dkjrpos==16 && moved==0) {
                my_x=135; my_y=10;
                ham_UpdateObjGfx(0,(void*)&DKJRANIM_DAT[64*(64*16)]);
                dkjrpos=17;
                moved=5;
                  jumpingaround=50;
                              if(!mysample[0]->playing) ham_PlaySample(mysample[0]);
               } 

               if (dkjrpos==14 && moved==0) {
                my_x=170; my_y=10;
                ham_UpdateObjGfx(0,(void*)&DKJRANIM_DAT[64*(64*14)]);
                dkjrpos=15;
                moved=5;
                hangingaround=600;
                              if(!mysample[0]->playing) ham_PlaySample(mysample[0]);
               } 

               if (dkjrpos==5 && moved==0) {
                my_x=100; my_y=66;
                ham_UpdateObjGfx(0,(void*)&DKJRANIM_DAT[64*(64*5)]);
                dkjrpos=6;
                moved=5;
                hangingaround=600;
                              if(!mysample[0]->playing) ham_PlaySample(mysample[0]);
               } 

               if (dkjrpos==7 && moved==0) {
                my_x=135; my_y=66;
                ham_UpdateObjGfx(0,(void*)&DKJRANIM_DAT[64*(64*7)]);
                dkjrpos=8;
                moved=5;
                hangingaround=600;
                              if(!mysample[0]->playing) ham_PlaySample(mysample[0]);
               } 

               if (dkjrpos==1 && moved==0) {
                my_x=32; my_y=66;
                ham_UpdateObjGfx(0,(void*)&DKJRANIM_DAT[64*(64*1)]);
                dkjrpos=2;
                moved=5;
                hangingaround=600;
                              if(!mysample[0]->playing) ham_PlaySample(mysample[0]);
               } 

               if (dkjrpos==3 && moved==0) {
                my_x=65; my_y=66;
                ham_UpdateObjGfx(0,(void*)&DKJRANIM_DAT[64*(64*3)]);
                dkjrpos=4;
                moved=5;
                jumpingaround=50;
                              if(!mysample[0]->playing) ham_PlaySample(mysample[0]);
               } 

	     		    if (dkjrpos==9 && moved==0) {
                my_x=165; my_y=66;
                ham_UpdateObjGfx(0,(void*)&DKJRANIM_DAT[64*(64*9)]);
                dkjrpos=10;
                moved=5;
                jumpingaround=50;
                              if(!mysample[0]->playing) ham_PlaySample(mysample[0]);
               } 

	     		    if (dkjrpos==11 && moved==0) {
                my_x=200; my_y=66;
                ham_UpdateObjGfx(0,(void*)&DKJRANIM_DAT[64*(64*11)]);
                dkjrpos=12;
                moved=5;
                hangingaround=600;
                              if(!mysample[0]->playing) ham_PlaySample(mysample[0]);
               } 
            }	
   	
   			if(F_CTRLINPUT_LEFT_PRESSED)
   			{
   				
                if (dkjrpos==6 && moved==0) {
                my_x=65; my_y=66;
                ham_UpdateObjGfx(0,(void*)&DKJRANIM_DAT[64*(64*3)]);
                dkjrpos=4;
                moved=2;
                  jumpingaround=50;
                              if(!mysample[0]->playing) ham_PlaySample(mysample[0]);
               } 

               if (dkjrpos==8 && moved==0) {
                my_x=100; my_y=66;
                ham_UpdateObjGfx(0,(void*)&DKJRANIM_DAT[64*(64*5)]);
                dkjrpos=6;
                moved=5;
                hangingaround=600;
                              if(!mysample[0]->playing) ham_PlaySample(mysample[0]);
               } 

   				if (dkjrpos==16 && moved==0) {
                  my_x=100;
               	ham_UpdateObjGfx(0,(void*)&DKJRANIM_DAT[64*(64*17)]);
                  dkjrpos=18;
                  moved=3;
                              if(!mysample[0]->playing) ham_PlaySample(mysample[0]);
               } 
   				if (dkjrpos==14 && moved==0) {
                  my_x=135;
               	ham_UpdateObjGfx(0,(void*)&DKJRANIM_DAT[64*(64*15)]);
                  dkjrpos=16;
                  moved=3;
                              if(!mysample[0]->playing) ham_PlaySample(mysample[0]);
               } 
   				if (dkjrpos==13 && moved==0) {
                  my_x=165;
               	ham_UpdateObjGfx(0,(void*)&DKJRANIM_DAT[64*(64*13)]);
                  dkjrpos=14;
                  moved=3;
                              if(!mysample[0]->playing) ham_PlaySample(mysample[0]);
               } 
   				if (dkjrpos==11 && moved==0) {
                  my_x=165;
               	ham_UpdateObjGfx(0,(void*)&DKJRANIM_DAT[64*(64*8)]);
                  dkjrpos=9;
                  moved=3;
                              if(!mysample[0]->playing) ham_PlaySample(mysample[0]);
               } 
   				if (dkjrpos==9 && moved==0) {
                  my_x=135;
               	ham_UpdateObjGfx(0,(void*)&DKJRANIM_DAT[64*(64*6)]);
                  dkjrpos=7;
                  moved=3;
                              if(!mysample[0]->playing) ham_PlaySample(mysample[0]);
               } 
   				if (dkjrpos==7 && moved==0) {
                  my_x=100;
               	ham_UpdateObjGfx(0,(void*)&DKJRANIM_DAT[64*(64*4)]);
                  dkjrpos=5;
                  moved=3;            
                              if(!mysample[0]->playing) ham_PlaySample(mysample[0]);
               } 
   				if (dkjrpos==5 && moved==0) {
                  my_x=70;
               	ham_UpdateObjGfx(0,(void*)&DKJRANIM_DAT[64*(64*2)]);
                  dkjrpos=3;
                  moved=3;
                              if(!mysample[0]->playing) ham_PlaySample(mysample[0]);
               } 
               if (dkjrpos==3 && moved==0) {
                  my_x=30;
               	ham_UpdateObjGfx(0,(void*)&DKJRANIM_DAT[64*(64*0)]);
                  dkjrpos=1;
                  moved=3;
                              if(!mysample[0]->playing) ham_PlaySample(mysample[0]);
               } 
            
   			}  //end if left

   			if(F_CTRLINPUT_RIGHT_PRESSED)
			   {
               if (dkjrpos==8 && moved==0) {
                my_x=165; my_y=66;
                ham_UpdateObjGfx(0,(void*)&DKJRANIM_DAT[64*(64*9)]);
                dkjrpos=10;
                moved=4;
                  jumpingaround=50;
                              if(!mysample[0]->playing) ham_PlaySample(mysample[0]);
               } 

               if (dkjrpos==6 && moved==0) {
                my_x=135; my_y=66;
                ham_UpdateObjGfx(0,(void*)&DKJRANIM_DAT[64*(64*7)]);
                dkjrpos=8;
                moved=4;
               hangingaround=600;
                              if(!mysample[0]->playing) ham_PlaySample(mysample[0]);
               } 

               if (dkjrpos==2 && moved==0) {
                my_x=65; my_y=66;
                ham_UpdateObjGfx(0,(void*)&DKJRANIM_DAT[64*(64*3)]);
                dkjrpos=4;
                moved=4;
                  jumpingaround=50;
                              if(!mysample[0]->playing) ham_PlaySample(mysample[0]);
               } 
   			
   				if (dkjrpos==18 && moved==0) {
                  my_x=135;
               	ham_UpdateObjGfx(0,(void*)&DKJRANIM_DAT[64*(64*15)]);
                  dkjrpos=16;
                  moved=4;
                              if(!mysample[0]->playing) ham_PlaySample(mysample[0]);
               } 
   				if (dkjrpos==16 && moved==0) {
                  my_x=165;
               	ham_UpdateObjGfx(0,(void*)&DKJRANIM_DAT[64*(64*13)]);
                  dkjrpos=14;
                  moved=4;
                              if(!mysample[0]->playing) ham_PlaySample(mysample[0]);
               } 
   				if (dkjrpos==14 && moved==0) {
                  my_x=200;
               	ham_UpdateObjGfx(0,(void*)&DKJRANIM_DAT[64*(64*12)]);
                  dkjrpos=13;
                  moved=4;
                              if(!mysample[0]->playing) ham_PlaySample(mysample[0]);
               } 

               if (dkjrpos==1 && moved==0) {
                  my_x=70;
               	ham_UpdateObjGfx(0,(void*)&DKJRANIM_DAT[64*(64*2)]);
                  dkjrpos=3;
                  moved=4;
	
                              if(!mysample[0]->playing) ham_PlaySample(mysample[0]);
               } 
			   	if (dkjrpos==3 && moved==0) {
                  my_x=100;
               	ham_UpdateObjGfx(0,(void*)&DKJRANIM_DAT[64*(64*4)]);
                  dkjrpos=5;
                  moved=4;
                              if(!mysample[0]->playing) ham_PlaySample(mysample[0]);
               } 
   				if (dkjrpos==5 && moved==0) {
                  my_x=135;
               	ham_UpdateObjGfx(0,(void*)&DKJRANIM_DAT[64*(64*6)]);
                  dkjrpos=7;
                  moved=4;            
                              if(!mysample[0]->playing) ham_PlaySample(mysample[0]);
               } 
			   	if (dkjrpos==7 && moved==0) {
                  my_x=165;
               	ham_UpdateObjGfx(0,(void*)&DKJRANIM_DAT[64*(64*8)]);
                  dkjrpos=9;
                  moved=4;
                              if(!mysample[0]->playing) ham_PlaySample(mysample[0]);
               } 
			   	if (dkjrpos==9 && moved==0) {
                  my_x=205;
               	ham_UpdateObjGfx(0,(void*)&DKJRANIM_DAT[64*(64*10)]);
                  dkjrpos=11;
                  moved=4;
                              if(!mysample[0]->playing) ham_PlaySample(mysample[0]);
               } 
			   } //end if right
         } // end keyboard routine

}


