=====================================================
= The Unofficial Blues Brothers GBA Remake - v.0.02 =
=====================================================
=============== http://gba.kof91.com/ ===============
=====================================================
======= by moah (moah@kof91.com) - 17/09/2001 =======
=====================================================

This demo is a remake of 'The Blues Brothers', a platform game by Titus published in 1991
for home computers (Amiga, Atari ST, CPC, PC) .
I tried to be faithful to the original so none of the GBA advanced features are used 
(the demo actually uses 16 colors, just like the original) .
This demo is not produced by Titus and does not represent or reflect the quality of their
products (Look out for Prehistorik on GBA !).


Controls
========

Use arrow keys to control your character and A-button to pick up and throw crates .


What's New
==========

v.0.02	

* ennemies
* weapons (crates)
* collisions
* bonus items (discs)
* score/life display
* fixed elevator 'shaking' bug
* improved player speed


v.0.01

* first release !


Thanks to
=========

Martin and his 'Scrolling Background' Demo : it has the best documented code 
i've ever seen (there's actually more comments than code...) . Get it @ www.gbadev.org .
The disclaimer was borrowed from The_Letter_M's Oddworld demo (i couldn't phrase it better...)


Send feedback and suggestions to moah@kof91.com

Get the new versions @ http://gba.kof91.com/

Visit my other websites :
=========================
http://www.kof91.com/ - 2D Fighting Game Engine
http://mch.kof91.com/ - Mad Cow Hunter 3D Engine
