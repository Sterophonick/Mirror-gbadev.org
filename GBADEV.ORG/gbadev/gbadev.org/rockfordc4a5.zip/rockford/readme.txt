ROCKFORD 0.9 GBA by Zapf Bandit
-------------------------------

Here is my first real GBA game. It is a very accurate recreation of one of my favorite every DOS games.

It is not 100% complete but unfortunately I can't make it to a few of the levels in the original so I'm not sure what some of the blocks are... If you are a rockford fan please let me know what they are when you get to them.

The controls are reasonably easy:
	A - picks up or shoots
	B - abort life
	START - pauses the game
	
There are probably a lot of bugs left (I know shooting is still wiggy) so if you find one please let me know and I'll try and fix them.

Many thanks to Peter De Wachter who was nice enough to supply me with the graphics.

Hope you enjoy,

Zapf Bandit

zapf_bandit@hotmail.com

P.S. If there is any GBA developer who wants help or source get in touch with me and I'll help you out.