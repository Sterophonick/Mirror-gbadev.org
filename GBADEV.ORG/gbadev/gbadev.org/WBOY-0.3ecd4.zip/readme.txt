Hello gbadev,

I'm glad to present you my project : a GBA port of the ultimate jump and run game, Sega's WONDERBOY. It's my fourth try to make something cool for the GBA, and I think it may be the good one. The game engine seems not to much difficult to code, the main difficulty remains to reproduce the perfect gameplay of this classic. 

Commands :
A 	Small Jump
B	Run
A + B	Big Jump
L	Shoot

Hope you will enjoy it !

Kinski

kinski_kinski@hotmail.com
http://kinskifromfrance.free.fr


