SCRABBLE DICTIONARY
by Rob Blanding, June 2003

I hacked this dictionary together in an afternoon to supplement my travel Scrabble board. It has been tested on GBA SP hardware and the VisualBoy Advance emulator.

I am using the Enable2k word list. This is a very complete list of over 173,000 words. I have yet to find any words included in the official Scrabble dictionary that are not included here.

The controls should be self-explanatory.

You can get this and my other GBA stuff at: http://staff.washington.edu/robertb/GBA/ 

Comments can be sent to rblanding@hotmail.com.
