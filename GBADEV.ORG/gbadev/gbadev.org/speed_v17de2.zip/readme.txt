Speed
Ver: 1.0
Mark Harvey (mharvey1@san.rr.com)
2002

Introduction
============
Speed (also known as Spit) is a card game which requires quick thinking as you attempt to play
all your cards before your opponent is able to do the same.  Each player begins with 5 cards in their
hand, and can play cards onto one of two face down piles in the center of the two players.  A card can be
played only if its value is one higher or lower than the shown card.  The card values wrap around, allowing 
Aces to be played on Kings and vice versa.  Once a card is played, it replaces the old as the card to be played 
upon.  Once a card is played, the player will draw a new card from their play pile to replace it in their hand.
If no moves are available, a player can flip over the top card of the play piles to replace the two center cards.
When one player has played all their cards, they score a number of points equal to the number of cards their
opponent still had in their hand and draw pile.

Play Area
=========
The players hand will be shown as face up cards along the bottom of the screen, with the player's draw pile on
the left side.  The number of cards remaining in the draw pile is displayed underneath the deck.  The computer
player's cards are displayed as face down cards along the top, their draw pile is located in the right side
of the screen.  The play cards are shown in the center of the screen, inside the two raised rectangles.

Controls
========
Use the left and right buttons on the direction pad to move the cursor to point to the card you
wish to play.  Press the Left shoulder button to play onto the left play pile.  Press the Right shoulder
button to play onto the right play pile.  Only valid moves will be allowed.  The player will be unable to
play cards while the computer is in the process of playing one, or before a replacement card for an already 
played card has been delt.  Press the B button if you wish to replace the play cards with new
cards from the player's draw piles.

Designer Notes
==============
This game came into being at the request of my daughter, as it has become a rather popular game for the kids
at her school to play during lunch.  Not always being able to find a willing opponent at home, I spent a 
couple days to assemble this program for her.  It is a good feeling to see her embrace it and tell me how 
much she enjoys it, even if it means I do not get to play my GBA as much as I might like, I still have to
finish Mega Man Battle Network afterall :)

One interesting game note is that the computer's time to play a card is delayed slightly with each card
the player plays, allowing long runs by a player who is quick enough to take advantage.  There are three game
levels, distinguished by the different backgrounds.  Each level features increased difficulty (i.e. the computer
takes less time to make a move.)  What is the best score you can get, our bests are in the 30's range.

