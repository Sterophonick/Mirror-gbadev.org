
GBA MIDI Player

�2001  Parasytic Industries  -  http://parasytic.tripod.com/gbadev/
(Yep, a company* with a Tripod-hosted website! (company* = me) :P)


  The midi contained in this zip file is the one you'll hear in the ROM.
Some emulators have trouble playing it, VisualBoyAdvance plays it too fast,
for example. It works very nicely with the Flash Advance (if you don't
already have an FA cart, you need to get one NOW! NOW! NOW!).

  The player code is highly unoptimized, but still runs pretty fast. The
tempo in the ROM is set at 3700. (in my player, the higher the tempo, the
slower the music)
I'll have to use the player in a demo that uses a lot more CPU power to
see how much slower the demo or midi plays.




 -Credits
Programming:        Parasyte
Art:                Parasyte
Original Music:     Nintendo
MIDI Remix:         Nick Koustenis
