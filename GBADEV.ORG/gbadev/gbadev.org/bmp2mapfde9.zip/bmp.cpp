//////////////////////////////////////////////////////////////////////////////
// bmp.cpp                                                                  //
//////////////////////////////////////////////////////////////////////////////

//////////////////////////////////////////////////////////////////////////////
// Includes                                                                 //
//////////////////////////////////////////////////////////////////////////////
#include "bmp.h"

//////////////////////////////////////////////////////////////////////////////
// BMP::BMP                                                                 //
//////////////////////////////////////////////////////////////////////////////
BMP::BMP() : bits(0), palette(0), fi(0)
{
}

//////////////////////////////////////////////////////////////////////////////
// BMP::~BMP                                                                //
//////////////////////////////////////////////////////////////////////////////
BMP::~BMP()
{
	if (bits) { delete bits; bits = 0; }
	if (palette) { delete palette; palette = 0; }
	if (fi) { fclose(fi); fi = 0; }
}

//////////////////////////////////////////////////////////////////////////////
// BMP::Open                                                                //
//////////////////////////////////////////////////////////////////////////////
int BMP::Open(char *filename)
{
	fi = fopen(filename, "rb");
	if (!fi) { fprintf(stderr, "Error opening input file!\n"); return -1; }

	fread(&bfh, sizeof(bfh), 1, fi);
	fread(&bih, sizeof(bih), 1, fi);

	//printf("image size: %dx%d, bits: %d\n", bih.biWidth, bih.biHeight, bih.biBitCount);

	switch (bih.biBitCount)
	{
		case 4: return Read4();
		case 8: return Read8();
		case 24: return Read24();
		default:
		{
			fprintf(stderr, "Unknown bit-depth!\n");
			return -1;
		}
	}

	return -1;
}

//////////////////////////////////////////////////////////////////////////////
// BMP::ReadPalette                                                         //
//////////////////////////////////////////////////////////////////////////////
int BMP::ReadPalette()
{
	// read palette
	fseek(fi, sizeof(BITMAPFILEHEADER) + sizeof(BITMAPINFOHEADER), SEEK_SET);
	int colors = 1<<bih.biBitCount;
	palette = new RGBQUAD[colors];
	fread(palette, sizeof(RGBQUAD), colors, fi);

	/*for (int i=0; i<colors; i++)
	{
		fread(&palette[i], 3, 1, fi);	// R,G,B
		getc(fi);	// reserved
	}*/

	return 0;
}

//////////////////////////////////////////////////////////////////////////////
// BMP::Read4                                                               //
//////////////////////////////////////////////////////////////////////////////
int BMP::Read4()
{
	// read palette
	ReadPalette();

	// read bits

	return 0;
}

//////////////////////////////////////////////////////////////////////////////
// BMP::Read8                                                               //
//////////////////////////////////////////////////////////////////////////////
int BMP::Read8()
{
	// read palette
	ReadPalette();

	// read bits
	bits = (void *)new unsigned char[bih.biWidth * bih.biHeight];
	int line_size = bih.biWidth * 1;
	int align_size = ALIGN4(line_size);
	unsigned char *p = (unsigned char *)bits;
	for (int y=0; y<bih.biHeight; y++)
	{
		fseek(fi, bfh.bfOffBits + (bih.biHeight-1-y)*align_size, SEEK_SET);
		fread(p, line_size, 1, fi);
		p += bih.biWidth;
	}

	return 0;
}

//////////////////////////////////////////////////////////////////////////////
// BMP::Read24                                                              //
//////////////////////////////////////////////////////////////////////////////
int BMP::Read24()
{
	// read 24 bits colors
	fseek(fi, bfh.bfOffBits, SEEK_SET);
	bits = (void *)new RGBTRIPLE[bih.biWidth * bih.biHeight];

	int line_size = bih.biWidth * sizeof(RGBTRIPLE);
	int align_size = ALIGN4(line_size);
	RGBTRIPLE *p = (RGBTRIPLE *)bits;
	for (int y=0; y<bih.biHeight; y++)
	{
		fseek(fi, bfh.bfOffBits + (bih.biHeight-1-y)*align_size, SEEK_SET);
		fread(p, line_size, 1, fi);
		p += bih.biWidth;
	}
	
	return 0;
}
