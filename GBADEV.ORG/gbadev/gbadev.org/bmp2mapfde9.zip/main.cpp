//////////////////////////////////////////////////////////////////////////////
// main.cpp                                                                 //
//////////////////////////////////////////////////////////////////////////////
/*
	bmp to map converter

	by Dark Fader:
	v1.00
		initial version
		input: 8 bit bmp
		output: tiles (8x8), map, palette (15 bits)
		tiles are identified with a 64 bits hash value
*/

//////////////////////////////////////////////////////////////////////////////
// Includes                                                                 //
//////////////////////////////////////////////////////////////////////////////
#include "bmp.h"
#include <map>

using namespace std;

//////////////////////////////////////////////////////////////////////////////
// Defines                                                                  //
//////////////////////////////////////////////////////////////////////////////
#define VER "1.00"

//////////////////////////////////////////////////////////////////////////////
// Tile                                                                     //
//////////////////////////////////////////////////////////////////////////////
class Tile
{
	public:
		int index;
		unsigned char *bits;
};

//////////////////////////////////////////////////////////////////////////////
// Typedefs                                                                 //
//////////////////////////////////////////////////////////////////////////////
typedef map<__int64, Tile *> UniqueTiles;		// hashing table

//////////////////////////////////////////////////////////////////////////////
// Variables                                                                //
//////////////////////////////////////////////////////////////////////////////
__int64 rnd[256];	// used to generate hash values

//////////////////////////////////////////////////////////////////////////////
// main                                                                     //
//////////////////////////////////////////////////////////////////////////////
int main(int argc, char *argv[])
{
	if (argc < 2)
	{
		fprintf(stderr, "bmp2map v"VER" by Rafael Vuijk (aka Dark Fader)\n");
		fprintf(stderr, "Syntax: %s <image.bmp> <tiles.bin> <map.bin> <palette.bin>\n", argv[0]);
		return -1;
	}

	char *bmp_arg = (argc >= 2) ? argv[1] : 0;
	char *tiles_arg = (argc >= 3) ? argv[2] : 0;
	char *map_arg =  (argc >= 4) ? argv[3] : 0;
	char *pal_arg = (argc >= 5) ? argv[4] : 0;

	// open bitmap
	BMP8 bmp;
	if (bmp.Open(bmp_arg)) return -1;
	int numXTiles = bmp.bih.biWidth/8;
	int numYTiles = bmp.bih.biHeight/8;
	int numAllTiles = numYTiles * numXTiles;

	// generate random table
	for (int i=0; i<256; i++)
	{
		rnd[i] = rand()<<0 ^ rand()<<8 ^ rand()<<16 ^ rand()<<24 ^ rand()<<32 ^ rand()<<40 ^ rand()<<48 ^ rand()<<56;
	}

	// scan for unique tiles
	int numUniqueTiles;
	UniqueTiles uniqueTiles;	// hash value -> tile info
	int *tileNumbers = new int[numAllTiles];	// map
	{
		int index = 0;	// tile number
		for (int ty=0; ty<numYTiles; ty++)
		{
			for (int tx=0; tx<numXTiles; tx++)
			{
				// calculate hashvalue for tile
				int hashvalue = 0;
				for (int y=0; y<8; y++)
				{
					unsigned char *p = bmp[ty*8 + y] + tx*8 + 0;
					for (int x=0; x<8; x++)
					{
						int c	= rnd[*p++];		// color
						int xy	= rnd[y*8 + x];		// x,y

						hashvalue ^= (__int64)xy * c;		// works ok already :)
						hashvalue ^= (hashvalue >> 13) ^ (hashvalue << 42);	// hmm... scramble some more
					}
				}

				// check if already done
				Tile *tile = uniqueTiles[hashvalue];
				if (!tile)
				{
					tile = new Tile();
					uniqueTiles[hashvalue] = tile;
					tile->bits = bmp[ty*8 + 0] + tx*8 + 0;
					tile->index = index++;
				}

				// set tilenumber
				tileNumbers[ty * numXTiles + tx] = tile->index;
			}
		}
		numUniqueTiles = uniqueTiles.size();
	}

	// write tiles
	if (argc >= 2)
	{
		FILE *fo = fopen(tiles_arg, "wb");
		if (!fo) { fprintf(stderr, "Error operning output file!\n"); return -1; }

		UniqueTiles::reverse_iterator i;
		i = uniqueTiles.rbegin();
		for (int j=0; j<numUniqueTiles; j++)
		{
			Tile *tile = i->second;

			fseek(fo, tile->index * 8*8, SEEK_SET);
			for (int y=0; y<8; y++)
			{
				fwrite(tile->bits + bmp.bih.biWidth*y, 1, 8, fo);
			}

			delete tile;	// don't need it anymore

			i++;
		}

		fclose(fo);
	}

	// write map
	if (argc >= 3)
	{
		FILE *fo = fopen(map_arg, "wb");
		if (!fo) { fprintf(stderr, "Error operning output file!\n"); return -1; }

		for (int ty=0; ty<numYTiles; ty++)
		{
			for (int tx=0; tx<numXTiles; tx++)
			{
				fputc(tileNumbers[ty * numXTiles + tx], fo);
			}
		}

		fclose(fo);
	}

	// write palette
	if (argc >= 4)
	{
		FILE *fo = fopen(pal_arg, "wb");
		if (!fo) { fprintf(stderr, "Error operning output file!\n"); return -1; }

		int colors = 1<<bmp.bih.biBitCount;
		for (int i=0; i<colors; i++)
		{
			int r = bmp.palette[i].rgbRed >> 3;
			int g = bmp.palette[i].rgbGreen >> 3;
			int b = bmp.palette[i].rgbBlue >> 3;
			short rgb = r<<0 | g<<5 | b<<10;
			fwrite(&rgb, sizeof(rgb), 1, fo);
		}

		fclose(fo);
	}

	// output parsable info
	{
		fprintf(stdout, "%d %d %d %d", numUniqueTiles, numXTiles, numYTiles, numAllTiles);
		fprintf(stdout, "(unique_tiles map_width map_height total_tiles)\n");
	}
	
	delete tileNumbers;

	return 0;
}
