Readme.txt -- Attack... On Outer Space!

Programmer: Josh Chudnovsky, Chud575 on #gbadev, chud575@hotmail.com
Artist: Danil, Lord Danil, lorddanil@mail.ru (he speaks good english if you want to email him)
Music from: GBA MusicWave, courtesy of Sergej Kravcenko

Well if you're reading this, it means i finally finished the damn game.  It took 6 weeks but i did it ;).  Anyways, Here is what you need to know to play:

Gameplay:
D-pad - Move ship
A button - Shoot

Powerups:
H - health
S - speed
P - plasma damage upgrade
X - clear screen

2 Levels and 2 bosses.  Here are some things i know i did wrong in my code:
- EnemyShips array is incorrectly accessed, added to and deleted from, making strange display bugs if you try to add 30+ enemies to the screen at once
- Linked list for explosions instead of static array like for the plasma
- using divide and mod in some places when i know i shouldn't or should've wrote some kind of assembly instruction to do it.  Oh well, its not too many of them and the game still runs smooth.
- OAM Memory manager isn't perfect, have to be careful to always load and unload like a stack, because model is simple and doesn't resort images in OAM, it just tells you where you can start writing to, example:
OAMLoad (PlayerShip)
OAMLoad (PlayerBullet)
OAMLoad (EnemyShip)
OAMRemove(PlayerShip) - this has untested effects, because i never tried it hehe.  the effect of this is removing the player ship from the linked list, and freeing up OAM all the way to the beginning, but we did not remove playerbullet or enemyship from the list!.. so always remove like a stack.. last to first of what was loaded
- boss Ship loading/updating isn't extremely dyanmic, and the 'pieceLoad' function is god awful.. i pass in like 20 var's.. was trying to get the damn thing done at this point.
- i have some software sprites for score and health.. my software pixel write method is slow, and not ASM optimized.

I check my email everyday and i would love to hear from all of you.. anybody who knows how i could have done something better, ASM optimizations, etc.. or if you hate my game and want to tell me that too thats cool, send away.

Thanks to people from #gbadev on EF-net (or possible a website i read):
JSensebe
Bitfox
Dovoto
Niemod
YoyoGrrl
Eloist
Gweedo767
Jeff Frowhein
Russ Prince
GBAJunkie
Dark Fader
Dooby
Bruno Vedder

Shoutouts to buddies:
Bobbster Shammy (has a flash kit, thank god)
Behi Shamster (The Behrangatang)
Matteus Kaareus (God among men, and completely untrustworthy)
Hept0ne (Not a god, but trustworthy)
Hartman, C and K (UGA sucks)
Johnny "We named the dog Indiana" Jones
Mandarax85 (Falcons suck too)
Raw Dawe (Do you even check your email anymore?.. Def Accordian Jam '02!)
"The Man" ('nuff said)
Bleifeld (Not your everyday Jew)
The Viking (Slingo, Slackjack, and the 25 Million Dollar Slot Pull, Thats VEGAS ACTION BABY!)
"Everybody Loves" Raymond (Ya, we are niahlists, we believe in nothing)
