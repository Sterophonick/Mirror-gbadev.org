Gridlock v1.0
September 19 2004
Neil McConnell

-------------------------

This is a relatively simple puzzle game.  It has been implemented in mode 3; the sprites are using 16 colour palettes.

The instructions are included in the ROM - you can't miss them.

I created this demo with the twin goals of learning to program the GBA, and having some C code that I could show to employers.  It took significant chunks of my spare time for about three weeks.

I hope you enjoy playing Gridlock.

--Neil
