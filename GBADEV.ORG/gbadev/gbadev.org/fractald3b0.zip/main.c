#include "main.h"
#include "misc.h"
#include "intr.h"
#include "armfunc.h"
#include "sprno.h"
#include "font_LZ.h"

//#define C_CODE
//#define USE_64BIT
#define PRECISION 24
#define PRECISION_MUL (1<<PRECISION)
#define AUTO_UPDATE

#define DEFAULT_ZOOM 160000

#define NO_SLOTS 16

#define RGB(r,g,b) ((r)|((g)<<5)|((b)<<10))

#define WIDTH   240
#define HEIGHT  136

#define XOFS    0
#define YOFS    0

#define FIRST_BOX_SPRITE 88
#define HISTORY_MAXLEN 100
#define BOXSPR (768-16)
#define CURSORSPR (768-24)

#define VRAM_BACKUP EX_WRAM

#define SRAM_ADDR    0x0E000000 
#define sram ((u8*)SRAM_ADDR)
#define VERSION_CRC 0x27

#if PRECISION==12
#define DOMANDEL(x,y,z,a,b,c) doMandel12(x,y,z,a,b,c)
#else
#if PRECISION==24
#define DOMANDEL(x,y,z,a,b,c) doMandel24(x,y,z,a,b,c)
#endif
#endif

OamData OamBak[128];

s32 frameCnt;

u8 lineUpdate[2][HEIGHT];

s32 interlace=1;
s32 curFractal;
s32 curPalette;

struct TZoom history[HISTORY_MAXLEN];
s32 histlen=0;

#include "default.c"

struct TJulia fractalslot[NO_SLOTS];
struct TPal palslot[NO_SLOTS];

const u16 font_Palette[32] = {
	0x0000,0x4210,0xffff,0xffff,0xffff,0xffff,0xffff,0xffff,
	0xffff,0xffff,0xffff,0xffff,0xffff,0xffff,0xffff,0xffff,
	0x0000,0x0010,0x001f,0xffff,0xffff,0xffff,0xffff,0xffff,
	0xffff,0xffff,0xffff,0xffff,0xffff,0xffff,0xffff,0xffff,
};

const u32 palspr[16]={
	0x7F7F7F7F,0x0000007F,
	0x8080807F,0x0000007F,
	0x8080807F,0x0000007F,
	0x8080807F,0x0000007F,
	0x8080807F,0x0000007F,
	0x8080807F,0x0000007F,
	0x8080807F,0x0000007F,
	0x7F7F7F7F,0x0000007F,
};

const u32 palXspr[16]={
	0x7F7F7F7F,0x0000007F,
	0x0000007F,0x0000007F,
	0x7F007F7F,0x0000007F,
	0x007F007F,0x0000007F,
	0x007F007F,0x0000007F,
	0x7F007F7F,0x0000007F,
	0x0000007F,0x0000007F,
	0x7F7F7F7F,0x0000007F,
};

const u32 palMark[16]={
	0x7E7E7E7E,0x0000007E,
	0x0000007E,0x0000007E,
	0x0000007E,0x0000007E,
	0x0000007E,0x0000007E,
	0x0000007E,0x0000007E,
	0x0000007E,0x0000007E,
	0x0000007E,0x0000007E,
	0x7E7E7E7E,0x0000007E,
};

void byteCopy(u8 *src, u8 *dest, u32 size)
{
	int i;
	for(i=0;i<size;i++)
		*dest++=*src++;
}

void saveFiles(void)
{
	s32 i,sum=0;
	u8 *p=sram,*q=sram;
	
	for(i=0;i<NO_SLOTS;i++) {
		byteCopy((u8*)(fractalslot+i),p,sizeof(struct TJulia));
		p+=sizeof(struct TJulia);
	}
	for(i=0;i<NO_SLOTS;i++) {
		byteCopy((u8*)(palslot+i),p,sizeof(struct TPal));
		p+=sizeof(struct TPal);
	}
	*p++=interlace;
	while (q<p) {
		sum+=*q;
		q++;
	}
	sum+=VERSION_CRC;
	*p=sum&0xFF;
}

void loadFiles(void)
{
	s32 i,sum=0;
	u8 *p=sram,*q=sram;
	
	for(i=0;i<NO_SLOTS;i++) {
		byteCopy(p,(u8*)(fractalslot+i),sizeof(struct TJulia));
		p+=sizeof(struct TJulia);
	}
	for(i=0;i<NO_SLOTS;i++) {
		byteCopy(p,(u8*)(palslot+i),sizeof(struct TPal));
		p+=sizeof(struct TPal);
	}
	interlace=*p++;
	while (q<p) {
		sum+=*q;
		q++;
	}
	sum+=VERSION_CRC;
	if ((sum&0xFF)!=*p) {	
		for(i=0;i<NO_SLOTS;i++) {
			strcpy(fractalslot[i].name,"<EMPTY>");
			strcpy(palslot[i].name,"<EMPTY>");
		}
		for(i=0;i<NO_PREDEF_FRACTALS;i++)
			CpuCopy(predefined+i,fractalslot+i,sizeof(struct TJulia),16);
		for(i=0;i<NO_PREDEF_PALETTES;i++)
			CpuCopy(predefinedpals+i,palslot+i,sizeof(struct TPal),16);
		interlace=1;
		saveFiles();
	}
}

void clearSprites(void)
{
	s32 i;
	for(i=0;i<128;i++)
		objRemove(i);
}

void mandelbrot(struct TJulia *j)
{
#ifdef C_CODE
	s32 cnt,limit;
#ifdef USE_64BIT
	s64 xv,yv,curx,cury,a2,b2;
#else
	s32	xv,yv,curx,cury,a2,b2;
#endif
	u8 *p;
#endif

	s32 i,y;

#ifdef USE_64BIT
	s64 xm=0,ym=0,xwidth,ywidth;
#else
	s32 xm=0,ym=0,xwidth,ywidth;
#endif

	u8 buf[256];

	frameCnt=0;

	CpuClear(0,buf,240,16);

#if PRECISION>=20
	xwidth=(j->zoom*30)<<(PRECISION-20);
	ywidth=(j->zoom*17)<<(PRECISION-20);
#else
	xwidth=(j->zoom*30)>>(20-PRECISION);
	ywidth=(j->zoom*17)>>(20-PRECISION);
#endif

	j->XRMin=j->cx-(xwidth>>1);
	j->YRMin=j->cy-(ywidth>>1);
	j->XRMax=j->cx+(xwidth>>1);
	j->YRMax=j->cy+(ywidth>>1);

	j->YDif=Div(j->YRMax-j->YRMin+(HEIGHT>>1),HEIGHT)-1;
	j->XDif=Div(j->XRMax-j->XRMin+(WIDTH>>1),WIDTH)-1;

	j->XRMin=j->cx-j->XDif*(WIDTH>>1);
	j->YRMin=j->cy-j->YDif*(HEIGHT>>1);
	j->XRMax=j->cx+j->XDif*(WIDTH>>1);
	j->YRMax=j->cy+j->YDif*(HEIGHT>>1);

	xm=j->real;
	ym=j->imag;

#ifdef C_CODE
	limit=((j->type==2)?2:8)<<PRECISION;
	for(i=0;i<HEIGHT;i++) {
		y=lineUpdate[interlace][i];
		cury=j->YRMin+y*j->YDif;
		p=buf;
		for(curx=j->XRMin;curx<j->XRMax;curx+=j->XDif) {
			xv=curx;
			yv=cury;
			a2=b2=0;
			cnt=j->pal.maxcnt;
			if (!j->type) {
				xm=curx;
				ym=cury;
			}
			while (a2+b2<limit) {
				if (j->type==2) {
					a2=(xv*xv)>>PRECISION;
					b2=(yv*yv)>>PRECISION;
					yv=(xv*yv)>>(PRECISION-1);
					xv=a2-b2;
				}
				a2=(xv*xv)>>PRECISION;
				b2=(yv*yv)>>PRECISION;
				yv=((xv*yv)>>(PRECISION-1))+ym;
				xv=a2-b2+xm;
				if (!--cnt)
					break;
			}
			*p++=j->pal.maxcnt-cnt;
		}
		CpuCopy(buf,VRAM+(y+YOFS)*240+XOFS,WIDTH,16);
	}
#else
	for(i=0;i<HEIGHT;i++) {
		y=lineUpdate[interlace][i];
		DOMANDEL(j->YRMin+y*j->YDif,buf,j,j->XRMin,j->XRMax,j->XDif);
		CpuCopy(buf,VRAM+(y+YOFS)*240+XOFS,WIDTH,16);
	}
#endif
}

void intr_initScreen(void)
{
	*(vu16*)PLTT=0;
	*(vu16*)REG_DISPCNT|=DISP_BG2_ON;
}

void intr_initStatus(void)
{
	while (!(*(vu16*)REG_STAT&2));
	*(vu16*)PLTT=0x7C00;
	*(vu16*)REG_DISPCNT&=~DISP_BG2_ON;
	CpuFastClear(0,OAM+FIRST_BOX_SPRITE*sizeof(vOamData),(128-FIRST_BOX_SPRITE)*sizeof(vOamData));
}

void enableInterrupts(void)
{
	VBlankHandler=intr_initScreen;
	VCounterHandler=intr_initStatus;
}

void disableInterrupts(void)
{
	VBlankIntrWait();
	VBlankHandler=0;
	VCounterHandler=0;
}

void init(void)
{
	s32 i,j,k;
	u32 *p;

	const u32 line[8]={0,4,2,6,1,3,5,7};

	CpuFastClear(0,VRAM,VRAM_SIZE);
  CpuFastClear(0,EX_WRAM,EX_WRAM_SIZE);
  CpuFastClear(0,PLTT,PLTT_SIZE);

	intrInit();
	*(vu16*)REG_IME   = 1;
  *(vu16*)REG_IE    = V_BLANK_INTR_FLAG | CASSETTE_INTR_FLAG;
  *(vu16*)REG_STAT  = STAT_V_BLANK_IF_ENABLE;
  *(vu16*)REG_DISPCNT = 0;

	*(vu16*)REG_WAITCNT=CST_PREFETCH_ENABLE | CST_ROM0_1ST_3WAIT | CST_ROM0_2ND_1WAIT;

	*(vu16*)REG_DISPCNT=DISP_MODE_4 | DISP_BG2_ON | DISP_OBJ_ON | DISP_OBJ_CHAR_1D_MAP;
	*(vu16*)REG_BG2CNT=0;

	sprNoInit(0,512);

	p=(u32*)(OBJ_MODE0_VRAM+(BOXSPR<<5));
	for(i=0;i<32;i++)
		*p++=((i&7)<2)?0x11111111:0;
	for(i=0;i<16;i++)
		*p++=0x11;
	p=(u32*)(OBJ_MODE0_VRAM+(CURSORSPR<<5));
	for(i=0;i<8;i++)
		*p++=0x22222222;

	((u16*)OBJ_PLTT)[7*16+1]=0x7FFF; // Box color
	((u16*)OBJ_PLTT)[7*16+2]=0x7FE0; // Cursor color

	for(i=0;i<HEIGHT;i++)
		lineUpdate[0][i]=i;
	for(i=k=0;i<8;i++)
		for(j=line[i];j<HEIGHT;j+=8,k++)
			lineUpdate[1][k]=j;

	enableInterrupts();

	*(vu16*)REG_IE|=V_COUNT_INTR_FLAG;
	*(vu16*)REG_STAT|=STAT_V_COUNT_IF_ENABLE;
	*(vu8*)(REG_STAT+1)=(YOFS<<1)+HEIGHT-2;
}

void box(s32 x1, s32 y1, s32 xsize, s32 ysize)
{
	s32 x,y,x2,y2,size,n=FIRST_BOX_SPRITE;

	x2=x1+xsize;
	y2=y1+ysize;

	if (xsize<32) {
		size=OAM_SIZE_16x8;
		xsize=16;
	} else {
		size=OAM_SIZE_32x8;
		xsize=32;
	}

	x=x1;
	while (x<x2-xsize) {
		if ((x>-xsize) && (x<240)) {
			if ((y1>=0) && (y1<240))
				objPut16(n++,x,y1,BOXSPR,size,-1,0,0,7);
			if ((y2>=2) && (y2<242))
				objPut16(n++,x,y2-2,BOXSPR,size,-1,0,0,7);
		}
		x+=xsize;
	}

	if ((x2>0) && (x2<240+xsize)) {
		if ((y1>=0) && (y1<240))
			objPut16(n++,x2-xsize,y1,BOXSPR,size,-1,0,0,7);
		if ((y2>=2) && (y2<242))
			objPut16(n++,x2-xsize,y2-2,BOXSPR,size,-1,0,0,7);
	}

	if (ysize<16) {
		size=OAM_SIZE_8x8;
		ysize=8;
	} else {
		size=OAM_SIZE_8x16;
		ysize=16;
	}

	y=y1;
	while (y<y2-ysize) {
		if ((y>-ysize) && (y<160)) {
			if ((x1>=0) && (x1<240))
				objPut16(n++,x1,y,BOXSPR+4,size,-1,0,0,7);
			if ((x2>=2) && (x2<242))
				objPut16(n++,x2-2,y,BOXSPR+4,size,-1,0,0,7);
		}
		y+=ysize;
	}
	if ((y2>0) && (y2<160+ysize)) {
		if ((x1>=0) && (x1<240))
			objPut16(n++,x1,y2-ysize,BOXSPR+4,size,-1,0,0,7);
		if ((x2>=2) && (x2<242))
			objPut16(n++,x2-2,y2-ysize,BOXSPR+4,size,-1,0,0,7);
	}

	if (n>=128) while (1);
}

void decPrint(char *s, s32 v, char plus, char minus, s32 dec)
{
	if (v>=0) *s++=plus;
	if (v<0) {
		*s++=minus;
		v=-v;
	}
	s+=dec+1;
	while (dec>0) {
		*s--='0'+v%10;
		dec--;
		v=Div(v,10);
	}
	*s--='.';
	*s='0'+v;
}

void digPrint(char *s, s32 v, s32 nodig)
{
	s+=nodig;
	do {
		*--s='0'+v%10;
		v=Div(v,10);
		nodig--;
	} while (v);
	while (nodig-->0)
		*--s=' ';
}

void loadFractal(struct TJulia *j, s32 no)
{
	s32 i;
	CpuCopy(fractalslot+no,j,sizeof(struct TJulia),16);
	if (no<NO_PREDEF_FRACTALS)
		curFractal=-1;
	else
		curFractal=no;
	curPalette=-1;
	for(i=0;i<128;i++)
		((u16*)PLTT)[i]=j->pal.col[i];
	history[histlen=0].cx=j->cx;
	history[histlen].cy=j->cy;
	history[histlen].zoom=j->zoom;
}

void saveFractal(struct TJulia *j, s32 no)
{
	CpuCopy(j,fractalslot+no,sizeof(struct TJulia),16);
	curFractal=no;
	saveFiles();
}

void loadPalette(struct TPal *pal, s32 no)
{
	s32 i;
	CpuCopy(palslot+no,pal,sizeof(struct TPal),16);
	if (no<NO_PREDEF_PALETTES)
		curPalette=-1;
	else
		curPalette=no;
	for(i=0;i<128;i++)
		((u16*)PLTT)[i]=pal->col[i];
}

void savePalette(struct TPal *pal, s32 no)
{
	CpuCopy(pal,palslot+no,sizeof(struct TPal),16);
	curPalette=no;
	saveFiles();
}

void menuWrite(s32 x, s32 y, char *s, s32 pal)
{
	while (*s) {
		*(vu16*)(VRAM+0x8000+(y<<6)+(x<<1))=*s | (pal<<12);
		s++;
		x++;
	}
}

char *menuMain[3]={"FILE","PALETTE","OPTIONS"};
char *menuFile[3]={"LOAD","SAVE","SAVE AS"};
char *menuFile2[2]={"LOAD","SAVE AS"};
char *menuPalette[4]={"CHANGE","LOAD","SAVE","SAVE AS"};
char *menuPalette2[3]={"CHANGE","LOAD","SAVE AS"};
char *menuOptions[2]={
	"REFRESH:TOP-DOWN|INTERLACED|",
	"FRACTAL:MANDELBROT SET|JULIA SET z[=c|JULIA SET z\\=c|"};

void showMenu(char **options, s32 n, s32 y, s32 spr, s32 cur)
{
	s32 i,j,m,x=4;
	m=spr;
	for(i=0;i<n;i++) {
		sprNoPal=(i==cur)?1:0;
		sprNoText(options[i],x,y,m);
		sprNoPal=0;
		j=strlen(options[i]);
		x+=(j+2)*8;
		m+=j;
	}
}

s32 doMenu(char **options, s32 n, s32 y, s32 spr, s32 cur)
{
	s32 i,j,m,x;
	while (1) {
		x=4;
		m=spr;
		for(i=0;i<n;i++) {
			sprNoPal=(i==cur)?1:0;
			sprNoText(options[i],x,y,m);
			sprNoPal=0;
			j=strlen(options[i]);
			x+=(j+2)*8;
			m+=j;
		}
		VBlankIntrWait();
		if (keyTrg & L_KEY)
			cur=(cur+n-1)%n;
		if (keyTrg & R_KEY)
			cur=(cur+1)%n;
		if (keyTrg & AB_BUTTON)
			break;
	}
	return (keyTrg&B_BUTTON)?-1:cur;
}

s32 doOptions(char **options, s32 n, s32 y, s32 spr, struct TJulia *j)
{
	s32 i,opt=0,cur[5],max[5];
	char s[32],*p,*q;

	cur[0]=interlace; max[0]=2;
	cur[1]=j->type; max[1]=3;
	while (1) {
		for(i=spr;i<spr+40;i++)
			objRemove(i);
		p=options[opt];
		q=s;
		while (*p!=':')
			*q++=*p++;
		*q++=*p++;
		*q=0;
		sprNoText(s,4,y,spr);
		sprNoPal=1;
		i=cur[opt];
		while (i-->0) {
			while (*p!='|')
				p++;
			p++;
		}
		q=s;
		while (*p!='|')
			*q++=*p++;
		*q=0;
		p++;
		sprNoText(s,84,y,spr+20);
		sprNoPal=0;
		VBlankIntrWait();
		if (keyTrg & U_KEY) opt=(opt+n-1)%n;
		if (keyTrg & D_KEY) opt=(opt+1)%n;
		if (keyTrg & L_KEY) cur[opt]=(cur[opt]+max[opt]-1)%max[opt];
		if (keyTrg & R_KEY) cur[opt]=(cur[opt]+1)%max[opt];
		if (keyTrg & AB_BUTTON)
			break;
	}
	if (keyTrg & A_BUTTON) {
		interlace=cur[0];		
		j->type=cur[1];
		saveFiles();
		return 0;
	}
	return -1;
}

char charNext(char cur, s32 step)
{
	const char *chars=" ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789!#$%&'*+,-./:;=?@";
	s32 i=0,nochars;
	char *p=(char*)chars;

	nochars=strlen(chars);
	while (*p!=cur) {
		p++;
		i++;
	}
	i+=step;
	if (i<0) return chars[nochars-1];
	if (i>=nochars) return chars[0];
	return chars[i];
}

s32 selectFile(char *names[], s32 cnt, s32 save)
{
	s32 i,j,topy=0,cur=0,x=0,y=0,n,pos;
	char s[MAX_NAME_LEN+1],*p,*q;

	while (1) {
		VBlankIntrWait();
		clearSprites();
		for(i=0,n=4;(i<4) && ((topy<<1)+i<cnt);i++) {
			n=i*MAX_NAME_LEN;
			sprNoPal=((topy<<1)+i==cur)?1:0;
			sprNoText(names[(topy<<1)+i],(i&1)?124:4,(i>>1)*10+138,n);
		}
		sprNoPal=0;
		if (keyTrg & U_KEY) y--;
		if (keyTrg & D_KEY) y++;
		if (keyTrg & L_KEY) x--;
		if (keyTrg & R_KEY) x++;
		if (y<0) y=(cnt>>1)-1;
		if (y>=(cnt>>1)) y=0;
		if (x<0) x=1;
		if (x>1) x=0;
		cur=(y<<1)+x;
		if (cur>=cnt) cur=cnt-1;
		if (y<topy) topy=y;
		if (y>topy+1) topy=y-1;
		if (topy<0) topy=0;
		if (keyTrg & B_BUTTON) break;
		if (keyTrg & A_BUTTON) {
			if (!save && (*names[cur]=='<'))
				continue;
			if (save) {
				i=(cur-(topy<<1));
				n=i*MAX_NAME_LEN;
				for(j=0;j<MAX_NAME_LEN;j++)
					s[j]=' ';
				s[MAX_NAME_LEN]=0;
				pos=0;
				if (*names[cur]!='<') {
					p=names[cur];
					q=s;
					while (*p) {
						*q++=*p++;
						pos++;
					}
				}
				if (pos>=MAX_NAME_LEN)
					pos=MAX_NAME_LEN-1;
				sprNoPal=1;
				while (1) {
					sprNoText(s,(i&1)?124:4,(i>>1)*10+138,n);
					objPut16(63,((i&1)?124:4)+(pos<<3),(i>>1)*10+138,CURSORSPR,OAM_SIZE_8x8,-1,0,0,7);
					VBlankIntrWait();
					if ((keyTrg & L_KEY) && (pos>0)) pos--;
					if ((keyTrg & R_KEY) && (pos<MAX_NAME_LEN-1)) pos++;
					if (keyTrg & U_KEY) s[pos]=charNext(s[pos],1);
					if (keyTrg & D_KEY) s[pos]=charNext(s[pos],-1);
					if (keyTrg & AB_BUTTON) break;
					if (keyTrg & L_BUTTON) {
						for(j=0;j<MAX_NAME_LEN;j++)
							s[j]=' ';
						pos=0;
					}
				}
				objRemove(63);
				sprNoPal=0;
				if (keyTrg & B_BUTTON)
					continue;
				p=s+MAX_NAME_LEN-1;
				while ((p>=s) && (*p==' '))
					p--;
				if (p<s)
					continue;
				*++p=0;
				strcpy(names[cur],s);
			}
			break;
		}
	}
	clearSprites();
	return (keyTrg & A_BUTTON)?cur:-1;
}

s32 changePalette(struct TPal *pal)
{
	s32 i,j,k,left=0,x,cur=0,cnt=0,keyCnt=20;
	s32 r,g,b,r1,g1,b1,r2,g2,b2;
	u32 spr[16];
	s16 col[128];
	u8 *p,*q;
	clearSprites();
	for(i=0;i<128;i++) {
		p=(u8*)palspr;
		q=(u8*)spr;
		for(j=0;j<64;j++)
			q[j]=p[j]+(p[j]<0x80?0:i);
		CpuFastArrayCopy(spr,OBJ_MODE0_VRAM+((1024-256+(i<<1))<<5));
	}
	CpuFastArrayCopy(palXspr,OBJ_MODE0_VRAM+((1024-258)<<5));
	CpuFastArrayCopy(palMark,OBJ_MODE0_VRAM+((1024-260)<<5));
	for(i=0;i<128;i++) {
		if (i<=pal->maxcnt)
			col[i]=pal->col[i];
		else
			col[i]=-1;
		((u16*)OBJ_PLTT)[i+128]=col[i];
	}	
	((u16*)OBJ_PLTT)[127]=0;
	while (1) {
		clearSprites();
		i=(cnt<16)?cnt:31-cnt;
		cnt=(cnt+1)&31;
		((u16*)OBJ_PLTT)[126]=RGB(i<<1,i<<1,0);
		for(i=0;i<58;i++)
			objPut(i+1,4+(i<<2),138,(col[i+left]<0)?766:(768+((i+left)<<1)),OAM_SIZE_8x8,-1,0,0);
		objPut(0,4+((cur-left)<<2),138,764,OAM_SIZE_8x8,-1,0,0);
		j=60;
		for(i=0;i<=128;i+=16) {
			if ((i>=left) && (i<left+58)) {
				x=((i-left)<<2)+2;
				if (i>9) x+=4;
				if (i>99) x+=4;
				sprNoPrint(i,j,3,x,148);
				j+=3;
			}
		}
		VBlankIntrWait();
		if (keyCnt>5) {
			if ((keyCur & L_KEY) && (cur>0)) { cur--; keyCnt=0; }
			if ((keyCur & R_KEY) && (cur<127)) { cur++; keyCnt=0; }
		} else
			keyCnt++;
		if (cur<left) left=cur;
		if (cur>left+57) left=cur-57;
		if (keyTrg & L_BUTTON) {
			for(i=0;i<128;i++)
				col[i]=-1;
			col[0]=0;
		}
		if (keyTrg & R_BUTTON) {
			for(i=0;i<128;i++) {
				if (col[i]>=0) {
					for(j=i+1;(j<128) && (col[j]<0);j++);
					if (j<128) {
						r1=col[i]&31;
						g1=(col[i]>>5)&31;
						b1=(col[i]>>10)&31;
						r2=col[j]&31;
						g2=(col[j]>>5)&31;
						b2=(col[j]>>10)&31;
						for(k=i+1;k<j;k++) {
							r=r1+Div((r2-r1)*(k-i),j-i);
							g=g1+Div((g2-g1)*(k-i),j-i);
							b=b1+Div((b2-b1)*(k-i),j-i);
							col[k]=r|(g<<5)|(b<<10);
							((u16*)OBJ_PLTT)[k+128]=col[k];
						}
					}
					i=j-1;
				}
			}
		}		
		if (keyTrg & AB_BUTTON)
			break;
		if (keyTrg & SELECT_BUTTON) {
			for(i=60;i<128;i++)
				objRemove(i);
			sprNoText("R:",4,148,60);
			sprNoText("G:",64,148,62);
			sprNoText("B:",124,148,64);
			if (col[cur]<0)
				r=g=b=0;
			else {
				r=col[cur]&31;
				g=(col[cur]>>5)&31;
				b=(col[cur]>>10)&31;
			}
			while (1) {
				sprNoPrint(r,66,3,44,148);
				sprNoPrint(g,69,3,104,148);
				sprNoPrint(b,72,3,164,148);
				((u16*)OBJ_PLTT)[cur+128]=r|(g<<5)|(b<<10);
				objPut((cur-left)+1,4+((cur-left)<<2),138,768+(cur<<1),OAM_SIZE_8x8,-1,0,0);
				VBlankIntrWait();
				if (keyTrg & AB_BUTTON)
					break;
				if (keyCnt>5) {
					if (keyCur & L_KEY) { r=(r+31)&31; keyCnt=0; }
					if (keyCur & R_KEY) { r=(r+1)&31; keyCnt=0; }
					if (keyCur & U_KEY) { g=(g+1)&31; keyCnt=0; }
					if (keyCur & D_KEY) { g=(g+31)&31; keyCnt=0; }
					if (keyCur & L_BUTTON) { b=(b+31)&31; keyCnt=0; }
					if (keyCur & R_BUTTON) { b=(b+1)&31; keyCnt=0; }
				} else
					keyCnt++;
			}
			if (keyTrg & A_BUTTON)
				col[cur]=r|(g<<5)|(b<<10);
			((u16*)OBJ_PLTT)[cur+128]=col[cur];
		}
	}
	clearSprites();
	if (keyTrg & A_BUTTON) {
		for(i=j=0;i<128;i++) {
			if (!j && (col[i]>=0)) {
				pal->col[i]=col[i];
				pal->maxcnt=i;
				((u16*)PLTT)[i]=col[i];
			} else {
				pal->col[i]=0;
				j=1;
			}
		}
		while (pal->maxcnt<2)
			pal->col[pal->maxcnt+1]=pal->col[pal->maxcnt++];
		return 0;
	}
	return -1;
}

s32 menu(struct TJulia *j)
{
	s32 i=0,k,m,cnt,last;
	char *names[NO_SLOTS];
	do {
		clearSprites();
		i=doMenu(menuMain,3,138,4,i);
		switch (i) {
			case 0 :			
				last=0;
				while (1) {
					showMenu(menuMain,3,138,4,0);
					if (curFractal<0) {
						k=doMenu(menuFile2,2,148,40,last);
						last=k;
						if (k==1) k=2;
					} else {
						k=doMenu(menuFile,3,148,40,last);
						last=k;
					}
					if (k<0)
						break;
					if (k==1) {
						saveFractal(j,curFractal);
						return 0;
					}
					cnt=0;
					for(m=!k?0:NO_PREDEF_FRACTALS;m<NO_SLOTS;m++)
						names[cnt++]=fractalslot[m].name;
					m=selectFile(names,cnt,k);
					if (m<0)
						continue;
					if (!k) {
						loadFractal(j,m);
						return 1;
					}
					m+=NO_PREDEF_FRACTALS;
					strcpy(j->name,fractalslot[m].name);
					saveFractal(j,m);
					return 0;
				}
				break;				
			case 1 :
				last=0;
				while (1) {
					showMenu(menuMain,3,138,4,1);
					if (curPalette<0) {
						k=doMenu(menuPalette2,3,148,40,last);
						last=k;
						if (k==2) k=3;
					} else {
						k=doMenu(menuPalette,4,148,40,last);
						last=k;
					}
					if (k<0)
						break;					
					switch (k) {
						case 0 :
							k=changePalette(&j->pal);
							if (k>=0)
								return 2;
							break;
						case 2 :
							savePalette(&j->pal,curPalette);
							return 0;
						default :
							cnt=0;
							for(m=(k==1)?0:NO_PREDEF_PALETTES;m<NO_SLOTS;m++)
								names[cnt++]=palslot[m].name;
							m=selectFile(names,cnt,k-1);
							if (m<0)
								break;
							if (k==1) {
								loadPalette(&j->pal,m);
								return 2;
							}
							m+=NO_PREDEF_PALETTES;
							strcpy(j->pal.name,palslot[m].name);
							savePalette(&j->pal,m);
							return 0;
					}
				}
				break;
			case 2 :
				if (!doOptions(menuOptions,2,148,40,j)) {
					clearSprites();
					return 2;
				}
				break;
		}
	} while (i>=0);
	clearSprites();
	return 0;
}

void AgbMain(void)
{
	s32 i=0,j,x,y,size,mode=0,curline=0,cnt,doZoom,first=1;
	char s[64];
	u8 buf[256];
	struct TJulia julia;

	init();

	loadFiles();	

	loadFractal(&julia,0);

	while (1) {
		if (first) {
			sprNoText("FRACTAL ZOOMER",4,138,4);
			sprNoText("  - BY JIMMY M]RDELL",4,148,44);	
		}
		mandelbrot(&julia);
		if (first) {
			waitKeyDelay(30,AB_BUTTON);
			first=0;
		}

		//sprNoPrint(frameCnt,0,4,230,4);

		x=WIDTH>>1;
		y=HEIGHT>>1;
		size=WIDTH;
		while (1) {
			doZoom=0;
#ifdef AUTO_UPDATE
			if (mode)
				do {
					i=lineUpdate[interlace][curline];
					frameCnt=0;
					cnt=*(vu16*)REG_VCOUNT;
					DOMANDEL(julia.YRMin+i*julia.YDif,buf,&julia,julia.XRMin,julia.XRMax,julia.XDif);
					cnt=*(vu16*)REG_VCOUNT-cnt;
					if (frameCnt)
						cnt=228;
					if (++curline==HEIGHT)
						curline=0;
					CpuCopy(buf,VRAM+(i+YOFS)*240+XOFS,WIDTH,16);
				} while (*(vu16*)REG_VCOUNT+cnt<150);
#endif
			VBlankIntrWait();
			clearSprites();
			i=4;
			if (julia.type) {
				switch (julia.type) {
					case 1 : i=sprNoText("JULIA SET z[+c",4,138,i); break;
					case 2 : i=sprNoText("JULIA SET z\\+c",4,138,i); break;
				}
				s[0]='c'; s[1]='=';
				decPrint(s+2,Div(((julia.real+8)>>4)*1000,(PRECISION_MUL>>4)),' ','-',3);
				decPrint(s+8,Div(((julia.imag+8)>>4)*1000,(PRECISION_MUL>>4)),'+','-',3);
				s[14]='i';
				s[15]=0;
				i=sprNoText(s,4,148,i);
			} else {
				i=sprNoText("MANDELBROT SET",4,138,i);
			}

			j=Div(julia.zoom*size,WIDTH);
			if ((j>0) && (julia.XDif>0)) {
				j=Div(DEFAULT_ZOOM,j);
				s[0]='Z'; s[1]=':';
				digPrint(s+2,j,6);
				s[8]=':'; s[9]='1';
				s[10]=0;
				i=sprNoText(s,148,138,i);
			} else
				i=sprNoText("       ---",148,138,i);

			if (!julia.type)
				mode=0;

			if (!mode) {
				i=sprNoText("CHANGE ZOOM",148,148,i);
				box(XOFS+x-(size>>1),YOFS+y-Div((size>>1)*HEIGHT,WIDTH),size,Div(size*HEIGHT,WIDTH));
			}	else
				i=sprNoText("CHANGE c",148,148,i);

			if (mode) {
				i=(keyCur & B_BUTTON)?8:12;
				if (keyCur & L_KEY) julia.real-=(PRECISION_MUL>>i);
				if (keyCur & R_KEY) julia.real+=(PRECISION_MUL>>i);
				if (keyCur & U_KEY) julia.imag-=(PRECISION_MUL>>i);
				if (keyCur & D_KEY) julia.imag+=(PRECISION_MUL>>i);
			} else {
				if (keyCur & L_KEY) x--;
				if (keyCur & R_KEY) x++;
				if (keyCur & U_KEY) y--;
				if (keyCur & D_KEY) y++;
				if (keyCur & R_BUTTON) size+=2;
				if ((keyCur & L_BUTTON) && (size>16)) size-=2;
			}
			if (keyTrg & SELECT_BUTTON) mode=!mode;

			if (!mode && (keyTrg & A_BUTTON)) { doZoom=1; break; }
			if (!mode && (keyTrg & B_BUTTON) && (histlen>0)) { doZoom=1; break; }
			if (keyTrg & START_BUTTON) {
				clearSprites();
				i=menu(&julia);
				if (i==1) {
					x=WIDTH>>1;
					y=HEIGHT>>1;
					size=WIDTH;
					histlen=0;
				}
				if (i)
					break;
			}
		}
		VBlankIntrWait();
		if (doZoom) {
			if (!mode && ((keyCur & AB_BUTTON)==AB_BUTTON)) {
				if (histlen>0) {
					julia.cx=history[histlen=0].cx;
					julia.cy=history[histlen].cy;
					julia.zoom=history[histlen].zoom;
				}
			} else if (!mode && (keyCur & B_BUTTON) && (histlen>0)) {
				julia.cx=history[--histlen].cx;
				julia.cy=history[histlen].cy;
				julia.zoom=history[histlen].zoom;
			} else {
				if (histlen<HISTORY_MAXLEN) {
					history[histlen].cx=julia.cx;
					history[histlen].cy=julia.cy;
					history[histlen++].zoom=julia.zoom;
				}
				julia.cx+=(x-(WIDTH>>1))*julia.XDif;
				julia.cy+=(y-(HEIGHT>>1))*julia.YDif;
				julia.zoom=Div(julia.zoom*size,WIDTH);
			}
		}

		for(i=FIRST_BOX_SPRITE;i<128;i++)
			objRemove(i);
	}
}
