#include "armfunc.h"

extern void doMandel12_ROM(u32, u8*, struct TJulia*);
extern void doMandel24_ROM(u32, u8*, struct TJulia*, s32, s32, s32);

const void (*doMandel12)(u32, u8*, struct TJulia*) = (const void (*)(u32, u8*, struct TJulia*))doMandel12_ROM;
const void (*doMandel24)(u32, u8*, struct TJulia*, s32, s32, s32) = (const void (*)(u32, u8*, struct TJulia*, s32, s32, s32))doMandel24_ROM;
