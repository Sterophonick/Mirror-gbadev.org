#ifndef _MAIN_H
#define _MAIN_H

#include <Agb.h>
#include "intr.h"

#define MAX_NAME_LEN 14

struct TPal
{
	s32 maxcnt;
	u16 col[128];
	char name[MAX_NAME_LEN+1];
};

struct TJulia
{
	s32 type; // 0 = mandelbrot, 1 = julia (z^2), 2 = julia (z^4)
	s32 cx,cy;
	s32 real,imag;
	s32 zoom;
	struct TPal pal;
	char name[MAX_NAME_LEN+1];
	s32 XRMin,XRMax,XDif;
	s32 YRMin,YRMax,YDif;
};

struct TZoom
{
	s32 cx,cy;
	s32 zoom;
};

extern const u16 font_Palette[32];

extern OamData OamBak[128];
extern s32 frameCnt;

#endif
