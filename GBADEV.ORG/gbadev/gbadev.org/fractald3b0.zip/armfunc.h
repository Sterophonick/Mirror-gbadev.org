#ifndef _armfunc_h
#define _armfunc_h

#include <agb.h>

#include "main.h"

const void (*doMandel12)(u32, u8*, struct TJulia*);
const void (*doMandel24)(u32, u8*, struct TJulia*, s32, s32, s32);

#endif
