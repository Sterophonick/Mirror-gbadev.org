#include <agb.h>
#include "sprno.h"
#include "main.h"
#include "font_LZ.h"

u32 sprNoPal,sprNoChar;

void sprNoPrint(s32 i, u32 first, u32 len, u32 x, u32 y)
{
	u32 j,minus=0;
	j=first;
	if (i<0) {
		i=-i;
		minus=1;
	}
	do {
		OamBak[j].VPos=y;
		OamBak[j].HPos=x;
		OamBak[j].Pltt=sprNoPal;
		OamBak[j].ColorMode=0;
		OamBak[j].AffineMode=0;
		OamBak[j].Priority=0;
		OamBak[j].ObjMode=0;
		OamBak[j++].CharNo=sprNoChar+16+i%10;
		x-=8;
		i/=10;
		len--;
	} while ((i>0) && (len>minus));
	if (minus) {
		OamBak[j].VPos=y;
		OamBak[j].HPos=x;
		OamBak[j].Pltt=sprNoPal;
		OamBak[j].ColorMode=0;
		OamBak[j].AffineMode=0;
		OamBak[j].Priority=0;
		OamBak[j].ObjMode=0;
		OamBak[j++].CharNo=sprNoChar+13;
		len--;
	}
	while (len-->0)
		OamBak[j++].VPos=160;
}

s32 sprNoText(char *s, s32 x, s32 y, s32 n)
{
	while (*s) {
		if (*s>=' ') {
			OamBak[n].VPos=y;
			OamBak[n].HPos=x;
			OamBak[n].Pltt=sprNoPal;
			OamBak[n].ColorMode=0;
			OamBak[n].AffineMode=0;
			OamBak[n].Priority=0;
			OamBak[n].ObjMode=0;
			OamBak[n++].CharNo=sprNoChar+*s-' ';
			x+=8;
		}
		s++;
	}
	return n;
}

void sprNoInit(u32 pal, u32 charno)
{
	sprNoPal=pal;
	sprNoChar=charno;
	CpuFastArrayCopy(font_Palette,OBJ_PLTT+(pal<<5));
 	LZ77UnCompVram(font_LZ,(void*)(OBJ_MODE0_VRAM+(charno<<5)));
}
