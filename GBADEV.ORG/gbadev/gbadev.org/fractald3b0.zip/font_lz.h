#ifndef _font_lz_h
#define _font_lz_h

extern const u8 font_LZ[];

#endif
