#ifndef _INTR_H
#define _INTR_H

typedef void (*IntrFuncp)(void);

void intrInit(void);
void IntrDummy(void);
void VBlankIntr(void);
void VBlankProcess(void);
void HBlankIntr(void);
void VCounterIntr(void);
void setModeSwitch(void*,void*);
void clearModeSwitch(void);

extern IntrFuncp IntrTable[14];
extern IntrFuncp VBlankHandler,VBlankHandler2,PlasmaHandler,TutHandler,HBlankHandler,VCounterHandler;

#endif
