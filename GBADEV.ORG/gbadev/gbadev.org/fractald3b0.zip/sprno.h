#ifndef _sprno_h
#define _sprno_h

void sprNoPrint(s32, u32, u32, u32, u32);
void sprNoInit(u32, u32);
s32 sprNoText(char *s, s32 x, s32 y, s32 n);

extern u32 sprNoPal,sprNoChar;

#endif
