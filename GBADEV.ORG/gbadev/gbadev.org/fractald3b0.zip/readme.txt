FRACTAL ZOOMER
--------------
Explore the amazing world of fractals on your Game Boy Advance
with this neat little program!

Please read the tutorial below - it explains all the features in this
program!

FEATURES
--------
* Explore three different kinds of fractals:
   - Mandelbrot set
   - Julia set (c=z^2)
   - Julia set (c=z^4)
* Change fractal settings (Julia sets) and watch the fractal "morph"!
* Zooming with history, up to 160,000:1 scale without losing precision!!
* Create your own palettes
* Load and save your favourite fractals and palettes to SRAM!

TUTORIAL
--------
When turning on the GBA, the most famous of all fractals, the
Mandelbrot Set, will be loaded with a burning red-yellow palette.

The blue, bottom part of the screen is the status bar. Here you can
see what kind of fractal is being shown, the zoom factor as well as in
what mode you are in. Notice it reads "MANDELBROT SET", the current
fractal, as well as "Z 1:1" which is the zoom factor - no zoom at all
that is!

Lets start with changing the palette. Press the START button to enter
the menu. Use the D-pad and the A button to select a menu option. The
B button will bring you back to the previous menu (and also cancel any
changes you've made).

Now select PALETTE -> LOAD. A list of palettes will be shown. Select
the (RED-GREEN) palette. You will immediately leave the menu system
and return to the main screen with the fractal redrawn with the new
palette.

Now lets zoom! Hold down the left shoulder button to decrease the
white box which is used to select what area to enlarge. Decrease the
size of the box so the scale (shown in the statusbar) is 4:1. It's
most interesting to explore the Mandelbrot Set near the "edge", so use
the D-pad to move the box so it centers around a spot at the edge. Now
press A to actually do the zoom. Cool huh? The time it takes to update
the fractal depends on the zooming factor, but more importantly, where
in the fractal you zoom.

You can now continue to zoom in on any spot you wish. The maximum zoom
factor is 160000:1! If you press B you will return to the previous
zooming (can be repeated) and if you press A and B at the same time,
you will zoom out to the original view.

When you have found a nice close-up of the fractal, lets save it!
Press START, select FILE, SAVE AS and then select any empty slot (the
first one will do). Entering a file name is a bit cumbersome due to
the lack of a keyboard: you press UP/DOWN to change letter and
LEFT/RIGHT to move the cursor. Press A to save and B to cancel. Note:
an empty file name is not allowed.

Now turn off your GBA, and then turn it on again. Enter the menu,
select FILE -> LOAD. Press down two times, and you should find your
saved entry! Press A to load it. All entries starting in paranthesis
are presaved entries and cannot be overwritten.

Lets see what other fractals there are. Open (FILE -> LOAD) the
fractal "(DEF JULIA3)". Note that the top row of the status bar now
reads "JULIA SET z^2+c". This is another type of fractal, a Julia Set,
which is very similiar to the Mandelbrot Set in the construction (and
yet so different, *sigh* :) )

A Julia Set is made up of a single constant (the c in the equation)
which can be changed. In the loaded fractal it's 0.300+0.600i (a
complex number). By pressing SELECT, you will switch from "change
zoom" mode to "change c" mode (not available when exploring the
Mandelbrot Set, since there's no constant involved then). The constant
is change using the D-pad. Play around with it and watch the fractal
change! Pretty nice, huh!? Hold down B while pressing the D-pad to
speed up the change.

If you managed to "destroy" the fractal by choosing a bad constant
(most constants will not produce a nice looking fractal), reload the
fractal (FILE -> LOAD again), before continuing.

Now lets play around with the palette a bit more. If you want to
explore the edges, it might be interesting to check out the
BLACK&WHITE palette. Do that! (PALETTE -> LOAD -> (BLACK&WHITE)) Looks
pretty crazy, don't you think!?

Lets create a custom palette! There's no grayscale palette presaved,
so lets make one. Choose PALETTE -> CHANGE. Now you'll see a list of
colors. The list contains at most 128 colors (not all of them visible
at the same time). Notice the non-colored squares. These are the
unused colors, which means that if some pixel in the fractal ought to
have color 40 (which is uncolored in the black&white palette), it will
be given the highest indexed colored, in this case 32 (which is
black). Important: the less colors you use, the faster the fractal
will be generated!! The more you zoom, the more colors will be used
(if enough colors are defined that is).

Press the left shoulder button to clear the palette. Make sure the
blinking cursor is to the left (color 0) and press SELECT. Change the
color using the D-pad and the shoulder buttons. Select color R: 31 G: 31
B: 31 (white) by pressing left, down and the left shoulder button
and then press A. Now select color 32 (or somewhere close to 32) by
holding down RIGHT on the D-pad, and make it black (press SELECT and
then A). Then press the right shoulder button - magic!! The colors
between the colors you selected are filled, fading from the leftmost
color to the rightmost. If you had selected more than two colors, this
will work as well, filling all the unused colors with the appropriate
color. This makes it very easy to create your own palettes.

Now press A and watch the fractal with this new palette! If you like
it, you can save it the same way you saved the fractal (PALETTE ->
SAVE).

Finally, lets check out the OPTIONS menu. There are currently only two
options - REFRESH and FRACTAL. Use UP/DOWN to switch between options,
and LEFT/RIGHT to change an option).

The REFRESH option controls how the screen is updated. The default is
interlaced, which creates the pretty cool "morphing" effect when
changing the c constant in a Julia Set. If you don't like this, you
can change it to "TOP-DOWN" which, of course, updates the screen in a
more regular fashion. Note: this option is a global option.

FRACTAL controls which type of fractal to show. There are three
different types, as explained in the features section above. We
haven't yet checked out the Julia Set z^4=c fractal. There are less
nice-looking fractals of this type than z^2=c, and they also take
slightly more time to generate. Check out the presaved fractal (DEF
JULIA2) to see how they can look like.

Well, that's all folks!


Comments
--------
Please feel free to send comments, suggestions or whatever to
Jimmy M�rdell <jimmy@yarin.se> or talk to me on IRC, #gbadev
on EFnet, where I use the handle Yarin.
