//---------------------------------------------//
//  Legend (TITLE SCREEN) by The_Letter_M      //
//  Code borrowed from many                    //
//  www.gbadev.com sources                     //
//---------------------------------------------//

#include "gba.h"     // defines the GBA registers
#include "tree.h"   // contains all tile graphics in an array...
#include "sprites.h" // contains all sprite graphics
#include "flowerpos.h"  // contains the positions of all the flowers...

#define OAM     ((Sprite*)0x07000000)   // Setup pointer to OAM ram

typedef struct _Sprite { u16 Attrib0, Attrib1, Attrib2, RotateScale; } Sprite;


// VSYNC function by Eloist
void WaitForVSync()
{
  __asm
   {
    mov 	r0, #0x4000006
    scanline_wait:
     ldrh	r1, [r0]
     cmp	r1, #160
    bne 	scanline_wait
   }
}


void C_Entry()
{


  u16 i,x,y;                      // define temporary variables
  u8 temp, flight, flowercounter = 0, birdcounter = 0;    // define counters
  

  u16 *tpal=(u16*)0x05000000; // background palette pointer
  u16 *spal=(u16*)0x5000200;  // sprite palette pointer
  u8 *tiles=(u8*)0x06004000; // tiles pointer
  u16 *map0=(u16*)0x06000000; // tile map pointer
  u8 *sprites=(u8*)0x06010000; // sprite tiles pointer
  

  REG_BG0CNT =  0x0084;      // tiles @ x6004000, map @ x6000000
  REG_DISPCNT = 0x1140;	     // mode 0, 32x32 tile map, display BG0 and sprites

  for (i=0;i<treepallen;i++) {
    tpal[i]=treepal[i];  // copy across backgroundpalette data
  }

  for (i=0;i<spritepallen;i++) {
    spal[i]=spritepal[i];  // copy across sprite palette data
  }
  
  for (i=0;i<treedatalen;i++) {
    tiles[i]=treedata[i]; //load the bg tiles into the correct address
  }


  for (i=0;i<spritedatalen;i++) {
    sprites[i]=spritedata[i]; //load the sprite tiles into the correct address
  }


  for (x=0;x<30;x++) {
    for (y=0;y<20;y++) {
      map0[y*32+x] = treemap[y*30+x];
    }
  }




  while (1) {


    flowercounter++;
    if (flowercounter>14) flowercounter = 0;


    if (flowercounter == 0) {
      for (i=0;i<flowerlen;i++) {
        temp = flowerdata[i][2];
        if (temp > 1) {
          flowerdata[i][2]--;
        };
        
        OAM[i].Attrib0 = flowerdata[i][1] | 0x2000;  // 40 down, 8x8 sprite, 256 palette
        OAM[i].Attrib1 = flowerdata[i][0];  // 8x8 sprite
        if (temp > 5) {
          OAM[i].Attrib2 = 0;
        }
        else {
          OAM[i].Attrib2 = ((temp + (5*flowerdata[i][3]))*2);
        };
      };

    };


    birdcounter++;
    if (birdcounter>15) birdcounter = 0;



    if (birdcounter==0) {
      for (i=0;i<birdlen;i++) {
      
        temp = birddata[i][2];
        if (temp > 0) {
          birddata[i][2]--;
        }
        else {
          birddata[i][2]=3;
        };
        if (temp == 3) temp = 1;

        flight = birddata[i][3];
        if (flight > 0) {
          birddata[i][3]--;
        }
        else {
          birddata[i][3]=flightlen-1;
        };

        OAM[i+30].Attrib0 = birddata[i][1] + flightdata[flight][0] | 0x2000;  // 40 down, 8x8 sprite, 256 palette
        OAM[i+30].Attrib1 = birddata[i][0] + flightdata[flight][1] ;  // 8x8 sprite
        OAM[i+30].Attrib2 = (temp + 16)*2;
      };

    };





    WaitForVSync();


  }


   

}