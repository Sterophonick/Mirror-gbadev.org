
This is my first GBA demo.  It was designed as a "Title Screen" to a game I've been working
on.  

It's been tested on the IGBA emulator.  I have no idea if it runs on real hardware.

Thanks to all source code contributors who I've borrowed lots of little pieces.  Thanks all.
Also thanks for the pcx2gba program which was a HUGE help and also to AGENTQ for his
techincal documentation.  Even if it is a little out of date!

Sorry this demo is so simple, but it is pretty :)

A game will be coming soon, I promise!


The_Letter_M
hallmb@yahoo.com