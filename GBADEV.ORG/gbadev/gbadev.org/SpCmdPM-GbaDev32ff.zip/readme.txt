Readme.txt
*
* Space Commander Pac-Man  (v1.0)
*
2/10/2003

Programmer: Aaron Shadis (shadis@mindspring.com)

This is my FIRST game on the GBA.  The last game I wrote was on the Apple IIe in 1988.  (I've been busy with other things for a while!)  I really wanted to try writing games on the GBA, so I threw together the first things that came to my mind... Pac-Man & Space Invaders.  The rest of the game grew from there.

Please reply to my email with any comments, criticisms, or praises about the game.  I'd love to hear for you.

I have only tested this game with Boycott Advance.  If anyone plays it on an actual GBA, let me know how it goes.

Gameplay:
D-pad - Move Pac-Man left or right.
A button - Shoot

GamePlay:
There are 6 difficulty levels in the game based on the score.  Each level adds a new ghost and new ghost behaviors.


Special Thanks to www.gbajunkie.co.uk for his tutorials on GBA Development and all the contributes to www.gbadev.org for many examples.



