1945

Programmed by Samuel Adolfsson (man][ac @efnet, #gbadev)
Graphics by Ari Feldman, make sure to visit http://www.arifeldman.com
Music by Andreas Samuelsson, Jimmy Fredriksson

Description:
One level of a simple 2d shoot 'em up.
More levels will be made if enough people wants it!

Source might be released later on.
