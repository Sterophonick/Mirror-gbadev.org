#include <allegro.h>



#include <stdio.h>
FILE *f;
BITMAP *input;
PALLETE temppal;
void print_instructions(void)
{
    printf("My sprite making program v0.2\n");
    printf("Usage:\n swapcol <num1> <num2> sprite1.bmp sprite2.bmp \n");
    printf("where sprite2.bmp will be the same as sprite1.bmp\n");
    printf("except <num1> and <num2> will be swapped around in the palette\n");
    printf("note the .bmp will appear identical if loaded into say psp\n");
    printf("I use this to move a different colour to slot 0 so I can make\n");
    printf("that colour transparent!!\n");
}




main(int argc, char *argv[])
{
    RGB temp;
    int loop1,loop2,i;
    int option,col1,col2;
    allegro_init();
    install_keyboard();
    if(argc<4) print_instructions(); else
    {
        input=load_bitmap(argv[3],temppal);
        col1=atoi(argv[1]);
        col2=atoi(argv[2]);
        if(!input) fprintf(stderr,"Couldn't load file: %s\nDoes it exist? Is it a valid file?\n",argv[3]);
        else
        {
            for(loop1=0;loop1<=(*input).w-1;loop1++)
            {
                for(loop2=0;loop2<=(*input).h-1;loop2++)
                {
                    if(getpixel(input,loop1,loop2)==col1)
                    {
                        putpixel(input,loop1,loop2,col2);
                    }
                    else
                    {
                        if(getpixel(input,loop1,loop2)==col2)
                        {
                            putpixel(input,loop1,loop2,col1);
                        }
                    }

                }
            }

        }
        
    temp.r=temppal[col1].r;
    temp.g=temppal[col1].g;
    temp.b=temppal[col1].b;
    temppal[col1].r=temppal[col2].r;
    temppal[col1].g=temppal[col2].g;
    temppal[col1].b=temppal[col2].b;
    temppal[col2].r=temp.r;
    temppal[col2].g=temp.g;
    temppal[col2].b=temp.b;
    save_bitmap(argv[4],input,temppal);
    }
    
    for(i = 0; i <= argc; i++)
        fprintf(stderr,"arg %d: %s\n", i, argv[i]);
    return 0;
}


