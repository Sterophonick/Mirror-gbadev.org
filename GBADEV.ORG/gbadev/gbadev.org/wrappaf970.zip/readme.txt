12:09 PM 8/7/02

by Bitfox

This is a demo of my two optimized memory managers: TileMem and Scroller. 

TileMem is a tile manager that can dynamically transfer 65k unique tiles into and out of VRAM. Under maximum load conditions, it can allocate 896 simultaneous tiles in VRAM, which is more than enough to use a tile background as a bitmap! 

Scroller is a map manager that can handle any sized map with dimensions equalling 4B. It's been tested through a range of scroll increments from 1 pixel to 16 pixels (two tiles) at high speeds.

This demo uses a set of 63 tiles managed by one TileMem and a 1028x320 pixel map which is shared by 4 Scrollers mapping to each background in Mode 0.