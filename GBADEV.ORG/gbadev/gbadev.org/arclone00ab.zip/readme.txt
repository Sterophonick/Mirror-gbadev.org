-------------------------
Arkanoid Demo
-------------------------

File:		Arclone.bin
Date:		08 - 08 - 2002
Program:		Arkanoid Demo/Clone
Author:		Johan Jansen (Jenswa)
Contact:		awsnej@hotmail.com
Site:		http://www.geocities.com/flashsite_jrj/gba (could be down)
		

-----------------------------
About this bin-file:

This is my seventh demo produced for the gba, it has only been tested with VisualBoyAdvance.
It's a clone of the classic arkanoid game in my style and has five levels to play.
The code could be more optimized, but i don't know much of the language,
only the simple pieces of code.

I am sorry for not releasing the code , as i am currently working on this project.


---------------
Features:

Start screen, yeah!
32x16, 16x16 and 8x8 sprites.
Moving paddle.
Moving ball (with simple bounce code)
Single press
Primitive collision detection
MOSAIC effect
pause button
Gameover screen

------------------
Debugging:

For debugging, i use visualboyadvance :P, great emulator!
And read all the error messages i get during compiling :P


----------------
Thanks to:

Forgotten (VisualBoyAdvance)
Jason Wilkins (Dev-Kit Advance)
Eloist (gba.h)
GBAjunkie (tutorial, dovoto, dispcnt.h, sprite_info.h)
Dovoto (pcx2sprite, dispcnt.h, sprite_info.h, mosaic.h!) 
Nokturn (lot's of things)
GBADEV.org (they have lots of sources and updates around gba, always usefull)
devrs.com/gba (Jeff Frohweins gba development page)
Loirak Development (thanks to them, I discovered how the start screen works!)
Warder1 (for his tile editor)
Brian Sowers (used his keypad.h instead of Nokturns and he helped me with detecting a single press)
AnthC(his example for splitting up integers)


---------
Links:

These are some helpfull links if you are a gba beginner, just like me.

http://www.gbadev.org
http://www.devrs.com/gba
http://www.gbaemu.com/gba
http://www.gbajunkie.co.uk
http://www.loirak.com
http://www.gamedev.net
http://www.thepernproject.com


----------------
Jenswa


-----------------
Disclaimer:
This game is freeware. This software is provided 'as is' with no warranty or guarantees of
any kind, you use this software at your own risk. You accept all responsibility for any 
damage caused as a result of using this software. The author is not liable for any costs 
incurred as a result of using this software.

