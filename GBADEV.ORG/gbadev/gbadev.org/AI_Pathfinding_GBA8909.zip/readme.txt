////////////////////////////////////////////////////////////////////
//
// Games AI ICA Implementation Build Directory Readme File
// Author: Brian Davis
// Date: 31/03/2005
//
////////////////////////////////////////////////////////////////////

AI Pathfinding Instructions:

The main AI features of the implementation include real-time pathfinding for units, and Finite-State Transition Networks (FSTN) to define their behaviour. A waypoint system was also implemented in the real-time search module to simplify the pathfinding.

User Input:

The user input description (below) is separated into columns to show the functionality mapped to the default keys in the VisualBoyAdvance emulator and the Game Boy Advance (GBA) hardware buttons.

Emulator 	GBA	Functionality

Up arrow	Up	Move Cursor Up.
Down arrow	Down	Move Cursor Down.
Left arrow	Left	Move Cursor Left.
Right arrow	Right	Move Cursor Right.
Enter		Start	Start/Pause Game.
Z		A	Attack Command.
X		B	Move Command.
