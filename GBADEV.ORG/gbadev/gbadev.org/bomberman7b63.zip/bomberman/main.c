// The Main HAM Library
#include "mygba.h"
#include <stdlib.h>

// Graphics Includes
#include "gfx/sprite_bomber.raw.c"
#include "gfx/sprite_bomber.pal.c"

/*********************/
#include "gfx/sprite_bomber_ennemi.raw.c"

#include "gfx/carre.raw.c"
#include "gfx/carre2.raw.c"
#include "gfx/carre3.raw.c"


#include "gfx/bg1.raw.c"
#include "gfx/bg1.pal.c"
#include "gfx/bg1.map.c"

#include "gfx/game_over.pal.c"
#include "gfx/game_over.raw.c"
#include "gfx/winner.pal.c"
#include "gfx/winner.raw.c"

//#include "gfx/game_over.map.c"



// Defines    
#define ANIM_DOWN  0
#define ANIM_RIGHT 1
#define ANIM_UP    2
#define ANIM_LEFT  3

//timings
#define BOMBE_DEADLINE  60000
#define FLAME_DEADLINE  10000

// structure bomber

struct bomber {
	u32 objNumber;	//numero de l'objet dans OAM
	u8 x;		// position x
	u8 y;		// position y
	u8 nvx;		// nouvelle position x
	u8 nvy;		// nouvelle position y
	u8 offsetg;	// debut (gauche) du sprite dans son bloc 16*32
	u8 offsetd;	// fin (droite) sprite ds le bloc 16*32
	u8 offseth;  	// debut (haut) du sprite dans son bloc 16*32
	u8 offsetb;	// fin (bas) sprite ds le bloc 16*32
	u8 mvt;		// en mouvement/a l'arret
	u8 dir;		// direction
	u8 nvdir;	// nouvelle direction
	u8 framescnt;	// compteur de frames
	u8 animcnt;	// compteur des animations
};

struct bombe {
	struct bombe * next;
	u32 objNumber;	//numero de l'objet dans OAM
	u8 x;		// position x
	u8 y;		// position y
	u16 deadline;  //explose quand deadline=0;
	u8 framescnt;	// compteur de frames
	u8 animcnt;	// compteur des animations

};


struct master_flame {
	
	struct master * next_master;
	struct micro_flame * micro ;
	u8 length;			// position x		// position y
	u16 deadline;
	
	};
	
struct micro_flame
{	struct micro_flame * next;
	u8 objNumber;
	u8 x;
	u8 y;
};
	
/*****************************************************
 VARIABLES GLOBALES
 *****************************************************/

struct bombe *bombelist_begin=0;	//debut de la liste de bombe;
struct bombe *bombelist_end=0;	//dernier element de la liste de bombe;

struct master_flame * flamelist_begin=0;
struct master_flame * flamelist_end=0;

int nb_bombes=0;
int nb_flames=0;

int breakable_map[10][15];


u32 array_spot = 0; // Stores the location of the sprite's current image
u32 carre; 		// Sprite index for the bomber
u8 vivant=1;

struct bomber bomber1;

struct bomber ennemi;
int distance_move_ennemi=0;
int direction=0;
int nombre_deplacement=0;


/*map convention
1=mur
2=bombe
3=flame
4=mur cassable*/

u8 Map[10][15] =  {1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,
		   1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,
		   1,0,0,0,4,4,0,0,4,0,0,0,0,4,1,
		   1,4,1,0,1,4,1,0,1,0,1,0,1,0,1,
		   1,4,4,4,4,4,4,4,4,0,4,4,0,4,1,
		   1,0,1,4,1,0,1,0,1,0,1,4,1,0,1,
		   1,0,0,0,4,0,0,4,0,0,0,4,0,0,1,
		   1,4,1,0,1,0,1,0,1,0,1,0,1,0,1,
		   1,0,0,4,0,0,0,0,0,4,0,0,0,0,1,
		   1,1,1,1,1,1,1,1,1,1,1,1,1,1,1
		} ;
                  


 

// Function Prototypes
void vblFunc(); 	// VBL function
void query_keys(); 	// Query the keyboard
void redraw_bomber(); 	// Redraws the falling block
void check_deadline();	//parcours la liste des bombe et les fait exploser si elle sont pretes
struct master_flame * create_flame(u8 x, u8 y, u8 length);
void update_bomblist(struct bombe * b);
void set_map(u8 x, u8 y, u8 value);
void deplacer_ennemi();
void redraw_ennemi();
u8 check_map(u8 x, u8 y);
int checkMoveMap();
void check_collision_bomber_ennemi();
int checkMoveMap_ennemi();
void clean_all();
void init_breakable_map();
int tirer_nombre(int min,int max);
int time();
void check_flame_deadline();
void update_flamelist(struct master_flame * masf);
void delete_flame(struct micro_flame * micf);
void deinit_breakable_map();


// Main function
int main()
{
//debut:
	/**********init bomberman**********/
	bomber1.dir = ANIM_DOWN;
	bomber1.framescnt = 0;
	bomber1.animcnt = 0;
	bomber1.x=16;
	bomber1.y=16;
	bomber1.nvx=16;
	bomber1.nvy=16;

	bomber1.offseth=18;
	bomber1.offsetb=28;
	bomber1.offsetg=4;
	bomber1.offsetd=12;
	bomber1.mvt= 0;
	
	/**********init ennemi**********/
	ennemi.dir = ANIM_UP;
	ennemi.framescnt = 0;
	ennemi.animcnt = 0;
	ennemi.x=208;
	ennemi.y=112;
	ennemi.nvx=64;
	ennemi.nvy=64;

	ennemi.offseth=18;
	ennemi.offsetb=28;
	ennemi.offsetg=4;
	ennemi.offsetd=12;
	ennemi.mvt= 0;
	
	map_fragment_info_ptr mymap;
	
	// Initialize HAMlib
	ham_Init();

	// Setup the background mode to 1: tiles 0,1,2 2 is rotating + scalling
	ham_SetBgMode(0);
	ham_InitText(0);

	// Initialize the palettes
	ham_LoadObjPal(&sprite_bomber_Palette, 256);  	// Sprite palette
	//ham_LoadObjPal16(&carre)
	ham_LoadBGPal(&bg1_Palette,256); 		// Background palette
	
	// Initialize the rotating background
 	ham_bg[1].ti = ham_InitTileSet(&bg1_Tiles, SIZEOF_16BIT(bg1_Tiles),1,1);
	// init an empty map
	ham_bg[1].mi = ham_InitMapEmptySet(3,0);

	// make a reference to Map data in the ROM
	mymap = ham_InitMapFragment(&bg1_Map,30,20,0,0,30,20,0);

	// copy (in this case the whole) map to BG1 at x=0 y=0
	ham_InsertMapFragment(mymap,1,0,0);

  	// Display the background
	ham_InitBg(1,1,1,0);
	
	// Setup the array spot
	array_spot = (2048 * bomber1.dir) + (512 * bomber1.animcnt);  	

	// Setup the bomber
	bomber1.objNumber = ham_CreateObj((void *)&sprite_bomber_Bitmap[array_spot],2,2,OBJ_MODE_NORMAL,1,0,0,0,0,0,0,bomber1.x,bomber1.y);

	ennemi.objNumber = ham_CreateObj((void *)&sprite_bomber_ennemi_Bitmap[array_spot],2,2,OBJ_MODE_NORMAL,1,0,0,0,0,0,0,ennemi.x,ennemi.y);
	
	init_breakable_map();

bombelist_begin=0;
bombelist_end=0;

srand(time(NULL));


	// Start the VBL interrupt handler
  	ham_StartIntHandler(INT_TYPE_VBL,&vblFunc);
	while(vivant==1)
	{
		query_keys();
		if(distance_move_ennemi==0)
		{
			distance_move_ennemi=tirer_nombre(1,7)*16;
		}
		deplacer_ennemi();

		check_collision_bomber_ennemi();

		check_deadline();

		check_flame_deadline();

		// Infinite loop to keep the program running
	}
	
	deinit_breakable_map();
	clean_all();	
	
	ham_DeInitBg(0);
	ham_SetBgMode(4);
	
	if(vivant==0){
	ham_LoadBGPal(&game_over_Palette,SIZEOF_16BIT(game_over_Palette));
	TOOL_DMA1_SET(&game_over_Bitmap,
	MEM_BG_PTR,
	SIZEOF_32BIT(game_over_Bitmap),
	DMA_TRANSFER_32BIT,
	DMA_STARTAT_NOW); 
	}
	else
	{
	ham_LoadBGPal(&winner_Palette,SIZEOF_16BIT(winner_Palette));
	TOOL_DMA1_SET(&winner_Bitmap,
	MEM_BG_PTR,
	SIZEOF_32BIT(winner_Bitmap),
	DMA_TRANSFER_32BIT,
	DMA_STARTAT_NOW);
	}
	
	while(!F_CTRLINPUT_START_PRESSED){}
	ham_StopIntHandler(INT_TYPE_VBL);

	return EXIT_SUCCESS; 
} // End of main()


// VBL function
void vblFunc()
{
	ham_CopyObjToOAM(); // Copy bomber sprite to hardware
	//ham_DrawText(1,1,"ecart %d",bomber1.nvx-bomber1.x);
	
		int test = checkMoveMap();
		if ((test == 1) || (test == 4)) { // on garde l'ancienne position
			bomber1.nvx = bomber1.x;
			bomber1.nvy = bomber1.y;
		}
		else if(test==3)
		{
			ham_SetObjVisible(bomber1.objNumber,0);
			vivant=0;
		}
		else{	bomber1.x = bomber1.nvx;
			bomber1.y = bomber1.nvy;
	}
	redraw_bomber(); // Redraw the bomber
	
	int test2=checkMoveMap_ennemi();
	if ((test2 == 1 || test2==4) ) {
			direction=tirer_nombre(0,4);
			ennemi.nvx = ennemi.x;
			ennemi.nvy = ennemi.y;
	}
	else if(test2==3){
	ham_SetObjVisible(ennemi.objNumber,0);
	vivant=2;
	}
	else{	ennemi.x = ennemi.nvx;
		ennemi.y = ennemi.nvy;
	}
	redraw_ennemi();
	return;
	
} // End of vblFunc()


// Query the keyboard
void query_keys()
{
	if(F_CTRLINPUT_A_PRESSED)	{

		struct bombe * b;
		b=malloc(100);
		
		(*b).x=(((bomber1.x+bomber1.offsetg + bomber1.x+bomber1.offsetd)/2)/16)*16;		// s'arranger pour se mettre dans le bon carre precisement
 		(*b).y=((((bomber1.y+bomber1.offseth + bomber1.y+bomber1.offsetb)/2)/16))*16;
		
		if(check_map((*b).x/16,(*b).y/16)!=0)
			free(b);
		else
		{
		set_map((*b).x/16,(*b).y/16,2);
		nb_bombes++;
		(*b).next=0;
		
		(*b).objNumber=ham_CreateObj((void *)&carre2_Bitmap[0],0,1,OBJ_MODE_NORMAL,1,0,0,0,0,0,0,(*b).x,(*b).y);
		(*b).deadline=BOMBE_DEADLINE;
		
		update_bomblist(b);
		}
		
	}
	// UP only
	if(F_CTRLINPUT_UP_PRESSED && !F_CTRLINPUT_RIGHT_PRESSED && !F_CTRLINPUT_LEFT_PRESSED)
	{
		bomber1.nvy = bomber1.y - 1;
		bomber1.nvx = bomber1.x;
		bomber1.nvdir = ANIM_UP;
		bomber1.mvt = 1;
		return;
	}

	// RIGHT only
	if(F_CTRLINPUT_RIGHT_PRESSED && !F_CTRLINPUT_UP_PRESSED && !F_CTRLINPUT_DOWN_PRESSED)
	{
		bomber1.nvy = bomber1.y;
		bomber1.nvx = bomber1.x + 1;
		bomber1.nvdir = ANIM_RIGHT;
		bomber1.mvt = 1;
		return;
	}
	
	// DOWN only
	if(F_CTRLINPUT_DOWN_PRESSED && !F_CTRLINPUT_RIGHT_PRESSED && !F_CTRLINPUT_LEFT_PRESSED)
	{
		bomber1.nvy = bomber1.y + 1;
		bomber1.nvx = bomber1.x;
		bomber1.nvdir = ANIM_DOWN;
		bomber1.mvt = 1;
		return;
	}

	// LEFT only
	if(F_CTRLINPUT_LEFT_PRESSED && !F_CTRLINPUT_UP_PRESSED && !F_CTRLINPUT_DOWN_PRESSED)
	{
		bomber1.nvy = bomber1.y;
		bomber1.nvx = bomber1.x - 1;
		bomber1.nvdir = ANIM_LEFT;
		bomber1.mvt = 1;
		return;
	}
		
	// A l'arret
	bomber1.mvt = 0;
	
} // End of query_keys()

void deplacer_ennemi()
{
	if(distance_move_ennemi==0){direction=tirer_nombre(0,4);}

	
	// UP only
	if(direction==0)
	{
		ennemi.nvy = ennemi.y - 1;
		ennemi.nvx = ennemi.x;
		ennemi.nvdir = ANIM_UP;
		ennemi.mvt = 1;
		if(nombre_deplacement<17)nombre_deplacement++;
		return;
	}

	// RIGHT only
	if(direction==1)
	{
		ennemi.nvy = ennemi.y;
		ennemi.nvx = ennemi.x + 1;
		ennemi.nvdir = ANIM_RIGHT;
		ennemi.mvt = 1;
		if(nombre_deplacement<17)nombre_deplacement++;
		return;
	}
	
	// DOWN only
	if(direction==2)
	{
		ennemi.nvy = ennemi.y + 1;
		ennemi.nvx = ennemi.x;
		ennemi.nvdir = ANIM_DOWN;
		ennemi.mvt = 1;
		if(nombre_deplacement<17)nombre_deplacement++;
		return;
	}

	// LEFT only
	if(direction==3)
	{
		ennemi.nvy = ennemi.y;
		ennemi.nvx = ennemi.x - 1;
		ennemi.nvdir = ANIM_LEFT;
		ennemi.mvt = 1;
		if(nombre_deplacement<17)nombre_deplacement++;
		return;
	}

	return;
}



// Redraws the bomber
void redraw_bomber()
{
	// Make sure to set the (new) bomber co-ordinates
	ham_SetObjX(bomber1.objNumber,bomber1.x);
	ham_SetObjY(bomber1.objNumber,bomber1.y);
	
	// Bomberman a l'arret
	
	if ((bomber1.mvt == 0) || (bomber1.nvdir != bomber1.dir)  ) {
		bomber1.framescnt = 0;
		bomber1.animcnt = 0;
	}
	else { // bomber en mvt sur la meme direction
		if ((bomber1.framescnt ++) >= 10 ){
			bomber1.framescnt = 0;
			bomber1.animcnt = (bomber1.animcnt+1)%4;	
		} 
	}
	array_spot = (2048 * bomber1.dir) + (512 * bomber1.animcnt);
	ham_UpdateObjGfx(bomber1.objNumber,(void*)&sprite_bomber_Bitmap[array_spot]);

	bomber1.dir = bomber1.nvdir;	
	return;
} // End of redraw_bomber()

void redraw_ennemi()
{
	ham_SetObjX(ennemi.objNumber,ennemi.x);
	ham_SetObjY(ennemi.objNumber,ennemi.y);
	
	// Bomberman a l'arret
	
	if ((ennemi.mvt == 0) || (ennemi.nvdir != ennemi.dir)  ) {
		ennemi.framescnt = 0;
		ennemi.animcnt = 0;
	}
	else { // bomber en mvt sur la meme direction
		if ((ennemi.framescnt ++) >= 10 ){
			ennemi.framescnt = 0;
			ennemi.animcnt = (ennemi.animcnt+1)%4;	
		} 
	}
	array_spot = (2048 * ennemi.dir) + (512 * ennemi.animcnt);
	ham_UpdateObjGfx(ennemi.objNumber,(void*)&sprite_bomber_ennemi_Bitmap[array_spot]);
	
	/*test si le sprite ennemi s'est d�plac� d'une case*/
	if(nombre_deplacement==17)
	{
		distance_move_ennemi=distance_move_ennemi-16;
		nombre_deplacement=0;
	}
	ennemi.dir = ennemi.nvdir;	
	return;
}




int checkMoveMap() {
	switch (bomber1.nvdir) {
		case ANIM_UP :
			if (Map[(bomber1.nvy + bomber1.offseth)/16][(bomber1.nvx + bomber1.offsetg)/16] == 1) return 1;
			else return (Map[(bomber1.nvy + bomber1.offseth)/16][(bomber1.nvx + bomber1.offsetd)/16]);
		case ANIM_DOWN :
			if (Map[(bomber1.nvy + bomber1.offsetb)/16][(bomber1.nvx + bomber1.offsetg)/16] == 1) return 1;
			else return (Map[(bomber1.nvy + bomber1.offsetb)/16][(bomber1.nvx + bomber1.offsetd)/16]);
		case ANIM_LEFT :
			if (Map[(bomber1.nvy + bomber1.offseth)/16][(bomber1.nvx + bomber1.offsetg)/16] == 1) return 1;
			else return (Map[(bomber1.nvy + bomber1.offsetb)/16][(bomber1.nvx + bomber1.offsetg)/16]);
		case ANIM_RIGHT :
			if (Map[(bomber1.nvy + bomber1.offseth)/16][(bomber1.nvx + bomber1.offsetd)/16] == 1) return 1;
			else return (Map[(bomber1.nvy + bomber1.offsetb)/16][(bomber1.nvx + bomber1.offsetd)/16]);
		default :
			return 0;
	}
}

void check_collision_bomber_ennemi(){
 		
	int centre_bomber_x=(((bomber1.x+bomber1.offsetg + bomber1.x+bomber1.offsetd)/2)/16)*16;
	int centre_bomber_y=((((bomber1.y+bomber1.offseth + bomber1.y+bomber1.offsetb)/2)/16))*16;
	int centre_ennemi_x=(((ennemi.x+ennemi.offsetg + ennemi.x+ennemi.offsetd)/2)/16)*16;
	int centre_ennemi_y=((((ennemi.y+ennemi.offseth + ennemi.y+ennemi.offsetb)/2)/16))*16;

	int distance_bomber_ennemi=(centre_bomber_x-centre_ennemi_x)*(centre_bomber_x-centre_ennemi_x)+(centre_bomber_y-centre_ennemi_y)*(centre_bomber_y-centre_ennemi_y);
		
	if (distance_bomber_ennemi<=225){ham_SetObjVisible(ennemi.objNumber,0);vivant=0;}
}

int checkMoveMap_ennemi() {
	switch (ennemi.nvdir) {
		case ANIM_UP :
			if (Map[(ennemi.nvy + ennemi.offseth)/16][(ennemi.nvx + ennemi.offsetg)/16] == 1) return 1;
			else return (Map[(ennemi.nvy + ennemi.offseth)/16][(ennemi.nvx + ennemi.offsetd)/16]);
		case ANIM_DOWN :
			if (Map[(ennemi.nvy + ennemi.offsetb)/16][(ennemi.nvx + ennemi.offsetg)/16] == 1) return 1;
			else return (Map[(ennemi.nvy + ennemi.offsetb)/16][(ennemi.nvx + ennemi.offsetd)/16]);
		case ANIM_LEFT :
			if (Map[(ennemi.nvy + ennemi.offseth)/16][(ennemi.nvx + ennemi.offsetg)/16] == 1) return 1;
			else return (Map[(ennemi.nvy + ennemi.offsetb)/16][(ennemi.nvx + ennemi.offsetg)/16]);
		case ANIM_RIGHT :
			if (Map[(ennemi.nvy + ennemi.offseth)/16][(ennemi.nvx + ennemi.offsetd)/16] == 1) return 1;
			else return (Map[(ennemi.nvy + ennemi.offsetb)/16][(ennemi.nvx + ennemi.offsetd)/16]);
		default:
		return 0;
	}
}

//parcourir la liste de bombe en decrementant le deadline

void check_deadline() 
{	
	struct bombe * temp;
	temp=bombelist_begin;
	
	if(bombelist_begin!=0)
	{
	while( temp!=0)
	{	
		(*temp).deadline--;
	
		if ((*temp).deadline==0 || (*temp).deadline>65000)
		{	
			ham_DeleteObj((*temp).objNumber);
			set_map((*temp).x/16,(*temp).y/16,0);
			struct master_flame * address=create_flame((*temp).x,(*temp).y,2);
			update_flamelist(address);
			nb_bombes--;
			
			bombelist_begin=(*temp).next;
			free(temp);
			temp=bombelist_begin;
			if (nb_bombes==1)
				bombelist_end=temp;
			if (nb_bombes==0)
				bombelist_end=0;
		}
		else
		{
		
			temp=(*temp).next;
		}
				
		
	}	
	}
	
}

void check_flame_deadline() 
{	
	

	
	struct master_flame * temp;
	temp=flamelist_begin;
		
	if(flamelist_begin!=0)
	{
	while( temp!=0)
	{	
		(*temp).deadline--;
	
		if ((*temp).deadline==0 || (*temp).deadline>65000)
		{				
			delete_flame((*temp).micro);
			nb_flames--;			
			
			flamelist_begin=(*temp).next_master;
			free(temp);
			temp=flamelist_begin;
			if (nb_flames==1)
				flamelist_end=temp;
			if (nb_flames==0)
				flamelist_end=0;
		}
		else
		{
		
			temp=(*temp).next_master;
		}
				
		
	}
	
	}
	
}


//ajoute la bombe pass�e en parametre a la fin de la liste de bombe
void update_bomblist(struct bombe * b)
{
	//update liste
		if(bombelist_end!=0)
		//on fait pointer l'avant derniere bombe sur la derniere
			(*bombelist_end).next=b;
			
		
		bombelist_end=b; //on met a jour le pointeur de fin de liste
		
		if(bombelist_begin==0) 
		//si la liste etait vide on fait pointer le debut de la liste sur la nouvelle bombe
			bombelist_begin=b;
	
}

void update_flamelist(struct master_flame * masf)
{
	//update liste
		if(flamelist_end!=0)
		//on fait pointer l'avant derniere bombe sur la derniere
			(*flamelist_end).next_master=masf;
			
		
		flamelist_end=masf; //on met a jour le pointeur de fin de liste
		
		if(flamelist_begin==0) 
		//si la liste etait vide on fait pointer le debut de la liste sur la nouvelle bombe
			flamelist_begin=masf;
	
}

//faire une macro
u8 check_map(u8 x, u8 y)
{
	
	return Map[y][x];
}

//faire une macro
void set_map(u8 x, u8 y, u8 value)
{
	
	Map[y][x]=value;
}

//cree des flammes centree sur les coordonees x et y, de longueur length
//ca marche !! 
struct master_flame * create_flame(u8 x, u8 y, u8 length)
{
	nb_flames++;
	struct master_flame * masf;
	masf=malloc(100);
	(*masf).length=length;
	(*masf).deadline=FLAME_DEADLINE;
	(*masf).next_master=0;
	
	//create center flame
	struct micro_flame * micf;
	struct micro_flame * previous;	
	micf=malloc(100);
	(*micf).x=x;
	(*micf).y=y;
	(*micf).objNumber=ham_CreateObj((void *)&carre_Bitmap[0],0,1,OBJ_MODE_NORMAL,1,0,0,0,0,0,0,(*micf).x,(*micf).y);
	(*micf).next=0;
	(*masf).micro=micf;
	set_map((*micf).x/16,(*micf).y/16,3);
	
	//create other flames 
	previous=micf;
	u8 dir,index;
	for(dir=0;dir<4;dir++)
	{
		for(index =1; index<=length; index++)
		{
			micf=malloc(100);
			switch(dir)
			{
				case 0:
				{
					(*micf).x=x;
					(*micf).y=y-(index*16);
					break;
					
				}
				case 1:
				{
					(*micf).x=x+(index*16);
					(*micf).y=y;
					break;
			
					
				}
				case 2:
				{
					(*micf).x=x;
					(*micf).y=y+(index*16);
					break;
					
				}
				case 3:
				{
					(*micf).x=x-(index*16);
					(*micf).y=y;
					break;
					
				}
			}//end switch
				int value=check_map((*micf).x/16,(*micf).y/16);
				if(value==0 || value==2)
				{	
					(*previous).next=micf;
					previous=micf;
					(*micf).next=0;
					(*micf).objNumber=ham_CreateObj((void *)&carre_Bitmap[0],0,1,OBJ_MODE_NORMAL,1,0,0,0,0,0,0,(*micf).x,(*micf).y);
					set_map((*micf).x/16,(*micf).y/16,3);	
				
				}
				else
				{
					if(value==4)
					{
						set_map((*micf).x/16,(*micf).y/16,0);
						ham_DeleteObj(breakable_map[(*micf).y/16][(*micf).x/16]);
						breakable_map[(*micf).y/16][(*micf).x/16]=0;

					}
					index=length+1;
				}
		}//end for
	
}//end for

	return masf;

}//end create_flame

void delete_flame(struct micro_flame * micf)
{	struct micro_flame * micf2;
	while(micf!=0)
	{	micf2=(*micf).next;
		ham_DeleteObj((*micf).objNumber);
		set_map((*micf).x/16,(*micf).y/16,0);
		free(micf);
		micf=micf2;
	}
}

/*Tirage al�atoire d'un nombre dans l'intervalle [min,max-1]*/
int tirer_nombre(int min,int max)
{
	double intervalle=max-min;
	double tirage=min + (rand()*intervalle)/(RAND_MAX+1.0);
	return (int)(tirage);
}

//affiche les briques cassables
void init_breakable_map()
{
	int i;
	int j;
	for(i=0; i<10;i++)
	{
		for(j=0;j<15;j++)
		{
			if(Map[i][j]==4)
			{
				breakable_map[i][j]=ham_CreateObj((void *)&carre3_Bitmap[0],0,1,OBJ_MODE_NORMAL,1,0,0,0,0,0,0,j*16,i*16);
			}else
			{
				breakable_map[i][j]=0;
			}
		}
	}
}

void deinit_breakable_map()
{
	int i;
	int j;
	for(i=0; i<10;i++)
	{
		for(j=0;j<15;j++)
		{	
			int value=breakable_map[i][j];
			if(value!=0)
			{
				ham_DeleteObj(value);
			}
		}
	}
}

void clean_all()
{
	struct bombe * temp1;
	struct bombe * temp2;
	struct master_flame * temp3;
	struct master_flame * temp4;
	
	temp1=bombelist_begin;
		
	//remove bombes
	if(bombelist_begin!=0)
	{
	
	while( temp1!=0)
	{	
		temp2=(*temp1).next;
		ham_DeleteObj((*temp1).objNumber);
		free(temp1);
		temp1=temp2;
		
				
	}//end while
	
	}
	
	temp3=flamelist_begin;
	
	if(flamelist_begin!=0)
	{
	
	while( temp3!=0)
	{	
		temp4=(*temp3).next_master;				
		delete_flame((*temp3).micro);
		free(temp3);
		temp3=temp4;
		
				
	}//end while
	
	}
	ham_DeleteObj(bomber1.objNumber);
	ham_DeleteObj(ennemi.objNumber);
}

