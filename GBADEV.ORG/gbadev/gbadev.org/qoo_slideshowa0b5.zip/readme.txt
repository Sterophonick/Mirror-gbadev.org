
Qoo Slideshow v1.0 - by Devon Hsiao
-----------------------------------

A little 12 image slideshow in mode 4.  

A: show image
B: back menu
UP,DOWN,RIGHT,LEFT: scroll image
Select: show small image

Runs on several emulators and hardware.


devon@ms48.url.com.tw

PictureBoy - http://www.dig-life.idv.tw:8080/~devon/