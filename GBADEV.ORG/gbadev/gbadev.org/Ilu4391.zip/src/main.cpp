////////////////////////////////////////////////////////////////////////////////
//                                 main.cpp                                   //
////////////////////////////////////////////////////////////////////////////////
//                       file including the entry point                       //
//                                                                            //
//                         Last update: 16/05/2005                            //
//                             @ HardNULL 2002                                //
////////////////////////////////////////////////////////////////////////////////

#include <math.h>
#include <string.h>
#include "gba/gba.h"
#include "gba/sprite.h"
#include "gba/screenmode.h"
#include "gba/interupts.h"
#include "gba/keypad.h"

#include "snd/GbaPlayer.h"

#include "efectos.h"
#include "printxy.h"

#include "gfx/notlicensed.h"
#include "gfx/credix.h"
#include "gfx/apagaordena.h"

// Show a gfx into screen, should be in any other place, too lazy tho...

void MostrarPantallitaFadeMode4(u32 *bitmap, u32 *paleta, int num_cols, int pos_y, int alto, int tiempo)
{
    SetMode(MODE_4|BG2_ENABLE|OBJ_MAP_1D|OBJ_ENABLE);
    REG_BLDMOD = (1<<13)|(1<<6)|(1<<2);
    REG_COLEV = (8<<8)|0;
    aMemSet32((u32*)VideoBuffer, 0, 240*160/4);
    aMemCpy32((u32*)(VideoBuffer+(pos_y*240/2)), (u32*)bitmap, 240*alto/4);
    aMemCpy32((u32*)BGPaletteMem, (u32*)paleta, num_cols/2);

    int intensidad = 0;

    // aparece
    while (intensidad<17)
    {
        REG_COLEV = (8<<8)|intensidad;
        for (int i=0; i < 3; i++)
            WaitForFullVsync();
        intensidad++;
    }
    
    // se queda un instante
    for (int i=0; i < tiempo; i++)
        WaitForFullVsync();
        
    // y desaparece
    while (intensidad>0)
    {
        REG_COLEV = (8<<8)|intensidad;
        for (int i=0; i < 3; i++)
            WaitForFullVsync();
        intensidad--;
    }

    aMemSet32((u32*)VideoBuffer, 0, 240*160/4);
    REG_BLDMOD = 0;
}

// same as the former one, this time in mode 3

void MostrarPantallitaFadeMode3(u32 *bitmap, int tiempo)
{
    SetMode(MODE_3|BG2_ENABLE|OBJ_MAP_1D|OBJ_ENABLE);
    REG_BLDMOD = (1<<13)|(1<<6)|(1<<2);
    REG_COLEV = (8<<8)|0;
    aMemCpy32((u32*)(VideoBuffer), (u32*)bitmap, 240*160/2);

    int intensidad = 0;

    // aparece
    while (intensidad<17)
    {
        REG_COLEV = (8<<8)|intensidad;
        for (int i=0; i < 3; i++)
            WaitForFullVsync();
        intensidad++;
    }
    
    // se queda un instante
    for (int i=0; i < tiempo; i++)
        WaitForFullVsync();
        
    // y desaparece
    while (intensidad>0)
    {
        REG_COLEV = (8<<8)|intensidad;
        for (int i=0; i < 3; i++)
            WaitForFullVsync();
        intensidad--;
    }

    aMemSet32((u32*)VideoBuffer, 0, 240*160/2);
    REG_BLDMOD = 0;
}

int main(void)
{
    u16 loop;

    // Set ROM speed
    //*((volatile u16 *)0x04000204) |= 0x0014;
    *((u16 *)0x04000204) &= (1<<15);
    *((u16 *)0x04000204) |= (1<<14)|(6<<8)|(6<<5)|(5<<2)|2;

    ////////////////////////////////////////////////////////////////
    // tipica pantallita de semos ilegales

    MostrarPantallitaFadeMode4((u32*)notlicensed, (u32*)notlicensedPalette, 16, 74, 12, 100);

    ////////////////////////////////////////////////////////////////
    // Inicializaci�n global
    
    //calculate my divide look up table so I can use the property x/y = x*(1/y) = x*div[y]
    for (loop=0;loop <256;loop++)
    {
        DIV[loop] = (FIXED)( (1<<16)/loop); //our fixed point divide table is 8.24 (24 bits of fraction)
    }

    // precalculos imprescindibles y preparacion del GBAND
    InicializarEfectos();

    // preparamos la fuente para los printf's
    printxy_init();
    
    // load mocule
    InicializarMusica1();

    // play
    EnableInterupts(INT_DMA1|INT_VBLANK);
    InicializarMusica2();

    ////////////////////////////////////////////////////////////////
    // main bucle
    
    gTiempo = aClock();
    //gTiempo -= 93*60;
    //u16 gCnt = 0;
    gCnt = 0;
    while (gTablaGeneral[gCnt].Datos.in != NULL)
    {
        InitializeSprites();
        gTablaGeneral[gCnt].Funcion.Reservar (gCnt);
        while (gTablaGeneral[gCnt].Datos.Parte > 0)
        {
            while (_NULL_event())
//            while (1)
            {
//                gTablaGeneral[gCnt].Funcion.Actualizar (gCnt);
                gTablaGeneral[gCnt].Funcion.Renderizar (gCnt);
            }
            gTablaGeneral[gCnt].Datos.Parte--;     // Siguiente parte o efecto            
        }
        SetMode(MODE_2);    // lo veo todo muy negro
        Liberar (gCnt);
        gCnt++;
    }        
    
    ////////////////////////////////////////////////////////////////
    // todo tiene su final...
    
    TerminarMusica();

    // credix
    MostrarPantallitaFadeMode4((u32*)credix, (u32*)credixPalette, 256, 0, 240, 100);

    // "apaga el ordenador y vete a la cama"
    // (credits goes to LucasFilm's Monkey Island)
    while (1)
    {
        MostrarPantallitaFadeMode4((u32*)apagaordena, (u32*)apagaordenaPalette, 16, 75, 9, 25);
    }    

    return 0;
}
