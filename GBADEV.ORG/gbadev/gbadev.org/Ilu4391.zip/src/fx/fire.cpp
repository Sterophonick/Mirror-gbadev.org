#include <stdio.h>
#include <stdlib.h>
#include <malloc.h>
#include <math.h>
#include "../gba/gba.h"
#include "../gba/screenmode.h"
#include "../gba/sprite.h"

#include "../efectos.h"
#include "../printxy.h"

#include "../gfx/fire.h"

typedef unsigned char BYTE;
typedef unsigned long DWORD;

typedef struct
{
    u32 intensidad, partedone;
}Tfire;

//////////////////////////////////////////////////
/////// ----- Metodos Principales ----- //////////
//////////////////////////////////////////////////

//////////////// Reservar /////////////////////////

inline u16 RGBto16(u16 R, u16 G, u16 B)
{
    return (B<<10)|(G<<5)|R;
}

void
fire_Reservar (DWORD ETG)
{
    Tfire *efecto;
    //u16 i;
   
    if ( !gTablaGeneral[ETG].Datos.Reservado )
    {
        efecto = (Tfire *) gTablaGeneral[ETG].Datos.in;
        gTablaGeneral[ETG].Datos.Reservado = 1;
      
        ////////////////////////////////////////////////////////////////
        // Inicializaci�n efecto
    
        SetMode(MODE_3|BG2_ENABLE|OBJ_MAP_1D|OBJ_ENABLE);

        // pintar fondo
        aMemCpy16((u16*)VideoBuffer, (u16*)fire, 240*160);
        
      	sprites[0].attribute0 = MODE_TRANSPARENT | COLOR_256 | SQUARE | (64+14); // y
        sprites[0].attribute1 = SIZE_64 | (96-8);   // x
    	sprites[0].attribute2 = PALETTE(0)|PRIORITY(0)|(512);   // bloques de 8x8x16-colores, este es el primero y ocupa 64/8 * 32/8 = 32 bloques

      	//sprites[1].attribute0 = MODE_TRANSPARENT | COLOR_256 | SQUARE | 64; // y
        //sprites[1].attribute1 = SIZE_64 | 16;   // x
    	//sprites[1].attribute2 = PALETTE(0)|PRIORITY(0)|(640);   // bloques de 8x8x16-colores, este es el primero y ocupa 64/8 * 32/8 = 32 bloques

        // 12 y 2 o 10 y 4
    	REG_BLDMOD = (1<<10)|(1<<6)|(1<<4);
    	REG_COLEV = (17<<8)|17;
    
        // Limpiamos el espacio destinado para el fuego
        aMemSet32((u32*)(OAMData+640*8*8/4), 0, 64*64/4);

/*
        // colocamos la paleta (si que va a acabar coloc� si XD
        for (int i = 0; i < 64; i++)
            OBJPaletteMem[i] = RGBto16(i/2, 0, 0);
        for (int i = 64; i < 128; i++)
            OBJPaletteMem[i] = RGBto16(31, (i-64)/2, 0);
        for (int i = 128; i < 192; i++)
            OBJPaletteMem[i] = RGBto16(31, 31, (i-128)/2);
        for (int i = 192; i < 240; i++)
            OBJPaletteMem[i] = RGBto16(31, 31, 31);
*/
        // colocamos la paleta (si que va a acabar coloc� si XD
        for (int i = 0; i < 32; i++)
            OBJPaletteMem[i] = RGBto16(i/2, 0, 0);
        for (int i = 32; i < 96; i++)
            OBJPaletteMem[i] = RGBto16(15, (i-32)/4, 0);
        for (int i = 96; i < 128; i++)
            OBJPaletteMem[i] = RGBto16(15, 15, (i-96));
        for (int i = 128; i < 160; i++)
            OBJPaletteMem[i] = RGBto16(15+((i-128)/2), 15+((i-128)/2), 31);
        for (int i = 160; i < 240; i++)
            OBJPaletteMem[i] = RGBto16(31, 31, 31);

        efecto->intensidad = 0;
        efecto->partedone = gTablaGeneral[ETG].Datos.Parte+1;

        WaitForVsync();
        CopyOAM();
    }
}

//////////////// Renderizar /////////////////////////

unsigned int
fire_Renderizar (DWORD ETG)
{
//    Tfire *efecto = (Tfire *) gTablaGeneral[ETG].Datos.in;

    // Renderizamos el fuego
    u8 *buffer = (((u8*)(OAMData+640*8*8/4)) + 2);
    for (int i=4; i < 60; i+=2)
    {
        int j = i-31;
        int altura = j*j/100;

        u8 color1 = rand8();
        u8 color2 = rand8();

        if (color1 > 239) color1 = 239;
        if (color2 > 239) color2 = 239;
        *((u16*)buffer + 32*(63-altura) + i/2) = ((color1<<8)|color2);
    }

    // Lineas restantes
    u16 *pbuf16 = (u16*)(buffer + 2);
    do {
        for (int i=1; i < 31; pbuf16++, i++)
        {
            s32 color1 = ( ( ((*(pbuf16)&(255<<8))>>8) + (*(pbuf16-1)&255) + (*(pbuf16)&255) +
                         ((*(pbuf16+32)&(255<<8))>>8) ) >> 2) - 1;
            if (color1 < 0) color1 = 0;
            s32 color2 = ( ( (*(pbuf16)&255) + ((*(pbuf16)&(255<<8))>>8) + ((*(pbuf16+1)&(255<<8))>>8) +
                         (*(pbuf16+32)&255) ) >> 2) - 2;
            if (color2 < 0) color2 = 0;
            *pbuf16 = ((color1)|(color2<<8));
            (*(pbuf16-32)) = (*pbuf16);
        }
        pbuf16 += 2;
    } while (pbuf16 < (u16*)(buffer + 64*(66-1)));

    // Copiamos el fuego en forma de sprite
    u16 *buffer16 = (OAMData+512*8*8/4);
    u16 *bufferCalculado = (OAMData+640*8*8/4);
    for (int j = 0; j < 8; j++)    // y por bloques
    {
        for (int i = 0; i < 8; i++)    // x por bloques
        {
            for (int k = 0; k < 8; k++)    // y por pixels dentro de un bloque
            {
                for (int l = 0; l < 4; l++)    // x por (2 pixels) dentro de un bloque
                {
                    *(buffer16++) = *(bufferCalculado+(j*4*8*8+k*4*8+i*4+l));
                }
            }
        }
    }

    return (0);    // Sincronizado con la musica
}

//////////////// Actualizar /////////////////////////

void
fire_Actualizar (DWORD ETG)
{
    Tfire *efecto = (Tfire *) gTablaGeneral[ETG].Datos.in;
    if (efecto->partedone >= gTablaGeneral[ETG].Datos.Parte)
    {
        efecto->partedone--;
        efecto->intensidad = 0;
        
        if (gTablaGeneral[ETG].Datos.Parte == 14)
        {
            printxy_clrscr();
            printxy(56, 30, "our hero", PRINTXY_TRANSPARENT|PRINTXY_MOSAIC);
        }
        else if (gTablaGeneral[ETG].Datos.Parte == 13)
        {
            printxy_clrscr();
            printxy(40, 30, "has a rest", PRINTXY_TRANSPARENT|PRINTXY_MOSAIC);
        }
        else if (gTablaGeneral[ETG].Datos.Parte == 12)
        {
            printxy_clrscr();
            printxy(32, 30, "by the fire", PRINTXY_TRANSPARENT|PRINTXY_MOSAIC);
        }
        else if (gTablaGeneral[ETG].Datos.Parte == 11)
        {
            printxy_clrscr();
            printxy(64, 30, "cooking", PRINTXY_TRANSPARENT|PRINTXY_MOSAIC);
        }
        else if (gTablaGeneral[ETG].Datos.Parte == 10)
        {
            printxy_clrscr();
            printxy(48, 30, "some shit", PRINTXY_TRANSPARENT|PRINTXY_MOSAIC);
        }
        else if (gTablaGeneral[ETG].Datos.Parte == 9)
        {
            printxy_clrscr();
            printxy(0, 30, "for the journey", PRINTXY_TRANSPARENT|PRINTXY_MOSAIC);
        }
        else if (gTablaGeneral[ETG].Datos.Parte == 8)
        {
            printxy_clrscr();
            printxy(32, 30, "that awaits", PRINTXY_TRANSPARENT|PRINTXY_MOSAIC);
        }
        else if (gTablaGeneral[ETG].Datos.Parte == 7)
        {
            printxy_clrscr();
            printxy(24, 30, "his powerful", PRINTXY_TRANSPARENT|PRINTXY_MOSAIC);
        }
        else if (gTablaGeneral[ETG].Datos.Parte == 6)
        {
            printxy_clrscr();
            printxy(32, 30, "magic steel", PRINTXY_TRANSPARENT|PRINTXY_MOSAIC);
        }
        else if (gTablaGeneral[ETG].Datos.Parte == 5)
        {
            printxy_clrscr();
            printxy(32, 30, "and singing", PRINTXY_TRANSPARENT|PRINTXY_MOSAIC);
        }
        else if (gTablaGeneral[ETG].Datos.Parte == 4)
        {
            printxy_clrscr();
            printxy(48, 30, "a song of", PRINTXY_TRANSPARENT|PRINTXY_MOSAIC);
        }
        else if (gTablaGeneral[ETG].Datos.Parte == 3)
        {
            printxy_clrscr();
            printxy(32, 30, "pride honor", PRINTXY_TRANSPARENT|PRINTXY_MOSAIC);
        }
        else if (gTablaGeneral[ETG].Datos.Parte == 2)
        {
            printxy_clrscr();
            printxy(16, 30, "and bloodshed", PRINTXY_TRANSPARENT|PRINTXY_MOSAIC);
        }
        else if (gTablaGeneral[ETG].Datos.Parte == 1)
        {
            printxy_clrscr();
            printxy(48, 30, "get going", PRINTXY_TRANSPARENT|PRINTXY_MOSAIC|PRINTXY_QUAKE);
        }
    }
    
    if (efecto->intensidad < 111) efecto->intensidad++;
    else printxy_clrscr();

    if ( efecto->intensidad > 80)
    {
        int intensi = (efecto->intensidad-80)/2;
        
        if ((gTablaGeneral[ETG].Datos.Parte & 3) == 0)
            SetMosaic(0, 0,intensi,0);
        else if ((gTablaGeneral[ETG].Datos.Parte & 3) == 1)
            SetMosaic(0, 0, 0, intensi);
        else if ((gTablaGeneral[ETG].Datos.Parte & 3) == 2)
            SetMosaic(0, 0, intensi, intensi);
        else SetMosaic(0, 0, intensi, 0);
    }
    else SetMosaic(0, 0, 0, 0);
}

//////////////// Terminar /////////////////////////

void
fire_Terminar (DWORD ETG)
{
    Tfire *efecto = (Tfire *) gTablaGeneral[ETG].Datos.in;

    if (efecto != NULL)
    {
        free (efecto);
    }
}

//////////////// Inicializar /////////////////////////

void
fire_Inicializar (DWORD ETG)
{
    Tfire *efecto = (Tfire *) malloc (sizeof(Tfire));
//    if (efecto == NULL) exit(-1); //NULL_Error ("Error: No Hay Suficiente Memoria para Water.\n");

    gTablaGeneral[ETG].Datos.in            = (Tfire *) efecto;
    gTablaGeneral[ETG].Datos.Parte         = 15;
    gTablaGeneral[ETG].Datos.Reservado     = 0;

    gTablaGeneral[ETG].Funcion.Reservar    = fire_Reservar;
    gTablaGeneral[ETG].Funcion.Renderizar  = fire_Renderizar;
    gTablaGeneral[ETG].Funcion.Actualizar  = fire_Actualizar;
    gTablaGeneral[ETG].Funcion.Terminar    = fire_Terminar;
}
