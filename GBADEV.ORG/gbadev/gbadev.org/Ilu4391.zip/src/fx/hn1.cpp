#include <stdio.h>
#include <stdlib.h>
#include <malloc.h>
#include <math.h>
#include "../gba/gba.h"
#include "../gba/screenmode.h"
#include "../gba/sprite.h"

#include "../efectos.h"
#include "../printxy.h"

// Sprites
#include "../gfx/hn1a.h"
#include "../gfx/hn1b.h"
#include "../gfx/hn1c.h"

struct letrerohn
{
    u16 x, y;
} letrerohn[16];

typedef unsigned char BYTE;
typedef unsigned long DWORD;

typedef struct
{
    FIXED alfax;
}Thn1;

#define numhns 16

//////////////////////////////////////////////////
/////// ----- Metodos Principales ----- //////////
//////////////////////////////////////////////////

//////////////// Reservar /////////////////////////

void
hn1_Reservar (DWORD ETG)
{
    Thn1 *efecto;
    u16 i;
   
    if ( !gTablaGeneral[ETG].Datos.Reservado )
    {
        efecto = (Thn1 *) gTablaGeneral[ETG].Datos.in;
        gTablaGeneral[ETG].Datos.Reservado  = 1;
      
        ////////////////////////////////////////////////////////////////
        // Inicializaci�n efecto
    
        SetMode(MODE_2|OBJ_MAP_1D|OBJ_ENABLE);
        
        u16 loop;
        // "limpiamos" el fondo
    	for(loop = 0; loop < 256; loop++)
    		BGPaletteMem[loop] = 0;
    
        //loop through and store the palette from your pict 
    	for(loop = 0; loop < 16; loop++)
    		OBJPaletteMem[loop] = hn1aPalette[loop];
    	for(loop = 0; loop < 16; loop++)
    		OBJPaletteMem[loop+16] = hn1bPalette[loop];
    	for(loop = 0; loop < 16; loop++)
    		OBJPaletteMem[loop+32] = hn1cPalette[loop];
        
        //InitializeSprites();
    
        for (i = 0; i < numhns; i++)
        {
          	sprites[3*i+0].attribute0 = MODE_TRANSPARENT | COLOR_16 | WIDE;
            sprites[3*i+0].attribute1 = SIZE_64;
        	sprites[3*i+0].attribute2 = PALETTE(0)|PRIORITY(0)|(0);   // bloques de 8x8x16-colores, este es el primero y ocupa 64/8 * 32/8 = 32 bloques
          	sprites[3*i+1].attribute0 = MODE_TRANSPARENT | COLOR_16 | WIDE;
            sprites[3*i+1].attribute1 = SIZE_64;
        	sprites[3*i+1].attribute2 = PALETTE(1)|PRIORITY(0)|(32);
          	sprites[3*i+2].attribute0 = MODE_TRANSPARENT | COLOR_16 | SQUARE;
            sprites[3*i+2].attribute1 = SIZE_32;
        	sprites[3*i+2].attribute2 = PALETTE(2)|PRIORITY(0)|(64);
        }
    	REG_BLDMOD = (1<<13)|(2<<6)|(1<<4);
    
        // Copiamos los sprites en si
    	for(i = 0; i < 64*32/4; i++)
    		OAMData[i] = (((u16)hn1a[4*i+3])<<12)|(((u16)hn1a[4*i+2])<<8)|(((u16)hn1a[4*i+1])<<4)|(((u16)hn1a[4*i+0])<<0);
    	for(i = 0; i < 64*32/4; i++)
    		OAMData[i+64*32/4] = (((u16)hn1b[4*i+3])<<12)|(((u16)hn1b[4*i+2])<<8)|(((u16)hn1b[4*i+1])<<4)|(((u16)hn1b[4*i+0])<<0);
    	for(i = 0; i < 32*32/4; i++)
    		OAMData[i+2*64*32/4] = (((u16)hn1c[4*i+3])<<12)|(((u16)hn1c[4*i+2])<<8)|(((u16)hn1c[4*i+1])<<4)|(((u16)hn1c[4*i+0])<<0);
    		
        efecto->alfax = (90<<16);
    }
}

//////////////// Renderizar /////////////////////////

unsigned int
hn1_Renderizar (DWORD ETG)
{
    Thn1 *efecto = (Thn1 *) gTablaGeneral[ETG].Datos.in;
  
//   ResX           = Water->ResX;
//   ResY           = Water->ResY;
//    u16 Parte       = gTablaGeneral[ETG].Datos.Parte;

    // asi conseguimos el efecto este chulo ^_^ (que co�aaaa :)
  	//REG_COLEV = (8<<8)|8;
  	REG_COLEV = (8<<8)|(((16-ABS((SIN[efecto->alfax>>16]*16)>>16))-1)>>1);
    int i = 100;
    while (--i) {};
    REG_COLEV = (8<<8)|((16-ABS((SIN[efecto->alfax>>16]*16)>>16))-1);

    return (0);    // Sincronizado con la musica
}

//////////////// Actualizar /////////////////////////

void
hn1_Actualizar (DWORD ETG)
{
    Thn1 *efecto = (Thn1 *) gTablaGeneral[ETG].Datos.in;
    FIXED alfax = efecto->alfax;
    u16 i;

    // Movemos los sprites
    FIXED incx = (SIN[alfax>>16]*16);
    alfax += (1<<15);
    if (alfax >= (360<<16)) alfax = 0;
    efecto->alfax = alfax;
    
	REG_COLEV = (8<<8)|((16-ABS(incx>>16))-1);
    for (i = 0; i < numhns; i++)    
    {
        letrerohn[i].x = 40+((incx*i)>>21)*((u16)pow(-1,i));
        letrerohn[i].y = 64;//-((incy*i)>>5);
    }

    for (i = 0; i < numhns; i++)
    {
      	sprites[3*i+0].attribute0 &= 65280; sprites[3*i+0].attribute0 |= letrerohn[i].y;
      	sprites[3*i+0].attribute1 &= 65024; sprites[3*i+0].attribute1 |= letrerohn[i].x;            
      	sprites[3*i+1].attribute0 &= 65280; sprites[3*i+1].attribute0 |= letrerohn[i].y;
      	sprites[3*i+1].attribute1 &= 65024; sprites[3*i+1].attribute1 |= letrerohn[i].x+64;
      	sprites[3*i+2].attribute0 &= 65280; sprites[3*i+2].attribute0 |= letrerohn[i].y;
      	sprites[3*i+2].attribute1 &= 65024; sprites[3*i+2].attribute1 |= letrerohn[i].x+128;
    }
}

//////////////// Terminar /////////////////////////

void
hn1_Terminar (DWORD ETG)
{
    Thn1 *efecto = (Thn1 *) gTablaGeneral[ETG].Datos.in;

    if (efecto != NULL)
    {
        free (efecto);
    }
}

//////////////// Inicializar /////////////////////////

void
hn1_Inicializar (DWORD ETG)
{
    Thn1 *efecto = (Thn1 *) malloc (sizeof(Thn1));
//    if (efecto == NULL) exit(-1); //NULL_Error ("Error: No Hay Suficiente Memoria para Water.\n");

    gTablaGeneral[ETG].Datos.in            = (Thn1 *) efecto;
    gTablaGeneral[ETG].Datos.Parte         = 1;
    gTablaGeneral[ETG].Datos.Reservado     = 0;

    gTablaGeneral[ETG].Funcion.Reservar    = hn1_Reservar;
    gTablaGeneral[ETG].Funcion.Renderizar  = hn1_Renderizar;
    gTablaGeneral[ETG].Funcion.Actualizar  = hn1_Actualizar;
    gTablaGeneral[ETG].Funcion.Terminar    = hn1_Terminar;
}
