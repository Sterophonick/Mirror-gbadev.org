#include <stdio.h>
#include <stdlib.h>
#include <malloc.h>
#include <string.h>
#include "../gba/gba.h"
#include "../gba/screenmode.h"
#include "../gba/backgrounds.h"
#include "../gba/sprite.h"

#include "../efectos.h"
#include "../printxy.h"

#define RESX 160
#define RESY 120


// Sprites

typedef unsigned char BYTE;
typedef unsigned long DWORD;

void A_rob_BlurMotion (u16 *buffer, u8 paso, u32 resx_por_resy);

typedef struct {
    u16 x,y;
    s8 lineas[4];   // una linea hasta cada vertice del siguiente trapecio
} Tpunto;

typedef struct {
    Tpunto vertices[4];
    Tpunto centro;
} TTrapecio;

typedef struct
{
    FIXED alfa;
    TTrapecio trapecios[3];
    u32 multx, doneup, donedown;
}Trob;

u16 *video;

void rob_Flip(void)
{
    if (REG_DISPCNT & BACKBUFFER) //back buffer is the current buffer so we need to switch it to the font buffer
    { 
        REG_DISPCNT &= ~BACKBUFFER; //flip active buffer to front buffer by clearing back buffer bit
        video = BackBuffer; //now we point our drawing buffer to the back buffer
    }
    else //front buffer is active so switch it to backbuffer
    { 
        REG_DISPCNT |= BACKBUFFER; //flip active buffer to back buffer by setting back buffer bit
        video = FrontBuffer; //now we point our drawing buffer to the front buffer
    }
}

void PolyFiller_Flat(Tpunto *vertA, Tpunto *vertB, Tpunto *vertC, u16 color, u16 *buf);
int Bresenham(int x0, int y0, int x1, int y1, u16 color, u16 *video);

//////////////////////////////////////////////////
/////// ----- Metodos Principales ----- //////////
//////////////////////////////////////////////////

//////////////// Reservar /////////////////////////

void
rob_Reservar (DWORD ETG)
{
    Trob *efecto;
//    u16 i;
   
    if ( !gTablaGeneral[ETG].Datos.Reservado )
    {
        efecto = (Trob *) gTablaGeneral[ETG].Datos.in;
        gTablaGeneral[ETG].Datos.Reservado  = 1;
      
        ////////////////////////////////////////////////////////////////
        // Inicializaci�n efecto
    
        setmode5flipped();
        SetMode(MODE_5|BG2_ENABLE|OBJ_MAP_1D|OBJ_ENABLE);
        memset(FrontBuffer, 0, RESX*RESY*sizeof(u16));
        memset(BackBuffer, 0, RESX*RESY*sizeof(u16));

        
        // empezamos pintando en el backbuffer y mostrando el frontbuffer
        video = BackBuffer;
        REG_DISPCNT &= ~BACKBUFFER;
        
        // inicializamos los valores de las lineas
        for (int i=0; i < 3; i++)
        for (int j=0; j < 4; j++)
        for (int k=0; k < 4; k++)
            efecto->trapecios[i].vertices[j].lineas[k] = 15;
            
        efecto->multx = 0;
        efecto->doneup = 5;
        efecto->donedown = 5;
    }
}

//////////////// Renderizar /////////////////////////

unsigned int
rob_Renderizar (DWORD ETG)
{
    Trob *efecto = (Trob *) gTablaGeneral[ETG].Datos.in;
    int i;
//    u16 Parte       = gTablaGeneral[ETG].Datos.Parte;
    TTrapecio trapeciostmp[3];
    memcpy(trapeciostmp, efecto->trapecios, 3*sizeof(TTrapecio));

    //memset(video, 0, 160*128*sizeof(u16));
    A_rob_BlurMotion (video, 6, RESX*RESY);

    // Pintamos los trapecios
    for (i=0; i<3; i++)
    {
        u16 color;
        if (i == 0)      color = (1<<15)|(25<<10)|(25<<5)|(17);
        else if (i == 1) color = (1<<15)|(23<<10)|(19<<5)|(20);
        else             color = (1<<15)|(13<<10)|(23<<5)|(23);
        
        //*(video + trapeciostmp[i].centro.y*RESX + trapeciostmp[i].centro.x) = 0xffff;
        //for (int j=0; j<4; j++)
        //    *(video + trapeciostmp[i].vertices[j].y*RESX + trapeciostmp[i].vertices[j].x) = ((31<<10)|(31<<5)|(0));

        PolyFiller_Flat(&(trapeciostmp[i].vertices[0]), &(trapeciostmp[i].vertices[1]), &(trapeciostmp[i].vertices[2]), color, video);
        PolyFiller_Flat(&(trapeciostmp[i].vertices[2]), &(trapeciostmp[i].vertices[3]), &(trapeciostmp[i].vertices[0]), color, video);
    }

    for (int i=0; i < 3; i++)
    for (int j=0; j < 4; j++)
    for (int k=0; k < 4; k++)
    {
        // elegimos el color
        u8 intensidad = (trapeciostmp[i].vertices[j].lineas[k]);
        u16 color;
        if (i == 1) color = (((24*intensidad)>>5)<<10)|(((22*intensidad)>>5)<<5)|((18*intensidad)>>5);
        else if (i == 2) color = (((18*intensidad)>>5)<<10)|(((21*intensidad)>>5)<<5)|((21*intensidad)>>5);
        else color = (((19*intensidad)>>5)<<10)|(((24*intensidad)>>5)<<5)|((20*intensidad)>>5);
        
        // pintamos la linea
        int imasuno = i+1;
        if (imasuno > 2) imasuno = 0;
        trapeciostmp[i].vertices[j].lineas[k] += Bresenham(trapeciostmp[i].vertices[j].x, trapeciostmp[i].vertices[j].y, trapeciostmp[imasuno].vertices[k].x, trapeciostmp[imasuno].vertices[k].y, color, video);
        
        // cambiamos el color
        if (trapeciostmp[i].vertices[j].lineas[k] > 31) trapeciostmp[i].vertices[j].lineas[k] = 31;
        else if (trapeciostmp[i].vertices[j].lineas[k] < 0) trapeciostmp[i].vertices[j].lineas[k] = 0;

    }

    rob_Flip();
    
    //printxy_clrscr();
    //printxy(50, 50, "an�oz", PRINTXY_QUAKE);
    //printxy(50, 80, "AN�OZ", PRINTXY_TRANSPARENT);

    return (0);    // Sincronizado con la musica
}

//////////////// Actualizar /////////////////////////

void
rob_Actualizar (DWORD ETG)
{
    Trob *efecto = (Trob *) gTablaGeneral[ETG].Datos.in;
    FIXED alfa = efecto->alfa;
    int i;

    int alfa2 = alfa;
    // Movemos los centros de los trapecios
    for (i=0; i<3; i++)
    {
        efecto->trapecios[i].centro.x = ((SIN[alfa2>>16]*45) >> 16) + (RESX>>1) + (rand8()&3)-2;
        efecto->trapecios[i].centro.y = ((COS[alfa2>>16]*35) >> 16) + (RESY>>1) + (rand8()&3)-2;
        
        alfa2 += (120<<16);
        if (alfa2 >= (360<<16)) alfa2 -= (360<<16);
    }

    // Movemos los v�rtices de los trapecios
    alfa2 = alfa;
    for (i=0; i<3; i++)
    {
        alfa2 = (i+1)*alfa;
        if (alfa2 >= (360<<16)) alfa2 -= (360<<16);
        if (alfa2 >= (360<<16)) alfa2 -= (360<<16);
        for (int j=0; j<4; j++)
        {
            efecto->trapecios[i].vertices[j].x = ((SIN[alfa2>>16]*(22 + (j&1)*11)) >> 16)
                    + efecto->trapecios[i].centro.x;
            efecto->trapecios[i].vertices[j].y = ((COS[alfa2>>16]*(15 + (j&1)*8)) >> 16)
                    + efecto->trapecios[i].centro.y;
                    
            alfa2 += (90<<16);
            if (alfa2 >= (360<<16)) alfa2 -= (360<<16);
        }
    }

    alfa += (1<<14);
    if (alfa >= (360<<16)) alfa = 0;
    efecto->alfa = alfa;
    
    // efectos paralelos
    if (gTablaGeneral[ETG].Datos.Parte < efecto->doneup)
    {    
        REG_BG2PA = 0;    // horizontal texture step in x
        REG_BG2PB = 256;    // vertical texture step in x
        REG_BG2PC = 128 - (efecto->multx+=8);  // horizontal texture step in y
        REG_BG2PD = 0;    // vertical texture step in y
        if (efecto->multx > 127) { efecto->doneup = gTablaGeneral[ETG].Datos.Parte; efecto->multx-=32; }
    }
    else if ( gTablaGeneral[ETG].Datos.Parte < efecto->donedown )
    {
        REG_BG2PA = 0;      // horizontal texture step in x
        REG_BG2PB = 256;    // vertical texture step in x
        REG_BG2PC = 128 - (efecto->multx-=8);    // horizontal texture step in y
        REG_BG2PD = 0;      // vertical texture step in y
        if (efecto->multx == 0) efecto->donedown = gTablaGeneral[ETG].Datos.Parte;
    }
}

//////////////// Terminar /////////////////////////

void
rob_Terminar (DWORD ETG)
{
    Trob *efecto = (Trob *) gTablaGeneral[ETG].Datos.in;

    if (efecto != NULL)
    {
        free (efecto);
    }
    unsetmode5flipped();
    REG_BG2PA = 256;  // horizontal texture step in x
    REG_BG2PB = 0;    // vertical texture step in x
    REG_BG2PC = 0;    // horizontal texture step in y
    REG_BG2PD = 256;  // vertical texture step in y
}

//////////////// Inicializar /////////////////////////

void
rob_Inicializar (DWORD ETG)
{
    Trob *efecto = (Trob *) malloc (sizeof(Trob));
//    if (efecto == NULL) exit(-1); //NULL_Error ("Error: No Hay Suficiente Memoria para Water.\n");

    gTablaGeneral[ETG].Datos.in            = (Trob *) efecto;
    gTablaGeneral[ETG].Datos.Parte         = 5;
    gTablaGeneral[ETG].Datos.Reservado     = 0;

    gTablaGeneral[ETG].Funcion.Reservar    = rob_Reservar;
    gTablaGeneral[ETG].Funcion.Renderizar  = rob_Renderizar;
    gTablaGeneral[ETG].Funcion.Actualizar  = rob_Actualizar;
    gTablaGeneral[ETG].Funcion.Terminar    = rob_Terminar;
}


/////////////////////////////////////////
/////////////////////////////////////////
/////////////////////////////////////////
/////////////////////////////////////////

// ****************************************************************************
// Rellena un poligono interpolando x1, x2 (modo 5)

void PolyFiller_Flat(Tpunto *vertA, Tpunto *vertB, Tpunto *vertC, u16 color, u16 *buf)
{
    int y, incx, x1, x2;
    float incy, prestep;
    FIXED dx1, dx2=0, dx3=0, x_act1, x_act2=0;                                // interpolar x
    Tpunto *vert_min, *vert_cen, *vert_max, *vert_temp;
    u16 *pbuf;

    // ordenamos los vertices por su "y".
    vert_min = vertA; vert_cen = vertB; vert_max = vertC;
    if (vert_min->y > vert_cen->y)
        { vert_temp = vert_min; vert_min = vert_cen; vert_cen = vert_temp; }
    if (vert_cen->y > vert_max->y)
        { vert_temp = vert_cen; vert_cen = vert_max; vert_max = vert_temp; }
    if (vert_min->y > vert_cen->y)
        { vert_temp = vert_min; vert_min = vert_cen; vert_cen = vert_temp; }

    float ymin = vert_min->y;
    float ycen = vert_cen->y;
    float ymax = vert_max->y;

    prestep = ((int)ymin + 1) - ymin;

    // Extremo directo
    if ((incy = ymax - ymin))
    {
        dx1 = (FIXED) (((vert_max->x - vert_min->x)*65536) / incy);
        x_act1 = (FIXED) ((vert_min->x*65536) + prestep*dx1);
    }
    else return;

    // Extremos con punto intermedio
    if ((incy = ycen - ymin))
    {
        dx2 = (FIXED) (((vert_cen->x - vert_min->x)*65536) / incy);
        x_act2 = (FIXED) ((vert_min->x*65536) + prestep*dx2);
        y = (FIXED) ymin;
    }
    else y = (FIXED) ycen;

    if ((incy = ymax - ycen))
    {
        dx3 = (FIXED) (((vert_max->x - vert_cen->x)*65536) / incy);
        if ((int)ycen == (int)ymin)
        {
            prestep = ((int)ycen + 1) - ycen;
            x_act2 = (FIXED) ((vert_cen->x*65536) + prestep*dx3);
        }
    }

    // recorremos el poligono de abajo a arriba, linea a linea.
    int ymax_int = (int)ymax;
    for (; y < ymax_int; y++)
    {
        ////
        // Dibujamos la scan de altura y, que va de x1 a x2 y de z1 a z2

        if (x_act1 <= x_act2)
        { 
            x1 = x_act1>>16; x2 = x_act2>>16;
        }
        else
        { 
            x1 = x_act2>>16; x2 = x_act1>>16;
        }

        if ((incx = x2 - x1))
        {

            pbuf = (buf  + RESX * y + x1);
            do {
                *pbuf = color;
                pbuf++;
            } while (--incx);
//            memset(pbuf, color, incx*2);
        }

        ////
        // Sumamos los diferenciales para dibujar la siguiente scan

        // Extremos directos
        x_act1 += dx1;

        // Extremos con punto intermedio
        // (ycen-1) para tener bi�n la siguiente linea (ycen)
        if (y > ((int)ycen-1)) { x_act2 += dx3; }
        else if (y == ((int)ycen-1))
        {
            prestep = ((int)ycen + 1) - ycen;
            x_act2 = (FIXED) (vert_cen->x*65536 + prestep*dx3);
        }
        else { x_act2 += dx2; }
    }
}

/****************************************************************************/
// funci�n que dibuja lineas usando el algoritmo del punto medio (Bresenham)

inline int putpixel(int x, int y, int color, u16 *video)
{
    u16 *pbuf = ((u16 *) video + RESX * y + x);
    int retorno = (((*pbuf)&(1<<15))>>15);

    int r = ((*pbuf)&(31<<10));
    if (r+(color&(31<<10)) > (31<<10)) r = (31<<10);
    else r += (color&(31<<10));

    int g = ((*pbuf)&(31<<5));
    if (g+(color&(31<<5)) > (31<<5)) g = (31<<5);
    else g += (color&(31<<5));

    int b = ((*pbuf)&31);
    if (b+(color&31) > 31) b = 31;
    else b += (color&31);

    *pbuf = r|g|b;

    //*pbuf = color;
    return retorno;
}

int Bresenham(int x0, int y0, int x1, int y1, u16 color, u16 *video)
{
    int dx, dy, incrE, incrNE, incy = 1, d, x, y, temp;
    char flag = 0;
    int retorno = 0;

    // con esto nos aseguramos que va de izquierda a derecha
    if (x0 > x1)
    {
        temp = x0; x0 = x1; x1 = temp;
        temp = y0; y0 = y1; y1 = temp;
    }

    dx = x1 - x0;
    dy = y1 - y0;

    // esto es para arreglar el problema que hay si m > 1 (de 45 a 90 grados)
    if (dy > dx)
    {
        temp = x0; x0 = y0; y0 = temp;
        temp = x1; x1 = y1; y1 = temp;
        temp = dx; dx = dy; dy = temp;
        flag = 1;
    }

    d = 2*dy - dx;
    incrE = 2*dy;
    incrNE = 2*(dy - dx);

    // cuando m es < 0
    if (dy < 0)
    {
        if (dx > -dy)   // 0 a -45 grados
        {
            d = -2*dy - dx;
            incrE = -2*dy;
            incrNE = 2*(-dy - dx);
        }
        else    // -45 a -90 grados
        {
            temp = y0; y0 = x1; x1 = temp;
            temp = x0; x0 = y1; y1 = temp;
            flag = 1;

            d = 2*dx + dy;
            incrE = 2*dx;
            incrNE = 2*(dx + dy);
        }
        incy = -1;
    }

    x = x0;
    y = y0;
    
    if (flag) { retorno += putpixel(y, x, color, video); }
    else { retorno += putpixel(x, y, color, video); }

    while (x < x1)
    {
        x++;

        if (d <= 0) d += incrE;
        else
        {
            d += incrNE;
            y += incy;
        }

        if (flag) { retorno += putpixel(y, x, color, video); }
        else { retorno += putpixel(x, y, color, video); }
    }
    
    if (retorno > 15) return -5;
    else if (retorno > 8) return -3;
    else if (retorno > 4) return -1;
    else return 3;
}

// ****************************************************************************
void A_rob_BlurMotion (u16 *buffer, u8 paso, u32 resx_por_resy)
{
    do {
        int r = (((*buffer)&(31<<10))>>10) - paso;
        if (r < 0) r = 0;

        int g = (((*buffer)&(31<<5))>>5) - paso;
        if (g < 0) g = 0;

        int b = ((*buffer)&31) - paso;
        if (b < 0) b = 0;

        *(buffer++) = (r<<10)|(g<<5)|(b);
    } while (--resx_por_resy);
}
