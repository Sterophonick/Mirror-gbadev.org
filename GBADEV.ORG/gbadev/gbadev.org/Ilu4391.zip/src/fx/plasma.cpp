#include <stdio.h>
#include <stdlib.h>
#include <malloc.h>
#include <math.h>
#include "../gba/gba.h"
#include "../gba/screenmode.h"
#include "../gba/sprite.h"

#include "../efectos.h"
#include "../printxy.h"


typedef unsigned char BYTE;
typedef unsigned long DWORD;

typedef struct
{
     u8 wavetable[256];
     FIXED spd1, spd2, spd3, spd4;
     FIXED pos1, pos2, pos3, pos4;     
}Tplasma;

//////////////////////////////////////////////////
/////// ----- Metodos Principales ----- //////////
//////////////////////////////////////////////////

u16 *plasma_video=FrontBuffer, *plasma_videoback=BackBuffer;

void plasma_Flip(void)
{
    if (REG_DISPCNT & BACKBUFFER) //back buffer is the current buffer so we need to switch it to the font buffer
    { 
        REG_DISPCNT &= ~BACKBUFFER; //flip active buffer to front buffer by clearing back buffer bit
        plasma_video = FrontBuffer; //now we point our drawing buffer to the back buffer
        plasma_videoback = BackBuffer;
    }
    else //front buffer is active so switch it to backbuffer
    { 
        REG_DISPCNT |= BACKBUFFER; //flip active buffer to back buffer by setting back buffer bit
        plasma_video = BackBuffer; //now we point our drawing buffer to the front buffer
        plasma_videoback = FrontBuffer;
    }
}

//////////////// Reservar /////////////////////////

inline u16 RGBto16(u16 R, u16 G, u16 B)
{
    return (B<<10)|(G<<5)|R;
}

void
plasma_Reservar (DWORD ETG)
{
    Tplasma *efecto;
    //u16 i;
   
    if ( !gTablaGeneral[ETG].Datos.Reservado )
    {
        efecto = (Tplasma *) gTablaGeneral[ETG].Datos.in;
        gTablaGeneral[ETG].Datos.Reservado = 1;
      
        ////////////////////////////////////////////////////////////////
        // Inicializaci�n efecto
    
        SetMode(MODE_4|BG2_ENABLE|OBJ_MAP_1D|OBJ_ENABLE);

        // colocamos la paleta (si que va a acabar coloc� si XD
        /*
        for (int i = 0; i < 64; i++)
            BGPaletteMem[i] = RGBto16(i/2, 0, 0);
        for (int i = 64; i < 128; i++)
            BGPaletteMem[i] = RGBto16(31, (i-64)/2, 0);
        for (int i = 128; i < 192; i++)
            BGPaletteMem[i] = RGBto16(31, 31, (i-128)/2);
        for (int i = 192; i < 256; i++)
            BGPaletteMem[i] = RGBto16(31-(i-192)/2, 31-(i-192)/2, 31-(i-192)/2);
                                      
*/  
        for (int i = 0; i < 64; i++)
            BGPaletteMem[i] = RGBto16((i-4)/5,5+(i/8) , (i)/4);
        for (int i = 64; i < 128; i++)
            BGPaletteMem[i] = RGBto16((i-13)/5,5+(i/8) , (i)/4);
        for (int i = 128; i < 192; i++)
            BGPaletteMem[i] = RGBto16((255-i-13)/5,5+((255-i)/8) , (255-i)/4);            
        for (int i = 192; i < 256; i++)
            BGPaletteMem[i] = RGBto16((255-i-4)/5,5+((255-i)/8) , (255-i)/4);

        efecto->spd1 = 2<<14; efecto->spd2 = 3<<14; efecto->spd3 = 4<<14; efecto->spd4 = 5<<14;
        efecto->pos1 = 0; efecto->pos2 = 0; efecto->pos3 = 0; efecto->pos4 = 0;              
      	for (u16 x=0; x<256; x++)
  	     	//efecto->wavetable[x] = 62*(sin(x*2 * M_PI / 256));
  	 	efecto->wavetable[x] = (x*COS[x*360/256])>>16;
        
        REG_BG2PA = 256;  // horizontal texture step in x
        REG_BG2PB = 0;    // vertical texture step in x
        REG_BG2PC = 0;    // horizontal texture step in y
        REG_BG2PD = 128;  // vertical texture step in y
    }
}

//////////////// Renderizar /////////////////////////

unsigned int
plasma_Renderizar (DWORD ETG)
{
    Tplasma *efecto = (Tplasma *) gTablaGeneral[ETG].Datos.in;
    int v=0;
    u8 tpos1, tpos2, tpos3, tpos4;
    u8 pos1tmp, pos2tmp, pos3tmp, pos4tmp;
    pos1tmp = (efecto->pos1>>16);
    pos2tmp = (efecto->pos2>>16);
    pos3tmp = (efecto->pos3>>16);
    pos4tmp = (efecto->pos4>>16);

    tpos1 = pos1tmp;
    tpos2 = pos2tmp;
    for (u8 y=0; y<(160>>1); y++){
      tpos3 = pos3tmp;
      tpos4 = pos4tmp;
      for(u8 x=0; x<(240>>1); x++){
            char z = efecto->wavetable[tpos1] + efecto->wavetable[tpos2] +
            efecto->wavetable[tpos3] + efecto->wavetable[tpos4];
           *((u8*)(plasma_videoback + (v++))) = z;
        tpos3 += 2;
        tpos4 += 2;
      }
      tpos1 += 1;
      tpos2 += 1;
    }
    
    WaitForVsync();
    plasma_Flip();
    return (0);    // Sincronizado con la musica
}

//////////////// Actualizar /////////////////////////

void
plasma_Actualizar (DWORD ETG)
{
    Tplasma *efecto = (Tplasma *) gTablaGeneral[ETG].Datos.in;

    efecto->pos1 -= efecto->spd1;
    efecto->pos2 += efecto->spd2;
    efecto->pos3 += efecto->spd3;
    efecto->pos4 -= efecto->spd4;
}

//////////////// Terminar /////////////////////////

void
plasma_Terminar (DWORD ETG)
{
    Tplasma *efecto = (Tplasma *) gTablaGeneral[ETG].Datos.in;

    if (efecto != NULL)
    {
        free (efecto);

        REG_BG2PA = 256;  // horizontal texture step in x
        REG_BG2PB = 0;    // vertical texture step in x
        REG_BG2PC = 0;    // horizontal texture step in y
        REG_BG2PD = 256;  // vertical texture step in y
    }
}

//////////////// Inicializar /////////////////////////

void
plasma_Inicializar (DWORD ETG)
{
    Tplasma *efecto = (Tplasma *) malloc (sizeof(Tplasma));
//    if (efecto == NULL) exit(-1); //NULL_Error ("Error: No Hay Suficiente Memoria para Water.\n");

    gTablaGeneral[ETG].Datos.in            = (Tplasma *) efecto;
    gTablaGeneral[ETG].Datos.Parte         = 1;
    gTablaGeneral[ETG].Datos.Reservado     = 0;

    gTablaGeneral[ETG].Funcion.Reservar    = plasma_Reservar;
    gTablaGeneral[ETG].Funcion.Renderizar  = plasma_Renderizar;
    gTablaGeneral[ETG].Funcion.Actualizar  = plasma_Actualizar;
    gTablaGeneral[ETG].Funcion.Terminar    = plasma_Terminar;
}
