#include <stdio.h>
#include <stdlib.h>
#include <malloc.h>
#include <math.h>
#include <string.h>
#include "../gba/gba.h"
#include "../gba/screenmode.h"
#include "../gba/backgrounds.h"
#include "../gba/sprite.h"

#include "../efectos.h"
#include "../printxy.h"

//#include "../gfx/blobssprite.h"

#define RESX 240
#define RESY 160


// Sprites

typedef unsigned char BYTE;
typedef unsigned long DWORD;

typedef struct
{
    u32 **tabla;
    FIXED alfa;
    int x1, y1, x2, y2, x3, y3, x4, y4;
}Tblobs;

u16 *blobs_video=FrontBuffer, *blobs_videoback=BackBuffer;

void blobs_Flip(void)
{
    if (REG_DISPCNT & BACKBUFFER) //back buffer is the current buffer so we need to switch it to the font buffer
    { 
        REG_DISPCNT &= ~BACKBUFFER; //flip active buffer to front buffer by clearing back buffer bit
        blobs_video = FrontBuffer; //now we point our drawing buffer to the back buffer
        blobs_videoback = BackBuffer;
    }
    else //front buffer is active so switch it to backbuffer
    { 
        REG_DISPCNT |= BACKBUFFER; //flip active buffer to back buffer by setting back buffer bit
        blobs_video = BackBuffer; //now we point our drawing buffer to the front buffer
        blobs_videoback = FrontBuffer;
    }
}

inline u16 RGBto16(u16 R, u16 G, u16 B)
{
    return (B<<10)|(G<<5)|R;
}

//////////////////////////////////////////////////
/////// ----- Metodos Principales ----- //////////
//////////////////////////////////////////////////

//////////////// Reservar /////////////////////////

void
blobs_Reservar (DWORD ETG)
{
    Tblobs *efecto;
//    u16 i;
   
    if ( !gTablaGeneral[ETG].Datos.Reservado )
    {
        efecto = (Tblobs *) gTablaGeneral[ETG].Datos.in;
        gTablaGeneral[ETG].Datos.Reservado  = 1;
      
        ////////////////////////////////////////////////////////////////
        // Inicializaci�n efecto
    
        //setmode5flipped();
        SetMode(MODE_4|BG2_ENABLE|OBJ_MAP_1D|OBJ_ENABLE);
        aMemSet16(FrontBuffer, 0, RESX*RESY);
        //aMemSet16(BackBuffer, 0, RESX*RESY);
        
        // empezamos pintando en el backbuffer y mostrando el frontbuffer
        REG_DISPCNT &= ~BACKBUFFER;
        
        // Inicializar (tela)...    
        
        // colocamos la paleta (si que va a acabar coloc� si XD
        u16* Paleta = (u16*)BGPaletteMem;
        for (int i = 0; i < 64; i++)
            *(Paleta++) = RGBto16(0, 0, i/2);
        for (int i = 0; i < 128; i++)
            *(Paleta++) = RGBto16(0, i/4, 31);
        for (int i = 0; i < 64; i++)
            *(Paleta++) = RGBto16(i/2, 31, 31);
            
        efecto->alfa = (1<<16);

        // Escalamos la y en un factor de 2
        REG_BG2PA = 256;  // horizontal texture step in x
        REG_BG2PB = 0;    // vertical texture step in x
        REG_BG2PC = 0;    // horizontal texture step in y
        REG_BG2PD = 128;  // vertical texture step in y
    }
}

//////////////// Renderizar /////////////////////////
int blobs_frame = 0;
unsigned int
blobs_Renderizar (DWORD ETG)
{
    Tblobs *efecto = (Tblobs *) gTablaGeneral[ETG].Datos.in;
//    u16 Parte       = gTablaGeneral[ETG].Datos.Parte;

    u8 *pbuf = (u8*)blobs_videoback;
    u16 subtotal;
    int x, y=1;
    int x1 = efecto->x1, x2 = efecto->x2, x3 = efecto->x3, x4 = efecto->x4;
    int y1 = efecto->y1, y2 = efecto->y2, y3 = efecto->y3, y4 = efecto->y4;
    u32 **tabla = (u32**)(efecto->tabla);

    // primera linea    
    for (x = 0; x < (RESX>>2); x++)
    {
        subtotal = ( (tabla[y1][abs(x1-x)])
                   + (tabla[y2][abs(x2-x)])
                   + (tabla[y3][abs(x3-x)])
                   + (tabla[y4][abs(x4-x)]) );

        *pbuf = ((subtotal < 256) ? subtotal : 255);
        *(pbuf+2) = *pbuf;
        pbuf+=4;
    }

    //if (blobs_frame++ & 1) { pbuf += RESX*2; y++; }

    // grueso de la pantalla
    for (; y < (RESY>>2); y++)
    {
        // izquierda
        subtotal = ( (tabla[abs(y1-y)][x1])
                   + (tabla[abs(y2-y)][x2])
                   + (tabla[abs(y3-y)][x3])
                   + (tabla[abs(y4-y)][x4]) );

        *pbuf = ((subtotal < 256) ? subtotal : 255);
        pbuf+=RESX;
        *pbuf = *(pbuf-RESX);

        pbuf+=2;

        // todo
        for (x = 1; x < (RESX>>2); x++)
        {
            pbuf+=2;

            subtotal = ( (tabla[abs(y1-y)][abs(x1-x)])
                       + (tabla[abs(y2-y)][abs(x2-x)])
                       + (tabla[abs(y3-y)][abs(x3-x)])
                       + (tabla[abs(y4-y)][abs(x4-x)]) );

            *pbuf = ((subtotal < 256) ? subtotal : 255);

            // Interpolamos
            *(pbuf-2) = (*(pbuf-4) + *(pbuf) )>>1;
            *(pbuf-RESX) = (*(pbuf) + *(pbuf-2*RESX) )>>1;
            *(pbuf-RESX-2) = (*(pbuf-2) + *(pbuf-2*RESX-2) )>>1;
            //*(pbuf-2) = *pbuf;
            //*(pbuf-RESX) = *pbuf;
            //*(pbuf-RESX-2) = *pbuf;

            pbuf+=2;
        }
        pbuf+=2;
    }

    WaitForVsync();
    blobs_Flip();
    return (0);    // Sincronizado con la musica
}

//////////////// Actualizar /////////////////////////

void
blobs_Actualizar (DWORD ETG)
{
    Tblobs *efecto = (Tblobs *) gTablaGeneral[ETG].Datos.in;

    int alfa = ((efecto->alfa)>>16);
    int alfa2 = alfa*2;
    if (alfa2 >= 360) alfa2 -= 360;
    int menosalfa = -alfa + 360;
    if (menosalfa >= 360) menosalfa -= 360;
    int menosalfa2 = (-alfa2) + 360;
    

    // Movemos el bicho
    efecto->x1 = (((60 * COS[alfa]       + 30 * SIN[menosalfa])>>16) + RESX/2)>>2;
    efecto->y1 = (((25 * COS[menosalfa2] + 35 * SIN[alfa]     )>>16) + RESY/2)>>2;
    efecto->x2 = (((30 * COS[alfa]       + 60 * SIN[alfa2]    )>>16) + RESX/2)>>2;
    efecto->y2 = (((45 * COS[alfa]       + 25 * SIN[alfa]     )>>16) + RESY/2)>>2;
    efecto->x3 = (((45 * COS[menosalfa]  + 45 * SIN[alfa]     )>>16) + RESX/2)>>2;
    efecto->y3 = (((45 * COS[alfa2]      + 15 * SIN[menosalfa])>>16) + RESY/2)>>2;
    efecto->x4 = (((75 * COS[alfa]       + 15 * SIN[alfa2]    )>>16) + RESX/2)>>2;
    efecto->y4 = (((15 * COS[menosalfa]  + 55 * SIN[alfa2]    )>>16) + RESY/2)>>2;

    efecto->alfa += (1<<17);
    if (efecto->alfa >= (360<<16)) efecto->alfa -= (360<<16);
}

//////////////// Terminar /////////////////////////

void
blobs_Terminar (DWORD ETG)
{
    Tblobs *efecto = (Tblobs *) gTablaGeneral[ETG].Datos.in;

    if (efecto != NULL)
    {
        for (int y=0; y<(RESY>>2); y++)
        {
            free (efecto->tabla[y]);
        }
        free(efecto->tabla);

        // Volvemos al estado normal
        REG_BG2PA = 256;  // horizontal texture step in x
        REG_BG2PB = 0;    // vertical texture step in x
        REG_BG2PC = 0;    // horizontal texture step in y
        REG_BG2PD = 128;  // vertical texture step in y
        
        free(efecto);
    }
}

//////////////// Inicializar /////////////////////////

void
blobs_Inicializar (DWORD ETG)
{
    Tblobs *efecto = (Tblobs *) malloc (sizeof(Tblobs));
//    if (efecto == NULL) exit(-1); //NULL_Error ("Error: No Hay Suficiente Memoria para Water.\n");

    gTablaGeneral[ETG].Datos.in            = (Tblobs *) efecto;
    gTablaGeneral[ETG].Datos.Parte         = 1;
    gTablaGeneral[ETG].Datos.Reservado     = 0;

    gTablaGeneral[ETG].Funcion.Reservar    = blobs_Reservar;
    gTablaGeneral[ETG].Funcion.Renderizar  = blobs_Renderizar;
    gTablaGeneral[ETG].Funcion.Actualizar  = blobs_Actualizar;
    gTablaGeneral[ETG].Funcion.Terminar    = blobs_Terminar;

    // Precalculamos la tabla potenciales/distancia
    efecto->tabla = (u32**) malloc((RESY>>2)*sizeof(u32));     // usamos coma fija 19.13
    for (int y=0; y<(RESY>>2); y++)
    {
        efecto->tabla[y] = (u32*) malloc((RESX>>2)*sizeof(u32));

        for (int x=0; x<(RESX>>2); x++)
        {
            efecto->tabla[y][x] = (u16)((51000/((16*x*x)+(16*y*y)+1)));
        }
    }
}


/////////////////////////////////////////
/////////////////////////////////////////
/////////////////////////////////////////
/////////////////////////////////////////
