#include <stdio.h>
#include <stdlib.h>
#include <malloc.h>
#include <math.h>
#include "../gba/gba.h"
#include "../gba/screenmode.h"
#include "../gba/backgrounds.h"
#include "../gba/sprite.h"

#include "../efectos.h"
#include "../printxy.h"

// Sprites
#include "../gfx/roto2.h"
#include "../gfx/roto1.h"

typedef unsigned char BYTE;
typedef unsigned long DWORD;

typedef struct
{
    FIXED alfa;
    Bg bg2, bg3;
    int sentido;
}Troto;

//////////////////////////////////////////////////
/////// ----- Metodos Principales ----- //////////
//////////////////////////////////////////////////

//////////////// Reservar /////////////////////////

void
roto_Reservar (DWORD ETG)
{
    Troto *efecto;
    //u16 i;

    if ( !gTablaGeneral[ETG].Datos.Reservado )
    {
        efecto = (Troto *) gTablaGeneral[ETG].Datos.in;
        gTablaGeneral[ETG].Datos.Reservado  = 1;
      
        SetMode(MODE_2|OBJ_MAP_1D|OBJ_ENABLE|BG2_ENABLE|BG3_ENABLE);

        ////////////////////////////////////////////////////////////////
        // Inicializaci�n efecto
    
        // Preparamos el background 2
        efecto->bg2.mosaic = 0;
        efecto->bg2.colorMode = BG_COLOR_256;
        efecto->bg2.number = 2;
        efecto->bg2.size = ROTBG_SIZE_128x128;
        efecto->bg2.charBaseBlock = 1;
        efecto->bg2.screenBaseBlock = 16;
        efecto->bg2.wraparound = WRAPAROUND;
        EnableBackground(&(efecto->bg2));
        
        int cont = 0;
        for (int j = 0; j < 16; j++)    // y por bloques
        {
            for (int i = 0; i < 16; i++)    // x por bloques
            {
                for (int k = 0; k < 8; k++)    // y por pixels dentro de un bloque
                {
                    for (int l = 0; l < 4; l++)    // x por (2 pixels) dentro de un bloque
                    {
                        *(efecto->bg2.tileData + (cont++)) = *(((u16*)roto1)+(j*4*16*8+k*4*16+i*4+l));
                    }
                }
            }
        }
        for (int l = 0; l < 128; l++)    // x por (2 pixels) dentro de un bloque
        {
            *(efecto->bg2.mapData + l) = (((2*l))|((2*l+1)<<8));
        }
        aMemCpy32((u32*)(BGPaletteMem), (u32*)roto1Palette, 128/2);

        // Preparamos el background 3
        efecto->bg3.mosaic = 0;
        efecto->bg3.colorMode = BG_COLOR_256;
        efecto->bg3.number = 3;
        efecto->bg3.size = ROTBG_SIZE_128x128;
        efecto->bg3.charBaseBlock = 0;
        efecto->bg3.screenBaseBlock = 16;
        efecto->bg3.wraparound = WRAPAROUND;
        EnableBackground(&(efecto->bg3));
        
        cont = 0;
        for (int j = 0; j < 16; j++)    // y por bloques
        {
            for (int i = 0; i < 16; i++)    // x por bloques
            {
                for (int k = 0; k < 8; k++)    // y por pixels dentro de un bloque
                {
                    for (int l = 0; l < 4; l++)    // x por (2 pixels) dentro de un bloque
                    {
                        *(efecto->bg3.tileData + (cont++)) = *(((u16*)roto2)+(j*4*16*8+k*4*16+i*4+l)) + ((128<<8)|128);
                    }
                }
            }
        }
        aMemCpy32(((u32*)(BGPaletteMem)+128/2), (u32*)roto2Palette, 128/2);

//        SetMode(MODE_2|OBJ_MAP_1D|OBJ_ENABLE|BG2_ENABLE|BG3_ENABLE);
        SetMode(MODE_2|OBJ_MAP_1D|OBJ_ENABLE|BG3_ENABLE);

        REG_BLDMOD = (1<<10)|(1<<6)|(1<<3);
        REG_COLEV = (8<<8)|(7>>16);
        
//        efecto->alfax = (90<<16);
        efecto->sentido = 1;
    }
}

//////////////// Renderizar /////////////////////////

unsigned int
roto_Renderizar (DWORD ETG)
{
    Troto *efecto = (Troto *) gTablaGeneral[ETG].Datos.in;
  
    //printxy_clrscr();
    //printxy(30, 30, "tiemblo", PRINTXY_TRANSPARENT|PRINTXY_QUAKE);

    WaitForVsync();
    UpdateBackground(&(efecto->bg2));
    UpdateBackground(&(efecto->bg3));
    
    return (0);    // Sincronizado con la musica
}

//////////////// Actualizar /////////////////////////

void
roto_Actualizar (DWORD ETG)
{
    Troto *efecto = (Troto *) gTablaGeneral[ETG].Datos.in;

    int alfa = ((efecto->alfa)>>16);
    int alfa2 = alfa*2;
    if (alfa2 >= 360) alfa2 -= 360;
    int menosalfa = 360 - alfa;
    if (menosalfa >= 360) menosalfa -= 360;
    int menosalfa2 = 360 - alfa2;

    if (gTablaGeneral[ETG].Datos.Parte > 32)
    {
        SetMode(MODE_2|OBJ_MAP_1D|OBJ_ENABLE|BG3_ENABLE);
        if (! (gTablaGeneral[ETG].Datos.Parte & 1) )
        {
            if (gTablaGeneral[ETG].Datos.Parte & 2) efecto->sentido = -1;
            else efecto->sentido = 1;
        }

        // rotozoom normalito
        RotateBackground(&(efecto->bg3), menosalfa, menosalfa, alfa, 1<<8);
        efecto->alfa += efecto->sentido * (1<<14) * (1 + 47 - gTablaGeneral[ETG].Datos.Parte);
    }
    else if (gTablaGeneral[ETG].Datos.Parte > 16)
    {
        // dos planos
        SetMode(MODE_2|OBJ_MAP_1D|OBJ_ENABLE|BG2_ENABLE|BG3_ENABLE);
        RotateBackground(&(efecto->bg2), alfa2, alfa, menosalfa, SIN[alfa]>>6);
        RotateBackground(&(efecto->bg3), menosalfa, menosalfa2, alfa2, COS[menosalfa]>>6);
        efecto->alfa += (8 + 32 - gTablaGeneral[ETG].Datos.Parte)<<12;
        //efecto->alfa += (1<<12);
    }
    else
    {
        // un plano muy rallado
        SetMode(MODE_2|OBJ_MAP_1D|OBJ_ENABLE|BG3_ENABLE);

        efecto->alfa += (1 + 16 - gTablaGeneral[ETG].Datos.Parte)<<18;
        efecto->bg3.x_scroll = - 120 - 64;
        efecto->bg3.y_scroll = - 80;
        RotateBackground(&(efecto->bg3), menosalfa, 120, 80, 1<<8);
    }

    if (efecto->alfa >= (360<<16)) efecto->alfa -= (360<<16);
    else if (efecto->alfa < 0) efecto->alfa += (360<<16);
}

//////////////// Terminar /////////////////////////

void
roto_Terminar (DWORD ETG)
{
    Troto *efecto = (Troto *) gTablaGeneral[ETG].Datos.in;

    if (efecto != NULL)
    {
        free (efecto);
    }
    efecto->bg2.x_scroll = 0;
    efecto->bg2.y_scroll = 0;
    efecto->bg3.x_scroll = 0;
    efecto->bg3.y_scroll = 0;
    RotateBackground(&(efecto->bg2), 0, 0, 0, 1<<8);
    UpdateBackground(&(efecto->bg2));
    RotateBackground(&(efecto->bg3), 0, 0, 0, 1<<8);
    UpdateBackground(&(efecto->bg3));
}

//////////////// Inicializar /////////////////////////

void
roto_Inicializar (DWORD ETG)
{
    Troto *efecto = (Troto *) malloc (sizeof(Troto));
//    if (efecto == NULL) exit(-1); //NULL_Error ("Error: No Hay Suficiente Memoria para Water.\n");

    gTablaGeneral[ETG].Datos.in            = (Troto *) efecto;
    gTablaGeneral[ETG].Datos.Parte         = 47;
    gTablaGeneral[ETG].Datos.Reservado     = 0;

    gTablaGeneral[ETG].Funcion.Reservar    = roto_Reservar;
    gTablaGeneral[ETG].Funcion.Renderizar  = roto_Renderizar;
    gTablaGeneral[ETG].Funcion.Actualizar  = roto_Actualizar;
    gTablaGeneral[ETG].Funcion.Terminar    = roto_Terminar;
}
