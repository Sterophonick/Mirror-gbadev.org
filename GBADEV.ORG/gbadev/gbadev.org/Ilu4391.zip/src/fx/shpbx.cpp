#include <stdio.h>
#include <stdlib.h>
#include <malloc.h>
#include <string.h>
#include "../gba/gba.h"
#include "../gba/screenmode.h"
#include "../gba/backgrounds.h"
#include "../gba/sprite.h"

#include "../efectos.h"
#include "../printxy.h"

#include "../gfx/shpbxsprite.h"

#define RESX 80
#define RESY 120


// Sprites

typedef unsigned char BYTE;
typedef unsigned long DWORD;

typedef struct
{
    FIXED alfa;
    int x, y;
    u32 intensidad, partedone;
}Tshpbx;

u16 *shpbx_video=FrontBuffer, *shpbx_videoback=BackBuffer;

void shpbx_Flip(void)
{
    if (REG_DISPCNT & BACKBUFFER) //back buffer is the current buffer so we need to switch it to the font buffer
    { 
        REG_DISPCNT &= ~BACKBUFFER; //flip active buffer to front buffer by clearing back buffer bit
        shpbx_video = FrontBuffer; //now we point our drawing buffer to the back buffer
        shpbx_videoback = BackBuffer;
    }
    else //front buffer is active so switch it to backbuffer
    { 
        REG_DISPCNT |= BACKBUFFER; //flip active buffer to back buffer by setting back buffer bit
        shpbx_video = BackBuffer; //now we point our drawing buffer to the front buffer
        shpbx_videoback = FrontBuffer;
    }
}

void A_BlurMotion (u16 *buffer, u8 paso, u32 resx_por_resy);
void A_BlurDeBuffer1aBuffer2 (u16 *ori, u16 *des, int resx, int resy);
//void shpbx_zoomScreen1a2(u16 *origen, u16 *destino);
void shpbx_pintaSprite16Zoom (u16 *spr_datos, int spr_ancho, int spr_alto,
                        int posx, int posy, long ancho_fis, long alto_fis,
                        u16 *buffer);

//////////////////////////////////////////////////
/////// ----- Metodos Principales ----- //////////
//////////////////////////////////////////////////

//////////////// Reservar /////////////////////////

void
shpbx_Reservar (DWORD ETG)
{
    Tshpbx *efecto;
//    u16 i;
   
    if ( !gTablaGeneral[ETG].Datos.Reservado )
    {
        efecto = (Tshpbx *) gTablaGeneral[ETG].Datos.in;
        gTablaGeneral[ETG].Datos.Reservado  = 1;
      
        ////////////////////////////////////////////////////////////////
        // Inicializaci�n efecto
    
        setmode5flipped();
        REG_BG2PA = 0;  // horizontal texture step in x
        REG_BG2PB = 128;    // vertical texture step in x
        REG_BG2PC = 128;    // horizontal texture step in y
        REG_BG2PD = 0;  // vertical texture step in y
        SetMode(MODE_5|BG2_ENABLE|OBJ_MAP_1D|OBJ_ENABLE);
        aMemSet16(FrontBuffer, 0, 2*RESX*RESY);
        aMemSet16(BackBuffer, 0, 2*RESX*RESY);
        
        // empezamos pintando en el backbuffer y mostrando el frontbuffer
        REG_DISPCNT &= ~BACKBUFFER;

        efecto->intensidad = 0;
        efecto->partedone = gTablaGeneral[ETG].Datos.Parte+1;

        // 12 y 2 o 10 y 4
    	REG_BLDMOD = (1<<10)|(2<<6)|(1<<4);
    	REG_COLEV = (17<<8)|17;
    }
}

//////////////// Renderizar /////////////////////////
unsigned int
shpbx_Renderizar (DWORD ETG)
{
    Tshpbx *efecto = (Tshpbx *) gTablaGeneral[ETG].Datos.in;
//    u16 Parte       = gTablaGeneral[ETG].Datos.Parte;

    pintaSpriteSoftware((u16*)shpbxsprite, efecto->x, efecto->y, 64, 32, shpbx_video, SPRITESOFT_COLORKEY|SPRITESOFT_BLEND|6);
    A_BlurDeBuffer1aBuffer2 (shpbx_video, shpbx_videoback, 2*RESX, RESY);
    //A_BlurMotion (shpbx_videoback, 1, RESX*RESY);
    //WaitForVsync();
    shpbx_pintaSprite16Zoom(shpbx_videoback, RESX, RESY, -4, -8, RESX+8, RESY+16, shpbx_video);
    //shpbx_Flip();

    return (0);    // Sincronizado con la musica
}

//////////////// Actualizar /////////////////////////
void
shpbx_Actualizar (DWORD ETG)
{
    Tshpbx *efecto = (Tshpbx *) gTablaGeneral[ETG].Datos.in;
    FIXED alfa = efecto->alfa;

    // Movemos el bicho
    efecto->x = ((SIN[alfa>>16]*10) >> 16) + (RESX) + (rand8()&7)-2 -55;
    efecto->y = (((COS[alfa>>16]*7) >> 16) + (RESY>>1) + (rand8()&7)-2 -26)>>1;
        
    // Pintamos las letras
    if (efecto->partedone >= gTablaGeneral[ETG].Datos.Parte)
    {
        efecto->partedone--;
        efecto->intensidad = 0;
        
        if (gTablaGeneral[ETG].Datos.Parte == 23)
        {
            printxy_clrscr();
            printxy(24, 20, "greetings to", PRINTXY_TRANSPARENT);
        }
        if (gTablaGeneral[ETG].Datos.Parte == 21)
        {
            printxy_clrscr();
            printxy(56, 124, "anaconda", PRINTXY_TRANSPARENT);
        }
        else if (gTablaGeneral[ETG].Datos.Parte == 20)
        {
            printxy_clrscr();
            printxy(72, 20, "Chanka", PRINTXY_TRANSPARENT);
        }
        else if (gTablaGeneral[ETG].Datos.Parte == 19)
        {
            printxy_clrscr();
            printxy(96, 124, "CoD", PRINTXY_TRANSPARENT);
        }
        else if (gTablaGeneral[ETG].Datos.Parte == 18)
        {
            printxy_clrscr();
            printxy(64, 20, "Concept", PRINTXY_TRANSPARENT);
        }
        else if (gTablaGeneral[ETG].Datos.Parte == 17)
        {
            printxy_clrscr();
            printxy(64, 124, "Fuzzion", PRINTXY_TRANSPARENT);
        }
        else if (gTablaGeneral[ETG].Datos.Parte == 16)
        {
            printxy_clrscr();
            printxy(48, 20, "Gods Maze", PRINTXY_TRANSPARENT);
        }
        else if (gTablaGeneral[ETG].Datos.Parte == 15)
        {
            printxy_clrscr();
            printxy(80, 124, "Hansa", PRINTXY_TRANSPARENT);
        }
        else if (gTablaGeneral[ETG].Datos.Parte == 14)
        {
            printxy_clrscr();
            printxy(72, 20, "Lucera", PRINTXY_TRANSPARENT);
        }
        else if (gTablaGeneral[ETG].Datos.Parte == 13)
        {
            printxy_clrscr();
            printxy(24, 124, "NecroStudios", PRINTXY_TRANSPARENT);
        }
        else if (gTablaGeneral[ETG].Datos.Parte == 12)
        {
            printxy_clrscr();
            printxy(64, 20, "network", PRINTXY_TRANSPARENT);
        }
        else if (gTablaGeneral[ETG].Datos.Parte == 11)
        {
            printxy_clrscr();
            printxy(80, 124, "ozone", PRINTXY_TRANSPARENT);
        }
        else if (gTablaGeneral[ETG].Datos.Parte == 10)
        {
            printxy_clrscr();
            printxy(88, 20, "RGBA", PRINTXY_TRANSPARENT);
        }
        else if (gTablaGeneral[ETG].Datos.Parte == 9)
        {
            printxy_clrscr();
            printxy(56, 124, "Solstice", PRINTXY_TRANSPARENT);
        }
        else if (gTablaGeneral[ETG].Datos.Parte == 8)
        {
            printxy_clrscr();
            printxy(96, 20, "TCM", PRINTXY_TRANSPARENT);
        }
        else if (gTablaGeneral[ETG].Datos.Parte == 7)
        {
            printxy_clrscr();
            printxy(32, 124, "threepixels", PRINTXY_TRANSPARENT);
        }
        else if (gTablaGeneral[ETG].Datos.Parte == 6)
        {
            printxy_clrscr();
            printxy(80, 20, "TLOTB", PRINTXY_TRANSPARENT);
        }
        else if (gTablaGeneral[ETG].Datos.Parte == 5)
        {
            printxy_clrscr();
            printxy(64, 124, "Unknown", PRINTXY_TRANSPARENT);
        }
    }
    
    if (efecto->intensidad < 32) efecto->intensidad++;
    else printxy_clrscr();

    int intensi = 17 - (efecto->intensidad>>1);
	REG_COLEV = (17<<8)|intensi;
}

//////////////// Terminar /////////////////////////

void
shpbx_Terminar (DWORD ETG)
{
    Tshpbx *efecto = (Tshpbx *) gTablaGeneral[ETG].Datos.in;

    if (efecto != NULL)
    {
        free (efecto);
    }
    unsetmode5flipped();
}

//////////////// Inicializar /////////////////////////

void
shpbx_Inicializar (DWORD ETG)
{
    Tshpbx *efecto = (Tshpbx *) malloc (sizeof(Tshpbx));
//    if (efecto == NULL) exit(-1); //NULL_Error ("Error: No Hay Suficiente Memoria para Water.\n");

    gTablaGeneral[ETG].Datos.in            = (Tshpbx *) efecto;
    gTablaGeneral[ETG].Datos.Parte         = 26;
    gTablaGeneral[ETG].Datos.Reservado     = 0;

    gTablaGeneral[ETG].Funcion.Reservar    = shpbx_Reservar;
    gTablaGeneral[ETG].Funcion.Renderizar  = shpbx_Renderizar;
    gTablaGeneral[ETG].Funcion.Actualizar  = shpbx_Actualizar;
    gTablaGeneral[ETG].Funcion.Terminar    = shpbx_Terminar;
}


/////////////////////////////////////////
/////////////////////////////////////////
/////////////////////////////////////////
/////////////////////////////////////////

// ****************************************************************************
void A_BlurMotion (u16 *buffer, u8 paso, u32 resx_por_resy)
{
    /*
    do {
        int r = (((*buffer)&(31<<10))>>10) - paso;
        if (r < 0) r = 0;

        int g = (((*buffer)&(31<<5))>>5) - paso;
        if (g < 0) g = 0;

        int b = ((*buffer)&31) - paso;
        if (b < 0) b = 0;

        *(buffer++) = (r<<10)|(g<<5)|(b);
    } while (--resx_por_resy);
    */
    do {
        if (*buffer)
        {
            int r = (((*buffer)&(31<<10))>>10) + paso;
            if (r > 31) r = 31;
    
            int g = (((*buffer)&(31<<5))>>5) + paso;
            if (g > 31) g = 31;
    
            int b = ((*buffer)&31) + paso;
            if (b > 31) b = 31;
            
            *(buffer) = (r<<10)|(g<<5)|(b);
        }
        buffer++;
    } while (--resx_por_resy);
}

void A_BlurDeBuffer1aBuffer2 (u16 *ori, u16 *des, int resx, int resy)
{
    //aMemSet16 (des, 0, resx*resy);

    resx >>= 1;
    
    int y = resy;
    u16 *pdes = des;
    do {
        int x = resx;
        do {
            *(pdes++) = 0;
        } while (--x);
        pdes += resx;
    } while (--y);
    
    ori += (2*resx+1);
    des += (2*resx+1);
    int j = resy - 2;
    do {
        int i = resx - 2;
        do {
            int r = (((*ori)&(7<<12)) >> 2);
            int g = (((*ori)&(7<<7)) >> 2);
            int b = (((*ori)&(7<<2)) >> 2);
            *(des-2*resx) += (r+(2<<10))|(g+(2<<5))|(b+2);
            //*(des-resx) += r|g|b;
            *(des-1)    += r|g|b;
            *(des+1)    += r|g|b;
            *(des+2*resx) += r|g|b;

            ori++;
            des++;
        } while (--i);
        ori += 2+resx;
        des += 2+resx;
    } while (--j);
}
/*
void shpbx_zoomScreen1a2(u16 *origen, u16 *destino)
{
    int ancho = RESX;
    int alto = RESY;
//    FIXED offsetx
    do {
        int ancho2 = ancho;
        do {
            *(destino++) = *(origen++);
        } while (--ancho2);
    } while (--alto);
}
*/

inline u16 sumaPixelsBlend(u16 pia, u16 pib)
{
    int r = ((pia>>1)&(15<<10)) + ((pib>>1)&(15<<10));
    int g = ((pia>>1)&(15<<5)) + ((pib>>1)&(15<<5));
    int b = ((pia>>1)&15) + ((pib>>1)&15);
    return r|g|b;
}

void shpbx_pintaSprite16Zoom (u16 *spr_datos, int spr_ancho, int spr_alto,
                        int posx, int posy, long ancho_fis, long alto_fis,
                        u16 *buffer)
{
    register u16 *pOrig;
    u16 *pDest;
    u16 *pDestS;
    int cnt;
    long _dH = (spr_ancho << 16) / (long)ancho_fis;
    long dV = (spr_alto << 16) / (long)alto_fis;
    long yprec = 0;
    register long xprec = 0;
    long xprecini = 0;
    int cntx=ancho_fis, cnty=alto_fis;
    
    // clipping...
    if (posx < 0) { xprecini = _dH * (-posx);  cntx += posx;  posx = 0; }
    if (posy < 0) { yprec    =  dV * (-posy);  cnty += posy;  posy = 0; }
    if (posx + cntx > RESX) cntx = RESX - posx;
    if (posy + cnty > RESY) cnty = RESY - posy;
    
    if ( (cntx <= 0) || (cnty <= 0) ) return;
    
    pDest = buffer + posx + posy*RESX*2;
    
    // y a pintar
    do {
        pOrig = spr_datos + 2*spr_ancho * (yprec >> 16);
        pDestS = pDest;
        cnt = cntx;
        xprec = xprecini;
        
        do {
            u16 valor = *(pOrig + (xprec >> 16));
            //if (valor)
            //*pDest = sumaPixelsSat((*pDest), valor);
            // *pDest = sumaPixelsBlend((*pDest), valor);
            *pDest = valor;
            pDest++;
            xprec += _dH;
        } while (--cnt);
        pDest = pDestS + RESX*2;
        yprec += dV;
        ++posy;
    } while (--cnty);      
}
