#ifndef __PRINTXY_H__
#define __PRINTXY_H__

// a print string function, first we init the sprites memory needed, then
// we can use it freely. It uses the final part of the sprites mem and
// the last sprites.
void printxy_init(void);
void printxy_clrscr(void);
void printxy(int x, int y, char *texto, int modo);

#define PRINTXY_NORMAL          0
#define PRINTXY_QUAKE           1
#define PRINTXY_MOSAIC          2
#define PRINTXY_TRANSPARENT     4


#endif // __PRINTXY_H__
