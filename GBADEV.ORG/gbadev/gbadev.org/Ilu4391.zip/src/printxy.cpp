#include <string.h>
#include <ctype.h>
#include "gba/gba.h"
#include "gba/sprite.h"
#include "gba/screenmode.h"
#include "gfx/printxyfuente.h"
#include "printxy.h"

int gPrintxyPosAct = 127;
char printxy_orden[] = {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
                        0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
                        0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
                        0, 0, 0, 0, 0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 16,
                        17, 18, 19, 20, 21, 22, 23, 24, 25, 26, 27, 0, 0, 0, 0, 0, 0, 1, 2, 3,
                        4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 16, 17, 18, 19, 20, 21, 22, 23, 24,
                        25, 26, 27, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
                        0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
                        0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
                        0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
                        0, 0, 0, 0, 0, 0, 0, 0, 0, 15, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
                        0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
                        0, 15, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0 };

void printxy_clrscr(void)
{
    while (gPrintxyPosAct < 127) InitializeSprite(++gPrintxyPosAct);
}
void printxy_init(void)
{
    // almacenamos la paleta en las �ltimas 16 posiciones
	aMemCpy32((u32*)(OBJPaletteMem+240), (u32*)printxyfuentePalette, 16/2);
		
    // 1024 8x8 16 color tiles, usamos los ultimos 27, nuestros bloques son de 16*16,
    // con lo que necesitamos 4 bloques de 16x16 x 27 sprites = 108 bloques de 8x8
    // (empezamos en el 916)
    
    // Copiamos los sprites
    aMemCpy32((u32*)(OAMData+(916*8*8/4)), (u32*)printxyfuente, 27*4*8*8/8);
}

void printxy(int x, int y, char *texto, int modo)
{
    for(u32 i=0; i < strlen(texto); i++)
    {
        if ( (isalpha(texto[i])) || (texto[i] == '�') || (texto[i] == '�') )
        {
            if (modo & PRINTXY_QUAKE)
            {
          	    sprites[gPrintxyPosAct].attribute0 = MODE_NORMAL | COLOR_16 | SQUARE | (y+(rand8()&1)-1);
                sprites[gPrintxyPosAct].attribute1 = SIZE_16 | ((x + 16*i)+(rand8()&1)-1);
            }
            else 
            {
          	    sprites[gPrintxyPosAct].attribute0 = MODE_NORMAL | COLOR_16 | SQUARE | y;
                sprites[gPrintxyPosAct].attribute1 = SIZE_16 | (x + 16*i);
            }

            if (modo & PRINTXY_MOSAIC)
          	    sprites[gPrintxyPosAct].attribute0 |= MOSAIC;

            if (modo & PRINTXY_TRANSPARENT)
                sprites[gPrintxyPosAct].attribute0 |= MODE_TRANSPARENT;

        	sprites[gPrintxyPosAct--].attribute2 = PALETTE(15)|PRIORITY(0)|(916 + (printxy_orden[texto[i]]-1)*4);
        }
    }
}
