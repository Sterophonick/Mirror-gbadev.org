#ifndef __EXTERNS_H__
#define __EXTERNS_H__

#define u32 unsigned long

///////////////////////////////////////////////////////////////////////
//////////////////////// Funciones Externas ///////////////////////////
///////////////////////////////////////////////////////////////////////


extern void hn1_Inicializar         (u32 ETG);
extern void rob_Inicializar         (u32 ETG);
extern void shpbx_Inicializar       (u32 ETG);
extern void blobs_Inicializar       (u32 ETG);
extern void roto_Inicializar        (u32 ETG);
extern void fire_Inicializar        (u32 ETG);
extern void plasma_Inicializar      (u32 ETG);

#undef u32

#endif
