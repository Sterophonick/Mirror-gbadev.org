#ifndef __EFECTOS_H__
#define __EFECTOS_H__

/////////////////////////////////////////////
////////////// INCLUDES /////////////////////
/////////////////////////////////////////////

#include "Externs.h"
#include "gba/gba.h"
#include "gba/interupts.h"

extern int              gTiempo;
#define kNumEfectos     7 // Numero de efectos en la demo

int _NULL_event();
void InicializarEfectos();
void InicializarMusica1();
void InicializarMusica2();
void TerminarMusica();
void Liberar (unsigned long ETG);

////////////////////////////////////////////////////////////////////////////////
////////////// Estructuras generales de datos ANSI NULL default ////////////////
////////////////////////////////////////////////////////////////////////////////

typedef struct Funciones
{
   void (* Inicializar)(unsigned long ETG);
   void (* Reservar)   (unsigned long ETG);
   unsigned int (* Renderizar)(unsigned long ETG);
   void (* Actualizar) (unsigned long ETG);
   void (* Terminar)   (unsigned long ETG);   
} TFuncion;

typedef struct Efectos
{
   unsigned long Parte;       // Parte del efecto en curso.
   unsigned char Reservado;   // Byte de estado de la reserva.
   unsigned char *Buffer;     // Buffer del efecto.
   void          *in;         // Entrada para datos internos.
} TEfecto;

typedef struct General
{
   long     Liberar[2];    // Vector de efectos a Liberar
   TEfecto  Datos;       // Datos del Efecto
   TFuncion Funcion;     // Funciones de la interfaz publica
} TGeneral;


extern TGeneral gTablaGeneral[];

extern FIXED loading_incx;
extern FIXED loading_ancho;


#endif
