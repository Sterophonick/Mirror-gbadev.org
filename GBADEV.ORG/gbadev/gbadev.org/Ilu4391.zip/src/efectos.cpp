#include <stdio.h>
#include <stdlib.h>
#include <malloc.h>
#include <string.h>
#include "efectos.h"

#include "gba/gba.h"
#include "snd/GbaPlayer.h"
extern const unsigned char _binary_module_bin_start[];


/////////////////////////////////////////////////////////////////
/////////////////////////// DEFINES /////////////////////////////
/////////////////////////////////////////////////////////////////

////////////////////////////////////////////////////////////////////////////
/////////////////////////// Variables Globales /////////////////////////////
////////////////////////////////////////////////////////////////////////////
TGeneral       gTablaGeneral[kNumEfectos+1];
int            gTiempo;

////////////////////////////////////////////////////////////////////////////
//////////////////////////// Tabla de tiempos //////////////////////////////
////////////////////////////////////////////////////////////////////////////

const float gTablaTiempos[] = {
    // FUEGO
    ////////////////
      3.85, // letras...
      5.80,
      7.69,
      9.63,
     11.49,
     13.43,
     15.38,
     17.30,
     19.23,
     21.14,
     23.04,
     24.98,
     26.89,
     28.81,
     30.73, // fin fuego

    // ROB
    ////////////////
     //30.80,
     //32.67,
     //34.62,
     //36.57,
     38.40, // estiramientos...
     40.38,
     42.27,
     44.20,
     46.10,  // fin rob
     
    // BLOBS
    ////////////////
     //47.06,
     //48.01,
     //48.96,
     //49.96,
     //50.91,
     //51.86,
     //52.80,
     //53.80,
     //54.72,
     //55.67,
     //56.62,
     //57.60,
     //58.55,
     //59.51,
     //60.54,
     61.47,  // fin blobs
     
    // PLASMA
    ////////////////
     //62.43,
     //63.38,
     //64.30,
     //65.28,
     //66.21,
     //67.16,
     //68.14,
     //69.06,
     //70.07,
     //71.02,
     //71.99,
     //72.96,
     //73.91,
     //74.86,
     //75.84,
     //76.82;
     //77.76,
     //78.69,
     //79.69,
     //80.65,
     //81.60,
     //82.60,
     //83.50,
     //84.47,
     //85.40,
     //86.37,
     87.00,  // fin plasma
          
    // HN1
    ////////////////
     //88.28,
     //89.31,
     //90.21,
     //91.19,
     92.13,  // fin hn1
          
    // ROTO
    ////////////////
                // parte 47: rotozoom
     93.07,
     94.07,
     95.02,
     96.02,
     96.95,
     97.95,
     98.87,
     99.87,
     100.78,
     101.76,
     102.71,
     103.71,
     104.63,
     105.61,
     106.58,
     107.48,    // parte 32: rotozoom doble
     108.49,
     109.44,
     110.42,
     111.37,
     112.34,
     113.32,
     114.30,
     115.26,
     116.15,
     117.07,
     118.02,
     118.90,
     119.90,
     120.96,
     121.91,
     122.86,    // parte 16: efecto rallado
     123.79,
     124.81,
     125.76,
     126.74,
     127.69,
     128.65,
     129.62,
     130.55,
     131.44,
     132.47,
     133.40,
     134.37,
     135.30,
     136.31,
     137.23,  // fin roto

    // SHPBX
    ////////////////
    138.21,
    139.23,
    140.16,
    141.11,
    142.07, // fin? primer greet
    143.05,
    143.98,
    144.96,
    145.93,
    146.84,
    147.82,
    148.83,
    149.79,
    150.64,
    151.65,
    152.65,
    153.61,
    154.53,
    155.50,
    156.52,
    157.39,
    158.40,
    159.28,
    160.28,
    161.28,
//    162.23,
//    163.19,
//    164.12,
//    165.06,
//    166.05,
//    167.00,
//    167.98,
//    168.92,
    169.00   // fin shpbx   /**/
};

////////////////////////////////////////////////////////////////////////////
/////////////////////////// Funciones Utiles ///////////////////////////////
////////////////////////////////////////////////////////////////////////////

//////////////////////////////////////////////////////
/////////////// FUNCIONES PRINCIPALES ////////////////
//////////////////////////////////////////////////////


unsigned long CntEft = 0;

int
_NULL_event()
{
   if ((aClock() - gTiempo) > (int)(60*gTablaTiempos[CntEft]*205/208))
   {
      CntEft++;
      return 0;
   } 
   else return 1;
}

void
InicializarEfectos ()
{
   u16 i;
   
   /*                               */
   /* Inicializa Tabla de funciones */
   /*                               */

   // INTRODUCCI�N
   i = 0;
   gTablaGeneral [i++].Funcion.Inicializar = fire_Inicializar;
   gTablaGeneral [i++].Funcion.Inicializar = rob_Inicializar;
   gTablaGeneral [i++].Funcion.Inicializar = blobs_Inicializar;
   gTablaGeneral [i++].Funcion.Inicializar = plasma_Inicializar;
   gTablaGeneral [i++].Funcion.Inicializar = hn1_Inicializar;
   gTablaGeneral [i++].Funcion.Inicializar = roto_Inicializar;
   gTablaGeneral [i++].Funcion.Inicializar = shpbx_Inicializar;

   /*                                  */
   /* Inicializa Efectos (Precalculos) */
   /*                                  */

   for (i=0; i < kNumEfectos; i++)
       gTablaGeneral[i].Funcion.Inicializar (i);
   
   /*                                    */
   /* El ultimo siempre apunta a NULL ;D */
   /*                                    */

   gTablaGeneral[kNumEfectos].Datos.in = NULL;
}

void
Liberar (unsigned long ETG)
{
   if (gTablaGeneral[ETG].Liberar != NULL)
   {
         gTablaGeneral[ETG].Funcion.Terminar(ETG);
      free (gTablaGeneral[ETG].Liberar);
   }
}

void
InicializarMusica1 ()
{
    MP_InitArm();
}

void
InicializarMusica2 ()
{
    // play
    MP_PlayModuleArm(_binary_module_bin_start, 0);
}

void
TerminarMusica()
{
    int volumen = 100;
    do {
        MP_SetVolumeArm(volumen);
        volumen -= 4;
        WaitForFullVsync();
    } while (volumen);
}

