#define INTERUPT_C

#include "gba.h"
#include "dma.h"
#include "sprite.h"
#include "interupts.h"
#include "backgrounds.h"

#include "../snd/GbaPlayer.h"
#include "../efectos.h"

u16              gCnt;   // efecto actual

//these are my function definitios to let the c compiler know what I am talking about

void VBLANK(void) IN_IWRAM;
void HBLANK(void);  //put this in ram to make it fast
                            //you may also notice that I make this with arm instructions
                            //just look in the makeme.bat
void DMA0(void);
void DMA1(void) IN_IWRAM;
void DMA2(void);
void DMA3(void);
void VCOUNT(void);
void TIMMER0(void);
void TIMMER1(void);
void TIMMER2(void);
void TIMMER3(void);
void KEYBOARD(void);
void CART(void);
void COMUNICATION(void);


//here is a function to enable interupts.  If it is VBLANK or HBLANK it sets REG_DISPSTAT to the apropriate values
//all others you will have to do on your own.
/*---------------------------------------some externals------------------------*/
extern FIXED SIN[360];      //my LUTs for sign and cosign
extern FIXED COS[360];
extern FIXED div[320];
extern int angle;
extern FIXED x;      //x and y background scroll
extern FIXED y;
extern int height;     //height of the player

/*-------enable/disable interupt rutien---------------*/
void EnableInterupts(u16 interupts)
{
    REG_IME = 0;  //probably not necessary but not a good idea to change interupt registers when an interupt is ocuring

    
    if(interupts | INT_VBLANK)
        REG_DISPSTAT |= 0x8;

    if(interupts | INT_HBLANK)
        REG_DISPSTAT |= 0x10;
    

    REG_IE |= interupts;

    REG_IME = 1;

}

void DisableInterupts(u16 interupts)
{
    REG_IE &= ~interupts;

    if ((interupts = INT_ALL)) //this is were that ALL comes in
        REG_IME = 0;  //disable all interupts;
}




//here is our table of function pointers.  I added the definition of fp to gba.h because I figure it would be usefull
//to have elsewhere
//typedef void (*fp)(void);   this is the definition you will find in gba.h.  It is just delaring fp to represent a pointer
//to a function


//here is our table of functions.  Once interupts are enabled in crt0.s you will not be able to link your code if this table is not pressent.
//the interupts must be listed in that order.

fp IntrTable[]  = 
{
    VBLANK,
    HBLANK,
    VCOUNT,
    TIMMER0,
    TIMMER1,
    TIMMER2,
    TIMMER3,
    COMUNICATION,
    DMA0,
    DMA1,
    DMA2,
    DMA3,
    KEYBOARD,
    CART
};



//all our interupt functions empty for now.

void VBLANK()
{
    CopyOAM();				//Copies our sprite array into OAM.
    __gMyClockVar__++;
    MP_UpdateArm(); // Update song
    if (gCnt < kNumEfectos)
        gTablaGeneral[gCnt].Funcion.Actualizar (gCnt);
    REG_IF |= INT_VBLANK;        
}
void HBLANK(void) 
{
/*  
//  Modo 7

    int center_y;   //these are the points around which the the screen rotates
    int center_x; 
    int tempS = SIN[angle];//some temps to hold the sine cos values so we eliminate all those table acceses
    int tempC = COS[angle];//actualy only need to do this once per frame so we could store then in a global
                            //and calc durring the vblank if we wanted
    
    int zoom;

    zoom = (height*div[REG_VCOUNT])>>16; //div is fixed 16.16 height is fixed 24.8 so I end up with 8.24..
                                            //so I shift away 16 bits to give me a zoom that is fixed 24.8
                                            //you may notice that I still have some distortion at the bottom of the screen
                                            //this can probably be fixed by keeping some of the presision in the 
                                            //value and shifting later

    center_y = (180 * zoom)>>2;  //set for the center of the screen in the x direction and slightlu
    center_x = (120 * zoom)>>2; //bellow the screen for the Y (about were the observer would be standing)
    
    REG_BG2X = (((x)-center_y*tempS-center_x*tempC))>>14; //x and y are the background scroll factors
    REG_BG2Y = (((y)-center_y*tempC+center_x*tempS))>>14;
         
    REG_BG2PA  = (tempC*zoom)>>16;  //cos&sin are LUTs that are .8 fixed numbers
    REG_BG2PB  = (tempS*zoom)>>16;  //zoom is also fixed
    REG_BG2PC  = (-tempS*zoom)>>16;
    REG_BG2PD  = (tempC*zoom)>>16;
*/    
    REG_IF |= INT_HBLANK;
}
void DMA0(void)
{
    REG_IF |= INT_DMA0;
}

void DMA1(void)
{
    // Sonido
    MP_IntHandler();
    REG_IF |= INT_DMA1;
}
void DMA2(void)
{
    REG_IF |= INT_DMA2;
}
void DMA3(void)
{
    REG_IF |= INT_DMA3;
}
void VCOUNT(void)
{
    REG_IF |= INT_VCOUNT;
}
void TIMMER0(void)
{
    REG_IF |= INT_TIMMER0;
}
void TIMMER1(void)
{
    REG_IF |= INT_TIMMER1;
}
void TIMMER2(void)
{
    REG_IF |= INT_TIMMER2;
}
void TIMMER3(void)
{
    REG_IF |= INT_TIMMER3;
}
void KEYBOARD(void)
{
    REG_IF |= INT_TIMMER3;
}
void CART(void)
{
    REG_IF |= INT_CART;
}
void COMUNICATION(void)
{
    REG_IF |= INT_COMUNICATION;
}
