/***************\
* Sprite.h     *
*              *
\***************/

#ifndef SPRITE_H
#define SPRITE_H

#include "gba.h"

////////////////////////////////
// HARDWARE SPRITES
////////////////////////////////

//Atribute0 stuff
#define ROTATION_FLAG       0x100
#define SIZE_DOUBLE         0x200
#define MODE_NORMAL         0x0
#define MODE_TRANSPARENT    0x400
#define MODE_WINDOWED       0x800
#define MOSAIC              0x1000
#define COLOR_16            0x0000
#define COLOR_256           0x2000
#define SQUARE              0x0
#define TALL                0x8000
#define WIDE                0x4000

//Atribute1 stuff
#define ROTDATA(n)          ((n) << 9)
#define HORIZONTAL_FLIP     0x1000
#define VERTICAL_FLIP       0x2000
#define SIZE_8              0x0
#define SIZE_16             0x4000
#define SIZE_32             0x8000
#define SIZE_64             0xC000

//atribute2 stuff

#define PRIORITY(n)         ((n) << 10)
#define PALETTE(n)          ((n) << 12)


/////structs/////

typedef struct tagOAMEntry
{
    u16 attribute0;
    u16 attribute1;
    u16 attribute2;
    u16 attribute3;
} OAMEntry, *pOAMEntry;

typedef struct tagRotData
{
    u16 filler1[3];
    u16 pa;

    u16 filler2[3];
    u16 pb; 
        
    u16 filler3[3];
    u16 pc; 

    u16 filler4[3];
    u16 pd;
} RotData, *pRotData;


void InitializeSprites(void);
void InitializeSprite(int number);
__attribute__(( long_call )) void CopyOAM(void); // Copy our sprite array to OAM

extern OAMEntry sprites[128]; //My sprite array
extern pRotData rotData; //My rotation and scaling array


////////////////////////////////
// SOFTWARE SPRITES
////////////////////////////////

inline u16 sumaPixelsSat(u16 pia, u16 pib);
inline u16 sumaPixelsBlend(u16 pia, u16 pib);

#define SPRITESOFT_MODO       7     // for the "new" mode 5
#define SPRITESOFT_SUMSAT   128     // saturated addition
#define SPRITESOFT_BLEND    256     // 0.5 alpha blending
#define SPRITESOFT_COLORKEY 512     // color key
void pintaSpriteSoftware(u16 *sprite, int x, int y, int ancho, int alto, u16 *buffer, int modo);


#endif  // SPRITE_H
