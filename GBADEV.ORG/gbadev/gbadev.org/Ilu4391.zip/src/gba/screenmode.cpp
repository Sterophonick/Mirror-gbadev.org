#include "screenmode.h"
#include "gba.h"

// Mode 5 flipped + scaled 2x
// http://www.gbadev.org/files/newmode.txt

void setmode5flipped(void)
{
  REG_BG2PA = 0;    // horizontal texture step in x
  REG_BG2PB = 256;  // vertical texture step in x
  REG_BG2PC = 128;  // horizontal texture step in y
  REG_BG2PD = 0;    // vertical texture step in y
}

void unsetmode5flipped(void)
{
  REG_BG2PA = 256;  // horizontal texture step in x
  REG_BG2PB = 0;    // vertical texture step in x
  REG_BG2PC = 0;    // horizontal texture step in y
  REG_BG2PD = 256;  // vertical texture step in y
}

