#include "sprite.h"

////////////////////////////////
// HARDWARE SPRITES
////////////////////////////////

OAMEntry sprites[128]; //My sprite array
pRotData rotData = (pRotData)sprites; //My rotation and scaling array

void InitializeSprites(void)
{
    u16 loop;
    for (loop = 0; loop < 128; loop++)
    {
        sprites[loop].attribute0 = 160; //y to > 159
        sprites[loop].attribute1 = 240; //x to > 239
    }
}

void InitializeSprite(int number)
{
    sprites[number].attribute0 = 160; //y to > 159
    sprites[number].attribute1 = 240; //x to > 239
}

// Copy our sprite array to OAM
void CopyOAM(void)
{
	u16 loop;
	u16* temp;
	temp = (u16*)sprites;
	for(loop = 0; loop < 128*4; loop++)
	{
		OAMmem[loop] = temp[loop];
	}
}


////////////////////////////////
// SPRITES SOFTWARE
////////////////////////////////

inline u16 sumaPixelsSat(u16 pia, u16 pib)
{
    int r = (pia&(31<<10)) + (pib&(31<<10));
    if (r > (31<<10)) r = (31<<10);
    int g = (pia&(31<<5)) + (pib&(31<<5));
    if (g > (31<<5)) g = (31<<5);
    int b = (pia&31) + (pib&31);
    if (b > 31) b = 31;
    return r|g|b;
}

inline u16 sumaPixelsBlend(u16 pia, u16 pib)
{
    int r = ((pia>>1)&(15<<10)) + ((pib>>1)&(15<<10));
    int g = ((pia>>1)&(15<<5)) + ((pib>>1)&(15<<5));
    int b = ((pia>>1)&15) + ((pib>>1)&15);
    return r|g|b;
}

void pintaSpriteSoftware(u16 *sprite, int x, int y, int ancho, int alto, u16 *buffer, int modo)
{
    int resx;
    if (((modo & SPRITESOFT_MODO) == 5) || ((modo & SPRITESOFT_MODO) == 6)) resx = 160;
    else resx = 240;
    
    if (modo & SPRITESOFT_COLORKEY)
    {
        if (modo & SPRITESOFT_SUMSAT)
        {
            if ((modo & SPRITESOFT_MODO) == 6)
            {
                buffer += x*resx + y;
                do {
                    int ancho2 = ancho;
                    do {
                        if (*sprite)
                            *buffer = sumaPixelsSat(*buffer, *sprite);
                        sprite++;
                        buffer+=resx;
                    } while (--ancho2);
                    buffer += -resx*ancho + 1;
                } while (--alto);
            }
            else    // modos restantes
            {
                buffer += y*resx + x;
                do {
                    int ancho2 = ancho;
                    do {
                        if (*sprite)
                            *buffer = sumaPixelsSat(*buffer, *sprite);
                        sprite++;
                        buffer++;
                    } while (--ancho2);
                    buffer += resx - ancho;
                } while (--alto);
            }
        }
        else if (modo & SPRITESOFT_BLEND)
        {
            if ((modo & SPRITESOFT_MODO) == 6)
            {
                buffer += x*resx + y;
                do {
                    int ancho2 = ancho;
                    do {
                        if (*sprite)
                            *buffer = sumaPixelsBlend(*buffer, *sprite);
                        sprite++;
                        buffer+=resx;
                    } while (--ancho2);
                    buffer += -resx*ancho + 1;
                } while (--alto);
            }
            else    // modos restantes
            {
                buffer += y*resx + x;
                do {
                    int ancho2 = ancho;
                    do {
                        if (*sprite)
                            *buffer = sumaPixelsBlend(*buffer, *sprite);
                        sprite++;
                        buffer++;
                    } while (--ancho2);
                    buffer += resx - ancho;
                } while (--alto);
            }
        }
        else    // pintamos normal
        {
            if ((modo & SPRITESOFT_MODO) == 6)
            {
                buffer += x*resx + y;
                do {
                    int ancho2 = ancho;
                    do {
                        if (*sprite)
                            *buffer = *sprite;
                        sprite++;
                        buffer += resx;
                    } while (--ancho2);
                    buffer += -resx*ancho + 1;
                } while (--alto);
            }
            else    // modos restantes
            {
                buffer += y*resx + x;
                do {
                    int ancho2 = ancho;
                    do {
                        if (*sprite)
                            *buffer = *sprite;
                        sprite++;
                        buffer++;
                    } while (--ancho2);
                    buffer += resx - ancho;
                } while (--alto);
            }
        }
    }
    else // no color key
    {
        if (modo & SPRITESOFT_SUMSAT)
        {
            if ((modo & SPRITESOFT_MODO) == 6)
            {
                buffer += x*resx + y;
                do {
                    int ancho2 = ancho;
                    do {
                        *buffer = sumaPixelsSat(*buffer, *(sprite++));
                        buffer+=resx;
                    } while (--ancho2);
                    buffer += -resx*ancho + 1;
                } while (--alto);
            }
            else    // modos restantes
            {
                buffer += y*resx + x;
                do {
                    int ancho2 = ancho;
                    do {
                        *buffer = sumaPixelsSat(*buffer, *(sprite++));
                        buffer++;
                    } while (--ancho2);
                    buffer += resx - ancho;
                } while (--alto);
            }
        }
        else if (modo & SPRITESOFT_BLEND)
        {
            if ((modo & SPRITESOFT_MODO) == 6)
            {
                buffer += x*resx + y;
                do {
                    int ancho2 = ancho;
                    do {
                        *buffer = sumaPixelsBlend(*buffer, *(sprite++));
                        buffer+=resx;
                    } while (--ancho2);
                    buffer += -resx*ancho + 1;
                } while (--alto);
            }
            else    // modos restantes
            {
                buffer += y*resx + x;
                do {
                    int ancho2 = ancho;
                    do {
                        *buffer = sumaPixelsBlend(*buffer, *(sprite++));
                        buffer++;
                    } while (--ancho2);
                    buffer += resx - ancho;
                } while (--alto);
            }
        }
        else    // pintamos normal
        {
            if ((modo & SPRITESOFT_MODO) == 6)
            {
                buffer += x*resx + y;
                do {
                    int ancho2 = ancho;
                    do {
                        *(buffer+=resx) = *(sprite++);
                    } while (--ancho2);
                    buffer += -resx*ancho + 1;
                } while (--alto);
            }
            else    // modos restantes
            {
                buffer += y*resx + x;
                do {
                    int ancho2 = ancho;
                    do {
                        *(buffer++) = *(sprite++);
                    } while (--ancho2);
                    buffer += resx - ancho;
                } while (--alto);
            }
        }
    }
}
