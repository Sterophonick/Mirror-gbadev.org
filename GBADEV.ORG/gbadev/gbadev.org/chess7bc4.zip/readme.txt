2 Player Chess

About:

This is just a chess board that enables two people to play chess. Developing a chess algorithm
for the GBA would have been much too time consuming, so the user is able to move pieces,
and take pieces. The program doesn't check to see if any of the moves are legal or not.
You can change the background using the left/right shoulder buttons.

Controls:

Left/Right, Up/Down - Move Cursor
A - Select Piece / Move Piece / Take Piece
B - Deselect Piece

L Shoulder / R Shoulder - Advance Background Picture

Any comments or questions (they are more than welcome--I love feedback!)
contact me:

jcraymond@coolgoose.com


