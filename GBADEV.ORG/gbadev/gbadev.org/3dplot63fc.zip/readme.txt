Mode5 3D Plotter for the GBA. (07/2001)
Rotate some plots on differents axis and
display a "screen reduction" of the displayed
screen... (try it =) 

Written in C.
by Bruno Vedder  (bruno.vedder@wanadoo.fr)

It was build with a cross gcc under Linux 2.2.16.
Gfx were made with the gimp :-)  (nice c-source output !)
The intro was tested with VGBA, all seems to work fine
excepted the frame rate maybe (Linux VGBA don t display it !).

    I release the source cause, it might be usefull for someone, like me,
starting with gba coding, but remember it s not an example of good
C writting...
    A lot of things could be better, but speed was not my goal.
If you have any comment or question, feel free to email me.
I d like to know, frame rate, on emulator even a true hardware, if 
it works .

Greets to:
Stephen Stair   (for testing on windows emulator, and his sources,answers etc..)
Joat		(cool docs)
Nokturn		(tutorials)
Dovoto		 (  " " )
Richard "Ries" van der Brugge (compiler advice,sources)
The Forgotten   :)
And all sources contributors and consoles coders.
