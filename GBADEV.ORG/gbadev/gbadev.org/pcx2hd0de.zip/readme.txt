Hi all, i'm bored.

Here is the basic source to take a 16X(16*v) tiles in pcx, where v is a variable, and make it into a .h file.
Works almost in the same way as pcx2sprite (only allowing 16pixels of length).

Ethos

