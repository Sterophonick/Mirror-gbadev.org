#include <stdio.h>
#include <stdlib.h> 
#include <string.h>
 
 
int main (int argc, char ** argv) {
  FILE *inf;
  char *image, pal[768];
  unsigned char *trueImage;
  int width, height; 
  int x, y;
  int i,j,k;
  //char * pch;
  char temp1, temp2;
  unsigned char r,g,b;
  x = 0;
  y = 0;
  unsigned short finalV;
  unsigned long finalL;
  
  if (argc != 2) {
  	printf("Usage: pcx2h <input_file>\n");
    exit(0);
  }
  inf = fopen(argv[1], "rb");

  if(inf == NULL)
  {
    printf("Could not open the file: %s.\n", argv[1]);
    exit(0);
  }

  fseek(inf, 8, SEEK_SET);

  width = fgetc(inf);
  width = ((fgetc(inf) << 8) | width) + 1;
  height = fgetc(inf);
  height = ((fgetc(inf) << 8) | height) + 1;

  image = (char *)malloc(width * height);
  trueImage = (char *)malloc(width * height);
  
  fseek(inf, -768, SEEK_END);
  fread(pal, 1, 768, inf);

  fseek(inf, 128, SEEK_SET);
  fread(image, 1, width * height, inf);
  
  printf ("Width: %d\nHeight: %d\n", width, height);
  
  while((y < height) && ((x * y) < (width * height))){
    temp1 = *image;
    image++;

    if((temp1 & 192) == 192){                              
      temp2 = *image;
      image++;

      for(i = 0; i < (temp1 & 63); i++){
        trueImage [x + (y* width)] = temp2;   
       	x++;
        if(x == width){
        	y++; x = 0; 
        }
      }
    }

    else {                                 
      trueImage [x + (y* width)] = temp1;
     
      x++;
      if(x == width) {
      	y++; x = 0; 
      }
    }
  }   

  fclose (inf);

  inf = fopen("b_tiles.h", "w+t");
  fputs ("#ifndef B_TILE_H\n#define B_TILE_H\n\n", inf);
  
  fputs ("const u16 b_palette [] = {\n",inf);
  for (i = 0; i < 256; i++){
  	r = pal[i*3];
  	g = pal[i*3 + 1];
  	b = pal[i*3 + 2];
  	r = r >> 3; 	
  	g = g >> 3;
  	b = b >> 3; 	
    finalV = (r + (g << 5) + (b << 10));
    fprintf (inf,"0x%.4X", finalV);
   	fprintf (inf,"\n");
  }
  
  fputs ("};\n\n", inf);
  
  
  fputs ("const u16 b_tiles [] = {\n",inf);

  finalL = height / 8;
  for (k = 0; k < finalL; k++) {
  	for (j = 0; j < 8; j++) {
  		for (i = 0; i < 4; i++) {
  			fprintf (inf, "0X%.2X", trueImage [(i*2) + 1 + (j * 16) + (k * 128)]);
  			fprintf (inf, "%.2X,", trueImage [(i*2) + (j * 16) + (k * 128)]);		
  		}
  		if (j == 3)
  			fputs ("\n",inf);
  	}
  	fputs ("\n",inf);
  	for (j = 0; j < 8; j++) {
  		for (i = 4; i < 8; i++) {
  			fprintf (inf, "0X%.2X", trueImage [(i*2) + 1 + (j * 16) + (k * 128)]);
  			fprintf (inf, "%.2X", trueImage [(i*2) + (j * 16) + (k * 128)]);
  			if (i != 7 || j != 7 || k != finalL -1) 
  				fputs (",", inf);
  		}
  		if (j == 3)
  			fputs ("\n",inf);
  	}
  	fputs ("\n",inf); 	
  }
  		

  fputs ("};\n\n#endif\n", inf);
  fclose (inf);     
  return 0;
  
  
}
