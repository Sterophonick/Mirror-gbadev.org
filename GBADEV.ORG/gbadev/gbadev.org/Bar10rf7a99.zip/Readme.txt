
  Progress on this project has been slow, mainly due to past
 work commitments. But as luck would have it, I have now
 been made redundant and have time to work on Barbarian.

  Work on the game is now going on at an accelerated rate
 and I am looking at a final release date during the first
 quarter of 2004.

 Changes so far from last release:-

 * Completely reworked the animations and cut down the number
   of frames per move (the GBA version still has more frames
   than the origonal version).
 * The sword is now incorporated into each frame whereas before
   the sword for most frames was drawn seperately due mainly to
   a smaller cell size. (NOT ALL FRAMES HAVE SWORD IN YET)
 * Painted in all clothing.
 * Completely reorganised all data structures to make frame
   drawing and animations quicker and more compact code-wise.
   This also meant a complete rewrite for most of the code but
   I'm pleased with the result. I've now had to put in a delay
   loop which gives me spare CPU time....
 * Added hit detection. You can now hack the opponent about and
   he responds by staggering or falling over. (Decapitation also
   done.)
 * Added blood splatter at point of impact.
 * Added blood staining to the floor (An extra improvment on
   the origonal).
 * Added scoring updates for successful attacks.
 * Added life level updates for successful attacks.
 * ADDED SOUND. Full direct sound added during fights.
 * Fixed bug on title screen which caused glitching if A or B
   pressed instead of START.

 TO DO.

 * AI
 * Tweaking. (Sfx, Gfx and collision.)

 Hope you like it. Feedback is welcome.

 mike.hawkins@fsmail.net

 mike@gbacoding.fsnet.co.uk


 Mike
