English:
This is my first GBA demo. I used devkitAdvance by Jason Wilkins with Jeff Frohweins, header files from Dovoto's (www.thepernproject.com) tutorial and Visual C++ 6. For testing and debugging I used Mappy, VisualBoyAdvance and BoycottAdvance.

Thanks to:
Dovoto
staringmonkey
http://www.gbadev.org/
http://www.devrs.com/gba/
Jeff Frohweins
Jason Wilkins
Forgotten
Gollum
BottledLight

Espa�ol:
Esta es mi primera demo en GBA. He usado el devkitAdvance de Jason Wilkins y Jeff Frohweins, los ficheros de cabecera de los tutoriales de Dovoto (www.thepernproject.com) y el Visual C++ 6. Para prueba y debug he usado Mappy, VisualBoyAdvance and BoycottAdvance.

Gracias a:
Dovoto
staringmonkey
http://www.gbadev.org/
http://www.devrs.com/gba/
Jeff Frohweins
Jason Wilkins 
Forgotten
Gollum
BottledLight
