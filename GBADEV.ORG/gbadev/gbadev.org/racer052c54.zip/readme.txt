Racer v0.5
By Premandrake
Homepage: http://www.fortunecity.com/rivendell/soldier/619/gba.html
Email: premandrake@hotmail.com

Introduction
------------

Racer is a little test of the GBA that I wrote for fun.  I just wanted to
see how easy it was to reproduce a basic racer.  In the future this might
expand somewhat to have cars to race against.  I may also release the map
editor I used to make the map, as it has some nifty features.

How it works
------------

The code uses some pretty advanced features of the gba and currently the
only emulators it runs on are vgba and igba.  It uses repeating hblank
to make the mode7 effect and a vcount-equals interrupt to change screen
mode from the one at the top.  The racetrack is actually two-layers, one
for the track itself and one for the outside.

The car itself is just a simple sprite.

Map Editor
----------

This is a preview release of the editor that I've been working on.  It can
currently import a bitmap and automatically make a map out of it.  Then you
can export it to a gba specific format which is arranged as follows:

dword - number of tiles
dword - height of map (tiles)
dword - width of map (tiles)
256 words - palette in gba format
numTiles * 64 bytes - linear array of tiles stored in 1d format
width * height bytes - actual map
numTiles bytes - collision map for tiles (tile specific data)

There is an example map file included with the editor, so you can play around
with it and see what it can do.

Revision history
----------------
V0.1 - Got interrupts working and made a mode7 like track

V0.2 - Redesigned mode7 code to use repeating hblank

V0.3 - Started using custom map files
     - Implemented background scrolling to match movement

V0.4 -Implemented the car

V0.5 -Got collision detection sort of working
     -Made a cleaner map structure