Pete's l33t demo :)
~~~~~~~~~~~~~~~~~~~

Well it's been a while since I last released some stuff. Since then I've moved
my all my development over to my favourite OS, Linux ^_^

The triangle plotter has been optimised further, and with some help from
Jeff's FAQ some stuff is running from IWRAM now.`

As always, the code is messy :) Especially the hack to get clearscreen and
triangle code in IWRAM - something for me to work on...

'Select' does slow motion, 'Start' restarts after 1000 line stats.

VGBA doesn't like the demo but it works on my multiboot cable and on boycott
advance... There's also a bug in most emulators - the bottom 2 bits of the
stack pointer should be IGNORED. I.e writing sp += 4 to implement stm or ldm
is not ARM architecturally correct! I was a bit tight on regs and I wanted to
use this trick (thanks Charlie ;) to store a binary flag in sp :(

Next up I guess the maths stuff needs looking at, and maybe a 3D file
descriptor grammar and parser - I'm fed up of cut'n'pasting code in vim...

Enjoy.
--
Pete (dooby@bits.bris.ac.uk / http://bits.bris.ac.uk/dooby/)
