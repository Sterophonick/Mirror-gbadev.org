// l33t demo
// Pete (dooby@bits.bris.ac.uk)

#include "gba.h"

#define NULL	0

#define MULTIBOOT volatile const u8 __gba_multiboot;
MULTIBOOT

typedef struct vertex Vertex;
typedef struct face Face;
typedef struct object Object;

struct vertex {
  signed short int x, y, z;
};

struct face {
  Vertex v[4];
  unsigned short col;		// We may want 15bpp colours one day...
  struct face *n;		// Pointer to next face in object face list.
};

struct object {
  struct face *face;
  unsigned short angX;
  unsigned short angY;
  unsigned short angZ;
  unsigned short incX;
  unsigned short incY;
  unsigned short incZ;
  signed short offX;
  signed short offY;
  signed short offZ;
  struct object *n;
};

#define XOFF 120
#define YOFF 80

void psp(Face *temp) {
  int i;
  for(i = 0; i < 4; i ++) {
    temp->v[i].x = (temp->v[i].x * (temp->v[i].z + 256)) >> 8;
    temp->v[i].y = (temp->v[i].y * (temp->v[i].z + 256)) >> 8;
  }
}

void trs(Face *temp, signed short offX, signed short offY, signed short offZ) {
  int i;
  for(i = 0; i < 4; i ++) {
    temp->v[i].x += offX;
    temp->v[i].y += offY;
    temp->v[i].z += offZ;
  }
}

void rotX(Face *temp, signed long sin_val, signed long cos_val) {
  int i;
  signed short nz, ny;
  for(i = 0; i < 4; i ++) {
    nz = (signed short)(cos_val * temp->v[i].z - sin_val * temp->v[i].y) >> 7;
    ny = (signed short)(cos_val * temp->v[i].y + sin_val * temp->v[i].z) >> 7;
    temp->v[i].z = nz;
    temp->v[i].y = ny;
    temp->v[i].x = temp->v[i].x;
  }
}

void rotY(Face *temp, signed long sin_val, signed long cos_val) {
  int i;
  signed short nx, nz;
  for(i = 0; i < 4; i ++) {
    nx = (signed short)(cos_val * temp->v[i].x - sin_val * temp->v[i].z) >> 7;
    nz = (signed short)(cos_val * temp->v[i].z + sin_val * temp->v[i].x) >> 7;
    temp->v[i].x = nx;
    temp->v[i].z = nz;
    temp->v[i].y = temp->v[i].y;
  }
}

void rotZ(Face *temp, signed long sin_val, signed long cos_val) {
  int i;
  signed short nx, ny;
  for(i = 0; i < 4; i ++) {
    nx = (signed short)(cos_val * temp->v[i].x - sin_val * temp->v[i].y) >> 7;
    ny = (signed short)(cos_val * temp->v[i].y + sin_val * temp->v[i].x) >> 7;
    temp->v[i].x = nx;
    temp->v[i].y = ny;
    temp->v[i].z = temp->v[i].z;
    // Rounding experiment... Could be done faster in ASM using
    // mov	a1, a1, asr #7
    // addcs	a1, a1, #1
    //if(temp->v[i].x & 1 != 0) temp->v[i].x = (temp->v[i].x + 1) >> 1;
    //else temp->v[i].x = temp->v[i].x >> 1;
    // Rounding experiment...
    //if(temp->v[i].y & 1 != 0) temp->v[i].y = (temp->v[i].y + 1) >> 1;
    //else temp->v[i].y = temp->v[i].y >> 1;
  }
}

void copy(Face *dest, Face *src) {
  int i;

  // This can almost certainly be done quicker using some sort of memcpy.
  for(i = 0; i < 4; i ++) {
    dest->v[i].x = src->v[i].x;
    dest->v[i].y = src->v[i].y;
    dest->v[i].z = src->v[i].z;
  }
  dest->col = src->col;
}

void init_viper(Object *o, Face f[]) {
  // top
  f[0].v[0].x = -19; f[0].v[0].y =   5; f[0].v[0].z =  -9;
  f[0].v[1].x =   0; f[0].v[1].y =   5; f[0].v[1].z =   0;
  f[0].v[2].x = -19; f[0].v[2].y =   5; f[0].v[2].z =   9;
  f[0].v[3].x = -19; f[0].v[3].y =   5; f[0].v[3].z =   9;
  f[0].col = 1;

  // left
  f[1].v[0].x = -19; f[1].v[0].y =   5; f[1].v[0].z =   9;
  f[1].v[1].x =   0; f[1].v[1].y =   5; f[1].v[1].z =   0;
  f[1].v[2].x =  19; f[1].v[2].y =   0; f[1].v[2].z =   0;
  f[1].v[3].x = -19; f[1].v[3].y =   0; f[1].v[3].z =  19;
  f[1].col = 2;

  // right
  f[2].v[0].x = -19; f[2].v[0].y =   0; f[2].v[0].z = -19;
  f[2].v[1].x =  19; f[2].v[1].y =   0; f[2].v[1].z =   0;
  f[2].v[2].x =   0; f[2].v[2].y =   5; f[2].v[2].z =   0;
  f[2].v[3].x = -19; f[2].v[3].y =   5; f[2].v[3].z =  -9;
  f[2].col = 3;

  // bottom
  f[3].v[0].x = -19; f[3].v[0].y =  -5; f[3].v[0].z =   9;
  f[3].v[1].x =   0; f[3].v[1].y =  -5; f[3].v[1].z =   0;
  f[3].v[2].x = -19; f[3].v[2].y =  -5; f[3].v[2].z =  -9;
  f[3].v[3].x = -19; f[3].v[3].y =  -5; f[3].v[3].z =  -9;
  f[3].col = 4;

  // bottom left
  f[4].v[0].x = -19; f[4].v[0].y =   0; f[4].v[0].z =  19;
  f[4].v[1].x =  19; f[4].v[1].y =   0; f[4].v[1].z =   0;
  f[4].v[2].x =   0; f[4].v[2].y =  -5; f[4].v[2].z =   0;
  f[4].v[3].x = -19; f[4].v[3].y =  -5; f[4].v[3].z =   9;
  f[4].col = 5;

  // bottom right
  f[5].v[0].x = -19; f[5].v[0].y =  -5; f[5].v[0].z =  -9;
  f[5].v[1].x =   0; f[5].v[1].y =  -5; f[5].v[1].z =   0;
  f[5].v[2].x =  19; f[5].v[2].y =   0; f[5].v[2].z =   0;
  f[5].v[3].x = -19; f[5].v[3].y =   0; f[5].v[3].z = -19;
  f[5].col = 6;

  // back lower left
  f[6].v[0].x = -19; f[6].v[0].y =  -5; f[6].v[0].z =   9;
  f[6].v[1].x = -19; f[6].v[1].y =  -5; f[6].v[1].z =  -9;
  f[6].v[2].x = -19; f[6].v[2].y =   5; f[6].v[2].z =   9;
  f[6].v[3].x = -19; f[6].v[3].y =   0; f[6].v[3].z =  19;
  f[6].col = 7;

  // back upper right
  f[7].v[0].x = -19; f[7].v[0].y =  -5; f[7].v[0].z =  -9;
  f[7].v[1].x = -19; f[7].v[1].y =   0; f[7].v[1].z = -19;
  f[7].v[2].x = -19; f[7].v[2].y =   5; f[7].v[2].z =  -9;
  f[7].v[3].x = -19; f[7].v[3].y =   5; f[7].v[3].z =   9;
  f[7].col = 7;

  // Initialise object face list.
  o->face = &f[0];
  f[0].n = &f[1];
  f[1].n = &f[2];
  f[2].n = &f[3];
  f[3].n = &f[4];
  f[4].n = &f[5];
  f[5].n = &f[6];
  f[6].n = &f[7];
  f[7].n = 0;

  // Initialise object offset & rotation attributes.
  o->angX =    0;
  o->angY =    0;
  o->angZ =    0;
  o->incX =    1;
  o->incY =    3;
  o->incZ =    2;
  o->offX =   60;
  o->offY =   40;
  o->offZ =    0;
}

void init_gecko(Object *o, Face f[]) {
  // top
  f[0].v[0].x = -12; f[0].v[0].y =   4; f[0].v[0].z =  -8;
  f[0].v[1].x =  12; f[0].v[1].y =   0; f[0].v[1].z =  -4;
  f[0].v[2].x =  12; f[0].v[2].y =   0; f[0].v[2].z =   4;
  f[0].v[3].x = -12; f[0].v[3].y =   4; f[0].v[3].z =   8;
  f[0].col = 1;

  // top left
  f[1].v[0].x = -12; f[1].v[0].y =   4; f[1].v[0].z =   8;
  f[1].v[1].x =  12; f[1].v[1].y =   0; f[1].v[1].z =   4;
  f[1].v[2].x =  -8; f[1].v[2].y =   0; f[1].v[2].z =  19;
  f[1].v[3].x =  -8; f[1].v[3].y =   0; f[1].v[3].z =  19;
  f[1].col = 2;

  // top right
  f[2].v[0].x =  -8; f[2].v[0].y =   0; f[2].v[0].z = -19;
  f[2].v[1].x =  12; f[2].v[1].y =   0; f[2].v[1].z =  -4;
  f[2].v[2].x = -12; f[2].v[2].y =   4; f[2].v[2].z =  -8;
  f[2].v[3].x = -12; f[2].v[3].y =   4; f[2].v[3].z =  -8;
  f[2].col = 3;

  // bottom
  f[3].v[0].x = -12; f[3].v[0].y =  -4; f[3].v[0].z =   8;
  f[3].v[1].x =  12; f[3].v[1].y =   0; f[3].v[1].z =   4;
  f[3].v[2].x =  12; f[3].v[2].y =   0; f[3].v[2].z =  -4;
  f[3].v[3].x = -12; f[3].v[3].y =  -4; f[3].v[3].z =  -8;
  f[3].col = 4;

  // bottom left
  f[4].v[0].x =  -8; f[4].v[0].y =   0; f[4].v[0].z =  19;
  f[4].v[1].x =  12; f[4].v[1].y =   0; f[4].v[1].z =   4;
  f[4].v[2].x = -12; f[4].v[2].y =  -4; f[4].v[2].z =   8;
  f[4].v[3].x = -12; f[4].v[3].y =  -4; f[4].v[3].z =   8;
  f[4].col = 5;

  // bottom right
  f[5].v[0].x = -12; f[5].v[0].y =  -4; f[5].v[0].z =  -8;
  f[5].v[1].x =  12; f[5].v[1].y =   0; f[5].v[1].z =  -4;
  f[5].v[2].x =  -8; f[5].v[2].y =   0; f[5].v[2].z = -19;
  f[5].v[3].x =  -8; f[5].v[3].y =   0; f[5].v[3].z = -19;
  f[5].col = 6;

  // back left
  f[6].v[0].x =  -8; f[6].v[0].y =   0; f[6].v[0].z =  19;
  f[6].v[1].x = -12; f[6].v[1].y =  -4; f[6].v[1].z =   8;
  f[6].v[2].x = -12; f[6].v[2].y =   4; f[6].v[2].z =   8;
  f[6].v[3].x = -12; f[6].v[3].y =   4; f[6].v[3].z =   8;
  f[6].col = 7;

  // back right
  f[7].v[0].x = -12; f[7].v[0].y =  -4; f[7].v[0].z =  -8;
  f[7].v[1].x =  -8; f[7].v[1].y =   0; f[7].v[1].z = -19;
  f[7].v[2].x = -12; f[7].v[2].y =   4; f[7].v[2].z =  -8;
  f[7].v[3].x = -12; f[7].v[3].y =   4; f[7].v[3].z =  -8;
  f[7].col = 7;

  // back centre
  f[8].v[0].x = -12; f[8].v[0].y =  -4; f[8].v[0].z =   8;
  f[8].v[1].x = -12; f[8].v[1].y =  -4; f[8].v[1].z =  -8;
  f[8].v[2].x = -12; f[8].v[2].y =   4; f[8].v[2].z =  -8;
  f[8].v[3].x = -12; f[8].v[3].y =   4; f[8].v[3].z =   8;
  f[8].col = 7;

  // Initialise object face list.
  o->face = &f[0];
  f[0].n = &f[1];
  f[1].n = &f[2];
  f[2].n = &f[3];
  f[3].n = &f[4];
  f[4].n = &f[5];
  f[5].n = &f[6];
  f[6].n = &f[7];
  f[7].n = &f[8];
  f[8].n = 0;

  // Initialise object offset & rotation attributes.
  o->angX =    0;
  o->angY =    0;
  o->angZ =    0;
  o->incX =    1;
  o->incY =    2;
  o->incZ =    3;
  o->offX =  -60;
  o->offY =   40;
  o->offZ =    0;
}

void init_sidewinder(Object *o, Face f[]) {
  // top
  f[0].v[0].x =  -9; f[0].v[0].y =   5; f[0].v[0].z =   0;
  f[0].v[1].x =   9; f[0].v[1].y =   0; f[0].v[1].z =  -9;
  f[0].v[2].x =   9; f[0].v[2].y =   0; f[0].v[2].z =   9;
  f[0].v[3].x =   9; f[0].v[3].y =   0; f[0].v[3].z =   9;
  f[0].col = 1;

  // left wing
  f[1].v[0].x =  -9; f[1].v[0].y =   5; f[1].v[0].z =   0;
  f[1].v[1].x =   9; f[1].v[1].y =   0; f[1].v[1].z =   9;
  f[1].v[2].x =  -9; f[1].v[2].y =   0; f[1].v[2].z =  19;
  f[1].v[3].x =  -9; f[1].v[3].y =   0; f[1].v[3].z =  19;
  f[1].col = 2;

  // right wing
  f[2].v[0].x =  -9; f[2].v[0].y =   0; f[2].v[0].z = -19;
  f[2].v[1].x =   9; f[2].v[1].y =   0; f[2].v[1].z =  -9;
  f[2].v[2].x =  -9; f[2].v[2].y =   5; f[2].v[2].z =   0;
  f[2].v[3].x =  -9; f[2].v[3].y =   5; f[2].v[3].z =   0;
  f[2].col = 3;

  // bottom
  f[3].v[0].x =   9; f[3].v[0].y =   0; f[3].v[0].z =   9;
  f[3].v[1].x =   9; f[3].v[1].y =   0; f[3].v[1].z =  -9;
  f[3].v[2].x =  -9; f[3].v[2].y =  -5; f[3].v[2].z =   0;
  f[3].v[3].x =  -9; f[3].v[3].y =  -5; f[3].v[3].z =   0;
  f[3].col = 4;

  // bottom left wing
  f[4].v[0].x =  -9; f[4].v[0].y =   0; f[4].v[0].z =  19;
  f[4].v[1].x =   9; f[4].v[1].y =   0; f[4].v[1].z =   9;
  f[4].v[2].x =  -9; f[4].v[2].y =  -5; f[4].v[2].z =   0;
  f[4].v[3].x =  -9; f[4].v[3].y =  -5; f[4].v[3].z =   0;
  f[4].col = 5;

  // bottom right wing
  f[5].v[0].x =  -9; f[5].v[0].y =  -5; f[5].v[0].z =   0;
  f[5].v[1].x =   9; f[5].v[1].y =   0; f[5].v[1].z =  -9;
  f[5].v[2].x =  -9; f[5].v[2].y =   0; f[5].v[2].z = -19;
  f[5].v[3].x =  -9; f[5].v[3].y =   0; f[5].v[3].z = -19;
  f[5].col = 6;

  // back
  f[6].v[0].x =  -9; f[6].v[0].y =  -5; f[6].v[0].z =   0;
  f[6].v[1].x =  -9; f[6].v[1].y =   0; f[6].v[1].z = -19;
  f[6].v[2].x =  -9; f[6].v[2].y =   5; f[6].v[2].z =   0;
  f[6].v[3].x =  -9; f[6].v[3].y =   0; f[6].v[3].z =  19;
  f[6].col = 7;

  // Initialise object face list.
  o->face = &f[0];
  f[0].n = &f[1];
  f[1].n = &f[2];
  f[2].n = &f[3];
  f[3].n = &f[4];
  f[4].n = &f[5];
  f[5].n = &f[6];
  f[6].n = 0;

  // Initialise object offset & rotation attributes.
  o->angX =    0;
  o->angY =    0;
  o->angZ =    0;
  o->incX =    2;
  o->incY =    1;
  o->incZ =    3;
  o->offX =   60;
  o->offY =  -40;
  o->offZ =    0;
}

void init_mamba(Object *o, Face f[]) {
  // Bottom face.
  f[0].v[0].x = -17; f[0].v[0].y =   0; f[0].v[0].z =  19;
  f[0].v[1].x =  17; f[0].v[1].y =   0; f[0].v[1].z =   0;
  f[0].v[2].x = -17; f[0].v[2].y =   0; f[0].v[2].z = -19;
  f[0].v[3].x = -17; f[0].v[3].y =   0; f[0].v[3].z = -19;
  f[0].col = 1;

  // Left wing.
  f[1].v[0].x = -17; f[1].v[0].y =   5; f[1].v[0].z =  10;
  f[1].v[1].x =  17; f[1].v[1].y =   0; f[1].v[1].z =   0;
  f[1].v[2].x = -17; f[1].v[2].y =   0; f[1].v[2].z =  19;
  f[1].v[3].x = -17; f[1].v[3].y =   0; f[1].v[3].z =  19;
  f[1].col = 2;

  // Right wing.
  f[2].v[0].x = -17; f[2].v[0].y =   0; f[2].v[0].z = -19;
  f[2].v[1].x =  17; f[2].v[1].y =   0; f[2].v[1].z =   0;
  f[2].v[2].x = -17; f[2].v[2].y =   5; f[2].v[2].z = -10;
  f[2].v[3].x = -17; f[2].v[3].y =   5; f[2].v[3].z = -10;
  f[2].col = 3;

  // Roof.
  f[3].v[0].x = -17; f[3].v[0].y =   5; f[3].v[0].z = -10;
  f[3].v[1].x =  17; f[3].v[1].y =   0; f[3].v[1].z =   0;
  f[3].v[2].x = -17; f[3].v[2].y =   5; f[3].v[2].z =  10;
  f[3].v[3].x = -17; f[3].v[3].y =   5; f[3].v[3].z =  10;
  f[3].col = 4;

  // Back.
  f[4].v[0].x = -17; f[4].v[0].y =   0; f[4].v[0].z =  19;
  f[4].v[1].x = -17; f[4].v[1].y =   0; f[4].v[1].z = -19;
  f[4].v[2].x = -17; f[4].v[2].y =   5; f[4].v[2].z = -10;
  f[4].v[3].x = -17; f[4].v[3].y =   5; f[4].v[3].z =  10;
  f[4].col = 5;

  // Initialise object face list.
  o->face = &f[0];
  f[0].n = &f[1];
  f[1].n = &f[2];
  f[2].n = &f[3];
  f[3].n = &f[4];
  f[4].n = 0;

  // Initialise object offset & rotation attributes.
  o->angX =    0;
  o->angY =    0;
  o->angZ =    0;
  o->incX =    3;
  o->incY =    2;
  o->incZ =    1;
  o->offX =  -60;
  o->offY =  -40;
  o->offZ =    0;
}

int AgbMain(void) {
  int i, j;
  Object *world, *curr_obj;
  Object mamba, sidewinder, gecko, viper;
  Face temp, mamba_faces[5], sidewinder_faces[7], gecko_faces[9], viper_faces[8], *curr;
  signed long int sin[3], cos[3], visible;
  long int bx, bxs = 4, by = 90, bz, bzs = 2;
  long int nx, ny, nz, nm;

  // Speed debugging.
  int min = 200, max = 0, total = 0, frames = 0, length;

  init_mamba(&mamba, mamba_faces);
  init_sidewinder(&sidewinder, sidewinder_faces);
  init_gecko(&gecko, gecko_faces);
  init_viper(&viper, viper_faces);

  world = &mamba;
  world->n = &sidewinder;
  world->n->n = &gecko;
  world->n->n->n = &viper;
  world->n->n->n->n = NULL;

  gba_setmode(0x04);

  gba_initbank();
// Set cube palette.
  gba_setpalette(0, 0, 0, 0);
  gba_setpalette(1, 31, 0, 0);
  gba_setpalette(2, 0, 31, 0);
  gba_setpalette(3, 31, 31, 0);
  gba_setpalette(4, 0, 0, 31);
  gba_setpalette(5, 31, 0, 31);
  gba_setpalette(6, 0, 31, 31);
  gba_setpalette(7, 31, 31, 31);

  // Set lighter face palettes.
  for(i = 0; i < 32; i ++) gba_setpalette( 32 + i, (i >> 1) + 16, 0, 0);
  for(i = 0; i < 32; i ++) gba_setpalette( 64 + i, 0, (i >> 1) + 16, 0);
  for(i = 0; i < 32; i ++) gba_setpalette( 96 + i, (i >> 1) + 16, (i >> 1) + 16, 0);
  for(i = 0; i < 32; i ++) gba_setpalette(128 + i, 0, 0, (i >> 1) + 16);
  for(i = 0; i < 32; i ++) gba_setpalette(160 + i, (i >> 1) + 16, 0, (i >> 1) + 16);
  for(i = 0; i < 32; i ++) gba_setpalette(192 + i, 0, (i >> 1) + 16, (i >> 1) + 16);
  for(i = 0; i < 32; i ++) gba_setpalette(224 + i, (i >> 1) + 16, (i >> 1) + 16, (i >> 1) + 16);

  while(frames < 1000) {

    // Ready to draw.
    gba_clsUnroll();

    curr_obj = world;
    while(curr_obj != NULL) {

    // Get the rotation angle sin and cos values.
    sin[0] = gba_sinq(curr_obj->angX); cos[0] = gba_cosq(curr_obj->angX);
    sin[1] = gba_sinq(curr_obj->angY); cos[1] = gba_cosq(curr_obj->angY);
    sin[2] = gba_sinq(curr_obj->angZ); cos[2] = gba_cosq(curr_obj->angZ);

    curr = curr_obj->face;

    while(curr != 0) {

      // Rotate face into temp.
      copy(&temp, curr);
      rotX(&temp, sin[0], cos[0]);
      rotY(&temp, sin[1], cos[1]);
      rotZ(&temp, sin[2], cos[2]);
      trs(&temp, curr_obj->offX, curr_obj->offY, curr_obj->offZ);
      psp(&temp);

      // Calculate face visibility.
nz  = (temp.v[1].x - temp.v[0].x) * (temp.v[2].y - temp.v[1].y);
nz -= (temp.v[1].y - temp.v[0].y) * (temp.v[2].x - temp.v[1].x);

      if(nz < 0) {
// Debug normals
nx  = (temp.v[1].y - temp.v[0].y) * (temp.v[2].z - temp.v[1].z);
nx -= (temp.v[1].z - temp.v[0].z) * (temp.v[2].y - temp.v[1].y);

if(nz == 0) {
  nm = 31;
} else {
  nm = gba_div(nx << 8, nz);
}
if(nm < 0) nm = -nm;
nm = nm >> 4;
if(nm > 31) nm = 31;

        // Draw temporary face.
        gba_setcolour(temp.col * 32 + 31 - nm);
        gba_triangle(temp.v[0].x+XOFF, temp.v[0].y+YOFF,
                     temp.v[1].x+XOFF, temp.v[1].y+YOFF,
                     temp.v[2].x+XOFF, temp.v[2].y+YOFF);
        gba_triangle(temp.v[0].x+XOFF, temp.v[0].y+YOFF,
                     temp.v[2].x+XOFF, temp.v[2].y+YOFF,
                     temp.v[3].x+XOFF, temp.v[3].y+YOFF);

      }

      // Get next face.
      curr = curr->n;
    }

    // Increment angles.
    curr_obj->angX = (curr_obj->angX + curr_obj->incX) % 360;
    curr_obj->angY = (curr_obj->angY + curr_obj->incY) % 360;
    curr_obj->angZ = (curr_obj->angZ + curr_obj->incZ) % 360;

    curr_obj = curr_obj->n;
    }
    gba_setcolour(255);
    gba_print(6, 10, "l33t demo by dooby");

    // Speed debug stuff.
    length = *((volatile unsigned short int *)(0x04000006));
    if(length < min) min = length;
    if(length > max) max = length;
    total += length;
    frames ++;

// Raster timing.
/*
    if((length >= 0) && (length < 160)) {
      //if(length < 64) gba_setcolour(1);
      //else gba_setcolour(2);
      gba_setcolour(2);
      gba_drawline(0, 159-length, 239, 159-length);
    } else {
      gba_setcolour(1);
      gba_drawline(0, 159-(length - 160), 239, 159-(length - 160));
    }
    */

    // Loop.
//    while(*((volatile unsigned short int *)(0x04000006)) != 208 /*0xe3*/);
    gba_vsync();
    if((gba_readpad() & PAD_SELECT) == 0) for(i = 0; i < 10; i ++) gba_vsync();
    gba_swapbank();
  }

  // Debug speed info.
  gba_setwbank(1);
  gba_cls();
  gba_setdbank(0);
  gba_setcolour(7);
  gba_print(0, 0, "frames"); gba_debug_32_16(7, 0, frames);
  gba_print(0, 1, "min");    gba_debug_32_16(7, 1, min);
  gba_print(0, 2, "max");    gba_debug_32_16(7, 2, max);
  //gba_print(0, 3, "avg");    gba_debug_32_16(7, 3, (int)(total/frames));

  while(gba_readpad() & PAD_START);
  return(0);
}
