#include "..\gba\gba.h"

void irq_init(void);
void set_palette(void);

int code_start(void) {
  s32 x1 =   0, y1 =  29;
  s32 x2 = -25, y2 = -14;
  s32 x3 =  25, y3 = -14;
  u32 tx1, ty1, tx2, ty2, tx3, ty3;
  s32 sin, cos;
  u16 ang = 0;

  // Install IRQ handler.
  irq_init();

  // Set up interrupts.
  *(unsigned short *)0x04000004 |= 0x10;         // Enable LCDs HBLANK IRQ.
  *(unsigned short *)0x04000004 |= 0x8;          // Enable LCDs VBLANK IRQ.
  *(unsigned short *)0x04000200 |= 0x0002;       // Enable HBLANK IRQ.
  *(unsigned short *)0x04000200 |= 0x0001;       // Enable VBLANK IRQ.
  *(unsigned short *)0x04000208 |= 0x0001;       // Master interrupt enable.

  set_palette();
  gba_setmode(0x04);

  // We're gonna change the palette entry of colour 7 every HBLANK.
  gba_setcolour(7);

  // Test raster stuff.
  gba_initbank();
  while(0 == 0) {
    sin = gba_sinq(ang);
    cos = gba_cosq(ang);
    tx1 = (x1 * cos - y1 * sin) >> 7;
    ty1 = (y1 * cos + x1 * sin) >> 7;
    tx2 = (x2 * cos - y2 * sin) >> 7;
    ty2 = (y2 * cos + x2 * sin) >> 7;
    tx3 = (x3 * cos - y3 * sin) >> 7;
    ty3 = (y3 * cos + x3 * sin) >> 7;
    gba_triangleQ(tx1 + XOFF, ty1 + YOFF, tx2 + XOFF, ty2 + YOFF, tx3 + XOFF, ty3 + YOFF);
    gba_triangleQ(tx1 + XOFF-55, ty1 + YOFF-25, tx2 + XOFF-55, ty2 + YOFF-25, tx3 + XOFF-55, ty3 + YOFF-25);
    gba_triangleQ(tx1 + XOFF+55, ty1 + YOFF+25, tx2 + XOFF+55, ty2 + YOFF+25, tx3 + XOFF+55, ty3 + YOFF+25);
    ang = (ang + 1) % 360;
    gba_print((int)(((240/8)-19)/2), 17, "Raster demo by Pete");
    gba_print((int)(((240/8)-21)/2), 18, "dooby@bits.bris.ac.uk");
    gba_print((int)(((240/8)-25)/2), 19, "www.bits.bris.ac.uk/dooby");
    gba_vsync();
    gba_swapbank();
    gba_clsUnroll();
  }

  return(0);
}

void set_palette(void) {
  int i;

  // Set basic 8 colour palette.
  gba_setpalette(0, 0, 0, 0);
  gba_setpalette(1, 31, 0, 0);
  gba_setpalette(2, 0, 31, 0);
  gba_setpalette(3, 31, 31, 0);
  gba_setpalette(4, 0, 0, 31);
  gba_setpalette(5, 31, 0, 31);
  gba_setpalette(6, 0, 31, 31);
  gba_setpalette(7, 31, 31, 31);
  gba_setpalette(255, 31, 31, 31);

  // Set colour fade palettes.
  for(i = 0; i < 32; i ++) gba_setpalette( 32 + i, (i >> 1) + 16, 0, 0);
  for(i = 0; i < 32; i ++) gba_setpalette( 64 + i, 0, (i >> 1) + 16, 0);
  for(i = 0; i < 32; i ++) gba_setpalette( 96 + i, (i >> 1) + 16, (i >> 1) + 16, 0);
  for(i = 0; i < 32; i ++) gba_setpalette(128 + i, 0, 0, (i >> 1) + 16);
  for(i = 0; i < 32; i ++) gba_setpalette(160 + i, (i >> 1) + 16, 0, (i >> 1) + 16);
  for(i = 0; i < 32; i ++) gba_setpalette(192 + i, 0, (i >> 1) + 16, (i >> 1) + 16);
  for(i = 0; i < 32; i ++) gba_setpalette(224 + i, (i >> 1) + 16, (i >> 1) + 16, (i >> 1) + 16);

}
