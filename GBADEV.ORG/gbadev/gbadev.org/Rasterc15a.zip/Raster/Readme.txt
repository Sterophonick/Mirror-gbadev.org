Raster
~~~~~~

This is my second release for GBA. This one's a little tidier ;) It shows how
to use interrupts to get a raster effect.
--
Pete (dooby@bits.bris.ac.uk / http://bits.bris.ac.uk/dooby/)
