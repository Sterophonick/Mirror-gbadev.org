PCX to RAW v1 by Chris Lord
---------------------------

Outline: Inputs PCX files (8-bit or 24-bit format, any size) and outputs the appropriate raw format (8-bit palettised or 15-bit BGR).

Usage: PCXtoRAW.exe <image name> <mode>
Where mode is 0 for binary and 1 for C format.

Output: In the case of 8-bit images, the palette is included after the image data (the address of which can be calculated by multiplying the Width by the Height, obviously)

To do list:
-Add C format output
-Add compressed (lzh/rle/huffman) output
-Release source

Notes:
I haven't tested the 8-bit output, but I'll assume it works until someone tells me otherwise. The 15-bit output works fine.

Contact
-------
E-mail: cwiiis:hotmail.com
Webpage: http://ChrisLord.cjb.net/