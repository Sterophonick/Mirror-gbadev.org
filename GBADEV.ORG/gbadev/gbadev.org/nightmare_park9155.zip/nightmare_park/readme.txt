/////////////////////////////////////
//Nightmare Park - Created by Jonah//
/////////////////////////////////////

This is my first GBA game. Its based on an old computer game from BreadHill software.
The objective is to find the keys then get to the exit. You will encounter a monster
every couple of steps you take. If you pass the monster's challenge, you can move on.

I got bored of working on this project after only a couple of weeks, so I ended up 
rushing to complete it. Thats why there are only seven minigames and no audio.

IMPORTANT NOTE - This game should only be ran on the Visual Boy Advanced GBA emulator.
All the other emulators I tested it on didn't run it properly.

My website - http://www.websamba.com/gamecircle/index.html
