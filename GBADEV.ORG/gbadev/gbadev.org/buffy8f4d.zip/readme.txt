Buffy Demo
Coded by Jim Bagley <JimBagley@Hotmail.com> http://www.jim.bagley.btinternet.co.uk/home.html

This game is Freeware, and is ok to distribute as long as it's kept as is with this text file
and a link to http://www.jim.bagley.btinternet.co.uk/home.html
