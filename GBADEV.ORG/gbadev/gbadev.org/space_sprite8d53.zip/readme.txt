-------------------------
Space_sprite Demo
-------------------------

File:		space_sprite.bin
Program:		Space demo with bg
Author:		Johan Jansen (Jenswa)
Contact:		awsnej@hotmail.com
Site:		http://www.geocities.com/flashsite_jrj/gba
		

-----------------------------
About this bin-file:
This is my 5th gba-demo, it's to understand the programming in c
and also because don't have much knowledge of the gba.
I'm following gbajunkies tutorials, they're great!

---------------
Features:
transparent 16x16 sprite
horizontal and vertical flipping
sprite anitmation
One bg
----------------
Thanks to:

Forgotten (VisualBoyAdvance)
Jason Wilkins (Dev-Kit Advance)
Eloist (gba.h)
GBAjunkie (tutorial, dovoto, dispcnt.h, sprite_info.h)
Dovoto (pcx2sprite, dispcnt.h, sprite_info.h) 
Noktrun (keypad.h)
GBADEV.org (they have lots of sources and updates around gba, always usefull)
devrs.com/gba (they are just like gbadev.org, comes in handy)

----------------
Jenswa

