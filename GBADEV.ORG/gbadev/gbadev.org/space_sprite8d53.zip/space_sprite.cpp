////////////////////////////////////////////////////////////////////////////
//File:		space_sprite.cpp
//Description:	Display a background map with a plane over it
//Date:		06 - 08 - 2002
//Author:		Jenswa
//Thanks to:	gbajunkie and dovoto
////////////////////////////////////////////////////////////////////////////

#include<math.h>		//sin and cos stuff

#include "gba.h"		//GBA register definitions
#include "dispcnt.h"		//REG_DISPCNT register #defines
#include "keypad.h"	//button registers
#include "bg.h"		//background definitions
#include "sprite_info.h"	//sprite definitions

//Graphis Data
#include "space_tiles.h"		//tile gfx
#include "space_bg.c"		//map gfx
#include "plane.h"			// plane sprite
#include "palette.h"			//palette from sprites


//Rotation variables (don't worry about them here) done in later chapter
/**********************************************************************************/
FIXED angle = 0;
FIXED zoom = 1<<8;  //zoom is a fixed point number

FIXED SIN[360];	    //Look-Up Tabless for sign and cosign
FIXED COS[360];

char RotIndexCounter = 0;  //global to keep track of rotation indexes used
/**********************************************************************************/


Bg bg2;		//declare an instance of background structure

//wait for the screen to stop drawing
void WaitForVsync()
{
	while((volatile u16)REG_VCOUNT != 160){}
}

//create an OAM variable and make it point to the address of OAM
u16* OAM = (u16*)0x7000000;

//create the array of sprites (128 is the maximum)
OAMEntry sprites[128];

//create the rotation and scaling array (overlaps the OAMEntry array memory)
pRotData rotData = (pRotData)sprites;

//declare ypos and xpos
s16 xpos = 120;
s16 ypos = 80;
s16 spriteflipv = 0;
s16 spritefliph = 0;

//sprite strucure, for animation of the sprite
typedef struct
{
	u16 xpos;		//x position
	u16 ypos;		//y position
	u16 spriteFrame[3];	//total frames
	int activeFrame;	//which frame is active
}Sprite;

Sprite plane;		//create a sprite instance

//Copy sprite array to OAM
void CopyOAM()
{
	u16 loop;
	u16* temp;
	temp = (u16*)sprites;
	for(loop=0; loop < 128*4; loop++)
	{
		OAM[loop] = temp[loop];
	}
}

// Set sprites off screen
void InitializeSprites()
{
	u16 loop;
	for (loop = 0; loop < 128; loop++)
	{
		sprites[loop].attribute0 = 160;	//y > 159
		sprites[loop].attribute1 = 240;	//x > 239
	}
}

//move the sprite
void MoveSprite(OAMEntry* sp, int x, int y)
{
	if(x < 0)			//if it is off the left correct
		x = 512 + x;
	if(y < 0)			//if off the top correct
		y = 256 + y;

	sp->attribute1 = sp->attribute1 & 0xFE00;  //clear the old x value
	sp->attribute1 = sp->attribute1 | x;

	sp->attribute0 = sp->attribute0 & 0xFF00;  //clear the old y value
	sp->attribute0 = sp->attribute0 | y;
}

//A button was pressed at the gba
void GetInput()
{
	if(!(*KEYS & KEY_UP))                   //if the UP key is pressed
	{
	plane.activeFrame = 0;
	sprites[0].attribute2 = plane.spriteFrame[plane.activeFrame];
	spriteflipv = 0;
        	if(ypos > 0)
        		ypos--;
	}
	if(!(*KEYS & KEY_DOWN))                 //if the DOWN key is pressed
	{
	plane.activeFrame = 0;
	sprites[0].attribute2 = plane.spriteFrame[plane.activeFrame];
	spriteflipv = 1;
        	if(ypos < 144)
        		ypos++;
	}
	if(!(*KEYS & KEY_LEFT))                 //if the LEFT key is pressed
	{
	plane.activeFrame = 1;
	sprites[0].attribute2 = plane.spriteFrame[plane.activeFrame];
	spritefliph = 0;
        	if(xpos > 0)
        		xpos--;
	}
	if(!(*KEYS & KEY_RIGHT))                //if the RIGHT key is pressed
	{
	plane.activeFrame = 1;
	sprites[0].attribute2 = plane.spriteFrame[plane.activeFrame];
	spritefliph = 1;
        	if(xpos < 224)
        		xpos++;
	}
	if(!(*KEYS & KEY_LEFT) && !(*KEYS & KEY_UP))	//if left and up are pressed
	{	
	plane.activeFrame = 2;
	sprites[0].attribute2 = plane.spriteFrame[plane.activeFrame];
	spritefliph = 0;
	spriteflipv = 0;
	}
	if(!(*KEYS & KEY_RIGHT) && !(*KEYS & KEY_UP))	//if right and up are pressed
	{	
	plane.activeFrame = 2;
	sprites[0].attribute2 = plane.spriteFrame[plane.activeFrame];
	spritefliph = 1;
	spriteflipv = 0;
	}
	if(!(*KEYS & KEY_LEFT) && !(*KEYS & KEY_DOWN))	//if left and down are pressed
	{	
	plane.activeFrame = 2;
	sprites[0].attribute2 = plane.spriteFrame[plane.activeFrame];
	spritefliph = 0;
	spriteflipv = 1;
	}
	if(!(*KEYS & KEY_RIGHT) && !(*KEYS & KEY_DOWN))	//if right and down are pressed
	{	
	plane.activeFrame = 2;
	sprites[0].attribute2 = plane.spriteFrame[plane.activeFrame];
	spritefliph = 1;
	spriteflipv = 1;
	}
	if(!(*KEYS & KEY_A))                	//if the A key is pressed
	{}
	if(!(*KEYS & KEY_B))                	//if the B key is pressed
	{}
	if(!(*KEYS & KEY_L))                	//if the L key is pressed
	{}
	if(!(*KEYS & KEY_R))                	//if the R key is pressed
	{}
	if(!(*KEYS & KEY_SELECT))               //if the SELECT key is pressed
	{}
	if(!(*KEYS & KEY_START))                //if the START key is pressed
	{}
}



int main()
{

	int index = 0;  //generic loop variables
	u16 loop;
	u16* temp;      //temporary storage pointer

	//compute my Look up tables (Rotation stuff again)
	for(loop = 0; loop < 360; loop++)
		{
			SIN[loop] = (FIXED)(sin(RADIAN(loop)) * 256);  //sin and cos are computed and cast to fixed							//fixed
			COS[loop] = (FIXED)(cos(RADIAN(loop)) * 256);
		}

	//set mode 1 and enable sprites and 1d mapping
	SetMode(MODE_1 | OBJ_ENABLE | OBJ_MAP_1D);

	bg2.number =2;			//background number 0-3
	bg2.charBaseBlock = 0;		//tile data position
	bg2.screenBaseBlock = 28;		//map dat position
	bg2.colorMode = BG_COLOR_256;	//256-clour background
	bg2.size = ROTBG_SIZE_256x256;	//size of map
	bg2.mosaic = 0;			//mosaic disabled
	bg2.x_scroll = 120;			//x scroll position
	bg2.y_scroll = 80;			//y scroll position

	EnableBackground(&bg2);

	for(loop = 0; loop < 256; loop++)
		BGPaletteMem[loop] = tilesPalette[loop];	//Background (tile) palette

	for(loop = 0; loop < tiles_WIDTH *tiles_HEIGHT /2; loop++)
		bg2.tileData[loop] = tilesData[loop];		//Background (tile) data

	temp = (u16*)map;
	for(loop = 0; loop < 32*32/2; loop++)
		bg2.mapData[loop] = temp[loop];		//Background (map) data


	for(loop = 0; loop < 256; loop++)		//load palette into memory
	OBJPaletteMem[loop] = palette[loop];

	InitializeSprites();

	sprites[0].attribute0 = COLOR_256 | SQUARE | MODE_TRANSPARENT | ypos;
	sprites[0].attribute1 = SIZE_16 | xpos;
	sprites[0].attribute2 = 0;			//pointer to tile where sprite starts

	plane.spriteFrame[0] = 0;
	plane.spriteFrame[1] = 8;
	plane.spriteFrame[2] = 16;
	plane.activeFrame = 0;

for(loop = 0; loop < 384; loop++)	//load sprite image data
{
	OAMData[loop] = planeData[loop];
}




	//Main loop
	while(1)
	{
	GetInput();		//check for input
		if(spriteflipv == 1)
		{
			sprites[0].attribute1 |= VERTICAL_FLIP;         //flip the sprite vertically
		}
		else
			sprites[0].attribute1 &= ~VERTICAL_FLIP;        //back to original unflipped sprite
		if(spritefliph == 1)
		{
			sprites[0].attribute1 |= HORIZONTAL_FLIP;         //flip the sprite horizontally
		}
		else
			sprites[0].attribute1 &= ~HORIZONTAL_FLIP;        //back to original unflipped sprite
	CopyOAM();		//essential for sprite data !!
	RotateBackground(&bg2,angle,119,79,zoom);
	MoveSprite(&sprites[0], xpos, ypos);	//moves sprite 0 around the screen
	WaitForVsync();		//wait for screen to stop drawing
	UpdateBackground(&bg2);	//make sure registers are updated
	}

}
