Runes v1.0 by Headspin
---------------------------------------------------------------

This is a port of an old Amiga program I wrote back in 1992...

Runes are little stones that have been used to look into the future since the dark ages. Each rune has it's own name, and it's own meaning. There are 25 runes - each was once a letter in an ancient Germanic alphabet. This program does all the reading of the stones for you. All you have to do is follow the messages that appear onscreen. 

These are genuine layouts and interpretations of the runes. And yes, it does work so be serious when you use the oracle of the runes!

---------------------------------------------------------------

- Pogoshell Users

Apply the exit hack patch and SELECT will exit back to Pogoshell

---------------------------------------------------------------

Notes:

Tested on Visualboy Advance and real hardware.

It seems to run too fast on Visualboy, but runs at a nice speed on real GBA.

---------------------------------------------------------------

- The Future

At the moment the last reading is saved to SRAM. If I can be bothered I might write a DOS program to read the .sav file and output the reading to a .txt file for printing. Sorry, I was going to put this feature in version 1.0 but I got too lazy to add it.

---------------------------------------------------------------

Greets to all @ GBATemp / GBAEmu / forum.gbadev.org / #gbadev

---------------------------------------------------------------

For bugs / suggestions / comments
Please let me know if you keep this program on your flash cart!

E-Mail me at: freeaxs@iinet.net.au

---------------------------------------------------------------

(c) Copyright 2003 By Ben Baker
