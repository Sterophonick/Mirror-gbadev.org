Here is a GBA video codec test I made for the music video:
Touhou - Bad Apple!

I wanted to see how small I could get all the frames of animation to encode.
I am using RLE compressed frames, that are then compressed with LZ77 compression.
For extra speed, instead of using the GBA Bios decompression functions,
I made my own optimized routines in ARM assembly for RLE & LZ77 decompression
& run the video decoder from IWRAM.

Also I am using RAW PCM mono audio, using the GBA internal DAC for playback.

Video Stats:
Frames: 6572
Frames Per Second: 30
Frames Resolution: 240x160, 4-Bit (16 Shades)
Frames File Size: 10.4MB
Audio Sample Rate: 22050Hz, 8-Bit RAW PCM Data
Audio File Size: 4.6MB
Video Playback Time: 3 Minutes, 39 Seconds
Total GBA ROM Size: 15MB

Full ARM assembly source code using <b>FASMARM</b> can be found here:
https://github.com/PeterLemon/GBA/tree/master/Video/Touhou-BadApple!

/krom (Peter Lemon)