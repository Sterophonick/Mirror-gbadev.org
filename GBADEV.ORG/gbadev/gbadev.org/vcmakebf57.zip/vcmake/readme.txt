VCMake 1.3 - Copyright (c)2002 Nicolas Cannasse
-----------------------------------------------
Last version : http://warplayer.free.fr
Support : warplayer@free.fr

This software comes with ABSOLUTELY NO WARRANTY.
This is free software, and you are welcome to redistribute
it under certain conditions; read LICENCE.txt or contact me
at warplayer@free.fr for details

* Features
* Included files
* How it works ?
* Makefile generation
* Filtering output
* Tutorial
* Options
* The End

Features
--------
- read VC++6 project file (.DSP)
- use a template makefile to produce a complete makefile
- run NMAKE on this new makefile
- use an extensible regular expression matching on build output

(using GNU regex C library )

Included files
--------------
Theses files are included in the current distribution :

- vcmake.exe    (executable)
- vcmake.cfg    (some filtering)
- licence.txt   (GPL licence notes)
- readme.txt    (this file)

Full Source Code (compiled with VC++6) :
- src\vcmake.dsp
- src\vcmake.dsw
- src\vcmake.cpp
- src\multiregex.h
- src\libs\wfile.h
- src\libs\wlist.h
- src\libs\wstring.h
- src\libs\regex.c   (GNU GPL regex library)
- src\libs\regex.h

How it works ?
--------------
VCMake takes a DSP VC++6 project file and read all
infos into it. Then it try to find a suitable makefile
for this project and create a makefile including all
infos from the DSP ( files, build options... )

Then, VCMake run NMAKE on the produced makefile with
a redirected output and match compiler special output
format using regular expressions to produce a final
output compatible with VC6 format :

<file>(<line>) : <error msg>

Thus, error are now "clickable".

Makefile generation
-------------------

Before running the Make process, VCMake first takes a
template Makefile and add lots of useful informations
into it.

For example, if we have a workspace like this :

>>
 |- MainFiles
 |     |- main.c
 |     |- main.res
 |     \- main.ico
 |- Modules
 |     |- A
 |     |  |- A.c
 |     |  \- A.h
 |     \- B
 |        |- B.c
 |        \- B.h
 \- data.dat

VCMake will produce a makefile defining :

VCMD_ROOT = data.data
VCMD_MAINFILES = main.c main.res main.ico
VCMD_MODULES =
VCMD_A = A.c A.h
VCMD_B = B.c B.h
=> VCMD_* is defining all files contained into the directory

VCMR_ROOT = $(VCMD_ROOT) $(VCMD_MAINFILES) $(VCMD_MODULES) $(VCMD_A) $(VCMD_B)
VCMR_MAINFILES = $(VCMD_MAINFILES)
VCMR_MODULES = $(VCMD_MODULES) $(VCMD_A) $(VCMD_B)
VCMR_A = $(VCMD_A)
VCMR_B = $(VCMD_B)
=> VCMR_* is defining all files contained into the directory and any subdirectory

VCME_C = main.c A. B.c
VCME_RES = main.res
VCME_ICO = main.ico
VCME_H = A.h B.h
VCME_DAT = data.dat
=> VCME_* is defining all files with a specific extension

and lots of VCMO_* such as :

VCMO_RSC = /l 0x40c /d "NDEBUG"
VCMO_BSC32 = /nologo
VCMO_LINK32 = kernel32.lib user32.lib advapi32.lib /nologo /subsystem:console /machine:I386
=> VCMO_* is defining DSP internal options

...and then will run the Make process :

The original makefile only have to use theses Macros
without any need to keep the makefile updated when
updating the project workspace !

Filtering output
----------------

One of the features of VCMake is to enable regular
expression matching on Compiler outputs.

In fact, some compiler may print :
  In file "test.wpp" , on line 454 you got an error "<message>"

And to make errors "clickable" under VC++, we would have like to have
  test.wpp(454) : <message>

VCMake, allow this to be done by using regular expression pattern
matching. Using the regular expression :
  In file "([^"]+)" , on line ([0-9]+) you got an error

VCMake will take the first matched sequence (between braces) as the
name of the file, and the second matched sequence as the line number
(I don't think that any compiler is printing the line number first :)

-> for more informations on regular expression syntax, seek on Google !

More than one regex can be specified at the same time, theses are
specified in the configuration file :

- - - - - - vcmake.cfg - - - - - - - -
# Ocaml 3.04
File "([^"]+)", line ([0-9]+), 
# GCC
^([A-Za-z]:[^:]*):([0-9]+): 
^([^:]+):([0-9]+): 
- - - - - - - - - - - - - - - - - - - -

Lines beginning with a # are ignored, to be able to comment regex.

Tutorial
--------

1) First, be sure to have VCMake.exe in one of the directories
accessible by VC++ (Tools/Options/Directories/Executable files)

2) Create a new Makefile project, add your files to the project
workspace and SAVE THE WORKSPACE (not done when compiling)

3) Create the corresponding makefile and edit it, set the main
configuration to run vcmake with the options you want (you can
also directly run vcmake from the build process )

4) Test... it works ! ( Hope you'll find that much easy )

5) Add regex support for your compiler

Options
-------

Usage: vcmake [args] prj_name

   project name always has to be the last option passed to vcmake,
   all non-matched options are passed to NMAKE.

      -h   : help screen

      -nfq : remove quotes around files
             some compilers may does not like doublequotes around long
             files name.

      -noq : remove quotes around VC options
             "idem" but of VCMO_* macros

      -v   : verbose mode, print some infos

      -nd  : do not delete tmp makefile on exit
             useful when you want to make a release without providing
             VCMake, or only see what's generated.

      -cfg <config>  : setup VC configuration options
             a DSP file can contain many configurations, with different
             sets of options. You can specify the configuration you want
             to use by using this argument. Using "-cfg Release" for example
             will choose the configuration "<prj_name> - Win32 Release"

      -mak <file>    : use the specified template makefile
             if the DSP does not contains a reference to a makefile or if
             you don't want to use the default makefile, you can specify
             the source makefile.

      -mcfg <config> : run the specified configuration from makefile
             after Makefile generation, run the specified configuration of
             the makefile

      -ext <string>  : replace all files extensions in VCME tags by 'string'
             
      -reg <file>    : use specified file for ereg matching
             instead of using the standart regular expressions configuration
             file, you may want to use another file.

      -run <command> : run specified command instead of NMAKE

      -out <file>    : set output makefile name (use with -nd)

      -norun         : only produce makefile, do not run make process

   Sample : vcmake -nd -norun -out Makefile my_project
      will only produce a Makefile from my_project.dsp using
      makefile found in DSP information as template

The END
-------
    ALL SOURCES ARE INCLUDED AND ARE UNDER GPL !
    Feel free to modify theses and redistribute this application.
    If you fix bugs / add good features, please contact me at
    warplayer@free.fr to keep the last version updated.

    Thanks to GNU for the Regex C library ( www.gnu.org )

02-02-2002 <- strange but true
Warp / Nicolas Cannasse