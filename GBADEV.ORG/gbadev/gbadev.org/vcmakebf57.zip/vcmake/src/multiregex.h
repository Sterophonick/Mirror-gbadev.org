/* ****************************************************************************	*/
/*																				*/
/*	multiregex.h																*/
/*		multiple regular expression matching									*/
/*																				*/
/*		Copyright (C)2001 Nicolas Cannasse										*/
/*		warplayer@free.fr	 													*/
/*		http://www.warplayer.fr.st												*/
/*																				*/
/*	This file is part of VCMake.												*/
/*																				*/
/*	VCMake is free software; you can redistribute it and/or modify				*/
/*	it under the terms of the GNU General Public License as published by		*/
/*	the Free Software Foundation; either version 2 of the License, or			*/
/*	(at your option) any later version.											*/
/*																				*/
/*	VCMake is distributed in the hope that it will be useful,					*/
/*	but WITHOUT ANY WARRANTY; without even the implied warranty of				*/
/*	MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the				*/
/*	GNU General Public License for more details.								*/
/*																				*/
/*	You should have received a copy of the GNU General Public License			*/
/*	along with VCMake; if not, write to the Free Software						*/
/*	Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA	*/
/*																				*/
/* ****************************************************************************	*/
#ifndef MULTIREGEX_H
#define MULTIREGEX_H

extern "C" {
#define __STDC__ 1
#include "libs/regex.h"
#undef __STDC__
}
#include "libs/wstring.h"
#include "libs/wlist.h"

class MultiRegex {
	
	typedef re_pattern_buffer *ereg;

	WList<ereg> eregs;
	const char *lastmsg;
	int lastpos;

public:

	MultiRegex() {
		lastmsg = "No error";
		lastpos = -1;
	}

	bool AddRegex( WString pattern ) {
		ereg regex = new re_pattern_buffer();

		re_syntax_options = RE_DOT_NEWLINE | RE_NO_BK_BRACES | RE_NO_BK_PARENS | RE_NO_BK_REFS | RE_NO_BK_VBAR;

		regex->allocated = 0;
		regex->buffer = NULL;
		regex->translate = NULL;
		regex->fastmap = new char[256];
		lastmsg = re_compile_pattern(pattern.c_str(),pattern.length(),regex);
		if( lastmsg != NULL ) {
			delete regex->fastmap;
			delete regex;
			return false;
		}
		re_compile_fastmap(regex);
		regex->regs_allocated = REGS_FIXED;
		eregs.Add(regex);		
		return true;
	}

	bool Search( WString str, WString *res, int nres ) {
		re_registers found;
		re_registers last;
		int pos = -1;
		found.num_regs = nres;
		found.start = new regoff_t[nres];
		found.end = new regoff_t[nres];
		last.start = new regoff_t[nres];
		last.end = new regoff_t[nres];
		FOREACH(ereg,eregs,
			int r = re_search(item,str.c_str(),str.length(),0,str.length(),&found);
			switch(r) {
			case -2:
			case -1:
				break;
			default:
				if( pos == -1 || r < pos ) {
					memcpy(last.start,found.start,sizeof(regoff_t)*nres);
					memcpy(last.end,found.end,sizeof(regoff_t)*nres);
					pos = r;
				}
				break;
			}
		);
		if( pos >= 0 ) {
			int i;
			lastpos = pos;
			for(i=0;i<nres;i++)
				if( last.start[i] >= 0 )
					res[i] = str.substr(last.start[i],last.end[i]-last.start[i]);
				else
					res[i] = "";
		}
		delete found.start;
		delete found.end;
		delete last.start;
		delete last.end;
		return (pos>=0);
	}

	int LastPos() {
		return lastpos;
	}

	WString LastError() {
		return lastmsg;
	}

	~MultiRegex() {
		FOREACH(ereg,eregs,
			delete item->fastmap;
			delete item;
		);
	}
};


#endif
/* ****************************************************************************	*/
