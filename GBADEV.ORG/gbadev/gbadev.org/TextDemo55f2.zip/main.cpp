//Some defines
#define CBB         ((unsigned short*)0x06004000) //Pointer to char-base-block
#define SBB         ((unsigned short*)0x06001000) //Pointer to screen-base-block
#define DISPCNT     *(unsigned short*)0x04000000  //Pointer to display control
#define BG0_CNT     *(unsigned short*)0x04000008  //Pointer to BG0 control
#define BG_PALETTE  ((unsigned short*)0x05000000) //Pointer to the BG palette
typedef unsigned char u8;

//This plots into the 4bpp canvas. I'll let you figure out the code.
#define _4BPP_PLOT(X,Y,C) CBB[((X&7)>>2)+((Y&7)<<1)+((X>>3)<<4)+((Y>>3)<<9)] |= (C<<((X&3)<<2))

//Our font
#include "Font.c"

//I think this function explains itself...
void PRINT(int X, int Y, const u8* src, const char* STRING) {
 int i, iX, iY, ch;
 for(i=0;i<1024;i++) SBB[i] = i;
 for(i=0;(ch=*STRING++)!='\0';i++) {
  ch-=' ';
  for(iX=0;iX<8;iX++) {
   for(iY=0;iY<8;iY++) _4BPP_PLOT(iX+X+(i<<3), iY+Y, src[(ch<<6)+((iY<<3)+iX)]);
  }
 }
}

//Entry point
int main() {
 //Enable display and BG0
 DISPCNT = (1 << 8); //BG0 On
 BG0_CNT = (2 << 8) | (1 << 2); //Screen-base-block 2, char-base-block 1
 
 //Copy our palette over
 for(int i=0;i<16;i++) BG_PALETTE[i] = TONC_FONT_PAL[i];
 
 //Write the text
 PRINT(0, 0, (u8*)TONC_FONT_DAT, "FONT EXAMPLE - VERSION 0.01");
 PRINT(0, 16, (u8*)TONC_FONT_DAT, "This is a small example that's");
 PRINT(0, 24, (u8*)TONC_FONT_DAT, "not optimised at all. This");
 PRINT(0, 32, (u8*)TONC_FONT_DAT, "program can also be used to");
 PRINT(0, 40, (u8*)TONC_FONT_DAT, "make variable width fonts.");
 PRINT(0, 48, (u8*)TONC_FONT_DAT, "Simply replace the");
 PRINT(0, 56, (u8*)TONC_FONT_DAT, "'iX+X+(i<<3)' with something");
 PRINT(0, 64, (u8*)TONC_FONT_DAT, "like 'iX+X+CX' and increment");
 PRINT(0, 72, (u8*)TONC_FONT_DAT, "'CX' by that char's width");
 PRINT(0, 80, (u8*)TONC_FONT_DAT, "and that SHOULD work lol...");
 
 //Write the credits
 PRINT(0, 144, (u8*)TONC_FONT_DAT, "Ruben Nunez");
 PRINT(0, 152, (u8*)TONC_FONT_DAT, "rubenn93@iprimus.com.au");
 
 //This function SHOULD wait for an interrupt to occur but none are enabled so
 //it just stops without giving me errors on the 'No$gba' emulator...
 asm("swi 0x02");
}
