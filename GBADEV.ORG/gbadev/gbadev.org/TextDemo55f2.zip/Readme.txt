Font Demo Version 0.01
----------------------
Hi. I thought I'd make this program for you newbies who don't want to actually
learn how to do all the stuff needed to 'plot' pixels in 4bpp. It is also good for
fonts, as shown in the demo.

I'd like to give credits to Cearn from gbadev.org for the references in TONC
and his simple, yet effective font.

You might have to change the 'SET GCCDIR=C:\devKitPro\devKitARM' to suit your
needs...

Catch ya later, people!

Ruben Nunez
rubenn93@iprimus.com.au