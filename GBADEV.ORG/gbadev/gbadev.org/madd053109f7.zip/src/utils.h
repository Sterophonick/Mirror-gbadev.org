typedef struct
{
  char *fontptr;
  char ascii2local[256];
  int palette;
}font_struct;


extern void mosaic(int, int, int);

extern void FadeToBlack(int);
extern void FadeFromBlack(int);

extern void ClearOAM(void);

extern void LoadFont(char *, font_struct *, char *, char *, int);
extern int PutsxyOBJ(int, int, char *, font_struct *, int);
extern int PutsxyOBJ256(int, int, char *, font_struct *, int);
extern void PutsxyBG(int, int, char *, font_struct *, int);
extern void PutsxyBG256(int, int, char *, font_struct *, int);

extern int f1_23_8_to_f1_19_8(int);
extern short f1_23_8_to_f1_7_8(int);
