========================================================================
    Mortal Konsole : Pong Edition  -  Overview
========================================================================

Created by Neil Kemp
Web : www.gcdev.net
Email : neil@gcdev.net

Finally a reason to actually play pong again! 
Choose from over 51 available game consoles. 
Compete in a 5 level tournament against the computer. 
Kill your opponent with fatalities.

Controls are simple "UP/DOWN" moves the player and "A" gets the ball moving.

After a match you can press B to do a fatality.

2 hidden characters and gyms can be unlocked.


To do list:
* Add sounds and music
* Add "Finish Him" and "Fatality" sprites with voice.
* Update when new Xbox and PS3 come out.

check out www.gcdev.net

/////////////////////////////////////////////////////////////////////////////
