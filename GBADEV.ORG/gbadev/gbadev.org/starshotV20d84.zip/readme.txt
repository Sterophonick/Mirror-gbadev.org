Last February I began to play around with the GBA.  Starshot was mostly an excuse to build up
a GBA game engine, but I also kept thinking about the classic arcade game "Time Pilot."  I
ended up with a little minigame that I submitted to gbadev.org six months ago.

Since then, I continued to add new GBA code.  Starshot now includes background artwork
(including 1000 asteroids and 5 rotating spacestations), new weapons, and difficulty
settings.  It also now includes 6 simple sound effects, and it permanently saves high
scores on the backup RAM.

Most of the game assets (everything other than the spacestation and the explosion art) is my
own simple yet awful brand of programmer art.  I used an old version of the GCC compiler
(also available on my webpage) to compile the game, and tUME to create the asteroids.

Source code for the original version of the minigame is still available on my webpage
(www.opusgames.com).

-Opus
