/*	Coder:		Decay
	E-mail:		thefountainofdecay@hotmail.com
	Home Page:	http://members.lycos.co.uk/gbce
	File:		BrownianFade.c
	Purpose:	Simple demo to show brownian motion using a simple random function and basic fade routine
*/

//list defines
#define REG_DISPCNT *(unsigned short*)0x4000000	//this controls vid mode, bkgs, objs etc
#define MODE_0 0x0	//set mode 0 - tiled, bkgs 0123, no rot/scale
#define MODE_1 0x1	//set mode 1 - tiled, bkgs 012, rot/scale 2
#define MODE_2 0x2	//set mode 2 - tiled, bkgs 23,  rot/scale 23
#define MODE_3 0x3	//set mode 3 - 16bit buffer (enable bkg 2 to use)
#define MODE_4 0x4	//set mode 4 - 8bit buffer, double bufferable
#define MODE_5 0x5	//set mode 5 - 16bit buffer, double bufferable at 160x128
#define BKG0_ENABLE 0x100	//enable bkg 0
#define BKG1_ENABLE 0x200	//enable bkg 1	 
#define BKG2_ENABLE 0x400	//enable bkg 2
#define BKG3_ENABLE 0x800	//enable bkg 3
#define OBJ_ENABLE 0x1000 	//enable objects
#define VRAM (unsigned short*)0x6000000

#define KEY_A 1
#define KEY_B 2
#define KEY_SELECT 4
#define KEY_START 8
#define KEY_RIGHT 16
#define KEY_LEFT 32
#define KEY_UP 64
#define KEY_DOWN 128
#define KEY_R 256
#define KEY_L 512

short* KEYS = (short*)0x04000130;
unsigned short *videobuffer = VRAM;
unsigned long seed;

//random code taken from Tank Ravagers by Loirak Development (hope you don't mind :)
#define RAND_MAX 32767
long rand(long Value)
{
   seed *= 20077;
   seed += 12345;
   return ((((seed >> 16) & RAND_MAX) * Value) >> 15);
}

void Plot(unsigned short x, unsigned short y, unsigned short c)
{
	videobuffer=VRAM;	//reset to start of vram
	videobuffer[x+(y*240)]=c;	//draw pixel
}

void fadebuffer()
{
	unsigned short r,g,b,counter,counter2;
	static short vcount = 0;
	for (counter=vcount;counter<=159;counter+=10)	//fade 16 lines per function call
	{
		videobuffer= VRAM + (counter*240);
		for (counter2=0;counter2<240;counter2++)
		{	//split pixel colour into red/green/blue
			r= *videobuffer & 31;		//AND it with binary 11111 to get red element
			g= (*videobuffer>>5) & 31;	//AND it with binary 11111 to get green element
			b= (*videobuffer>>10) & 31;	//AND it with binary 11111 to get blue element
			
			//decrease the colours, if possible
			if (r>1) r--;
			if (g>1) g--;
			if (b>1) b--;
			
			//write back faded colour
			*videobuffer++= r + (g<<5) + (b<<10);
		}
	}
	if (vcount<9)	vcount++;	//take 10 loops to fade entire screen
	else	vcount=0;
}

int main(void)
{
	unsigned short plotx, ploty, plotc, r, g, b, random, counter=0;
	
	REG_DISPCNT=(MODE_3|BKG2_ENABLE);	//set mode 3, bkg2 needs to be enabled to show anything

	seed=1;
	//debounce start key
	while (*KEYS & KEY_START)	seed++;
	//wait for start key
	while (!(*KEYS & KEY_START))
	{
		if (seed<999999999)	seed++;
		else seed=1;
	}

	plotx=120;
	ploty=80;
	counter=0;
	while (1)
	{
		r=rand(31);
		g=rand(31);
		b=rand(31);
		plotc= (b << 10) + (g << 5) + r;
		Plot(plotx,ploty,plotc);
		random=rand(100);
		if (random < 25 && ploty>0)	//up
		{
			ploty--;
		}
		else if (random < 50 && ploty<160) //down
		{
			ploty++;
		}
		else if (random < 75 && plotx>0) //left
		{
			plotx--;
		}
		else if (random < 101 && plotx<240) //right
		{
			plotx++;
		}
		if (counter<15)	counter++;	//draw 15 pixels before calling the fade routine
		else
		{
			fadebuffer();
			counter=0;
		}
	}
}
