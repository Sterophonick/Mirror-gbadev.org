SNAKE OR DIE
============

Everyone seems to make a snake game. I am too :)
I created this game last year to learn more about the GBA.

Thanks to my mate Spooky (spooky@professional-raccoons.org),
he designed many of the sprites / tiles.

From time to time there appear some special symbols to collect.
Every special symbol has two effects, a good one and a bad one.
So its up to you to collect it and hope for the good effect
or wait a few seconds until the symbol disappear. For example one
could cut down the snake length or increase it a lot, another one ends
the level or make you nearly invisible and so on

The game is playable but it is not finished yet.

ToDo:

- add highscore table
- better game over screen
- end screen when all level finished instead of replay from start
- add more levels (12 at the moment)
- add more special symbols
- nice pause screen
- and many of these minor things
- find the time to do all this :)

Language used: C/C++

Bastian Pflieger (wb@illogical.de)

