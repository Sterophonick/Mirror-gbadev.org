AGB demo

Satsuma Yoyo! v1.1 - by ioojk
-----------------------

The first 3 levels of (unfinished) platform game.

A     - jump
B     - throw yoyo
L     - look up / look down
UP    - go through door
LEFT  - move left
RIGHT - move right

diamond - change yoyo direction
heart   - extra life
club    - nothing happens yet
spade   - nothing happens yet

Game runs well on Boycott Advance.  It might be a bit slow though,
because it's speed it set for running on hardware.

Now tested on Hardware! Runs perfectly.

I have cheekily used a number of things from dovoto's and Nokturn's
tutorials - so thankyou.

contact me: mouldiwarp@hotmail.com