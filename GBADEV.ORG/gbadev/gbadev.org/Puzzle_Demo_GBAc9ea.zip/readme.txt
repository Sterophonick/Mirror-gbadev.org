////////////////////////////////////////////////////////////////////
//
// Final Year Project Implementation Build Directory Readme File
// Author: Brian Davis
// Date: 16/03/2005
//
////////////////////////////////////////////////////////////////////

Puzzle Demo Instructions:

The gameplay for this demo is based on Nintendo's Dr. Mario, where you have to clear seeded viruses from the grid by aligning four same-colour blocks, horizontally or vertically. Clear all the viruses to complete the level.

User Input:

The user input description (below) is separated into columns to show the functionality mapped to the default keys in the VisualBoyAdvance emulator and the Game Boy Advance (GBA) hardware buttons.

Emulator 	GBA	Functionality

Down arrow	Down	Move Puzzle Piece Down Faster.
Left arrow	Left	Move Puzzle Piece Left.
Right arrow	Right	Move Puzzle Piece Right.
Enter		Start	Start/Pause Game.
Z		A	Rotate Puzzle Piece Clockwise.
X		B	Rotate Puzzle Piece Anti-Clockwise.
