
Welcome to SPLAM!SID v1.0	27th Sept 2002

------------------------------------------------
Revision 1.			01 Oct 2002
	Changed the bin and added a bit of code which seems is necessary for total
compatibilty with multiple roms per cart (basically clearing out ram to get rid of any
crap the multiboot software left there,  shouldn't be needed cuz my code 'should' initialise
everything properly, I obviously missed something..

Left the version number the same for now as its not really a 'change' as such.

------------------------------------------------



SPLAM!SID is the sid emulation part of my c64 emu (still in development) SPLAM released as
 a stand alone SID player.

I've been working on this for a couple of weeks now and was going to wait until it was 100%
 complete but I thought, what the hell..
 
This is a development release so don't be too harsh (wait for the next version 1st).

Please read this whole document before mailing and asking "why is this sid in there but doesn't
work?"

Currently emulated..
-------------------------------
6510 - ~90%
6581 - ~90%

Emulation isn't 100% (compared to other emulations, not the c64 hardware) and as such some
sids will sound wrong or not play at all but I've left in ones that don't work correctly so
you can see (hmm,  hear) the progress when the next version is released.

If some tunes don't play, it may be an initialisation bug, just try left/right a couple of times
to give them a kick (e.g. Ghouls and Ghosts).

Remember, this is written for GBA, so playing it under an emulator will just make it sound
wrong, I developed it using VBOY (many thanks for such a great emu Forgotten) but at the last
minute before I was going to release it I realised that the vboy directsound emulation works
differently to the gba hardware (I'll be sending an email to Forgotten to explain the difference).
 This meant a bit of a rewrite and may have caused some bugs/inacuracies to creep in at the
last minute.

There's a slight possibilty that it may crash on some hardware, I've been assured by someone
that I shouldn't worry about this and that it was older versions of the flash linker software
that caused the problems but I've had a report from someone already that weird things happen
 (maybe he's still using old linker software,  hmm)

Finally,  use headphones pleaaaase,  the gba speaker is crud :-P


Instructions..
-------------------------------

Up/Down to scroll through the sids ('mostly' in alphabetical order)
shoulder buttons left/right to page up/down
Button A to choose a sid
Left/Right for subtunes
Start for some debug info on the sid registers (just used for my own info while developing)


What still needs to be done..
-------------------------------
All of these are in progress and won't take too long to do.

Filters aren't quite working how I'd like yet so they're left out of this release.
I ended up saving a wav of a sid I made with 1 waveform and various filters applied so I
could look at the waveform which gave me the knowledge I needed to get the filters right
(yeah, I could look at the source code, but thats no fun).

Higher mixing frequency.   It's currently ~16khz but when I recode the 6581 emulation in ARM
I think 48khz or even above will be very possible as the 6581 emulation is currently written
in C  yeah yeah, I know, but it's easier to mess around with stuff like that before coding
an optimised asm version (ie, I know how many registers I need etc) and I've looked at the
asm made by the gcc compiler and I reckon a 400%+ increase in speed is easily possible.

'Galway noise' isn't done yet (just not got around to it) and sampling is a bit dodgy too as 
I haven't implemented the full spec yet.  I may add support for PSID_v2 when the asm version
is complete and do the sample playing that way.

6510 emulation needs to be optimised and have some missing opcodes (some of the ones classed
as 'extra' opcodes from the 6502) implementing.  Optimisation will only really matter so much
in SPLAM itself where the emulation of the rest of the c64 also needs to be done.

Timers, some tunes use the c64 timers to call the play routine more than once per frame, this
isn't emulated correctly yet and so some tunes will play at the wrong speeds (e.g. Times of Lore)
 and the ones that do play at the correct speed (e.g. Wizball, ZigZag, Flash_inc) sounda kinda glitchy
 due to the way my mixer currently works.

SID 'injector' Yes, everyone will want their own sids and not my choice (mostly the HVSC top
100 with a few extras)

A few extra bits and pieces which may or may not get done :-P

Sources of info
-------------------------------
http://www.emuitalia.com/cbmitapages/c64/sid2eng.htm 
An interview with Bob Yannes creator of the SID chip 

http://www.emuitalia.com/cbmitapages/c64/sid1eng.htm
The SID  (a page about you know what)


Contact
-------------------------------
email	splam@emuhq.com
Web	splam.emuhq.com