PocketFlute 0.51 is a small application made with Ham 2.8 that permits you to play a virtual flute on your GBA, while seeing its music score.

Controls:
LEFT	Do	C
UP	Re	D
RIGHT	Mi	E
DOWN	Fa	F
A	Sol	G
B	La	A
L	Si	B
R	Do	C

Coming soon:
Save&load function


Federico Severi
federico.severi@gmail.com
http://digilander.libero.it/tipika/