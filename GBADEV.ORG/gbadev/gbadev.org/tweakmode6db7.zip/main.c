#include "gba.h"				// gba registers, typedefs
#include "screenmode.h"		// screenmode defines
#include "interupts.h"		// interupt handling
#include "GBAio.h"			// some dma, swi routines
#include "trigLUT.h"			// sin/cos lookup

// handy macros for color processing
#define getRGB(R,G,B,PAL) (B) = ((PAL) >> 10) & 31; \
	                      (G) = ((PAL) >> 5)  & 31; \
                          (R) = (PAL) & 31;

#define setRGB(R,G,B) (B) << 10 | (G) << 5 | (R)

#define fadePal		((u16 *)0x203F800)
#define sourcePal		((u16 *)0x203FC00)


// useful for checking key presses
#define keyDown(KEY) (!(KEYS & (KEY)))

// defined in GBAio.c, used for dma clear routine
extern u32 clearVal;

// externs from resource.a
extern const u16 icelogo3_Image_Data[];
extern const u16 icelogo3_Palette_Data[];
extern const u16 title_Image_Data[];
extern const u16 title_Palette_Data[];
extern const u16 title_Map_Data[];

extern void rotateVectors() CODE_IN_IWRAM;
extern void clearVRAM() CODE_IN_IWRAM;
extern void plotPixels() CODE_IN_IWRAM;
extern void setupMatrix() CODE_IN_IWRAM;

u32 bgY, bgX;
s32 dots[512][3];				// dot vector list
s32 screen[512][2];
s32 rmatrix[9];				// rotation matrix
s32 oneOverZ[2000];			// 1/z table for perspective trasnform
u32 rx, rz;
u32 xbase;

#define workRam ((u8 *)0x2030000)
u16 ramPtr;

void doFadeIn(s32 vsync)
{
	u16 fadeR, fadeG, fadeB;
	u16 palR, palG, palB;
	u16 loop;

	for (loop = 0; loop < 512; loop++)
	{
		getRGB(fadeR, fadeG, fadeB, fadePal[loop]);
		getRGB(palR, palG, palB, sourcePal[loop]);
		if (fadeR < palR) fadeR++;
		if (fadeG < palG) fadeG++;
		if (fadeB < palB) fadeB++;
		fadePal[loop] = setRGB(fadeR, fadeG, fadeB);
	}

	if (vsync)
		VBlankIntrWait();

	dma32xfer((u32)fadePal, (u32)BGPaletteMem, 256);
}


void doFadeOut(s32 vsync)
{
	u16 fadeR, fadeG, fadeB;
	u16 loop;

	for (loop = 0; loop < 512; loop++)
	{
		getRGB(fadeR, fadeG, fadeB, fadePal[loop]);
		if (fadeR > 0) fadeR--;
		if (fadeG > 0) fadeG--;
		if (fadeB > 0) fadeB--;
		fadePal[loop] = setRGB(fadeR, fadeG, fadeB);
	}

	if (vsync)
		VBlankIntrWait();

	dma32xfer((u32)fadePal, (u32)BGPaletteMem, 256);
}


// do splash screen
void doSplash(void)
{
	u16 loop, fadeloop;
	double r;
	s16 x, y, z;

	REG_DISPCNT = MODE_4 | BG2_ENABLE; // switch to mode4

	clearVal = 0;
	dma32clear((u32)fadePal, 256);
	dma32clear((u32)BGPaletteMem, 256);

	dma32xfer((u32)icelogo3_Palette_Data, (u32)sourcePal, 128);

#if COGREG == 1
	LZ77UnCompVRAM((u32)icelogo3_Image_Data, 0x6000000);
#else
	dma32xfer((u32)icelogo3_Image_Data, 0x6000000, 38400 >> 2);
#endif

	// fade in the palette for the splash screen
	for (fadeloop = 0; fadeloop < 32; fadeloop++)
		doFadeIn(1);

	r = -1;
	for (loop=1; loop<2000; loop++) {
		oneOverZ[loop] = (s32)((4096.0/r) * 4096.0);
		r--;
	}

	// init matrix with 3d coords
	loop = 0;
	for (z=-140; z<=140; z+=40) {
		for (y=-140; y<=140; y+=40) {
			for (x=-140; x<=140; x+=40) {
				dots[loop][0] = x << 8;
				dots[loop][1] = y << 8;
				dots[loop][2] = z << 8;
				loop++;
			}
		}
	}


	// fade out the splash screen
	for (fadeloop = 0; fadeloop < 32; fadeloop++)
		doFadeOut(1);
}

void VCount_Split(void)
{
	u16 scan = REG_VCOUNT;

	if (scan == 0) {
		REG_DISPSTAT &= 0xFF;
		REG_DISPSTAT |= 0x1000;	//set next vcount irq at scan 16

		xbase = 120 - xbase;
		clearVRAM();	// start vram clear
	}

	// switch to mode4 for center 128 rows
	if (scan == 16) {

		REG_DISPCNT = MODE_4 | BG2_ENABLE | BACKBUFFER;

		// tweak mode4 so its rotated 90 degrees CW and flipped horizontally
		// scale to fill screen

		bgY = ((120 - xbase) << 8);
		REG_BG2X = bgY + (16 << 8);	// flip page buffers
		REG_BG2PA = 0;
		REG_BG2PB = 192;	// vertical scale = 160/120 = 1.3333	256/1.3333 = 192
		REG_BG2PC = 170;	// horizontal scale = 240/160 = 1.5		256/1.5 = 170
		REG_BG2PD = 0;

		REG_DISPSTAT &= 0xFF;
		REG_DISPSTAT |= 0x8F00;	// set next vcount irq at scan 143
	}

	// switch to mode0 for bottom 32 rows and top 32
	if (scan == 143) {
		REG_DISPCNT = MODE_0 | BG3_ENABLE;
		REG_BG3CNT = 0x4800;	//512x256 text map, char map 4, 16 color, char set 0
		REG_BG3HOFS = bgX;
		REG_DISPSTAT &= 0xFF;
		REG_DISPSTAT |= 0x0000;	//set next vcount irq at scan 16

	}

	REG_IF = INT_VCOUNT;

}


int AgbMain(void)
{
	int loop;

	// enable vblank interupts for VBlankIntrWait to work
	EnableInterupts(INT_VBLANK);

	doSplash();

	REG_DISPCNT = MODE_0 | BG3_ENABLE;
	REG_BG3CNT = 0x4800;	//512x256 text map, char map 4, 16 color, char set 0

	clearVal = 0;
	dma32clear((u32)sourcePal, 256);
	dma32clear((u32)0x6000000, 0x18000 >> 2);

#if COGREG == 1
	LZ77UnCompVRAM((u32)title_Image_Data, 0x6000000);
	LZ77UnCompVRAM((u32)title_Map_Data, 0x6004000);
#else
	dma32xfer((u32)title_Image_Data, 0x6000000, 8224 >> 2);
	dma32xfer((u32)title_Map_Data, 0x6004000, 2048 >> 2);
#endif

	bgY = 120<<8;
	xbase = 120;
	dma32xfer((u32)title_Palette_Data, (u32)sourcePal,  32 >> 2);

	IntrTable[2] = (fp)VCount_Split;
	REG_DISPSTAT |= 0x1020;
	EnableInterupts(INT_VCOUNT);

	for (loop=0; loop<32; loop++)
	{
		setupMatrix();
		rotateVectors();
		doFadeIn(1);
		plotPixels();
		rx += 11;
		rz += 15;
	}


	while (true) {
		setupMatrix();
		rotateVectors();
		VBlankIntrWait();
		plotPixels();
		rx += 11;
		rz += 15;

	}

	return 0;
}

