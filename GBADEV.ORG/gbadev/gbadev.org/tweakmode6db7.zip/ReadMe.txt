tweakmode 1.0
-------------

Written by MrMr[iCE]
email: pureedlizard@hotmail.com
irc: any EFNet server, on #gbadev, #emuholic, #gameart

This is a small testbed rom for showing off a few things:
	tweaked mode 4
	mode splits
	Arm assembler 3d routines
	
This is just a small demo of some techniques I picked up and a preview
of a 3d engine I'm in the middle of writing. The screen is split in 3
sections. The top and bottom graphic areas is a mode 0 tile map while
the middle is a "tweaked" mode 4. It is rotated on its side and scaled 
to fill the screen, but with only half the resolution of mode 4. This 
allows me 2 "buffers" to draw in with only one page of vram. Page flips 
is accomplished by tweaking the BG x register to show the other buffer. 

To build the demo, it requires CoG, an excellent graphics conversion 
utility. Go get it at www.onemanband.com. And support OMB's efforts
by registering CoG. The makefiles are designed to work with both trial
and registered versions, read Makefile on how to compile with the 2 versions.

You must run gnu make to compile, MS Visual C++'s nmake will not work.

Kudos to Joat, Costis and Torlus for asm tips and tricks.
Thanks to OneManBand for providing CoG to the gba dev scene.