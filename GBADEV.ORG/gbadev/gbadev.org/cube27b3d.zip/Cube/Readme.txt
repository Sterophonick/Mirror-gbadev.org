cube
~~~~

This was my first demo for GBA before I had hardware. I've tidied the
library up a bit but this code is messy, and not the best example of
how to handle vertices and faces ;)

My line drawing code still isn't fixed for non byte writes either, but
who wants to plot lines when we can plot polys...
--
Pete (dooby@bits.bris.ac.uk / http://bits.bris.ac.uk/dooby/)