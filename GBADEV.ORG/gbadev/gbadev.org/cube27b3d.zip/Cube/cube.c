// cube demo
// Pete (dooby@bits.bris.ac.uk)

#include "..\gba\gba.h"

void fuzz(void);

typedef struct vertex Vertex;
typedef struct face Face;
typedef struct object Object;

struct vertex {
  signed short int x, y, z;
};

struct face {
  Vertex v[4];
  unsigned short col;		// We may want 15bpp colours one day...
  struct face *n;		// Pointer to next face in object face list.
};

struct object {
  struct face *face;
  unsigned short angX;
  unsigned short angY;
  unsigned short angZ;
  signed short offX;
  signed short offY;
  signed short offZ;
};

#define XOFF 120
#define YOFF 80

void psp(Face *temp) {
  int i;
  for(i = 0; i < 4; i ++) {
    temp->v[i].x = (temp->v[i].x * (temp->v[i].z + 256)) >> 8;
    temp->v[i].y = (temp->v[i].y * (temp->v[i].z + 256)) >> 8;
  }
}

void trs(Face *temp, signed short offX, signed short offY, signed short offZ) {
  int i;
  for(i = 0; i < 4; i ++) {
    temp->v[i].x += offX;
    temp->v[i].y += offY;
    temp->v[i].z += offZ;
  }
}

void rotX(Face *temp, signed long sin_val, signed long cos_val) {
  int i;
  signed short nz, ny;
  for(i = 0; i < 4; i ++) {
    nz = (signed short)(cos_val * temp->v[i].z - sin_val * temp->v[i].y) >> 7;
    ny = (signed short)(cos_val * temp->v[i].y + sin_val * temp->v[i].z) >> 7;
    temp->v[i].z = nz;
    temp->v[i].y = ny;
    temp->v[i].x = temp->v[i].x;
  }
}

void rotY(Face *temp, signed long sin_val, signed long cos_val) {
  int i;
  signed short nx, nz;
  for(i = 0; i < 4; i ++) {
    nx = (signed short)(cos_val * temp->v[i].x - sin_val * temp->v[i].z) >> 7;
    nz = (signed short)(cos_val * temp->v[i].z + sin_val * temp->v[i].x) >> 7;
    temp->v[i].x = nx;
    temp->v[i].z = nz;
    temp->v[i].y = temp->v[i].y;
  }
}

void rotZ(Face *temp, signed long sin_val, signed long cos_val) {
  int i;
  signed short nx, ny;
  for(i = 0; i < 4; i ++) {
    nx = (signed short)(cos_val * temp->v[i].x - sin_val * temp->v[i].y) >> 7;
    ny = (signed short)(cos_val * temp->v[i].y + sin_val * temp->v[i].x) >> 7;
    temp->v[i].x = nx;
    temp->v[i].y = ny;
    temp->v[i].z = temp->v[i].z;
    // Rounding experiment... Could be done faster in ASM using
    // mov	a1, a1, asr #7
    // addcs	a1, a1, #1
    //if(temp->v[i].x & 1 != 0) temp->v[i].x = (temp->v[i].x + 1) >> 1;
    //else temp->v[i].x = temp->v[i].x >> 1;
    // Rounding experiment...
    //if(temp->v[i].y & 1 != 0) temp->v[i].y = (temp->v[i].y + 1) >> 1;
    //else temp->v[i].y = temp->v[i].y >> 1;
  }
}

void copy(Face *dest, Face *src) {
  int i;

  // This can almost certainly be done quicker using some sort of memcpy.
  for(i = 0; i < 4; i ++) {
    dest->v[i].x = src->v[i].x;
    dest->v[i].y = src->v[i].y;
    dest->v[i].z = src->v[i].z;
  }
  dest->col = src->col;
}

void init_cube(Object *o, Face f[]) {
  // Left face.
  f[0].v[0].x = -25; f[0].v[0].y = -25; f[0].v[0].z = -25;
  f[0].v[1].x = -25; f[0].v[1].y = -25; f[0].v[1].z =  25;
  f[0].v[2].x = -25; f[0].v[2].y =  25; f[0].v[2].z =  25;
  f[0].v[3].x = -25; f[0].v[3].y =  25; f[0].v[3].z = -25;
  f[0].col = 1;

  // Front face.
  f[1].v[0].x = -25; f[1].v[0].y = -25; f[1].v[0].z =  25;
  f[1].v[1].x =  25; f[1].v[1].y = -25; f[1].v[1].z =  25;
  f[1].v[2].x =  25; f[1].v[2].y =  25; f[1].v[2].z =  25;
  f[1].v[3].x = -25; f[1].v[3].y =  25; f[1].v[3].z =  25;
  f[1].col = 2;

  // Right face.
  f[2].v[0].x =  25; f[2].v[0].y = -25; f[2].v[0].z =  25;
  f[2].v[1].x =  25; f[2].v[1].y = -25; f[2].v[1].z = -25;
  f[2].v[2].x =  25; f[2].v[2].y =  25; f[2].v[2].z = -25;
  f[2].v[3].x =  25; f[2].v[3].y =  25; f[2].v[3].z =  25;
  f[2].col = 3;

  // Back face.
  f[3].v[0].x =  25; f[3].v[0].y = -25; f[3].v[0].z = -25;
  f[3].v[1].x = -25; f[3].v[1].y = -25; f[3].v[1].z = -25;
  f[3].v[2].x = -25; f[3].v[2].y =  25; f[3].v[2].z = -25;
  f[3].v[3].x =  25; f[3].v[3].y =  25; f[3].v[3].z = -25;
  f[3].col = 4;

  // Top face.
  f[4].v[0].x = -25; f[4].v[0].y =  25; f[4].v[0].z =  25;
  f[4].v[1].x =  25; f[4].v[1].y =  25; f[4].v[1].z =  25;
  f[4].v[2].x =  25; f[4].v[2].y =  25; f[4].v[2].z = -25;
  f[4].v[3].x = -25; f[4].v[3].y =  25; f[4].v[3].z = -25;
  f[4].col = 5;

  // Bottom face.
  f[5].v[0].x = -25; f[5].v[0].y = -25; f[5].v[0].z = -25;
  f[5].v[1].x =  25; f[5].v[1].y = -25; f[5].v[1].z = -25;
  f[5].v[2].x =  25; f[5].v[2].y = -25; f[5].v[2].z =  25;
  f[5].v[3].x = -25; f[5].v[3].y = -25; f[5].v[3].z =  25;
  f[5].col = 6;

  // Initialise object face list.
  o->face = &f[0];
  f[0].n = &f[1];
  f[1].n = &f[2];
  f[2].n = &f[3];
  f[3].n = &f[4];
  f[4].n = &f[5];
  f[5].n = 0;

  // Initialise object offset & rotation attributes.
  o->angX =    0;
  o->angY =    0;
  o->angZ =    0;
  o->offX =  -49;
  o->offY =   24;
  o->offZ =    0;
}

int code_start(void) {
  int i, j;
  Object cube;
  Face temp, cube_faces[6], *curr;
  signed long int sin[3], cos[3], visible;
  long int bx, bxs = 4, by = 90, bz, bzs = 2;
  long int nx, ny, nz, nm;

  // Speed debugging.
  int min = 200, max = 0, total = 0, frames = 0, length;

  init_cube(&cube, cube_faces);

  gba_setmode(0x04);

  gba_clsW();
  for(i = 0; i < 256; i ++) gba_setpalette(i, i >> 3, i >> 3, i >> 3);

  fuzz();

// Fuzz.
  gba_clsW();
  for(i = 0; i < 256; i ++) gba_setpalette(i, i >> 3, i >> 3, i >> 3);

/*  for(i = 0; i < 30; i ++) {
    for(j = 0; j < 38400; j += 4) {
      *(unsigned long *)(0x06000000 + j) = gba_rand();
    }
    gba_vsync();
  }
*/
  gba_clsW();
  gba_setpalette(255, 0, 0, 0);
  gba_setpalette(254, 0, 0, 0);
  gba_setcolour(255);
  gba_print(4, 6, "dooby@bits.bris.ac.uk");
  gba_setcolour(254);
  gba_print(2,  13, "www.bits.bris.ac.uk/dooby");
  for(i = 0; i < 16; i ++) {
    gba_setpalette(255, i, i, i);
    gba_vsync();
  }
  for(i = 0; i < 16; i ++) {
    gba_setpalette(255, i+16, i+16, i+16);
    gba_setpalette(254, i, i, i);
    gba_vsync();
  }
  for(i = 0; i < 16; i ++) {
    gba_setpalette(254, i+16, i+16, i+16);
    gba_vsync();
  }
  for(i = 0; i < 30; i ++) gba_vsync();
  for(i = 31; i > 15; i --) {
    gba_setpalette(255, i, i, i);
    gba_vsync();
  }
  for(i = 31; i > 15; i --) {
    gba_setpalette(255, i-16, i-16, i-16);
    gba_setpalette(254, i, i, i);
    gba_vsync();
  }
  for(i = 31; i > 15; i --) {
    gba_setpalette(254, i-16, i-16, i-16);
    gba_vsync();
  }
  gba_clsW();

  gba_initbank();
// Set cube palette.
  gba_setpalette(0, 0, 0, 0);
  gba_setpalette(1, 31, 0, 0);
  gba_setpalette(2, 0, 31, 0);
  gba_setpalette(3, 31, 31, 0);
  gba_setpalette(4, 0, 0, 31);
  gba_setpalette(5, 31, 0, 31);
  gba_setpalette(6, 0, 31, 31);
  gba_setpalette(7, 31, 31, 31);

  // Set lighter face palettes.
  for(i = 0; i < 32; i ++) gba_setpalette( 32 + i, (i >> 1) + 16, 0, 0);
  for(i = 0; i < 32; i ++) gba_setpalette( 64 + i, 0, (i >> 1) + 16, 0);
  for(i = 0; i < 32; i ++) gba_setpalette( 96 + i, (i >> 1) + 16, (i >> 1) + 16, 0);
  for(i = 0; i < 32; i ++) gba_setpalette(128 + i, 0, 0, (i >> 1) + 16);
  for(i = 0; i < 32; i ++) gba_setpalette(160 + i, (i >> 1) + 16, 0, (i >> 1) + 16);
  for(i = 0; i < 32; i ++) gba_setpalette(192 + i, 0, (i >> 1) + 16, (i >> 1) + 16);
  for(i = 0; i < 32; i ++) gba_setpalette(224 + i, (i >> 1) + 16, (i >> 1) + 16, (i >> 1) + 16);
  // Set darker face palettes.
  /*
  for(i = 0; i < 32; i ++) gba_setpalette( 32 + i, i, 0, 0);
  for(i = 0; i < 32; i ++) gba_setpalette( 64 + i, 0, i, 0);
  for(i = 0; i < 32; i ++) gba_setpalette( 96 + i, i, i, 0);
  for(i = 0; i < 32; i ++) gba_setpalette(128 + i, 0, 0, i);
  for(i = 0; i < 32; i ++) gba_setpalette(160 + i, i, 0, i);
  for(i = 0; i < 32; i ++) gba_setpalette(192 + i, 0, i, i);
  for(i = 0; i < 32; i ++) gba_setpalette(224 + i, i, i, i);
  */

  // Test darker palette
  /*
  for(i = 0; i < 224; i ++) {
    gba_setcolour(i + 32);
    gba_drawline(i, 0, i, 159);
  }
  gba_swapbank();
  while(gba_readpad() & PAD_B);
  */

//gba_setcolour(7);

  /*while(TRUE) {
    length = *((unsigned short int *)(0x04000006));
    if(length > max) max = length;
    gba_debug_32_16(0, 7, length);
    gba_debug_32_16(0, 15, max);
  }*/


  while((gba_readpad() & PAD_A)) {
//  while((*(volatile unsigned short *)0x04000130 & 0x0001)) {
/*
  gba_setpalette(255, 16, 16, 16);
  gba_setcolour(255);
  gba_print(0, 0, "here");
  while(0==0);
*/

    // Ready to draw.
    gba_clsUnroll();

    // Let's have a bounding box.
//    gba_setcolour(1);
    // Back wall.
      gba_setcolour(232);
    gba_drawline(-85 + XOFF, 57 + YOFF, 85 + XOFF, 57 + YOFF);
    gba_drawline(-85 + XOFF, -57 + YOFF, 85 + XOFF, -57 + YOFF);
    gba_drawline(-85 + XOFF, -57 + YOFF, -85 + XOFF, 57 + YOFF);
    gba_drawline(85 + XOFF, -57 + YOFF, 85 + XOFF, 57 + YOFF);
//    gba_triangle(-85 + XOFF, -57 + YOFF, 85 + XOFF, -57 + YOFF, 85 + XOFF, 57 + YOFF);
//    gba_triangle(-85 + XOFF, 57 + YOFF, -85 + XOFF, -57 + YOFF, 85 + XOFF, 57 + YOFF);

    // Perspective lines.
//    gba_setcolour(1);
//    gba_triangle(0, 159, -85 + XOFF, 57 + YOFF, 239, 159);
//    gba_triangle(-85 + XOFF, 57 + YOFF, 85 + XOFF, 57 + YOFF, 239, 159);
//    gba_setcolour(3);
//    gba_triangle(0, 159, 0, 0, -85 + XOFF, -57 + YOFF);
//    gba_triangle(0, 159, -85 + XOFF, 57 + YOFF, -85 + XOFF, -57 + YOFF);
//    gba_setcolour(7);
    gba_drawline(0, 159, -85 + XOFF, 57 + YOFF);
    gba_drawline(0, 0, -85 + XOFF, -57 + YOFF);
    gba_drawline(239, 0, 85 + XOFF, -57 + YOFF);
    gba_drawline(239, 159, 85 + XOFF, 57 + YOFF);


    // Get the rotation angle sin and cos values.
    sin[0] = gba_sinq(cube.angX); cos[0] = gba_cosq(cube.angX);
    sin[1] = gba_sinq(cube.angY); cos[1] = gba_cosq(cube.angY);
    sin[2] = gba_sinq(cube.angZ); cos[2] = gba_cosq(cube.angZ);

    curr = cube.face;

    while(curr != 0) {

      // Rotate face into temp.
      copy(&temp, curr);
      rotX(&temp, sin[0], cos[0]);
      rotY(&temp, sin[1], cos[1]);
      rotZ(&temp, sin[2], cos[2]);
      trs(&temp, cube.offX, cube.offY, cube.offZ);
      psp(&temp);

      // Calculate face visibility.
//      visible  = (temp.v[0].x - temp.v[1].x) * (temp.v[2].y - temp.v[1].y);
//      visible -= (temp.v[0].y - temp.v[1].y) * (temp.v[2].x - temp.v[1].x);
//ny  = (temp.v[1].z - temp.v[0].z) * (temp.v[2].x - temp.v[1].x);
//ny -= (temp.v[1].x - temp.v[0].x) * (temp.v[2].z - temp.v[1].z);
nz  = (temp.v[1].x - temp.v[0].x) * (temp.v[2].y - temp.v[1].y);
nz -= (temp.v[1].y - temp.v[0].y) * (temp.v[2].x - temp.v[1].x);

      if(nz > 0) {
// Debug normals
//gba_setcolour(7);
nx  = (temp.v[1].y - temp.v[0].y) * (temp.v[2].z - temp.v[1].z);
nx -= (temp.v[1].z - temp.v[0].z) * (temp.v[2].y - temp.v[1].y);
//gba_debug(0, 152, nx);
//gba_debug(0, 144, nz);

if(nz == 0) {
  nm = 31;
} else {
  nm = gba_div(nx << 8, nz);
}
if(nm < 0) nm = -nm;
nm = nm >> 4;
if(nm > 31) nm = 31;
//gba_debug(0, 136, nm);
//nm = gba_atan(nm);
//gba_debug(0, 128, nm);

//nm = (nx * nx + ny * ny + nz * nz) * 256 * 256;
//nm = gba_sqrt(nm);

//gba_drawline(XOFF, YOFF, (nx * (nz + 256)) >> 8, (ny * (nz + 256)) >> 8);

        // Draw temporary face.
        gba_setcolour(temp.col * 32 + 31 - nm);
        gba_triangle(temp.v[0].x+XOFF, temp.v[0].y+YOFF,
                     temp.v[1].x+XOFF, temp.v[1].y+YOFF,
                     temp.v[2].x+XOFF, temp.v[2].y+YOFF);
        gba_triangle(temp.v[0].x+XOFF, temp.v[0].y+YOFF,
                     temp.v[2].x+XOFF, temp.v[2].y+YOFF,
                     temp.v[3].x+XOFF, temp.v[3].y+YOFF);
//        gba_drawline(temp.v[0].x+XOFF, temp.v[0].y+YOFF, temp.v[1].x+XOFF, temp.v[1].y+YOFF);
  //      gba_drawline(temp.v[1].x+XOFF, temp.v[1].y+YOFF, temp.v[2].x+XOFF, temp.v[2].y+YOFF);
    //    gba_drawline(temp.v[2].x+XOFF, temp.v[2].y+YOFF, temp.v[3].x+XOFF, temp.v[3].y+YOFF);
      //  gba_drawline(temp.v[3].x+XOFF, temp.v[3].y+YOFF, temp.v[0].x+XOFF, temp.v[0].y+YOFF);
      }

      // Get next face.
      curr = curr->n;
    }

    // Increment angles.
    cube.angX = (cube.angX + 1) % 360;
    cube.angY = (cube.angY + 3) % 360;
    //cube.angZ = (cube.angZ + 1) % 360;

    // Bounce :)
    cube.offX += bxs;
    if((cube.offX >= 49) || (cube.offX <= -49)) {
      cube.offX -= bxs;
      bxs *= -1;
    }
    cube.offZ += bzs;
    if((cube.offZ >= 75) || (cube.offZ <= -75)) {
      cube.offZ -= bzs;
      bzs *= -1;
    }
    by = (by + 4) % 180;
    cube.offY = ((gba_sin(by) * 48) >> 7) -24;

    // Increment z offset.
    //if(cube.offZ < 100) cube.offZ += 2;

    // Speed debug stuff.
    length = *((volatile unsigned short int *)(0x04000006));
    if(length < min) min = length;
    if(length > max) max = length;
    total += length;
    frames ++;

// Raster timing.
/*
    if((length >= 0) && (length < 160)) {
      //if(length < 64) gba_setcolour(1);
      //else gba_setcolour(2);
      gba_setcolour(2);
      gba_drawline(0, 159-length, 239, 159-length);
    } else {
      gba_setcolour(1);
      gba_drawline(0, 159-(length - 160), 239, 159-(length - 160));
    }
*/

    // Loop.
//    while(*((volatile unsigned short int *)(0x04000006)) != 208 /*0xe3*/);
    gba_vsync();
    if((gba_readpad() & PAD_B) == 0) for(i = 0; i < 10; i ++) gba_vsync();
    gba_swapbank();
  }

  // Debug speed info.
  gba_setwbank(1);
  gba_cls();
  gba_setdbank(0);
  gba_setcolour(7);
  gba_print(0, 0, "frames"); gba_debug_32_16(7, 0, frames);
  gba_print(0, 1, "min");    gba_debug_32_16(7, 1, min);
  gba_print(0, 2, "max");    gba_debug_32_16(7, 2, max);
  gba_print(0, 3, "avg");    gba_debug_32_16(7, 3, (int)(total/frames));

  return(0);
}
