                             -------------------
                             | Mediaeval Quest |
                             -------------------

                         Version 1.3 (December 2005)

                             For GameBoy Advance

                         Programmed by Donnie Russell
                              Copyright (C) 2005



License
-------

The contents of this archive are freeware; they are not in the public domain.
This archive may only be redistributed in an unmodified state. The software
contained in this archive is provided to the end-user "as is", and comes with
no warranty of any kind. In no event shall the copyright owner be liable for
any damage that may result from the use of this software.

This software may not be sold in any form for any reason whatsoever.
Distribution of this software on cartridge media is strictly prohibited.



About This Game
---------------

Mediaeval Quest is based on Adventure for the Atari VCS/2600, but is not a
direct port. It deviates from Adventure in significant ways, but is also very
similar in others.



Story
-----

Monsters have invaded the land, causing most of its inhabitants to flee for
their lives, and a magical artifact, the Sangreal, has been stolen. You, a
brave knight, have undertaken a quest to find the Sangreal and return it to
its resting place in the gold castle. Only the Sangreal's magic is powerful
enough to defeat the evil that has befallen the land. Alone and unarmed, you
begin your quest.



Beginning a quest
-----------------

At the title screen, press SELECT to choose one of three types of quests.

Quest #1 features items that start in fixed locations and monsters who guard
but do not steal items.

Quest #2 is like #1, except that items are randomly scattered across the land.

Quest #3 is like #2, except that monsters also steal items in addition to
guarding them.

Press the START button to begin your selected quest.



Controls
--------

Use the directional keys to move through the various locations of the game.
Move off the edge of the screen in one of the four compass directions to leave
your current location and enter an adjacent one.

Scattered throughout the game world are several objects. Walk into an object
to automatically pick it up. Press the A button to drop any object you are
carrying. If you are carrying an object, and walk into another, the first one
will be dropped. Objects have various properties and interactions in the game
that are left for you to discover.

If you are unfortunate enough to be killed by one of the roaming monsters, you
have been given three chances to reincarnate yourself at the gold castle by
pressing the A button.

If you become trapped (under a slain monster, for example) you can teleport
yourself to another location by pressing the SELECT button.

After finishing your quest, press the START button to go back to the title
screen.

At any time during your quest you can press the START button to bring up a
menu with several options. Use the directional keys or SELECT button to
highlight an option, then press the A or START button to select it. The
options are:

Customize Room: Press the SELECT button to toggle between the room map and the
virtual keyboard. Use the directional keys to move the cursors. Press the A
button to change the character highlighted on the room map (see the Room Map
Characters section). Press the START button to exit.

Save Map: Save customizations to persistent memory.

Restore Map: Load previously saved customizations from persistent memory.

Default Map: Reset all customizations back to the default.

Quit Game: End current game and return to the title screen.

Continue Game: Continue playing the current game.



Room Map Characters
-------------------

space    ground (walkable)
x        rock
a-d      black castle exterior
e-h      gold castle exterior
i-l      silver castle exterior
~        water
0        black castle moat crossing (1)
2        gold castle moat crossing (1)
4        silver castle moat crossing (1)
1        black castle entrance
3        gold castle entrance
5        silver castle entrance
B        black castle interior
G        gold castle interior
S        silver castle interior
_        darkness (walkable)
*        hedge
#        cave wall
.        floor (walkable)
!        tree
|        bridge (walkable)
<        table left (2)
>        table right (2)

All other characters are displayed as rock and are non-walkable.

(1) Drawbridge positioning depends upon these characters not being moved or
    changed.
(2) The default table in the gold castle should not be moved or changed, but
    additional tables can be added in any room.



Easter Egg
----------

Like Adventure, this game contains an Easter egg, a hidden feature that is
revealed by performing a particular series of actions in the game.
