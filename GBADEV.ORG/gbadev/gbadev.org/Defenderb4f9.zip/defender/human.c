//-------------------------------------------------------------------------

// humanoid routines
// Rich Heasman July 1997 / May 2002

//-------------------------------------------------------------------------

#include 	"human.h"

#include 	"gfx.h"
#include 	"gfxdata2.h"
#include 	"land.h"
#include 	"alien.h"
#include 	"ship.h"
#include 	"collide.h"
#include 	"radar.h"
#include 	"soundfx.h"
#include 	"bonus.h"
#include 	"rnd.h"
#include 	"player.h"
#include 	"scores.h"
#include 	"explode.h"
#include	"sprite.h"
#include	"debug.h"

//-------------------------------------------------------------------------

#define	HUMAN_MAX_NUM		HUMAN_NEW_NUM	// Max number of new humans
#define	HUMAN_NEW_EVERY		4				// number of waves before new humans

#define	HUMAN_MIN_SPEED 	(FIXEDPT)(FIXEDPT_UNITS*0.01)	// units pixels per frame along surface
#define	HUMAN_MAX_SPEED 	(FIXEDPT)(FIXEDPT_UNITS*0.1) 	// units pixels per frame along surface
#define	HUMAN_BELOW_LAND	(GFX_PLAY_HEIGHT/50)			// number of pixels under surface that humans sit
#define	HUMAN_GRAVITY		(FIXEDPT)(FIXEDPT_UNITS*0.03)	// gravity acceleration
#define	HUMAN_DEAD_SPEED	(FIXEDPT)(FIXEDPT_UNITS*1.90)	// speed for human death

//-------------------------------------------------------------------------

typedef struct {
	SPRITE_TYPE	*pSprite;			// Object
	FIXEDPT		xXCo;		   		// X position
	FIXEDPT		xYCo;		   		// Y position
	FIXEDPT		xYSpeed;	   		// Speed of falling human
	FIXEDPT		xXSpeed;	   		// Speed of roaming
	int			nStatus;	   		// Status
	int			nSolider; 			// Solider interested in human
	int			nRadar; 			// Radar entry
} HUMAN_TYPE;

static	HUMAN_TYPE  	Humanoids[HUMAN_MAX_NUM];
static	int			nHumanNumAlive;

//-------------------------------------------------------------------------

void	Human_Init(void)
{
	int	nLoop;

	for (nLoop=0;nLoop<HUMAN_MAX_NUM;nLoop++)
	{
		Humanoids[nLoop].nStatus=HUMAN_DEAD;
	}
}

//-------------------------------------------------------------------------

void	Human_Clear(void)
{			 
	int	nLoop;

	for (nLoop=0;nLoop<HUMAN_MAX_NUM;nLoop++)
	{
		if (Humanoids[nLoop].nStatus!=HUMAN_DEAD)
		{
			Humanoids[nLoop].nStatus=HUMAN_DESTROY;
		}
	}
}

//-------------------------------------------------------------------------

void	Human_Start(int nSheet)
{
	if (nSheet%HUMAN_NEW_EVERY==1)
	{
		nHumanNumAlive=HUMAN_NEW_NUM;
	}
	Human_New(nHumanNumAlive);
}

//-------------------------------------------------------------------------

void	Human_New(int nNum)
{
	int	nLoop;
	int	nCount;

	for (nCount=0;nCount<nNum;nCount++)
	{
		nLoop=0;
		while (nLoop<HUMAN_MAX_NUM && Humanoids[nLoop].nStatus!=HUMAN_DEAD)
		{
			nLoop++;
		}
		if (nLoop<HUMAN_MAX_NUM && Sprite_Available())
		{
			Humanoids[nLoop].xXCo=GFX_PLAY_WIDTH/nNum*nLoop;		// div (not in game)
			Humanoids[nLoop].xYCo=0;
			Humanoids[nLoop].nStatus=HUMAN_ROAMING;
			Humanoids[nLoop].nSolider=0;
			Humanoids[nLoop].xYSpeed=0;
			Humanoids[nLoop].xXSpeed=SHIP_RANDOM_DIR*FixedRnd(HUMAN_MIN_SPEED,HUMAN_MAX_SPEED);
			if (Humanoids[nLoop].xXSpeed>0)
			{
				Humanoids[nLoop].pSprite=Sprite_Create(GFX_HUMANOID_L,0,GFX_SCREEN_PIXEL_HEIGHT);
			}
			else
			{
				Humanoids[nLoop].pSprite=Sprite_Create(GFX_HUMANOID_R,0,GFX_SCREEN_PIXEL_HEIGHT);
			}
			Humanoids[nLoop].nRadar=Radar_Add(GFX_PURPLE_RADAR);
		}
	}
}

//-------------------------------------------------------------------------

void	Human_Update(void)
{
	int		nLoop;
	BOOL	bHumanReplaced;
	int		nX;
	int		nY;

	bHumanReplaced=FALSE;
	for (nLoop=0;nLoop<HUMAN_MAX_NUM;nLoop++)
	{
		switch 	(Humanoids[nLoop].nStatus)
		{
			case HUMAN_DEAD :
			{
				break;
			}
			case HUMAN_DESTROY :
			{
				Sprite_Destroy(Humanoids[nLoop].pSprite);
				Radar_Remove(Humanoids[nLoop].nRadar);
				Humanoids[nLoop].nStatus=HUMAN_DEAD;
				break;
			}
			case HUMAN_ROAMING :
			{
				Humanoids[nLoop].xXCo+=Humanoids[nLoop].xXSpeed;
				Humanoids[nLoop].xXCo=Land_Boundary(Humanoids[nLoop].xXCo);
				Humanoids[nLoop].xYCo=Land_HeightGet(Humanoids[nLoop].xXCo)-HUMAN_BELOW_LAND;
				break;
			}
			case HUMAN_WAITING :
		 	{
				break;
			}
			case HUMAN_CAPTURED :
			{
				Humanoids[nLoop].xYCo=Alien_HeightGet(Humanoids[nLoop].nSolider)-GFX_SOLIDER_HEIGHT;
				break;
			}
			case HUMAN_DROPING :
			{
				Humanoids[nLoop].xYSpeed+=HUMAN_GRAVITY;
				Humanoids[nLoop].xYCo-=Humanoids[nLoop].xYSpeed;
				if (Humanoids[nLoop].xYCo<=Land_HeightGet(Humanoids[nLoop].xXCo)-HUMAN_BELOW_LAND)
				{
					if (Humanoids[nLoop].xYSpeed>=HUMAN_DEAD_SPEED)
					{
						Human_Kill(nLoop);
					}
					else
					{
						Human_Landed(nLoop);
						Bonus_Create(HUMAN_LANDED,Humanoids[nLoop].xXCo,Humanoids[nLoop].xYCo,Humanoids[nLoop].xXSpeed*3);
						Player_ScoreAdd(SCORE_HUMAN_DROP);
					}
				}
				else
				{
					if (Ship_CollisionCheck(Humanoids[nLoop].xXCo,Humanoids[nLoop].xYCo,GFX_HUMAN_WIDTH,GFX_HUMAN_HEIGHT) && !Ship_IsDead())
					{
						Humanoids[nLoop].nStatus=HUMAN_RIDING;
						Bonus_Create(HUMAN_PICKUP,Humanoids[nLoop].xXCo,Humanoids[nLoop].xYCo,Humanoids[nLoop].xXSpeed*3);
						Player_ScoreAdd(SCORE_HUMAN);
					}
				}
				break;
			}
			case HUMAN_RIDING :
			{
				if (Ship_IsDead())
				{
					Human_Drop(nLoop);
				}
				else
				{
					Humanoids[nLoop].xXCo=Ship_PosXGet();
					Humanoids[nLoop].xYCo=Ship_PosYGet()-GFX_SHIP_HEIGHT;
					if (!bHumanReplaced&&(Humanoids[nLoop].xYCo<=Land_HeightGet(Humanoids[nLoop].xXCo)-HUMAN_BELOW_LAND))
					{
						Human_Landed(nLoop);
						Bonus_Create(HUMAN_REPLACED,Humanoids[nLoop].xXCo,Humanoids[nLoop].xYCo,Humanoids[nLoop].xXSpeed*3);
						Player_ScoreAdd(SCORE_HUMAN);
						bHumanReplaced=TRUE;
					}
				}
				break;
			}
		}
		if (Humanoids[nLoop].nStatus!=HUMAN_DEAD)
		{
			nX=FixedToScreenX(Land_Boundary(Humanoids[nLoop].xXCo-Ship_PosGet()),GFX_HUMAN_WIDTH);
			nY=FixedToScreenY(Humanoids[nLoop].xYCo,0);
			Sprite_PositionSet(Humanoids[nLoop].pSprite, nX, nY);
			Radar_Position(Humanoids[nLoop].nRadar,Humanoids[nLoop].xXCo,Humanoids[nLoop].xYCo);
		}
	}
}

//-------------------------------------------------------------------------

void	Human_Claim(int nHuman,int nSolider)
{
	Humanoids[nHuman].nSolider=nSolider;
	Humanoids[nHuman].nStatus=HUMAN_WAITING;
}

//-------------------------------------------------------------------------

void	Human_Pickup(int nHuman,int nSolider)
{
	Humanoids[nHuman].nSolider=nSolider;
	Humanoids[nHuman].nStatus=HUMAN_CAPTURED;
	SoundFX_Make(SOUNDFX_CHANNEL_A, SOUNDFX_SQUEEK);
}

//-------------------------------------------------------------------------

void	Human_Kill(int nHuman)
{
	nHumanNumAlive--;
	SoundFX_Make(SOUNDFX_CHANNEL_A, SOUNDFX_SQUEEK);
	Humanoids[nHuman].nStatus=HUMAN_DESTROY;
	Explode_Make(EXPLODE_HUMAN,Humanoids[nHuman].xXCo,Humanoids[nHuman].xYCo-GFX_HUMAN_HEIGHT/2);
}

//-------------------------------------------------------------------------

void	Human_Landed(int nHuman)
{
	Humanoids[nHuman].nStatus=HUMAN_ROAMING;
}

//-------------------------------------------------------------------------

int		Human_Status(int nHuman)
{
	return(Humanoids[nHuman].nStatus);
}

//-------------------------------------------------------------------------

FIXEDPT	Human_Height(int nHuman)
{
	return(Humanoids[nHuman].xYCo);
}

//-------------------------------------------------------------------------

void	Human_Drop(int nHuman)
{
	Humanoids[nHuman].nStatus=HUMAN_DROPING;
	Humanoids[nHuman].xYSpeed=0;
}

//-------------------------------------------------------------------------

int		Human_Check(FIXEDPT xXPos)
{
	int	nLoop;
	int	nHuman;

	nHuman=HUMAN_NOT_PRESENT;
	for (nLoop=0;nLoop<HUMAN_MAX_NUM;nLoop++)
	{
		if (FixedToInt(xXPos)==FixedToInt(Humanoids[nLoop].xXCo)
		 && Humanoids[nLoop].nStatus==HUMAN_ROAMING)
		{
			nHuman=nLoop;
		}
	}

	return(nHuman);
}

//-------------------------------------------------------------------------

BOOL	Human_CollisionCheck(FIXEDPT xXCo,FIXEDPT xYCo,FIXEDPT xWidth,FIXEDPT xHeight)
{
	int		nHit;
	BOOL	bHit;

	nHit = __FarFunction( Human_CollisionCheck_IWRAM, xXCo, xYCo, xWidth, xHeight);
	bHit = FALSE;
	if (nHit != HUMAN_NOT_PRESENT)
	{
		Human_Kill(nHit);
		bHit = TRUE;
	}

	return(bHit);
}

//-------------------------------------------------------------------------

uint	Human_CollisionCheck_IWRAM(u32 *pFuncAddr, FIXEDPT xXCo,FIXEDPT xYCo,FIXEDPT xWidth,FIXEDPT xHeight)
{
	int		nLoop;
	uint 	uCurrentHit;
	FIXEDPT	xClosestDist;
	FIXEDPT	xDist;

	uCurrentHit=HUMAN_NOT_PRESENT;
	xClosestDist=0;
	for (nLoop=0;nLoop<HUMAN_MAX_NUM;nLoop++)
	{
		if (Humanoids[nLoop].nStatus!=HUMAN_DEAD
			&& Collision(xXCo,xYCo,abs(xWidth),xHeight,
				Humanoids[nLoop].xXCo,Humanoids[nLoop].xYCo,GFX_HUMAN_WIDTH,GFX_HUMAN_HEIGHT))
		{
			xDist=abs(Humanoids[nLoop].xXCo-(xXCo-xWidth/2));
			if (uCurrentHit==HUMAN_NOT_PRESENT || xDist<xClosestDist)
			{
				xClosestDist=xDist;
				uCurrentHit=nLoop;
			}
		}
	}

	return(uCurrentHit);
}

//-------------------------------------------------------------------------

int		Human_NumAliveGet(void)
{
	return(nHumanNumAlive);
}

//-------------------------------------------------------------------------
