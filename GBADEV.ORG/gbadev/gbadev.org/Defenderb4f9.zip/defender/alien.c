//-------------------------------------------------------------------------

// Alien routines
// Rich Heasman July 1997 / May 2002

//-------------------------------------------------------------------------

#include 	"alien.h"

#include 	"gfx.h"
#include 	"gfxdata2.h"
#include 	"land.h"
#include 	"ship.h"
#include 	"human.h"
#include 	"collide.h"
#include 	"radar.h"
#include	"soundfx.h"
#include 	"rnd.h"
#include 	"scores.h"
#include 	"player.h"
#include 	"explode.h"
#include 	"bullet.h"
#include 	"mine.h"
#include 	"ship.h"
#include 	"sheet.h"
#include	"timer.h"
#include	"sprite.h"
#include	"debug.h"

//-------------------------------------------------------------------------

#define	ALIEN_MAX_NUM			40	   	// total maximum number of aliens

enum
{
	ALIEN_DEAD,
	ALIEN_DESTROY,
	ALIEN_SOLIDER,
	ALIEN_MUTANT,
	ALIEN_POD,
	ALIEN_SWARMER,
	ALIEN_MINER,
	ALIEN_BAITER
};

#define	ALIEN_NOT_HIT			-1

//-------------------------------------------------------------------------

enum
{
	SOLIDER_ROAMING,
	SOLIDER_DROPING,
	SOLIDER_RISING
};

#define	SOLIDER_NEW_NUM				5	   				// new soliders per wave
#define	SOLIDER_X_SPEED_MIN			(FIXEDPT)(FIXEDPT_UNITS*0.3)
#define	SOLIDER_X_SPEED_MAX			(FIXEDPT)(FIXEDPT_UNITS*1.5)
#define	SOLIDER_Y_SPEED_MIN			(FIXEDPT)(FIXEDPT_UNITS*0.15)
#define	SOLIDER_Y_SPEED_MAX			(FIXEDPT)(FIXEDPT_UNITS*0.4)
#define	SOLIDER_ANIM_RATE			(FIXEDPT)(FIXEDPT_UNITS*0.4)
#define	SOLIDER_ABOVE_LAND			(GFX_PLAY_HEIGHT/7)		// units pixels
#define	SOLIDER_PICKUP_CHANCE		13					// chance of picking up a human
#define	SOLIDER_FIRE_CHANCE			8
#define	SOLIDER_FIRE_AT_SHIP		15
#define	SOLIDER_FIRE_MIN_SPEED		(FIXEDPT)(FIXEDPT_UNITS*0.5)
#define	SOLIDER_FIRE_MAX_SPEED		(FIXEDPT)(FIXEDPT_UNITS*2.0)

//-------------------------------------------------------------------------

#define	MUTANT_ANIM_RATE			(FIXEDPT)(FIXEDPT_UNITS*0.4)
#define	MUTANT_X_SPEED_MIN			(FIXEDPT)(FIXEDPT_UNITS*2.5)
#define	MUTANT_X_SPEED_MAX			(FIXEDPT)(FIXEDPT_UNITS*4.5)
#define	MUTANT_Y_SPEED_MIN			(FIXEDPT)(FIXEDPT_UNITS*0.8)
#define	MUTANT_Y_SPEED_MAX			(FIXEDPT)(FIXEDPT_UNITS*2.2)
#define	MUTANT_Y_RND_MIN			(FIXEDPT)(FIXEDPT_UNITS*1.0)
#define	MUTANT_Y_RND_MAX			(FIXEDPT)(FIXEDPT_UNITS*3.0)
#define	MUTANT_FIRE_CHANCE			16
#define	MUTANT_FIRE_AT_SHIP			25
#define	MUTANT_FIRE_MIN_SPEED		(FIXEDPT)(FIXEDPT_UNITS*1.5)
#define	MUTANT_FIRE_MAX_SPEED		(FIXEDPT)(FIXEDPT_UNITS*3.0)

//-------------------------------------------------------------------------

#define	POD_X_SPEED_MIN				(FIXEDPT)(FIXEDPT_UNITS*0.01)
#define	POD_X_SPEED_MAX				(FIXEDPT)(FIXEDPT_UNITS*0.02)
#define	POD_Y_SPEED_MIN				(FIXEDPT)(FIXEDPT_UNITS*0.01)
#define	POD_Y_SPEED_MAX				(FIXEDPT)(FIXEDPT_UNITS*0.05)
#define	POD_ANIM_RATE				(FIXEDPT)(FIXEDPT_UNITS*0.025)
#define	POD_DIR_CHANGE_CHANCE		1			
								
//-------------------------------------------------------------------------

enum
{
	SWARMER_MOVING,
	SWARMER_TURNING
};

#define	SWARMER_NUM_PER_POD			4
#define	SWARMER_X_SPEED_MIN			(FIXEDPT)(FIXEDPT_UNITS*2.8)
#define	SWARMER_X_SPEED_MAX			(FIXEDPT)(FIXEDPT_UNITS*3.2)
#define	SWARMER_Y_SPEED_MIN			(FIXEDPT)(FIXEDPT_UNITS*1.0)
#define	SWARMER_Y_SPEED_MAX			(FIXEDPT)(FIXEDPT_UNITS*2.5)
#define	SWARMER_X_SWAP_CHANCE		20
#define	SWARMER_Y_SWAP_SPEED		(FIXEDPT)(FIXEDPT_UNITS*0.08)
#define	SWARMER_X_TURN_TIME			32

//-------------------------------------------------------------------------

#define	MINER_X_SPEED_MIN			(FIXEDPT)(FIXEDPT_UNITS*0.5)
#define	MINER_X_SPEED_MAX			(FIXEDPT)(FIXEDPT_UNITS*0.9)
#define	MINER_Y_SPEED_MAX			(FIXEDPT)(FIXEDPT_UNITS*2.0)
#define	MINER_Y_SWAP_MIN			(FIXEDPT)(FIXEDPT_UNITS*0.006)
#define	MINER_Y_SWAP_MAX			(FIXEDPT)(FIXEDPT_UNITS*0.015)
#define	MINER_ANIM_RATE				(FIXEDPT)(FIXEDPT_UNITS*0.1)
#define	MINER_NO_MINE_TIME			30
#define	MINER_MINE_CHANCE			4

//-------------------------------------------------------------------------

#define	BAITER_X_SPEED_MIN			(FIXEDPT)(FIXEDPT_UNITS*3.0)
#define	BAITER_X_SPEED_MAX			(FIXEDPT)(FIXEDPT_UNITS*8.0)
#define	BAITER_Y_SPEED_MIN			(FIXEDPT)(FIXEDPT_UNITS*1.5)
#define	BAITER_Y_SPEED_MAX			(FIXEDPT)(FIXEDPT_UNITS*2.9)
#define	BAITER_CHANGE_CHANCE		50
#define	BAITER_FIRE_CHANCE			20
#define	BAITER_FIRE_AT_SHIP			30
#define	BAITER_FIRE_MIN_SPEED		(FIXEDPT)(FIXEDPT_UNITS*4.0)
#define	BAITER_FIRE_MAX_SPEED		(FIXEDPT)(FIXEDPT_UNITS*7.0)

//-------------------------------------------------------------------------

typedef struct {
	SPRITE_TYPE	*pSprite;			// gfx object
	FIXEDPT		xXCo; 				// centre of alien object
	FIXEDPT		xYCo;	 			// Top edge of alien object
	FIXEDPT		xXSpeed; 			// alien X speed
	FIXEDPT		xYSpeed; 			// alien Y speed
	FIXEDPT		xAnim;				// animation frame count
	FIXEDPT		xWidth;				// width 
	FIXEDPT		xHeight; 			// height
	FIXEDPT		xSwap;	 			// speed of direction swap
	int			nType;				// type of alien (maybe dead)
	int			nStatus; 			// alien status
	int			nHuman;				// number of human a solider is after
	int			nRadar;				// radar entry
	int			nRadarGfx;			// radar gfx
	int			nScore;				// value of alien
	int			nExplode;			// type of explosion
	uint		Timer;				// general timer
} ALIEN_TYPE;

//-------------------------------------------------------------------------
 
static	ALIEN_TYPE	Aliens[ALIEN_MAX_NUM];
static	BOOL		bAliensAllDead;

//----------------------------------------------------------------------------

void	Alien_Init(void)
{
	int	nLoop;

	for (nLoop=0;nLoop<ALIEN_MAX_NUM;nLoop++)
	{
		Aliens[nLoop].nType=ALIEN_DEAD;
	}
}

//----------------------------------------------------------------------------

void	Alien_Clear(void)
{
	int	nLoop;

	for (nLoop=0;nLoop<ALIEN_MAX_NUM;nLoop++)
	{
		if (Aliens[nLoop].nType!=ALIEN_DEAD)
		{
			Aliens[nLoop].nType=ALIEN_DESTROY;
		}
	}
}

//----------------------------------------------------------------------------

void	Alien_Update(void)
{
	int		nLoop;
	int		nX;
	int		nY;

	bAliensAllDead=TRUE;
	for (nLoop=0;nLoop<ALIEN_MAX_NUM;nLoop++)
	{
		switch (Aliens[nLoop].nType)
		{
			case ALIEN_DEAD :
			{
				break;
			}
			case ALIEN_DESTROY :
			{
				Sprite_Destroy(Aliens[nLoop].pSprite);
				Radar_Remove(Aliens[nLoop].nRadar);
				Aliens[nLoop].nType=ALIEN_DEAD;
				break;
			}
			case ALIEN_SOLIDER :
			{
				Alien_SoliderMove(nLoop);
				if (Alien_ShipInRange(nLoop))
				{
					if (Rnd(1000)<Sheet_ModifiedInt(SOLIDER_FIRE_CHANCE,100))
					{
						if (Rnd(100)<Sheet_ModifiedInt(SOLIDER_FIRE_AT_SHIP,80))
						{
							Alien_AtShipShoot(nLoop,SOLIDER_FIRE_MAX_SPEED,SOLIDER_FIRE_MAX_SPEED);
						}
						else
						{
							Alien_RandomlyShoot(nLoop,SOLIDER_FIRE_MIN_SPEED,SOLIDER_FIRE_MAX_SPEED);
						}
					}
				}
				break;
			}
			case ALIEN_MUTANT :
			{
				Alien_MutantMove(nLoop);
				if (Alien_ShipInRange(nLoop))
				{
					if (Rnd(1000)<Sheet_ModifiedInt(MUTANT_FIRE_CHANCE,100))
					{
						if (Rnd(100)<Sheet_ModifiedInt(MUTANT_FIRE_AT_SHIP,80))
						{
							Alien_AtShipShoot(nLoop,MUTANT_FIRE_MIN_SPEED,MUTANT_FIRE_MAX_SPEED);
						}
						else
						{
							Alien_RandomlyShoot(nLoop,MUTANT_FIRE_MIN_SPEED,MUTANT_FIRE_MAX_SPEED);
						}
					}
				}
				break;
			}
			case ALIEN_POD :
			{
				Alien_PodMove(nLoop);
				break;
			}
			case ALIEN_SWARMER :
			{
				Alien_SwarmerMove(nLoop);
				break;
			}
			case ALIEN_MINER :
			{
				Alien_MinerMove(nLoop);
				if (Timer_Mature(&Aliens[nLoop].Timer) && Rnd(1000)<Sheet_ModifiedInt(MINER_MINE_CHANCE,100))
				{
					Mine_Create(Aliens[nLoop].xXCo,Aliens[nLoop].xYCo);
					Timer_Set(&Aliens[nLoop].Timer,MINER_NO_MINE_TIME);
				}
				break;
			}
			case ALIEN_BAITER :
			{
				Alien_BaiterMove(nLoop);
				if (Alien_ShipInRange(nLoop))
				{
					if (Rnd(1000)<Sheet_ModifiedInt(BAITER_FIRE_CHANCE,100))
					{
						if (Rnd(100)<Sheet_ModifiedInt(BAITER_FIRE_AT_SHIP,60))
						{
							Alien_AtShipShoot(nLoop,BAITER_FIRE_MIN_SPEED,BAITER_FIRE_MAX_SPEED);
						}
						else
						{
							Alien_RandomlyShoot(nLoop,BAITER_FIRE_MIN_SPEED,BAITER_FIRE_MAX_SPEED);
						}
					}
				}
				break;
			}
		}

		if (Aliens[nLoop].nType!=ALIEN_DEAD)
		{
			if (Aliens[nLoop].nRadar==RADAR_INVALID)
			{
				Aliens[nLoop].nRadar=Radar_Add(Aliens[nLoop].nRadarGfx);
			}
			if (Aliens[nLoop].nType!=ALIEN_BAITER)
			{
				bAliensAllDead=FALSE;
			}
			if (Ship_CollisionCheck(Aliens[nLoop].xXCo,Aliens[nLoop].xYCo,Aliens[nLoop].xWidth,Aliens[nLoop].xHeight) && !Ship_IsDead())
			{
		 		Ship_Kill();
		 		Alien_Kill(nLoop);
			}
			if (Ship_SmartBombActive() && (FixedToInt(Land_Boundary(Aliens[nLoop].xXCo-Ship_PosGet()))<GFX_SCREEN_PIXEL_WIDTH))
			{
				Alien_Kill(nLoop);
			}
			nX=FixedToScreenX(Land_Boundary(Aliens[nLoop].xXCo-Ship_PosGet()),Aliens[nLoop].xWidth);
			nY=FixedToScreenY(Aliens[nLoop].xYCo,0);
			Sprite_PositionSet(Aliens[nLoop].pSprite, nX, nY);
			Radar_Position(Aliens[nLoop].nRadar,Aliens[nLoop].xXCo,Aliens[nLoop].xYCo);
		}
	}
}

//----------------------------------------------------------------------------

BOOL	Alien_AllDead(void)
{
	return(bAliensAllDead);
}

//----------------------------------------------------------------------------

void	Alien_Start(void)
{
	int	nLoop;

	for (nLoop=0;nLoop<Sheet_NumOfPods();nLoop++)
	{
		Alien_Create(ALIEN_POD,IntToFixed(Rnd(GFX_PLAY_WIDTH_PIXELS)),FixedRnd(GFX_PLAY_HEIGHT-GFX_POD_HEIGHT*4,GFX_PLAY_HEIGHT));
	}
	for (nLoop=0;nLoop<Sheet_NumOfMiners();nLoop++)
	{
		Alien_Create(ALIEN_MINER,IntToFixed(Rnd(GFX_PLAY_WIDTH_PIXELS)),GFX_PLAY_HEIGHT-GFX_MINER_HEIGHT);
	}
}

//----------------------------------------------------------------------------

void	Alien_Create(int nType,FIXEDPT xXCo,FIXEDPT xYCo)
{
	int			nLoop;
	ALIEN_TYPE	*AlienPtr;

	nLoop=0;
	while (nLoop<ALIEN_MAX_NUM && Aliens[nLoop].nType!=ALIEN_DEAD)
	{
		nLoop++;
	}
	if (nLoop<ALIEN_MAX_NUM && Sprite_Available())
	{
		AlienPtr=&Aliens[nLoop];
		AlienPtr->nType=nType;
		AlienPtr->xXCo=xXCo;
		AlienPtr->xYCo=xYCo;
		AlienPtr->pSprite=Sprite_Create(0,0,GFX_SCREEN_PIXEL_HEIGHT);
		AlienPtr->xAnim=0;
		switch (nType)
		{
			case ALIEN_SOLIDER :
			{
				AlienPtr->nStatus=SOLIDER_ROAMING;
				AlienPtr->xXSpeed=SHIP_RANDOM_DIR*Sheet_ModifiedFixed(FixedRnd(SOLIDER_X_SPEED_MIN,SOLIDER_X_SPEED_MAX),80);
				AlienPtr->xYSpeed=Sheet_ModifiedFixed(FixedRnd(SOLIDER_Y_SPEED_MIN,SOLIDER_Y_SPEED_MAX),60);
				AlienPtr->xWidth=GFX_SOLIDER_WIDTH;
				AlienPtr->xHeight=GFX_SOLIDER_HEIGHT;
				AlienPtr->nHuman=0;
				AlienPtr->nRadar=RADAR_INVALID;
				AlienPtr->nRadarGfx=GFX_GREEN_RADAR;
				AlienPtr->nScore=SCORE_SOLIDER;
				AlienPtr->nExplode=EXPLODE_SOLIDER;
				break;
			}
			case ALIEN_MUTANT :
			{
				AlienPtr->xXSpeed=Sheet_ModifiedFixed(FixedRnd(MUTANT_X_SPEED_MIN,MUTANT_X_SPEED_MAX),40);
				AlienPtr->xYSpeed=Sheet_ModifiedFixed(FixedRnd(MUTANT_Y_SPEED_MIN,MUTANT_Y_SPEED_MAX),20);
				AlienPtr->xWidth=GFX_MUTANT_WIDTH;
				AlienPtr->xHeight=GFX_MUTANT_HEIGHT;
				AlienPtr->nRadar=RADAR_INVALID;
				AlienPtr->nRadarGfx=GFX_BROWN_RADAR;
				AlienPtr->nScore=SCORE_MUTANT;
				AlienPtr->nExplode=EXPLODE_MUTANT;
				break;
			}
			case ALIEN_POD :
			{
				AlienPtr->xXSpeed=SHIP_RANDOM_DIR*FixedRnd(POD_X_SPEED_MIN,POD_X_SPEED_MAX);
				AlienPtr->xYSpeed=-FixedRnd(POD_Y_SPEED_MIN,POD_Y_SPEED_MAX);
				AlienPtr->xWidth=GFX_POD_WIDTH;
				AlienPtr->xHeight=GFX_POD_HEIGHT;
				AlienPtr->nRadar=RADAR_INVALID;
				AlienPtr->nRadarGfx=GFX_PINK_RADAR;
				AlienPtr->nScore=SCORE_POD;
				AlienPtr->nExplode=EXPLODE_POD;
				break;
			}
			case ALIEN_SWARMER :
			{
				AlienPtr->nStatus=SWARMER_MOVING;
				AlienPtr->xXSpeed=SHIP_RANDOM_DIR*FixedRnd(SWARMER_X_SPEED_MIN,SWARMER_X_SPEED_MAX);
				AlienPtr->xYSpeed=SHIP_RANDOM_DIR*FixedRnd(SWARMER_Y_SPEED_MIN,SWARMER_Y_SPEED_MAX);
				AlienPtr->xSwap=SWARMER_Y_SWAP_SPEED;
				AlienPtr->xWidth=GFX_SWARMER_WIDTH;
				AlienPtr->xHeight=GFX_SWARMER_HEIGHT;
				AlienPtr->nRadar=RADAR_INVALID;
				AlienPtr->nRadarGfx=GFX_RED_RADAR;
				AlienPtr->nScore=SCORE_SWARMER;
				AlienPtr->nExplode=EXPLODE_SWARMER;
				break;
			}
			case ALIEN_MINER :
			{
				AlienPtr->xXSpeed=SHIP_RANDOM_DIR*Sheet_ModifiedFixed(FixedRnd(MINER_X_SPEED_MIN,MINER_X_SPEED_MAX),60);
				AlienPtr->xYSpeed=0;
				AlienPtr->xSwap=FixedRnd(MINER_Y_SWAP_MIN,MINER_Y_SWAP_MAX);
				AlienPtr->xWidth=GFX_MINER_WIDTH;
				AlienPtr->xHeight=GFX_MINER_HEIGHT;
				AlienPtr->nRadar=RADAR_INVALID;
				AlienPtr->nRadarGfx=GFX_BLUE_RADAR;
				AlienPtr->nScore=SCORE_MINER;
				AlienPtr->nExplode=EXPLODE_MINER;
				Timer_Set(&AlienPtr->Timer,0);
				break;
			}
			case ALIEN_BAITER :
			{
				AlienPtr->xXSpeed=FixedRnd(BAITER_X_SPEED_MIN,BAITER_X_SPEED_MAX);
				AlienPtr->xYSpeed=FixedRnd(BAITER_Y_SPEED_MIN,BAITER_Y_SPEED_MAX);
				AlienPtr->xWidth=GFX_BAITER_WIDTH;
				AlienPtr->xHeight=GFX_BAITER_HEIGHT;
				AlienPtr->nRadar=RADAR_INVALID;
				AlienPtr->nRadarGfx=GFX_YELLOW_RADAR;
				AlienPtr->nScore=SCORE_BAITER;
				AlienPtr->nExplode=EXPLODE_BAITER;
				break;
			}
		}
	}
}

//----------------------------------------------------------------------------

void	Alien_SolidersNew(void)
{
	int	nLoop;

	for (nLoop=0;nLoop<Sheet_ModifiedInt(SOLIDER_NEW_NUM,50);nLoop++)
	{
		Alien_Create(ALIEN_SOLIDER,IntToFixed(Rnd(GFX_PLAY_WIDTH_PIXELS)),GFX_PLAY_HEIGHT);
	}
}

//----------------------------------------------------------------------------

void	Alien_BaiterNew(void)
{
	Alien_Create(ALIEN_BAITER,IntToFixed(Rnd(GFX_PLAY_WIDTH_PIXELS)),GFX_PLAY_HEIGHT-GFX_BAITER_HEIGHT);
  	SoundFX_Make(SOUNDFX_CHANNEL_A, SOUNDFX_ZAPPY);
}

//------------------------------------------------------------------------

void	Alien_BaitersKill(void)
{
	int	nLoop;

	for (nLoop=0;nLoop<ALIEN_MAX_NUM;nLoop++)
	{
		if (Aliens[nLoop].nType==ALIEN_BAITER)
		{
			Aliens[nLoop].nType=ALIEN_DESTROY;
		}
	}
}

//------------------------------------------------------------------------
void	Alien_SoliderMove(int nNum)
{
	int	nHumanPos;

	switch	(Aliens[nNum].nStatus)
	{
		case SOLIDER_ROAMING :
		{
			Aliens[nNum].xXCo+=Aliens[nNum].xXSpeed;
			Aliens[nNum].xXCo=Land_Boundary(Aliens[nNum].xXCo);

			if (Aliens[nNum].xYCo>Land_HeightGet(Aliens[nNum].xXCo)+SOLIDER_ABOVE_LAND)
			{
				Aliens[nNum].xYCo-=Aliens[nNum].xYSpeed;
			}
			if (Aliens[nNum].xYCo<Land_HeightGet(Aliens[nNum].xXCo)+SOLIDER_ABOVE_LAND)
			{
				Aliens[nNum].xYCo+=Aliens[nNum].xYSpeed;
			}
	
			nHumanPos=Human_Check(Aliens[nNum].xXCo);
			if (nHumanPos!=HUMAN_NOT_PRESENT && Rnd(100)<Sheet_ModifiedInt(SOLIDER_PICKUP_CHANCE,250))
			{
				Aliens[nNum].nStatus=SOLIDER_DROPING;
				Aliens[nNum].nHuman=nHumanPos;
				Human_Claim(Aliens[nNum].nHuman,nNum);
			}
			break;
		}
		case SOLIDER_DROPING :
		{
			Aliens[nNum].xYCo-=Aliens[nNum].xYSpeed;
			if (Human_Status(Aliens[nNum].nHuman)!=HUMAN_WAITING)
			{
				Aliens[nNum].nStatus=SOLIDER_ROAMING;
			}
			else
			{
				if (Aliens[nNum].xYCo-GFX_SOLIDER_HEIGHT<=Human_Height(Aliens[nNum].nHuman))
				{
					Aliens[nNum].nStatus=SOLIDER_RISING;
					Human_Pickup(Aliens[nNum].nHuman,nNum);
				}
			}
			break;
		}
		case SOLIDER_RISING :
		{
			Aliens[nNum].xYCo+=Aliens[nNum].xYSpeed;

			if (Aliens[nNum].xYCo>=GFX_PLAY_HEIGHT-FIXEDPT_UNITS)
			{
				if (Human_Status(Aliens[nNum].nHuman)==HUMAN_CAPTURED)
				{
					Human_Kill(Aliens[nNum].nHuman);
					Alien_Create(ALIEN_MUTANT,Aliens[nNum].xXCo,Aliens[nNum].xYCo);
					Aliens[nNum].nType=ALIEN_DESTROY;
					SoundFX_Make(SOUNDFX_CHANNEL_A, SOUNDFX_ZAPPY);
				}
				else
				{
					Aliens[nNum].nStatus=SOLIDER_ROAMING;
				}
			}
			break;
		}
	}
	if (Human_NumAliveGet()==0 && !Ship_IsDead())
	{
		Alien_Create(ALIEN_MUTANT,Aliens[nNum].xXCo,Aliens[nNum].xYCo);
		Aliens[nNum].nType=ALIEN_DESTROY;
	}

	Aliens[nNum].xAnim+=SOLIDER_ANIM_RATE;
	if (Aliens[nNum].xAnim>=IntToFixed(GFX_SOLIDER_FRAMES))
	{
		Aliens[nNum].xAnim=0;
	}
	Sprite_FrameSet(Aliens[nNum].pSprite,GFX_SOLIDER+FixedToInt(Aliens[nNum].xAnim));
}

//------------------------------------------------------------------------

void	Alien_MutantMove(int nNum)
{
	FIXEDPT	xXDiff,xYDiff;
	FIXEDPT	xXAdd,xYAdd;

	xXAdd=Aliens[nNum].xXSpeed;
	xYAdd=Aliens[nNum].xYSpeed;
	if (!Ship_IsDead())
	{
		xXDiff=Land_Boundary(Aliens[nNum].xXCo-Ship_PosXGet());
		xYDiff=Aliens[nNum].xYCo-Ship_PosYGet();
		if (xXDiff>=GFX_PLAY_WIDTH/2)
		{
			xXDiff=xXDiff-GFX_PLAY_WIDTH;
		}
		// stop them getting level when still distant
		if (FixedMultiply(abs(xXDiff),xYAdd) > FixedMultiply(abs(xYDiff),xXAdd))
		{
			xYAdd=0;
		}
		if (xXDiff>0)
		{
		 	xXAdd=-xXAdd;
		}
		if (xYDiff>0)
		{
			xYAdd=-xYAdd;
		}
		if (Aliens[nNum].xYCo+xYAdd<=Aliens[nNum].xHeight
		 || Aliens[nNum].xYCo+xYAdd>=GFX_PLAY_HEIGHT)
		{
			xYAdd=0;
		}
	}
	else
	{
		xYAdd=0;
		if (nNum%2)	xXAdd=-xXAdd;
	}
	xYAdd+=SHIP_RANDOM_DIR*FixedRnd(MUTANT_Y_RND_MIN,MUTANT_Y_RND_MAX);
	if (Aliens[nNum].xYCo+xYAdd<=Aliens[nNum].xHeight||Aliens[nNum].xYCo+xYAdd>=GFX_PLAY_HEIGHT)
	{
		xYAdd=0;
	}
	Aliens[nNum].xYCo+=xYAdd;
	Aliens[nNum].xXCo+=xXAdd;
	Aliens[nNum].xXCo=Land_Boundary(Aliens[nNum].xXCo);
	Aliens[nNum].xAnim+=MUTANT_ANIM_RATE;
	if (Aliens[nNum].xAnim>=IntToFixed(GFX_MUTANT_FRAMES))
	{
		Aliens[nNum].xAnim=0;
	}
	Sprite_FrameSet(Aliens[nNum].pSprite,GFX_MUTANT+FixedToInt(Aliens[nNum].xAnim));
}

//------------------------------------------------------------------------

void	Alien_PodMove(int nNum)
{
	Aliens[nNum].xXCo+=Aliens[nNum].xXSpeed;
	Aliens[nNum].xXCo=Land_Boundary(Aliens[nNum].xXCo);
	if (Aliens[nNum].xYCo+Aliens[nNum].xYSpeed>GFX_PLAY_HEIGHT
	 || Aliens[nNum].xYCo+Aliens[nNum].xYSpeed<=GFX_POD_HEIGHT
	 || Rnd(1000)<POD_DIR_CHANGE_CHANCE)
	{
		Aliens[nNum].xYSpeed=-Aliens[nNum].xYSpeed;
	}
	Aliens[nNum].xYCo+=Aliens[nNum].xYSpeed;
	Aliens[nNum].xAnim+=POD_ANIM_RATE;
	if (Aliens[nNum].xAnim>=IntToFixed(GFX_POD_FRAMES))
	{
		Aliens[nNum].xAnim=0;
	}
	Sprite_FrameSet(Aliens[nNum].pSprite,GFX_POD+FixedToInt(Aliens[nNum].xAnim));
}

//------------------------------------------------------------------------

void	Alien_SwarmerMove(int nNum)
{
	FIXEDPT	xXDiff;

	if (Aliens[nNum].nStatus==SWARMER_TURNING)
	{
		Aliens[nNum].xXCo+=Aliens[nNum].xXSpeed/(SWARMER_X_TURN_TIME/2)*(SWARMER_X_TURN_TIME/2-Aliens[nNum].xAnim);
		Aliens[nNum].xAnim++;
		if (Aliens[nNum].xAnim>=SWARMER_X_TURN_TIME)
		{
			Aliens[nNum].xXSpeed=-Aliens[nNum].xXSpeed;
			Aliens[nNum].nStatus=SWARMER_MOVING;
		}
	}
	else
	{
		if (!Ship_IsDead())
		{
			xXDiff=Land_Boundary(Aliens[nNum].xXCo-Ship_PosXGet());
			if (xXDiff>=GFX_PLAY_WIDTH/2)
			{
				xXDiff=xXDiff-GFX_PLAY_WIDTH;
			}
			if ((xXDiff>0 && Aliens[nNum].xXSpeed>0)
	 	 	|| (xXDiff<0 && Aliens[nNum].xXSpeed<0))
			{
				if (Rnd(100)<SWARMER_X_SWAP_CHANCE)
				{
					Aliens[nNum].xAnim=0;
					Aliens[nNum].nStatus=SWARMER_TURNING;
				}
			}
		}
		Aliens[nNum].xXCo+=Aliens[nNum].xXSpeed;
	}
	Aliens[nNum].xXCo=Land_Boundary(Aliens[nNum].xXCo);

	if (Aliens[nNum].xYCo-Ship_PosYGet()>0)
	{
		if (Aliens[nNum].xYSpeed>-SWARMER_Y_SPEED_MAX)
		{
			Aliens[nNum].xYSpeed-=Aliens[nNum].xSwap;
		}
	}
	else
	{
		if (Aliens[nNum].xYSpeed<SWARMER_Y_SPEED_MAX)
		{
			Aliens[nNum].xYSpeed+=Aliens[nNum].xSwap;
		}
	}
	if (Aliens[nNum].xYCo+Aliens[nNum].xYSpeed>GFX_PLAY_HEIGHT
	 || Aliens[nNum].xYCo+Aliens[nNum].xYSpeed<=Aliens[nNum].xHeight)
	{
		Aliens[nNum].xYSpeed=-Aliens[nNum].xYSpeed;
	}
	Aliens[nNum].xYCo+=Aliens[nNum].xYSpeed;
	Sprite_FrameSet(Aliens[nNum].pSprite,GFX_SWARMER);
}

//------------------------------------------------------------------------

void	Alien_MinerMove(int nNum)
{
	FIXEDPT	xYSpeedMax;

	xYSpeedMax=Sheet_ModifiedInt(MINER_Y_SPEED_MAX,60);
	Aliens[nNum].xXCo+=Aliens[nNum].xXSpeed;
	Aliens[nNum].xXCo=Land_Boundary(Aliens[nNum].xXCo);

	if (Aliens[nNum].xYCo-GFX_PLAY_HEIGHT/2>0)
	{
		if (Aliens[nNum].xYSpeed>-xYSpeedMax)
		{
			Aliens[nNum].xYSpeed-=Aliens[nNum].xSwap;
		}
	}
	else
	{
		if (Aliens[nNum].xYSpeed<xYSpeedMax)
		{
			Aliens[nNum].xYSpeed+=Aliens[nNum].xSwap;
		}
	}
	if (Aliens[nNum].xYCo+Aliens[nNum].xYSpeed>GFX_PLAY_HEIGHT
	 || Aliens[nNum].xYCo+Aliens[nNum].xYSpeed<=Aliens[nNum].xHeight)
	{
		Aliens[nNum].xYSpeed=-Aliens[nNum].xYSpeed;
	}
	Aliens[nNum].xYCo+=Aliens[nNum].xYSpeed;

	Aliens[nNum].xAnim+=MINER_ANIM_RATE;
	if (Aliens[nNum].xAnim>=IntToFixed(GFX_MINER_FRAMES))
	{
		Aliens[nNum].xAnim=0;
	}
	Sprite_FrameSet(Aliens[nNum].pSprite,GFX_MINER+FixedToInt(Aliens[nNum].xAnim));
}

//------------------------------------------------------------------------

void	Alien_BaiterMove(int nNum)
{
	FIXEDPT	xXDiff,xYDiff;

	if (Rnd(1000)<BAITER_CHANGE_CHANCE
	 || Aliens[nNum].xYCo+Aliens[nNum].xYSpeed<=Aliens[nNum].xHeight||Aliens[nNum].xYCo+Aliens[nNum].xYSpeed>=GFX_PLAY_HEIGHT)
	{
		Aliens[nNum].xXSpeed=Sheet_ModifiedFixed(FixedRnd(BAITER_X_SPEED_MIN,BAITER_X_SPEED_MAX),25);
		Aliens[nNum].xYSpeed=Sheet_ModifiedFixed(FixedRnd(BAITER_Y_SPEED_MIN,BAITER_Y_SPEED_MAX),20);
		xXDiff=Land_Boundary(Aliens[nNum].xXCo-Ship_PosXGet());
		xYDiff=Aliens[nNum].xYCo-Ship_PosYGet();
		if (xXDiff>=GFX_PLAY_WIDTH/2)
		{
			xXDiff=xXDiff-GFX_PLAY_WIDTH;
		}
		if (xXDiff>0)
		{
			Aliens[nNum].xXSpeed=-Aliens[nNum].xXSpeed;
		}
		if (xYDiff>0)
		{
			Aliens[nNum].xYSpeed=-Aliens[nNum].xYSpeed;
		}
		if (Ship_IsDead())
		{
			Aliens[nNum].xXSpeed*=SHIP_RANDOM_DIR;
		}
	}

	Aliens[nNum].xYCo+=Aliens[nNum].xYSpeed;
	Aliens[nNum].xXCo+=Aliens[nNum].xXSpeed;
	Aliens[nNum].xXCo=Land_Boundary(Aliens[nNum].xXCo);
	Sprite_FrameSet(Aliens[nNum].pSprite,GFX_BAITER);
}

//------------------------------------------------------------------------

FIXEDPT	Alien_HeightGet(int nAlien)
{
	return(Aliens[nAlien].xYCo);
}

//------------------------------------------------------------------------

BOOL	Alien_CollisionCheck(FIXEDPT xXCo,FIXEDPT xYCo,FIXEDPT xWidth,FIXEDPT xHeight)
{
	int		nHit;
	BOOL	bHit;

	nHit = __FarFunction(Alien_CollisionCheck_IWRAM, xXCo, xYCo, xWidth, xHeight);
	bHit = FALSE;
	if (nHit != ALIEN_NOT_HIT)
	{	bHit = TRUE;
		Alien_Kill(nHit);
	}

	return(bHit);
}

//------------------------------------------------------------------------

uint	Alien_CollisionCheck_IWRAM(u32 *pFuncAddr, FIXEDPT xXCo,FIXEDPT xYCo,FIXEDPT xWidth,FIXEDPT xHeight)
{
	int		nLoop;
	uint	uCurrentHit;
	FIXEDPT	xClosestDist;
	FIXEDPT	xDist;

	uCurrentHit=ALIEN_NOT_HIT;
	xClosestDist=0;
	for (nLoop=0;nLoop<ALIEN_MAX_NUM;nLoop++)
	{
		if (Aliens[nLoop].nType!=ALIEN_DEAD)
		{
			if (Collision(xXCo,xYCo,abs(xWidth),xHeight,
				Aliens[nLoop].xXCo,Aliens[nLoop].xYCo,Aliens[nLoop].xWidth,Aliens[nLoop].xHeight))
			{
				xDist=abs(Aliens[nLoop].xXCo-(xXCo-xWidth/2));
				if (uCurrentHit==ALIEN_NOT_HIT || xDist<xClosestDist)
				{
					xClosestDist=xDist;
					uCurrentHit=nLoop;
				}
			}
		}
	}

	return(uCurrentHit);
}

//------------------------------------------------------------------------

void	Alien_Kill(int nNum)
{
	int	nLoop;

	if (Aliens[nNum].nType==ALIEN_POD && !Ship_SmartBombActive())
	{
		for (nLoop=0;nLoop<Sheet_ModifiedInt(SWARMER_NUM_PER_POD,50);nLoop++)
		{
			Alien_Create(ALIEN_SWARMER,Aliens[nNum].xXCo,Aliens[nNum].xYCo);
		}
	}

	if (Aliens[nNum].nType==ALIEN_POD || Aliens[nNum].nType==ALIEN_MINER)
	{
		SoundFX_Make(SOUNDFX_CHANNEL_A, SOUNDFX_BOOM);
	}
	else
	{
		SoundFX_Make(SOUNDFX_CHANNEL_A, SOUNDFX_FIZPLODE);
	}

	Aliens[nNum].nType=ALIEN_DESTROY;
	if (Aliens[nNum].nStatus==SOLIDER_RISING
	 && Human_Status(Aliens[nNum].nHuman)==HUMAN_CAPTURED)
	{
		Human_Drop(Aliens[nNum].nHuman);
	}
	Player_ScoreAdd(Aliens[nNum].nScore);
	Explode_Make(Aliens[nNum].nExplode,Aliens[nNum].xXCo,Aliens[nNum].xYCo-Aliens[nNum].xHeight/2);
}

//------------------------------------------------------------------------

BOOL	Alien_ShipInRange(int nNum)
{
	FIXEDPT	xXDiff;
	BOOL	bInRange;

	bInRange=FALSE;
	xXDiff=Land_Boundary(Aliens[nNum].xXCo-Ship_PosXGet());
	if (xXDiff>=GFX_PLAY_WIDTH/2)
	{
		xXDiff=xXDiff-GFX_PLAY_WIDTH;
	}
	if (abs(xXDiff)<GFX_PLAY_SCREEN_WIDTH)
	{
		bInRange=TRUE;
	}

	return(bInRange);
}

//------------------------------------------------------------------------

void	Alien_RandomlyShoot(int nNum,FIXEDPT xMin,FIXEDPT xMax)
{
	FIXEDPT	xXSpeed,xYSpeed;

	xXSpeed=SHIP_RANDOM_DIR*Sheet_ModifiedFixed(FixedRnd(xMin,xMax),40);
	xYSpeed=SHIP_RANDOM_DIR*Sheet_ModifiedFixed(FixedRnd(xMin,xMax),40);
	Bullet_Create(Aliens[nNum].xXCo,Aliens[nNum].xYCo,xXSpeed,xYSpeed);
}

//------------------------------------------------------------------------

void	Alien_AtShipShoot(int nNum,FIXEDPT xMin,FIXEDPT xMax)
{
	FIXEDPT	xXDiff,xYDiff;
	FIXEDPT	xSpeed;
	FIXEDPT	xXSpeed,xYSpeed;
	int		nXDiff, nYDiff;

	xXDiff=Land_Boundary(Aliens[nNum].xXCo-Ship_PosXGet());
	if (xXDiff>=GFX_PLAY_WIDTH/2)
	{
		xXDiff=xXDiff-GFX_PLAY_WIDTH;
	}
	xYDiff=Aliens[nNum].xYCo-Ship_PosYGet();
	xSpeed=Sheet_ModifiedFixed(FixedRnd(xMin,xMax),40);

	xYSpeed = xSpeed;
	xXSpeed = xSpeed;

	nXDiff = abs(FixedToInt(xXDiff));
	nYDiff = abs(FixedToInt(xYDiff));
	if (nXDiff > nYDiff)
	{
		// divs - only happen once when alien first shoots at ship
		if (xXDiff > 0)
		{
			xXSpeed = -xSpeed;
		}
		if (nXDiff != 0)
		{
			xYSpeed = -FixedToInt(xYDiff) * xSpeed / nXDiff;
		}
	}
	else
	{
		if (xYDiff > 0)
		{
			xYSpeed = -xSpeed;
		}
		if (nYDiff != 0)
		{
			xXSpeed = -FixedToInt(xXDiff) * xSpeed / nYDiff;
 		}
	}

	Bullet_Create(Aliens[nNum].xXCo,Aliens[nNum].xYCo,xXSpeed,xYSpeed);
}

//------------------------------------------------------------------------

