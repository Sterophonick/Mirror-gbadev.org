//------------------------------------------------------------------------------------

// vblank
// Rich Heasman April 2002

//------------------------------------------------------------------------------------

#include "gba.h"
#include "vblank.h"

#include "interrupt.h"

//------------------------------------------------------------------------------------

typedef struct
{
	uint	uVBlankStatus:1;			// 0 during draw, 1 during VBlank
	uint	uHBlankStatus:1;			// 0 during draw, 1 during HBlank
	uint	uVCountYTriggerStatus:1; 	// 1 after an interrupt
	uint	uVBlankIntEnable:1;			// Enable VBlank interrupt
	uint	uHBlankIntEnable:1;			// Enable HBlank interrupt
	uint	uVCountYTriggerIntEnable:1;	// Enable VCount Y trigger interrupt
	uint	uUnused:2;
	uint	uVCountYTrigger:8;			// VCount trigger value
} VBLANK_TYPE;

//------------------------------------------------------------------------------------

static volatile	uint	uFrameCounter;
static VBLANK_TYPE		VBlankControl;

//------------------------------------------------------------------------------------

void	VBlank_Init(void)
{
	uFrameCounter = 0;
    Interrupt_HandlerSet(INTERRUPT_TYPE_VBL, VBlank_Handler);

	VBlankControl.uVBlankIntEnable = 1;
	VBlankControl.uHBlankIntEnable = 0;
	VBlankControl.uVCountYTriggerIntEnable = 0;

	R_DISSTAT = *(u16 *) &VBlankControl;
}

//------------------------------------------------------------------------------------

void 	VBlank_Handler(void)
{
	uFrameCounter++;
}

//------------------------------------------------------------------------------------

void 	VBlank_Wait(void)
{
	uint	uFrameCounterPrevious;

	uFrameCounterPrevious =	uFrameCounter;
	while (	uFrameCounterPrevious == uFrameCounter);
}

//------------------------------------------------------------------------------------

uint	VBlank_FrameCounterGet(void)
{
	return(uFrameCounter);
}

//------------------------------------------------------------------------------------
