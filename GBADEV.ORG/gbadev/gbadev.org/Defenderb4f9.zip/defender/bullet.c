//-------------------------------------------------------------------------

// Bullet routines
// Rich Heasman July 1997 / May 2002

//-------------------------------------------------------------------------

#include 	"bullet.h"

#include 	"gfx.h"
#include 	"gfxdata2.h"
#include 	"ship.h"
#include 	"land.h"
#include 	"sprite.h"
#include 	"debug.h"

//-------------------------------------------------------------------------

#define	BULLET_MAX_NUM			12 		// total maximum number of bullets
#define	BULLET_LIFE_LEN			(3*60)	// time bullets last

enum
{
	BULLET_DEAD,
	BULLET_DESTROY,
	BULLET_MOVING
};

typedef struct {
	int			nStatus; 			// Bullet status
	SPRITE_TYPE	*pSprite;			// gfx object
	FIXEDPT		xXCo; 				// centre of bullet object
	FIXEDPT		xYCo;	 			// Top edge of bullet object
	FIXEDPT		xXSpeed; 			// Bullet X speed
	FIXEDPT		xYSpeed; 			// Bullet Y speed
	int			nCount;				// length of life of bullet
} BULLET_TYPE;

static	BULLET_TYPE	Bullet[BULLET_MAX_NUM];

//----------------------------------------------------------------------------

void	Bullet_Init(void)
{
	int	nLoop;

	for (nLoop=0;nLoop<BULLET_MAX_NUM;nLoop++)
	{
		Bullet[nLoop].nStatus=BULLET_DEAD;
	}
}

//----------------------------------------------------------------------------

void	Bullet_Clear(void)
{
	int	nLoop;

	for (nLoop=0;nLoop<BULLET_MAX_NUM;nLoop++)
	{
		if (Bullet[nLoop].nStatus!=BULLET_DEAD)
		{
			Bullet[nLoop].nStatus=BULLET_DESTROY;
		}
	}
}

//----------------------------------------------------------------------------

void	Bullet_Update(void)
{
	int		nLoop;
	int		nX;
	int		nY;

	for (nLoop=0;nLoop<BULLET_MAX_NUM;nLoop++)
	{
		switch (Bullet[nLoop].nStatus)
		{
			case BULLET_DEAD :
			{
				break;
			}
			case BULLET_DESTROY :
			{
				Sprite_Destroy(Bullet[nLoop].pSprite);
				Bullet[nLoop].nStatus=BULLET_DEAD;
				break;
			}
			case BULLET_MOVING :
			{
				Bullet[nLoop].nCount++;
				Bullet[nLoop].xXCo+=Bullet[nLoop].xXSpeed;
				Bullet[nLoop].xYCo+=Bullet[nLoop].xYSpeed;
				if (Ship_CollisionCheck(Bullet[nLoop].xXCo,Bullet[nLoop].xYCo,GFX_BULLET_WIDTH,GFX_BULLET_HEIGHT) && !Ship_IsDead())
				{
					Ship_Kill();
				}
				nX=FixedToScreenX(Land_Boundary(Bullet[nLoop].xXCo-Ship_PosGet()),GFX_BULLET_WIDTH);
				nY=FixedToScreenY(Bullet[nLoop].xYCo,0);
				Sprite_PositionSet(Bullet[nLoop].pSprite, nX, nY);

				if (Bullet[nLoop].nCount>BULLET_LIFE_LEN || Bullet[nLoop].xYCo>GFX_PLAY_HEIGHT || Bullet[nLoop].xYCo<0)
				{
					Bullet[nLoop].nStatus=BULLET_DESTROY;
				}
				break;
			}
		}
	}
}

//----------------------------------------------------------------------------

void	Bullet_Create(FIXEDPT xXCo,FIXEDPT xYCo,FIXEDPT xXSpeed,FIXEDPT xYSpeed)
{
	int			nLoop;
	BULLET_TYPE	*BulletPtr;

	nLoop=0;
	while (nLoop<BULLET_MAX_NUM && Bullet[nLoop].nStatus!=BULLET_DEAD)
	{
		nLoop++;
	}
	if (nLoop<BULLET_MAX_NUM && Sprite_Available())
	{
		BulletPtr=&Bullet[nLoop];
		BulletPtr->nStatus=BULLET_MOVING;
		BulletPtr->pSprite=Sprite_Create(GFX_BULLET,0,GFX_SCREEN_PIXEL_HEIGHT);
		BulletPtr->xXCo=xXCo;
		BulletPtr->xYCo=xYCo;
		BulletPtr->xXSpeed=xXSpeed;
		BulletPtr->xYSpeed=xYSpeed;
		BulletPtr->nCount=0;
	}
}

//----------------------------------------------------------------------------


