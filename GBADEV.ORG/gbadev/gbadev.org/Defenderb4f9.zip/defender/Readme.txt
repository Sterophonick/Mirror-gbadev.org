
----------------
Defender Advance
----------------

v1.0 - 31 May 2002 - First Version

by Rich Heasman (richardheasman@hotmail.com)

This game is freeware and is an unoffical conversion that is not endorsed

---------------------------

What? Get highest score
How? Dpad - Move; A - Fire; R - Smart, L - Hyper, Select + Start - Dev menu

---------------------------

Thanks to:

Williams        : for Defender
Tubooboo        : for HAM (v1.40)
Jeff Frohwein   : for MultiBoot, crt0, lnkscript, FAQ, b2x (v1.7)
Forgotten       : for VisualBoyAdvance
Tom Happ        : for Cowbite spec
Markus          : for Gfx2Gba (v0.10)
Credo			: for Gbarm	(v1.0)
Staringmonkey	: for pixel and sound examples
Dark Fader		: for sound examples
gbadev.org		: for various info

---------------------------




