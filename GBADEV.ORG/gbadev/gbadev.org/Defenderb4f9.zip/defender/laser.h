//-------------------------------------------------------------------------

// Laser routines
// Rich Heasman July 1997 / May 2002

//-------------------------------------------------------------------------

#include	"fixedpt.h"

//-------------------------------------------------------------------------

void	Laser_Clear(void);
void	Laser_Fire(FIXEDPT xXCo,FIXEDPT xYCo,int nDir);
void	Laser_Render(void);
void	Laser_Plot(int nLoop,int nColour);

//-------------------------------------------------------------------------
