//-------------------------------------------------------------------------

// Land routines
// Rich Heasman July 1997 / May 2002

//-------------------------------------------------------------------------

#include	"gba.h"
#include	"fixedpt.h"

//-------------------------------------------------------------------------

void		Land_Init(void);
void		Land_New(void);
void		Land_Plot(u32 *pFuncAddr,int nLandPos) CODE_IN_IWRAM;
void		Land_Update(FIXEDPT xPos);
void		Land_Render(void);
FIXEDPT		Land_Boundary(FIXEDPT xPos);
FIXEDPT		Land_HeightGet(FIXEDPT xPos);

//-------------------------------------------------------------------------
