//-------------------------------------------------------------------------

// Collision routines
// Rich Heasman July 1997 / May 2002

//-------------------------------------------------------------------------

#include 	"collide.h"

#include 	"gfx.h"

//-------------------------------------------------------------------------

BOOL	Collision(FIXEDPT xXCo1,FIXEDPT xYCo1,FIXEDPT xWidth1,FIXEDPT xHeight1,
 				  FIXEDPT xXCo2,FIXEDPT xYCo2,FIXEDPT xWidth2,FIXEDPT xHeight2)
{
	BOOL	bResult;
		
	bResult=FALSE;
	if (xYCo1-xHeight1<xYCo2 && xYCo1>xYCo2-xHeight2)
	{
		if (xXCo2-xXCo1+GFX_PLAY_WIDTH<GFX_PLAY_SCREEN_WIDTH)
		{
			xXCo1-=GFX_PLAY_WIDTH;
		}
		if (xXCo1-xXCo2+GFX_PLAY_WIDTH<GFX_PLAY_SCREEN_WIDTH)
		{
			xXCo2-=GFX_PLAY_WIDTH;
		}
		if (xXCo1+xWidth1/2>xXCo2-xWidth2/2
		 && xXCo1-xWidth1/2<xXCo2+xWidth2/2)
		{
			bResult=TRUE;
		}
	}

	return(bResult);
}

//-------------------------------------------------------------------------
