//-------------------------------------------------------------------------

// Player status routines
// Rich Heasman July 1997 / May 2002

//-------------------------------------------------------------------------

void	Player_Init(void);
void	Player_Start(void);
void	Player_Update(void);
void	Player_CheckExtra(void);
void	Player_ScoreAdd(int nNum);
void	Player_ShipRender(void);
void	Player_SmartRender(void);
void	Player_ScoreRender(void);
void	Player_ShipRemove(void);
int		Player_ShipLeft(void);
void	Player_SmartRemove(void);
int		Player_SmartLeft(void);

//-------------------------------------------------------------------------
