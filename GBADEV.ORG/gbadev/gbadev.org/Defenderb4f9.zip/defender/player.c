//-------------------------------------------------------------------------

// Player status routines
// Rich Heasman July 1997 / May 2002

//-------------------------------------------------------------------------

#include 	"player.h"

#include 	"scores.h"
#include 	"gfx.h"
#include 	"gfxdata2.h"
#include 	"sprite.h"
#include 	"string.h"
#include 	"background.h"
#include 	"soundfx.h"

//-------------------------------------------------------------------------

#define	PLAYER_SCORE_GFX_MAX	7
#define	PLAYER_SCORE_YCO		28
#define	PLAYER_SCORE_XCO		1
#define	PLAYER_SCORE_XGAP		8
#define	PLAYER_SHIP_INIT		2
#define	PLAYER_SHIP_GFX_MAX		5
#define	PLAYER_SHIP_YCO			3
#define	PLAYER_SHIP_XCO			1
#define	PLAYER_SHIP_XGAP		10
#define	PLAYER_SMART_INIT		3
#define	PLAYER_SMART_GFX_MAX	5
#define	PLAYER_SMART_YCO		19
#define	PLAYER_SMART_XCO		1
#define	PLAYER_SMART_XGAP	    10

static	SPRITE_TYPE	*pShipSprite[PLAYER_SHIP_GFX_MAX];
static	SPRITE_TYPE	*pSmartSprite[PLAYER_SMART_GFX_MAX];
static 	uint		uScore;
static 	uint		uHiScore;
static 	int			nShipNum;
static 	int			nSmartNum;
static 	int			nExtraNum;

//-------------------------------------------------------------------------

void	Player_Init(void)
{
	int	nLoop;

	uScore=0;
	uHiScore=10000;
	nShipNum=0;
	nSmartNum=0;
	nExtraNum=1;
	for (nLoop=0;nLoop<PLAYER_SHIP_GFX_MAX;nLoop++)
	{
		pShipSprite[nLoop]=Sprite_Create(GFX_SHIP_ICON,PLAYER_SHIP_XCO+PLAYER_SHIP_XGAP*nLoop,GFX_SCREEN_PIXEL_HEIGHT);
	}
	for (nLoop=0;nLoop<PLAYER_SMART_GFX_MAX;nLoop++)
	{
		pSmartSprite[nLoop]=Sprite_Create(GFX_SMART_BOMB,PLAYER_SMART_XCO+PLAYER_SMART_XGAP*nLoop,GFX_SCREEN_PIXEL_HEIGHT);
	}
}

//-------------------------------------------------------------------------

void	Player_Start(void)
{
	uScore=0;
	nShipNum=PLAYER_SHIP_INIT;
	nSmartNum=PLAYER_SMART_INIT;
	nExtraNum=1;
}

//-------------------------------------------------------------------------

void	Player_Update(void)
{
	Player_CheckExtra();
	Player_ShipRender();
	Player_SmartRender();
	Player_ScoreRender();
}

//-------------------------------------------------------------------------

void	Player_CheckExtra(void)
{
	if (uScore>=nExtraNum*SCORE_EXTRA_SHIP)
	{
		nShipNum++;
		nSmartNum++;
		nExtraNum++;
		SoundFX_Make(SOUNDFX_CHANNEL_B, SOUNDFX_BLIB);
	}
}

//-------------------------------------------------------------------------

void	Player_ScoreAdd(int nNum)
{
	if (uScore+nNum<=SCORE_MAXIMUM&&uScore+nNum>=0)
	{
		uScore+=nNum;
	}
	if (uScore > uHiScore)
	{
		uHiScore = uScore;
	}

}

//-------------------------------------------------------------------------

void	Player_ShipRender(void)
{
	int	nLoop;

	for (nLoop=0;nLoop<PLAYER_SHIP_GFX_MAX;nLoop++)
	{
		if (nShipNum>nLoop)
		{
			pShipSprite[nLoop]->uY=PLAYER_SHIP_YCO;
		}
		else
		{
			pShipSprite[nLoop]->uY=GFX_SCREEN_PIXEL_HEIGHT;
		}
	}
}

//-------------------------------------------------------------------------

void	Player_SmartRender(void)
{
	int	nLoop;

	for (nLoop=0;nLoop<PLAYER_SMART_GFX_MAX;nLoop++)
	{
		if (nSmartNum>nLoop)
		{
			pSmartSprite[nLoop]->uY=PLAYER_SMART_YCO;
		}
		else
		{
			pSmartSprite[nLoop]->uY=GFX_SCREEN_PIXEL_HEIGHT;
		}
	}
}

//-------------------------------------------------------------------------

void	Player_ScoreRender(void)
{
	char	szMessage[STRING_LEN_MAX];
	char	szNumber[STRING_LEN_MAX];
	int		nMessageLength;
	int		nNumberLength;

	String_FromInt(szNumber, uScore);
	String_Copy(szMessage, SCORE_BLANK_STRING );
	nMessageLength = sizeof(SCORE_BLANK_STRING) - 1;
	nNumberLength = String_Length(szNumber);
	String_Copy(szMessage + (nMessageLength - nNumberLength), szNumber);
    Background_Font2Print( 0, 1, szMessage);

	String_FromInt(szNumber, uHiScore);
	String_Copy(szMessage, SCORE_BLANK_STRING );
	nMessageLength = sizeof(SCORE_BLANK_STRING) - 1;
	nNumberLength = String_Length(szNumber);
	String_Copy(szMessage + (nMessageLength - nNumberLength), szNumber);
    Background_Font2Print( 24, 1, szMessage);
}

//-------------------------------------------------------------------------

void	Player_ShipRemove(void)
{
	nShipNum--;
}

//-------------------------------------------------------------------------

int		Player_ShipLeft(void)
{
	return(nShipNum);
}

//-------------------------------------------------------------------------

void	Player_SmartRemove(void)
{
	nSmartNum--;
}

//-------------------------------------------------------------------------

int		Player_SmartLeft(void)
{
	return(nSmartNum);
}

//-------------------------------------------------------------------------
