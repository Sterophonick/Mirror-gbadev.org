//-------------------------------------------------------------------------

// human bonus routines
// Rich Heasman July 1997 / May 2002

//-------------------------------------------------------------------------

#include	"fixedpt.h"

//-------------------------------------------------------------------------

void	Bonus_Init(void);
void	Bonus_Clear(void);
void	Bonus_Update(void);
void 	Bonus_Create(int nType,FIXEDPT xXCo,FIXEDPT xYCo,FIXEDPT xXSpeed);

//-------------------------------------------------------------------------
