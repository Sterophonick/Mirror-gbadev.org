//-------------------------------------------------------------------------

// Land routines
// Rich Heasman July 1997 / May 2002

//-------------------------------------------------------------------------

#include 	"land.h"

#include 	"fixedpt.h"
#include 	"gfx.h"
#include 	"rnd.h"
#include 	"human.h"
#include 	"soundfx.h"
#include 	"ship.h"
#include 	"palette.h"
#include 	"pixel.h"
#include 	"sprite.h"

//----------------------------------------------------------------------------

// Definitions

#define	LAND_MAX_HEIGHT		(GFX_PLAY_HEIGHT*5/12)
#define	LAND_MIN_HEIGHT		(GFX_PLAY_HEIGHT/12)
#define	LAND_GRADIENT		(FIXEDPT_UNITS/2)	// gradient of land (1 = 45 degress)
#define	LAND_SWAP_CHANCE	2  					// percent chance of gradient swap
#define	LAND_LOST_LENGTH	100					// length of flashing visuals

enum
{
	LAND_GONE,								// land not present
	LAND_GOING,								// land going
	LAND_PRESENT							// land gone
};

//----------------------------------------------------------------------------

static u8			nLandHeight[GFX_PLAY_WIDTH_PIXELS];
static int			nLandStatus;
static FIXEDPT		xLandPosition;
static FIXEDPT		xLandPrevPosition;
static int			nLandLostCount;

//----------------------------------------------------------------------------

void	Land_Init(void)
{
	int		nLandCount;
	FIXEDPT	xGradient;
	FIXEDPT	xCurrentHeight;

	xGradient=LAND_GRADIENT;
	xCurrentHeight=LAND_MIN_HEIGHT;
	for (nLandCount=0;nLandCount<GFX_PLAY_WIDTH_PIXELS;nLandCount++)
	{
		nLandHeight[nLandCount]=GFX_SCREEN_PIXEL_HEIGHT-FixedToInt(xCurrentHeight);
		if (xCurrentHeight+xGradient <LAND_MIN_HEIGHT
		 || xCurrentHeight+xGradient >LAND_MAX_HEIGHT
		 || Rnd(100)<LAND_SWAP_CHANCE)
		{
			xGradient=-xGradient;
		}
		if ((GFX_PLAY_WIDTH_PIXELS-nLandCount)*LAND_GRADIENT <= xCurrentHeight-LAND_MIN_HEIGHT)
		{
			xGradient = -LAND_GRADIENT;

		}
		xCurrentHeight+=xGradient;
	}
	xLandPrevPosition = -1;
	xLandPosition = 0;
	nLandStatus=LAND_PRESENT;
}

//----------------------------------------------------------------------------

void	Land_New(void)
{
	if (Human_NumAliveGet()>0)
	{
		nLandStatus=LAND_PRESENT;
	}
	else
	{
		nLandStatus=LAND_GONE;
	}
}

//----------------------------------------------------------------------------

void	Land_Update(FIXEDPT xPos)
{
	xLandPosition = xPos;

	switch (nLandStatus)
	{
		case LAND_GONE :
		{
			xLandPosition=-1;
			break;
		}
		case LAND_GOING :
		{
			if (nLandLostCount>=LAND_LOST_LENGTH)
			{
				nLandStatus=LAND_GONE;
			}
			if (nLandLostCount%8==0)
			{
				SoundFX_Make(SOUNDFX_CHANNEL_A, SOUNDFX_ZAPPY);
			}
			nLandLostCount++;
			break;
		}
		case LAND_PRESENT :
		{
			if (Human_NumAliveGet()==0 && !Ship_IsDead())
			{
				nLandLostCount=0;
				nLandStatus=LAND_GOING;
			}
			break;
		}
	}
}

//----------------------------------------------------------------------------

void	Land_Render(void)
{
	Pixel_SetPen(COLOUR_DARK_RED_2);

	if (xLandPrevPosition != -1)
	{
		__FarProcedure(Land_Plot,FixedToInt(xLandPrevPosition));
	}
	if (xLandPosition != -1)
	{
		__FarProcedure(Land_Plot,FixedToInt(xLandPosition));
	}
	xLandPrevPosition = xLandPosition;

	switch (nLandStatus)
	{
		case LAND_GOING :
		{
			if (nLandLostCount%2||nLandLostCount>=LAND_LOST_LENGTH)
			{
				Palette_Copy(COLOUR_BACKGROUND,COLOUR_BLACK_2);
			}
			else
			{
				Palette_Copy(COLOUR_BACKGROUND,Rnd(16));
			}
			break;
		}
	}
}	

//----------------------------------------------------------------------------
//
// unoptimised version
//
//void	Land_Plot(int nLandPos)
//{
//	int	nLandCount,nLandXCo;
//
//	for (nLandCount=0;nLandCount<GFX_SCREEN_PIXEL_WIDTH;nLandCount++)
//	{
//		nLandXCo=nLandCount+nLandPos;
//		if (nLandXCo>=GFX_PLAY_WIDTH_PIXELS)
//		{
//			nLandXCo-=GFX_PLAY_WIDTH_PIXELS;
//		}
//		Pixel_PlotXOR(nLandCount,GFX_SCREEN_PIXEL_HEIGHT-nLandHeight[nLandXCo]);
//	}
//}
//
//----------------------------------------------------------------------------

// optimised version : incorporated pixel functions and split into 2 to avoid odd/even compare
// would be better to plot the ground onto a seperate background using only a few tiles and hardware scroll it

void	Land_Plot(u32 *pFuncAddr,int nLandPos)
{
	int		nLandXCo;
	int		nX;
	int		nY;
	u8		*pDest;
	u16		uPrevious;

	nLandXCo = nLandPos;
	for (nX = 0; nX < GFX_SCREEN_PIXEL_WIDTH; nX+=2)
	{
		nY = nLandHeight[nLandXCo];
		pDest = pPixelDestX[nX];
		pDest += nPixelOffsetY[nY];

		uPrevious = *(u16 *)pDest;
		*(u16 *)pDest = uPrevious ^ COLOUR_DARK_RED_2;

		nLandXCo = (nLandXCo + 2) & (GFX_PLAY_WIDTH_PIXELS - 1);
	}

	nLandXCo = nLandPos+1;
	for (nX = 1; nX < GFX_SCREEN_PIXEL_WIDTH; nX+=2)
	{
		nY = nLandHeight[nLandXCo];
		pDest = pPixelDestX[nX];
		pDest += nPixelOffsetY[nY];

		uPrevious = *(u16 *)pDest;
		*(u16 *)pDest = uPrevious ^ (COLOUR_DARK_RED_2 << 8);

		nLandXCo = (nLandXCo + 2) & (GFX_PLAY_WIDTH_PIXELS - 1);  
	}
}										   

//----------------------------------------------------------------------------

FIXEDPT	Land_Boundary(FIXEDPT xXPos)
{
	while (xXPos>GFX_PLAY_WIDTH)
	{
		xXPos-=GFX_PLAY_WIDTH;
	}
	while (xXPos<0)
	{
		xXPos+=GFX_PLAY_WIDTH;
	}

	return(xXPos);
}

//----------------------------------------------------------------------------

FIXEDPT	Land_HeightGet(FIXEDPT xXPos)
{
	return(IntToFixed(GFX_SCREEN_PIXEL_HEIGHT - nLandHeight[FixedToInt(xXPos)]));
}

//----------------------------------------------------------------------------
