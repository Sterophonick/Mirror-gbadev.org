//-------------------------------------------------------------------------

// Mine routines
// Rich Heasman July 1997 / May 2002

//-------------------------------------------------------------------------

#include 	"mine.h"

#include 	"fixedpt.h"
#include 	"gfx.h"
#include 	"gfxdata2.h"
#include 	"ship.h"
#include 	"land.h"
#include 	"sprite.h"

//-------------------------------------------------------------------------

#define	MINE_MAX_NUM			20 		// total maximum number of Mines
#define	MINE_LIFE_LEN			(10*60)	// time mines last

enum
{
	MINE_DEAD,
	MINE_DESTROY,
	MINE_LIVE
};

typedef struct {
	int			nStatus; 			// Mine status
	SPRITE_TYPE	*pSprite;			// gfx object
	FIXEDPT		xXCo; 				// centre of mine object
	FIXEDPT		xYCo;	 			// Top edge of mine object
	int			nCount;				// length of life of mine
} MINE_TYPE;

//-------------------------------------------------------------------------

static	MINE_TYPE	Mine[MINE_MAX_NUM];

//----------------------------------------------------------------------------

void	Mine_Init(void)
{
	int	nLoop;

	for (nLoop=0;nLoop<MINE_MAX_NUM;nLoop++)
	{
		Mine[nLoop].nStatus=MINE_DEAD;
	}
}

//----------------------------------------------------------------------------

void	Mine_Clear(void)
{
	int	nLoop;

	for (nLoop=0;nLoop<MINE_MAX_NUM;nLoop++)
	{
		if (Mine[nLoop].nStatus!=MINE_DEAD)
		{
			Mine[nLoop].nStatus=MINE_DESTROY;
		}
	}
}

//----------------------------------------------------------------------------

void	Mine_Update(void)
{
	int		nLoop;
	int		nX;
	int		nY;

	for (nLoop=0;nLoop<MINE_MAX_NUM;nLoop++)
	{
		switch (Mine[nLoop].nStatus)
		{
			case MINE_DEAD :
			{
				break;
			}
			case MINE_DESTROY :
			{
				Sprite_Destroy(Mine[nLoop].pSprite);
				Mine[nLoop].nStatus=MINE_DEAD;
				break;
			}
			case MINE_LIVE :
			{
				Mine[nLoop].nCount++;
				if (Ship_CollisionCheck(Mine[nLoop].xXCo,Mine[nLoop].xYCo,GFX_MINE_WIDTH,GFX_MINE_HEIGHT) && !Ship_IsDead())
				{
					Ship_Kill();
				}
				nX=FixedToScreenX(Land_Boundary(Mine[nLoop].xXCo-Ship_PosGet()),GFX_MINE_WIDTH);
				nY=FixedToScreenY(Mine[nLoop].xYCo,0);
				Sprite_PositionSet(Mine[nLoop].pSprite, nX, nY);

				if (Mine[nLoop].nCount>MINE_LIFE_LEN)
				{
					Mine[nLoop].nStatus=MINE_DESTROY;
				}
				break;
			}
		}
	}
}

//----------------------------------------------------------------------------

void	Mine_Create(FIXEDPT xXCo,FIXEDPT xYCo)
{
	int			nLoop;
	MINE_TYPE	*MinePtr;

	nLoop=0;
	while (nLoop<MINE_MAX_NUM && Mine[nLoop].nStatus!=MINE_DEAD)
	{
		nLoop++;
	}
	if (nLoop<MINE_MAX_NUM && Sprite_Available())
	{
		MinePtr=&Mine[nLoop];
		MinePtr->nStatus=MINE_LIVE;
		MinePtr->pSprite=Sprite_Create(GFX_MINE,0,GFX_SCREEN_PIXEL_HEIGHT);
		MinePtr->xXCo=xXCo;
		MinePtr->xYCo=xYCo;
		MinePtr->nCount=0;
	}
}

//----------------------------------------------------------------------------


