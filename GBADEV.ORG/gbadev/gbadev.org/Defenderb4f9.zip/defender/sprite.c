//------------------------------------------------------------------------

// sprite
// Rich Heasman May 2002

//------------------------------------------------------------------------

#include	"gba.h"
#include	"sprite.h"

#include	"gfx.h"
#include	"gfxdata2.h"
#include	"mem.h"
#include	"debug.h"
#include	"dma.h"

//------------------------------------------------------------------------

// future: need to add a next pointer so that sprites can be linked and rendered in order

//------------------------------------------------------------------------

#define	SPRITE_MAX			128

static	SPRITE_TYPE	Sprite[SPRITE_MAX];
static	int			nSpriteNumberActive;

//------------------------------------------------------------------------

void		Sprite_Init(void)
{
	int			nSprite;
	SPRITE_TYPE	*pSprite;
	u16			*pDest;
	u16			*pSrc;

	// blank down sprite info
	pSprite = &Sprite[0];
	pSprite->uChar = 0;
	pSprite->uX = GFX_SCREEN_PIXEL_WIDTH;
	pSprite->uY = GFX_SCREEN_PIXEL_HEIGHT;
	pSprite->uMode = 0;
	pSprite->uShape =	1;
	pSprite->uSize = 0;
	pSprite->uColMode = 1;
	pSprite->uPalette = 0;
	pSprite->uPriority = 1;
	pSprite->uVFlip = 0;
	pSprite->uHFlip = 0;
	pSprite->uMosaic = 0;
	pSprite->uRotation = 0;		
	pSprite->uDoubleSize = 1;			// Rot = 0, DoubleSize = 1 means sprite off
    pSprite->uActive = 0;


	pDest = (u16 *) &Sprite[0];
	pSrc = (u16 *) pSprite;
	for (nSprite = 0; nSprite < SPRITE_MAX; nSprite++)
	{
		*pDest++ = *pSrc;
		*pDest++ = *(pSrc + 1);
		*pDest++ = *(pSrc + 2);
		*pDest++ = 0;					// blank rotation part
	}

	nSpriteNumberActive = 0;

	Sprite_Render();

	Mem_Copy((u32 *)MEM_PAL_OBJ, (u32 *)gfxdata2_Palette, GFXDATA2_PALETTE_SIZE);
    Mem_Copy((u32 *)MEM_OBJ, (u32 *)gfxdata2_Tiles, GFXDATA2_TILE_SIZE);

	GfxControl.uEnableSprites = 1;
	GfxControl.uSpriteDimension = GFX_2D;
}	

//------------------------------------------------------------------------

void		Sprite_Render(void)
{
//	int			nSprite;
	u16			*pDest;
	u16			*pSrc;
	DMA_TYPE	Dma;

	pDest = (u16 *) MEM_OAM;
	pSrc = (u16 *) &Sprite[0];

	Dma.uSrc = (uint) pSrc;
	Dma.uDest = (uint) pDest;
	Dma.uCount = SPRITE_MAX * 2;
	Dma.uDestInc = DMA_INC;
	Dma.uSrcInc = DMA_INC;
	Dma.uSize = DMA_32_BIT;
	Dma.uMode = DMA_NOW;
	Dma.uRepeat = 0;
	Dma.uInterrupt = 0;
	Dma.uEnable = 1;
	Dma_Set(3,&Dma);

// non-dma version (if non-dma function used then move to IWRAM)
//	for (nSprite = 0; nSprite < SPRITE_MAX; nSprite++)
//	{
//		*pDest++ = *pSrc++;
//		*pDest++ = *pSrc++;
//		*pDest++ = *pSrc++;
//		pDest++; 				// skip rotation regs
//		pSrc++; 				// skip to next sprite
//	}
}	

//------------------------------------------------------------------------

// future: this should be done by maintaining a free list

SPRITE_TYPE	*Sprite_Create(int nFrame, int nX, int nY)
{
	int	 		nSprite;
	SPRITE_TYPE	*pSprite;

	nSprite = 0;
	pSprite = &Sprite[0];
	while (nSprite < SPRITE_MAX && pSprite->uActive == 1)
	{
		pSprite++;
		nSprite++;
	}

	if (nSprite >= SPRITE_MAX)
	{
		pSprite = NULL;			// wheres the error handling
	}
	else
	{
		Sprite_FrameSet(pSprite, nFrame);
		Sprite_PositionSet(pSprite, nX, nY);
		pSprite->uRotation = 0;		
		pSprite->uDoubleSize = 0;
	    pSprite->uActive = 1;
		nSpriteNumberActive++;
	}

	return(pSprite);
}	

//------------------------------------------------------------------------

void 		Sprite_Destroy(SPRITE_TYPE	*pSprite)
{
	if (pSprite->uActive)
	{
		pSprite->uActive = 0;
		pSprite->uRotation = 0;		
		pSprite->uDoubleSize = 1;
		pSprite->uX = GFX_SCREEN_PIXEL_WIDTH;
		pSprite->uY = GFX_SCREEN_PIXEL_HEIGHT;
		nSpriteNumberActive--;
	}
}	

//------------------------------------------------------------------------

BOOL		Sprite_Available(void)
{
	BOOL	boAvailable;

	boAvailable = FALSE;
	if ((nSpriteNumberActive+1) < SPRITE_MAX)
	{
		boAvailable = TRUE;
	}

	return(boAvailable);
}	


//------------------------------------------------------------------------

void		Sprite_FrameSet(SPRITE_TYPE *pSprite, int nFrame)
{
	pSprite->uChar = (nFrame/8) * 16 + (nFrame%8) * 2;
}	

//------------------------------------------------------------------------

void		Sprite_PositionSet(SPRITE_TYPE *pSprite, int nX, int nY)
{
	if (nX < -64 || nX > GFX_SCREEN_PIXEL_WIDTH)  nX = GFX_SCREEN_PIXEL_WIDTH;
	if (nY < -64 || nY > GFX_SCREEN_PIXEL_HEIGHT) nY = GFX_SCREEN_PIXEL_HEIGHT;
	pSprite->uX = nX;
	pSprite->uY = nY;
}	

//------------------------------------------------------------------------
