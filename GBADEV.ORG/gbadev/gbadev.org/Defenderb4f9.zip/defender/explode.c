//-------------------------------------------------------------------------

// Explosion routines
// Rich Heasman July 1997 / May 2002

//-------------------------------------------------------------------------

#include 	"explode.h" 

#include 	"fixedpt.h"
#include 	"rnd.h"
#include 	"ship.h"
#include 	"land.h"
#include 	"gfx.h"
#include 	"palette.h"
#include 	"pixel.h"
#include 	"debug.h"

//-------------------------------------------------------------------------

#define	EXPLODE_MAX_NUM		10
#define	EXPLODE_MAX_FRAGS	20
#define	EXPLODE_SCALAR		(1<<16)

enum
{
	EXPLODE_OFF,
	EXPLODE_ON
};

typedef struct {
	FIXEDPT		xXStep;
	FIXEDPT		xYStep;
} FRAGMENT_TYPE;

typedef struct {
	int			nStatus;
	int			nCount;
	int			nLength;
	int			nNum;
	int			nColour;
	FIXEDPT		xXStart;
	FIXEDPT		xYStart;
	FRAGMENT_TYPE	Fragment[EXPLODE_MAX_FRAGS];
} EXPLODE_TYPE;

static	EXPLODE_TYPE	Explode[EXPLODE_MAX_NUM];

//----------------------------------------------------------------------------

void	Explode_Init(void)
{
	Explode_Clear();
}

//----------------------------------------------------------------------------

void	Explode_Clear(void)
{
	int	nLoop;

	for (nLoop=0;nLoop<EXPLODE_MAX_NUM;nLoop++)
	{
		Explode[nLoop].nStatus=EXPLODE_OFF;
	}
}

//----------------------------------------------------------------------------

// optimised by pulling pixel write into function and splitting in half to avoid odd/even compare

void 	Explode_Render(u32 *pFuncAddr)
{
	int		nLoop;
	int		nCount;
	int		nXFrag,nYFrag;
	u8		*pDest;
	u16		uPrevious;
	u16		uColour;

	for (nLoop=0;nLoop<EXPLODE_MAX_NUM;nLoop++)
	{
		if (Explode[nLoop].nStatus == EXPLODE_ON)
		{
			uColour = Explode[nLoop].nColour;
			if (Explode[nLoop].nCount>=2)
			{
				for (nCount=0;nCount<Explode[nLoop].nNum;nCount++)
				{
					nXFrag=FixedToScreenX((Explode[nLoop].Fragment[nCount].xXStep*(Explode[nLoop].nCount-1)+Explode[nLoop].xXStart),0);
					nYFrag=FixedToScreenY((Explode[nLoop].Fragment[nCount].xYStep*(Explode[nLoop].nCount-1)+Explode[nLoop].xYStart),0);
					if (nXFrag>=0 && nXFrag<GFX_SCREEN_PIXEL_WIDTH && nYFrag>GFX_SCREEN_PIXEL_HEIGHT-GFX_PLAY_HEIGHT_PIXELS && nYFrag<GFX_SCREEN_PIXEL_HEIGHT)
					{
						pDest = pPixelDestX[nXFrag];
						pDest += nPixelOffsetY[nYFrag];
						uPrevious = *(u16 *) pDest;
						if (nXFrag & 1)	*(u16 *)pDest = uPrevious ^ (uColour << 8);
						else 		   	*(u16 *)pDest = uPrevious ^ uColour;
					}
				}
			}
			Explode[nLoop].nCount++;
			if (Explode[nLoop].nCount<=Explode[nLoop].nLength-2)
			{
				for (nCount=0;nCount<Explode[nLoop].nNum;nCount++)
				{
					nXFrag=FixedToScreenX((Explode[nLoop].Fragment[nCount].xXStep*Explode[nLoop].nCount+Explode[nLoop].xXStart),0);
					nYFrag=FixedToScreenY((Explode[nLoop].Fragment[nCount].xYStep*Explode[nLoop].nCount+Explode[nLoop].xYStart),0);
					if (nXFrag>=0 && nXFrag<GFX_SCREEN_PIXEL_WIDTH && nYFrag>GFX_SCREEN_PIXEL_HEIGHT-GFX_PLAY_HEIGHT_PIXELS && nYFrag<GFX_SCREEN_PIXEL_HEIGHT)
					{
						pDest = pPixelDestX[nXFrag];
						pDest += nPixelOffsetY[nYFrag];
						uPrevious = *(u16 *) pDest;
						if (nXFrag & 1)	*(u16 *)pDest = uPrevious ^ (uColour << 8);
						else 		   	*(u16 *)pDest = uPrevious ^ uColour;
					}
				}
			}
			if (Explode[nLoop].nCount>=Explode[nLoop].nLength)
			{
				Explode[nLoop].nStatus=EXPLODE_OFF;
			}
		}
	}
}

//----------------------------------------------------------------------------

void 	Explode_Make(int nType,FIXEDPT xXCo,FIXEDPT xYCo)
{
	int		nLoop;
	int		nCount;
	FIXEDPT	xDist;
	FIXEDPT	xXYScale;

	nLoop=0;
	while (nLoop<EXPLODE_MAX_NUM && Explode[nLoop].nStatus!=EXPLODE_OFF)
	{
		nLoop++;
	}
	if (nLoop<EXPLODE_MAX_NUM)
	{
		switch(nType)
		{
			case EXPLODE_HUMAN :
			{
				Explode[nLoop].nNum=6;
				Explode[nLoop].nLength=16;
				Explode[nLoop].nColour=COLOUR_WHITE;
				xDist=GFX_PLAY_HEIGHT/2;
				break;
			}
			case EXPLODE_SOLIDER :
			{
				Explode[nLoop].nNum=8;
				Explode[nLoop].nLength=20;
				Explode[nLoop].nColour=COLOUR_GREEN;
				xDist=GFX_PLAY_HEIGHT;
				break;
			}
			case EXPLODE_MUTANT :
			{
				Explode[nLoop].nNum=12;
				Explode[nLoop].nLength=30;
				Explode[nLoop].nColour=COLOUR_BROWN;
				xDist=GFX_PLAY_HEIGHT*3/2;
				break;
			}
			case EXPLODE_POD :
			{
				Explode[nLoop].nNum=20;
				Explode[nLoop].nLength=80;
				Explode[nLoop].nColour=COLOUR_PURPLE;
				xDist=GFX_PLAY_HEIGHT*2;
				break;
			}
			case EXPLODE_SWARMER :
			{
				Explode[nLoop].nNum=10;
				Explode[nLoop].nLength=20;
				Explode[nLoop].nColour=COLOUR_RED;
				xDist=GFX_PLAY_HEIGHT*2/3;
				break;
			}
			case EXPLODE_MINER :
			{
				Explode[nLoop].nNum=16;
				Explode[nLoop].nLength=60;
				Explode[nLoop].nColour=COLOUR_BLUE;
				xDist=GFX_PLAY_HEIGHT*2;
				break;
			}
			case EXPLODE_BAITER :
			{
				Explode[nLoop].nNum=10;
				Explode[nLoop].nLength=40;
				Explode[nLoop].nColour=COLOUR_YELLOW;
				xDist=GFX_PLAY_HEIGHT*2;
				break;
			}
			default :
			{
				xDist=0;
				break;
			}
		}
		Explode[nLoop].nStatus=EXPLODE_ON;
		Explode[nLoop].nCount=0;
		Explode[nLoop].xXStart=Land_Boundary(xXCo-Ship_PosGet());
		Explode[nLoop].xYStart=xYCo;
		xXYScale = IntToFixed(GFX_SCREEN_PIXEL_HEIGHT)/GFX_SCREEN_PIXEL_WIDTH;
		for (nCount=0;nCount<Explode[nLoop].nNum;nCount++)
		{
			// divs - only happen once when explosion first made
			Explode[nLoop].Fragment[nCount].xXStep=(FIXEDPT)(xDist*((int)Rnd(128)-64)/128) / Explode[nLoop].nLength;
			Explode[nLoop].Fragment[nCount].xYStep=(FIXEDPT)(FixedMultiply(xDist,xXYScale)*((int)Rnd(128)-64)/128) / Explode[nLoop].nLength;
		}
	}
}

//----------------------------------------------------------------------------
