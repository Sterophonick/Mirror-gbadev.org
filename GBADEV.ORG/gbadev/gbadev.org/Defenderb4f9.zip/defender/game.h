//-------------------------------------------------------------------------

// Game flow control routines
// Rich Heasman July 1997 / May 2002

//-------------------------------------------------------------------------

enum
{
	GAME_INIT,
	GAME_WAIT_TITLE,
	GAME_WAIT_START,
	GAME_START,
	GAME_START_WAIT,
	GAME_SHOW_WAVE,
	GAME_SHOW_WAVE_WAIT,
	GAME_RUNNING,
	GAME_WAVE_CLEAR,
	GAME_SHOW_DONE,
	GAME_SHOW_DONE_WAIT,
	GAME_SHOW_MEN,
	GAME_SHOW_MEN_WAIT,
	GAME_SHOW_MEN_REMOVE,
	GAME_SHIP_DEAD,
	GAME_SHIP_DEAD_WAIT,
	GAME_SHIP_NEW,
	GAME_OVER,
	GAME_OVER_WAIT
};

//-------------------------------------------------------------------------

void	Game_Init(void);
void	Game_Update(void);
void	Game_StateUpdate(void);
void	Game_Render(void);
void	Game_ClearAll(void);
void	Game_Start(void);
void	Game_WaveCompleteRender(void);
void	Game_StateSet(int nState);
void	Game_ShowFE(void);

//-------------------------------------------------------------------------
