//-------------------------------------------------------------------------

// Radar routines
// Rich Heasman July 1997 / May 2002

//-------------------------------------------------------------------------

#include	"fixedpt.h"

//-------------------------------------------------------------------------

#define	RADAR_INVALID	-1

void	Radar_Init(void);
void	Radar_Clear(void);
void	Radar_Update(void);
void	Radar_BoxRender(void);
int		Radar_Add(int nGfxNum);
void	Radar_Position(int nNum,FIXEDPT xXCo,FIXEDPT xYCo);
void	Radar_Remove(int nNum);

//-------------------------------------------------------------------------
