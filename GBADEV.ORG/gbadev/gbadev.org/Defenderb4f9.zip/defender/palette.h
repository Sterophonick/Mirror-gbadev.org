//------------------------------------------------------------------------

// palette
// Rich Heasman May 2002

//------------------------------------------------------------------------

#include	"gba.h"

//-----------------------------------------------------------------------

// colours for palette

enum
{
	COLOUR_BACKGROUND,
	COLOUR_BLACK,
	COLOUR_DARK_GREEN,		
	COLOUR_DARK_CYAN,		
	COLOUR_DARK_RED,			
	COLOUR_DARK_PURPLE,		
	COLOUR_BROWN,			
	COLOUR_GREY,				
	COLOUR_DARK_GREY,		
	COLOUR_BLUE,	 			
	COLOUR_GREEN, 			
	COLOUR_CYAN,				
	COLOUR_RED,				
	COLOUR_PURPLE,			
	COLOUR_YELLOW,			
	COLOUR_WHITE,			
	COLOUR_DARK_BLUE,		

	COLOUR_DARK_RED_2,		
	COLOUR_YELLOW_2,			
	COLOUR_BLACK_2			
};

//-----------------------------------------------------------------------

void	Palette_Copy(int nDest,int nSrc);

//-----------------------------------------------------------------------

