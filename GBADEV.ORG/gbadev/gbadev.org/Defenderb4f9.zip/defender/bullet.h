//-------------------------------------------------------------------------

// Bullet routines
// Rich Heasman July 1997 / May 2002

//-------------------------------------------------------------------------

#include	"fixedpt.h"

//-------------------------------------------------------------------------

void	Bullet_Init(void);
void	Bullet_Clear(void);
void	Bullet_Update(void);
void	Bullet_Create(FIXEDPT xXCo,FIXEDPT xYCo,FIXEDPT xXSpeed,FIXEDPT xYSpeed);

//-------------------------------------------------------------------------
