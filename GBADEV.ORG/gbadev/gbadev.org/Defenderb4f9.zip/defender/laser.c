//-------------------------------------------------------------------------

// Laser routines
// Rich Heasman July 1997 / May 2002

//-------------------------------------------------------------------------

#include 	"laser.h"

#include 	"fixedpt.h"
#include 	"gfx.h"

#include 	"land.h"
#include 	"ship.h"
#include 	"soundfx.h"
#include 	"alien.h"
#include 	"human.h"
#include 	"palette.h"
#include 	"pixel.h"
#include 	"sprite.h"
#include 	"debug.h"

//-------------------------------------------------------------------------

#define	LASER_MAX_NUM		1						// max number of lasers
#define	LASER_LIFE			8						// number of frames laser alive for
#define	LASER_TRAVEL		((FIXEDPT)(GFX_PLAY_SCREEN_WIDTH*7/8))	// length of laser beam
#define	LASER_NUM_COLOURS	4						// number of different laser colours
#define	LASER_INVALID 		-1						// no old laser

enum
{
	LASER_OFF,			
	LASER_ON,			
	LASER_STOPPING,
	LASER_KILLED
};

enum
{
	LASER_OLD,			
	LASER_NEW			
};

//-------------------------------------------------------------------------

typedef struct {
	FIXEDPT	xXCo;
	FIXEDPT	xYCo;
	int		nDir;
	int		nStatus;
	FIXEDPT	xLand[3];					// present and 2 previous
	int		nAge[3];
	int		nColour[3];
} LASER_TYPE;


//-------------------------------------------------------------------------

static	LASER_TYPE	Laser[LASER_MAX_NUM];

static	const int 	nLaserColourList[LASER_NUM_COLOURS]={COLOUR_PURPLE, COLOUR_GREEN, COLOUR_YELLOW, COLOUR_WHITE};

//-------------------------------------------------------------------------

void	Laser_Clear(void)
{
	int	nLoop;

	for (nLoop=0;nLoop<LASER_MAX_NUM;nLoop++)
	{
		Laser[nLoop].nStatus=LASER_OFF;
	}
}

//-------------------------------------------------------------------------

void	Laser_Fire(FIXEDPT xXCo,FIXEDPT xYCo,int nDir)
{
	int	nLaserNum;

	nLaserNum=0;
	while (nLaserNum<LASER_MAX_NUM && Laser[nLaserNum].nStatus!=LASER_OFF)
	{
		nLaserNum++;
	}
	if (nLaserNum<LASER_MAX_NUM)
	{
		Laser[nLaserNum].xXCo=xXCo;
		Laser[nLaserNum].xYCo=xYCo;
		Laser[nLaserNum].nDir=nDir;
		Laser[nLaserNum].nStatus=LASER_ON;
		Laser[nLaserNum].nAge[0]=0;
		Laser[nLaserNum].nColour[0]=0;
		Laser[nLaserNum].nColour[1]=LASER_INVALID;
		Laser[nLaserNum].nColour[2]=LASER_INVALID;
		SoundFX_Make(SOUNDFX_CHANNEL_B, SOUNDFX_BLAST);
	}
}

//-------------------------------------------------------------------------

void	Laser_Render(void)
{
	int	nLoop;

	for (nLoop=0;nLoop<LASER_MAX_NUM;nLoop++)
	{
		if (Laser[nLoop].nStatus!=LASER_OFF)
		{
 			Laser_Plot(nLoop,LASER_OLD);
			Laser[nLoop].nAge[0]++;
			if (Laser[nLoop].nAge[0]>=LASER_LIFE)
			{
				if (Laser[nLoop].nStatus==LASER_STOPPING)
				{
					Laser[nLoop].nStatus=LASER_OFF;
				}
				else
				{
					Laser[nLoop].nStatus=LASER_STOPPING;
				}
			}
			if (Laser[nLoop].nStatus==LASER_ON)
			{
				Laser[nLoop].xLand[0]=Ship_PosGet();
				Laser[nLoop].nColour[0]=(Laser[nLoop].nColour[0]+1)%LASER_NUM_COLOURS;
				Laser_Plot(nLoop,LASER_NEW);
			}
			Laser[nLoop].xLand[2]=Laser[nLoop].xLand[1];
			Laser[nLoop].nAge[2]=Laser[nLoop].nAge[1];
			Laser[nLoop].nColour[2]=Laser[nLoop].nColour[1];
			Laser[nLoop].xLand[1]=Laser[nLoop].xLand[0];
			Laser[nLoop].nAge[1]=Laser[nLoop].nAge[0];
			Laser[nLoop].nColour[1]=Laser[nLoop].nColour[0];
			Laser[nLoop].nColour[0]=LASER_INVALID;
		}
	}
}

//-------------------------------------------------------------------------

void	Laser_Plot(int nLaser,int nType)
{
	FIXEDPT	xLaserStart;
	FIXEDPT	xLaserLength;
	FIXEDPT	xLand;
	int		nAge;
	int		nColour;
	FIXEDPT	xLaserPosition;

	if (nType==LASER_NEW)
	{
		xLand=Laser[nLaser].xLand[0];
		nAge=Laser[nLaser].nAge[0];
		nColour=Laser[nLaser].nColour[0];
	}
	else	// old
	{
		xLand=Laser[nLaser].xLand[2];
		nAge=Laser[nLaser].nAge[2];
		nColour=Laser[nLaser].nColour[2];
	}


	if (Laser[nLaser].nDir==SHIP_FORWARD)
	{
		xLaserStart=Laser[nLaser].xXCo+(nAge-1)*LASER_TRAVEL/LASER_LIFE-xLand;
		xLaserLength=LASER_TRAVEL;
	}
	else
	{
		xLaserStart=Laser[nLaser].xXCo-(nAge-1)*LASER_TRAVEL/LASER_LIFE-xLand;
		xLaserLength=-LASER_TRAVEL;
	}

	if (xLaserStart>GFX_PLAY_SCREEN_WIDTH-FIXEDPT_UNITS)
	{
		xLaserStart=GFX_PLAY_SCREEN_WIDTH-FIXEDPT_UNITS;
	}
	if (xLaserStart<0)
	{
		xLaserStart=0;
	}
	if (xLaserStart+xLaserLength>GFX_PLAY_SCREEN_WIDTH-FIXEDPT_UNITS)
	{
		xLaserLength=GFX_PLAY_SCREEN_WIDTH-FIXEDPT_UNITS-xLaserStart;
	}
	if (xLaserStart+xLaserLength-FIXEDPT_UNITS<0)
	{
		xLaserLength=-xLaserStart+FIXEDPT_UNITS;
	}

	if (xLaserLength!=0 && nColour!=LASER_INVALID)
	{
		if (nType==LASER_NEW)
		{
			xLaserPosition=Land_Boundary(xLand+xLaserStart+xLaserLength/2);
			if (Alien_CollisionCheck(xLaserPosition,Laser[nLaser].xYCo,xLaserLength,FIXEDPT_UNITS)
			 || Human_CollisionCheck(xLaserPosition,Laser[nLaser].xYCo,xLaserLength,FIXEDPT_UNITS))
			{
				Laser[nLaser].nStatus=LASER_KILLED;
			}
		}
		Pixel_SetPen(nLaserColourList[nColour]);
		__FarProcedure(Pixel_DrawYConstantXOR, FixedToScreenX(xLaserStart,0), FixedToScreenX(xLaserStart + xLaserLength,0), FixedToScreenY(Laser[nLaser].xYCo,0));
	}
}

//-------------------------------------------------------------------------



								  
								  