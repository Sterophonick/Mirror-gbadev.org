//------------------------------------------------------------------------------------

// pixel ops on a tile based background
// Rich Heasman May 2002

//------------------------------------------------------------------------------------

#include	"gba.h"

//------------------------------------------------------------------------------------

// extern vars, direct access for optimisations

extern u8 *		pPixelDestX[];
extern u16		nPixelOffsetY[];

//------------------------------------------------------------------------------------

void	Pixel_Init(uint uScreenBase, uint uTileBase);
void	Pixel_SetPen(uint uColour);
void	Pixel_Plot(int nX, int nY);
void	Pixel_PlotXOR(int nX, int nY);
void	Pixel_Draw(int nX0, int nY0, int nX1, int nY1);
void	Pixel_Rectangle(int nX0, int nY0, int nX1, int nY1);
void	Pixel_DrawYConstantXOR(u32 *pFuncAddr, int nX0, int nX1, int nY) CODE_IN_IWRAM;

//------------------------------------------------------------------------------------
