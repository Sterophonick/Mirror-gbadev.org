//-------------------------------------------------------------------------

// Explosion routines
// Rich Heasman July 1997 / May 2002

//-------------------------------------------------------------------------

#include	"gba.h"
#include	"fixedpt.h"

//-------------------------------------------------------------------------

enum
{
	EXPLODE_HUMAN,
	EXPLODE_SOLIDER,
	EXPLODE_MUTANT,
	EXPLODE_POD,
	EXPLODE_SWARMER,
	EXPLODE_MINER,
	EXPLODE_BAITER,

	EXPLODE_ANY
};

//-------------------------------------------------------------------------

void		Explode_Init(void);
void		Explode_Clear(void);
void 		Explode_Render(u32 *pFuncAddr) CODE_IN_IWRAM;
void 		Explode_Make(int nType,FIXEDPT xXCo,FIXEDPT xYCo);

//-------------------------------------------------------------------------
