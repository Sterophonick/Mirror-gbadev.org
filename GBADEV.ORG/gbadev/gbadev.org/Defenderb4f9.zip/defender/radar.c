//-------------------------------------------------------------------------

// Radar routines
// Rich Heasman July 1997 / May 2002

//-------------------------------------------------------------------------

#include 	"radar.h"

#include 	"fixedpt.h"
#include 	"gfx.h"
#include 	"ship.h"
#include 	"land.h"
#include 	"human.h"
#include 	"alien.h"
#include 	"palette.h"
#include 	"pixel.h"
#include 	"sprite.h"
#include 	"debug.h"

#define	RADAR_MAX_NUM	40
#define	RADAR_HEIGHT	(GFX_SCREEN_PIXEL_HEIGHT-GFX_PLAY_HEIGHT_PIXELS-1)
#define	RADAR_WIDTH		142
#define	RADAR_SCALAR	(1<<16)

//-------------------------------------------------------------------------

typedef struct {
	SPRITE_TYPE	*pSprite;
	int			nStatus;
	FIXEDPT		xXCo;
	FIXEDPT		xYCo;
} RADAR_TYPE;

enum
{
	RADAR_DEAD,
	RADAR_DESTROY,
	RADAR_ON
};

static	RADAR_TYPE 	Radar[RADAR_MAX_NUM];
static	FIXEDPT		xRadarOff;

//----------------------------------------------------------------------------

void	Radar_Init(void)
{
	int		nLoop;

	for (nLoop=0;nLoop<RADAR_MAX_NUM;nLoop++)
	{
		Radar[nLoop].nStatus=RADAR_DEAD;
	}
	Radar_BoxRender();
}

//----------------------------------------------------------------------------

void	Radar_Clear(void)
{
	int		nLoop;

	for (nLoop=0;nLoop<RADAR_MAX_NUM;nLoop++)
	{
		if (Radar[nLoop].nStatus!=RADAR_DEAD)
		{
			Radar[nLoop].nStatus=RADAR_DESTROY;
		}
	}
}

//----------------------------------------------------------------------------

void	Radar_Update(void)
{
	int			nLoop;
	int			nX;
	int			nY;
	FIXEDPT		xXOffset;

	xXOffset = -Ship_PosGet() + xRadarOff;
	for (nLoop=0; nLoop<RADAR_MAX_NUM; nLoop++)
	{
		switch (Radar[nLoop].nStatus)
		{
			case RADAR_DEAD :
			{
				break;
			}
			case RADAR_DESTROY :
			{
				Sprite_Destroy(Radar[nLoop].pSprite);
				Radar[nLoop].nStatus=RADAR_DEAD;
				break;
			}
			case RADAR_ON :
			{
				nX = (int)((FixedToInt(Land_Boundary(Radar[nLoop].xXCo + xXOffset))
					 *RADAR_WIDTH)/GFX_PLAY_WIDTH_PIXELS +(GFX_SCREEN_PIXEL_WIDTH-RADAR_WIDTH)/2);
				nY = RADAR_HEIGHT-((FixedToInt(Radar[nLoop].xYCo)*(RADAR_HEIGHT*RADAR_SCALAR/GFX_PLAY_HEIGHT_PIXELS))/RADAR_SCALAR);
				Radar[nLoop].pSprite->uX = nX;
				Radar[nLoop].pSprite->uY = nY;

				break;
			}
		}
	}
}

//----------------------------------------------------------------------------

void	Radar_BoxRender(void)
{
	int		nNipXOff;

	Pixel_SetPen(COLOUR_YELLOW_2);
	Pixel_Draw(0,0,GFX_SCREEN_PIXEL_WIDTH-1,0);
	Pixel_Draw(0,RADAR_HEIGHT+1,GFX_SCREEN_PIXEL_WIDTH-1,RADAR_HEIGHT+1);
	Pixel_Draw((GFX_SCREEN_PIXEL_WIDTH-RADAR_WIDTH)/2-1,0,(GFX_SCREEN_PIXEL_WIDTH-RADAR_WIDTH)/2-1,RADAR_HEIGHT+1);
	Pixel_Draw(GFX_SCREEN_PIXEL_WIDTH/2+RADAR_WIDTH/2-1,0,GFX_SCREEN_PIXEL_WIDTH/2+RADAR_WIDTH/2-1,RADAR_HEIGHT+1);

	nNipXOff= RADAR_WIDTH*GFX_SCREEN_PIXEL_WIDTH/GFX_PLAY_WIDTH_PIXELS/2;
	Pixel_Plot(GFX_SCREEN_PIXEL_WIDTH/2-nNipXOff,1);
	Pixel_Plot(GFX_SCREEN_PIXEL_WIDTH/2+nNipXOff,1);
	Pixel_Plot(GFX_SCREEN_PIXEL_WIDTH/2-nNipXOff,RADAR_HEIGHT);
	Pixel_Plot(GFX_SCREEN_PIXEL_WIDTH/2+nNipXOff,RADAR_HEIGHT);
	xRadarOff=GFX_PLAY_WIDTH/2-GFX_PLAY_SCREEN_WIDTH/2;
}

//----------------------------------------------------------------------------

int		Radar_Add(int nGfxNum)
{
	int	nLoop;

	nLoop=0;
	while (nLoop<RADAR_MAX_NUM && Radar[nLoop].nStatus!=RADAR_DEAD)
	{
		nLoop++;
	}
	if (nLoop<RADAR_MAX_NUM && Sprite_Available())
	{
		Radar[nLoop].pSprite=Sprite_Create(nGfxNum,0,GFX_SCREEN_PIXEL_HEIGHT);
		Radar[nLoop].nStatus=RADAR_ON;
	}
	else
	{
		nLoop=RADAR_INVALID;
	}

	return(nLoop);
}

//----------------------------------------------------------------------------

void	Radar_Position(int nNum,FIXEDPT xXCo,FIXEDPT xYCo)
{
	if (nNum>=0 && nNum<RADAR_MAX_NUM)
	{
		Radar[nNum].xXCo=xXCo;
		Radar[nNum].xYCo=xYCo;
	}
}

//----------------------------------------------------------------------------

void	Radar_Remove(int nNum)
{
	if (nNum>=0 && nNum<RADAR_MAX_NUM)
	{
		Radar[nNum].nStatus=RADAR_DESTROY;
	}
}

//----------------------------------------------------------------------------

