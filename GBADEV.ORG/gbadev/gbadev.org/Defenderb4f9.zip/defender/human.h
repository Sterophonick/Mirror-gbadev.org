//-------------------------------------------------------------------------

// humanoid routines
// Rich Heasman July 1997 / May 2002

//-------------------------------------------------------------------------

#include	"gba.h"
#include	"fixedpt.h"

//-------------------------------------------------------------------------

enum
{
	HUMAN_DEAD,							// Human dead
	HUMAN_DESTROY,						// Human destroyed
	HUMAN_ROAMING,						// Human roaming planet surface
	HUMAN_WAITING,						// Human waiting to be picked up
	HUMAN_CAPTURED,						// Human caught by an alien
	HUMAN_DROPING,						// Human falling
	HUMAN_RIDING,						// Human riding on ship
	HUMAN_BONUS_SCREEN					// Human bonus end of wave
};

enum
{
	HUMAN_LANDED,						// Human landed under own steam
	HUMAN_REPLACED,						// Human placed back down
	HUMAN_PICKUP						// Human picked up
};

#define	HUMAN_NEW_NUM		8			// number of new humans created
#define	HUMAN_NOT_PRESENT	-1			// no human near

//-------------------------------------------------------------------------

void		Human_Init(void);
void		Human_Clear(void);
void		Human_New(int nNum);
void		Human_Start(int nSheet);
void		Human_Update(void);
int 		Human_Check(FIXEDPT xPos);
void		Human_Drop(int nHuman);
void		Human_Claim(int nHuman,int nSolider);
void		Human_Pickup(int nHuman,int nSolider);
void		Human_Kill(int nHuman);
void		Human_Landed(int nHuman);
int			Human_Status(int nHuman);
FIXEDPT 	Human_Height(int nHuman);
BOOL		Human_CollisionCheck(FIXEDPT xXCo,FIXEDPT xYCo,FIXEDPT xWidth,FIXEDPT xHeight);
uint		Human_CollisionCheck_IWRAM(u32 *pFuncAddr, FIXEDPT xXCo,FIXEDPT xYCo,FIXEDPT xWidth,FIXEDPT xHeight) CODE_IN_IWRAM;
int			Human_NumAliveGet(void);

//-------------------------------------------------------------------------
