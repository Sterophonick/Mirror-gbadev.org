//-------------------------------------------------------------------------

// Collision routines
// Rich Heasman July 1997 / May 2002

//-------------------------------------------------------------------------

#include	"gba.h"
#include	"fixedpt.h"

//-------------------------------------------------------------------------

BOOL	Collision(FIXEDPT xXCo1,FIXEDPT xYCo1,FIXEDPT xWidth1,FIXEDPT xHeight1,
 				  FIXEDPT xXCo2,FIXEDPT xYCo2,FIXEDPT xWidth2,FIXEDPT xHeight2) CODE_IN_IWRAM;

//-------------------------------------------------------------------------

