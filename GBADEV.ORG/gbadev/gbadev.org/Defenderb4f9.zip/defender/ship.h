//-------------------------------------------------------------------------

// Ship routines
// Rich Heasman July 1997 / May 2002

//-------------------------------------------------------------------------

#include	"gba.h"
#include 	"fixedpt.h"

//-------------------------------------------------------------------------

#define	SHIP_FORWARD		1	  		 
#define	SHIP_BACKWARD   	-SHIP_FORWARD
#define	SHIP_RANDOM_DIR		(Rnd(2) ? SHIP_FORWARD : SHIP_BACKWARD)

//-------------------------------------------------------------------------

void		Ship_Init(void);
void		Ship_Clear(void);
void		Ship_New(void);
void 		Ship_Update(void);
void 		Ship_Render(void);
void 		Ship_ExplosionRender(u32 *pFuncAddr) CODE_IN_IWRAM;
void		Ship_FormingRender(u32 *pFuncAddr) CODE_IN_IWRAM;
void		Ship_Controls(void);
void		Ship_Display(void);
void		Ship_Movement(void);
FIXEDPT		Ship_PosGet(void);
BOOL		Ship_CollisionCheck(FIXEDPT xXCo,FIXEDPT xYCo,FIXEDPT xWidth,FIXEDPT xHeight);
uint		Ship_CollisionCheck_IWRAM(u32 *pFuncAddr,FIXEDPT xXCo,FIXEDPT xYCo,FIXEDPT xWidth,FIXEDPT xHeight) CODE_IN_IWRAM;
void		Ship_Kill(void);
BOOL		Ship_IsDead(void);
FIXEDPT		Ship_PosXGet(void);
FIXEDPT		Ship_PosYGet(void);
FIXEDPT		Ship_SpeedXGet(void);
BOOL		Ship_SmartBombActive(void);

//-------------------------------------------------------------------------
