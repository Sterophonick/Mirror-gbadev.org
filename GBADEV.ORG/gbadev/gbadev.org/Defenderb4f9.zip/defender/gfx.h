//------------------------------------------------------------------------------------

// graphics
// Rich Heasman April 2002

//------------------------------------------------------------------------------------

#include	"gba.h"

#define	GFX_SCREEN_PIXEL_WIDTH		240
#define	GFX_SCREEN_PIXEL_HEIGHT		160
#define	GFX_SCREEN_TILE_WIDTH		(GFX_SCREEN_PIXEL_WIDTH/8)
#define	GFX_SCREEN_TILE_HEIGHT		(GFX_SCREEN_PIXEL_HEIGHT/8)
#define	GFX_TILE_MAP_WIDTH			32

#define	GFX_PLAY_WIDTH_PIXELS		2048		// needs to be a power of 2 for optimisations
#define	GFX_PLAY_HEIGHT_PIXELS		136
#define	GFX_PLAY_WIDTH				(FIXEDPT_UNITS*GFX_PLAY_WIDTH_PIXELS)
#define	GFX_PLAY_HEIGHT				(FIXEDPT_UNITS*GFX_PLAY_HEIGHT_PIXELS)
#define	GFX_PLAY_SCREEN_WIDTH		(FIXEDPT_UNITS*GFX_SCREEN_PIXEL_WIDTH)

//------------------------------------------------------------------------------------

enum
{
	GFX_1D,
	GFX_2D
};

typedef struct
{
	uint	uMode:3;
	uint	uGameBoyColor:1;
	uint	uFlip:1;
	uint	uObjProcessInHBlank:1;
	uint	uSpriteDimension:1;
	uint	uBlankDisplay:1;
	uint	uEnableBG0:1;
	uint	uEnableBG1:1;
	uint	uEnableBG2:1;
	uint	uEnableBG3:1;
	uint	uEnableSprites:1;
	uint	uEnableWin0:1;
	uint	uEnableWin1:1;
	uint	uEnableSpriteWin:1;
} GFX_TYPE;

extern GFX_TYPE	GfxControl;

//------------------------------------------------------------------------------------

void		Gfx_Init(void);
void		Gfx_Update(void);

//------------------------------------------------------------------------------------
