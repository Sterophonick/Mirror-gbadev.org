//------------------------------------------------------------------------

// sound routines
// Rich Heasman May 2002

//------------------------------------------------------------------------

#include	"gba.h"

//---------------------------------------------------------------------

// Definitions

enum 							// sounds defs
{
	SOUNDFX_BLAST,	   	  		// ship fire
	SOUNDFX_BOOM,	   	  		// pod/miner death
	SOUNDFX_BUZZ,  	   	  		// starting buzz
	SOUNDFX_FIZPLODE,	  		// alien death
	SOUNDFX_LASER,	   	  		// human collected
	SOUNDFX_NUKESHIP,     		// ship death
	SOUNDFX_TITLE,	   	  		// beginning drone
	SOUNDFX_SQUEEK,	   	  		// dead human
	SOUNDFX_THRUST,	   			// looping thrust 
	SOUNDFX_WHOOSH,	   	  		// ship form
	SOUNDFX_WOOWIP,	   	  		// human down
	SOUNDFX_WOOWOO,	   	  		// laser human down
	SOUNDFX_ZAPPY,	   	  		// made a mutant
	SOUNDFX_ZIPPYZAP,  	  		// new wave
	SOUNDFX_BLIB, 	 	  		// extra man

	SOUNDFX_MAX
};

enum
{
	SOUNDFX_CHANNEL_A,
	SOUNDFX_CHANNEL_B,

	SOUNDFX_CHANNEL_MAX
};

//---------------------------------------------------------------------

void	SoundFX_Init(void);
void	SoundFX_Update(int nChannel);
void	SoundFX_Make(int nChannel, int nSound);
void	SoundFX_HandlerDMA1(void);
void	SoundFX_HandlerDMA2(void);
void	SoundFX_Stop(int nChannel);
int		SoundFX_Playing(int nChannel);

//---------------------------------------------------------------------


