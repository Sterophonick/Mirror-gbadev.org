//------------------------------------------------------------------------

// debug
// Rich Heasman May 2002

//------------------------------------------------------------------------

#include	"gba.h"

#define	Debug_Display(x)	Debug_DisplayValueInt(#x, (int) x);

void	Debug_Init(void);
void	Debug_Render(void);
void	Debug_DisplayValueInt(char *szName, int nValue);
//-----------------------------------------------------------------------

