//-------------------------------------------------------------------------

// Sheet control
// Rich Heasman July 1997 / May 2002

//-------------------------------------------------------------------------

#include 	"sheet.h"

//----------------------------------------------------------------------------

#define	SHEET_TWICE_AS_DIFFICULT	16
#define	SHEET_NO_MORE_DIFFICULT		50

static const int	nSheetForExtraPod[]={3,7,12,21};
static const int	nSheetForExtraMiner[]={2,4,8,12,16,20};

//----------------------------------------------------------------------------

static	int		nSheetNum;
static	FIXEDPT	xSheetModFactor;

//----------------------------------------------------------------------------

void	Sheet_Start(void)
{
	nSheetNum=0;
	Sheet_Increment();
}

//----------------------------------------------------------------------------

void	Sheet_Increment(void)
{
	nSheetNum++;
	if (nSheetNum>SHEET_NO_MORE_DIFFICULT)
	{
		xSheetModFactor=IntToFixed(SHEET_NO_MORE_DIFFICULT)/SHEET_TWICE_AS_DIFFICULT;
	}
	else
	{
		xSheetModFactor=IntToFixed(nSheetNum-1)/SHEET_TWICE_AS_DIFFICULT;
	}
}

//----------------------------------------------------------------------------

int		Sheet_Number(void)
{
	return(nSheetNum);
}

//----------------------------------------------------------------------------

FIXEDPT	Sheet_ModifiedFixed(FIXEDPT xValue,int nFactor)
{
	return((FIXEDPT)(xValue + FixedMultiply(xValue, xSheetModFactor) * nFactor/128));
}

//----------------------------------------------------------------------------

int		Sheet_ModifiedInt(int nValue,int nFactor)
{
	return((int)(nValue+FixedToInt(nValue * xSheetModFactor * nFactor/128)));
}

//----------------------------------------------------------------------------

int		Sheet_ModifiedTime(int nTime,int nFactor)
{
	int	nModTime;

	nModTime=(int)(nTime-FixedToInt(nTime * xSheetModFactor * nFactor/128));
	if (nModTime<0)
	{
		nModTime=0;
	}

	return(nModTime);
}

//----------------------------------------------------------------------------

#define	SHEET_MAX_PODS	(sizeof(nSheetForExtraPod)/sizeof(nSheetForExtraPod[0]))

int		Sheet_NumOfPods(void)
{
	int	nPods;

	nPods=0;
	while (nPods<SHEET_MAX_PODS && nSheetForExtraPod[nPods]<=nSheetNum)
	{
		nPods++;
	}

	return(nPods);
}

//----------------------------------------------------------------------------

#define	SHEET_MAX_MINERS (sizeof(nSheetForExtraMiner)/sizeof(nSheetForExtraMiner[0]))

int		Sheet_NumOfMiners(void)
{
	int	nMiners;

	nMiners=0;
	while (nMiners<SHEET_MAX_MINERS && nSheetForExtraMiner[nMiners]<=nSheetNum)
	{
		nMiners++;
	}

	return(nMiners);
}

//----------------------------------------------------------------------------
