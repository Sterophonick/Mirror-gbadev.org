//-------------------------------------------------------------------------

// human bonus routines
// Rich Heasman July 1997 / May 2002

//-------------------------------------------------------------------------

#include 	"bonus.h"

#include 	"gfx.h"
#include 	"gfxdata2.h"
#include 	"land.h"
#include 	"human.h"
#include 	"ship.h"
#include 	"soundfx.h"
#include 	"sprite.h"

//-------------------------------------------------------------------------

#define	BONUS_MAX_NUM		HUMAN_NEW_NUM		// Max number of bonus objects

enum
{
	BONUS_DEAD,
	BONUS_DESTROY,
	BONUS_250,
	BONUS_500
};

#define	BONUS_ANIM_RATE		(FIXEDPT)(FIXEDPT_UNITS*0.4)// animation rate
#define	BONUS_LIFE			50				// number of frames bonus visual is active

//-------------------------------------------------------------------------

typedef struct {
	SPRITE_TYPE	*pSprite;			// Object
	FIXEDPT		xXCo;			   	// X position
	FIXEDPT		xYCo;			   	// Y position
	FIXEDPT		xAnim; 				// Animation number
	FIXEDPT		xXSpeed;		   	// X Speed
	int			nAge;			   	// Age of bonus 
	int			nStatus;		   	// Bonus status
} BONUS_TYPE;

static	BONUS_TYPE	Bonus[BONUS_MAX_NUM];

//-------------------------------------------------------------------------

void	Bonus_Init(void)
{
	int	nLoop;

	for (nLoop=0;nLoop<BONUS_MAX_NUM;nLoop++)
	{
		Bonus[nLoop].nStatus=BONUS_DEAD;
	}
}

//-------------------------------------------------------------------------

void	Bonus_Clear(void)
{
	int	nLoop;

	for (nLoop=0;nLoop<BONUS_MAX_NUM;nLoop++)
	{
		if (Bonus[nLoop].nStatus!=BONUS_DEAD)
		{
			Bonus[nLoop].nStatus=BONUS_DESTROY;
		}
	}
}

//-------------------------------------------------------------------------

void	Bonus_Update(void)
{
	int	nLoop;
	int	nX;
	int	nY;

	for (nLoop=0;nLoop<BONUS_MAX_NUM;nLoop++)
	{
		switch(Bonus[nLoop].nStatus)
		{
			case BONUS_DEAD :
			{
				break;
			}
			case BONUS_DESTROY :
			{
				Sprite_Destroy(Bonus[nLoop].pSprite);
				Bonus[nLoop].nStatus=BONUS_DEAD;
				break;
			}
			case BONUS_250 :
			case BONUS_500 :
			{
				Bonus[nLoop].xXCo+=Bonus[nLoop].xXSpeed;
				Bonus[nLoop].xXCo=Land_Boundary(Bonus[nLoop].xXCo);

				Bonus[nLoop].xAnim+=BONUS_ANIM_RATE;
				if (Bonus[nLoop].xAnim>=IntToFixed(GFX_BONUS_FRAMES))
				{
					Bonus[nLoop].xAnim=0;
				}

				if (Bonus[nLoop].nStatus==BONUS_250)
				{
					Sprite_FrameSet(Bonus[nLoop].pSprite,GFX_250S+FixedToInt(Bonus[nLoop].xAnim));
				}
				else
				{
					Sprite_FrameSet(Bonus[nLoop].pSprite,GFX_500S+FixedToInt(Bonus[nLoop].xAnim));
				}
		
				nX=FixedToScreenX(Land_Boundary(Bonus[nLoop].xXCo-Ship_PosGet()),GFX_BONUS_WIDTH);
				nY=FixedToScreenY(Bonus[nLoop].xYCo,0);
				Sprite_PositionSet(Bonus[nLoop].pSprite, nX, nY);

				Bonus[nLoop].nAge++;
				if (Bonus[nLoop].nAge>=BONUS_LIFE)
				{
					Bonus[nLoop].nStatus=BONUS_DESTROY;
				}
				break;
			}
		}
	}
}

//-------------------------------------------------------------------------

void 	Bonus_Create(int nType,FIXEDPT xXCo,FIXEDPT xYCo,FIXEDPT xXSpeed)
{
	int	nLoop;

	nLoop=0;
	while (nLoop<BONUS_MAX_NUM && Bonus[nLoop].nStatus!=HUMAN_DEAD)
	{
		nLoop++;
	}
	if (nLoop<BONUS_MAX_NUM && Sprite_Available())
	{
		switch (nType)
		{
			case HUMAN_LANDED :
			{
				Bonus[nLoop].nStatus=BONUS_250;
				SoundFX_Make(SOUNDFX_CHANNEL_A, SOUNDFX_WOOWIP);
				break;
			}
			case HUMAN_REPLACED :
			{
				Bonus[nLoop].nStatus=BONUS_500;
				SoundFX_Make(SOUNDFX_CHANNEL_A, SOUNDFX_WOOWOO);
				break;
			}
			case HUMAN_PICKUP :
			{
				Bonus[nLoop].nStatus=BONUS_500;
				SoundFX_Make(SOUNDFX_CHANNEL_A, SOUNDFX_LASER);
				break;
			}
		}
		Bonus[nLoop].xXCo=xXCo;
		Bonus[nLoop].xYCo=xYCo+GFX_HUMAN_HEIGHT/2;
		Bonus[nLoop].xAnim=0;
		Bonus[nLoop].xXSpeed=Ship_SpeedXGet()+xXSpeed;
		Bonus[nLoop].nAge=0;
		Bonus[nLoop].pSprite=Sprite_Create(GFX_250S,0,GFX_SCREEN_PIXEL_HEIGHT);
	}
}

//------------------------------------------------------------------------

