//-------------------------------------------------------------------------

// Alien routines
// Rich Heasman July 1997 / May 2002

//-------------------------------------------------------------------------

#include	"gba.h"
#include	"fixedpt.h"

//-------------------------------------------------------------------------

void	Alien_Init(void);
void	Alien_Clear(void);
void	Alien_Update(void);
BOOL	Alien_AllDead(void);
void	Alien_Start(void);
void	Alien_Create(int nType,FIXEDPT xXCo,FIXEDPT xYCo);
void	Alien_SolidersNew(void);
void	Alien_BaiterNew(void);
void	Alien_BaitersKill(void);
void	Alien_SoliderMove(int nNum);
void	Alien_MutantMove(int nNum);
void	Alien_PodMove(int nNum);
void	Alien_SwarmerMove(int nNum);
void	Alien_MinerMove(int nNum);
void	Alien_BaiterMove(int nNum);
FIXEDPT	Alien_HeightGet(int nAlien);
BOOL	Alien_CollisionCheck(FIXEDPT xXCo,FIXEDPT xYCo,FIXEDPT xWidth,FIXEDPT xHeight);
uint 	Alien_CollisionCheck_IWRAM(u32 *pFuncAddr, FIXEDPT xXCo,FIXEDPT xYCo,FIXEDPT xWidth,FIXEDPT xHeight) CODE_IN_IWRAM;
void	Alien_Kill(int nNum);
BOOL	Alien_ShipInRange(int nNum);
void	Alien_RandomlyShoot(int nNum,FIXEDPT xMin,FIXEDPT xMax);
void	Alien_AtShipShoot(int nNum,FIXEDPT xMin,FIXEDPT xMax);

//-------------------------------------------------------------------------
