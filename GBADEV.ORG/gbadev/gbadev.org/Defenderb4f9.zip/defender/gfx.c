//------------------------------------------------------------------------------------

// graphics 
// Rich Heasman April 2002

//------------------------------------------------------------------------------------

#include "gba.h"
#include "gfx.h"

#include "vblank.h"
#include "profile.h"
#include "background.h"
#include "sprite.h"

// VRAM Memory map : blocks x800 (slots 0 to 31)
// 0 - 5 		 : gfxdata1 tiles
// 8 - 27		 : bitmap tiles
// 28,29 		 : front and back for bg 0 (text)
// 30,31		 : front and back for bg 1 (display)

GFX_TYPE	GfxControl;

//------------------------------------------------------------------------------------

void	Gfx_Init(void)
{
	GfxControl.uMode = 0;
	GfxControl.uGameBoyColor = 0;
	GfxControl.uFlip = 0;
	GfxControl.uObjProcessInHBlank = 0;
	GfxControl.uSpriteDimension = GFX_2D;
	GfxControl.uBlankDisplay = 1;
	GfxControl.uEnableBG0 = 0;
	GfxControl.uEnableBG1 = 0;
	GfxControl.uEnableBG2 = 0;
	GfxControl.uEnableBG3 = 0;
	GfxControl.uEnableSprites = 0;
	GfxControl.uEnableWin0 = 0;
	GfxControl.uEnableWin1 = 0;
	GfxControl.uEnableSpriteWin = 0;

	Background_Init();
	Sprite_Init();
}

//------------------------------------------------------------------------------------

void	Gfx_Update(void)
{
	GfxControl.uBlankDisplay = 0;
	R_DISCNT = *(u16 *) &GfxControl;

	VBlank_Wait();
	Profile_Point("Post VBlank");

	Sprite_Render();

 	Background_FlipBufferView(BACKGROUND_TEXT);			
	Background_Update(BACKGROUND_TEXT);
	Background_FlipBufferWrite(BACKGROUND_TEXT);

	Background_Update(BACKGROUND_DISPLAY);

	Background_ScreenClear(BACKGROUND_TEXT);
}

//------------------------------------------------------------------------------------
