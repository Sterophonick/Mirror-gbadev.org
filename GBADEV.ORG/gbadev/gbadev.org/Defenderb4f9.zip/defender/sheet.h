//-------------------------------------------------------------------------

// Sheet control
// Rich Heasman July 1997 / May 2002

//-------------------------------------------------------------------------

#include	"fixedpt.h"

//-------------------------------------------------------------------------

void	Sheet_Start(void);
void	Sheet_Increment(void);
int		Sheet_Number(void);
FIXEDPT	Sheet_ModifiedFixed(FIXEDPT xValue,int nFactor);
int		Sheet_ModifiedInt(int nValue,int nFactor);
int		Sheet_ModifiedTime(int nTime,int nFactor);
int		Sheet_NumOfPods(void);
int		Sheet_NumOfMiners(void);

//-------------------------------------------------------------------------
