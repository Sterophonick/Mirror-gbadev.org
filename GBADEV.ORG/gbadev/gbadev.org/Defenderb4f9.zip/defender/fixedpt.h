//-------------------------------------------------------------------------

// Fixed point type definition
// Rich Heasman July 1997 / May 2002

//-------------------------------------------------------------------------

#ifndef _FIXEDPT_H
#define _FIXEDPT_H

#include	"gba.h"

//-------------------------------------------------------------------------

// Definitions for variables with 16.16 fixed point long format 
//	(whole.fraction)

typedef	long		FIXEDPT;

#define	FIXEDPT_UNITS			(1L<<16)
#define	FixedToInt(a)			((int)((a)>>16))
#define	IntToFixed(a)			((FIXEDPT)(a)<<16)
#define	FixedRnd(a,b)			(a+(b-(a))*Rnd(256)/256)
#define	FixedToScreenY(a,b)		(GFX_SCREEN_PIXEL_HEIGHT-FixedToInt(a-(b)/2))
#define	FixedToScreenX(a,b) 	FixedToInt((a)-(b)/2)
#define	FixedMultiply(a,b)		((a>>8)*(b>>8))

//-------------------------------------------------------------------------

#endif // _FIXEDPT_H

