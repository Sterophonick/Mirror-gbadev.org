//---------------------------------------------------------

// gba.h     
// Rich Heasman April 2002
// from version HAM (v1.40) by tubooboo@ngine.de

//------------------------------------------------------------------------------------

#ifndef _GBA_H
#define _GBA_H

//------------------------------------------------------------------------------------

// types

typedef     unsigned char           u8;
typedef     unsigned short int      u16;
typedef     unsigned int            u32;
typedef     unsigned long long int  u64;

typedef     unsigned int            uint;
typedef     unsigned char           uchar;
typedef		unsigned int			BOOL;

// defs

#define	NULL	((void *) 0)
#define TRUE 	1
#define FALSE 	0

//------------------------------------------------------------------------------------

// multiboot def for linker

#define MULTIBOOT volatile const int __gba_multiboot;  // enable/disable GBA multiboot

//------------------------------------------------------------------------------------

// linker options for internal RAM usage

extern u32 __FarFunction (u32 (*ptr)(), ...); 
extern void __FarProcedure (void (*ptr)(), ...);

#define CODE_IN_EWRAM __attribute__ ((section (".ewram")))
#define CODE_IN_IWRAM __attribute__ ((section (".iwram")))
#define VAR_IN_EWRAM __attribute__ ((section (".ewram"))) = {0}
#define VAR_IN_IWRAM __attribute__ ((section (".iwram"))) = {0}

//------------------------------------------------------------------------------------

// Memory locations

#define MEM_SYSROM				0x00000000	// System ROM, for BIOS Calls
#define MEM_EXRAM				0x02000000	// External WRAM, slow, also used for Multiboot uploads
#define MEM_RAM					0x03000000	// Fast CPU internal RAM
#define MEM_IO					0x04000000	// Register Base, all HW Registers are in here.
#define MEM_PAL					0x05000000	// Palette Base
#define MEM_PAL_BG				0x05000000	// Palette for BG
#define MEM_PAL_OBJ				0x05000200	// Palette for OBJ
#define MEM_VRAM				0x06000000	// GBA Video RAM
#define MEM_BG			    	0x06000000	// GBA Video RAM (in BG mode)
#define MEM_OBJ             	0x06010000  // OBJ memoryspace (32 kBytes)
#define MEM_OAM					0x07000000	// Object control space for sprites
#define MEM_ROM0				0x08000000	// Rom Space 0 (fastest, 0 wait)
#define MEM_ROM1				0x0A000000	// Rom Space 1 (1 wait)
#define MEM_ROM2				0x0C000000	// Rom Space 2 (slowest, 2 wait)
#define MEM_SRAM				0x0E000000	// Gamepak SRAM, if any.

#define MEM_SYSROM_SIZE		    0x00004000
#define MEM_EXRAM_SIZE		    0x00040000
#define MEM_RAM_SIZE		    0x00008000
#define MEM_PAL_SIZE		    0x00000400
#define MEM_VRAM_SIZE		    0x00018000
#define MEM_BG_MODE0_SIZE		0x00010000
#define MEM_BG_MODE1_SIZE		0x00010000
#define MEM_BG_MODE2_SIZE		0x00010000
#define MEM_BG_MODE3_BUFSIZE    0x00014000
#define MEM_BG_MODE4_BUFSIZE    0x0000A000
#define MEM_BG_MODE5_BUFSIZE    0x0000A000
#define MEM_BG_SIZE		        0x00010000
#define MEM_BG_SIZE		        0x00010000
#define MEM_OBJ_SIZE            0x00008000
#define MEM_OAM_SIZE		    0x00000400
#define MEM_ROM0_SIZE		    0x02000000
#define MEM_ROM1_SIZE		    0x02000000
#define MEM_ROM2_SIZE		    0x02000000
#define MEM_SRAM_SIZE		    0x00010000

//---------------------------------------------------------------------------------

// Regs

#define R_DISCNT		*(volatile u16 *) MEM_IO 					// Display Control register
#define R_DISSTAT		*(volatile u16 *)(MEM_IO + 0x04)			// Display Status register
#define R_VCNT			*(volatile u16 *)(MEM_IO + 0x06)			// Vertical counter(0-227)
#define R_BGXCNT(x)     *(volatile u16 *)(MEM_IO + 8 +(x*2))		// background conrol (0-3)
#define R_BGXSCRLX(x)   *(volatile u16 *)(MEM_IO + 0x10 + (x*4))	// background x scroll (0-3)
#define R_BGXSCRLY(x)   *(volatile u16 *)(MEM_IO + 0x12 + (x*4))	// background y scroll (0-3)
#define R_BLDCNT		*(volatile u16 *)(MEM_IO + 0x50)			// Blend Control
#define R_BLDALPHA		*(volatile u16 *)(MEM_IO + 0x52)			// Blend Alpha
#define R_BLDY			*(volatile u16 *)(MEM_IO + 0x54)			// Blend Amount
#define R_SNDCNT2		*(volatile u16 *)(MEM_IO + 0x82)			// Direct sound control
#define R_SNDCNT3		*(volatile u16 *)(MEM_IO + 0x84)			// Master Sound Control
#define R_TIMER0		*(volatile u32 *)(MEM_IO + 0x100)			// Timer 0
#define R_CTRLINPUT		*(volatile u16 *)(MEM_IO + 0x130)			// Control Input
#define R_INTENA		*(volatile u16 *)(MEM_IO + 0x200)			// Int Enable
#define R_INTREQ		*(volatile u16 *)(MEM_IO + 0x202)			// Int Request
#define R_INTMST		*(volatile u16 *)(MEM_IO + 0x208)			// Int Enable Master

//---------------------------------------------------------------------------------

// addresses

#define MEM_CBB(x)   	(MEM_VRAM + (x*0x4000))			// character VRAM address
#define MEM_SBB(x)   	(MEM_VRAM + (x*0x800))			// screen VRAM address
#define MEM_SNDFIFO_A	(MEM_IO + 0xA0)					// Sound FIFO A
#define MEM_SNDFIFO_B	(MEM_IO + 0xA4)					// Sound FIFO B
#define MEM_DMABASE		(MEM_IO + 0x0B0)				// DMA Control Base

//---------------------------------------------------------------------------------

// End of the file.

#endif GBA_H