//------------------------------------------------------------------------------------

// background
// Rich Heasman May 2002

//------------------------------------------------------------------------------------

#include	"gba.h"

enum
{
	BACKGROUND_TEXT,				// text
	BACKGROUND_DISPLAY,				// logo

	BACKGROUND_MAX
};

#define C_BGXCNT_SCRSIZE_256X256 0x00
#define C_BGXCNT_SCRSIZE_512X256 0x01
#define C_BGXCNT_SCRSIZE_256X512 0x02
#define C_BGXCNT_SCRSIZE_512X512 0x03

//---------------------------------------------------------------------------------
enum
{
	BACKGROUND_256X256,
	BACKGROUND_512X256,
	BACKGROUND_256X512,
	BACKGROUND_512X512
};

//------------------------------------------------------------------------------------

typedef struct
{
    uint  	uPriority:2;    		// 0=front,3=back,(sprites go on top)
    uint  	uCbb:2;        			// character base block
	uint	uPalette:2;				// something to do with palette select
    uint  	uMosaic:1;				// mosaic effect
    uint  	uColmode:1;    			// 0=16 pals 1=1 pal
    uint  	uSbb:5;   	   			// current screen base to write to
	uint	uRepeat:1;				// repeat multiple when scaled
    uint  	uMapsize:2;    			// size of map data (0: 256x256 to 3:512x512)

    uint  	uActive:1;				// active
    uint  	uBufferWrite:1;			// current buffer view 0/1
    uint  	uBufferView:1;			// current buffer write 0/1
    uint  	uSbbBase:5;    			// screen base block

	uint	uMapLength;				// map length in words
	int		nScrollX;				// scroll position
	int		nScrollY;				// scroll position
	BOOL	boFlipView;				// screen flip required this frame
} BACKGROUND_TYPE;


//------------------------------------------------------------------------------------

void 		Background_Init(void);

void 		Background_Setup(uint uBackground);
u16			*Background_SbbPtr(uint uBackground);
void		Background_SetScreen(uint uBackground, u16 nTileIndex);
void		Background_ScreenClear(uint uBackground);

void		Background_SetAll(uint uBackground, u16 nTileIndex);
void		Background_ScrollSet(uint uBackground, int nX, int nY);

void		Background_Update(uint uBackground);
void		Background_FlipBufferWrite(uint uBackground);
void		Background_FlipBufferView(uint uBackground);
void		Background_LoadVram(void);

u16			Background_TileFromGraphic(u16 uGraphic);
void		Background_Font1Print(int nXCo, int nYCo, char *szMessage);
void		Background_Font2Print(int nXCo, int nYCo, char *szMessage);

void		Background_ShowFE(void);

//------------------------------------------------------------------------------------
