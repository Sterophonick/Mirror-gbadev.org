//-------------------------------------------------------------------------

// Ship routines
// Rich Heasman July 1997 / May 2002

//-------------------------------------------------------------------------

#include 	"ship.h"

#include 	"fixedpt.h"
#include 	"gfx.h"
#include 	"gfxdata2.h"
#include 	"land.h"
#include 	"laser.h"
#include 	"soundfx.h"
#include 	"collide.h"
#include 	"radar.h"
#include 	"rnd.h"
#include 	"player.h"
#include 	"palette.h"
#include	"timer.h"
#include	"button.h"
#include 	"pixel.h"
#include 	"sprite.h"
#include 	"debug.h"

//-------------------------------------------------------------------------

#define	SHIP_XCO_INDENT		(GFX_PLAY_SCREEN_WIDTH/7)	// X indent from edge
#define	SHIP_YCO_START	  	(GFX_PLAY_HEIGHT/2)			// Start Y Co
#define	SHIP_Y_SPEED		(FIXEDPT_UNITS*3) 			// units pixels per frame Y movement for ship
#define	SHIP_SWAP_SPEED		(FIXEDPT_UNITS*5) 			// units pixels per frame direction swap
#define	SHIP_MAX_SPEED		(FIXEDPT_UNITS*10)			// units pixel per frame movement for ship
#define	SHIP_ACCELERATION	(FIXEDPT)(FIXEDPT_UNITS*0.18) // units pixel increase per frame 
#define	SHIP_DECELERATION	(FIXEDPT)(FIXEDPT_UNITS*0.08) // units pixel decrease per frame 

#define	SHIP_DEATH_LENGTH	32							// length of death sequence 
#define	SHIP_FORMING_LENGTH	16							// length of form sequence
#define	SHIP_FRAG_NUM		128							// number of death fragments
#define	SHIP_FORM_NUM		64							// number of forming fragments
#define	SHIP_FRAG_DIST		(GFX_PLAY_HEIGHT*2)			// maximum distance of fragment in pixels
#define	SHIP_FORM_DIST		(GFX_PLAY_HEIGHT/2)			// maximum distance of forming in pixels
#define	SHIP_SMART_BOMB_LEN	4							// length of smart bomb visual

enum
{
	SHIP_FORMING_INIT,
	SHIP_FORMING,	  
	SHIP_ALIVE,		  
	SHIP_DEAD,		  
	SHIP_HYPERSPACE,  
	SHIP_SMART_BOMB,  
	SHIP_DEATH,		  
	SHIP_DEATH_VISUAL_GAP,
	SHIP_DEATH_VISUAL 
};

//-------------------------------------------------------------------------

typedef struct {
	SPRITE_TYPE	*pSprite;			// ship object
	FIXEDPT		xLand;				// left side of screen 
	FIXEDPT		xSpeed; 			// ship speed
	FIXEDPT		xYCo;				// top edge of ship object
	FIXEDPT		xXCo;				// x offset from land to ship centre
	FIXEDPT		xXPos;				// ship x position
	int			nDir;				// ship direction
	int			nAnim;				// animation entry number
	int			nStatus;			// ship status
	int			nRadar;				// radar entry
	uint		uImmortalTimer;		// can't be killed until timer mature
	uint		uMoveTimer;			// can't move until timer mature
} SHIP_TYPE;

typedef struct {
	FIXEDPT	xXCo;
	FIXEDPT	xYCo;
	int		nColour;
} FRAGMENT_TYPE;

//-------------------------------------------------------------------------

static	SHIP_TYPE	Ship;
static	int			nThrust;
static	FRAGMENT_TYPE	Fragment[SHIP_FRAG_NUM];
static	BOOL		bSmartButtonDebounced;

//----------------------------------------------------------------------------

void	Ship_Init(void)
{
	Ship.pSprite=Sprite_Create(GFX_SHIP_FOR,0,GFX_SCREEN_PIXEL_HEIGHT);
	bSmartButtonDebounced=TRUE;
}

//----------------------------------------------------------------------------

void	Ship_Clear(void)
{
	if (Ship.nStatus==SHIP_SMART_BOMB)
	{
		Palette_Copy(COLOUR_BACKGROUND,COLOUR_BLACK_2);
	}
	Ship.nStatus=SHIP_DEAD;
	SoundFX_Stop(SOUNDFX_CHANNEL_B);
}

//----------------------------------------------------------------------------

void	Ship_New(void)
{
	Ship.xLand=IntToFixed(Rnd(GFX_PLAY_WIDTH_PIXELS));
	Ship.xSpeed=0;
	Ship.xYCo=SHIP_YCO_START;
	Ship.xXCo=SHIP_XCO_INDENT;
	Ship.nDir=SHIP_FORWARD;
	Ship.nRadar=Radar_Add(GFX_WHITE_RADAR);
	Radar_Position(Ship.nRadar,Ship.xLand+Ship.xXCo,Ship.xYCo);
	Timer_Set(&Ship.uImmortalTimer,1*60);
	Timer_Set(&Ship.uMoveTimer,0);
	Ship.nStatus=SHIP_FORMING_INIT;
}

//----------------------------------------------------------------------------

void 	Ship_Update(void)
{
	int	nLoop;

	switch (Ship.nStatus)
	{
		case SHIP_FORMING_INIT :
		{
			Ship.nAnim=0;
			for (nLoop=0;nLoop<SHIP_FORM_NUM;nLoop++)
			{
				Fragment[nLoop].nColour=COLOUR_WHITE;
				Fragment[nLoop].xXCo=(FIXEDPT)(SHIP_FORM_DIST*((int)Rnd(128)-64)/128);
				Fragment[nLoop].xYCo=(FIXEDPT)(SHIP_FORM_DIST*((int)Rnd(128)-64)/128);
			}
			SoundFX_Make(SOUNDFX_CHANNEL_A, SOUNDFX_WHOOSH);
			Ship.nStatus=SHIP_FORMING;
			break;
		}
		case SHIP_FORMING :
		{
			Ship.nAnim++;
			if (Ship.nAnim >= SHIP_FORMING_LENGTH * 2)
			{
				Ship.nStatus = SHIP_ALIVE;
			}
			break;
		}
		case SHIP_ALIVE :
		{
			if (Timer_Mature(&Ship.uMoveTimer))
			{
				Ship_Controls();
			}
			Ship_Movement();
			break;
		}
		case SHIP_DEATH :
		{
			Ship.nAnim=0;
			for (nLoop=0;nLoop<SHIP_FRAG_NUM;nLoop++)
			{
				Fragment[nLoop].xXCo=(FIXEDPT)(SHIP_FRAG_DIST*((int)Rnd(128)-64)/128);
				Fragment[nLoop].xYCo=(FIXEDPT)(SHIP_FRAG_DIST*((int)Rnd(128)-64)/128);
				Fragment[nLoop].nColour=Rnd(COLOUR_DARK_BLUE - COLOUR_BLACK) + COLOUR_DARK_GREEN;
			}
			SoundFX_Make(SOUNDFX_CHANNEL_A, SOUNDFX_NUKESHIP);
			Radar_Remove(Ship.nRadar);

			Ship.nStatus=SHIP_DEATH_VISUAL_GAP;
			break;
		}
		case SHIP_DEATH_VISUAL_GAP :
		{
			Ship.nStatus=SHIP_DEATH_VISUAL;		// hack to prevent particles getting left when ship collides with last alien
			break;
		}
		case SHIP_DEATH_VISUAL :
		{
			Ship.nAnim++;
			if (Ship.nAnim>=SHIP_DEATH_LENGTH*2)
			{
				Ship.nStatus=SHIP_DEAD;
			}
			break;
		}
		case SHIP_DEAD :
		{
			break;
		}
		case SHIP_HYPERSPACE :
		{
			Ship_Movement();
			Ship.xLand = FIXEDPT_UNITS*Rnd(GFX_PLAY_WIDTH_PIXELS);
			Ship.xYCo = SHIP_YCO_START;
			Ship.xSpeed = 0;
			Timer_Set(&Ship.uMoveTimer, 1*60);
			Radar_Position(Ship.nRadar,Ship.xLand+Ship.xXCo,Ship.xYCo);
			Ship.nStatus = SHIP_FORMING_INIT;
			break;
		}
		case SHIP_SMART_BOMB :
		{
			Ship_Movement();
			if (Ship.nAnim==0)
			{
				Palette_Copy(COLOUR_BACKGROUND,COLOUR_WHITE);
			}
			if (Ship.nAnim>=SHIP_SMART_BOMB_LEN)
			{
				Palette_Copy(COLOUR_BACKGROUND,COLOUR_BLACK_2);
				Ship.nStatus=SHIP_ALIVE;
			}
			Ship.nAnim++;
			break;
		}
	}
}

//----------------------------------------------------------------------------

void 	Ship_Render(void)
{
	if (Ship.nStatus == SHIP_FORMING)
	{
		__FarProcedure(Ship_FormingRender);
	}
	if (Ship.nStatus == SHIP_DEATH_VISUAL)
	{
		__FarProcedure(Ship_ExplosionRender);
	}
	Ship_Display();
}	

//----------------------------------------------------------------------------

// optimised by pulling in pixel function

void	Ship_ExplosionRender(u32 *pFuncAddr)
{
	int		nLoop;
	int		nXFrag,nYFrag;
	u8		*pDest;
	u16		uPrevious;
	u16		uColour;

	for (nLoop=0;nLoop<SHIP_FRAG_NUM;nLoop++)
	{
		nXFrag=FixedToScreenX((Fragment[nLoop].xXCo/SHIP_DEATH_LENGTH*(Ship.nAnim%SHIP_DEATH_LENGTH)+Ship.xXCo),0);
		nYFrag=FixedToScreenY((Fragment[nLoop].xYCo/SHIP_DEATH_LENGTH*(Ship.nAnim%SHIP_DEATH_LENGTH)+Ship.xYCo),GFX_SHIP_HEIGHT);
		if (nXFrag>=0 && nXFrag<GFX_SCREEN_PIXEL_WIDTH && nYFrag>GFX_SCREEN_PIXEL_HEIGHT-GFX_PLAY_HEIGHT_PIXELS && nYFrag<GFX_SCREEN_PIXEL_HEIGHT)
		{
			uColour = Fragment[nLoop].nColour;
			pDest = pPixelDestX[nXFrag];
			pDest += nPixelOffsetY[nYFrag];
			uPrevious = *(u16 *) pDest;
			if (nXFrag & 1)	*(u16 *)pDest = uPrevious ^ (uColour << 8);
			else 		   	*(u16 *)pDest = uPrevious ^ uColour;
		}
	}
}	

//----------------------------------------------------------------------------

// optimised by pulling in pixel function

void	Ship_FormingRender(u32 *pFuncAddr)
{			    
	int		nLoop;
	int		nXFrag,nYFrag;
	u8		*pDest;
	u16		uPrevious;
	u16		uColour;

	for (nLoop=0;nLoop<SHIP_FORM_NUM;nLoop++)
	{
		nXFrag=FixedToScreenX((Fragment[nLoop].xXCo/SHIP_FORMING_LENGTH*(SHIP_FORMING_LENGTH-Ship.nAnim%SHIP_FORMING_LENGTH)+Ship.xXCo),0);
		nYFrag=FixedToScreenY((Fragment[nLoop].xYCo/SHIP_FORMING_LENGTH*(SHIP_FORMING_LENGTH-Ship.nAnim%SHIP_FORMING_LENGTH)+Ship.xYCo),GFX_SHIP_HEIGHT);
		if (nXFrag>=0 && nXFrag<GFX_SCREEN_PIXEL_WIDTH && nYFrag>GFX_SCREEN_PIXEL_HEIGHT-GFX_PLAY_HEIGHT_PIXELS && nYFrag<GFX_SCREEN_PIXEL_HEIGHT)
		{
			uColour = Fragment[nLoop].nColour;
			pDest = pPixelDestX[nXFrag];
			pDest += nPixelOffsetY[nYFrag];
			uPrevious = *(u16 *) pDest;
			if (nXFrag & 1)	*(u16 *)pDest = uPrevious ^ (uColour << 8);
			else 		   	*(u16 *)pDest = uPrevious ^ uColour;
		}
	}
}	

//----------------------------------------------------------------------------

void	Ship_Movement(void)
{
	if (nThrust*Ship.xSpeed<=0)
	{
		if (Ship.xSpeed>0)
		{
			Ship.xSpeed-=SHIP_DECELERATION;
			if (Ship.xSpeed<0)
			{
				Ship.xSpeed=0;
			}
		}
		else
		{
			Ship.xSpeed+=SHIP_DECELERATION;
			if (Ship.xSpeed>0)
			{
				Ship.xSpeed=0;
			}
		}
	}
	if (Ship.nDir==SHIP_FORWARD && Ship.xXCo-SHIP_SWAP_SPEED>SHIP_XCO_INDENT)
	{
		Ship.xXCo-=SHIP_SWAP_SPEED;
		Ship.xLand+=SHIP_SWAP_SPEED;
	}
	if (Ship.nDir==SHIP_BACKWARD && Ship.xXCo+SHIP_SWAP_SPEED<GFX_PLAY_SCREEN_WIDTH-SHIP_XCO_INDENT-GFX_SHIP_WIDTH)
	{
		Ship.xXCo+=SHIP_SWAP_SPEED;
		Ship.xLand-=SHIP_SWAP_SPEED;
	}
	Ship.xLand=Land_Boundary(Ship.xLand+Ship.xSpeed);

	if (nThrust)
	{
		if (SoundFX_Playing(SOUNDFX_CHANNEL_B) != SOUNDFX_THRUST)
		{
			SoundFX_Make(SOUNDFX_CHANNEL_B, SOUNDFX_THRUST);
		}
	}
	else
	{
		if (SoundFX_Playing(SOUNDFX_CHANNEL_B) == SOUNDFX_THRUST)
		{
			SoundFX_Stop(SOUNDFX_CHANNEL_B);
		}
	}
}

//----------------------------------------------------------------------------

void	Ship_Display(void)
{
	int	nX;
	int	nY;

	if (Ship.nDir==SHIP_FORWARD)
	{
		Sprite_FrameSet(Ship.pSprite,GFX_SHIP_FOR);
		nX=FixedToScreenX(Ship.xXCo,GFX_SHIP_WIDTH);
	}
	else
	{
		Sprite_FrameSet(Ship.pSprite,GFX_SHIP_REV);
		nX=FixedToScreenX(Ship.xXCo,GFX_SHIP_WIDTH);
	}
	if (Ship.nStatus!=SHIP_ALIVE)
	{
		nY=GFX_SCREEN_PIXEL_HEIGHT;
	}
	else
	{
		nY=FixedToScreenY(Ship.xYCo,0);
		Radar_Position(Ship.nRadar,Ship.xLand+Ship.xXCo,Ship.xYCo);
	}
	Sprite_PositionSet(Ship.pSprite, nX, nY);
}

//----------------------------------------------------------------------------

void	Ship_Controls(void)
{
	nThrust=0;
   	if ((Button_Pressed(BUTTON_UP))
     && (Ship.xYCo+SHIP_Y_SPEED<GFX_PLAY_HEIGHT))
   	{
   		Ship.xYCo+=SHIP_Y_SPEED;
   	}
   	if ((Button_Pressed(BUTTON_DOWN))
   	 && (Ship.xYCo-SHIP_Y_SPEED-GFX_SHIP_HEIGHT>0))
   	{
   		Ship.xYCo-=SHIP_Y_SPEED;
   	}

	if (Button_Pressed(BUTTON_RIGHT))
	{
		if (Ship.xSpeed+SHIP_ACCELERATION<SHIP_MAX_SPEED)
		{
			Ship.xSpeed+=SHIP_ACCELERATION;
		}
		Ship.nDir=SHIP_FORWARD;
		nThrust=SHIP_FORWARD;
	}
	if (Button_Pressed(BUTTON_LEFT))
	{
		if (Ship.xSpeed-SHIP_ACCELERATION>-SHIP_MAX_SPEED)
		{
			Ship.xSpeed-=SHIP_ACCELERATION;
		}
		Ship.nDir=SHIP_BACKWARD;
		nThrust=SHIP_BACKWARD;
	}
	if (Button_Pressed(BUTTON_A))
	{
		if (Ship.nDir==SHIP_FORWARD)
		{
			Laser_Fire(Ship.xLand+Ship.xXCo+Ship.xSpeed+GFX_SHIP_WIDTH/2+FIXEDPT_UNITS,Ship.xYCo-GFX_SHIP_GUN,Ship.nDir);
		}
		else
		{
			Laser_Fire(Ship.xLand+Ship.xXCo+Ship.xSpeed-GFX_SHIP_WIDTH/2-2*FIXEDPT_UNITS,Ship.xYCo-GFX_SHIP_GUN,Ship.nDir);
		}
	}
	if (Ship.nStatus!=SHIP_HYPERSPACE && Button_Pressed(BUTTON_L))
	{
		Ship.nStatus=SHIP_HYPERSPACE;
		Ship.nAnim=0;
	}
	if (Player_SmartLeft()>0 && Ship.nStatus!=SHIP_SMART_BOMB)
	{
		if (Button_Pressed(BUTTON_R))
		{
			if (bSmartButtonDebounced)
			{
				Player_SmartRemove();
				Ship.nStatus=SHIP_SMART_BOMB;
				Ship.nAnim=0;
				bSmartButtonDebounced=FALSE;
			}
		}
		else
		{
			bSmartButtonDebounced=TRUE;
		}
	}
}

//----------------------------------------------------------------------------

FIXEDPT	Ship_PosGet(void)
{
	return(Ship.xLand);
}

//----------------------------------------------------------------------------

BOOL 	Ship_CollisionCheck(FIXEDPT xXCo,FIXEDPT xYCo,FIXEDPT xWidth,FIXEDPT xHeight)
{
	BOOL	bHit;

	Ship.xXPos = Land_Boundary(Ship.xLand+Ship.xXCo);
	bHit = __FarFunction(Ship_CollisionCheck_IWRAM, xXCo, xYCo, xWidth, xHeight);

	return(bHit);
}

//----------------------------------------------------------------------------

uint	Ship_CollisionCheck_IWRAM(u32 *pFuncAddr, FIXEDPT xXCo,FIXEDPT xYCo,FIXEDPT xWidth,FIXEDPT xHeight)
{
	return((Collision(xXCo,xYCo,xWidth,xHeight, Ship.xXPos, Ship.xYCo,GFX_SHIP_WIDTH,GFX_SHIP_HEIGHT)));
}

//----------------------------------------------------------------------------

void	Ship_Kill(void)
{
	if (Ship.nStatus==SHIP_ALIVE
	 && Timer_Mature(&Ship.uImmortalTimer))	
	{
		SoundFX_Stop(SOUNDFX_CHANNEL_B);
		Ship.nStatus=SHIP_DEATH;
	}
}

//----------------------------------------------------------------------------

BOOL	Ship_IsDead(void)
{
	return(Ship.nStatus==SHIP_DEAD||Ship.nStatus==SHIP_DEATH_VISUAL);
}

//----------------------------------------------------------------------------

FIXEDPT	Ship_PosXGet(void)
{
	return(Land_Boundary(Ship.xLand+Ship.xXCo));
}

//----------------------------------------------------------------------------

FIXEDPT	Ship_PosYGet(void)
{
	return(Ship.xYCo);
}

//----------------------------------------------------------------------------

FIXEDPT	Ship_SpeedXGet(void)
{
	return(Ship.xSpeed);
}

//----------------------------------------------------------------------------

BOOL	Ship_SmartBombActive(void)
{
	return(Ship.nStatus==SHIP_SMART_BOMB);
}

//----------------------------------------------------------------------------
