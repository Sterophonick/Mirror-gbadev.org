//-------------------------------------------------------------------------

// Score values
// Rich Heasman July 1997 / May 2002

//-------------------------------------------------------------------------

// scores for killing baddies

#define	SCORE_SOLIDER		150
#define	SCORE_MUTANT		150
#define	SCORE_MINER			100
#define	SCORE_POD			1000
#define	SCORE_SWARMER		250		
#define	SCORE_HUMAN			500		// pick up or put down human
#define	SCORE_HUMAN_DROP	250		// human drops to surface
#define	SCORE_BAITER		150		

#define	SCORE_EXTRA_SHIP	10000	// extra ship and smart after this score
#define	SCORE_MAXIMUM		999999 	// maximum score allowed
#define	SCORE_BLANK_STRING	"000000"
#define	SCORE_END_BONUS		100		// end of wave bonus per wave per human
#define	SCORE_BONUS_MAX		500		// max end of wave bonus

//-------------------------------------------------------------------------
