//------------------------------------------------------------------------

// mem
// Rich Heasman May 2002

//------------------------------------------------------------------------

#include	"gba.h"
#include	"mem.h"

#include	"dma.h"

//------------------------------------------------------------------------

// Bug: writes dwords (upto 3 bytes over end)

//------------------------------------------------------------------------

void	Mem_Copy(u32 *pDest, u32 *pSrc, uint uSize)
{
	DMA_TYPE	Dma;
	uint		uCount;

	uCount = (uSize + 3) / 4;

	Dma.uSrc = (uint) pSrc;
	Dma.uDest = (uint) pDest;
	Dma.uCount = uCount;
	Dma.uDestInc = DMA_INC;
	Dma.uSrcInc = DMA_INC;
	Dma.uSize = DMA_32_BIT;
	Dma.uMode = DMA_NOW;
	Dma.uRepeat = 0;
	Dma.uInterrupt = 0;
	Dma.uEnable = 1;
	Dma_Set(3,&Dma);

// non-dma version (if non-dma function used then move to IWRAM)
//	while (uCount > 0)
//	{
//		*pDest++ = *pSrc++;
//		uCount--;
//	}

}	

//------------------------------------------------------------------------

void	Mem_Set(u32 *pDest, u8 uValue, uint uSize)
{
	DMA_TYPE	Dma;
	uint 		uCount;
	uint 		uValueCombined;

	uCount = (uSize + 3) / 4;
	uValueCombined = uValue + (uValue << 8) + (uValue << 16) + (uValue << 24);

	Dma.uSrc = (uint) &uValueCombined;
	Dma.uDest = (uint) pDest;
	Dma.uCount = uCount;
	Dma.uDestInc = DMA_INC;
	Dma.uSrcInc = DMA_LEAVE;
	Dma.uSize = DMA_32_BIT;
	Dma.uMode = DMA_NOW;
	Dma.uRepeat = 0;
	Dma.uInterrupt = 0;
	Dma.uEnable = 1;
	Dma_Set(3,&Dma);

// non-dma version (if non-dma function used then move to IWRAM)
//	while (uCount > 0)
//	{
//		*pDest++ = uValueCombined;
//		uCount--;
//	}

}	

//-----------------------------------------------------------------------
