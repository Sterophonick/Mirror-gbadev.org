//------------------------------------------------------------------------------------

// pixel ops on a tile based background, (almost mode 4 but allows multiple backgrounds)
// Rich Heasman May 2002

//------------------------------------------------------------------------------------

#include	"gba.h"
#include	"pixel.h"

#include	"gfx.h"
#include	"palette.h"
#include	"button.h"
#include	"debug.h"

//------------------------------------------------------------------------------------

u8 *	pPixelDestX[GFX_SCREEN_PIXEL_WIDTH];
u16		nPixelOffsetY[GFX_SCREEN_PIXEL_HEIGHT];

static u8		*pPixelScreen;
static uint		uPixelColour;
static uint		uPixelColourHigh;

//------------------------------------------------------------------------------------

void	Pixel_Init(uint uScreenBase, uint uTileBase)
{						 
	uint	uSize;
	uint	uCount;
	u16		*pDest;
	u16		uTile;
	u8		*pDestX;
	int		nX;
	int		nY;
	int		nOffset;

	pPixelScreen = (u8 *) MEM_SBB(uTileBase);
	uSize = GFX_TILE_MAP_WIDTH * GFX_SCREEN_TILE_HEIGHT;
	pDest = (u16 *) MEM_SBB(uScreenBase);
	uTile = uTileBase * 0x800 / 64;
	for (uCount = 0; uCount < uSize ; uCount++)
	{
		*pDest++ = uTile++;
	}

	// prestore offsets for optimisation
	for (nX = 0; nX < GFX_SCREEN_PIXEL_WIDTH; nX++)
	{
		pDestX = pPixelScreen;
		pDestX += (nX & 6);
		pDestX += (nX >> 3) << 6;		    
		pPixelDestX[nX] = pDestX;
	}
	for (nY = 0; nY < GFX_SCREEN_PIXEL_HEIGHT; nY++)
	{
		nOffset = (nY & 7) << 3;
		nOffset += (nY >> 3) << 11;
		nPixelOffsetY[nY] = nOffset;
	}

	// clear all screen pixels, should be a dma for speed but its only initialisation
	Pixel_SetPen(COLOUR_BACKGROUND);
	Pixel_Rectangle(0, 0, GFX_SCREEN_PIXEL_WIDTH, GFX_SCREEN_PIXEL_HEIGHT);
}

//------------------------------------------------------------------------------------

void	Pixel_SetPen(uint uColour)
{
	uPixelColour = uColour;
	uPixelColourHigh = uColour << 8;
}	

//------------------------------------------------------------------------------------

// Slow as this needs to read, add, write due to vram writes having to be 16 bit

void	Pixel_Plot(int nX, int nY)
{
	u8		*pDest;
	u16		uPrevious;

	pDest = pPixelScreen;

	pDest += (nX & 6);
	pDest += (nX >> 3) << 6;
	pDest += (nY & 7) << 3;
	pDest += (nY >> 3) << 11;

	uPrevious = *(u16 *) pDest;

	if (nX & 1)	
	{
		*(u16 *)pDest = (uPixelColour << 8) + (uPrevious & 0xFF);
	}
	else 
	{
		*(u16 *)pDest = (uPrevious & 0xFF00) + uPixelColour;
	}
}	
		    
//------------------------------------------------------------------------------------

// Slow as this needs to read, add, write due to vram writes having to be 16 bit

void	Pixel_PlotXOR(int nX, int nY)
{
	u8		*pDest;
	u16		uPrevious;

	pDest = pPixelScreen;

	pDest += (nX & 6);
	pDest += (nX >> 3) << 6;
	pDest += (nY & 7) << 3;
	pDest += (nY >> 3) << 11;

	uPrevious = *(u16 *) pDest;

	if (nX & 1)
	{
		*(u16 *)pDest = uPrevious ^ uPixelColourHigh;
	}
	else 
	{
		*(u16 *)pDest = uPrevious ^ uPixelColour;
	}
}	

//------------------------------------------------------------------------------------

// this Breshenham alg taken from a Staringmonkey demo
// optimisation would be to pull in pixel_plot code

void	Pixel_Draw(int nX0, int nY0, int nX1, int nY1)
{
	//Variables
	int i, deltax, deltay, numpixels;
	int d, dinc1, dinc2;
	int x, xinc1, xinc2;
	int y, yinc1, yinc2;

	//Calculate deltaX and deltaY
	deltax = abs(nX1 - nX0);
	deltay = abs(nY1 - nY0);

	//Init vars
	if(deltax >= deltay)
	{
		//If x is independent variable
		numpixels = deltax + 1;
		d = (2 * deltay) - deltax;
		dinc1 = deltay << 1;
		dinc2 = (deltay - deltax) << 1;
		xinc1 = 1;
		xinc2 = 1;
		yinc1 = 0;
		yinc2 = 1;
	}
	else
	{
		//If y is independant variable
		numpixels = deltay + 1;
		d = (2 * deltax) - deltay;
		dinc1 = deltax << 1;
		dinc2 = (deltax - deltay) << 1;
		xinc1 = 0;
		xinc2 = 1;
		yinc1 = 1;
		yinc2 = 1;
	}

	//Move the right direction
	if(nX0 > nX1)
	{
		xinc1 = -xinc1;
		xinc2 = -xinc2;
	}
	if(nY0 > nY1)
	{
		yinc1 = -yinc1;
		yinc2 = -yinc2;
	}

	x = nX0;
	y = nY0;

	//Draw the pixels
	for(i = 1; i < numpixels; i++)
	{
		Pixel_Plot(x, y);

		if(d < 0)
		{
			d = d + dinc1;
			x = x + xinc1;
			y = y + yinc1;
		}
		else
		{
			d = d + dinc2;
			x = x + xinc2;
			y = y + yinc2;
		}
	}
}	

//------------------------------------------------------------------------------------

// Very slow, don't use in game

void	Pixel_Rectangle(int nX0, int nY0, int nX1, int nY1)
{
	int	nX;
	int	nY;

	for (nY = nY0; nY <= nY1; nY++)
	{
		for (nX = nX0; nX <= nX1; nX++)
		{
			Pixel_Plot(nX, nY);
		}
	}
}	

//------------------------------------------------------------------------------------

// optimised pixel XOR draw for Y being constant

void	Pixel_DrawYConstantXOR(u32 *pFuncAddr, int nX0, int nX1, int nY)
{
	int		nX;
	u8		*pDest;
	u16		uPrevious;
	int		nOffsetY;
	uint	nColourCompound;
	int		nXStart;
	int		nXEnd;

	nOffsetY = nPixelOffsetY[nY];
	if (nX0 > nX1)
	{
		nX = nX0;
		nX0 = nX1;
		nX1 = nX;
	}
	nColourCompound = uPixelColourHigh + uPixelColour;

	nXStart = (nX0 + 1) & 0xFE;
	nXEnd = nX1 & 0xFE;

	for (nX = nXStart; nX <= nXEnd; nX+=2)
	{
		pDest = pPixelDestX[nX];
		pDest += nOffsetY;
		uPrevious = *(u16 *) pDest;
		*(u16 *)pDest = uPrevious ^ nColourCompound;
	}

	if (nXStart & 1)
	{
		pDest = pPixelDestX[nXStart];
		pDest += nOffsetY;

		uPrevious = *(u16 *) pDest;
		*(u16 *)pDest = uPrevious ^ uPixelColourHigh;
	}
	if ((nXEnd & 1) == 0)
	{
		pDest = pPixelDestX[nXEnd];
		pDest += nOffsetY;
		uPrevious = *(u16 *) pDest;
		*(u16 *)pDest = uPrevious ^ uPixelColour;
	}
}	

//------------------------------------------------------------------------------------

