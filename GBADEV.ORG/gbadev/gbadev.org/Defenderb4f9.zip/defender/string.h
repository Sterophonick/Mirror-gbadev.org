//------------------------------------------------------------------------

// string
// Rich Heasman May 2002

//------------------------------------------------------------------------

#define	STRING_LEN_MAX		64
#define	STRING_TERMINATOR	'\0'

//------------------------------------------------------------------------

void	String_Copy(char *szDest, char *szSrc);
void	String_Cat(char *szDest, char *szSrc);
void	String_FromInt(char *szDest, int nSrc);
void	String_FromChar(char *szDest, char cSrc);
uint	String_Length(char *szDest);

//-----------------------------------------------------------------------

