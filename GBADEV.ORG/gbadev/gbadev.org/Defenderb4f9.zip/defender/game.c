//-------------------------------------------------------------------------

// Game flow control routines
// Rich Heasman July 1997 / May 2002

//-------------------------------------------------------------------------

#include 	"gba.h"
#include 	"game.h"

#include 	"fixedpt.h"

#include 	"explode.h"
#include 	"radar.h"
#include 	"laser.h"
#include 	"mine.h"
#include 	"bullet.h"
#include 	"bonus.h"
#include 	"scores.h"
#include 	"alien.h"
#include 	"land.h"
#include 	"human.h"
#include 	"ship.h"
#include 	"player.h"
#include 	"sheet.h"
#include 	"gfx.h"
#include 	"gfxdata2.h"
#include 	"sprite.h"
#include 	"timer.h"
#include 	"string.h"
#include 	"button.h"
#include 	"background.h"
#include 	"soundfx.h"
#include 	"pixel.h"
#include 	"debug.h"
#include 	"palette.h"
#include 	"profile.h"
#include 	"rnd.h"

//----------------------------------------------------------------------------

#define	GAME_SQUADS_PER_WAVE			3			// number of squads of soliders per wave
#define	GAME_TIME_1ST_SQUAD				(90)		// time before 1st squad
#define	GAME_TIME_BETWEEN_SQUADS		(16*60)
#define	GAME_TIME_NO_LAND				(2*60)		// time between squads when land lost
#define	GAME_TIME_SHOWING_HUMANS		5			// time between show human at end of wave
#define	GAME_TIME_TILL_DIFFICULT		(70*60)		// time pre baiter
#define	GAME_TIME_DIFFICULT_AGAIN		(14*60)		// time before next baiter
#define	GAME_TIME_TILL_FIREWORKS		(15*60)		// time before attract mode starts
#define	GAME_TIME_GAME_OVER				(6*60)		// time of game over pause 
#define	GAME_TIME_TILL_TITLE			(2*60)		// time gap before title appears
#define	GAME_TIME_SHOW_WAVE				(90)		// time showing wave number
#define	GAME_TIME_SHOW_MEN				(1*60)		// time showing complete men

//-------------------------------------------------------------------------

static	int			nGameStatus;
static	uint		GameTimer;
static	int			nGameSquadNum;
static	uint		GameDifficultTimer;
static	SPRITE_TYPE	*pGameHumanSprite[HUMAN_NEW_NUM];
static	int			nGameHumanBonus;
static	int			nGameWaveBonus;
static	BOOL		boGameStartable;
static	int			nGameFEType;
static	int			nGameNumber;


//-------------------------------------------------------------------------

void	Game_Init(void)
{
	int	nHuman;

	Land_Init();
	Human_Init();
	Bonus_Init();
	Alien_Init();
	Bullet_Init();
	Mine_Init();
	Ship_Init();
	Radar_Init();
	Explode_Init();
	Player_Init();

	Timer_Set(&GameTimer,0);
	Game_ClearAll();
	for (nHuman = 0; nHuman < HUMAN_NEW_NUM; nHuman++)
	{
		pGameHumanSprite[nHuman]=Sprite_Create(GFX_HUMANOID_L,0,GFX_SCREEN_PIXEL_HEIGHT);
	}
	boGameStartable = FALSE;
	nGameStatus=GAME_INIT;
	nGameNumber = 0;

	nGameFEType = EXPLODE_POD;
}

//-------------------------------------------------------------------------

void	Game_Update(void)
{
	Game_StateUpdate();
	Profile_Point("Game Update");
	Ship_Update();
	Land_Update(Ship_PosGet());
	Alien_Update();
	Profile_Point("Alien Update");
	Bullet_Update();
	Mine_Update();
	Human_Update();
	Bonus_Update();
	Radar_Update();
	Player_Update();
}

//-------------------------------------------------------------------------

void	Game_StateUpdate(void)
{
	char	szMessage[STRING_LEN_MAX];
	char	szNumber[STRING_LEN_MAX];
	int		nHuman;
	int		nX;
	
	switch (nGameStatus)
	{
		case GAME_INIT :
		{
			Timer_Set(&GameTimer, GAME_TIME_TILL_TITLE);
			nGameStatus=GAME_WAIT_TITLE;
			break;
		}
		case GAME_WAIT_TITLE :
		{
			if (Timer_Mature(&GameTimer))
			{
				Timer_Set(&GameTimer, GAME_TIME_TILL_FIREWORKS);
				SoundFX_Make(SOUNDFX_CHANNEL_A, SOUNDFX_TITLE);
				nGameStatus=GAME_WAIT_START;
			}
			break;
		}

		case GAME_WAIT_START :
		{
			Background_ShowFE();
			if (Timer_Get(&GameTimer) == 60)
			{
				Game_ClearAll();
			}
			if (Timer_Mature(&GameTimer))
			{
				Game_ShowFE();
			}
			if (boGameStartable)
			{

				if (Button_PressedDebounced(BUTTON_START) || Button_PressedDebounced(BUTTON_A))
				{
					Timer_Set(&GameTimer,20);
					nGameStatus=GAME_START;
				}
			}
			break;
		}
		case GAME_START :
		{
			if (Timer_Mature(&GameTimer))
			{
				Timer_Set(&GameTimer,0);
				nGameStatus=GAME_START_WAIT;
			}
			break;
		}
		case GAME_START_WAIT :
		{
			if (Timer_Mature(&GameTimer))
			{
				Sheet_Start();
				Player_Start();
				Game_ClearAll();
				nGameNumber++;
				nGameStatus=GAME_SHOW_WAVE;
			}
			break;
		}
		case GAME_SHOW_WAVE :
		{
			SoundFX_Make(SOUNDFX_CHANNEL_A, SOUNDFX_BUZZ);
			Timer_Set(&GameTimer, GAME_TIME_SHOW_WAVE);
			nGameStatus=GAME_SHOW_WAVE_WAIT;
			break;
		}
		case GAME_SHOW_WAVE_WAIT :
		{
			String_Copy(szMessage, "WAVE ");
			String_FromInt(szNumber, Sheet_Number());
			String_Cat(szMessage, szNumber);
		    Background_Font2Print( 11, 10, szMessage);

			if (Timer_Mature(&GameTimer))
			{
				Game_ClearAll();
				Ship_New();
				Human_Start(Sheet_Number());
				Land_New();
				Alien_Start();
				nGameSquadNum=0;
				Timer_Set(&GameTimer,GAME_TIME_1ST_SQUAD);
				Timer_Set(&GameDifficultTimer,Sheet_ModifiedTime(GAME_TIME_TILL_DIFFICULT,25));
				nGameStatus=GAME_RUNNING;
			}
			break;
		}
		case GAME_RUNNING :
		{
			if (Ship_IsDead())
			{
				nGameStatus=GAME_SHIP_DEAD;
			}
			if (Timer_Mature(&GameDifficultTimer) && !Ship_IsDead())
			{
				Timer_Set(&GameDifficultTimer,Sheet_ModifiedTime(GAME_TIME_DIFFICULT_AGAIN,25));
				Alien_BaiterNew();
			}
			if (nGameSquadNum<GAME_SQUADS_PER_WAVE)
			{
				if (Timer_Mature(&GameTimer)||(Alien_AllDead()&&nGameSquadNum>0))
				{
					Alien_SolidersNew();
					nGameSquadNum++;
					Timer_Set(&GameTimer,Sheet_ModifiedTime(GAME_TIME_BETWEEN_SQUADS,25));
					SoundFX_Make(SOUNDFX_CHANNEL_A, SOUNDFX_ZIPPYZAP);
				}
				else
				{
					if (Human_NumAliveGet()==0 && Timer_Get(&GameTimer)>GAME_TIME_NO_LAND)
					{
						Timer_Set(&GameTimer,GAME_TIME_NO_LAND);
					}
				}
			}
			else
			{
				if (Alien_AllDead())
				{
					Timer_Set(&GameTimer,30);
					Ship_Clear();
					nGameStatus=GAME_WAVE_CLEAR;
				}
			}
			break;
		}
		case GAME_WAVE_CLEAR :
		{
			if (Timer_Mature(&GameTimer))
			{
				Game_ClearAll();
				nGameStatus=GAME_SHOW_DONE;
			}
			break;
		}
		case GAME_SHOW_DONE :
		{

			if (Sheet_Number()*SCORE_END_BONUS>SCORE_BONUS_MAX)
			{
				nGameWaveBonus=SCORE_BONUS_MAX;
			}
			else
			{
				nGameWaveBonus=Sheet_Number()*SCORE_END_BONUS;
			}
			Game_WaveCompleteRender();
			Timer_Set(&GameTimer,30);
			nGameStatus=GAME_SHOW_DONE_WAIT;
			break;
		}
		case GAME_SHOW_DONE_WAIT :
		{
			Game_WaveCompleteRender();
			if (Timer_Mature(&GameTimer))
			{
				Timer_Set(&GameTimer,0);
				nGameHumanBonus=0;
				nGameStatus=GAME_SHOW_MEN;
			}
			break;
		}
		case GAME_SHOW_MEN :
		{
			Game_WaveCompleteRender();
			if (nGameHumanBonus<Human_NumAliveGet())
			{
				if (Timer_Mature(&GameTimer))
				{
					nX = GFX_SCREEN_PIXEL_WIDTH/4+GFX_SCREEN_PIXEL_WIDTH/2*nGameHumanBonus/HUMAN_NEW_NUM;
					Sprite_PositionSet(pGameHumanSprite[nGameHumanBonus], nX, 12 * 8);
					nGameHumanBonus++;
					Player_ScoreAdd(nGameWaveBonus);
					Timer_Set(&GameTimer,GAME_TIME_SHOWING_HUMANS);
				}
			}
			else
			{
				Timer_Set(&GameTimer, GAME_TIME_SHOW_MEN);
				nGameStatus=GAME_SHOW_MEN_WAIT;
			}
			break;
		}
		case GAME_SHOW_MEN_WAIT :
		{
			Game_WaveCompleteRender();
			if (Timer_Mature(&GameTimer))
			{
				Timer_Set(&GameTimer,30);
				nGameStatus=GAME_SHOW_MEN_REMOVE;
			}
			break;
		}
		case GAME_SHOW_MEN_REMOVE :
		{
			Game_WaveCompleteRender();
			if (Timer_Mature(&GameTimer))
			{
				for (nHuman = 0; nHuman < HUMAN_NEW_NUM; nHuman++)
				{
					Sprite_PositionSet(pGameHumanSprite[nHuman], GFX_SCREEN_PIXEL_WIDTH, 0);
				}
				Sheet_Increment();
				nGameStatus=GAME_SHOW_WAVE;
			}
			break;
		}
		case GAME_SHIP_DEAD :
		{
			Timer_Set(&GameTimer,2*60);
			nGameStatus=GAME_SHIP_DEAD_WAIT;
			break;
		}
		case GAME_SHIP_DEAD_WAIT :
		{
			if (Timer_Mature(&GameTimer))
			{
				if (Player_ShipLeft()>0)
				{
					Timer_Set(&GameTimer,30);
					nGameStatus=GAME_SHIP_NEW;
				}
				else
				{
					nGameStatus=GAME_OVER;
				}
			}
			break;
		}
		case GAME_SHIP_NEW :
		{
			if (Timer_Mature(&GameTimer))
			{
				Ship_New();
				Player_ShipRemove();
				Alien_BaitersKill();
				Timer_Set(&GameDifficultTimer,GAME_TIME_DIFFICULT_AGAIN*2);		// allow a little time after death
				nGameStatus=GAME_RUNNING;
			}
			break;
		}
		case GAME_OVER :
		{
	 		Timer_Set(&GameTimer, GAME_TIME_GAME_OVER);
			nGameStatus=GAME_OVER_WAIT;
			break;
		}
		case GAME_OVER_WAIT :
		{
		    Background_Font2Print( 10, 10, "GAME  OVER");

			if (Timer_Mature(&GameTimer))
			{
				nGameStatus=GAME_INIT;
			}
			break;
		}
	}
}

//-------------------------------------------------------------------------

void	Game_Render(void)
{		
	__FarProcedure(Explode_Render);
	Profile_Point("Explode Render");
	Ship_Render();
	Profile_Point("Ship Render");
	Land_Render();
	Profile_Point("Land Render");
	Laser_Render();
	Profile_Point("Laser Render");
}	

//-------------------------------------------------------------------------

void	Game_ClearAll(void)
{
	Human_Clear();
	Bonus_Clear();
	Alien_Clear();
	Bullet_Clear();
	Mine_Clear();
	Ship_Clear();
	Radar_Clear();
}

//-------------------------------------------------------------------------

void	Game_Start(void)
{
	boGameStartable = TRUE;
}	

//-------------------------------------------------------------------------

void	Game_WaveCompleteRender(void)
{
	char	szMessage[STRING_LEN_MAX];
	char	szNumber[STRING_LEN_MAX];

	String_Copy(szMessage, "ATTACK WAVE ");
	String_FromInt(szNumber, Sheet_Number());
	String_Cat(szMessage, szNumber);
	String_Cat(szMessage, " COMPLETED");
    Background_Font2Print( 3, 8, szMessage);

	String_Copy(szMessage, "BONUS X ");
	String_FromInt(szNumber, nGameWaveBonus);
	String_Cat(szMessage, szNumber);
    Background_Font2Print( 8, 10, szMessage);
}

//-------------------------------------------------------------------------

void	Game_StateSet(int nState)
{
	nGameStatus = nState;
}	

//-------------------------------------------------------------------------

// attract mode, room for improvement

void	Game_ShowFE(void)
{
	int		nType;
	FIXEDPT	xX;
	FIXEDPT	xY;

	if (Rnd(200)<1)
	{
		switch (Rnd(3))
		{
			case 0 : nGameFEType = EXPLODE_POD; 	break;
			case 1 : nGameFEType = EXPLODE_MINER; 	break;
			case 2 : nGameFEType = EXPLODE_ANY; 	break;
		}
	}

	if (Rnd(100)<10)
	{
		nType = nGameFEType;
		if (nGameFEType == EXPLODE_ANY)
		{
			nType = Rnd(EXPLODE_ANY);
		}
		xX = IntToFixed(Rnd(GFX_SCREEN_PIXEL_WIDTH)) + Ship_PosGet();
		xY = IntToFixed(Rnd(GFX_SCREEN_PIXEL_HEIGHT));
		Explode_Make( nType, xX, xY);
	}
}	

//-------------------------------------------------------------------------
