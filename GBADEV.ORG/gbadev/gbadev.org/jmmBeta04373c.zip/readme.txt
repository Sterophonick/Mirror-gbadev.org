Contact: Sector0
E-Mail: windos6@yahoo.com

Version: Very Beta possibly alpha.... around there somewhere

Well .... Here it is.... A Java Map Maker... yep...

NOTE: YOU HAVE TO DOWNLAOD THE CLASSES FOR THIS TO WORK... JAVA APPLETS LOADED OVER THE WEB ARE TREATED AS
 NON-TRUSTED AND WILL NOT HAVE THE ABILITY TO SAVE!!!
 
NOTE2: SAVING IS ONLY POSSIBLE IF YOU READ DOWN BELOW :)

ALL SOURCE IS AVAILABLE -- This tool is provided with full source provided that it stays open source..
	If this code is modified or used then just drop me a note and tell me what wonderfull things you are
	using it for :)

Features:
	Multiple tile sets
	Multiple image formats (PCX,GIF,JPEG,C HEADER FILE)
	Tile Conversion Built In - ( more on this below)
	Export to C Header Files
	Vertical and Horizontal Flips
	Selection of multiple tiles with boxes (mouse drag)
			
Bugs (there are a lot right now):
        1. Some more bounds checking
	2. The IO boxes (save and load) are very very bad...
	3. There is no help for the keys (so look here)..
	4. I believe this is more of a Java bug than anything (if someone could confirm this) but
	when I run windows in 32bit color the tiles (when selected) in MM turn greyscale??
	5. Stupid IE has different key codes so saving and loading does not work from the browser
	6. Many more but I can't remember
	
Future Things to be Expected (anxiously):
	Export option for exporting all tiles ( to preserve tilesets if used more than once)
	Different map sizes other than 256x256 (scrolling)
	Collision Map
	Scrolling tile screens
	Level Loading
	An Eraser (to erase tiles from map )
	Ability to select a transparent color for palette entry 0
	Possibly a VERY basic tile editor ( maybe )	
	Whatever else I or someone else comes up with

Keys:
	ARROW UP   - Previous Tile Screen
	ARROW DOWN - Next Tile Screen
	V      	   - Vertical Flip ( when tiles are selected )
	H          - Horizontal Flip ( ditto )
	G          - Toggle grids
	S          - Save/Export to C File
	L          - Load image for tile set
	ESC        - Unselect Tiles or close save/load box

Tile Conversion:
	The JMM has built in tile conversion.  After creating a map, the tiles that have been USED in the map are
	exported in 256 colors.  What is that you say? It has built in 24/16BIT -> 256 color conversion! Yes!  
	It uses the MedianCut (hecklebert?) algorithim which I got, thankfully, from the IJ Open Source java library.  

	Mainly the advantage to this is the ability to keep your tilesets in 24bit color for as long as possible..
	The levels will then be optimized with the best color since you most likely will not be using all of the tiles..
	
	Of course this leads to a problem if you want to preserve tilesets for multiple levels, and not have MM export 
	the tiles, SO I will be adding the ability to export ALL tiles to preserve tile order (next release -- really soon)
	
Tile Screens:
	The tile screens contains the images which are divided into 8x8 (for now) tiles.  If the images are not divisible
	by 8 they will be padded. The width and height should be less than 256x256 for now until I get scrolling working.  
	Whenever you load an image the width and height are checked against the other tile screens, if it matches one 
	then the image is merged into that tile set, for simplicity sake.

Saving:
	I SUGGEST RUNNING THIS IN APPLETVIEWER (PART OF THE JDK FROM SUN)..
	This is mostly untested for browsers but should work (check bugs above)
	
	You have to run these classes locally, first off (read note above).  Then since Java is a whore about security you need
	to do one of 2 things.  
		#1. The environment variable CLASSPATH needs to contain the directory which you are going to save to:
			I.E. Windows:
				set CLASSPATH=somestupidsavingpath; (put this in the autoexec.bat or a batch file you can run)
			I.E. Linux (haven't tested it yet but):
			        export CLASSPATH=somestupidsavingpath; ( ??? - should work yes?)
		#2. Modify the file properties in the directory .hotjava to contain a line like acl.write=somedir
		
	Unfortunately I cannot get #2 to work yet (stupid java) so if someone does please tell me
	