#include "logo.c"
#include "bumpgfx.c"
#include "cossin.h"	// Precalculated Cos / Sin tables.

typedef unsigned short int uint16;
typedef unsigned int uint;
typedef unsigned char bool;

#define TRUE (0 == 0)
#define FALSE (0 == 1)
#define VRAM        0x06000000
#define BCK_M5_VRAM 0x0600A000
#define REG_BG0CNT  0x04000008
#define REG_BG1CNT  0x0400000a
#define REG_BLDCNT  0x04000050
#define REG_BLDY    0x04000054
#define REG_JP      0x04000130
#define REG_DISPCNT *(uint16*)0x04000000
#define SetMode(Mode) REG_DISPCNT=(Mode)
#define MODE_3	    0x03	//   240*160 15bits
#define MODE_4	    0x04	//   240*160 8bits indexed palette
#define MODE_5	    0x05	//   160*128 15bits :-O	
#define BACKBUFFER  0x010	
#define BG2_ENABLE  0x0400
#define RGB(r,g,b) ((r)+((g)<<5)+((b)<<10))

void waitretrace(void);
void WaitVBlank (void);
void sleep(int x);
uint16 jp_getstate(void);
void Copy32 (int *src,int *dst,unsigned int nb);
void Clear32 (int *src,unsigned int nb);
void M3_PutPixel (int x,int y, uint16 color);
void M5_PutPixel (int x,int y, uint16 color);
void M5_DirtyDrawSprite (int x,int y,int w,int h,unsigned short *src,unsigned short *dst);
void Bump (short cx,short cy,short int* Pal);
void SwapScreen (void);
int abs (int value);

uint16 *ActualVideoBuffer;
uint16 BumpPal1 [32] = {
RGB (0,0,0),
RGB (0,0,1),
RGB (0,0,2),
RGB (0,0,3),
RGB (0,0,4),
RGB (0,0,5),
RGB (0,0,6),
RGB (0,0,7),
RGB (0,0,8),
RGB (0,0,9),
RGB (0,0,10),

RGB (0,0,11),
RGB (0,0,12),
RGB (0,0,13),
RGB (0,0,14),
RGB (0,0,15),
RGB (0,0,16),
RGB (0,0,17),
RGB (0,0,18),
RGB (0,0,19),
RGB (0,0,20),

RGB (0,0,21),
RGB (0,0,22),
RGB (0,0,23),
RGB (0,0,24),
RGB (0,0,25),
RGB (1,1,26),
RGB (2,2,27),
RGB (4,4,28),
RGB (8,8,29),
RGB (16,16,30),
RGB (31,31,31),
};

uint16 BumpPal2 [32] = {
RGB (0,0,0),
RGB (0,1,0),
RGB (0,2,0),
RGB (0,3,0),
RGB (0,4,0),
RGB (0,5,0),
RGB (0,6,0),
RGB (0,7,0),
RGB (0,8,0),
RGB (0,9,0),
RGB (0,10,0),

RGB (0,11,0),
RGB (0,12,0),
RGB (0,13,0),
RGB (0,14,0),
RGB (0,15,0),
RGB (0,16,0),
RGB (0,17,0),
RGB (0,18,0),
RGB (0,19,0),
RGB (0,20,0),

RGB (0,21,0),
RGB (0,22,0),
RGB (0,23,0),
RGB (0,24,0),
RGB (0,25,0),
RGB (1,26,1),
RGB (2,27,2),
RGB (4,28,4),
RGB (8,29,8),
RGB (16,30,16),
RGB (31,31,31),
};

uint16 BumpPal3 [32] = {
RGB (0,0,0),
RGB (1,0,0),
RGB (2,0,0),
RGB (3,0,0),
RGB (4,0,0),
RGB (5,0,0),
RGB (6,0,0),
RGB (7,0,0),
RGB (8,0,0),
RGB (9,0,0),
RGB (10,0,0),

RGB (11,0,0),
RGB (12,0,0),
RGB (13,0,0),
RGB (14,0,0),
RGB (15,0,0),
RGB (16,0,0),
RGB (17,0,0),
RGB (18,0,0),
RGB (19,0,0),
RGB (20,0,0),

RGB (21,0,0),
RGB (22,0,0),
RGB (23,0,0),
RGB (24,0,0),
RGB (25,0,0),
RGB (26,1,1),
RGB (27,2,2),
RGB (28,4,4),
RGB (29,8,8),
RGB (30,16,16),
RGB (31,31,31),
};


int main()
{
  int x0,y0,alpha0=0;
  int x1,y1,alpha1=120;
  int x2,y2,alpha2=240;
  
  SetMode (MODE_5 | BG2_ENABLE);
  ActualVideoBuffer = (uint16*)0x600A000;// BCK_M5_VRAM;
  while (1) {

  Clear32 ((int *)ActualVideoBuffer,10240);

  x0 = 55+ ((55 * Cos [alpha0])>>7); 
  y0 = 30+ ((30 * Sin [alpha0])>>7);
  Bump (x0,y0,BumpPal2);
  alpha0 -=2;
  if (alpha0<1) alpha0 =359;

  x1 = 55+ ((55 * Cos [alpha1])>>7); 
  y1 = 30+ ((30 * Sin [alpha1])>>7);
  Bump (x1,y1,BumpPal3);
  alpha1 +=3;
  if (alpha1>359) alpha1 =0;

  x2 = 55+ ((55 * Cos [alpha2])>>7); 
  y2 = 30+ ((30 * Sin [alpha2])>>7);
  Bump (x2,y2,BumpPal1);
  alpha2 +=4;
  if (alpha2>359) alpha2 =0;
  M5_DirtyDrawSprite (0,102,160,25,logo,ActualVideoBuffer);
  WaitVBlank();
  SwapScreen ();
  }
  return(0);
}

/* returns joypad state */
uint16 jp_getstate(void)
{
  return(~*((uint16 *)REG_JP));
}

void waitretrace(void)
{
  while(!((*((volatile uint16 *)0x04000004) & (1<<0))));
  return;
}

/* 
 * sleep for a few vblanks just to slow this down on hardware
 */
void sleep(int x)
{
  for(;x;x--)
  {
    waitretrace();
    while(((*((volatile uint16 *)0x04000004) & (1<<0))));
  }
  return;
}

void M3_PutPixel (int x,int y, uint16 color)
{
ActualVideoBuffer[(y*240)+x] = color;
}

void M5_PutPixel (int x,int y, uint16 color)
{
ActualVideoBuffer[(y*160)+x] = color;
}

void Copy32 (int *src,int *dst,unsigned int nb)
{
unsigned int i=0;

for (i=0;i<nb;i++)
  {
  *dst= *src;
  dst++;
  src++;
  }
}

void Clear32 (int *src,unsigned int nb)
{
unsigned int i=0;

for (i=0;i<nb;i++)
  {
  *src=0;
  src++;
  }
}



void M5_DirtyDrawSprite (int x,int y,int w,int h,unsigned short *src,unsigned short *dst)
{
unsigned int i,o;
unsigned int idst;

idst =(y*160)+x;
for (i=0;i<h;i++)
  {
  for (o=0;o<w;o++)
    {
    if (*src != 0) 
      {
       dst [idst] = *src;
      } 
    idst++;
    src++;
    } 
  idst += (160-w);	// jmp next line
  }
}

/*
void Bump (short Cx,short Cy)
{
int Position,Lx,Ly,Nx,Ny;
int Couleur1,Couleur2,x,y;
int Couleur;

Position = 161;	// [0,1] in screen
Ly = 1-Cy;
for (y=1;y<127;y++)
  {
  Lx = 1-Cx;
  for (x=1;x<159;x++)
    {
    Nx = (bump_bg [Position+1] & 31 ) - (bump_bg [Position-1] & 31);
    Couleur1 = 31 - abs (Nx - Lx);
    if (Couleur1 >0) 
      {
      Ny = (bump_bg [Position+160] & 31) - (bump_bg [Position-160] &31);
      Couleur2 =  31 - abs (Ny - Ly);        
      if (Couleur2 >0)
        { 
        Couleur = (Couleur1 * Couleur2) >>5;
	ActualVideoBuffer [Position] = BumpPal[Couleur];
        }
      else ActualVideoBuffer [Position] =0;  	
      }
    else ActualVideoBuffer [Position] =0;  
    Position++;
    Lx++;
    }
  Position+=2;
  Ly++;
  }
}

*/

void Bump (short Cx,short Cy,short int *Pal)
{
int Position,Lx,Ly,Nx,Ny;
int Couleur1,Couleur2,x,y;
int Couleur;

Position = (Cy*160)+Cx;	// [0,1] in screen
Ly = -25;
for (y=0;y<50;y++)
  {
  Lx = -25;
  for (x=0;x<50;x++)
    {
    Nx = (bump_bg [Position+1] & 31 ) - (bump_bg [Position-1] & 31);
    Couleur1 = 24 - abs (Nx - Lx);
    if (Couleur1 >0) 
      {
      Ny = (bump_bg [Position+160] & 31) - (bump_bg [Position-160] &31);
      Couleur2 =  24 - abs (Ny - Ly);        
      if (Couleur2 >0)
        { 
        Couleur = (Couleur1 * Couleur2) >>5;
	ActualVideoBuffer [Position] |= Pal[Couleur];
        }
      }
    Position++;
    Lx++;
    }
  Position+=110;
  Ly++;
  }
}


int abs (int value)
{
if (value <0) return (value* -1);
else return (value);
}

void SwapScreen ()
{
if (REG_DISPCNT & BACKBUFFER)
  {
  
  REG_DISPCNT &= ~BACKBUFFER;
  ActualVideoBuffer = (uint16*) BCK_M5_VRAM;
  }
else
  {
  
  REG_DISPCNT |= BACKBUFFER;
  ActualVideoBuffer = (uint16*) VRAM;
  }
}

void WaitVBlank (void)
{
while (*(volatile uint16*)0x4000006<160) {};
}



#ifdef __GNUC__
static void __gccmain() { }
#endif
