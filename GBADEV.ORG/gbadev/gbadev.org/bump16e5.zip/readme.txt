Mode5 Bump mapper for the GBA. (07/2001)

Written in C only ...
by Bruno Vedder  (bruno.vedder@wanadoo.fr)

Here is my first release for the Gameboy Advance =)

It was build with a cross gcc under Linux 2.2.16.
Gfx were made with the gimp :-)  (nice c-source output !)
The intro was tested with VGBA, all seems to work fine
excepted the frame rate maybe (Linux VGBA don t display it !).

    I release the source cause, it might be usefull for someone, like me,
starting with gba coding, but remember it s not an example of good
C writting...
    A lot of things could be better, but speed was not my goal.
If you have any comment or question, feel free to email me.
If something s wrong let me know, frame rate too ...


Greets to:
Stephen Stair   (for testing on windows emulator, and his sources,answers etc..)
Joat		(cool docs)
Nokturn		(tutorials)
Dovoto		 (  " " )
Richard "Ries" van der Brugge (compiler advice,sources)
The Forgotten   :)
And all sources contributors and consoles coders.
