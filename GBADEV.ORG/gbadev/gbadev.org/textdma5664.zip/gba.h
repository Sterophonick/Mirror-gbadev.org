/*
 GBA.H
*/

//we don't include that much stuff here, just very basic stuff

#ifndef GBA_H
#define GBA_H

typedef unsigned short  u16;
typedef unsigned long   u32;

#define REG_DISP_CNT             (*(u16*)0x4000000)
#define REG_BG0CNT               (*(u16*)0x4000008)
#define CharBaseBlock(n)		 (((n)*0x4000)+0x6000000)
#define ScreenBaseBlock(n)		 (((n)*0x800)+0x6000000)

//include the Direct memory access-functions
#include "dma.h"

#endif
//EOF