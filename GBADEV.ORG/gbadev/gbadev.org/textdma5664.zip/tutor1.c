//I reduced the code to only show the basics of plotting text to the screen
//It's recommed that you know how to set up an BG in mode 0

//This code will introduce to DMA (I won't cover that much about it though) and Text output

#include "gba.h" //prototypes for dma copy funcs and some basic defines
#include "font.h" //The font image data

u16* pFontData =(u16*)ScreenBaseBlock(21); //Where the font MAP is saved
u16* pFontTiles =(u16*)CharBaseBlock(0);   //Where the font IMAGE is saved

//This function does the actual work
//it cuts of the first 32 chars of an standard
//ascii value and stores the index into the font map
void PlotText(char* TextIn, u32 PosX, u32 PosY) {
  u32 t=0;
  while (1) {
	pFontData[PosY * 32 + PosX + t] = TextIn[t]-32; //Put the index into the map
	if (TextIn[t++] == 0) return; //We reached the end of the string
  }
}

int AgbMain(void) {
  //Activate BG0
  REG_DISP_CNT = (1<<8);
  //set up an 256pixx256pix 256col bg at the defined data positions for image and map data
  REG_BG0CNT = 0x80 | (21 << 8) | (0 << 2);

  //Copy the image palette into memory
  DMACopyCH3((void*)fontPal, ((void*)0x5000000), 128, DMA_32NOW);
  //load the font into VRAM
  DMACopyCH3((void*)fontData, (void*)pFontTiles, fontDataSize32, DMA_32NOW);
  
  //Lets plot the text
  PlotText("> This is a simple font test <",0,1);
  PlotText("       written by Lupin       ",0,3);
  PlotText("     mail: lupin003@gmx.de    ",0,5);
  PlotText(" or find me @ #gbadev / EFnet ",0,7);
  PlotText("      www.matrixvb.da.ru      ",0,11);

  //command this out to clear the ploted text
  //DMAClearMemory32(pFontData,256);

  //That's it! Now just wait till someone pulls the plug...
  //Mainloop
  while(1) { /* nothing */ }
  return 1;
}
////