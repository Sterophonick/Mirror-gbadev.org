The Pimple Demo
by limaCAT
22 December 2001
================

Legalese 1
==========

    Pimple Demo
    Copyright (C) 2001 Davide Inglima, limaCAT

    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program; if not, write to the Free Software
    Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.

E-mail:		Davide Inglima hadesnebula@libero.it
Paper mail:	Davide Inglima
		Via Bruna 53
		070 San Francesco al Campo (TO)
		Italy

Introduction
============

Ok boys and girls here it is a new demo. It uses h-blank interrupts and the
Mersenne Twister random number generator (which is also free to use for
commercial projects). As you may have seen by now, it is very lame and
only fills the gba screen of dots. I have to study how to tell GBA to go in
power-saving mode after returning from h-blanks, instead of doing that moronic
while loop, so people running it in hardware (if works, I never intended to see
it running in hw) know what they will face.

You will be asking why I reappear with such a lame demo for g*me boy *dv*nce
emulators after many months, instead of doing great games, like that half life
port ;). Well, it is because I lost TWICE my dev directories with source,
tools, docs... stuff I have done. The second time I managed to do a backup,
but I am too lazy to fetch the stuff from cd-roms, so I began again from zero.
Luckily there were some stuff mirrored on gbadev.org and the objects.script
pasted in a post to the yahoogroups mailing list, but bubble demo beta and
half life source code are gone -_-. So I won't be distributing it myself
anymore.

Compiling
=========

I am distributing this rom only as source code. You need devkit advance
installed and gnu make, which usually means a cygwin install with dka under
/devkitadv directory (or a linux environment with dka installed where you
like).

Gnu/Linux rules.

I used cpp to see if the devkit advance c++ setup worked, but it is also
possible to recompile and use this demo in C.

Legalese 2
==========

You are wondering Why I used GNU GPL to distribute this demo. Well. GNU GPL
applies to the demo in its totality. The Makefile has no copyright whatsoever,
the pimple.cpp is under X license (free to re-use in your commercial project
/ closed demos) and I choose the Artistic Licensed version of Mersenne Twister
so I can work on it freely (which is avaiable with a at
http://www.math.keio.ac.jp/~matumoto/emt.html along with a gpld version)

COPYING is the file with the GPL license, COPYING.artistic is the file
with Mt's artistic license.

What does this all mean? That you can't mirror this rom binary only period
(so I hope this time to see the source code coming home again, yeah... I will
do a backup on CD rom soon :p). If you want to make people download a binary
version too, please attach the source code. goodgba people: please contact me
for an official binary, if you need it. Gbadev's version will be ok.

Greetings
=========

- Simon B.: 
for http://www.gbadev.org

- Mike Wynn (Isotest):
I was pleased to change and re-changed your Makefiles until they worked in my
setup, so thank you.

- Staringmonkey (Interrupt Demos):
I haven't copied your source code, but I've got some good
clarification for the interrupts handling (the general algorithm was
taken from the Architecture course I had at school). I owe you a beer :)

- Eloist (gba.h):
Your gba.h was an inspiring base for my work, so thank you as well.

- Makoto Matsumoto and Takuji Nishimura (mersenne twister):
Thank you for Mersenne Twister.

- Kojote:
Moral support :)

- #gdronline (on another irc network :p):
Off topic, but I like playing IRC rpgs with you :). Viva il Chocobo! Morte
ad Urbo!

Standard Thanks apply to the #gbadev, #retro, devrs, gbaemu, nintendo.co.jp
people as well.
