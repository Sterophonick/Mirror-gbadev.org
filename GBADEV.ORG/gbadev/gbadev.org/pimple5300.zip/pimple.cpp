/*

COPYRIGHT AND PERMISSION NOTICE

Copyright (c) 2001 Davide Inglima

All rights reserved.

Permission is hereby granted, free of charge, to any person obtaining a
copy of this software and associated documentation files (the
"Software"), to deal in the Software without restriction, including
without limitation the rights to use, copy, modify, merge, publish,
distribute, and/or sell copies of the Software, and to permit persons
to whom the Software is furnished to do so, provided that the above
copyright notice(s) and this permission notice appear in all copies of
the Software and that both the above copyright notice(s) and this
permission notice appear in supporting documentation.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS
OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF
MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT
OF THIRD PARTY RIGHTS. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR
HOLDERS INCLUDED IN THIS NOTICE BE LIABLE FOR ANY CLAIM, OR ANY SPECIAL
INDIRECT OR CONSEQUENTIAL DAMAGES, OR ANY DAMAGES WHATSOEVER RESULTING
FROM LOSS OF USE, DATA OR PROFITS, WHETHER IN AN ACTION OF CONTRACT,
NEGLIGENCE OR OTHER TORTIOUS ACTION, ARISING OUT OF OR IN CONNECTION
WITH THE USE OR PERFORMANCE OF THIS SOFTWARE.

Except as contained in this notice, the name of a copyright holder
shall not be used in advertising or otherwise to promote the sale, use
or other dealings in this Software without prior written authorization
of the copyright holder.

*/

#include "gba.h"
#include "mt19937int.h"

#define random(num) (genrand() % num)

void
plot(void) {
	int x = random(160) * 240;
        int y = random(240); 
	AGB_VRAM[x+y] = (random(0x7FFF));
}

void
irq_handler (void) {
	// Let's disable the Interrupt Handler
	*AGB_IME = AGB_IME_DISABLE;

	// Check for VBLANK, uncheck it and do the function
	if((*AGB_IF && AGB_IF_HBLANK) /*== AGB_IF_HBLANK */) {
		*AGB_IF = *AGB_IF && !(AGB_IF_HBLANK);
		plot();    
	}

	// Let's reenable the Interrupt Handler
	*AGB_IME = AGB_IME_ENABLE;
}

int
main(void) {
	// SETTING UP

        sgenrand((u32)4357);
	*AGB_IME	= AGB_IME_ENABLE;
	*AGB_IE		= AGB_IE_HBLANK;
	*AGB_INTERRUPT  = (u32)irq_handler;
	*AGB_DISPCNT	= /* 0x0403; */ AGB_BG2_ON | AGB_MODE_3;
	*AGB_DISPSTAT	= /* 0x0010; */ AGB_DISPSTAT_HBLANK_INT;

        int a, b = 0;
	// ENDLESS LOOP
        while(a == b){ a = b; };
}
