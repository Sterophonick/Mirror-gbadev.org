;	Snake Advance
;	Schultz,
;	   die
;	Zahlberhaft.

;	Introduction

	This game is not very original since thousands of versions of it have already been
developed. Nevertheless, I think it is a very reliable source to those who wish to develop
games to the Game Boy Advance using the assembly language.
	Without the help of high-level coding, it is very rare to see a fully functional
version of any game with its source code open and in assembly.
	So that the number of people who often get frustrated by the fact that most of their
efforts are in vain when trying to learn low level programming for consoles reduce, this
game is open for any modifications and copying.

	The game is about a snake who is very hungry. To feed it up, thou shalt control it
in its attempt to kill and eat many rats. However, each and every rat moves randomly so
a difficulty is added. Futhermore, the snake shall not hit the wall or bite herself. Elseway,
it is game over.

;	Requirements

	0.	This game has been developed with the help of the emulator Visual Boy Advance.
	1.	It shall not run on a real GBA since the cartridge header is incomplete.
	(the Nintendo Logo and the Checksum, as well as everything, is missing).
	2.	If it is of thy wish to have this game running on a real console, thou shouldst
	change the header.txt file that comes within the game.
	3.	If running on the real console, thou canst remove the cartridge after the
	game main picture appears on the screen, since no bus cycles are destined to the
	cartridge since then. (I have not tested that yet.)

;	Instructions

	0.	Turn ON the console or load the ROM from the emulator.
	1.	When the main picture shows itself on the screen, thou canst remove the
	cartridge if running the game from a console. (Again, I have not tested this).
	2.	Press the START button to initiate the main menu

	;	Main Menu
	
		0.	Move the icon with the UP and DOWN keys.
		1.	Select difficulty with the LEFT and RIGHT keys.
		2.	Make thy choice with the START or A keys.

		;	Options
			0.	NEW GAME:
			Starts a new game from scratch.

			1.	CONTINUE:
			Resumes a game started previously.
			If no game have been started or the last one has ended, this option
			is not enabled.

			2.	DIFFICULTY:
			Raises or drops difficulty level (from 1 to 8 decimal).
			If a game is running, thou canst not access this option. In other
			words, when continue is enabled, difficulty is disabled and vice-versa.

	;	Game

		0.	The snake starts with 4 pieces (the tail, two body pieces and the head).
		1.	The rat does no exist in the very beginning of the game.
		2.	In each frame, the snake shall move in the direction it is pointing.
		3.	If the rat is not visible, in each frame it shall have the chance of
		appearing. This chance gradually decreases as the snake gets bigger.
		4.	The speed in which the frames take place is determined by the difficulty.
		5.	When the heads eats a rodent, score is earned in proportion to the
		difficulty.
		6.	The score is shown in hexadecimal numbering system.
		7.	Each and every time the snake kill a rat, it grows a bit.
		8.	Thou shalt not let the snake hit the wall or bite itself.
		9.	When this happens, the snake and part of the scenario border goes red
		and it is game over for thee.

	;	Controls
		
		0.	DIRECTIONS: set snake direction.
		1.	START: interrupts a game. (Can resume later).

;	Fun

	0.	Thou shalt have fun.