13/08/2001 - Tet*is Advance
Copyright (c) Sergej Kravcenko - sergej@codewaves.com

COPYRIGHT NOTICE
Music          - Copyright (c) Adam Skorupa
Level Pictures - Copyright (c) by picture authors 
(Pictures can be used only if game distributed freely and no money is involved)
Anything other in this game is Copyright (c) by Sergej Kravcenko

This game can be copied and distributed freely only if no money is
involved. If you distribute this game please don't change original
archive files. 

INTRODUCTION
After some small experiments I realized that I can create something more
serious than small test programs. This is my first almost finished game
project for GBA. Game is Tetris clone with some extensions like powerups
and pictures. The main game target is picture opening.

FEATURES
16-bit 240x160 graphics
Module music
Sound effects
8 demo levels

CONTROLS
Left,Right - Move block
Down       - Drop block faster
A          - Rotate block
B          - Use powerup
LShift     - Shift powerups left
RShift     - Shift powerups right
Start      - Pause/Exit game

CONTACTS
If you have any suggestions or questions use this e-mail address:
sergej@codewaves.com Actualy I'm still looking for my place in game
development industry and if you are game development company I'll
send my CV on your request.

Sergej Kravcenko 