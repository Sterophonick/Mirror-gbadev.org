The Nomad II: Trapped - An puzzle/adventure/action game for the
GameBoy Advance.
Copyright (C) 2003  Alexander Markley

LICENSE
This game is licensed under the GNU GPL. A copy may be found in
the file README.LICENSE

HOW TO PLAY
Please see the instruction manual. It can be found in
the docs/ directory in multiple formats.

CONTACT
IRC Channel: #opengbgames at irc.freenode.net (Port: 6667)
Author/Maintainer: Alex Markley
E-Mail: alex@milent.com

CHANGELOG

I'm bad at keeping changelogs. Sorry.

1.0.1 - Full: Full Release. Includes source code, and 40 levels.
1.0.1 - Demo: Fixed a stupid bug.
1.0.0 - Demo: Initial release. Contains only 20 levels, and no source is availible.
