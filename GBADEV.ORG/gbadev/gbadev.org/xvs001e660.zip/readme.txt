******************************************
*Xmen Vs StreetFighter Juggernaut Edition*
******************************************

It 's not Game only a interactive demo
Try It.

About 16 Hours of work
All sprites are from the original arcade game (thank to final Burn)

