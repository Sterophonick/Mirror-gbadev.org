******************************
**** THE KIRBY REVOLUTION ****
******************************

)     Table of Contents      (
)                            (
)       1. How to Play       (
)         2. Status          (
)        3. Known Bugs       (
)       4. Source Code       (
)      5. Contributions      (

1. How to Play

A - Jump or Accept
D-Pad - Walk or Choose Options

2. Status

Currently, the title screen
works, AAS has generously
allowed me to add sound (Sound
in GBA programming always kills
me), I have two working Maps,
an almost complete AI character,
and an Intro movie.

3. Known Bugs

WaddleDee scrolls incorrectly.
WaddleDee does not appear if
you do not start in his Map.
(To make him appear, go outside
Kirby's House, save, reset the
GBA, and load your game.)

4. Source Code

If you would like to see the
source for this game, please PM
me at the forums. My username
is Kirby.

5. Contributations

I would love any contributations,
such as MODS (they have to be
ProTracker mods), SFX (wavs),
sprites, tilesets, bla...

Anyway, have fun!