~~ MandelBoy v1 ~~
   R E A D  M E

== CONTROLS ==

R will bring up and close the palette editor window

>>> Menu closed (mandel brot view)
-----------------------------------

press A to select the zoom area

press B to reset zoom


>>> Menu open (palette editor view)
-----------------------------------

press A to drag the color selection slider (at the very left side of the screen)

color sliders will move with the cursor if you move over them

"SAVE" will store the palette to SRAM

"DEL" will delete the color key (color keys are marked
with a little white line - the last color of the 
palette is always a color key)


== RANDOM STUFF ==

If you zoom in too deep the mandelbrot will just screw up 
(overflow error somewhere i guess...)

Try to use contrast colors for the palette, this will look best

I would appreciate any tips on how to improve the code (mostly in accuracy)

The screen will stay black for a while depending on your last
position inside the mandelbrot (btw, pixels inside the mandelbrot = slow)
this is because the last position gets saved in SRAM.

e-mail: lupin003[@]gmx.de