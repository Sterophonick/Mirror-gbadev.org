#ifndef __gbavars_h
#define __gbavars_h

extern void (*VBLANK)        (void);
extern void (*TIMER1)        (void);

extern void NoProcess (void);

extern FIXED reciprocal[512];

extern vu16* OAM; //the address of OAM 
extern OAMEntry sprites[128]; //My sprite array
extern pRotData rotData; //My rotation and scaling array

extern u32 clear;

#endif