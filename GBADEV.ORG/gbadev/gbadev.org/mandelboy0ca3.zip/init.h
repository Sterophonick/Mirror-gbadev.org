#ifndef _MAIN
#define _MAIN

//#include <math.h>
void VBLANK_MENU(void);
void MenuDrawFull(void);
void RecalcPalette(void);


#endif
