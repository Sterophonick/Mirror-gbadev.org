#include "gba/gba.h"
#include "gbavars.h"
#include "gbafuncs.h"
//funcs
#include "init.h"

//sprite def
#include "sprites_symbols.h"

extern u16 mandelsprt[];
extern u16 mandelsprtpal[];

typedef struct tColor {
  u8 r,g,b;
} color;

typedef struct tmPos {
  char ident[2];
  s32 lonx,lony,runx,runy;
} mandelpos;

s32 loax,loay,ruax,ruay;
  
color MandelPal[128];

#define START_ZOOM  768

extern mandelpos pos;

s16 mx=120, my=80, ps=0, pr=0;
s16 omx, omy;

s16 rx=0,gx=0,bx=0,sc=0,sc2=0;
u16 last_keys = (u16)~0;
boolean drag = false;

void SavePalette(void) {
register u8* p = (u8*)0x0E000000;

  p[0] = 123; //just an identifier...
  p[1] = 212;

  MemCpy8((u8*)MandelPal, (p+2), 128*3);

}

boolean LoadPalette(void) {
register u8* p = (u8*)0x0E000000;

  if((p[0] == 123) && (p[1]==212)) {
    MemCpy8((p+2), (u8*)MandelPal, 128*3);
    return true;
  } else {
    return false; //wrong identifier
  }

}

void SavePosition(void) {
register u8* p = (u8*)0x0E000000;

  pos.ident[0] = 'M';  pos.ident[1] = 'P';
  MemCpy8((u8*)&pos, (p+128*3+2), sizeof(mandelpos));

}

void LoadPosition(void) {
register u8* p = (u8*)0x0E000000;

  MemCpy8((p+128*3+2),(u8*)&pos, sizeof(mandelpos));
  if((pos.ident[0] != 'M') || (pos.ident[1] != 'P')) {

    pos.lonx = -START_ZOOM<<16;
    pos.lony = (171*START_ZOOM)<<8;
    pos.runx = START_ZOOM<<16;
    pos.runy = -(171*START_ZOOM)<<8;

    SavePosition();

  }
  calcd();

}


void RecalcPalette(void) {
  s32 di, j, lastPos=0;
  s32 dr,dg,db;
  s32 cr,cg,cb, ix;
  
  for(ix=1;ix<128;ix++) {

    if ((MandelPal[ix].r >> 7) == 1) {
      di = ix - lastPos;
      dr = (((s32)MandelPal[lastPos].r&0x7F) - ((s32)MandelPal[ix].r&0x7F) ) * reciprocal[di];
      dg = ((s32)MandelPal[lastPos].g - (s32)MandelPal[ix].g) * reciprocal[di];
      db = ((s32)MandelPal[lastPos].b - (s32)MandelPal[ix].b) * reciprocal[di];
      cr = (s32)(MandelPal[lastPos].r&0x7F)<<16;
      cg = (s32)MandelPal[lastPos].g<<16;
      cb = (s32)MandelPal[lastPos].b<<16;

      for(j=lastPos;j<=ix;j++) {
        if(((MandelPal[j].r >> 7) != 1) && (j!=0)) {
          MandelPal[j].r = (cr>>16);
          MandelPal[j].g = (cg>>16);
          MandelPal[j].b = (cb>>16);
        }
        ScreenPalette[j] = RGB((cr>>17),(cg>>17),(cb>>17));
        cr -= dr;
        cg -= dg;
        cb -= db;
      }
      ScreenPalette[ix] = RGB((MandelPal[ix].r&0x7F)>>1,MandelPal[ix].g>>1,MandelPal[ix].b>>1);
      
      lastPos = ix;
    } //if
  } //for
    
  for(ix=0;ix<128;ix=ix+2) {
    for(j=1;j<5;j++)
      PlotPixel8(ix,SCREEN_HEIGHT-j,ix,(ix+1));

    if((MandelPal[ix].r>>7)) {
      PlotPixel8(ix,SCREEN_HEIGHT-3,128,(ix+1));
      PlotPixel8(ix,SCREEN_HEIGHT-4,128,(ix+1));
    }
    if((MandelPal[ix+1].r>>7)) {
      PlotPixel8(ix,SCREEN_HEIGHT-3,ix,128);
      PlotPixel8(ix,SCREEN_HEIGHT-4,ix,128);
    }
    PlotPixel8(ix,SCREEN_HEIGHT-5,128,128);
  }
  

  
}



boolean PointInside(s32 px, s32 py, 
                    s32 ox, s32 oy,
                    s32 w, s32 h ) {

if( ( ((px-ox)<=w) && ((px-ox)>0) ) &&
    ( ((py-oy)<=h) && ((py-oy)>0) ) )
     return true;
   else
     return false;

}



void HandleInput(void) {
int cc=false,j;
u16 key_tap = ~REG_KEY & last_keys;

  if(pr==1) {
   
    SpritePaletteMem[3] = RGB((rx>>1),(gx>>1),(bx>>1));

    if(key_tap & KEY_A) { //A tapped
      //del
      if(PointInside(mx,my,103,141,21,9) && (MandelPal[sc].r>>7)) {
        MandelPal[sc].r &= 0x7F;
        RecalcPalette();
        rx = MandelPal[sc].r;
        gx = MandelPal[sc].g;
        bx = MandelPal[sc].b;
      }
      //save
      if(PointInside(mx,my,103,130,21,9)) {
        SavePalette();
      }
    }

    if(PointInside(mx,my,sc-2,151,4,4)) {
      ChangeSprite(3, 512+ARROW_OFF_START);
      if(KEY_A_PRESSED) {
        drag = true;
      }

    } else {
      ChangeSprite(3, 512+ARROW_ON_START);
    }


    cc=false;
    if(PointInside(mx,my,rx+35,127,4,4)) {
      ChangeSprite(6, 512+ARROW_OFF_START);
      if((KEY_LEFT_PRESSED) && (rx>0)) {
        rx--; cc=true;
      } else if((KEY_RIGHT_PRESSED) && (rx<63)) {
        rx++; cc=true;
      }
    } else {
      ChangeSprite(6, 512+ARROW_ON_START);
    }
    
    if(PointInside(mx,my,gx+35,135,4,4)) {
      ChangeSprite(5, 512+ARROW_OFF_START);
      if((KEY_LEFT_PRESSED) && (gx>0)) {
        gx--; cc=true;
      } else if((KEY_RIGHT_PRESSED) && (gx<63)) {
        gx++; cc=true;       
      }
    } else {
      ChangeSprite(5, 512+ARROW_ON_START);
    }
    
    if(PointInside(mx,my,bx+35,143,4,4)) {
      ChangeSprite(4, 512+ARROW_OFF_START);
      if((KEY_LEFT_PRESSED) && (bx>0)) {
        bx--; cc=true;
      } else if((KEY_RIGHT_PRESSED) && (bx<63)) {
        bx++; cc=true;
      }
    } else {
      ChangeSprite(4, 512+ARROW_ON_START);
    }        

    if(cc==true) {

      MandelPal[sc].r = rx;
      if(sc>0) {
        MandelPal[sc].r |= (1<<7); //interpolations bit setzen
      }
      MandelPal[sc].g = gx;
      MandelPal[sc].b = bx;

      RecalcPalette();
      
    } 
    
    if(drag) {
      if((KEY_LEFT_PRESSED) && (sc2>0))
        sc2--;
      if((KEY_RIGHT_PRESSED) && (sc2<127))
        sc2++;        

      sc = sc2;
      for(j=(sc2-2)>0?sc2-2:0;j<sc2+3;j++) {
        if(MandelPal[j].r>>7)
          sc = j;
      }
      rx = (MandelPal[sc].r&(0x7F));
      gx = MandelPal[sc].g;
      bx = MandelPal[sc].b;
      if(!KEY_A_PRESSED)
        drag = false;
    }
    
    SetSprite(4,bx+35,143);
    SetSprite(5,gx+35,135);
    SetSprite(6,rx+35,127);
    SetSprite(3,sc-2,151);
    CopyOAM(10); //cursor+menu
  } else {
  
    if(key_tap & KEY_A) { //A tapped
      if(ps==0) {
        loax=pos.lonx;
        loay=pos.lony;
        ruax=pos.runx;
        ruay=pos.runy;
        pos.lonx=mul32x32_64((ruax-loax),69905)*mx+loax;  //tx(ix,loax,ruax);
        pos.lony=mul32x32_64((ruay-loay),104858)*my+loay;  //ty(iy,loay,ruay); 
        omx=mx;
        omy=my; 
        PlotPixel8(mx,my,128,128);    
        ps++;
      } else {
        pos.runx=mul32x32_64((ruax-loax),69905)*mx+loax;  //tx(ix,loax,ruax);
        pos.runy=mul32x32_64((ruay-loay),104858)*my+loay;  //ty(iy,loay,ruay);      
        
        ps=0;        
        SavePosition();
        calcd();

        mandelbrot();
        RecalcPalette();
      }
    }
  
    if(KEY_B_PRESSED) {
      pos.lonx = -START_ZOOM<<16;
      pos.lony = (171*START_ZOOM)<<8;
      pos.runx = START_ZOOM<<16;
      pos.runy = -(171*START_ZOOM)<<8;

      calcd();
        
      SavePosition();
      mandelbrot(); 
      RecalcPalette();
    }
    
    CopyOAM(1); //nur cursor
  }





  if((KEY_LEFT_PRESSED) && (mx > 0)) mx--;
  if((KEY_RIGHT_PRESSED) && (mx < 239)) mx++;

  if(ps==1) {
    my=omy+(((mx-omx)*171)>>8);
    SetSprite(0,mx,my);
  } else {
    SetSprite(0,mx,my);
    if((KEY_UP_PRESSED) && (my > 0)) my--;
    if((KEY_DOWN_PRESSED) && (my < 159)) my++;    
  }

  if(key_tap & KEY_R) { //R tapped
  
    if(pr==0) {
      ShowSprites(1, 6);
      pr=1;
    } else {
      HideSprites(1, 6);
      pr=0;
    }

  }  

  last_keys = REG_KEY;
}

void WaitForVblank(void)
{
   while(! (REG_DISP_STAT & DISPSTAT_VB));
   while(REG_DISP_STAT & DISPSTAT_VB);
}


void AgbMain(void) {
int i;

    //Initialize display
    REG_DISP_CNT = MODE_4 | OBJ_ENABLE | OBJ_MAP_1D | BG2_ENABLE;
    REG_BG2CNT = 3;

    InitializeSprites();
    //Initialize lookup tables
   
    for(i=0;i<9;i++) {
      SpritePaletteMem[i] = mandelsprtpal[i];
    }
    for(i = 1; i < 128; i++) {
      reciprocal[i] = Div(0x10000, i);
    }
    
    LZ77UnCompVram(mandelsprt, (void*)SpriteMem);
	
	sprites[0].attribute0 = A0_COLOR_256 | A0_SHAPE_SQUARE | 80;
	sprites[0].attribute1 = A1_SIZE_16 | (120);
	sprites[0].attribute2 = A2_PRIORITY(0) | (512+CURSOR_START);			//pointer to tile where sprite starts, the first 512 tiles aren't available in mode 4

	sprites[1].attribute0 = A0_COLOR_256 | A0_SHAPE_WIDE | (160-32-5);
	sprites[1].attribute1 = A1_SIZE_64 | (0);
	sprites[1].attribute2 = A2_PRIORITY(1) | (512+PANEL_1_START);

	sprites[2].attribute0 = A0_COLOR_256 | A0_SHAPE_WIDE | (160-32-5);
	sprites[2].attribute1 = A1_SIZE_64 | (64);
	sprites[2].attribute2 = A2_PRIORITY(1) | (512+PANEL_2_START);	

	sprites[3].attribute0 = A0_COLOR_256 | A0_SHAPE_SQUARE | (160-32+23);
	sprites[3].attribute1 = A1_SIZE_8 | ((-2) & 0x1FF);
	sprites[3].attribute2 = A2_PRIORITY(0) | (512+ARROW_ON_START);				

	sprites[4].attribute0 = A0_COLOR_256 | A0_SHAPE_SQUARE | (160-32+15);
	sprites[4].attribute1 = A1_SIZE_8 | (40);
	sprites[4].attribute2 = A2_PRIORITY(0) | (512+ARROW_ON_START);	

	sprites[5].attribute0 = A0_COLOR_256 | A0_SHAPE_SQUARE | (160-32+7);
	sprites[5].attribute1 = A1_SIZE_8 | (40);
	sprites[5].attribute2 = A2_PRIORITY(0) | (512+ARROW_ON_START);	

	sprites[6].attribute0 = A0_COLOR_256 | A0_SHAPE_SQUARE | (160-33);
	sprites[6].attribute1 = A1_SIZE_8 | (40);
	sprites[6].attribute2 = A2_PRIORITY(0) | (512+ARROW_ON_START);	
	
	ShowSprite(0);	    
    
    //Load from sram
    
    if(!LoadPalette()) {
      MandelPal[0].r = MandelPal[0].g = MandelPal[0].b = 63;
      MandelPal[127].r = (1<<7); //interpolations bit setze
    }
    LoadPosition();
    ScreenPalette[128] = RGB(31,31,31);
  
    rx = (MandelPal[0].r&(0x7F));  
    gx = MandelPal[0].g; bx = MandelPal[0].b;

    mandelbrot();
    RecalcPalette();
  
    while(1) {
      HandleInput();
      WaitForVblank();
    }

//    gba_halt();
}

