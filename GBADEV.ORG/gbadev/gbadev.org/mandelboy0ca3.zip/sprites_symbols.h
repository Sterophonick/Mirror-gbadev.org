#ifndef __SPRITES_SYMBOLS
#define __SPRITES_SYMBOLS
#define PANEL_1_START		0
#define PANEL_2_START		64
#define ARROW_ON_START		128
#define ARROW_OFF_START		130
#define CURSOR_START		132
#define SPRITES_BYTES		140
#endif
