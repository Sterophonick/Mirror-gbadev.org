#ifndef _gbavars_h
#define _gbavars_h

FIXED reciprocal[128];

vu16* OAM = (vu16*)0x7000000; //the address of OAM 
OAMEntry sprites[128]; //My sprite array
pRotData rotData = (pRotData)sprites; //My rotation and scaling array

u32 clear = 0;

#endif