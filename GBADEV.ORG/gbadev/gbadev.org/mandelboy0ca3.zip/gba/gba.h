/*
 GBA.H
*/

#ifndef GBA_H
#define GBA_H

void __swi(0x12) LZ77UnCompVram(void *source, void *dest);
int __swi(0x6) Div(int Numerator, int Denominator);

#include "general.h"
#include "screen.h"
#include "system.h"
#include "dma.h"
#include "sprites.h"
#include "effects.h"

extern s32 mul32x32_64(s32,s32);
extern void MemCpy8(u8*,u8*,s32);

typedef struct tKomplex { 
  s32 re; //Realteil 24.8
  s32 im; //Imagin�rteil 24.8
} komplex; 
extern void mandelbrot(void);
extern void calcd(void);

#endif
//EOF
