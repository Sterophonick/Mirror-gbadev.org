#ifndef _GBAFUNCS_H
#define _GBAFUNCS_H

//Sprites
void CopyOAM(u32 nSpr);
void InitializeSprites(void);
void ChangeSprite(u32 id, u32 spriteid);
void SetSprite(u32 id, u32 x, s32 y);
void ShowSprites(u32 startid, u32 numsprites);
void ShowSprite(u32 spriteid);
void HideSprites(u32 startid, u32 numsprites);
void HideSprite(u32 spriteid);
void ClearSprites(u32 Start);

#endif