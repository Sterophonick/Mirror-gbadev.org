/*
 DMA.H
*/

#ifndef DMA_H
#define DMA_H

//DMA registers
#define REG_DMA0SAD					(*(vu32*)0x40000B0)
#define REG_DMA0SAD_L				(*(vu16*)0x40000B0)
#define REG_DMA0SAD_H				(*(vu16*)0x40000B2)
#define REG_DMA0DAD					(*(vu32*)0x40000B4)
#define REG_DMA0DAD_L				(*(vu16*)0x40000B4)
#define REG_DMA0DAD_H				(*(vu16*)0x40000B6)
#define REG_DMA0CNT					(*(vu32*)0x40000B8)
#define REG_DMA0CNT_L				(*(vu16*)0x40000B8)
#define REG_DMA0CNT_H				(*(vu16*)0x40000BA)
#define REG_DMA1SAD					(*(vu32*)0x40000BC)
#define REG_DMA1SAD_L				(*(vu16*)0x40000BC)
#define REG_DMA1SAD_H				(*(vu16*)0x40000BE)
#define REG_DMA1DAD					(*(vu32*)0x40000C0)
#define REG_DMA1DAD_L				(*(vu16*)0x40000C0)
#define REG_DMA1DAD_H				(*(vu16*)0x40000C2)
#define REG_DMA1CNT					(*(vu32*)0x40000C4)
#define REG_DMA1CNT_L				(*(vu16*)0x40000C4)
#define REG_DMA1CNT_H				(*(vu16*)0x40000C6)
#define REG_DMA2SAD					(*(vu32*)0x40000C8)
#define REG_DMA2SAD_L				(*(vu16*)0x40000C8)
#define REG_DMA2SAD_H				(*(vu16*)0x40000CA)
#define REG_DMA2DAD					(*(vu32*)0x40000CC)
#define REG_DMA2DAD_L				(*(vu16*)0x40000CC)
#define REG_DMA2DAD_H				(*(vu16*)0x40000CE)
#define REG_DMA2CNT					(*(vu32*)0x40000D0)
#define REG_DMA2CNT_L				(*(vu16*)0x40000D0)
#define REG_DMA2CNT_H				(*(vu16*)0x40000D2)
#define REG_DMA3SAD					(*(vu32*)0x40000D4)
#define REG_DMA3SAD_L				(*(vu16*)0x40000D4)
#define REG_DMA3SAD_H				(*(vu16*)0x40000D6)
#define REG_DMA3DAD					(*(vu32*)0x40000D8)
#define REG_DMA3DAD_L				(*(vu16*)0x40000D8)
#define REG_DMA3DAD_H				(*(vu16*)0x40000DA)
#define REG_DMA3CNT					(*(vu32*)0x40000DC)
#define REG_DMA3CNT_L				(*(vu16*)0x40000DC)
#define REG_DMA3CNT_H				(*(vu16*)0x40000DE)

//these defines let you control individual bit in the control register
#define DMA_ENABLE					0x80000000
#define DMA_INTERUPT_ENABLE			0x40000000
#define DMA_TIMEING_IMMEDIATE		0x00000000
#define DMA_TIMEING_VBLANK			0x10000000
#define DMA_TIMEING_HBLANK			0x20000000
#define DMA_TIMEING_SYNC_TO_DISPLAY 0x30000000
#define DMA_16						0x00000000
#define DMA_32						0x04000000
#define DMA_REPEATE					0x02000000
#define DMA_SOURCE_INCREMENT		0x00000000
#define DMA_SOURCE_DECREMENT		0x00800000
#define DMA_SOURCE_FIXED			0x01000000
#define DMA_DEST_INCREMENT			0x00000000
#define DMA_DEST_DECREMENT			0x00200000
#define DMA_DEST_FIXED				0x00400000
#define DMA_DEST_RELOAD				0x00600000

//these defines group common options to save typing. You may notice that I don't have to include the option to increment the source and address register as that is the default.
#define DMA_32NOW					DMA_ENABLE | DMA_TIMEING_IMMEDIATE |DMA_32 
#define DMA_16NOW					DMA_ENABLE | DMA_TIMEING_IMMEDIATE |DMA_16 


#define DMACopyCH0(source,dest,wc,mode)      REG_DMA0SAD = (u32)source; \
										     REG_DMA0DAD = (u32)dest; \
										     REG_DMA0CNT = wc | mode;

#define DMACopyCH1(source,dest,wc,mode)      REG_DMA1SAD = (u32)source; \
										     REG_DMA1DAD = (u32)dest; \
										     REG_DMA1CNT = wc | mode;

#define DMACopyCH2(source,dest,wc,mode)      REG_DMA2SAD = (u32)source; \
										     REG_DMA2DAD = (u32)dest; \
										     REG_DMA2CNT = wc | mode;

#define DMACopyCH3(source,dest,wc,mode)      REG_DMA3SAD = (u32)source; \
										     REG_DMA3DAD = (u32)dest; \
										     REG_DMA3CNT = wc | mode;
										     
//these #defines are very handy for cleaning ploted text
//since the source is fixed, the function will always copy 0
#define DMAClearMemory16(dest,wc)    			   REG_DMA3SAD = (u32)&clear; \
												   REG_DMA3DAD = (u32)dest; \
    											   REG_DMA3CNT = wc | DMA_ENABLE | DMA_TIMEING_IMMEDIATE | DMA_16 | DMA_SOURCE_FIXED;
    											   
#define DMAClearMemory32(dest,wc)      			   REG_DMA3SAD = (u32)&clear; \
    											   REG_DMA3DAD = (u32)dest; \
   												   REG_DMA3CNT = wc | DMA_ENABLE | DMA_TIMEING_IMMEDIATE | DMA_32 | DMA_SOURCE_FIXED;


#endif 
//EOF
