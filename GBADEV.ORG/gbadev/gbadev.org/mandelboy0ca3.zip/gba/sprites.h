/*
 SPRITE.H 
*/

#ifndef SPRITES_H
#define SPRITES_H

//Atribute0 stuff
//Bits:
// 15  14  13  12  11  10   9   8   7   6   5   4   3   2   1
//  Shape | C | M | DMode | SD| R |       Y Coordinate 
#define A0_ROTATION_FLAG			0x100  //Skalierung/Rotation aktivieren?
#define A0_SIZE_DOUBLE				0x200  //Die Gr��e des Zeichenbereiches (!) wird verdoppelt
#define A0_MODE_NORMAL				0x0
#define A0_MODE_TRANSPERANT			0x400
#define A0_MODE_PROHIBITED			0xC00
#define A0_MODE_WINDOWED			0x800
#define A0_MOSAIC					0x1000 //Mosaic flag
#define A0_COLOR_16					0x0000 //16 Farben
#define A0_COLOR_256				0x2000 //256 Farben
#define A0_SHAPE_SQUARE				0x0    //Beide Seiten gleich
#define A0_SHAPE_TALL				0x8000 //H�he verdoppelt (bei A1_SIZE_8 wird H�he 16)
#define A0_SHAPE_WIDE				0x4000 //Das gleiche mit der Breite

//Atribute1 stuff
//15  14  13  12  11  10   9   8   7   6   5   4   3   2   1   0 
// Size  |VF |HF |  RotData  |        X Coordinate 
#define A1_ROTDATAINDEX(n)			(n<<9) //Der Index zeigt in den OAM-Speicher, dort werden Eigenschaften gespeichert
#define A1_HORIZONTAL_FLIP			0x1000
#define A1_VERTICAL_FLIP			0x2000
#define A1_SIZE_8					0x0    //Die Gr��en
#define A1_SIZE_16					0x4000 //Da Sprites immer in einem 8x8 Raster gespeichert werden sind 
#define A1_SIZE_32					0x8000 //nur diese Gr��en m�glich
#define A1_SIZE_64					0xC000

//atribute2 stuff
// 15  14  13  12  11  10   9   8   7   6   5   4   3   2   1   0 
//Palette number |Priority|        Character Name (Index)
#define A2_PRIORITY(n)              ((n) << 10)
#define A2_PALETTE(n)               ((n) << 12)

//Der Speicherbereich, in dem die 8x8-Tiles gespeichert werden
#define SpriteMem                   ((vu16*)0x6014000)
#define SpriteMem8                  ((vu8*)0x6014000)
//#define SpriteMem                   ((vu16*)0x6010000)
#define SpritePaletteMem            ((vu16*)0x5000200)

/////structs/////
typedef struct tagOAMEntry
{
        u16 attribute0;
        u16 attribute1;
        u16 attribute2;
        u16 attribute3;
}OAMEntry,*pOAMEntry;

typedef struct tagRotData
{
        u16 filler1[3];
        u16 hdx;
        u16 filler2[3];
        u16 hdy; 
        u16 filler3[3];
        u16 vdx; 
        u16 filler4[3];
        u16 vdy;
}RotData,*pRotData;




#endif
//EOF
