#include "gba/gba.h"
#include "_gbavars.h"

//Copy sprite array to OAM
void CopyOAM(u32 nSpr) {
	DMACopyCH3((u32*)sprites,OAM,nSpr<<1,DMA_32NOW);
}

// Set sprites off screen
void InitializeSprites() {
	u16 loop;
	for (loop = 0; loop < 128; loop++) {
		sprites[loop].attribute0 = 160;	//y > 159
		sprites[loop].attribute1 = 240;	//x > 239
	}
	CopyOAM(128); //clear all sprites in sys memory
}

// Set sprites off screen
void ClearSprites(u32 start) {
	u16 loop;
	for (loop = start; loop < 128; loop++) {
		sprites[loop].attribute0 = 160;	//y > 159
		sprites[loop].attribute1 = 240;	//x > 239			
	}
}

void ChangeSprite(u32 id, u32 spriteid) {
    sprites[id].attribute2 = A2_PRIORITY(0) | (spriteid & 0x3FF);
}

void SetSprite(u32 id, u32 x, s32 y) {
    sprites[id].attribute0 = (sprites[id].attribute0 & 0xFF00) | (y & 0xFF);
    sprites[id].attribute1 = (sprites[id].attribute1 & 0xFE00) | (x & 0x1FF);
}

void ShowSprites(u32 startid, u32 numsprites) {
	DMACopyCH3((u32*)(sprites+startid),(u32*)(OAM+(startid<<2)),numsprites<<1,DMA_32NOW);
}

void ShowSprite(u32 spriteid) {
	DMACopyCH3((u32*)(sprites+spriteid),(u32*)(OAM+(spriteid<<2)),2,DMA_32NOW);
}

void HideSprite(u32 spriteid) {
    register vu16* p = OAM + (spriteid<<2); 
    *p = 160;
    *(p+1) = 240;
}

void HideSprites(u32 spriteid, u32 numsprites) {
int i;
register vu16* p;

  for(i=spriteid;i<=numsprites;i++) {
    p = OAM + (i<<2); 
    *p = 160;
    *(p+1) = 240;
  }
}