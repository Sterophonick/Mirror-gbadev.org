/*
 SCREEN.H
*/

#ifndef SCREEN_H
#define SCREEN_H

#define USEDOUBLEBUFFER

//Haupt screen register
#define REG_DISP_CNT				(*(vu16*)0x4000000)
#define SetMode(mode)				(REG_DISP_CNT=mode)

//Eigenschaften f�r REG_DISP_CNT
#define MODE_0                   0x0
#define MODE_1                   BIT0
#define MODE_2                   BIT1
#define MODE_3                   BIT0 | BIT1
#define MODE_4                   BIT2
#define MODE_5                   BIT0 | BIT2
#define BACKBUFFER               BIT4
#define H_BLANK_OAM              BIT5 
#define OBJ_MAP_2D               0x0
#define OBJ_MAP_1D               BIT6
#define FORCE_BLANK              BIT7
#define BG0_ENABLE               BIT8
#define BG1_ENABLE               BIT9 
#define BG2_ENABLE               BIT10
#define BG3_ENABLE               BIT11
#define OBJ_ENABLE               BIT12 
#define WIN1_ENABLE              BIT13 
#define WIN2_ENABLE              BIT14
#define WINOBJ_ENABLE            BIT15

//Interrupt-Einstellungen
#define REG_DISP_STAT				(*(vu16*)0x4000004)
#define REG_SCANLINE_COUNT			(*(vu16*)0x4000006)

#define DISPSTAT_VB			BIT0
#define DISPSTAT_HB			BIT1
#define DISPSTAT_YT			BIT2
#define DISPSTAT_V_IRQ		BIT3
#define DISPSTAT_H_IRQ		BIT4
#define DISPSTAT_YT_IRQ		BIT5

//Wieviele Zeilen schon gezeichnet wurden
#define REG_VCOUNT					(*(vu16*)0x4000006)

#ifdef USEDOUBLEBUFFER
  #define VideoBuffer               VBuffer 
#else
  #define VideoBuffer				((vu16*)0x6000000) //Bildschirmspeicher
#endif

#define VideoBuffer32				((vu32*)0x6000000) //Bildschirmspeicher
#define VideoBuffer16				((vu16*)0x6000000) //Bildschirmspeicher

//Bildschirmpalette
#define ScreenPalette				((vu16*)0x5000000) //Die Bildschirm-Farb-Palette
#define PlotPixel(x,y,c)			(VideoBuffer16[((y)*240)+(x)]=(c))
#define PlotPixel8(x,y,c1,c2)		(VideoBuffer16[((y)*120)+((x)>>1)]=(((c2)<<8) | (c1)))

//BG-Layer registers
#define REG_BG0CNT					(*(vu16*)0x4000008)
#define REG_BG1CNT					(*(vu16*)0x400000A)
#define REG_BG2CNT					(*(vu16*)0x400000C)
#define REG_BG3CNT					(*(vu16*)0x400000E)

//BGxCNT defines
#define BG_MOSAIC_ENABLE		 0x40
#define BG_COLOR256				 0x80
#define BG_COLOR16				 0x0

#define CharBaseBlock(n)		 ((n*0x4000)+0x6000000)
#define ScreenBaseBlock(n)		 ((n*0x800)+0x6000000)

#define CHAR_SHIFT				 2
#define SCREEN_SHIFT			 8
#define TEXTBG_SIZE_256x256		 0x0
#define TEXTBG_SIZE_256x512		 0x8000
#define TEXTBG_SIZE_512x256		 0x4000
#define TEXTBG_SIZE_512x512		 0xC000

#define ROTBG_SIZE_128x128		 0x0
#define ROTBG_SIZE_256x256		 0x4000
#define ROTBG_SIZE_512x512		 0x8000
#define ROTBG_SIZE_1024x1024	 0xC000

#define WRAPAROUND               0x1


//BG0 offset (scrolling)
#define REG_BG0HOFS              (*(vu16*)0x4000010)
#define REG_BG0VOFS              (*(vu16*)0x4000012)
//BG1 offset (scrolling)
#define REG_BG1HOFS              (*(vu16*)0x4000014)
#define REG_BG1VOFS              (*(vu16*)0x4000016)
//BG2 offset (scrolling)
#define REG_BG2HOFS              (*(vu16*)0x4000018)
#define REG_BG2VOFS              (*(vu16*)0x400001A)
//BG3 offset (scrolling)
#define REG_BG3HOFS              (*(vu16*)0x400001C)
#define REG_BG3VOFS              (*(vu16*)0x400001E)

#define REG_BG2PA                (*(vu16*)0x4000020)
#define REG_BG2PB                (*(vu16*)0x4000022)
#define REG_BG2PC                (*(vu16*)0x4000024)
#define REG_BG2PD                (*(vu16*)0x4000026)
#define REG_BG2X                 (*(vu32*)0x4000028)
#define REG_BG2X_L               (*(vu16*)0x4000028)
#define REG_BG2X_H               (*(vu16*)0x400002A)
#define REG_BG2Y                 (*(vu32*)0x400002C)
#define REG_BG2Y_L               (*(vu16*)0x400002C)
#define REG_BG2Y_H               (*(vu16*)0x400002E)
#define REG_BG3PA                (*(vu16*)0x4000030)
#define REG_BG3PB                (*(vu16*)0x4000032)
#define REG_BG3PC                (*(vu16*)0x4000034)
#define REG_BG3PD                (*(vu16*)0x4000036)
#define REG_BG3X                 (*(vu32*)0x4000038)
#define REG_BG3X_L               (*(vu16*)0x4000038)
#define REG_BG3X_H               (*(vu16*)0x400003A)
#define REG_BG3Y                 (*(vu32*)0x400003C)
#define REG_BG3Y_L               (*(vu16*)0x400003C)
#define REG_BG3Y_H               (*(vu16*)0x400003E)

//windowing stuff

#define WIN0H                    (*(vu16*)0x4000040)
#define WIN1H                    (*(vu16*)0x4000042)
#define WIN0V                    (*(vu16*)0x4000044)
#define WIN1V                    (*(vu16*)0x4000046)

#define WININ                    (*(vu16*)0x4000048)
#define WINOUT                   (*(vu16*)0x400004A)

#define TIMES_240(x) (((x) << 8) - ((x) << 4)) 
#define TIMES_120(x) (((x) << 7) - ((x) << 3)) 

// Screen dimensions
#define SCREEN_WIDTH             240
#define SCREEN_HALF_WIDTH        120
#define SCREEN_HEIGHT            160
#define SCREEN_HALF_HEIGHT       80


#endif
//EOF
