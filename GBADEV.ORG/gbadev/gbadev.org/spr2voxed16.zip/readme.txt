Spr2Vox is an new experiment done after talking with Jinroh. It turns a bitmap/sprite into 
a voxel model that can rotate in 3D. It�s pretty fast and cool :-)
