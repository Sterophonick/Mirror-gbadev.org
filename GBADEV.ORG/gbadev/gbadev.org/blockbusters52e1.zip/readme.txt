*******************
*   BLOCKBUSTERS  *
* by John Sensebe *
*******************

INTRODUCTION
------------
This is a new, improved version of the game originally submitted to the
Kraln.com contest in 2005.

The improvements include:

* New ball-to-paddle collision physics
* Faster ball
* Enemies, a la Arkanoid
* Ability to jump to any level you've reached previously
* New and improved levels
* New and improved graphics
* New and improved sound effects and music
* Numerous (but mostly minor) bugs fixed

OBJECT
------
Use you magic piano to keep the ball in play, hitting as many bricks as
possible. Collect power capsules for special abilities. If you can hack it,
you will discover the secret mastermind behind those crazy bricks!

CONTROLS
--------
D-pad - move left/right
L/R - quick-move left/right
A - launch ball
START - pause or exit game

NOTES
-----
Sound does not work 100% correctly in VBA.

CHEATS
------
During the title screen, input this sequence:

B, A, Down, R, Up, B

The music will restart when you do this. You will then have infinite lives,
and can use the SELECT buttonto skip levels. You cannot, however. post a high
score.

