Conway's Game of Life for GBA

by Andrew H. Cox

Contact:

	<andy4294967296@hotmail.com>
or:
	<ahcox@btinternet.com>

Latest Version:
	http://www.btinternet.com/~ahcox/GBA/Life.html

Come see my 3d stuff for the GBA here:
	http://www.btinternet.com/~ahcox/GBA/index.html

Controls:
    Start: Reset sim. The longer the button is held down, the more densly
           populated the resulting simulation grid will be.
    Select: Spray some random set cells into the sim.
            Use if it gets boring.

Hope you like it!