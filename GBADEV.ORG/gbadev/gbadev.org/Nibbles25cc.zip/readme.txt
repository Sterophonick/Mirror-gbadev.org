Nibbles v0.2
-------------
Britney Spears edition


aka Snake, SnakePit, ...

The classic game for Gameboy Advance.

#players: 1
#levels: 10

during gameplay
- use keypad to move snake around.
- press <B> to toggle music.
- press <START> to pause the game.
