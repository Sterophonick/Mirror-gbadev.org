gcc -Wall -O2 gbfs.c -o gbfs
gcc -Wall -O2 lsgbfs.c -o lsgbfs
gcc -Wall -O2 insgbfs.c -o insgbfs
gcc -Wall -O2 ungbfs.c -o ungbfs
gcc -Wall -O2 padbin.c -o padbin
gcc -Wall -O2 bin2s.c -o bin2s
