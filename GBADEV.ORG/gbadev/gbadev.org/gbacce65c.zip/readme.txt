Controls:
A - Selects stuff

//During game
B - Backs out of selection
Holding R over a piece - will display that pieces possible moves without actually selecting the piece.
Start - Will bring up the in-game menu. 

In-Game Menu:
From here you can Save or Load a game (only one) and you can exit to the title screen.  Press B to return to your game.

The moves that each piece can make is displayed once you select them.  Pieces that are in read during the selection phase are in danger.  Pieces that are green during the selection phase can attack a piece.  Once a piece is selected a new set of moves are displayed.  Pieces that are highlighted in Green are the pieces you can take.

The game continues till the General (the piece with the G) is taken.  Some rules apply.  Generals and Pieces can not move into a position where the two Generals are on the same Y line (line of sight).

The Move listing is rather lengthy so I guess I just let you figure that one out on your own.

Pardon grammar and spelling please :)