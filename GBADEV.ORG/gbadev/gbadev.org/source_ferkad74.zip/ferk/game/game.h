#ifndef GAME_GAME_H
#define GAME_GAME_H



#include "../core/gba.h"




#define CAR_COUNT 2
#define CAR_TYPE_COUNT 1




void init_game(void);
u8 game_loop(void);





#endif

