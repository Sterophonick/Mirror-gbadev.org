============================================
MarioBreak! 1.0 by Hugo Smits aka 0xC0DE
============================================

This isn�t 100% done, but it was rotting on my harddrive. So I decided to release it 
anyway. I might update this game with the extra stuff, when I get the time.

Although MarioBreak! is a breakout clone, it has alot of cool new gameplay.For example, 
if the ball hits the floor. The floor will sink, each floor tile can be hit 3 times before it
completely sinks into the lava. Mario ,afcourse, can't stand on the lava so that makes it 
quite hard. Luckily there are enough powerups for Mario to collect (such as a mushroom 
which restores the floor tiles). Also if mario collects coins, he can fire a canon with the 
A-button. The canon will take 1 row out. The more coins you collect the higher the canon 
will go. The game features multiple levels.

Enjoy playing!
