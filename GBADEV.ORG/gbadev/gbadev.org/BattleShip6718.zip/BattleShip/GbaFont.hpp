#include <mygba.h>

//////////////////////////////////////////////////////////////////////////////////////////
class GbaFont
{
public:
	GbaFont(unsigned short mode);
	~GbaFont() {}

    void Print(int, int, char *, unsigned short);
    void SetBackGroundColor(unsigned short bc) { m_BackGroundColor = bc; }
    	
private:
    inline u16 Rgb(u16 r, u16 g, u16 b) { return (u16)( r+(g<<5)+(b<<10) ); }
    
    void DrawPixel3(int x, int y, unsigned short color);
    void DrawPixel4(int x, int y, unsigned char color);
    void DrawPixel5(int x, int y, unsigned short color);
    void DrawChar(int, int, char, unsigned short);
    
    unsigned short  *m_VideoBuffer;
    unsigned short m_Mode;
    unsigned short m_BackGroundColor;
};
