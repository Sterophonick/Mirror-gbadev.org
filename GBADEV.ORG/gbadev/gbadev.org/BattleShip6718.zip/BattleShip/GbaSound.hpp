#ifndef _GBA_SOUND_
#define _GBA_SOUND_

#include "mygba.h"
#include "modules.h"

//////////////////////////////////////////////////////////////////////////////////////////
//
// GbaSound
//
// This class encapsulates the Krawall sound features.  The hardest part was converting
// a .wav to a .s3m.  The process I used was outlined on www.ngine.de.  You download
// Modplug Tracker.  Open the .wav file and in the general tab, click the "Change..."
// button and choose s3m.  Modplug was downloaded from www.modplug.com
//
class GbaSound
{
public:
	GbaSound() {
        kragInit(KRAG_INIT_STEREO);

        ham_StartIntHandler(INT_TYPE_TIM1,(void *)kradInterrupt);
    }
	~GbaSound() {}

    void Intro() { krapPlay(&mod_welcomeStereo,KRAP_MODE_JINGLE,0); }
	void Hit()   { krapPlay(&mod_hitStereo,KRAP_MODE_JINGLE,1); }
	void Miss()  { krapPlay(&mod_missStereo,KRAP_MODE_JINGLE,2); }
	
	void Process() { kramWorker(); }

};
#endif
