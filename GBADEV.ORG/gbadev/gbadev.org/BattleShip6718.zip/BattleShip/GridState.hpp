#ifndef _GRID_STATE_
#define _GRID_STATE_

//////////////////////////////////////////////////////////////////////////////////////////
class GridState
{
public:
	GridState()  {}
	~GridState() {}

    enum {
        EMPTY = 0,
        SHIP,
        MISS,
        HIT
    };
    
    void Reset()
    {
        for(short y=0; y<10; y++) {
            for(short x=0; x<10; x++) {
                m_Grid[x][y] = EMPTY;
            }
        }
    }
    void SetState(short x, short y, short state) { m_Grid[x][y] = state; };
    void SetStateShip(short x, short y) { m_Grid[x][y] = SHIP; }

    short State(short x, short y) { return m_Grid[x][y]; }
    bool ValidEmptySpace(short x, short y)
    {
        bool xValid = (x >= 0) && (x < 10);
        bool yValid = (y >= 0) && (y < 10);

        return ( xValid && yValid && (m_Grid[x][y] == EMPTY) );
    }
    
private:
	short m_Grid[10][10];	
};
#endif
