#ifndef _SHIP_
#define _SHIP_

#ifndef FALSE
#define FALSE 0
#endif

#ifndef TRUE
#define TRUE -1
#endif

//////////////////////////////////////////////////////////////////////////////////////////
//
// ShipBase
//
//  A storage class to keep track of a ship's state (hits, sinking).
//
class Ship
{
public:
	Ship(short length) { m_Length = length; Reset(); }
	~Ship() {}

	void SetLocation(short x, short y) { m_X[m_Count] = x; m_Y[m_Count] = y; m_Count++; }
    void Reset() {
        m_Count = 0;
        m_HitCount = 0;
        m_Sinking = 0;
        m_Ready = false;

        for(short i=0; i<5; i++) m_Hit[i] = false;
    }
    void SetReady() { m_Ready = true; }
    
    void SetHit(short x, short y) {
        for(short i=0; i<m_Length; i++){
            if( (x == m_X[i]) && (y == m_Y[i]) ) {
                if ( !m_Hit[i] ) {
                    m_Hit[i] = true;
                    m_HitCount++;
                    m_Sinking++;
                }
            }
        }
    }
    
    bool Sunk()    { return ( m_Sinking >= m_Length ); }
    bool Ready()   { return m_Ready; }
    
    short Length() { return m_Length; }
    short X(short i) { return m_X[i]; }
    short Y(short i) { return m_Y[i]; }
        
private:
    short m_Count;
    short m_HitCount;
    short m_X[5];
    short m_Y[5];
    
    short m_Length;
    short m_Sinking;
    
    bool m_Hit[5];
    bool m_Ready;
};
#endif
