#include "Fleet.hpp"

#include <math.h>
#include <stdlib.h>

//////////////////////////////////////////////////////////////////////////////////////////
//
// Fleet
//
//  Construct the fleet of ships and set the lengths.
//
Fleet::Fleet()
{
    // Remember the grid state (EMPTY, SHIP, HIT, MISS)
    m_Grid = new GridState();
    
	// Set the lengths of the 5 different battleships
	m_ShipLength[0] = 5;
	m_ShipLength[1] = 4;
	m_ShipLength[2] = 3;
	m_ShipLength[3] = 3;
	m_ShipLength[4] = 2;

    for (short i=0; i<5; i++)
        m_Ship[i] = new Ship( m_ShipLength[i] );
}

//////////////////////////////////////////////////////////////////////////////////////////
//
// SetShip
//
//  To set the ship location, give the starting x and y coordinates.  A ship can either
// be horizontal or vertical.  Now all that is left is to give the length (or the index
// to the ship's length).  Ship 0 has a length of 5, etc (see above constructor).
//
// Note that this function is called to set a known valid ship.
//
void Fleet::SetShip(short xStart, short yStart, bool horizontal, short ship)
{
    short x = xStart;
    short y = yStart;
    
    for(short i=0; i< m_ShipLength[ship]; i++) {
        if( horizontal) x = xStart + i;
        else            y = yStart + i;

        m_Grid->SetState(x,y,GridState::SHIP);
        
        m_Ship[ship]->SetLocation(x,y);
    }
    
    // Mark that the ship is ready
    m_Ship[ship]->SetReady();
}

//////////////////////////////////////////////////////////////////////////////////////////
//
// SetComputerFleet
//
//  Randomly places the computer's fleet on the grid.
//
void Fleet::SetComputerFleet()
{
    short xStart;
    short yStart;
    short vertical;
    short size;

    // Set all 5 ships for the computer
    for(short aShip=0; aShip<5; aShip++) {
    	bool getNewPosition = true;

    	while ( getNewPosition ) {
    	    // Assume the position is unless the guess is bad
    		getNewPosition = false;
    		
    		// Get random location and direction
   			xStart   = rand()%10;
	        yStart   = rand()%10;
            vertical = rand()%2;
            
    		size = m_ShipLength[aShip];

            // If this position is not valid, then we need a new ship position
            getNewPosition = !ValidShipPlacement(xStart,yStart,vertical,size);
    	}
    	
    	// We made it out so it must be a valid guess.  Set the ship
    	SetShip( xStart, yStart, !vertical, aShip);
	}
}

//////////////////////////////////////////////////////////////////////////////////////////
//
// ValidShipPlacement
//
// return bool - true if the guess is valid.
//
//  Pass in the ship (x,y, horizontal/vertical, and size) and test whether the ship's
// placement is valid (ie, is on the grid, not ontop of other ships).
//
bool Fleet::ValidShipPlacement(short xStart, short yStart, bool vertical, short size)
{
    // Assume a valid guess until proven otherwise.
    bool validShipPlacement = true;
    short x = xStart;
    short y = yStart;
    for(short i=0; i<size; i++) {
        if( vertical == 0 ) x = xStart + i;
        else                y = yStart + i;

        bool valid = m_Grid->ValidEmptySpace(x,y);

    	if ( !valid ) validShipPlacement = false;
    }
    
    return validShipPlacement;
}

//////////////////////////////////////////////////////////////////////////////////////////
//
// BadGuess
//
//  Check to make sure that a guess is OK (on the grid and hasn't already been guessed.
//
bool Fleet::BadGuess(short x, short y)
{
    bool badGuess;
    
    // A bad X or Y doesn't lie on the grid
    bool badX = (x<0) || (x>9);
    bool badY = (y<0) || (y>9);
    
    // Bad guess because of bad coordinates
    if ( badX || badY ){
        badGuess = true;
        
    // Bad guess if the spot is already a hit or miss
    } else {
        short gs = m_Grid->State(x,y);
        
        badGuess = (gs == GridState::MISS) || (gs == GridState::HIT);
    }
    
    return badGuess;
}

//////////////////////////////////////////////////////////////////////////////////////////
//
// NewGame
//
//  To be called at every new game to reset the grid and ship states.
//
void Fleet::NewGame(void)
{
    // Reset the grid states
    m_Grid->Reset();

    // Reset all of the ships
	for (short i=0; i<5; i++)
		m_Ship[i]->Reset();
}

//////////////////////////////////////////////////////////////////////////////////////////
//
// SetHit()
//
//  Mark the hit on the grid and the ship
//
void Fleet::SetHit (short x, short y)
{
    // Mark a hit on the grid
    m_Grid->SetState(x,y,GridState::HIT);

    // Also mark the hit on the ship state.  Since we don't know which ship, march through
    // all 5 ships looking for the hit.
    for(short i=0; i<5; i++) m_Ship[i]->SetHit(x,y);
}

//////////////////////////////////////////////////////////////////////////////////////////
//
// Hit()
//
// Mehtod to return true if a hit.
//
bool Fleet::Hit(short x, short y)
{
    // A hit if already a hit or occupied spot is a ship
    bool hit = (m_Grid->State(x,y) == GridState::SHIP ) ||
               (m_Grid->State(x,y) == GridState::HIT );
    
    return hit;
}
    
//////////////////////////////////////////////////////////////////////////////////////////
//
// Ready()
//
// Method that returns a true if all 5 ships have been set.
//
bool Fleet::Ready()
{
    bool allReady = m_Ship[0]->Ready();
    
    for(short i=1; i<5; i++) allReady = allReady && m_Ship[i]->Ready();
    
    return allReady;
}
    
//////////////////////////////////////////////////////////////////////////////////////////
//
// SunkShips()
//
// Method returns the number of ships that are sunk.
//
short Fleet::SunkShips()
{
    short sunkShips = 0;
    
    // Count the number of sunk ships
    for(short i=0; i<5; i++) if ( m_Ship[i]->Sunk() ) sunkShips++;

    return sunkShips;
}

