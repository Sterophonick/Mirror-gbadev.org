#include "Fleet.hpp"

////////////////////////////////////////////////////////////////
class BattleShipGame
{

public:
	BattleShipGame(unsigned int seed=34500);
	~BattleShipGame() {}

	void NewGame(void);
    void SetShip(short x, short y,  bool horizontal, short ship){ m_MyFleet->SetShip(x,y,horizontal,ship); }
    
	bool HumanWinner(void);
	bool EndGame(void);
    bool Guess(short x, short y);
    bool ComputerGuess(short *xGuess, short *yGuess);
    bool Ready()              { return ( MyShipsReady() && ComputerShipsReady() ); }
    bool MyShipsReady()       { return m_MyFleet->Ready(); }
    bool ComputerShipsReady() { return m_ComputerFleet->Ready(); }
    bool ValidShipPlacement(short xStart, short yStart, bool vertical, short size) {
        return m_MyFleet->ValidShipPlacement(xStart,yStart,vertical,size);
    }
    
    short MyShipsSunk()       { return m_MyFleet->SunkShips(); }
    short ComputerShipsSunk() { return m_ComputerFleet->SunkShips(); }

 	char *StringLocation(int i, int j);
 	
 	Ship *ComputerShip(short i) { return m_ComputerFleet->Boat(i); }
    
private:
	Fleet *m_ComputerFleet;
	Fleet *m_MyFleet;
	
	bool m_RandomGuess;
	short m_Xhit;
	short m_Yhit;
	short m_XhitStart;
	short m_YhitStart;
	bool m_DirectionFound;
	short m_DirectionIndex;
	short m_PreviousSunkShips;

	const int m_NumberOfShips;
};

