#ifndef _GBA_STRING_
#define _GBA_STRING_

#include <mygba.h>
#include <ctype.h>

//////////////////////////////////////////////////////////////////////////////////////////
//
// GbaString - a simple class to handle strings
//
class GbaString
{
public:
    GbaString()          { m_Str[0] = 0; m_HorizontalPixelSize = 8; }
	GbaString(char *str) { strcpy(m_Str,str); m_HorizontalPixelSize = 8; }
	~GbaString() {}

    char * StrPtr()   { return m_Str; }
    u16 Length()      { return strlen(m_Str); }
    u16 PixelLength() { return m_HorizontalPixelSize*Length(); }
    
    void SetX(u16 x)        { m_X = x; }
    void SetY(u16 y)        { m_Y = y; }
    void SetColor(u8 color) { m_Color = color; }
    
    void Set(char *str) { strcpy(m_Str,str); }
    
    char *Mid(unsigned short start , unsigned short num) {
        for(unsigned short i=0; i<num; i++)
            m_StrTemp[i] = m_Str[start+i];
        
        return m_StrTemp;
    }
    
    void Add(char *str) {
        unsigned short len  = strlen(str);
        unsigned short start=Length();
        unsigned short end  =start+len;
        
        for(unsigned short i=start; i<end; i++) m_Str[i] = str[i-start];
    }
    
    short Find(char *str, short start) {
        short len = strlen(str);
        short loc = -1;
        
        for(short i=start;i<Length();i++) if( !strncmp(&m_Str[i],str,len) ) loc = i;
        
        return loc;
    }
    
    char GetAt(u8 i) { return m_Str[i]; }
    
    void Delete(u8 start) {
        u16 len = Length();
        
        for(u16 i=start; i<len; i++) m_Str[start] = m_Str[start+1];
        
        m_Str[len-1] = 0;
    }

    void MakeUpper() {
        for(u16 i=0; i<Length(); i++) m_Str[i] = toupper( m_Str[i] );
    }
    
    u16 X()                { return m_X; }
    u16 Y()                { return m_Y; }
    unsigned short Color() { return m_Color; }

private:
    char m_Str[64];
    char m_StrTemp[64];
    u8 m_HorizontalPixelSize;
    u16 m_X;
    u16 m_Y;
    unsigned short m_Color;
};
#endif
