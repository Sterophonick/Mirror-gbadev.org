#include <mygba.h>

//////////////////////////////////////////////////////////////////////////////////////////
class GbaBattleShipGfx
{
public:
	GbaBattleShipGfx(unsigned short mode);
	~GbaBattleShipGfx() {}

    void DrawMiss(int left, int top) { DrawPegBase(left,top,RGB(255,255,255),16); }
    void DrawHit(int left, int top) { DrawPegBase(left,top,RGB(255,0,0),16); }
    
    void DrawSmallMiss(int left, int top) { DrawPegBase(left,top,RGB(255,255,255),8); }
    void DrawSmallHit(int left, int top) { DrawPegBase(left,top,RGB(255,0,0),8); }
    
    void DrawSmallShip(int left, int top,  bool horizontal, int size);
    
    void DrawShip(short x, short y) { DrawPegBase(x,y,RGB(200,200,200),16,true); }
    
    enum {
        VERTICAL=0,
        HORIZONTAL
    };

    enum {
        BLACK=0,
        WHITE,
        RED,
        GREEN,
        BLUE
    };

private:
    inline u16 Rgb(u16 r, u16 g, u16 b) { return (u16)( r+(g<<5)+(b<<10) ); }
    
    void DrawPegBase(int left, int top, unsigned short color,unsigned short size,
            bool inverse=false);
    void DrawPixel3(int x, int y, unsigned short color);
    void DrawPixel4(int x, int y, unsigned char color);
    void DrawPixel5(int x, int y, unsigned short color);
    
    unsigned short  *m_VideoBuffer;
    unsigned short m_Mode;
};
