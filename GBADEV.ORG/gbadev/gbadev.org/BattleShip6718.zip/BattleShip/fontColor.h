//////////////////////////////////////////////////////////////////////////////////////////
//
// Define font colors for GbaFont class
//
#ifndef _FONT_COLOR_H
#define _FONT_COLOR_H

#define FONT_BLACK 0
#define FONT_WHITE 1
#define FONT_RED 2
#define FONT_GREEN 3
#define FONT_BLUE 4


#endif
