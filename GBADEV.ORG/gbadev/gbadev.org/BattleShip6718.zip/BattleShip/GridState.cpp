#include "GridState.hpp"

//////////////////////////////////////////////////////////////////////////////////////////
void GridState::Reset()
{
    for(short y=0; y<10; y++) {
        for(short x=0; x<10; x++) {
            m_Grid[x][y] = EMPTY;
        }
    }
}

//////////////////////////////////////////////////////////////////////////////////////////
bool GridState::ValidEmptySpace(short x, short y)
{
    bool xValid = (x >= 0) && (x < 10);
    bool yValid = (y >= 0) && (y < 10);

    return ( xValid && yValid && (m_Grid[x][y] == EMPTY) );
}
