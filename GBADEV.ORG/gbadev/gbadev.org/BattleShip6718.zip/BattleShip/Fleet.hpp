#ifndef _FLEET_
#define _FLEET_

#include "Ship.hpp"
#include "GridState.hpp"

////////////////////////////////////////////////////////////////
class Fleet
{
public:
	Fleet();
	~Fleet() {}

	void NewGame(void);
	void SetShip(short x, short y,  bool horizontal, short ship);
    void SetComputerFleet();
    void SetMiss(short x, short y) { m_Grid->SetState(x,y,GridState::MISS); }
    void SetHit (short x, short y); 
    
    bool Hit(short x, short y);
    bool BadGuess(short x, short y);
    bool Ready();
    bool ValidShipPlacement(short xStart, short yStart, bool vertical, short size);
    
    short SunkShips();
    
    Ship *Boat(short i) { return m_Ship[i]; }

private:
	int m_ShipLength[5];
	
	GridState *m_Grid;
	Ship *m_Ship[5];
};
#endif
