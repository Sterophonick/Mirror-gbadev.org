#include <mygba.h>              // The Main HAM include
#include <stdio.h>

#include "BattleShipGame.hpp"   // The BattleShip game engine
#include "Ship.hpp"             // For drawing the computer's ship at game's end

#include "GbaBattleShipGfx.hpp" // The BattleShip graphics
#include "GbaString.hpp"        // String helper class
#include "GbaFont.hpp"          // For drawing text on the screen
#include "GbaButton.hpp"        // Button manager
#include "GbaSound.hpp"         // Sound manager

BattleShipGame *g_BattleShip;       // The game playing engine
bool g_CreateBattleShipGame = TRUE; // Create only one instance of the game per startup

GbaBattleShipGfx *g_Gfx;        // The graphics rountines manager class
GbaFont *g_Text;                // The manager of text on the screen
GbaButton *g_ButtonManager;     // The button manager
GbaSound *g_Sound;

u8 g_BoxObj;                    // The user's cursor to launch bombs at the computer's ships
bool g_BoxMove = FALSE;         // Flag to notify that the bomb cursor has been moved
short g_BoxX = 0;               // The bomb cursor position
short g_BoxY = 0;

u8 g_ShipObj[5];                // The sprites for setting the user's fleet
bool g_ShipMove = FALSE;
short g_ShipX = 0;
short g_ShipY = 0;
bool g_ShipHorizontal = TRUE;   // A ship is placed either horizontally or vertically
short g_Ship[5] = { 5,4,3,3,2 };// The length of the ships
short g_ShipIndex = 0;          // The marker for the current ship (total 5 ships)
bool g_SetFleet = FALSE;        // Flag that the user is to set his fleet.

u16 g_Counter = 0;              // Counter for random number seed

bool g_StartGame = FALSE;

#include "ship.raw.c"
#include "box.raw.c"
#include "bs.pal.c"
#include "grid.raw.c"

// Function Prototypes
void RunGame();         // VBL function to run the game
void QueryKeys();       // Query the GBA buttons
void DPadBox();         // Use the D pad to move the firing cursor
void DPadShip();        // Use the D pad for the user to set her fleet
void SetShipKeys();     // The button presses are for setting the user's fleet
void PlayGameKeys();    // The buttons are for playing the game

void PrintPressStart(u16 color);
void PrintFleetInstructions(u16 color);

u8 g_VideoMode = 3;

//////////////////////////////////////////////////////////////////////////////////////////
//
//  BattleShip for GBA
//
//  Trey Arthur
//  1/21/2005
//  trey_arthur@yahoo.com 
//
// This is my implementation of the classic BattleShip game.  In this version, you play
// against a computer opponent.  The coordinate system used is x is the horizontal
// coordinate with 0 at the left and 9 the far right position.  The y coordinate runs
// from a 0 position at the top and the 9 position at the bottom of the screen.
//
// In the classic game, there were 2 game books (that look like laptop computers) where
// the top grid was where you would guess where your opponent's ships were. In this game,
// this is the large grid (160x160 pixels).  The small grid is your bottom grid where your
// fleet is placed.  This is the small grid (80x80) pixels.
//
// The remaining 80x80 space at the bottom right is used as a status area for the game.
//
// Code for the fonts:  "Programming The Nintendo Game Boy Advance" by Jonathan S. Harbour
//  http://www.jharbour.com/gameboy/default.aspx
//
// Originally built with Visual HAM v2.8
//  http://www.ngine.de/site/index.php
//
int main()
{
    // Initialize HAMlib
    ham_Init();

    // Setup the background mode
    ham_SetBgMode(g_VideoMode);
    
    // Load the palette for the sprites (magenta box and ships)
    ham_LoadObjPal((void*)bs_Palette,256);
    
    // Load a bitmap of a large grid (user hit and misses) and a smaller grid (computer
    // guesses).
    ham_LoadBitmap((void *)grid_Bitmap);
    
    // Create the button manager
    g_ButtonManager = new GbaButton();
    
    // Create a text generator
    g_Text = new GbaFont(g_VideoMode);

    // Create the graphics manager for Battle Ship
    g_Gfx = new GbaBattleShipGfx(g_VideoMode);
    
    // Sound
    g_Sound = new GbaSound();
    
    // "Welcome to Battleship" said once on startup
    g_Sound->Intro();
    
    // Print a "Press Start" screen
    PrintPressStart( RGB(255,255,255) );

    // Create the box sprite object
    g_BoxObj = ham_CreateObj((void*)box_Bitmap,OBJ_SIZE_16X16,
                                 OBJ_MODE_NORMAL,1,0,0,0,0,0,0,g_BoxX,g_BoxY);
                                 
    // Turn the box off at the start of the game.  We won't need to see it until the fleet
    // is set.
    ham_SetObjVisible ( g_BoxObj , 0 );
    
    // Create the ship sprite objects
    for(u8 i=g_ShipX; i<5; i++) {
        g_ShipObj[i] = ham_CreateObj((void*)ship_Bitmap,OBJ_SIZE_16X16,
                                  OBJ_MODE_NORMAL,1,0,0,0,0,0,0,i*16,g_ShipY);
        ham_SetObjVisible ( g_ShipObj[i] , 0 );
    }
                                 
    // Draw the sprite
    ham_CopyObjToOAM();
    
    // Start the VBL interrupt handler that runs the BattleShip game
    ham_StartIntHandler(INT_TYPE_VBL,(void *)RunGame);
    
    // Infinite loop to keep the program running
    while(1) {}

    return 0;
} // End of main()

//////////////////////////////////////////////////////////////////////////////////////////
//
// RunGame()
//
// VBL function that runs the game.
//
void RunGame()
{
    // Run the sounds (if there are any)
    g_Sound->Process();
    
    // Tell the GBA to copy objects (sprites) to memory
    bool copyObj = FALSE;
    
    // Check if buttons have been pressed
    QueryKeys();
    
    // The grid box (bomb cursor) was moved
    if ( g_BoxMove ) {
        g_BoxMove = FALSE;
        
        // Once the game is on, print the location of the bomb cursor in green text
        if ( g_StartGame && !g_SetFleet ) {
            GbaString boxLoc = g_BattleShip->StringLocation( g_BoxX , g_BoxY );
            
            g_Text->Print( 168, 88, boxLoc.StrPtr(), RGB(0,255,0) );
        }
        
        // The large grid is 10 x 10 and each grid block is 16 pixels.
        // So, the multipication by 16 is to convert from grid space to GBA pixel space
        ham_SetObjXY( g_BoxObj , g_BoxX * 16 , g_BoxY * 16 );
        
        // Notify that a sprite has moved
        copyObj = TRUE;
    }
    
    // The ship was moved
    if ( g_ShipMove ) {
        g_ShipMove = FALSE;
        
        // Draw the current ship to be set (starts with length 5 ship)
        for (u8 i=0; i<g_Ship[g_ShipIndex]; i++) {
            u16 x = (g_ShipX+i) * 16;
            u16 y = g_ShipY * 16;
            if ( !g_ShipHorizontal ) {
                x = g_ShipX * 16;
                y = (g_ShipY+i) * 16;
            }
            
            ham_SetObjXY( g_ShipObj[i] , x , y);
        }
            
        copyObj = TRUE;
    }
    
    // Copy block sprite to hardware
    if ( copyObj ) ham_CopyObjToOAM(); 
    
    // Just run a counter around for seeding the random number generator
    g_Counter++;
    if ( g_Counter > 64000 ) g_Counter = 0;
}

//////////////////////////////////////////////////////////////////////////////////////////
//
// QueryKeys()
//
// This function checks for button presses.  Based on the stage of the game, the buttons
// do differnt things.  There are 2 stages to the game; setting the fleet and playing the
// game.
//
void QueryKeys()
{
    if ( g_SetFleet )
        SetShipKeys();
    else
        PlayGameKeys();
}


//////////////////////////////////////////////////////////////////////////////////////////
//
// SetShipKeys()
//
// The D pad is used to set the ships.
// The A button is used to set the ship (if it is a valid placement).
// The B button is used to rotate the ship between horizontal and vertical placement.
//
void SetShipKeys()
{
    // Arrow keys to place the fleet
    DPadShip();
    
    // The A button is to set the ship.  The current location must be a valid spot.
    if( g_ButtonManager->OneShotA() ) {
        if (g_BattleShip->ValidShipPlacement(g_ShipX,g_ShipY,!g_ShipHorizontal, g_Ship[g_ShipIndex]) )
        {
            // Get the next ship index
            u8 index = g_Ship[g_ShipIndex+1];

            // Turn off a peice of the ship being placed.
            ham_SetObjVisible ( g_ShipObj[index] , 0 );

            // Set the ship
            g_BattleShip->SetShip(g_ShipX,g_ShipY,g_ShipHorizontal,g_ShipIndex);

            // Get the orientation for the graphics to draw the ship on the small board.
            int orientation = GbaBattleShipGfx::HORIZONTAL;
            if ( !g_ShipHorizontal ) orientation = GbaBattleShipGfx::VERTICAL;
            g_Gfx->DrawSmallShip(g_ShipX,g_ShipY,orientation,g_Ship[g_ShipIndex]);

            // Increment for the next ship
            g_ShipIndex++;

            // After all 5 ships are set, it is time to play the game
            if ( g_ShipIndex > 4 ) {
                // The fleet is set so time to stop setting ships and play
                g_SetFleet = FALSE;

                // Turn off all of the ship sprite peices
                for(u8 i=0; i<5; i++) ham_SetObjVisible ( g_ShipObj[i] , 0 );

                // Turn on the bomb cursor
                ham_SetObjVisible ( g_BoxObj , 1 );
                
                // Erase fleet placement instructions
                PrintFleetInstructions( RGB(0,0,0) );
            }
            ham_CopyObjToOAM();
        }
    }
    
    // The B button rotates between a horizontal/vertical ship placement
    if( g_ButtonManager->OneShotB() )
    {
        // Change the orientation.
        g_ShipHorizontal = !g_ShipHorizontal;
        short xMax = 9;
        short yMax = 9;

        // Make sure that once rotated, the ship stays on the grid
        if ( g_ShipHorizontal ) xMax = 10 - g_Ship[ g_ShipIndex ];
        else                    yMax = 10 - g_Ship[ g_ShipIndex ];
        
        if ( g_ShipX > xMax ) g_ShipX = xMax;
        if ( g_ShipY > yMax ) g_ShipY = yMax;
        
        g_ShipMove = TRUE;
    }
}

//////////////////////////////////////////////////////////////////////////////////////////
//
// DPadShip()
//
// Use the Arrow keys to move the ship around the grid for placement.
//
void DPadShip()
{
    short x   = g_ShipX;
    short y   = g_ShipY;
    bool move = g_ShipMove;

    short xMax = 9;
    short yMax = 9;

    if ( g_ShipHorizontal ) xMax = 10 - g_Ship[ g_ShipIndex ];
    else                    yMax = 10 - g_Ship[ g_ShipIndex ];
    
    if ( g_ButtonManager->OneShotLeft() )
    {
        move = TRUE;

        x--;
        if ( x < 0 ) x = xMax;
    }
    if ( g_ButtonManager->OneShotRight() )
    {
        move = TRUE;

        x++;
        if ( x > xMax ) x = 0;
    }
    if ( g_ButtonManager->OneShotUp() )
    {
        move = TRUE;

        y--;
        if ( y < 0 ) y = yMax;
    }
    if ( g_ButtonManager->OneShotDown() )
    {
        move = TRUE;

        y++;
        if ( y > yMax ) y = 0;
    }

    g_ShipX = x;
    g_ShipY = y;
    g_ShipMove = move;
}

//////////////////////////////////////////////////////////////////////////////////////////
//
// PlayGameKeys()
//
// The buttons are now for playing the game.
// The D Pad moves the bomb cursor around the large grid.
// The A buttons fires a shot.
//
void PlayGameKeys()
{
    // Move the bomb cursor around the board via the arrow keys
    DPadBox();
    
    // Start the game
    if( g_ButtonManager->Start() )
    {
        if ( !g_StartGame ) {
            g_StartGame = TRUE;

            // Initialize the bomb cursor
            g_BoxMove = TRUE;
            g_BoxX = 0;
            g_BoxY = 0;
            
            // Initially, we set the fleet so turn off the bomb cursor
            ham_SetObjVisible ( g_BoxObj , 0 );

            // Erase the "Press Start" banner
            PrintPressStart( RGB(0,0,0) );

            // We only need to create the game playing object once
            if (g_CreateBattleShipGame) {
                g_CreateBattleShipGame = FALSE;
                g_BattleShip = new BattleShipGame(g_Counter);
            }

            // Initialize the fleet setting parameters
            g_ShipIndex = 0;
            g_SetFleet = TRUE;
            g_ShipX = 0;
            g_ShipY = 0;
            g_ShipMove = TRUE;
            
            // Turn on the ship placing sprites
            for(u8 i=0; i<5; i++) ham_SetObjVisible ( g_ShipObj[i] , 1 );
            
            // Notify the game to reset all states
            g_BattleShip->NewGame();

            // Clear the board and re draw the large and small grid
            ham_LoadBitmap((void *)grid_Bitmap);

            g_Text->Print( 168,98,"         ", RGB(0,0,0) );
            
            // Show ship placement instructions
            PrintFleetInstructions( RGB(255,255,255) );
        }
    }

    // Once the game has started and all of the ships are ready (all fleets have been
    // placed), then the A button launches a missile.
    if ( g_StartGame ) {
        if( g_ButtonManager->OneShotA() && g_BattleShip->Ready() )
        {
       	    // Check to see if the guess is a hit or miss
            bool hit = g_BattleShip->Guess( g_BoxX , g_BoxY );

            // Draw a hit and play a explosion sound
            if ( hit ) {
                g_Gfx->DrawHit(g_BoxX,g_BoxY);
                g_Sound->Hit();
            }
            else       g_Gfx->DrawMiss(g_BoxX,g_BoxY);

            // Now it is the computer's turn
            short x,y;
            hit = g_BattleShip->ComputerGuess( &x, &y );

            // Draw the hit or miss on the small board
    		if ( hit ) g_Gfx->DrawSmallHit(x,y);
    		else       g_Gfx->DrawSmallMiss(x,y);
    		
    		// Draw the computer's guess in red text
    		GbaString boxLoc = g_BattleShip->StringLocation( x , y );
            g_Text->Print( 216, 88, boxLoc.StrPtr(), RGB(255,0,0) );

            // Get the sunk ships in both fleets
    		short computerShipsSunk = g_BattleShip->ComputerShipsSunk();
    		short myShipsSunk       = g_BattleShip->MyShipsSunk();
    		
    		// Display how many ships the user has sunk in green
    		char shipsSunk[8];
    		sprintf( shipsSunk,"%d",computerShipsSunk );
    		g_Text->Print( 160,118,"SUNK", RGB(0,255,0) );
    		g_Text->Print( 168,128,shipsSunk, RGB(0,255,0) );
    		
    		// Display the number of ships the computer has sunk in red
    		sprintf( shipsSunk,"%d",myShipsSunk );
    		g_Text->Print( 208,118,"SUNK"   , RGB(255,0,0) );
    		g_Text->Print( 216,128,shipsSunk, RGB(255,0,0) );
    		
    		// Check if it is the end of the game
    		if ( g_BattleShip->EndGame() ) {
    		    g_StartGame = FALSE;
    		    
    		    // Determine the winner
    		    if ( g_BattleShip->HumanWinner() )
    		      g_Text->Print( 168,98,"YOU WIN!", RGB(255,255,255) );
  		        else
                  g_Text->Print( 168,98,"YOU LOSE!", RGB(255,255,255) );
                  
                // Reveal the computers ships
                Ship *ship;
                for(short i=0; i<5; i++) {
                    ship = g_BattleShip->ComputerShip(i);
                    
                    // Draw the ship
                    for(short j=0; j<ship->Length(); j++) {
                        g_Gfx->DrawShip( ship->X(j) , ship->Y(j) );
                    }
                }
                    
                // Print the "Press Start" message.
                g_Text->Print( 176,138,"PRESS", RGB(255,255,255) );
    		    g_Text->Print( 176,148,"START", RGB(255,255,255) );
		    }
        }
    }
}

//////////////////////////////////////////////////////////////////////////////////////////
//
// DPadBox()
//
// This function moves the bomb cursor around the board during game play.
//
void DPadBox()
{
    short x;
    short y;
    bool move;

    x = g_BoxX;
    y = g_BoxY;
    move = g_BoxMove;

    if ( g_ButtonManager->OneShotLeft() )
    {
        move = TRUE;

        x--;
        if ( x < 0 ) x = 9;
    }
    if ( g_ButtonManager->OneShotRight() )
    {
        move = TRUE;

        x++;
        if ( x > 9 ) x = 0;
    }
    if ( g_ButtonManager->OneShotUp() )
    {
        move = TRUE;

        y--;
        if ( y < 0 ) y = 9;
    }
    if ( g_ButtonManager->OneShotDown() )
    {
        move = TRUE;

        y++;
        if ( y > 9 ) y = 0;
    }

    g_BoxX = x;
    g_BoxY = y;
    g_BoxMove = move;
}

//////////////////////////////////////////////////////////////////////////////////////////
//
// PrintPressStart()
//  input u16 color - the color of the displayed text
//
// Print a start up message in the bottom right corner of the screen.
//
void PrintPressStart(u16 color)
{
    g_Text->Print( 160,80,"BATTLESHIP", color );

    g_Text->Print( 184,88,"V1.0",color);

    g_Text->Print( 176,112,"PRESS",color);
    g_Text->Print( 176,128,"START",color);
    
    g_Text->Print( 168,150,"TREYWARE",color);
}

//////////////////////////////////////////////////////////////////////////////////////////
//
// PrintFleetInstructions()
//  input u16 color - the color of the displayed text
//
// Print the instructions on setting your fleet.
//
void PrintFleetInstructions(u16 color)
{
    g_Text->Print( 160,84,"SET SHIPS", color );

    g_Text->Print( 160,114,"BUTTON:",color);
    g_Text->Print( 160,128,"A-SET SHIP",color);
    g_Text->Print( 160,138,"B-ROTATE",color);
}
