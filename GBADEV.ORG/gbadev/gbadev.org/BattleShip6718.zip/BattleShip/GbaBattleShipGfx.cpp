#include "GbaBattleShipGfx.hpp"

#define W 1
unsigned short smallPeg[] =
{
0,0,0,0,0,0,0,0,
0,0,W,W,W,W,0,0,
0,W,W,W,W,W,W,0,
0,W,W,W,W,W,W,0,
0,W,W,W,W,W,W,0,
0,W,W,W,W,W,W,0,
0,0,W,W,W,W,0,0,
0,0,0,0,0,0,0,0,
};

unsigned short peg[] =
{
0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,
0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,
0,0,0,0,0,W,W,W,W,W,W,0,0,0,0,0,
0,0,0,W,W,W,W,W,W,W,W,W,W,0,0,0,
0,0,0,W,W,W,W,W,W,W,W,W,W,0,0,0,
0,0,W,W,W,W,W,W,W,W,W,W,W,W,0,0,
0,0,W,W,W,W,W,W,W,W,W,W,W,W,0,0,
0,0,W,W,W,W,W,W,W,W,W,W,W,W,0,0,
0,0,W,W,W,W,W,W,W,W,W,W,W,W,0,0,
0,0,W,W,W,W,W,W,W,W,W,W,W,W,0,0,
0,0,W,W,W,W,W,W,W,W,W,W,W,W,0,0,
0,0,0,W,W,W,W,W,W,W,W,W,W,0,0,0,
0,0,0,W,W,W,W,W,W,W,W,W,W,0,0,0,
0,0,0,0,0,W,W,W,W,W,W,0,0,0,0,0,
0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,
0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,
};

//////////////////////////////////////////////////////////////////////////////////////////
//
// GbaBattleShipGfx
//
//  Initialize the color palette for the fonts.  Default the font background color to
// black.
//
GbaBattleShipGfx::GbaBattleShipGfx(unsigned short mode)
{
    if ( mode == 4 ) {
        unsigned short* paletteMem = (unsigned short*)0x5000000;

        paletteMem[BLACK] = Rgb(0,0,0);
        paletteMem[WHITE] = Rgb(31,31,31);
        paletteMem[RED]   = Rgb(31,0,0);
        paletteMem[GREEN] = Rgb(0,31,0);
        paletteMem[BLUE]  = Rgb(0,0,31);
    }

    // Set the video buffer
    m_VideoBuffer = (unsigned short*)0x6000000;
    
    // Default the background color to black
    //SetBackGroundColor(FONT_BLACK);
    
    // Set the video mode
    m_Mode = mode;
}

//////////////////////////////////////////////////////////////////////////////////////////
//
// DrawPixel3
//
// Draws a pixel in mode 3
//
void GbaBattleShipGfx::DrawPixel3(int x, int y, unsigned short color)
{
    m_VideoBuffer[y * 240 + x] = color;
}

//////////////////////////////////////////////////////////////////////////////////////////
//
// DrawPixel4
//
// Draws a pixel in video mode 4
//
void GbaBattleShipGfx::DrawPixel4(int x, int y, unsigned char color)
{
    unsigned short pixel;
    unsigned short offset = (y * 240 + x) >> 1;
    pixel = m_VideoBuffer[offset];
    
    if (x & 1)
        m_VideoBuffer[offset] = (color << 8) + (pixel & 0x00FF);
    else
        m_VideoBuffer[offset] = (pixel & 0xFF00) + color;
}

//////////////////////////////////////////////////////////////////////////////////////////
//
// DrawPixel5
//
// Draws a pixel in video mode 5
//
void GbaBattleShipGfx::DrawPixel5(int x, int y, unsigned short color)
{
    m_VideoBuffer[y * 160 + x] = color;
}

//////////////////////////////////////////////////////////////////////////////////////////
//
// DrawPegBase
//
// Draws a peg one pixel at a time
//
void GbaBattleShipGfx::DrawPegBase(int left, int top, unsigned short color,
        unsigned short size, bool inverse)
{
    int x,y;
    int xs, ys;
    int draw;
    
    if ( size == 8 ) xs = 160 + 8*left;
    else             xs = 16*left;
    ys = size*top;

    unsigned short *array = peg;
    if (size == 8) array = smallPeg;
    
    for (y = 0; y < size; y++)
    for (x = 0; x < size; x++)
    {
        // grab a pixel from the small peg
        draw = array[y * size + x];
        if ( inverse ) draw = !draw;

        // Call the correct DrawPixel method
		switch ( m_Mode ) {
		case 3:
			if (draw) DrawPixel3(xs + x, ys + y, color);
			break;
		case 4:
            if (draw) DrawPixel4(xs + x, ys + y, color);
            break;
  		case 5:
            if (draw) DrawPixel5(xs + x, ys + y, color);
            break;
        }
    }
}

//////////////////////////////////////////////////////////////////////////////////////////
//
// DrawSmallShip
//
// Draws the ships
//
void GbaBattleShipGfx::DrawSmallShip(int left, int top, bool horizontal, int size)
{
    for(u8 i=0; i< size; i++) {
        u8 x = left;
        u8 y = top;
        
        if( horizontal) x += i;
        else            y += i;
        
        DrawPegBase(x,y,RGB(200,200,200),8,true);
    }
}

