Battleship for GBA

Trey Arthur
trey_arthur@yahoo.com
1/21/2005

This is a single player GBA version of the classic game Battleship.  The main purpose for writing this was to
expand on my learning GBA, HAM, Krawall, gfx2gba, etc.  The game is written to replicate the classic look of
the game (read as, the dude was too lazy to make snazzy graphics).  But, you have the source so have at it.  The
game is single player, man against machine.

The game is written in C++ using Visual HAM and HAM lib version 2.8 and Krawall distributed with HAM.

If you have comments or additions, I would be interested in hearing about them.  

The controls are:

When setting the fleet:
 Left, Right, Up and Down move the current ship for you to place.
 A - set the ship
 B - rotate between a horizontal and vertical ship

Playing the game:
  Left, Right, Up and Down move the bombing cursor to your desired guess.
  A - Drop the bomb

Revision history - the current version is displayed on the start up splash screen

version 1.0:
 - inital release

    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.