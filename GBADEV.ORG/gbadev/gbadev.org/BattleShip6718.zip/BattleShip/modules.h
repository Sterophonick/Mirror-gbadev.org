#ifndef __MODULES_H__
#define __MODULES_H__

#include "mtypes.h"

extern const Module mod_welcomeStereo;
extern const Module mod_hitStereo;
extern const Module mod_missStereo;

#endif
