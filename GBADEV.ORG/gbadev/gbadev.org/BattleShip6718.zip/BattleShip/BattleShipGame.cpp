#include "BattleShipGame.hpp"

#include <math.h>
#include <stdlib.h>

//////////////////////////////////////////////////////////////////////////////////////////
//
// BattleShipGame
//
//  Construct the game and seed the random number generator.  Create a fleet for the
// computer and one for the player.  Each fleet has 5 ships.
//
BattleShipGame::BattleShipGame(unsigned int seed):m_NumberOfShips(5)
{
    srand( seed );
    
	m_ComputerFleet = new Fleet();
	m_MyFleet       = new Fleet();
}

//////////////////////////////////////////////////////////////////////////////////////////
//
// NewGame()
//
// Call new game for each new game to reset both fleets.
//
void BattleShipGame::NewGame(void)
{
	m_ComputerFleet->NewGame();
    m_ComputerFleet->SetComputerFleet();
    
	m_MyFleet->NewGame();

    m_RandomGuess = true;
    m_DirectionFound = false;
    m_PreviousSunkShips = 0;
}

//////////////////////////////////////////////////////////////////////////////////////////
//
// Guess
//
//  The human makes a guess.
//
bool BattleShipGame::Guess(short x, short y)
{	
	bool hit = m_ComputerFleet->Hit(x,y);
	
	if (hit) m_ComputerFleet->SetHit(x,y);
    else     m_ComputerFleet->SetMiss(x,y);
	
	return hit;
}

//////////////////////////////////////////////////////////////////////////////////////////
//
// ComputerGuess
//
// The GBA makes a guess.  This is the computer's brain for playing the game.
//
bool BattleShipGame::ComputerGuess(short *xGuess, short *yGuess)
{
	bool hit = false;
	
	// The computer doesn't have a good guess so make a random guess	
	if ( m_RandomGuess ) {
	    bool keepGuessing = true;
	    
	    short ix;
	    short even[5] = { 0,2,4,6,8 };
	    short odd[5]  = { 1,3,5,7,9 };
	    
	    // This is a little smarter than just a blind random guess.  Instead of just
	    // firing randomly at sea looking for a hit, even rows only fire even colums
        // and likewise for odd rows and columns.  Consider 2 rows:  you could march
	    // down each row for a total of 20 hits (turns).  Or, fire at every even column
	    // for the first row and every odd column for the second row.  This only
	    // requires 10 turns (half of the original) for exactly the same outcome.
	    while ( keepGuessing ) {
	        keepGuessing = false;
	        
	        // get a random index for the even or odd array
	        ix      = rand()%5;
	        *yGuess = rand()%10;
	        
	        // even rows, fire at even columns; likewise for odd rows and columns
	        if ( *yGuess%2 == 0 ) *xGuess = even[ ix ];
	        else                  *xGuess = odd [ ix ];
	
	       // Make sure the computer's current guess hasn't already been guessed
	        if( m_MyFleet->BadGuess( *xGuess, *yGuess ) ) keepGuessing = true;
        }
        
        // Check for a hit on the random guess
        hit = m_MyFleet->Hit(*xGuess,*yGuess);
	
	   // The computer got lucky and found a hit.  For the next turn, the computer
	   // can be smart for sinking the ship.
	    if ( hit ) {
	        // Set the computer's "memory" of the hit
            m_MyFleet->SetHit (*xGuess,*yGuess);
            
            // Store the hit for the next turn
            m_Xhit = *xGuess;
            m_Yhit = *yGuess;
            
            // The computer stores the starting hit incase he needs to change directions
            // when trying to sink the ship.  So, if hit the ship anywhere but and end,
            // you will need to change directions to finish sinking the ship.
            m_XhitStart = m_Xhit;
            m_YhitStart = m_Yhit;
            
            // We got a hit so next turn, be smart about finding and sinking the ship
            m_RandomGuess = false;
        }
        // Remember the misses so they are not guessed again
        else m_MyFleet->SetMiss(*xGuess,*yGuess);
        
    // The computer knows a ship is around
	} else {
	    // xAdd and yAdd have the computer check around the hit
	    // Basically, the computer will always look south, then proceed clockwise for
	    // the next hit.
	    short xAdd[4] = { 0,-1, 0, 1 };
	    short yAdd[4] = { 1, 0,-1, 0 };
	    
	    // This array stores the indices of the opposite directions defined in xAdd and
	    // yAdd.  xAdd[0] and yAdd[0] define south.  north is at the xAdd[2] and yAdd[2].
	    short oppDir[4] = { 2, 3, 0, 1 };
	    
	    // Two hits gives the computer a direction to try to sink the ship
        short i=0;
        if ( m_DirectionFound ) {
            // Continue guessing along the current direction
            *xGuess = m_Xhit + xAdd[m_DirectionIndex];
   	        *yGuess = m_Yhit + yAdd[m_DirectionIndex];
   	        
   	        // The hit may have been in the middle of the ship.
   	        // Try bombing in the opposite direction from the first hit
   	        if( m_MyFleet->BadGuess( *xGuess, *yGuess ) ) {
                m_DirectionIndex = oppDir[ m_DirectionIndex ];
                
   	            *xGuess = m_XhitStart + xAdd[m_DirectionIndex];
   	            *yGuess = m_YhitStart + yAdd[m_DirectionIndex];
   	            
   	            // If we find all the hits between two misses, then multiple ships have
   	            // been hit.  Tell the computer to get a new direction for the next round
   	            // of bombing.
   	            if( m_MyFleet->BadGuess( *xGuess, *yGuess ) ) {
   	                m_DirectionFound = false;
   	                
   	                // Current direction and opposite direction didn't sink the ship.
   	                // Look for a new direction.
                    bool keepGuessing = true;
    	            while ( keepGuessing ) {
    	               keepGuessing = false;
    	               *xGuess = m_Xhit + xAdd[i];
    	               *yGuess = m_Yhit + yAdd[i];
    	               i++;
    	
    	               if( m_MyFleet->BadGuess( *xGuess, *yGuess ) ) keepGuessing = true;
                    }
                    i--;
                }
            }
        // The computer looks around the hit in search of another hit to find the
        // bombing direction.  Continue around the horn until a hit is made.  With
        // the second hit, the computer knows a direction.
        } else {
            bool keepGuessing = true;
    	    while ( keepGuessing ) {
    	        keepGuessing = false;
    	        *xGuess = m_Xhit + xAdd[i];
    	        *yGuess = m_Yhit + yAdd[i];
    	        i++;
    	
    	        // If the guess is bad, continue around the horn to get a good direction.
    	        if( m_MyFleet->BadGuess( *xGuess, *yGuess ) ) keepGuessing = true;
            }
            i--;
        }
        
        // Check if the guess is a hit
        hit = m_MyFleet->Hit(*xGuess,*yGuess);
	
	    if ( hit ) {
	        // If the computer didn't have a direction before, now we do.
            if ( !m_DirectionFound ) m_DirectionIndex = i;
            m_DirectionFound = true;
	        
	        // Store the number of sunk ships before the hit is registered
	        m_PreviousSunkShips = m_MyFleet->SunkShips();
	        
	        // Register the hit
            m_MyFleet->SetHit (*xGuess,*yGuess);
            
            // The computer sunk the ship if this hit changes the number of ships sunk
            if ( m_MyFleet->SunkShips() != m_PreviousSunkShips ) {
                m_DirectionFound = false;
   	            m_RandomGuess    = true;
            }

            // Store the hit for the next turn
            m_Xhit = *xGuess;
            m_Yhit = *yGuess;
        }
        else       m_MyFleet->SetMiss(*xGuess,*yGuess);
    }

	return hit;
}

//////////////////////////////////////////////////////////////////////////////////////////
//
// HumanWinner()
//
// Return true if the human won.
//
bool BattleShipGame::HumanWinner(void)
{
	bool winner = (m_ComputerFleet->SunkShips() >= 5);

	return winner;
}

//////////////////////////////////////////////////////////////////////////////////////////
//
// EndGame()
//
// Check to see if the game is over (does someone have 5 sunk ships)
//
bool BattleShipGame::EndGame(void)
{
	bool endGame = (m_ComputerFleet->SunkShips() >= 5) || (m_MyFleet->SunkShips() >= 5);

	return endGame;
}
//////////////////////////////////////////////////////////////////////////////////////////
//
// StringLocation
//
// Convert a x,y coordinate into the Battleship coordinate system.  (letter for rows
// and number for column).  Column 0 is 10.
//
char *BattleShipGame::StringLocation(int i, int j)
{
	static char alphaNum[2];

    alphaNum[0] = j + 'A';

	if ( i == 9 ) alphaNum[1] = '0';		// Special case for 10 (ie, 0 = 10)
	else          alphaNum[1] = i + '1';

	return alphaNum;
}

