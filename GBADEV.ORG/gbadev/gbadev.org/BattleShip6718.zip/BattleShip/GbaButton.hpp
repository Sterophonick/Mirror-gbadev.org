#include <mygba.h>

/////////////////////////////////////
class GbaButton
{
public:
	GbaButton();
	~GbaButton() {}

    bool Left()  { return F_CTRLINPUT_LEFT_PRESSED; }
    bool Right() { return F_CTRLINPUT_RIGHT_PRESSED; }
    bool Up()    { return F_CTRLINPUT_UP_PRESSED; }
    bool Down()  { return F_CTRLINPUT_DOWN_PRESSED; }
    
    bool Start() { return F_CTRLINPUT_START_PRESSED; }
    bool Select(){ return F_CTRLINPUT_SELECT_PRESSED; }
    
    bool A() { return F_CTRLINPUT_A_PRESSED; }
    bool B() { return F_CTRLINPUT_B_PRESSED; }
    bool L() { return F_CTRLINPUT_L_PRESSED; }
    bool R() { return F_CTRLINPUT_R_PRESSED; }
    
    bool OneShotLeft()  { return OneShot( eLeft  , F_CTRLINPUT_LEFT_PRESSED ); }
    bool OneShotRight() { return OneShot( eRight , F_CTRLINPUT_RIGHT_PRESSED ); }
    bool OneShotUp()    { return OneShot( eUp    , F_CTRLINPUT_UP_PRESSED ); }
    bool OneShotDown()  { return OneShot( eDown  , F_CTRLINPUT_DOWN_PRESSED ); }
    
    bool OneShotStart()  { return OneShot( eStart  , F_CTRLINPUT_START_PRESSED ); }
    bool OneShotSelect() { return OneShot( eSelect , F_CTRLINPUT_SELECT_PRESSED ); }
    
    bool OneShotA()     { return OneShot( eA     , F_CTRLINPUT_A_PRESSED ); }
    bool OneShotB()     { return OneShot( eB     , F_CTRLINPUT_B_PRESSED ); }
    bool OneShotL()     { return OneShot( eL     , F_CTRLINPUT_L_PRESSED ); }
    bool OneShotR()     { return OneShot( eR     , F_CTRLINPUT_R_PRESSED ); }
    	
private:
    enum {
        eUp = 0,
        eDown,
        eLeft,
        eRight,
        eA,
        eB,
        eR,
        eL,
        eStart,
        eSelect
    };
    bool OneShot(u8 button, bool buttonPress);
    
    bool m_Arm[10];
};
