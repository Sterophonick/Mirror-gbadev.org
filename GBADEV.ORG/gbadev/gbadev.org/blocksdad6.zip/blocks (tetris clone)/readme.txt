This is my first attempt at making a game for the gba.

Its a tetris clone done in mode 4. 

There is some useful information on my code like how to to make random numbers, print text, intergers,
images. Save on to the memory, etc.

I got started thanks to loirak. You can visit his website at http://www.loirak.com/gameboy/gbatutor.html

and you can visit my website at http://www.geocities.com/supersatanicfreak/news.html

The game doesnt have sound yet but i'll get to it eventually.

enjoy_

   SatanicFreak, from Madman productions.
     



