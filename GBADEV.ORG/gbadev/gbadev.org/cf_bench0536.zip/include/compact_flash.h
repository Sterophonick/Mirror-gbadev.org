/*
	compact_flash.h
	By chishm (Michael Chisholm)

	Routines for reading a compact flash card
	using the GBA Movie Player or M3.

	Some FAT routines are based on those in fat.c, which
	is part of avrlib by Pascal Stang.

	CF routines modified with help from Darkfader
	M3 routines added by MightyMax

	This software is completely free. No warranty is provided.
	If you use it, please give me credit and email me about your
	project at chishm@hotmail.com

	See gba_nds_fat.txt for help and license details.
*/

//---------------------------------------------------------------

#ifndef _CF_INCLUDED
#define _CF_INCLUDED

// When compiling for NDS, make sure NDS is defined
// If using this on the ARM7, you will need to explicitly define NDS
#ifdef ARM9
 #ifndef NDS
  #define NDS 1
 #endif
#endif

#ifdef NDS
// Appropriate placement of CF functions and data
 #include <nds/jtypes.h>
 #ifdef ARM7
  #define _CODE_IN_RAM __attribute__((section (".iwram"),long_call))
  #define _VARS_IN_RAM __attribute__((section (".bss")))
 #else
  #define _CODE_IN_RAM __attribute__((section (".ewram"),long_call))
  #define _VARS_IN_RAM __attribute__ ((section (".sbss")))
 #endif
#else
 #include "gba_types.h"
 #define _CODE_IN_RAM __attribute__((section (".iwram"),long_call))
 #define _VARS_IN_RAM __attribute__ ((section (".sbss")))
#endif

//---------------------------------------------------------------
#ifdef __cplusplus
extern "C" {
#endif
//---------------------------------------------------------------

/*-----------------------------------------------------------------
M3_Unlock
Returns true if M3 was unlocked, false if failed
Added by MightyMax
-----------------------------------------------------------------*/
_CODE_IN_RAM bool M3_Unlock(void);

/*-----------------------------------------------------------------
CF_IsInserted
Is a compact flash card inserted?
bool return OUT:  true if a CF card is inserted
-----------------------------------------------------------------*/
_CODE_IN_RAM bool CF_IsInserted (void);

/*-----------------------------------------------------------------
CF_ClearStatus
Is a compact flash card inserted?
bool return OUT:  true if a CF card is inserted
-----------------------------------------------------------------*/
_CODE_IN_RAM bool CF_ClearStatus (void);

/*-----------------------------------------------------------------
CF_ReadSectors
Read 512 byte sector numbered "sector" into "buffer"
u32 sector IN: address of first 512 byte sector on CF card to read
u8 numSecs IN: number of 512 byte sectors to read,
 1 to 256 sectors can be read, 0 = 256
void* buffer OUT: pointer to 512 byte buffer to store data in
bool return OUT: true if successful
-----------------------------------------------------------------*/
_CODE_IN_RAM bool CF_ReadSectors (u32 sector, u8 numSecs, void* buffer);
#define CF_ReadSector(sector,buffer) CF_ReadSectors(sector, 1, buffer)

/*-----------------------------------------------------------------
CF_WriteSectors
Write 512 byte sector numbered "sector" from "buffer"
u32 sector IN: address of 512 byte sector on CF card to read
u8 numSecs IN: number of 512 byte sectors to read,
 1 to 256 sectors can be read, 0 = 256
void* buffer IN: pointer to 512 byte buffer to read data from
bool return OUT: true if successful
-----------------------------------------------------------------*/
_CODE_IN_RAM bool CF_WriteSectors (u32 sector, u8 numSecs, void* buffer);
#define CF_WriteSector(sector,buffer) CF_WriteSectors(sector, 1, buffer)

/*-----------------------------------------------------------------
CF_LastSector
Returns the number of the last sector accessed as an u32
Best to use this before using any other reads of CF when first 
starting program, to get the last sector where the program is stored
u32 return OUT: Address of last read sector
-----------------------------------------------------------------*/
_CODE_IN_RAM u32 CF_LastSector (void);

//------------------------------------------------------------------
#ifdef __cplusplus
}	   // extern "C"
#endif
//------------------------------------------------------------------

#endif	// ifndef _CF_INCLUDED

