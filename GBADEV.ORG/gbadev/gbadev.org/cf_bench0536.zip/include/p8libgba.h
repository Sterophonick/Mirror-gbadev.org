/* p8libgba.h
   stuff that was in pin8gba.h that was left out of libgba
*/

/* Rationale

In October 2005, I decided to reorganize pin8gba.h around the libgba
that everyone else seems to be developing against.  I was willing to
give up my well-thought-out names of registers in exchange for the
better-known names after it became clear that Nintendo wasn't
planning to take legal action against use of the better-known names
that some thought were swiped from the official devkit in violation
of NDA.  But libgba still didn't use some of the more clever macros
that I had developed for pin8gba.h.  This file is an attempt to fill
the gaps in libgba's headers, with the macros from pin8gba.h renamed
to fit into the libgba naming conventions.
*/

#ifndef _p8libgba_h_
#define _p8libgba_h_


/* gba_video.h *****************************************************/
#include <gba_video.h>  /* no, nothing to do with majesco */

/* CHAR_BASE_ADR() is the direct equivalent to old PATRAM(),
   giving the base address of a chr bank.
   But my macros pinpoint the base address of a single tile.
*/
#define PATRAM4(x, tn) ((u32 *)(VRAM | (((x) << 14) + ((tn) << 5)) ))
#define PATRAM8(x, tn) ((u32 *)(VRAM | (((x) << 14) + ((tn) << 6)) ))
#define SPR_VRAM(tn) ((u32 *)(VRAM | 0x10000 | ((tn) << 5)))


/* MAP_BASE_ADR() only gives the beginning of a map.
   Some people would rawther access each cell of a text map
   using 3D array notation:
   MAP[page][y][x]
*/
typedef u16 NAMETABLE[32][32];
#define MAP ((NAMETABLE *)0x06000000)

/* Someone forgot to recognize that width and height of a
   GBA text map can (and probably should) be controlled separately.
*/
#define BG_WID_32 BG_SIZE_0
#define BG_WID_64 BG_SIZE_1
#define BG_HT_32  BG_SIZE_0
#define BG_HT_64  BG_SIZE_2

/* Symbolic names for the rot/scale map sizes are appreciated as well. */
#define ROTBG_SIZE_16  BG_SIZE_0
#define ROTBG_SIZE_32  BG_SIZE_1
#define ROTBG_SIZE_64  BG_SIZE_2
#define ROTBG_SIZE_128 BG_SIZE_3


/* gba_sprites.h ***************************************************/
#include <gba_sprites.h>

#define OBJ_TRANSLUCENT OBJ_MODE(1)
#define OBJ_OBJWINDOW   OBJ_MODE(2)
#define OBJ_SQUARE      OBJ_SHAPE(0)
#define OBJ_WIDE        OBJ_SHAPE(1)
#define OBJ_TALL        OBJ_SHAPE(2)


/* gba_sound.h *****************************************************/

/* Most of the well-known names for the sound registers make 0 sense.
   I'll just use the pin8gba names wholesale in a separate header
   file to be included instead of gba_sound.h.
*/




/* End *************************************************************/
#endif
