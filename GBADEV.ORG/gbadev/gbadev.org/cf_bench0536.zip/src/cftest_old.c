/* Code removed from cftest.c */
static void display_palette(void)
{
  u32 *dst = PATRAM4(0, 0);
  unsigned int col;

  /* display palette */
  for(col = 0; col < 16; col++)
  {
    u32 pxdata = col | col << 4;
	int j;
	
	pxdata |= pxdata << 8;
	pxdata |= pxdata << 16;
    for(j = 8; j > 0; j--)
	  *dst++ = pxdata;
    MAP[4][10][7 + col] = col;
  }
}

static void setup_map(void)
{
  unsigned int x, y, c = 1024 - 600;
  for(y = 0; y < 30; y++)
    for(x = 0; x < 30; x++)
	  MAP[20][y][x] = c++;
  BGCTRL[0] = CHAR_BASE(2) | SCREEN_BASE(20) | BG_SIZE_0;
}


static void display_todbg(const char *filename)
{
  FAT_FILE *fp = FAT_fopen(filename, "r");
  char tmp[512];
  u32 *dst = (u32 *)0x0203b000;
  
  if(!fp)
    return;

  FAT_fread(dst, 2, 16, fp);
  dma_memcpy(BG_COLORS, dst, 32);
  setup_map();
  FAT_fread(dst, 32, 600, fp);
  dma_memcpy(PATRAM4(2, 1024 - 600), dst, 32 * 600);
  FAT_fclose(fp);
}
