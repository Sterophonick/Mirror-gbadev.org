/* cftest.c
   CompactFlash benchmark tool

Copyright � 2005 Damian Yerrick

This software is provided 'as-is', without any express or implied
warranty. In no event will the authors be held liable for any damages
arising from the use of this software.

Permission is granted to anyone to use this software for any purpose,
including commercial applications, and to alter it and redistribute
it freely, subject to the following restrictions:

1. The origin of this software must not be misrepresented; you must
   not claim that you wrote the original software. If you use this
   software in a product, an acknowledgment in the product
   documentation would be appreciated but is not required.

2. Altered source versions must be plainly marked as such, and must
   not be misrepresented as being the original software.

3. This notice may not be removed or altered from any source
   distribution.

*/

#include <stdio.h>
#include <string.h>
#include "p8libgba.h"
#include <gba_interrupt.h>
#include <gba_input.h>
#include <gba_dma.h>
#include <gba_systemcalls.h>

#include "gba_nds_fat.h"
#include "agbtty.h"

static void press_A(void)
{
  while(!(REG_KEYINPUT & KEY_A))
    VBlankIntrWait();
  while( (REG_KEYINPUT & KEY_A))
    VBlankIntrWait();
}

static void halt(void)
{
  while (1) {
    VBlankIntrWait();
  }
}

#if 0
static void dma_memcpy(void *dst, const void *src, int len)
{
  DMA3COPY(src, dst, (len >> 1) | DMA16);
}
#endif


void ls(void)
{
  char filename[16];  /* FAT_Find*tFile deals only in 8.3 names */
  int file_type;
  for(file_type = FAT_FindFirstFile(filename);
      file_type > 0;
      file_type = FAT_FindNextFile(filename))
  {
    agbtty_puts(filename);
	if(file_type == 2)
	  agbtty_putc('/');
    agbtty_putc('\n');
  }
}


/* find_big_file() ********************
   Finds a file in the current directory at least |minimum| bytes
   in size.  If it finds one, returns 1 and copies its short name
   to |filename|.  If not, returns 0.
*/
int find_big_file(char *out_name, u32 minimum)
{
  char filename[16];
  int file_type;
  
  for(file_type = FAT_FindFirstFile(filename);
      file_type > 0;
      file_type = FAT_FindNextFile(filename))
  {
    if(file_type == 1)
    {
      u32 size = FAT_GetFileSize();
      if(size >= minimum)
      {
        strcpy(out_name, filename);
        return 1;
      }
    }
  }
  return 0;
}


static void benchmark_read(const char *filename, u32 read_size)
{
  FAT_FILE *fp = FAT_fopen(filename, "r");
  void *dst = (void *)0x0203bc00;
  unsigned int n_read, read_time;
  int read_times[3] = {0, 0, 0};
  int time_left = 80;
  
  if(!fp)
    return;

  agbtty_puts("\fHow fast can GBAMP read 512-\n"
                "byte blocks from your CF card?\n");
  agbtty_puts(filename);
  agbtty_putc('\n');
  
  do
  {
    read_times[2] = read_times[1];
    read_times[1] = read_times[0];

    /* synchronize to time base before reading */
    while(REG_VCOUNT != 0) { }
	n_read = FAT_fread(dst, 1, read_size, fp);
	if(n_read)
    {
	  read_times[0] = REG_VCOUNT;
    
      /* take the longest of the last 3 read times to avoid flicker */
      read_time = read_times[0];
      if(read_time < read_times[1])
        read_time = read_times[1];
      if(read_time < read_times[2])
        read_time = read_times[2];
      siprintf(dst, "%3d lines (%5d us)\r", 
	           read_time,
			   read_time * 1175 / 16);
	  agbtty_puts(dst);
    }
    
    /* slow it down a bit */
    VBlankIntrWait();
    VBlankIntrWait();
    VBlankIntrWait();
    time_left--;
  } while(n_read > 0 && time_left > 0);
  FAT_fclose(fp);
}


static unsigned int ayn_seed;
static unsigned int ayn(u32 max)
{
  ayn_seed = ayn_seed * 1103515245 + 12345;
  return ((ayn_seed >> 16) * max) >> 16;
}


static void benchmark_random_read(const char *filename, u32 read_size)
{
  FAT_FILE *fp = FAT_fopen(filename, "r");
  u32 max_seek = fp ? FAT_GetFileSize() : 0;
  void *dst = (void *)0x0203bc00;
  unsigned int n_read, read_time;
  int read_times[3] = {0, 0, 0};
  int time_left = 80;

  if(max_seek < read_size * 4)
  {
    if(fp)
      FAT_fclose(fp);
    agbtty_puts("\fneed ... bigger ... file ...\n");
    agbtty_puts(filename);
    agbtty_puts("\ndoesn't cut it.");
    press_A();
    return;
  }
  
  max_seek /= read_size;
  
  agbtty_puts("\fHow fast can GBAMP read 512-\n"
                "byte blocks from your CF card?\n");
  agbtty_puts(filename);
  agbtty_putc('\n');
  
  do
  {
    int sector = ayn(max_seek) * read_size;
    read_times[2] = read_times[1];
    read_times[1] = read_times[0];

    /* synchronize to time base before reading */
    while(REG_VCOUNT != 0) { }
    FAT_fseek(fp, sector, SEEK_SET);
	n_read = FAT_fread(dst, 1, read_size, fp);
	if(n_read)
    {
	  read_times[0] = REG_VCOUNT;
    
      /* take the longest of the last 3 read times to avoid flicker */
      read_time = read_times[0];
      if(read_time < read_times[1])
        read_time = read_times[1];
      if(read_time < read_times[2])
        read_time = read_times[2];
      siprintf(dst, "%3d lines (%5d us)\r", 
               read_time,
	           read_time * 1175 / 16);
	  agbtty_puts(dst);
    }
    else
    {
      siprintf(dst, "\ntried to read sector %d\n", 
	           sector);
	  agbtty_puts(dst);
      press_A();
    }
    
    /* slow it down a bit */
    VBlankIntrWait();
    VBlankIntrWait();
    VBlankIntrWait();
    time_left--;
  } while(n_read > 0 && time_left > 0);
  FAT_fclose(fp);
}


#define N_MENU_ITEMS 8

//---------------------------------------------------------------------------------
// Program entry point
//---------------------------------------------------------------------------------
int main(void)
{
  unsigned int menu_y = 0;
  char big_filename[16];

  // set up ISR for VBlankIntrWait()
  InitInterrupt();
  EnableInterrupt(Int_Vblank);

  // set up AGBTTY
  agbtty_init();
//  agbtty_init_cursor();

  // turn on screen
  SetMode(MODE_0 | BG0_ON);
  BG_COLORS[  0] = RGB5(31,31,31);
  BG_COLORS[  1] = RGB5( 0, 0, 0);
  OBJ_COLORS[  1] = RGB5(16,16, 0);

  if(!FAT_InitFiles())
  {
    agbtty_puts("chishm's driver failed to\n"
                "recognize the adapter or the\n"
                "CF card :(");
    press_A();
    SoftReset(0);
    halt();
  }
  
  if(!find_big_file(big_filename, 262144))
  {
    agbtty_puts("Please place a file at least\n"
                "256 KiB in size in the root\n"
                "of this CF card.");
    press_A();
    SoftReset(0);
    halt();
  }
  

  while(menu_y != N_MENU_ITEMS - 1)
  {
    int selected = 0;
    u32 last_joy = 0x3FF;

    agbtty_puts("\fGBAMP CF Speed Tester\n"
                "� 2005 Damian Yerrick\n\n"
                "  Sequential (512 byte)\n"
                "  Sequential (4 KiB)\n"
                "  Sequential (16 KiB)\n"
                "  Random (512 byte)\n"
                "  Random (4 KiB)\n"
                "  Random (16 KiB)\n"
                "  List root directory\n"
                "  Quit\n"
                "\n(Up and Down select; A starts)");
    agbtty_gotoxy(0, 3 + menu_y);
    agbtty_putc('>');
    while(!selected)
    {
      u32 j = ~REG_KEYINPUT;
      u32 jnew = j & ~last_joy;

      last_joy = j;
      if(jnew & KEY_DOWN)
      {
        agbtty_gotoxy(0, 3 + menu_y);
        agbtty_putc(' ');
        menu_y++;
        if(menu_y >= N_MENU_ITEMS)
          menu_y = 0;
        agbtty_gotoxy(0, 3 + menu_y);
        agbtty_putc('>');
      }
      
      if(jnew & KEY_UP)
      {
        agbtty_gotoxy(0, 3 + menu_y);
        agbtty_putc(' ');
        if(menu_y == 0)
          menu_y = N_MENU_ITEMS - 1;
        else
          menu_y--;
        agbtty_gotoxy(0, 3 + menu_y);
        agbtty_putc('>');
      }
      if(jnew & KEY_A)
      {
        selected = 1;
      }
      VBlankIntrWait();
    }

    switch(menu_y)
    {
    case 0:
      benchmark_read(big_filename, 512);
      break;
    case 1:
      benchmark_read(big_filename, 4096);
      break;
    case 2:
      benchmark_read(big_filename, 16384);
      break;
    case 3:
      benchmark_random_read(big_filename, 512);
      break;
    case 4:
      benchmark_random_read(big_filename, 4096);
      break;
    case 5:
      benchmark_random_read(big_filename, 16384);
      break;
    case 6:
      agbtty_putc('\f');
      ls();
      press_A();
      break;
    }
  }
  REG_IME = 0;
  SoftReset(0);
  halt();
}


