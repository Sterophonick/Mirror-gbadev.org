/* agbtty.c
   a tty for the GBA
   libgba version

Copyright � 2005 Damian Yerrick

This software is provided 'as-is', without any express or implied
warranty. In no event will the authors be held liable for any damages
arising from the use of this software.

Permission is granted to anyone to use this software for any purpose,
including commercial applications, and to alter it and redistribute
it freely, subject to the following restrictions:

1. The origin of this software must not be misrepresented; you must
   not claim that you wrote the original software. If you use this
   software in a product, an acknowledgment in the product
   documentation would be appreciated but is not required.

2. Altered source versions must be plainly marked as such, and must
   not be misrepresented as being the original software.

3. This notice may not be removed or altered from any source
   distribution.

*/

#include <gba_types.h>
#include <gba_video.h>
#include <errno.h>
#include "agbtty.h"
#include "p8libgba.h"
#include "p8gbasnd.h"

#define DEFAULT_MAP 4

/* which map we're using (0-30) */
static unsigned char nt = DEFAULT_MAP;

/* current scroll position (0-63) */
static unsigned char curs_x, curs_y;
static unsigned char scrollbase;

/* current scrollback position (0-44) */
unsigned int agbtty_cur_scrollback;
static unsigned char show_cursor;

/* current text attribute, in map entry format */
static unsigned short text_attr;

/* default font */
extern const unsigned int text_chr_size;
extern const unsigned char text_chr[];


/* agbtty_cls() ****************
   Clears the screen.  Call this from user code by printing
   a formfeed control character:
   agbtty_putc('\f');
*/
static int agbtty_cls(void)
{
  unsigned int y;
  unsigned int c = text_attr | ' ';

  c |= c << 16;

  for(y = 0; y < 20; y++)
  {
    u32 *base = (u32 *)(MAP[nt][(y + scrollbase) & 63]);
    unsigned int x;

    for(x = 5; x > 0; x--)  /* clear 6 spaces each time through */
    {
      *base++ = c;
      *base++ = c;
      *base++ = c;
    }
  }
  curs_x = 0;
  curs_y = 0;
  agbtty_scrollback(0);
  return 0;
}

/* upcvt_4bit() ************************
   Convert a 1-bit font to GBA 4-bit format.
   I use this function instead of GBA BIOS BitUnPack() for 2 reasons:
   1. BitUnPack() expects little-endian pixel ordering, unlike the
      big-endian pixel ordering found in PC, NES, and GB CHR files.
   2. BitUnPack() isn't emulated consistently among emulators that
      use high level emulation of BIOS calls, as seen in the text
      at the top of the screen in the so-called "Halo 2" demo.
*/
static void upcvt_4bit(void *dst, const u8 *src, size_t len)
{
  u32 *out = dst;

  for(; len > 0; len--)
  {
    u32 dst_bits = 0;
    u32 src_bits = *src++;
    u32 x;

    for(x = 0; x < 8; x++)
    {
      dst_bits <<= 4;
      dst_bits |= src_bits & 1;
      src_bits >>= 1;
    }
    *out++ = dst_bits;
  }
}


static int move_cursor(void)
{
  if(show_cursor)
  {
    int pixel_y = (curs_y + agbtty_cur_scrollback) * 8;

    if(pixel_y < 160)
    {
      OAM[0].attr0 = pixel_y | OBJ_16_COLOR | OBJ_SQUARE;
      OAM[0].attr1 = (curs_x << 3) | OBJ_SIZE(0);
    }
    else
    {
      OAM[0].attr0 = OBJ_DISABLE;
    }
  }
  return 0;
}


int agbtty_show_cursor(int shown)
{
  if(shown)
  {
    show_cursor = 1;
    OAM[0].attr2 = 1023 | OBJ_PRIORITY(1);
    move_cursor();
  }
  else
  {
    show_cursor = 0;
    OAM[0].attr0 = OBJ_DISABLE;
  }
  return 0;
}

int agbtty_init_cursor(void)
{
  static const u32 cursor_img[8] =
  {
    0x00000000,
    0x00000000,
    0x00000000,
    0x00000000,
    0x00000000,
    0x00000000,
    0x10101010,
    0x11111111
  };
  unsigned int i;

  for(i = 0; i < 128; i++)
  {
    OAM[0].attr0 = OBJ_DISABLE;
  }

  {
    u32 *last_oam_tile = (u32 *)0x06017fe0;

    for(i = 0; i < 8; i++)
      last_oam_tile[i] = cursor_img[i];
  }
  return agbtty_show_cursor(1);
}


static int agbtty_beep(void)
{
  SQR1CTRL = 0xd140;
  SQR1FREQ = 1917 | FREQ_HOLD | FREQ_RESET;
  return 0;
}


static int init_sound(void)
{
  //turn on sound circuit
  SNDSTAT = SNDSTAT_ENABLE;
  //full volume, enable sound 3 to left and right
  DMGSNDCTRL = DMGSNDCTRL_LVOL(7) | DMGSNDCTRL_RVOL(7) |
               DMGSNDCTRL_LSQR1 | DMGSNDCTRL_RSQR1 | 
               DMGSNDCTRL_LSQR2 | DMGSNDCTRL_RSQR2 | 
               DMGSNDCTRL_LTRI | DMGSNDCTRL_RTRI |
               DMGSNDCTRL_LNOISE | DMGSNDCTRL_RNOISE;
  DSOUNDCTRL = 0x0b06;

  SQR1SWEEP = SQR1SWEEP_OFF;
  SETSNDRES(1);
  return 0;
}

int agbtty_init(void)
{
  upcvt_4bit(PATRAM4(0, 0), text_chr, text_chr_size);
  agbtty_set_map(DEFAULT_MAP);
  scrollbase = 0;
  agbtty_textattr(0);
  agbtty_cls();
  BGCTRL[0] = 0 | CHAR_BASE(0) | BG_16_COLOR | SCREEN_BASE(DEFAULT_MAP)
            | BG_WID_32 | BG_HT_64;

  init_sound();

  return 0;
}


int agbtty_set_map(size_t in_nt)
{
  if(in_nt > 30 || (in_nt & 1))  /* if it's not even and in [0..30] */
  {
    errno = EDOM;
    return -1;
  }
  nt = in_nt;
  return 0;
}


static void agbtty_clreol(void)
{
  unsigned int x;

  for(x = curs_x; x < 30; x++)
    MAP[nt][(scrollbase + curs_y) & 63][x] = ' ' | text_attr;
}

static int agbtty_newline(void)
{
  curs_x = 0;
  if(curs_y >= 19)
  {
    scrollbase++;
    curs_y = 19;
    agbtty_clreol();
  }
  else
  {
    curs_y++;
  }
  return agbtty_scrollback(0);
}


static int agbtty_putc_printable(int c)
{
  MAP[nt][(scrollbase + curs_y) & 63][curs_x++] = (c & 0xff) | text_attr;
  if(curs_x >= 30)
    return agbtty_newline();
  move_cursor();
  return 0;
}


int agbtty_putc(int c)
{
  switch(c)
  {
  case '\a':
    return agbtty_beep();
  case '\b':
    if(curs_x > 0)
      curs_x--;
    return 0;
  case '\t':
    while(curs_x & 7)
      agbtty_putc_printable(' ');
    return 0;
  case '\n':
  case '\v':
    return agbtty_newline();
  case '\f':
    return agbtty_cls();
  case '\r':
    curs_x = 0;
    return move_cursor();
  default:
    return agbtty_putc_printable(c);
  }
}


ssize_t agbtty_write(const void *in_buf, size_t size)
{
  const char *buf = in_buf;
  ssize_t sz = size;

  for(; size > 0; size--)
    agbtty_putc(*buf++);
  return sz;
}


int agbtty_puts(const char *buf)
{
  while(*buf)
    agbtty_putc(*buf++);
  return 0;
}


int agbtty_gotoxy(unsigned int x, unsigned int y)
{
  if(x >= 30 || y >= 20)
  {
    errno = EDOM;
    return -1;
  }
  curs_x = x;
  curs_y = y;
  return move_cursor();
}

unsigned int agbtty_textattr(unsigned int attr)
{
  text_attr = attr;
  return attr;
}

int agbtty_scrollback(size_t n_lines)
{
  if(n_lines > 44)
  {
    errno = EDOM;
    return -1;
  }

  BG_OFFSET[0].x = 0;
  BG_OFFSET[0].y = 8 * ((scrollbase - n_lines) & 63);
  agbtty_cur_scrollback = n_lines;
  return move_cursor();
}
