/*
	compact_flash.c
	By chishm (Michael Chisholm)

	Routines for reading a compact flash card
	using the GBA Movie Player or M3.

	Some FAT routines are based on those in fat.c, which
	is part of avrlib by Pascal Stang.

	CF routines modified with help from Darkfader
	M3 routines added by MightyMax

	This software is completely free. No warranty is provided.
	If you use it, please give me credit and email me about your
	project at chishm@hotmail.com

	See gba_nds_fat.txt for help and license details.
*/


#include "compact_flash.h"
#ifdef NDS
 #include <nds/memory.h>
#endif

//---------------------------------------------------------------
// Customizable features

// Use DMA to read the card
#ifndef NDS				// DMA doesn't work on the ARM9 of the NDS
 #define  _CF_USE_DMA 0	// Remove this if DMA is unavailable
#endif

//---------------------------------------------------------------
// DMA
#ifdef _CF_USE_DMA
 #include "gba_dma.h"
#endif

//---------------------------------------------------------------
// CF Addresses & Commands

#define GAME_PAK		0x08000000			// Game pack start address

// GBAMP CF Addresses
#define MP_REG_STS		*(vu16*)(GAME_PAK + 0x018C0000)	// Status of the CF Card / Device control
#define MP_REG_CMD		*(vu16*)(GAME_PAK + 0x010E0000)	// Commands sent to control chip and status return
#define MP_REG_ERR		*(vu16*)(GAME_PAK + 0x01020000)	// Errors / Features

#define MP_REG_SEC		*(vu16*)(GAME_PAK + 0x01040000)	// Number of sector to transfer
#define MP_REG_LBA1		*(vu16*)(GAME_PAK + 0x01060000)	// 1st byte of sector address
#define MP_REG_LBA2		*(vu16*)(GAME_PAK + 0x01080000)	// 2nd byte of sector address
#define MP_REG_LBA3		*(vu16*)(GAME_PAK + 0x010A0000)	// 3rd byte of sector address
#define MP_REG_LBA4		*(vu16*)(GAME_PAK + 0x010C0000)	// last nibble of sector address | 0xE0

#define MP_DATA			(vu16*)(GAME_PAK + 0x01000000)		// Pointer to buffer of CF data transered from card

// M3 CF Addresses - with thanks to MightyMax
#define M3_REG_STS		*(vu16*)(GAME_PAK + 0x000C0000)	// Status of the CF Card / Device control
#define M3_REG_CMD		*(vu16*)(GAME_PAK + 0x008E0000)	// Commands sent to control chip and status return
#define M3_REG_ERR		*(vu16*)(GAME_PAK + 0x00820000)	// Errors / Features

#define M3_REG_SEC		*(vu16*)(GAME_PAK + 0x00840000)	// Number of sector to transfer
#define M3_REG_LBA1		*(vu16*)(GAME_PAK + 0x00860000)	// 1st byte of sector address
#define M3_REG_LBA2		*(vu16*)(GAME_PAK + 0x00880000)	// 2nd byte of sector address
#define M3_REG_LBA3		*(vu16*)(GAME_PAK + 0x008A0000)	// 3rd byte of sector address
#define M3_REG_LBA4		*(vu16*)(GAME_PAK + 0x008C0000)	// last nibble of sector address | 0xE0

#define M3_DATA			(vu16*)(GAME_PAK + 0x00800000)		// Pointer to buffer of CF data transered from card

// cf host type
enum CF_HOST_TYPE {CF_HOST_NOTTESTED, CF_HOST_GBAMP, CF_HOST_M3} cfHost = CF_HOST_NOTTESTED;

// CF Card status
#define CF_STS_INSERTED		0x50
#define CF_STS_REMOVED		0x00
#define CF_STS_READY		0x58

#define CF_STS_DRQ			0x08
#define CF_STS_BUSY			0x80

// CF Card commands
#define CF_CMD_LBA			0xE0
#define CF_CMD_READ			0x20
#define CF_CMD_WRITE		0x30

#define CARD_TIMEOUT	10000000		// Updated due to suggestion from SaTa, otherwise card will timeout sometimes on a write

#define BYTE_PER_READ 512

//-----------------------------------------------------------------
// Hardware level routines

/*-----------------------------------------------------------------
M3_Unlock
Returns true if M3 was unlocked, false if failed
Added by MightyMax
-----------------------------------------------------------------*/
_CODE_IN_RAM bool M3_Unlock(void) 
{
// define 2 NOP cycles between each sequence read
#define SHORTWAIT asm("mov r0,r0\nmov r0,r0\n") ;
	// run unlock sequence
	volatile unsigned short tmp ;
	tmp = *(volatile unsigned short *)0x08000000 ;
	SHORTWAIT ;
	tmp = *(volatile unsigned short *)0x08E00002 ;
	SHORTWAIT ;
	tmp = *(volatile unsigned short *)0x0800000E ;
	SHORTWAIT ;
	tmp = *(volatile unsigned short *)0x08801FFC ;
	SHORTWAIT ;
	tmp = *(volatile unsigned short *)0x0800104A ;
	SHORTWAIT ;
	tmp = *(volatile unsigned short *)0x08800612 ;
	SHORTWAIT ;
	tmp = *(volatile unsigned short *)0x08000000 ;
	SHORTWAIT ;
	tmp = *(volatile unsigned short *)0x08801B66 ;
	SHORTWAIT ;
	tmp = *(volatile unsigned short *)0x08800006 ;
	SHORTWAIT ;
	tmp = *(volatile unsigned short *)0x08000000 ;
	SHORTWAIT ;
	// provoke a ready reply
	*(volatile unsigned short *)0x080C0000 = 0x50 ;
	// is it ready ?
	return (*(volatile unsigned short *)0x080C0000==0x50) ;	
#undef SHORTWAIT
}


/*-----------------------------------------------------------------
CF_IsInserted
Is a compact flash card inserted?
bool return OUT:  true if a CF card is inserted
-----------------------------------------------------------------*/
_CODE_IN_RAM bool CF_IsInserted (void) 
{
	// If running on an NDS, make sure the correct CPU can access
	// the GBA cart. First implemented by SaTa.
#ifdef NDS
 #ifdef ARM9
	WAIT_CR &= ~(0x8080);
 #endif
 #ifdef ARM7
	WAIT_CR |= (0x8080);
 #endif
#endif
	// if not known what card we run on, test it while trying to unlock m3
	if (cfHost == CF_HOST_NOTTESTED) 
	{
		cfHost = M3_Unlock() ? CF_HOST_M3 : CF_HOST_GBAMP ;
	}

	// Change register, then check if value did change
	if (cfHost == CF_HOST_M3) 
	{
		M3_REG_STS = CF_STS_INSERTED;
		return (M3_REG_STS == CF_STS_INSERTED);
	}
	else 
	{
		MP_REG_STS = CF_STS_INSERTED;
		return (MP_REG_STS == CF_STS_INSERTED);
	}
}


/*-----------------------------------------------------------------
CF_ClearStatus
Is a compact flash card inserted?
bool return OUT:  true if a CF card is inserted
-----------------------------------------------------------------*/
_CODE_IN_RAM bool CF_ClearStatus (void) 
{
	int i;
	
	if (cfHost == CF_HOST_M3) 
	{
		// Wait until CF card is finished previous commands
		i=0;
		while ((M3_REG_CMD & CF_STS_BUSY) && (i < CARD_TIMEOUT))
		{
			i++;
		}
		
		// Wait until card is ready for commands
		i = 0;
		while ((!(M3_REG_STS & CF_STS_INSERTED)) && (i < CARD_TIMEOUT))
		{
			i++;
		}
		if (i >= CARD_TIMEOUT)
			return false;
	}
	else
	{
		// Wait until CF card is finished previous commands
		i=0;
		while ((MP_REG_CMD & CF_STS_BUSY) && (i < CARD_TIMEOUT))
		{
			i++;
		}
		
		// Wait until card is ready for commands
		i = 0;
		while ((!(MP_REG_STS & CF_STS_INSERTED)) && (i < CARD_TIMEOUT))
		{
			i++;
		}
		if (i >= CARD_TIMEOUT)
			return false;
	}
	
	return true;
}


/*-----------------------------------------------------------------
CF_ReadSectors
Read 512 byte sector numbered "sector" into "buffer"
u32 sector IN: address of first 512 byte sector on CF card to read
u8 numSecs IN: number of 512 byte sectors to read,
 1 to 256 sectors can be read, 0 = 256
void* buffer OUT: pointer to 512 byte buffer to store data in
bool return OUT: true if successful
-----------------------------------------------------------------*/
_CODE_IN_RAM bool CF_ReadSectors (u32 sector, u8 numSecs, void* buffer)
{
	int i;
	int j = (numSecs > 0 ? numSecs : 256);
	u16 *buff = (u16*)buffer;
	
	if (cfHost == CF_HOST_M3)
	{
		// Wait until CF card is finished previous commands
		i=0;
		while ((M3_REG_CMD & CF_STS_BUSY) && (i < CARD_TIMEOUT))
		{
			i++;
		}
		
		// Wait until card is ready for commands
		i = 0;
		while ((!(M3_REG_STS & CF_STS_INSERTED)) && (i < CARD_TIMEOUT))
		{
			i++;
		}
		if (i >= CARD_TIMEOUT)
			return false;
		
		// Set number of sectors to read
		M3_REG_SEC = numSecs;	
		
		// Set read sector
		M3_REG_LBA1 = sector & 0xFF;						// 1st byte of sector number
		M3_REG_LBA2 = (sector >> 8) & 0xFF;					// 2nd byte of sector number
		M3_REG_LBA3 = (sector >> 16) & 0xFF;				// 3rd byte of sector number
		M3_REG_LBA4 = ((sector >> 24) & 0x0F )| CF_CMD_LBA;	// last nibble of sector number
		
		// Set command to read
		M3_REG_CMD = CF_CMD_READ;
		
		
		while (j--)
		{
			// Wait until card is ready for reading
			i = 0;
			while ((M3_REG_STS != CF_STS_READY) && (i < CARD_TIMEOUT))
			{
				i++;
			}
			if (i >= CARD_TIMEOUT)
				return false;
			
			// Read data
#ifdef _CF_USE_DMA
			DMA3COPY ( M3_DATA, buff, 256 | DMA16 | DMA_ENABLE | DMA_SRC_FIXED);
			buff += BYTE_PER_READ / 2;
#else
			i=256;
			while(i--)
				*buff++ = *M3_DATA; 
#endif
		}
	}
	else
	{
		// Wait until CF card is finished previous commands
		i=0;
		while ((MP_REG_CMD & CF_STS_BUSY) && (i < CARD_TIMEOUT))
		{
			i++;
		}
		
		// Wait until card is ready for commands
		i = 0;
		while ((!(MP_REG_STS & CF_STS_INSERTED)) && (i < CARD_TIMEOUT))
		{
			i++;
		}
		if (i >= CARD_TIMEOUT)
			return false;
		
		// Set number of sectors to read
		MP_REG_SEC = numSecs;	
		
		// Set read sector
		MP_REG_LBA1 = sector & 0xFF;						// 1st byte of sector number
		MP_REG_LBA2 = (sector >> 8) & 0xFF;					// 2nd byte of sector number
		MP_REG_LBA3 = (sector >> 16) & 0xFF;				// 3rd byte of sector number
		MP_REG_LBA4 = ((sector >> 24) & 0x0F )| CF_CMD_LBA;	// last nibble of sector number
		
		// Set command to read
		MP_REG_CMD = CF_CMD_READ;
		
		
		while (j--)
		{
			// Wait until card is ready for reading
			i = 0;
			while ((MP_REG_STS != CF_STS_READY) && (i < CARD_TIMEOUT))
			{
				i++;
			}
			if (i >= CARD_TIMEOUT)
				return false;
			
			// Read data
#ifdef _CF_USE_DMA
			DMA3COPY ( MP_DATA, buff, 256 | DMA16 | DMA_ENABLE | DMA_SRC_FIXED);
			buff += BYTE_PER_READ / 2;
#else
			i=256;
			while(i--)
				*buff++ = *MP_DATA; 
#endif
		}
	}
	return true;
}



/*-----------------------------------------------------------------
CF_WriteSectors
Write 512 byte sector numbered "sector" from "buffer"
u32 sector IN: address of 512 byte sector on CF card to read
u8 numSecs IN: number of 512 byte sectors to read,
 1 to 256 sectors can be read, 0 = 256
void* buffer IN: pointer to 512 byte buffer to read data from
bool return OUT: true if successful
-----------------------------------------------------------------*/
_CODE_IN_RAM bool CF_WriteSectors (u32 sector, u8 numSecs, void* buffer)
{
	int i;
	int j = (numSecs > 0 ? numSecs : 256);
	u16 *buff = (u16*)buffer;
	
	if (cfHost == CF_HOST_M3)
	{
		// Wait until CF card is finished previous commands
		i=0;
		while ((M3_REG_CMD & CF_STS_BUSY) && (i < CARD_TIMEOUT))
		{
			i++;
		}
		
		// Wait until card is ready for commands
		i = 0;
		while ((!(M3_REG_STS & CF_STS_INSERTED)) && (i < CARD_TIMEOUT))
		{
			i++;
		}
		if (i >= CARD_TIMEOUT)
			return false;
		
		// Set number of sectors to write
		M3_REG_SEC = numSecs;	
		
		// Set write sector
		M3_REG_LBA1 = sector & 0xFF;						// 1st byte of sector number
		M3_REG_LBA2 = (sector >> 8) & 0xFF;					// 2nd byte of sector number
		M3_REG_LBA3 = (sector >> 16) & 0xFF;				// 3rd byte of sector number
		M3_REG_LBA4 = ((sector >> 24) & 0x0F )| CF_CMD_LBA;	// last nibble of sector number
		
		// Set command to write
		M3_REG_CMD = CF_CMD_WRITE;
		
		while (j--)
		{
			// Wait until card is ready for writing
			i = 0;
			while ((M3_REG_STS != CF_STS_READY) && (i < CARD_TIMEOUT))
			{
				i++;
			}
			if (i >= CARD_TIMEOUT)
				return false;
			
			// Write data
#ifdef _CF_USE_DMA
			DMA3COPY( buff, M3_DATA, 256 | DMA16 | DMA_ENABLE | DMA_DST_FIXED);
			buff += BYTE_PER_READ / 2;
#else
			i=256;
			while(i--)
				*M3_DATA = *buff++; 
#endif
		}
	}
	else
	{
		// Wait until CF card is finished previous commands
		i=0;
		while ((MP_REG_CMD & CF_STS_BUSY) && (i < CARD_TIMEOUT))
		{
			i++;
		}
		
		// Wait until card is ready for commands
		i = 0;
		while ((!(MP_REG_STS & CF_STS_INSERTED)) && (i < CARD_TIMEOUT))
		{
			i++;
		}
		if (i >= CARD_TIMEOUT)
			return false;
		
		// Set number of sectors to write
		MP_REG_SEC = numSecs;	
		
		// Set write sector
		MP_REG_LBA1 = sector & 0xFF;						// 1st byte of sector number
		MP_REG_LBA2 = (sector >> 8) & 0xFF;					// 2nd byte of sector number
		MP_REG_LBA3 = (sector >> 16) & 0xFF;				// 3rd byte of sector number
		MP_REG_LBA4 = ((sector >> 24) & 0x0F )| CF_CMD_LBA;	// last nibble of sector number
		
		// Set command to write
		MP_REG_CMD = CF_CMD_WRITE;
		
		while (j--)
		{
			// Wait until card is ready for writing
			i = 0;
			while ((MP_REG_STS != CF_STS_READY) && (i < CARD_TIMEOUT))
			{
				i++;
			}
			if (i >= CARD_TIMEOUT)
				return false;
			
			// Write data
#ifdef _CF_USE_DMA
			DMA3COPY( buff, MP_DATA, 256 | DMA16 | DMA_ENABLE | DMA_DST_FIXED);
			buff += BYTE_PER_READ / 2;
#else
			i=256;
			while(i--)
				*MP_DATA = *buff++; 
#endif
		}
	}
	
	return true;
}


/*-----------------------------------------------------------------
CF_LastSector
Returns the number of the last sector accessed as an u32
Best to use this before using any other reads of CF when first 
starting program, to get the last sector where the program is stored
u32 return OUT: Address of last read sector
-----------------------------------------------------------------*/
_CODE_IN_RAM u32 CF_LastSector (void)
{
	if (cfHost == CF_HOST_M3)
	{
		return ( M3_REG_LBA1 | (M3_REG_LBA2 << 8) | (M3_REG_LBA3 << 16) | ((M3_REG_LBA4 & 0xF) << 24) );
	}
	else
	{
		return ( MP_REG_LBA1 | (MP_REG_LBA2 << 8) | (MP_REG_LBA3 << 16) | ((MP_REG_LBA4 & 0xF) << 24) );
	}
}

