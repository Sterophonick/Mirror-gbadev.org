/////background.c/////

#define BACKGROUND_C

 

#include "gba.h"

#include "background.h"

#include "screenmode.h"

 

void EnableBackground(Bg* bg)

{

            u16 temp;  //used to save typing

 

            bg->tileData = (u16*)CharBaseBlock(bg->charBaseBlock);  //compute proper memory address

            bg->mapData = (u16*)ScreenBaseBlock(bg->screenBaseBlock);//same

            

            //Create my BGxCNT register setting and put in temp to save typing

            temp = bg->size | (bg->charBaseBlock<<CHAR_SHIFT) | (bg->screenBaseBlock<<SCREEN_SHIFT) 

                        | bg->colorMode | bg->mosiac | bg->wraparound;

 

            switch(bg->number)

            {

            case 0:

                        {

                                    REG_BG0CNT = temp;            //set the BGxCNT register to the values we just determined            

                                    REG_DISPCNT |= BG0_ENABLE;  //enable the correct background

                        }break;

            case 1:

                        {

                                    REG_BG1CNT = temp;

                                    REG_DISPCNT |= BG1_ENABLE;

                        }break;

            case 2:

                        {

                                    REG_BG2CNT = temp;

                                    REG_DISPCNT |= BG2_ENABLE;

                        }break;

            case 3:

                        {

                                    REG_BG3CNT = temp;

                                    REG_DISPCNT |= BG3_ENABLE;

                        }break;

            

            default:break;

            

            }

}

 
