///////Bakcground.h////////

#ifndef BACKGROUND_H

#define BACKGROUND_H

 

 

///BGCNT defines ///

#define BG_MOSAIC_ENABLE                 0x40

#define BG_COLOR_256                             0x80

#define BG_COLOR_16                               0x0

 

#define TEXTBG_SIZE_256x256                0x0

#define TEXTBG_SIZE_256x512                0x8000

#define TEXTBG_SIZE_512x256                0x4000

#define TEXTBG_SIZE_512x512                0xC000

 

#define ROTBG_SIZE_128x128                  0x0

#define ROTBG_SIZE_256x256                  0x4000

#define ROTBG_SIZE_512x512                  0x8000

#define ROTBG_SIZE_1024x1024              0xC000

 

#define WRAPAROUND                              0x2000

// the following simplify the determining of base blocks and will make more sense when you look

// at the enableBackground function.

#define CharBaseBlock(n)                (((n)*0x4000)+0x6000000)  //16k * number + start of VRAM = address of character base block

#define ScreenBaseBlock(n)             (((n)*0x800)+0x6000000)  //2k * number + start of VRAM = address of screen base block

#define CHAR_SHIFT                                  2 //used to shift the number over to the right place in REG_BGxCNT

#define SCREEN_SHIFT                             8

 

////background struct

typedef struct Bg

{

            u16* tileData;             //after call to EnableBackground() tiledata and mapData will point to the 

            u16* mapData;            //corect VRAM location.

            u8 mosiac;                   //mosaic enable

            u8 colorMode;             //256 or 16 color

            u8 number;                 //background number (0-3)   

            u16 size;                      //size of the background

            u8 charBaseBlock;     //0-3

            u8 screenBaseBlock; //0-31

            u8 wraparound;           //wraparound flag

            s16 x_scroll,y_scroll;  //the horizontal and vertical offsets

            s32 DX,DY;                //scroll for rotation screens

            s16 PA,PB,PC,PD;      //hold rotation attributes for the background.

 

}Bg;

 

#ifndef BACKGROUND_C

extern void EnableBackground(Bg* bg);

void UpdateBackground(Bg* bg);

#endif

 

#endif
