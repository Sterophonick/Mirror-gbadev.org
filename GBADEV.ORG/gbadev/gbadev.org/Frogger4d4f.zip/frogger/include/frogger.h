// FROGGER.H
// constantes y variables gen�ricas del juego FROGGER

#ifndef FROGGER_H
#define FROGGER_H

#define SIEMPRE		   1  // Para el bucle infinito.

typedef struct{			  // Estructura de datos para guardar la informaci�n de la rana, 
	u8 indice;			  // posicion X, Y, variables de situacion actual (atropellada, parada, etc) 
	s16 x;				  // y variables que definen la distinta posici�n de mem que conforman los
	s16 y;				  // distintos sprites de la rana.
	u16* sprite;		  
	u8 bloqueo;
	u8 agua;
	s8 movimiento;
	u8 sprite_arriba;
	u8 sprite_abajo;
	u8 sprite_izquierda;
	u8 sprite_derecha;
	u8 sprite_muerta;
} tiporana;

typedef struct{			  //Estructura de datos para los objetos (coches y troncos). posicion X, Y, velocidad, etc.
	u8 indice;
	s16 x;
	s16 y;
	u16* sprite;
	s8 velocidad;
} obstaculo;


//Definici�n de Variables Globales.
u16* SpriteMem = (u16*)0x6010000;			// Posicion de mem a partir de la cual se almacenan los SPRITES
u16* SpriteMemPal = (u16*)0x5000200;		// Posicion de mem a partir de la cual se almacena la paleta de colores de los SPRITES
u16* BufferBackground= (u16*)0x6000000;		// Aqu� ser� donde dibujamos el background
u16* datosMapa = (u16*)0x600F800;
u16* PaletaMem = (u16*)0x5000000;			// Paleta de colores para el background



//Declaraci�n de Funciones
void DibujarFondo(u16*, u16*);				// Dibuja el BACKGROUND
void IniciaSprites(void);					// los ubica fuera de pantalla para que no se vea nada.
void DibujaSprite(u16*, int, int);			// Dibuja en memoria el SPRITE pasado por par�metros
void EsperarPorVsync(void);					// Sirve para saber en que momento debemos dibujar (es un momento determinado justo cuando la GBA pinta la pantalla)
void CopiarOAM(void);						// Copia "datos" a la memoria de SPRITES (llamada memoria OAM)
void MoverSprite(OAMEntry*, int, int);		// Sirve para cambiar la pos X, Y de un determinado SPRITE
void Teclado(void);							// Controla el teclado. Tan facil como ver la tecla pulsada y actualizar X e Y
void CargaPaletaSprite(u16*);				// Coloca en memoria la paleta de colores de los sprites.
void CambiarSprite(OAMEntry*, int);			// Cambia la estructura de datos que forma la imagen de un sprite por otra dada (ubicada en la memoria de sprites)
void MoverCoche(s16* , s16* , int);			// Actualiza coordenadas X e Y de un sprite coche. Adem�s, calcula colision con rana.
void MoverTronco(s16* , s16* , int);		// Actualiza coordenadas X e Y de un sprite tronco. Adem�s, calcula colision con rana.
void MoverNenufar(s16* , s16* , int);		// Actualiza coordenadas X e Y de un sprite nenufar. Adem�s, calcula colision con rana.
void MoverRana(s16* , s16* , int);			// Actualiza coordeandas X e Y de la rana. Se llama a esta funcion solo cuando se encuentra sobre un tronco o nenufar.
void MoverSprites(void);					// Llama a MoverSprite de TODOS los sprites
void MoverObjetos(void);					// Llama a Mover*** donde *** es coche, tronco, nenufar o rana
void Morirse(void);						    // Rutina de muerte de la rana.
void CrearSprite(int, u16*, int, int, u16, u16, u16); // Prepara e inicia un sprite.
void CrearSprites(void);					// Realiza una llamada a CrearSprite para todos los sprites del juego.
void Espera(void);							// Rutina que realiza un bucle que mueve a los sprites mientras el user tiene pulsada una tecla.
s16 CalculaMovimiento(s16, int);			// Devuelve la variable X trans calcular el desplazamiento.
void Ganar(void);							// Muestra los sprites de ganar y bloquea el juego hasta pulsar la A.
void IniciarRana(void);						// Restaura los valores iniciales de la rana.
#endif

