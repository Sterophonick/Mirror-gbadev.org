FROGGER DEMO
----------------

Run under any GBA emulator (such as IGBA, VISUALBOY, BOYCOTTADVANCE) and hardware.
Compile under ARM/THUMB COMPILER.

This ZIP include all source, pics, etc.

This demo follow the DOVOTO tutorial (http://www.thepernproject.com/)