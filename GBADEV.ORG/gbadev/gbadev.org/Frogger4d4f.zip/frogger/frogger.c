/******************************************************/
/*	JUEGO FROGGER	            					  */
/*	AUTOR: Jos� M�nz�n								  */
/*	DESCRIPCION: Juego para la consola				  */
/*				 portatil GameBoyAdvance. Version     */
/*				 'lite' del famoso fuego FROGGER      */
/*				 realizado para la asignatura de      */
/*				 multimedia.						  */
/******************************************************/


//Lo primero es a�adir las cabeceras
#include "include\gba.h"			//Aqui se dan nombre a los registros (se definen) como por ejemplo el REG_DISPCNT (generico)
#include "include\screenmode.h"		//Esta es la cabecera que yo he escrito, define algunas posiciones de mem importante. (generico)
#include "include\keypad.h"			//Macros para el TECLADO (generico)
#include "include\sprite.h"			//Macros para controlar aspectos de sprites (generico)
#include "include\frogger.h"		//Definiciones de constantes y alguna variable global.


// Variables globales importadas de los ficheros .RAW (definidos en DATA.ASM)
extern u16 paletaFondo;		//Contiene los datos de la paleta de colores del background. Definido en DATOS.ASM
extern u16 datosFondo;		//Contiene los datos de la imagen del background (formato RAW). Definido en DATOS.ASM
extern u16 paletaObj;		//Contiene los datos de la paleta de colores de los sprites. Definido en DATOS.ASM
extern u16 ranaArriba;		//Contiene los datos de la imagen que forma la ranita (formato RAW)
extern u16 ranaAbajo;		
extern u16 ranaDerecha;		
extern u16 ranaIzquierda;	
extern u16 ranaMuerta;		
extern u16 datos_coche1;	//Contiene los datos de la imagen que componen los distintos coches (formato RAW)
extern u16 datos_coche2;		
extern u16 datos_coche3_1;	//La imagen del camion est� compuesta por 2 sprites (3-1 y 3-2).
extern u16 datos_coche3_2;			
extern u16 datos_coche4;			
extern u16 datos_coche5;
extern u16 tronco;			//Contiene los datos de la imagen que forma el tronco (formato RAW)
extern u16 nenufar;			//Contiene los datos de la imagen que forma la planta (formato RAW)
extern u16 datos_ok;		//Contiene los datos de la imagen que forma el OK cuando llegas a casa (formato RAW)
extern u16 datos_ganador1;	//Contiene los datos de la imagen que forma las felicitaciones cuando ganas (formato RAW)
extern u16 datos_ganador2;	//Consta de dos sprites de 64*64


// Variables objeto para los sprites (la rana, los coches y los troncos).
tiporana ranita = {7, 107, 144, &ranaArriba, 0, 0, 0, 0, 0, 0, 0};  //Rana inicializada en X=107, Y=144 con el SPRITE "ranaArriba". Campos de estado a FALSO (0). Campos de pos de mem de sprites temporalmente a 0

obstaculo coche1 = {17, 208, 128, &datos_coche1,   -3},	//Coche fijado en X=208, Y=128, sprite "datos_coche1" y velocidad 3.
		  coche5 = {18, 3,	112, &datos_coche3_1,   2},	//Coche fijado en X=3, Y=112, sprite "datos_coche2" y velocidad 2.
		  coche2 = {3, 35,	112, &datos_coche3_2, 2},	//Coche fijado en X=35, Y=112, sprite "datos_coche3" y velocidad 2.
		  coche4 = {4, 88,	96,	 &datos_coche2, -1},	//Coche fijado en X=88, Y=96, sprite "datos_coche4" y velocidad -1.
		  coche3 = {5, 208, 96,  &datos_coche4,   -1},	//Coche fijado en X=208, Y=96, sprite "datos_coche5" y velocidad -1.
		  coche6 = {6, 3,	80,  &datos_coche5,   5};	//Coche fijado en X=3, Y=80, sprite "datos_coche6" y velocidad 5.

obstaculo nenufar1 =  {16, 3, 48, &nenufar, 1},		//Nenufar fijado en X=3, Y = 48, velocidad = 1
		  nenufar2 =  {8, 123, 48, &nenufar, 1},	//Nenufar fijado en X=123, Y = 48, velocidad = 1
		  nenufar3 =  {9, 200, 16, &nenufar, 2},	//Nenufar fijado en X=200, Y = 16, velocidad = 1
		  tronco1 =  {10, 100, 32, &tronco, -2},	//Nenufar fijado en X=100, Y = 32, velocidad = 1
		  tronco2 =  {11, 132, 32, &tronco, -2},	//Nenufar fijado en X=132, Y = 32, velocidad = 1
		  tronco3 =  {12, 164, 32, &tronco, -2},	//Nenufar fijado en X=164, Y = 32, velocidad = 1
		  ok1	  =  {13, 240, 160, &datos_ok, 0},	//En realidad no es un objeto movil. Pero aprovecho la estructura de datos.
		  ok2	  =  {14, 240, 160, &datos_ok, 0},	//Defino los 4 sprites del OK
		  ok3	  =  {15, 240, 160, &datos_ok, 0},	//Originalmente est�n fuera de pantalla : X=240 Y = 160
		  ok4	  =  {0, 240, 160, &datos_ok, 0},	//El campo velocidad no ser� necesario.
		  ganador1=  {1, 240, 160, &datos_ganador1, 0},	//Dos sprites para mostrar un mensaje cuando ganas.
		  ganador2=  {2, 240, 160, &datos_ganador2, 0};	



//Funcion c principal. Esta funcion se llama desde el "startup code" (que es ese fichero en ensamblador: boot.asm)
void AgbMain(void){

	FijarModo(MODE_1 |BG0_ENABLE| OBJ_ENABLE | OBJ_MAP_1D);    //Modo 1. Background 0. Objetos permitidos y en modo de carga 1D
	
	//Lo anterior fija el registro: REG_DISPCNT 
	//Ahora, para controlar el background, tenemos algunos registros que hay que fijar apropiadamente. Hay un registro de control para cada backgrund (4 en total). Como usamos el BG0, fijamos el REG_BG0CNT

	
	
	REG_BG0CNT  = 0x1F83;	//Este es el control principal para el background. el bit 0 y 1 controlan la prioridad.
							//Cuanto mayor es el n�mero, menor la prioridad. �sta determina el �rden en que el fondo y los
							//sprites se dibujan, y es como sigue: BG3,OBJ3,BG2,OBJ2,BG1,OBJ1,BG0,OBJ0. Los dos siguientes
							//bits controlan que memoria usar para los datos de los sprites. Bits 4 y 5 no sirven para nada.
							//El bit 6 indica si el fondo se repite en modo "mosaico". El 7 bit controla el modo de color
							//(0: 16 colores * 16 paletas; 1: 256colores * 1 paleta). Los bits 8 a 12 controlan el tama�o
							//de la pantalla virtual; 00 es 256*256, 01 es 512*256, etc, etc. Esto solo es v�lido para 
							//modos de texto (esos que no tienen escalado y rotaci�n).	
	//Para saber que es 0x1F83 lo pasamos a bin (facil, recuerda que se pasan cada d�gito como 4 bits: 1 = 0001 f=111111 ... y as�:)
	//0001111110000011
	//Bits 0-1 = 11 Fija la prioridad
	//Bits 2-3 = 00 Fija en que bloque est� el CHAR_BASE_BLOCK. Como est� a 0, los datos comienzan en 0x6000000 (hay que escibirlos a partir de esa posici�n)
	//Bits 4-5 = 00 (no usados)
	//Bits 6 = 0 (no mosaico)
	//Bit 7 = 1 (modo 256 colores)
	//Bit 8-12 = 111111 = 31 = bloque donde est� el mapa que dibuja los tiles en su sitio (pos de mem: 0x600F800)
	//Bit 13 = 0 (una estupidez)
	//Bit 14-15 = 00 tama�o del fondo (ahora en 256*256)

	//Bien, llegados a este punto hay que explicar un truco vil que se ha echo: Todo el mundo sabe que cada uno de los 4 background tiene solo 16kb
	//Y, adem�s, los mapas solo pueden colocar 256tiles distintos en pantalla. Pero yo tengo, en mi fondo 600 tiles!!!
	//Lo que hago es escribir el fondo en el principio y se expande a trav�s de los otros backgrounds (0, 1, ...)
	//Para evitar solapamientos, coloco los datos al principio de la mem (0x6000000) y el mapa al final (0x600F800).
	//Con esto consigo no tener que estarme currando los tiles (tarea co�azo!) y el mapa je, je...
	
    
	DibujarFondo(&paletaFondo, &datosFondo); //Mostramos el fondo. (carga la paleta de colores del fondo y los datos de la imagen).

	
	CargaPaletaSprite(&paletaObj); // Carga la paleta de colores de los sprites (256 colores).
	IniciaSprites(); //Coloca todos los 128 sprites fuera de pantalla. Esto es porque la memoria de los sprites puede tener basura y no quiero que me salga por pantalla

	CrearSprites();	 //Una vez iniciados, creamos todos los sprites del juego (en total 19).

	//Bucle del juego
	while(SIEMPRE){
		Teclado();			//�Hay alguna tecla pulsada, si es as� actualizo las X e Y de la rana. En otro caso sigo con el bucle
		MoverObjetos();		//Calculo las nuevas posiciones X e Y de los coches y troncos. Adem�s, calculo los posibles impactos con la rana.
		MoverSprites();		//Muevo los objetos (tanto coches, como troncos como la rana) a sus nuevas posiciones X e Y (actualizar el array de SPRITES)
		EsperarPorVsync();	//Espero que la pantalla no se est� dibujando
		CopiarOAM();		//Actualizo los sprites en pantalla ahora que esta el VSYNC (copiar el array de SPRITES a la memoria OAM o memoria de Sprites)
	}		

}//Fin AgbMain



// Espera que la pantalla deje de pintarse para escribir en la memoria
// El barrido VERTICAL tiene una "duracion" de 228 l�neas. Pero solo 160 componen la pantalla. La diferencia (las 68 lineas restantes)
// se le denomina "Vertical Blank" y dura unos 4.994ms. Tiempo suficiente para actualiza la pantalla y que en el siguiente barrio ya est� como nueva.
void EsperarPorVsync(void) {
	__asm //esto es ensamblador :-)	
	{
		mov 	r0, #0x4000006   
								//0x4000006 es el contador de trazado vertical (el que cuenta las l�neas pintadas, se incrementa por hard)
								//Colocamos ese valor en el registro R0
				
		scanline_wait:	       	//Etiqueta

		ldrh	r1, [r0]		//Movemos el valor almacenado en R0 a R1
		cmp	r1, #160			//Comparamos R1 con el valor 160
		bne 	scanline_wait	// Branch not equal es decir, si no es 160, saltamos a arriba, es un bucle. As� de facil ;)
	}			
} //Fin de EsperarPorVsync()



//Copia a la memoria OAM (memoria de Sprites) mi array que define los sprites
void CopiarOAM(void) {
	u16 loop;
	u16* temp;
	temp = (u16*)sprites; //esta variable est� definida en sprite.h
	for(loop = 0; loop < 128*4; loop++)
		OAM[loop] = temp[loop]; //copiamos los sprites a la memoria OAM

} //fin CopiarOAM



//Inicializa todos los sprites. Lo que hace es dibujarlos FUERA de pantalla para que no se vea nada raro.
void IniciaSprites(void) {
	int loop;
	for(loop = 0; loop < 128; loop++){
		sprites[loop].attribute0 = 160;  //y to > 159
		sprites[loop].attribute1 = 240;  //x to > 239
	}
} //fin InicializaSprites



//Controla el teclado... 
void Teclado() {
	
	if(!ranita.bloqueo){  //Si no estamos muertos podemos mover la rana...

	if(ranita.agua) Morirse();	//Si la rana est� en el agua debe morir....

	else if(!(*KEYS & KEY_UP)){
		CambiarSprite(&sprites[ranita.indice], ranita.sprite_arriba); //Actualizamos el SPRITE
			
		while(!(*KEYS & KEY_UP)){ //Mientras el usuario sigue pulsando esta tecla, el juego no debe pararse.
				Espera();
		}
 		ranita.y-=16; 	// Operaciones para actualizar las coordeandas X e Y
			
		if(ranita.y<=8){
			if(
			((ranita.x+6>=0)&&(ranita.x+6<=28))||
			((ranita.x+6>=54)&&(ranita.x+6<=80))||
			((ranita.x+6>=106)&&(ranita.x+6<=132))||
			((ranita.x+6>=158)&&(ranita.x+6<=184))||
			((ranita.x+6>=210)&&(ranita.x+6<=236))
			){				
				Morirse(); //Upss...					
			}else{
				Ganar(); //El individuo ha ganado!
			}
		}
		ranita.movimiento = 0;
		if(ranita.y<64) ranita.agua = 1;


	} if(!(*KEYS & KEY_DOWN)){ //Similar a KEY_UP
		CambiarSprite(&sprites[ranita.indice], ranita.sprite_abajo);

		while(!(*KEYS & KEY_DOWN)){
			Espera();
		}
		ranita.y+=16; if(ranita.y>144) ranita.y=144;

		ranita.movimiento = 0;
		if(ranita.y<64) ranita.agua = 1;

	} if(!(*KEYS & KEY_LEFT)){
		CambiarSprite(&sprites[ranita.indice], ranita.sprite_izquierda);

		while(!(*KEYS & KEY_LEFT)){
			Espera();
		}
 		ranita.x-=13; if(ranita.x<3) ranita.x=3;

		ranita.movimiento = 0;
		if(ranita.y<64) ranita.agua = 1;
	
	} if(!(*KEYS & KEY_RIGHT)){
		CambiarSprite(&sprites[ranita.indice], ranita.sprite_derecha);

		while(!(*KEYS & KEY_RIGHT)){
			Espera();
		}
 		ranita.x+=13;  if(ranita.x>224) ranita.x=224;

		ranita.movimiento = 0;
		if(ranita.y<64){ ranita.agua = 1;}		
	
	}
	}else if(!(*KEYS & KEY_A))
	{
		//inicializaci�n
		IniciarRana();

	}
} //fin de Teclado


// Restaura los valores iniciales de la rana.
void IniciarRana(void){
		CambiarSprite(&sprites[ranita.indice], ranita.sprite_arriba);				
		ranita.x = 107;
		ranita.y = 144;
		ranita.agua =0;ranita.movimiento=0;
		
		if(ranita.bloqueo==2){ //GANADOR PARA SIEMPRE...
			ok1.x=ok2.x=ok3.x=ok4.x=240; //Quitamos todos los sprites, tanto lo de los OK como el de GANADOR.
			MoverSprite(&sprites[ok1.indice],ok1.x,ok1.y);
			MoverSprite(&sprites[ok2.indice],ok2.x,ok2.y);
			MoverSprite(&sprites[ok3.indice],ok3.x,ok3.y);
			MoverSprite(&sprites[ok4.indice],ok4.x,ok4.y);		
			MoverSprite(&sprites[ganador1.indice],ganador1.x,ganador1.y);
			MoverSprite(&sprites[ganador2.indice],ganador2.x,ganador2.y);
		}
		ranita.bloqueo=0; //Desbloqueamos y vuelta a empezar.
} //Fin IniciarRana



//Funcion que cambia la imagen de un sprite
void CambiarSprite(OAMEntry* sp, int numero){
	sp->attribute2 = sp->attribute2 & 0xFE00;  //Limpiar la variable 
	sp->attribute2 = sp->attribute2 | numero; //asigna un nuevo valor

} //fin de CambiarSprite


//Funcion que controla el movimiento de un SPRITE.
//Actualiza las posiciones de X e Y en el SPRITE
void MoverSprite(OAMEntry* sp, int x, int y){
	sp->attribute1 = sp->attribute1 & 0xFE00;  //Limpiar la variable X
	sp->attribute1 = sp->attribute1 | x; //asigna nueva variable X
	
	sp->attribute0 = sp->attribute0 & 0xFF00;  //Limpiar la variable Y
	sp->attribute0 = sp->attribute0 | y; //asigna nueva variable Y
} //fin de MOVERSPRITE




// Dibuja en la memoria de v�deo los datos del BACKGROUND
void DibujarFondo(u16* paleta, u16* datos){		
	int i=0, m= 0, h = 0, loop = 0;

	h = 0;
	for(i=0;i<20;i++){ //Creamos el mapa. �ste tiene 32*32 tiles (256*256) pero el nuestro tiene solo 30*20 (240*160)
					  //As� que para cada tile en pantalla le asignamos un n�mero consecutivo (H) Que es el tile.
		for(m=0;m<32;m++){
			if(m<30) datosMapa[(i*32)+m] = h++; //Si es >30 no se ve... no vale la pena asignarle ning�n valor.
		}
	}	

	for(i = 0; i<(300*8*8);i++) //Escribo en mem. los datos de los tiles. Son 300 tiles (que ocupan 8*8 bits cada uno)
	{									  										  
		BufferBackground[i] = datos[i];     										  
	}									  	
	
	for(loop = 0; loop < 256; loop++) //Cargar la paleta de colores del FONDO
		PaletaMem[loop] = paleta[loop]; //PaletaMem variable GLOBAL que apunta a la memoria de la paleta. FONDOPALETA est� definido en el fichero FONDO.H y contiene los datos del fondo. Fondo creado con PCX2GBA.EXE
	

} //Fin de DibujarFondo




// Coloca en memoria los datos de un sprite. A partir de la pos. de mem [base]+cont  hasta [base]+max
// donde BASE es la pos de memoria indicada por la variable global SpriteMem
void DibujaSprite(u16* sprite, int cont, int max){
	u32  loop;
	u16 *c = (u16 *) (SpriteMem + (cont));
	for(loop = 0; loop < max; loop++) //Cargar en MEM el BITMAP del sprite.
		c[loop] = sprite[loop];  		

} //Fin DibujaSprite



// Dibuja en la memoria de video asignada la paleta de colores de los sprites (1 paleta, 256colores)
void CargaPaletaSprite(u16* paleta){
	u16  loop;
	for(loop = 0; loop < 256; loop++) //Carga en memoria de SPRITE mi paleta de sprite en el sprite1.h
	   SpriteMemPal[loop] = paleta[loop];  
} //Fin CargaPaletaSprite



// Mueve el coche horizontalmente. Calcula impacto con la ranita
void MoverCoche(s16* x, s16* y, int incremento) { 
	
	if(*y==ranita.y) //Runita de impacto con la ranita. Si la cogemos, la matamos.
		if((*x+32>=ranita.x)&&(*x<=ranita.x))	Morirse();		
	
	*x = CalculaMovimiento(*x, incremento);
} //Fin de moverBolita


// Mueve el mato horizontalmente. Calcula impacto con la ranita
void MoverTronco(s16* x, s16* y, int incremento) { 
	s16 m;
	
	if(*y==ranita.y){ //Rutina de impacto con la ranita. Si permanese sobre el tronco, no toca agua y el incremento es el mismo que el del tronco
		if(*x<240){
			if((*x+32>=(ranita.x+6))&&(*x<=(ranita.x+6))){	ranita.agua=0;	ranita.movimiento = incremento; }
		}else{
			m = *x - 512;
			if((m+32>=(ranita.x+6))&&(m<=(ranita.x+6))){	ranita.agua=0;	ranita.movimiento = incremento; }
		}
	}
	
	*x = CalculaMovimiento(*x, incremento);
	
} //Fin de moverBolita


// Mueve la planta horizontalmente. Calcula impacto con la ranita
void MoverNenufar(s16* x, s16* y, int incremento) {
	s16 m;
	
	if(*y==ranita.y){ //Rutina de impacto con la ranita. Si permanese sobre el tronco, no toca agua y el incremento es el mismo que el del tronco
		if(*x<240){ //El impacto no es el mismo que el del tronco
			if((*x+25>=(ranita.x+6))&&(*x+7<=(ranita.x+6))){	ranita.agua=0;	ranita.movimiento = incremento; }
		}else{
			m = *x - 512;
			if((m+25>=(ranita.x+6))&&(m+7<=(ranita.x+6))){	ranita.agua=0;	ranita.movimiento = incremento; }
		}
	}
	

	*x = CalculaMovimiento(*x, incremento);
	
} //Fin de moverBolita


// Si la rana se coloca sobre un tronco/nenufar se ha de mover con ellos
void MoverRana(s16* x, s16* y, int incremento) { 
	*x = CalculaMovimiento(*x, incremento);
} //Fin de moverBolita


// Actualiza la variable X de un sprite en movimiento. Tiene tela porque hay que tener en cuenta cuando llega al l�mite de pantalla
// Adem�s, el contador es UNSIGNED (no tiene bit de signo) por tanto, se hace dificil dibujar sprites en posiciones <0 (por ejemplo, un coche que empieza a dibujarse
// en la posicion -5 y termina de verse en la +5 da el efecto de estar apareciendo por la izq.
s16 CalculaMovimiento(s16 x, int incremento){
	if(incremento>0){ //Si el objeto va hacia la derecha
		x += incremento; 
		if(x>=512) x=0; //Si el objeto ha empezado otra vez, ponemos a 0 para que la variable no se dispare.
		else if((x>=240)&&(x<472)) x = 472; //El objeto est� llegando al final. lo dejamos unpoco m�s para que se vea el efecto de desaparecer por la izq.
	}else{ //El coche va hacia la izquierda. El c�digo es similar al anterior
		x += incremento;
		if(x <=0) x = 512;
		else if((x<=472)&&(x>240)) x = 240;
	}	
	return x;
} //Fin CalculaMovimiento


void Morirse(void) { // Rutina para la muerte
   CambiarSprite(&sprites[ranita.indice], ranita.sprite_muerta); //Cambiamos los datos de la ranita, por el de la ranita destripada.
   ranita.bloqueo=1; //Bloqueamos el teclado para que la ranita no se siga moviendo.
} //Fin de Morirse



//Mete en memoria los datos de un Sprite e inicializa sus valores.
void CrearSprite(int indice, u16* datos, int datos_inicio, int datos_fin, u16 atributo0, u16 atributo1, u16 atributo2){

	DibujaSprite(datos, datos_inicio,datos_fin); // Cargamos en memoria los datos.

	sprites[indice].attribute0 = atributo0;   //colores forma y coordeanda y
	sprites[indice].attribute1 = atributo1; // tama�o y coordenada X
	sprites[indice].attribute2 = atributo2; // N� de sprite asignado

}//Fin de Crear Sprite


//Realiza el BUCLE para evitar que los objetos se queden quietos mientras el User pulsa una tecla
void Espera(void) {
	
	MoverObjetos();				  //Muevo los objetos (acutalizar X e Y)
	MoverSprites();				  //Copio los nuevos X e Y a los sprites.

	EsperarPorVsync();			  //Espero que la pantalla no se est� dibujando
	CopiarOAM();			      //Actualizo los sprites en pantalla ahora que esta el VSYNC			
} //Fin de moverBolita



//Modifico todos los sprites con los nuevos valores de X e Y.
void MoverSprites(void){

	MoverSprite(&sprites[coche1.indice],coche1.x,coche1.y); //Cambio los par�metros de los coches para que coja los nuevos
	MoverSprite(&sprites[coche2.indice],coche2.x,coche2.y); 
	MoverSprite(&sprites[coche3.indice],coche3.x,coche3.y); 
	MoverSprite(&sprites[coche4.indice],coche4.x,coche4.y); 
	MoverSprite(&sprites[coche5.indice],coche5.x,coche5.y); 
	MoverSprite(&sprites[coche6.indice],coche6.x,coche6.y); 

	MoverSprite(&sprites[nenufar1.indice],nenufar1.x,nenufar1.y); //Hago lo propio con los nenufares
	MoverSprite(&sprites[nenufar2.indice],nenufar2.x,nenufar2.y); 
	MoverSprite(&sprites[nenufar3.indice],nenufar3.x,nenufar3.y); 

	MoverSprite(&sprites[tronco1.indice],tronco1.x,tronco1.y); //Y continuo con los troncos
	MoverSprite(&sprites[tronco2.indice],tronco2.x,tronco2.y); 
	MoverSprite(&sprites[tronco3.indice],tronco3.x,tronco3.y); 

	MoverSprite(&sprites[ranita.indice],ranita.x,ranita.y); //No hay que olvidar a la rana

} //Fin de MoverSprites



// Calcula las nuevas coordenadas X e Y para todos los sprites
void MoverObjetos(void){

	MoverCoche(&coche1.x, &coche1.y, coche1.velocidad); //Consiste en aumentar la X y comprobar impacto con la rana
	MoverCoche(&coche2.x, &coche2.y, coche2.velocidad);
	MoverCoche(&coche3.x, &coche3.y, coche3.velocidad);
	MoverCoche(&coche4.x, &coche4.y, coche4.velocidad);
	MoverCoche(&coche5.x, &coche5.y, coche5.velocidad);
	MoverCoche(&coche6.x, &coche6.y, coche6.velocidad);

	MoverNenufar(&nenufar1.x, &nenufar1.y, nenufar1.velocidad); //Actualizar la X y comprobar impacto con rana
	MoverNenufar(&nenufar2.x, &nenufar2.y, nenufar2.velocidad);
	MoverNenufar(&nenufar3.x, &nenufar3.y, nenufar3.velocidad);

	MoverTronco(&tronco1.x, &tronco1.y, tronco1.velocidad); //Lo mismo: X e impacto
	MoverTronco(&tronco2.x, &tronco2.y, tronco2.velocidad);
	MoverTronco(&tronco3.x, &tronco3.y, tronco3.velocidad);

	if(ranita.movimiento) MoverRana(&ranita.x, &ranita.y, ranita.movimiento); //Si estoy sobre un tronco, muevo la rana (acutalizo su X)

} //Fin MoverObjetos;



//Rutina de la victoria
void Ganar(void){

	//Basicamente se comprueba que la rana llegue a uno de los 4 huecos. Si ya ha estado ah� la matamos. Pero si no,
	//colocamos un OK en ese hueco y bloqueamos
	if(ranita.x<=54){
		if(ok1.x==34) Morirse (); //ya estuvo por aqui. Muerete, perdedor! jajajaja
		ok1.x = 34;
		MoverSprite(&sprites[ok1.indice],ok1.x,0);
	}else if(ranita.x<=106){
		if(ok2.x==86) Morirse (); 
		ok2.x = 86;
		MoverSprite(&sprites[ok2.indice],ok2.x, 0);
	}else if(ranita.x<=184){
		if(ok3.x==138) Morirse (); 
		ok3.x = 138;
		MoverSprite(&sprites[ok3.indice],ok3.x,0);
	}else if(ranita.x<=240){
		if(ok4.x==190) Morirse ();
		ok4.x = 190;
		MoverSprite(&sprites[ok4.indice],ok4.x,0);
	}

	if((ok1.x==34)&&(ok2.x==86)&&(ok3.x==138)&&(ok4.x==190)){ //Llego a todos los huecos. Es un ganador!		
		ranita.x = 240; ranita.y = 160; //sacamos la rana de pantalla
		MoverSprite(&sprites[ganador1.indice],56,48); //Mostramos las felicitaciones
		MoverSprite(&sprites[ganador2.indice],120,48);
		ranita.bloqueo = 2;
	}else if(ranita.bloqueo==0){ //Si no ha completado los cuatro huecos (y no ha muerto por repetir hueco) lo volvemos a colocar al principio para que continue..
		IniciarRana();	
	}
		
} // Fin Ganar






//Crea la estructura de todos los sprites del juego.
void CrearSprites(void){

	CrearSprite(ranita.indice, ranita.sprite, 0, 128, COLOR_256 | SQUARE | ranita.y, SIZE_16 | ranita.x, PRIORITY(2) | 0);	
	// Crear el primer Sprite. "ranita.indice" indica el n�mero de Sprite (en este caso es el n� 0)
	// "ranita.sprite" contiene los datos de la imagen
	// "0 - 128" indica donde ser�n colocados los bytes de la imagen. Desde [BASE] hasta [BASE]+128. 
	// Esta cantidad de BYTES es la que yo he querido definir para la rana.	De aqui se deduce que la ranita tiene 128bytes de informacion
	// Los datos contiene 256 colores, el sprite tiene forma cuadrada. "ranita.y" y "ranita.x" indican las posiciones X e Y iniciales
	// SIZE_16 indica que el sprite es de 16*16p�xeles (porque adem�s es SQUARE) lo que hacen un total de 256p�xeles. 
	// De aqu� se desprende que los datos son 128bytes, pero la imagen consume 256bytes ya que as� lo exige el tama�o del Sprite (es el mas cercano para nuestros prop�sitos). Por tanto, 128bytes ser�n dejados a 0 (sin inicializar = color transparente). Pero hay que tener en cuenta que el siguiente SPRITE comienza en la [BASE]+256 posici�n y no en la [BASE]+128 !!!!
	ranita.sprite_arriba=0;					// Pos de mem en palabras: [BASE] + 0. Es decir, el primer sprite.
	DibujaSprite(&ranaMuerta, 256,384);		// Sprite RANA MUERTA. 
	ranita.sprite_muerta=16;				// 1 car�cter de 16*16 tiene 256bytes
											// A la hora de calcular la ubicaci�n de los datos, el hardware va contando de 16 en 16bytes
											// Por tanto, 256/16 = 16 <-- que es la posicion que debemos darle al hard para que coja este segundo sprite.											
	DibujaSprite(&ranaDerecha, 512,640);	// Sprite RANA. 
	ranita.sprite_derecha=32;				// Pos de mem en palabras: [BASE] + 32. Tercer sprite. 512/16 = 32
	DibujaSprite(&ranaIzquierda, 768,896);	// Sprite RANA.					
	ranita.sprite_izquierda=48;				// Pos de mem en palabras: [BASE] + 43. Cuarto sprite. 768/16 = 48
	DibujaSprite(&ranaAbajo, 1024,1152);	// Sprite RANA.
	ranita.sprite_abajo=64;					// Pos de mem en palabras: [BASE] + 64. Quinto sprite. 1024/16 = 64

	
	//De esta misma manera se continua definiendo los siguientes sprites (coches en este caso). Especial atencion a los par�metros cuarto y quinto de la funcion CREARSPRITE.		
	//En este caso, los sprites no son cuadrados, sino alargados (TALL) 32*16pixeles = 
	CrearSprite(coche1.indice, coche1.sprite, 1280, 1408, COLOR_256 | TALL | coche1.y, SIZE_32 | coche1.x, PRIORITY(1) | 80);
	CrearSprite(coche2.indice, coche2.sprite, 1536, 1664, COLOR_256 | TALL | coche2.y, SIZE_32 | coche2.x, PRIORITY(1) | 96);
	CrearSprite(coche3.indice, coche3.sprite, 1792, 1920, COLOR_256 | TALL | coche3.y, SIZE_32 | coche3.x, PRIORITY(1) | 112);
	CrearSprite(coche4.indice, coche4.sprite, 2048, 2176, COLOR_256 | TALL | coche4.y, SIZE_32 | coche4.x, PRIORITY(1) | 128);
	CrearSprite(coche5.indice, coche5.sprite, 2304, 2432, COLOR_256 | TALL | coche5.y, SIZE_32 | coche5.x, PRIORITY(1) | 144);
	CrearSprite(coche6.indice, coche6.sprite, 2560, 2688, COLOR_256 | TALL | coche6.y, SIZE_32 | coche6.x, PRIORITY(1) | 160);

	//Continuamos con los nenufares y los troncos.
	CrearSprite(nenufar1.indice, nenufar1.sprite, 2816, 2944, COLOR_256 | TALL | nenufar1.y, SIZE_32 | nenufar1.x, PRIORITY(3) | 176);
	CrearSprite(nenufar2.indice, nenufar2.sprite, 3072, 3200, COLOR_256 | TALL | nenufar2.y, SIZE_32 | nenufar2.x, PRIORITY(3) | 192);
	CrearSprite(nenufar3.indice, nenufar3.sprite, 3328, 3456, COLOR_256 | TALL | nenufar3.y, SIZE_32 | nenufar3.x, PRIORITY(3) | 208);
	CrearSprite(tronco1.indice,  tronco1.sprite, 3584, 3712, COLOR_256 | TALL |  tronco1.y, SIZE_32 |  tronco1.x, PRIORITY(3) | 224);
	CrearSprite(tronco2.indice,  tronco2.sprite, 3840, 3968, COLOR_256 | TALL |  tronco2.y, SIZE_32 |  tronco2.x, PRIORITY(3) | 240);
	CrearSprite(tronco3.indice,  tronco3.sprite, 4096, 4224, COLOR_256 | TALL |  tronco3.y, SIZE_32 |  tronco3.x, PRIORITY(3) | 256);

	//Creamos los 4 sprites para el OK. Los situamos originalmente fuera de la pantalla
	CrearSprite(ok1.indice,  ok1.sprite, 4352, 4480, COLOR_256 | SQUARE |  ok1.y, SIZE_16 |  ok1.x, PRIORITY(0) | 272);
	CrearSprite(ok2.indice,  ok2.sprite, 4608, 4736, COLOR_256 | SQUARE |  ok2.y, SIZE_16 |  ok2.x, PRIORITY(0) | 288);
	CrearSprite(ok3.indice,  ok3.sprite, 4864, 4992, COLOR_256 | SQUARE |  ok3.y, SIZE_16 |  ok3.x, PRIORITY(0) | 304);
	CrearSprite(ok4.indice,  ok4.sprite, 5120, 5248, COLOR_256 | SQUARE |  ok4.y, SIZE_16 |  ok4.x, PRIORITY(0) | 320);

	//Creamos los 2 sprites para felicitar cuando gana.
	CrearSprite(ganador1.indice,  ganador1.sprite, 5376, 5632, COLOR_256 | SQUARE |  ganador1.y, SIZE_64 |  ganador1.x, PRIORITY(0) | 336);
	CrearSprite(ganador2.indice,  ganador2.sprite, 7984, 8240, COLOR_256 | SQUARE |  ganador2.y, SIZE_64 |  ganador2.x, PRIORITY(0) | 499);
}//fin de crearSprites



//Fin del TUTORIAL.
