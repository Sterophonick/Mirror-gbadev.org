PACOMAN FINAL VERSION
December 2nd, 2002.


This is a project I have invested a lot of hours in. It's a Namco's Pacman clone called Pacoman. It features 5 levels of increasing difficult, intelligent ghosts, full 512x512 maze and hi-score saving. It has some bugs, but they're minor, and now it features sound!!! I hope you can enjoy playing Pacoman the same I did making it. And forgive me for these little bugs, it's my first game :).

In the main menu, you can set options by selecting them with the cursor and pressing left/right. The language option changes language from Spanish to English or from English to Spanish. And the sound option can deactivate or activate sound for those who play Pacoman with an emulator and it goes slow.

The credits screen song is from Wonderboy III: The Dragon's Trap on Game Gear. Play it if you've got the chance.

My webpage is http://cydoniasystems.tripod.com for more information don't hesitate visiting it or emailing me to taiyou_prod@hotmail.com

Thanks :)




PACOMAN VERSI�N FINAL
2 de Diciembre de 2002.


Este es un proyecto en el que he invertido un mont�n de horas. Es un clon del Pacman de Namco llamado Pacoman. Tiene 5 niveles de dificultad creciente, fantasmas inteligentes, un laberinto de 512x512 y guarda los records. Tiene algunos fallitos pero no son muy grandes, ���y ahora ya tiene sonido!!! Espero que disfrut�is jugando a Pacoman tanto como yo he disfrutado haci�ndolo. Y perdonadme por esos fallitos, es mi primer juego ;).

En el men� principal, puedes cambiar las opciones seleccion�ndolas con el cursor y pulsando izquierda/derecha. La opci�n del idioma cambia el idioma de los mensajes del juego de ingl�s a espa�ol y viceversa. Y la opci�n de sonido activa o desactiva el sonido en el juego para aquellos que jueguen con emulador y �ste les vaya lento.

La canci�n de los t�tulos de cr�dito es del juego Wonderboy III: The Dragon's Trap de Game Gear. Ju�galo si tienes la oportunidad.

Mi p�gina web es http://cydoniasystems.tripod.com para m�s informaci�n no dudes en visitarla o mandarme un mail a taiyou_prod@hotmail.com

Gracias :)
