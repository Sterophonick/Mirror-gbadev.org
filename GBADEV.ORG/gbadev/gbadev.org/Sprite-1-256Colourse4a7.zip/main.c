/*	Coder:		Decay
	E-mail:		thefountainofdecay@hotmail.com
	Home Page:	http://members.lycos.co.uk/gbce
	File:		Main.c
	Date:		01/02/2003
	Purpose:	very simple demo to show how to display a single 256 colour sprite on the gba
*/

#include "PLANE.h"

//list defines for the screen register at 0x4000000
#define REG_DISPCNT *(unsigned short*)0x4000000	//this controls vid mode, bkgs, objs. define as a pointer and dereference it
#define MODE_0 0x0	//set mode 0 - tiled, bkgs 0123, no rot/scale
#define MODE_1 0x1	//set mode 1 - tiled, bkgs 012, rot/scale 2
#define MODE_2 0x2	//set mode 2 - tiled, bkgs 23,  rot/scale 23
#define MODE_3 0x3	//set mode 3 - 16bit buffer (enable bkg 2 to use)
#define MODE_4 0x4	//set mode 4 - 8bit buffer, double bufferable
#define MODE_5 0x5	//set mode 5 - 16bit buffer, double bufferable at 160x128
#define BG0_ENABLE 0x100	//enable bkg 0
#define BG1_ENABLE 0x200	//enable bkg 1	 
#define BG2_ENABLE 0x400	//enable bkg 2
#define BG3_ENABLE 0x800	//enable bkg 3
#define OBJ_ENABLE 0x1000 	//enable objects

#define VBLANK_CNT	*(unsigned short*)0x4000006	//current vertical line being drawn, needs volatile
#define BKG_PALETTE	(unsigned short*)0x5000000	//start of bkg palettes
#define VRAM (unsigned short*)0x6000000	//start of vram
#define VRAM_BUFFER 0x600A000	//start of vram buffer for mode 45

#define OBJ_2DMAP 0x0	//2d sprite map
#define OBJ_1DMAP 0x40	//1d sprite map
#define COLOR_256	0x2000
#define SIZE_8		0x0
#define SIZE_16		0x4000
#define SIZE_32		0x8000
#define SIZE_64		0xC000

#define SetMode(mode) REG_DISPCNT=(mode)

unsigned short* OBJ_PALETTE =(unsigned short*)0x5000200;	//setup a pointer to the OBJ palette area
unsigned short* VideoBuffer=(unsigned short*)0x6000000;	//setup a pointer to VRAM
unsigned short* OBJ_VRAM =(unsigned short*)0x6010000;	//setup a pointer to OBJ data area
unsigned short* OAM_MEM =(unsigned short*)0x7000000;	//setup a pointer to OBJ memory

typedef struct tagSprite
{
	unsigned short attribute0;
	unsigned short attribute1;
	unsigned short attribute2;
	unsigned short attribute3;
}Sprite;

Sprite Sprites[128];

void WaitForVSync()
{
	while ((volatile unsigned short)VBLANK_CNT != 160) {}	//wait till vblank is at bottom of screen
}

void CopyOAM(void)
{
	unsigned short counter;
	unsigned short *temp;
	temp = (unsigned short*)Sprites;
	for(counter=0; counter<512; counter++)	//only have 512 characters since using 256 colour sprites
	{
		OAM_MEM[counter] = temp[counter];
	}
}

int main(void)
{
	unsigned short counter;
	
	//set up video and show obj in 1D
	SetMode(MODE_4|OBJ_ENABLE|OBJ_1DMAP);
	// load sprite palette into mem
	for (counter=0;counter<256;counter++)	//256 colours
		OBJ_PALETTE[counter]=PLANEPalette[counter];

	//move all 128 sprites off screen before setting attributes else a blob will appear in the top left corner
	for (counter=3;counter<128;counter++)
	{
		Sprites[counter].attribute0 = 160;	//move y offscreen
		Sprites[counter].attribute1 = 240;	//move x offscreen
	}

	Sprites[0].attribute0 = COLOR_256 | SIZE_16 | 50;	//y-axis data. 256 colours, 16 pixels high, 50 down
	Sprites[0].attribute1 = SIZE_32 | 110;	//x-axis. 32 pixels wide, 110 across
	Sprites[0].attribute2 = 512;	//OAM character number, since using 256 colour sprites it can only be 512-1023

	//put the sprite data into a holding place in memory
	for (counter=0;counter<256;counter++)	//32*16=512  Use half that value (256) since we write 2 pixels at once
		OBJ_VRAM[counter + 0x2000]=PLANEData[counter];
		//since we are using bitmap mode (4) for the background, we have less room for sprites in OBJ_VRAM
		//as the background uses 0x6000000 to 0x6012BFF, which cuts into OBJ_VRAM which starts at 0x6010000.
		//We are also using 256 colours for sprites, so we can only display sprites 512-1023 (256 colour
		//sprites take up twice the room of a 16 colour sprite). This mean that the starting position of OBJ_VRAM
		//is moved to 0x6014000. Thus we write to OBJ_VRAM[counter+0x2000 ] since the 0x2000 is 16bit

	WaitForVSync();
	CopyOAM();
	while (1)
	{}
}
