/////////////////////////////////////////////////////////////////////////////
//
// Player
// Rich Heasman June 2002
//
/////////////////////////////////////////////////////////////////////////////

#include 	"gba.h"
#include 	"player.h"

#include 	"gfx.h"
#include 	"gfxdata2.h"
#include 	"sprite.h"
#include 	"button.h"
#include 	"palette.h"
#include 	"pixel.h"
#include 	"fuse.h"
#include 	"debug.h"
#include 	"timer.h"
#include 	"rnd.h"
#include 	"error.h"
#include 	"background.h"
#include 	"profile.h"
#include 	"qix.h"
#include 	"display.h"
#include 	"attract.h"
#include 	"ball.h"
#include 	"string.h"
#include 	"soundfx.h"

//-------------------------------------------------------------------------

//#define	PLAYER_IMMORTAL	TRUE
#define	PLAYER_IMMORTAL 	FALSE

enum
{
	PLAYER_ALIVE,
	PLAYER_DEATH_INIT,
	PLAYER_DEATH,
	PLAYER_DEAD
};

enum
{
	PLAYER_MOVING,
	PLAYER_DRAWING,
	PLAYER_FILL
};

#define	PLAYER_FUSE_DELAY			10		// time stopped until fuse starts
#define	PLAYER_DEATH_DELAY			0		// time for death anim
#define	PLAYER_LIVES				3		// starting lives
#define	PLAYER_EXTRA_SCORE			10000 	// extra life every
#define	PLAYER_SCORE_MAX			999999	// max score

//-------------------------------------------------------------------------

static	int			nPlayerStatus;			// alive, dead
static	int			nPlayerMode;			// on line, drawing, filling
static	SPRITE_TYPE	*pPlayerSprite;
static	int			nPlayerX;
static	int			nPlayerY;
static	int			nPlayerPreviousDX;
static	int			nPlayerPreviousDY;
static	int			nPlayerStartX;			// start of current line 
static	int			nPlayerStartY;
static	int			nPlayerPixelsFilled;
static	int			nPlayerPixelsPercentage;
static	int			nPlayerPercentageNeeded;
static	BOOL		boPlayerKillable;
static	int			nPlayerScore;
static	int			nPlayerExtraScore;
static	BOOL		boPlayerSlowDraw;
static	BOOL		boPlayerSlowSkip;

static	BOOL		boPlayerStopped;
static	int			nPlayerDeathTimer;
static	int			nPlayerFuseTimer;
static	int			nPlayerLives;

//-------------------------------------------------------------------------

void	Player_Init(void)
{
	pPlayerSprite = Sprite_Create(GFX_PLAYER, 0, GFX_SCREEN_PIXEL_HEIGHT);
	nPlayerStatus = PLAYER_DEAD;

}	

//-------------------------------------------------------------------------

void	Player_Update(void)
{
	switch (nPlayerStatus)
	{
		case PLAYER_ALIVE:
		{
			Player_Control();
			break;
		}
		case PLAYER_DEATH_INIT :
		{
			Fuse_Stop();
			Timer_Set(&nPlayerDeathTimer, PLAYER_DEATH_DELAY);
			SoundFX_Make(SOUNDFX_CHANNEL_A, SOUNDFX_DEATH);
			SoundFX_Stop(SOUNDFX_CHANNEL_B);
			nPlayerStatus = PLAYER_DEATH;
			break;
		}
		case PLAYER_DEATH :
		{
			if (Timer_Mature(&nPlayerDeathTimer))
			{
				nPlayerLives--;
				Display_LivesSet(nPlayerLives);
				nPlayerStatus = PLAYER_DEAD;
			}
			break;
		}
		case PLAYER_DEAD :
		{
			break;
		}
	}
}	

//-------------------------------------------------------------------------

void	Player_Control(void)
{
	int		nDX;
	int		nDY;
	int		nFire;
	int		nNewX;
	int		nNewY;
	uint	uColour;
	uint	uDrawColour;

	// get controls
	nDX = 0;
	nDY = 0;
	nFire = 0;
	if (Button_Pressed(BUTTON_UP))		nDY = -1;
	if (Button_Pressed(BUTTON_DOWN))	nDY = 1;
	if (Button_Pressed(BUTTON_LEFT)) 	nDX = -1;
	if (Button_Pressed(BUTTON_RIGHT)) 	nDX = 1;
	if (Button_Pressed(BUTTON_A))		nFire = 1;

	if (Attract_Active())
	{
		Attract_ControlsGet(&nFire, &nDX, &nDY);
	}

	nNewX = nPlayerX + nDX;
	nNewY = nPlayerY + nDY;

	if (nNewX < GFX_PLAY_X0 || nNewX > GFX_PLAY_X1)		nDX = 0;
	if (nNewY < GFX_PLAY_Y0 || nNewY > GFX_PLAY_Y1)		nDY = 0;

	switch (nPlayerMode)
	{
		case PLAYER_MOVING :
		{
			// new line
			if (nFire)
			{
				if (nDX != 0 && nDY != 0)	nDY = 0;	// bias X if diagonal pressed
				uColour	= Pixel_Get(nPlayerX + nDX, nPlayerY + nDY);

				if (uColour & COLOUR_BEHIND && !(uColour & COLOUR_BAD))
				{
					nPlayerX += nDX;
					nPlayerY += nDY;
					nPlayerStartX = nPlayerX;
					nPlayerStartY = nPlayerY;
					nPlayerMode = PLAYER_DRAWING;
					boPlayerSlowDraw = TRUE;
					boPlayerSlowSkip = TRUE;
					if (!Attract_Active())
					{
						SoundFX_Make(SOUNDFX_CHANNEL_B, SOUNDFX_LINE);
					}
				}
			}
			else	// move along line
			{
				if (Pixel_Get(nPlayerX + nDX, nPlayerY) != COLOUR_LINE)	nDX = 0;
				if (Pixel_Get(nPlayerX, nPlayerY + nDY) != COLOUR_LINE)	nDY = 0;

				// figure out which direction to go if diagonal pressed
				if (nDX != 0 && nDY != 0)
				{
					// bias a change of direction (help to get down lines not on edge)
					if (nDX == nPlayerPreviousDX)
					{
						nDX = 0;
					}
				}
				if (nDX != 0 && nDY != 0)
				{
				 	nDY = 0;
				}

				uColour	= Pixel_Get(nPlayerX + nDX, nPlayerY + nDY);
				if (uColour == COLOUR_LINE)
				{
					nPlayerX += nDX;
					nPlayerY += nDY;
				}
			}

			break;
		}
		case PLAYER_DRAWING :
		{
			if (nDX != 0 && nDY != 0)	nDY = 0;	// bias X if diagonal pressed
			uColour	= Pixel_Get(nPlayerX + nDX, nPlayerY + nDY);

			Player_FuseUpdate(nDX, nDY);

			if (nPlayerStatus == PLAYER_ALIVE)
			{
				if (uColour & COLOUR_BAD)
				{
					Player_KillRequest();
				}

				if (nFire)
				{
					if (boPlayerSlowSkip)
					{
						nDX = 0;
						nDY = 0;
					}
					boPlayerSlowSkip = !boPlayerSlowSkip;
				}
				else
				{
					boPlayerSlowDraw = FALSE;
				}

				uDrawColour = 0;
				// draw line
				if (nDX != 0 || nDY != 0)
				{
					// set draw colour dependant on direction (all colours look the same)
					if (nDX == -1) uDrawColour = COLOUR_PLAYER_LEFT;
					if (nDX == 1) uDrawColour = COLOUR_PLAYER_RIGHT;
					if (nDY == -1) uDrawColour = COLOUR_PLAYER_UP;
					if (nDY == 1) uDrawColour = COLOUR_PLAYER_DOWN;

					if (uColour & COLOUR_BEHIND && !(uColour & COLOUR_BAD))
					{
						uColour = Pixel_Get(nPlayerX, nPlayerY);
						if (uColour & COLOUR_BAD)
						{
							uDrawColour ^= COLOUR_BAD;
						}
						Pixel_SetPen(uDrawColour);
						Pixel_Plot(nPlayerX, nPlayerY);
						nPlayerPixelsFilled++;
						nPlayerX += nDX;
						nPlayerY += nDY;
					}

					uColour	= Pixel_Get(nPlayerX + nDX, nPlayerY + nDY);

					// check for end of line
					if (uColour == COLOUR_LINE)
					{
						uColour = Pixel_Get(nPlayerX, nPlayerY);
						if (uColour & COLOUR_BAD)
						{
							uDrawColour ^= COLOUR_BAD;
						}
						Pixel_SetPen(uDrawColour);
						Pixel_Plot(nPlayerX, nPlayerY);
						nPlayerPixelsFilled++;
						Fuse_Stop();

						nPlayerX += nDX; 
						nPlayerY += nDY;

						SoundFX_Stop(SOUNDFX_CHANNEL_B);

						nPlayerMode = PLAYER_FILL;
					}
				}
			}
			break;
		}
		case PLAYER_FILL:
		{
			Player_RemoveLine(COLOUR_LINE);
			Player_Fill(nPlayerX, nPlayerY, nPlayerPreviousDX, nPlayerPreviousDY);
			nPlayerMode = PLAYER_MOVING;
			break;
		}
	}

	nPlayerPreviousDX = nDX; 
	nPlayerPreviousDY = nDY; 
}	

//-------------------------------------------------------------------------

void	Player_FuseUpdate(int nDX, int nDY)
{
	// check for fuse start
	if (nDX == 0 && nDY == 0)
	{
		if (boPlayerStopped)
		{
			if (Timer_Mature(&nPlayerFuseTimer))
			{
				Fuse_Start(nPlayerStartX, nPlayerStartY);
			}
		}
		else
		{
			boPlayerStopped = TRUE;
			Timer_Set(&nPlayerFuseTimer, PLAYER_FUSE_DELAY);
		}
	}
	else
	{
		boPlayerStopped = FALSE;
	}

	// check for death by fuse
	if (Fuse_Collision(nPlayerX, nPlayerY))
	{
		Player_Kill();
	}
}

//-------------------------------------------------------------------------

void	Player_Render(void)
{
	int		nX;
	int		nY;

	nX = 0;
	nY = GFX_SCREEN_PIXEL_HEIGHT;

	switch (nPlayerStatus)
	{
		case PLAYER_ALIVE :
		{
			nX = nPlayerX - GFX_PLAYER_WIDTH/2;
			nY = nPlayerY - GFX_PLAYER_HEIGHT/2;
			break;
		}
		case PLAYER_DEATH :
		{
			nX = 0;
			nY = GFX_SCREEN_PIXEL_HEIGHT;
			break;
		}
	}

	Sprite_PositionSet(pPlayerSprite, nX, nY);
}	

//-------------------------------------------------------------------------

void	Player_Begin(void)
{
	nPlayerScore = 0;
	Display_ScoreSet(nPlayerScore);
	nPlayerExtraScore = PLAYER_EXTRA_SCORE;
	nPlayerLives = PLAYER_LIVES;
	Display_LivesSet(nPlayerLives);
}	

//-------------------------------------------------------------------------

void	Player_Start(int nLevel)
{
	int	nThrough;

	nThrough = ((nLevel+1) / 15);
	if (nThrough >= 4)
	{
		nThrough = 4;
	}
	nPlayerPercentageNeeded = 75 + nThrough * 5;

	boPlayerKillable = TRUE;
	if (nLevel % 5 == 0)
	{
		boPlayerKillable = FALSE;
	}
	Display_BonusSet(!boPlayerKillable);

	nPlayerX = GFX_SCREEN_PIXEL_WIDTH/2;
	nPlayerY = GFX_PLAY_Y1;
	nPlayerStatus = PLAYER_ALIVE;
	nPlayerMode = PLAYER_MOVING;
	boPlayerStopped = FALSE;
	nPlayerPixelsFilled = 0;
	nPlayerPixelsPercentage = 0;
	Display_PercentageSet(nPlayerPixelsPercentage);
}	

//-------------------------------------------------------------------------

void	Player_Continue(void)
{
	int	uColour;
	int	uDrawColour;

	if (nPlayerMode == PLAYER_DRAWING || nPlayerMode == PLAYER_FILL)
	{
		uColour	= Pixel_Get(nPlayerX, nPlayerY);
		uColour	&= ~COLOUR_BAD;
		uDrawColour = COLOUR_BEHIND_1;
		if (uColour == COLOUR_BEHIND_2)
		{
			uDrawColour = COLOUR_BEHIND_2;
		}

		nPlayerX = nPlayerStartX;
		nPlayerY = nPlayerStartY;

		uColour	= Pixel_Get(nPlayerStartX, nPlayerStartY);
		uColour	&= ~COLOUR_BAD;
		if (uColour == COLOUR_PLAYER_LEFT) 	nPlayerX += 1;
		if (uColour == COLOUR_PLAYER_RIGHT) nPlayerX += -1;
		if (uColour == COLOUR_PLAYER_UP) 	nPlayerY += 1;
		if (uColour == COLOUR_PLAYER_DOWN) 	nPlayerY += -1;

		Player_RemoveLine(uDrawColour);
	}

	nPlayerStatus = PLAYER_ALIVE;
	nPlayerMode = PLAYER_MOVING;
	boPlayerStopped = FALSE;
}	

//-------------------------------------------------------------------------

void	Player_RemoveLine(int uFillColour)
{
	int		nX;
	int		nY;
	uint	uColour;
	uint	uDrawColour;
	BOOL	boDone;

	nX = nPlayerStartX;
	nY = nPlayerStartY;

	boDone = FALSE;
	while (!boDone)
	{
		uColour	= Pixel_Get(nX, nY);
		uDrawColour	= uColour & COLOUR_BAD;
		uColour	&= ~COLOUR_BAD;

		if ((uColour < COLOUR_PLAYER_LEFT) || (uColour > COLOUR_PLAYER_DOWN))
		{
			boDone = TRUE;
		}
		else
		{
			uDrawColour ^= uFillColour;
			Pixel_SetPen(uDrawColour);
			Pixel_Plot(nX, nY);
													 
			if (uColour == COLOUR_PLAYER_LEFT) 	nX += -1;
			if (uColour == COLOUR_PLAYER_RIGHT) nX += 1;
			if (uColour == COLOUR_PLAYER_UP) 	nY += -1;
			if (uColour == COLOUR_PLAYER_DOWN) 	nY += 1;
		}
	}
}	

//-------------------------------------------------------------------------

// Fills the areas the baddies are not in with solid colour, called upon the player completing a line

void	Player_Fill(int nX, int nY, int nDX, int nDY)
{
	int		nX0;
	int		nY0;
	int		nX1;
	int		nY1;
	int		nColourIn0;
	int		nColourIn1;
	uint	uColour;
	int		nPreviousX;
	int		nPreviousY;
	int		nDSwap;
	int		nScore;
	int		nSound;

//	Profile_Point("Pre Fill");

	// check for recent change of attack

	nPreviousX = nX - nDX;
	nPreviousY = nY - nDY;

	uColour = Pixel_Get(nPreviousX - nDX, nPreviousY - nDY);
	if (uColour & COLOUR_BEHIND)
	{
		nDSwap = nDX;
		nDX = nDY; 
		nDY = nDSwap;

		uColour = Pixel_Get(nPreviousX - nDX, nPreviousY - nDY);
		if (uColour & COLOUR_BEHIND)
		{
			nDX = -nDX;
			nDY = -nDY;
		}
	}

	// get co-ords for 2 points either side of completed line

	nX0 = nX - nDX;
	nY0 = nY - nDY;
	nX1 = nX - nDX;
	nY1 = nY - nDY;

	if (nDX == 0)
	{
		nX0 += 1;
		nX1 -= 1;
	}
	if (nDY == 0)
	{
		nY0 += 1;
		nY1 -= 1;
	}

	// find background for each point

	Player_FindBackground(&nX0, &nY0, nDX, nDY);
	Player_FindBackground(&nX1, &nY1, nDX, nDY);


	// test each region for foreign colour

	nColourIn0 = Player_TestRegion(nX0, nY0);
	nColourIn1 = Player_TestRegion(nX1, nY1);

	// if no foreign bodies found in regions then fill solid

	uColour = COLOUR_BOX_1;
	nSound = SOUNDFX_FILL1;
	if (boPlayerSlowDraw)
	{
		uColour = COLOUR_BOX_2;
		nSound = SOUNDFX_FILL2;
	}
	Pixel_SetPen(uColour);

	if (!Attract_Active())
	{
		if (nColourIn0 == 0 || nColourIn1 == 0)
		{
			SoundFX_Make(SOUNDFX_CHANNEL_A, nSound);
		}
	}
	 
	if (nColourIn0 == 0)
	{
		__FarFunction(Pixel_Fill, nX0, nY0);
		nPlayerPixelsFilled += Pixel_FilledGet();
	}
	
	if (nColourIn1 == 0)
	{
		__FarFunction(Pixel_Fill, nX1, nY1);
		nPlayerPixelsFilled += Pixel_FilledGet();
	}

	nPlayerPixelsPercentage = (nPlayerPixelsFilled * 100) / ((GFX_PLAY_WIDTH - 2) * (GFX_PLAY_HEIGHT-2));
	Display_PercentageSet(nPlayerPixelsPercentage);

	nScore = nPlayerPixelsFilled / 256;
	if (boPlayerSlowDraw)
	{
		nScore *= 32;
	}
	Player_ScoreAdd(nScore);

//	Profile_Point("Post Fill");
//	Profile_Hold(60 * 10);
}	

//-------------------------------------------------------------------------

// Finds a point of background colour
// if a test point is on a line then it is moved until background is found

void	Player_FindBackground(int *pX, int *pY, int nDX, int nDY)
{
	BOOL	boFoundBackground;
	BOOL	boOffEdge;
	uint	uColour;

	// find background by moving backwards along delta if on line

	boFoundBackground = FALSE;
	boOffEdge = FALSE;
	do {
		uColour = Pixel_Get(*pX, *pY);
		if (uColour & COLOUR_BEHIND)
		{
			boFoundBackground = TRUE;
		}
		else
		{
			*pX -= nDX;
			*pY -= nDY;
		}
		if ((*pX <= GFX_PLAY_X0 || *pX >= GFX_PLAY_X1)
		 || (*pY <= GFX_PLAY_Y0 || *pY >= GFX_PLAY_Y1))
		{
			boOffEdge = TRUE;
		}
	} while (!boFoundBackground && !boOffEdge);
}	

//-------------------------------------------------------------------------

// Tests if a baddy is in a fill region
// returns true if there are foreign colours in a region
// There are 2 background colours both set to look the same, these are toggled for the fills

int		Player_TestRegion(int nX, int nY)
{
	int 	nColourIn;
	uint	uColour;

	// toggle background colour
	uColour = COLOUR_BEHIND_1;
	if (Pixel_Get(nX, nY) == COLOUR_BEHIND_1)
	{
		uColour = COLOUR_BEHIND_2;
	}
	Pixel_SetPen(uColour);
	// fill region
	nColourIn = __FarFunction(Pixel_Fill, nX, nY);

	return(nColourIn);
}	

//-------------------------------------------------------------------------

BOOL	Player_Alive(void)
{
	return(nPlayerStatus != PLAYER_DEAD);
}	

//-------------------------------------------------------------------------

void	Player_KillRequest(void)
{
	if (boPlayerKillable)
	{
		Player_Kill();
	}
}	

//-------------------------------------------------------------------------

void	Player_Kill(void)
{
	if (nPlayerStatus == PLAYER_ALIVE)
	{
		if (!PLAYER_IMMORTAL)
		{
			nPlayerStatus = PLAYER_DEATH_INIT;
		}
	}
}	

//-------------------------------------------------------------------------

BOOL	Player_AtPosition(int nX, int nY)
{
	BOOL	boAt;
	
	boAt = FALSE;
	if (nPlayerStatus == PLAYER_ALIVE)
	{
		if (nX == nPlayerX && nY == nPlayerY)
		{
			boAt = TRUE;
		}
	}

	return(boAt);
}	

//-------------------------------------------------------------------------

BOOL	Player_LevelComplete(void)
{
	BOOL	boComplete;

	boComplete = FALSE;
	if (nPlayerPixelsPercentage >= nPlayerPercentageNeeded)
	{
		boComplete = TRUE;
	}

	return(boComplete);
}	

//-------------------------------------------------------------------------

int		Player_LivesGet(void)
{
	return(nPlayerLives);
}	

//-------------------------------------------------------------------------

BOOL	Player_Killable(void)
{
	return(boPlayerKillable);
}	

//-------------------------------------------------------------------------

void	Player_ScoreAdd(int nScore)
{
	nPlayerScore += nScore;
	if (nPlayerScore > PLAYER_SCORE_MAX)
	{
		nPlayerScore = PLAYER_SCORE_MAX;
	}

	Display_ScoreSet(nPlayerScore);

	while (nPlayerScore >= nPlayerExtraScore)
	{
		if (nPlayerLives < 10)
		{
			nPlayerLives++;
			Display_LivesSet(nPlayerLives);
			if (!Attract_Active())
			{
				SoundFX_Make(SOUNDFX_CHANNEL_A, SOUNDFX_NEW_LIFE);
			}
		}
		nPlayerExtraScore += PLAYER_EXTRA_SCORE;
	}
}	

//-------------------------------------------------------------------------

void	Player_CompleteScore(void)
{
	int	nExtra;

	nExtra = nPlayerPixelsPercentage - nPlayerPercentageNeeded;
	Player_ScoreAdd(nExtra * 200);
	Display_LivesSet(nPlayerLives);
}	

//-------------------------------------------------------------------------
