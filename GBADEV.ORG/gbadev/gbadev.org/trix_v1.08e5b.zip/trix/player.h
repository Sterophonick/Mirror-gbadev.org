/////////////////////////////////////////////////////////////////////////////
//
// Player
// Rich Heasman June 2002
//
/////////////////////////////////////////////////////////////////////////////

//-------------------------------------------------------------------------

void	Player_Init(void);
void	Player_Update(void);
void	Player_Control(void);
void	Player_FuseUpdate(int nDX, int nDY);
void	Player_Render(void);
void	Player_Begin(void);
void	Player_Start(int nLevel);
void	Player_Continue(void);
void	Player_RemoveLine(int uFillColour);
void	Player_Fill(int nX, int nY, int nDX, int nDY);
void	Player_FindBackground(int *pX, int *pY, int nDX, int nDY);
int		Player_TestRegion(int nX, int nY);
BOOL	Player_Alive(void);
void	Player_KillRequest(void);
void	Player_Kill(void);
BOOL	Player_AtPosition(int nX, int nY);
BOOL	Player_LevelComplete(void);
int		Player_LivesGet(void);
void	Player_AttractStart(void);
BOOL	Player_Killable(void);
void	Player_ScoreAdd(int nScore);
void	Player_CompleteScore(void);

//-------------------------------------------------------------------------
