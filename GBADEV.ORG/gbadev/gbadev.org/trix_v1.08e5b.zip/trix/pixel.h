//------------------------------------------------------------------------------------

// pixel ops on a tile based background
// Rich Heasman May 2002

//------------------------------------------------------------------------------------

#include	"gba.h"

//------------------------------------------------------------------------------------

void	Pixel_Init(uint uScreenBase, uint uTileBase);
void	Pixel_SetPen(uint uColour);
void	Pixel_Plot(int nX, int nY);
void	Pixel_PlotXOR(int nX, int nY);
uint	Pixel_Get(int nX, int nY);
void	Pixel_Draw(int nX0, int nY0, int nX1, int nY1);
void	Pixel_DrawXOR(int nX0, int nY0, int nX1, int nY1);
void	Pixel_TestQix(int nX0, int nY0, int nX1, int nY1, BOOL *pCrossedLine, BOOL *pCrossedFill);
void	Pixel_Rectangle(int nX0, int nY0, int nX1, int nY1);
void	Pixel_ScreenClear(void);
uint	Pixel_Fill(u32 *pFuncAddr, int nX0, int nY0) CODE_IN_IWRAM;
uint	Pixel_FilledGet(void);

//------------------------------------------------------------------------------------
