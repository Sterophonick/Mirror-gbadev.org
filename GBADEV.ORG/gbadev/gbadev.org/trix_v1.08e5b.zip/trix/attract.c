/////////////////////////////////////////////////////////////////////////////
//
// Attract
// Rich Heasman July 2002
//
/////////////////////////////////////////////////////////////////////////////

#include 	"gba.h"
#include 	"attract.h"

//-------------------------------------------------------------------------

typedef struct
{
	int	nFire;
	int	nDX;
	int	nDY;
	int	nCount;
} ATTRACT_CONTROL_TYPE;

//-------------------------------------------------------------------------

static	BOOL  					boAttractActive;
static	int	  					nAttractIndex;
static	int	  					nAttractCount;
static	ATTRACT_CONTROL_TYPE	AttractControl;

//-------------------------------------------------------------------------

static	ATTRACT_CONTROL_TYPE 	pAttractData[] = {
	{0, 0, 0, 300},
	{0, -1, 0, 50},
	{1, 0, -1, 1},
	{0, 0, -1, 79},
	{0, -1, 0, 20},
	{0, 0, -1, 5},
	{0, 1, 0, 45},
	{0, 0, 1, 5},
	{0, -1, 0, 20},
	{0, 0, 1, 80},
	{0, 0, 0, 50},

	{0, 1, 0, 5},
	{1, 0, -1, 1},
	{0, 0, -1, 49},
	{0, 1, 0, 30},
	{0, 0, 1, 5},
	{0, -1, 0, 25},
	{0, 0, 1, 45},
	{0, 0, 0, 50},

	{0, 1, 0, 30},
	{1, 0, -1, 1},
	{0, 0, -1, 49},
	{0, 1, 0, 5},
	{0, 0, 1, 50},
	{0, 0, 0, 50},

	{0, 1, 0, 5},
	{1, 1, -1, 2},
	{0, 1, -1, 48},
	{0, -1, -1, 50},
	{0, 1, 0, 5},
	{0, 1, 1, 44},
	{0, 1, -1, 44},
	{0, 1, 0, 6},
	{0, -1, 1, 52},
	{0, 1, 1, 44},
	{0, -1, 0, 5},
	{0, -1, -1, 38},
	{0, -1, 1, 42},

	{0, 0, 0, 0},
};

#define	ATTRACT_CONTROL_LENGTH		(sizeof(pAttractData)/sizeof(pAttractData[0]))

//-------------------------------------------------------------------------

BOOL	Attract_Active(void)
{
	return(boAttractActive);
}	

//-------------------------------------------------------------------------

void	Attract_Start(void)
{
	boAttractActive = TRUE;
	nAttractIndex = 0;
	nAttractCount = 0;
}	

//-------------------------------------------------------------------------

void	Attract_Stop(void)
{
	boAttractActive = FALSE;
}	

//-------------------------------------------------------------------------

void	Attract_ControlsGet(int *pFire, int *pDX, int *pDY)
{
	if (nAttractCount == 0)
	{
		AttractControl = pAttractData[nAttractIndex];
		nAttractCount = pAttractData[nAttractIndex].nCount;
		if (nAttractIndex < ATTRACT_CONTROL_LENGTH)
		{
			nAttractIndex ++;
		}
	}

	*pFire = AttractControl.nFire;
	*pDX = AttractControl.nDX;
	*pDY = AttractControl.nDY;

	if (*pDX != 0 && *pDY != 0)
	{
		if (nAttractCount & 1)
		{
			*pDX = 0;
		}
		else
		{
			*pDY = 0;
		}
	}

	if (nAttractCount>0)
	{
		nAttractCount--;
	}
}	

//-------------------------------------------------------------------------
