//------------------------------------------------------------------------------------

// background
// Rich Heasman May 2002

//------------------------------------------------------------------------------------

#include 	"gba.h"  
#include 	"background.h"

#include 	"gfx.h"
#include 	"gfxdata1.h"
#include 	"palette.h"
#include	"string.h"
#include	"mem.h"
#include	"dma.h"
#include	"pixel.h"

//------------------------------------------------------------------------------------

static BACKGROUND_TYPE	Background_Info[BACKGROUND_MAX];

static const uint 	uBackground_MapLength[4] = { 1024, 2048, 2048, 4096 };

//------------------------------------------------------------------------------------

void	Background_Init(void)
{
	Mem_Set((u32 *) MEM_BG, 0x00, MEM_BG_SIZE);			// clear background memory
	Background_LoadVram();

	// display

	Background_Info[BACKGROUND_BITMAP].uPriority = 3;
	Background_Info[BACKGROUND_BITMAP].uCbb = 0;
	Background_Info[BACKGROUND_BITMAP].uSbbBase = 23;
	Background_Info[BACKGROUND_BITMAP].uColmode = 1;
	Background_Info[BACKGROUND_BITMAP].uMapsize = BACKGROUND_256X256;
	Background_Setup(BACKGROUND_BITMAP);

	Pixel_Init(Background_Info[BACKGROUND_BITMAP].uSbbBase, 3);

	// text layer

	Background_Info[BACKGROUND_TEXT].uPriority = 0;
	Background_Info[BACKGROUND_TEXT].uCbb = 0;
	Background_Info[BACKGROUND_TEXT].uSbbBase = 25;
	Background_Info[BACKGROUND_TEXT].uColmode = 1;
	Background_Info[BACKGROUND_TEXT].uMapsize = BACKGROUND_256X256;
	Background_Setup(BACKGROUND_TEXT);
	Background_FlipBufferWrite(BACKGROUND_TEXT);		 	// get text buffers out of sync

	// display layer 1

	Background_Info[BACKGROUND_DISPLAY].uPriority = 1;
	Background_Info[BACKGROUND_DISPLAY].uCbb = 0;
	Background_Info[BACKGROUND_DISPLAY].uSbbBase = 27;
	Background_Info[BACKGROUND_DISPLAY].uColmode = 1;
	Background_Info[BACKGROUND_DISPLAY].uMapsize = BACKGROUND_256X256;
	Background_Setup(BACKGROUND_DISPLAY);
	Background_FlipBufferWrite(BACKGROUND_DISPLAY); 	 	// get text buffers out of sync
}

//------------------------------------------------------------------------------------

void 	Background_Setup(uint uBackground)
{
	BACKGROUND_TYPE	*pBg;

	pBg = &Background_Info[uBackground];

	pBg->uActive = 1;
	pBg->uMapLength = uBackground_MapLength[pBg->uMapsize];

	pBg->uBufferView = 0;
	pBg->uBufferWrite = 0;
	pBg->uSbb =	pBg->uSbbBase;
	pBg->boFlipView = FALSE;

	switch (uBackground)
	{
		case 0 : GfxControl.uEnableBG0 = 1; break;
		case 1 : GfxControl.uEnableBG1 = 1; break;
		case 2 : GfxControl.uEnableBG2 = 1; break;
		case 3 : GfxControl.uEnableBG3 = 1; break;
	}

	R_BGXCNT(uBackground) = *(u16 *) pBg;
}

//------------------------------------------------------------------------------------ 

void	Background_Update(uint uBackground)
{
	BACKGROUND_TYPE	*pBg;
	uint		uSbb;

	pBg = &Background_Info[uBackground];

	R_BGXSCRLX(uBackground) = pBg->nScrollX;
	R_BGXSCRLY(uBackground) = pBg->nScrollY;

	if (pBg->boFlipView)
	{
	    pBg->uBufferView = 1 - pBg->uBufferView;
		uSbb = pBg->uSbbBase + (pBg->uMapLength>>10) * pBg->uBufferView;
		pBg->boFlipView = FALSE;
		R_BGXCNT(uBackground) = *(u16 *) pBg;
	}
}

//------------------------------------------------------------------------------------ 

void 	Background_FlipBufferWrite(uint uBackground)
{
	BACKGROUND_TYPE	*pBg;

	pBg = &Background_Info[uBackground];

    pBg->uBufferWrite = 1 - pBg->uBufferWrite;
	pBg->uSbb = pBg->uSbbBase + (pBg->uMapLength>>10) * pBg->uBufferWrite;
}

//------------------------------------------------------------------------------------ 

void 	Background_FlipBufferView(uint uBackground)
{
	BACKGROUND_TYPE	*pBg;

	pBg = &Background_Info[uBackground];
	pBg->boFlipView = TRUE;
}

//------------------------------------------------------------------------------------ 

void	Background_SetAll(uint uBackground, u16 nTileIndex)
{
	BACKGROUND_TYPE	*pBg;
	uint 		uCount;
	u16			*pDest;
	u16			nTile;

	pBg = &Background_Info[uBackground];

	nTile = Background_TileFromGraphic(nTileIndex);
	pDest = (u16 *) MEM_SBB(pBg->uSbb);
	uCount = (pBg->uMapLength);
	while (uCount > 0)
	{
		*pDest++ = (u16) nTile;
		uCount--;
	}
}

//------------------------------------------------------------------------------------ 

void 	Background_ScrollSet(uint uBackground, int nX, int nY)
{
	BACKGROUND_TYPE	*pBg;
	
	pBg = &Background_Info[uBackground];
	pBg->nScrollX = nX;
	pBg->nScrollY = nY;
}
	
//------------------------------------------------------------------------------------ 

void		Background_SetScreen(uint uBackground, u16 nTileIndex)
{
	BACKGROUND_TYPE	*pBg;
	uint 		uCount;
	u32			*pDest;
	u16			nTile;
	u32			nTileComposite;

	pBg = &Background_Info[uBackground];

	nTile = Background_TileFromGraphic(nTileIndex);
	pDest = (u32 *) MEM_SBB(pBg->uSbb);
	uCount = ((GFX_TILE_MAP_WIDTH * GFX_SCREEN_TILE_HEIGHT) / 2);
	nTileComposite = nTile + (nTile << 16);
	while (uCount > 0)
	{
		*pDest++ = nTileComposite;
		uCount--;
	}
}

//------------------------------------------------------------------------------------ 

void		Background_ScreenClear(uint uBackground)		
{						    
	BACKGROUND_TYPE	*pBg;
	uint 		uCount;
	u32			nTileComposite;
	u32			*pDest;
	DMA_TYPE	Dma;

	pBg = &Background_Info[uBackground];
	uCount = (GFX_TILE_MAP_WIDTH * GFX_SCREEN_TILE_HEIGHT) / 2;
	nTileComposite = 0 + (0 << 16);		// clear 2 entries each write
	pDest = (u32 *) MEM_SBB(pBg->uSbb);

	Dma.uSrc = (uint) &nTileComposite;
	Dma.uDest = (uint) pDest;
	Dma.uCount = uCount;
	Dma.uDestInc = DMA_INC;
	Dma.uSrcInc = DMA_LEAVE;
	Dma.uSize = DMA_32_BIT;
	Dma.uMode = DMA_NOW;
	Dma.uRepeat = 0;
	Dma.uInterrupt = 0;
	Dma.uEnable = 1;
	Dma_Set(3,&Dma);
}	

//------------------------------------------------------------------------------------ 

u16		*Background_SbbPtr(uint uBackground)
{
	BACKGROUND_TYPE	*pBg;
	u16	   		*pDest;
	
	pBg = &Background_Info[uBackground];
	pDest = (u16 *) MEM_SBB(pBg->uSbb);

	return(pDest);
}

//------------------------------------------------------------------------------------ 

void	Background_LoadVram(void)
{
    Mem_Copy((u32 *) MEM_PAL_BG, (u32 *) gfxdata1_Palette, GFXDATA1_PALETTE_SIZE);
	Palette_Copy( COLOUR_BACKGROUND, COLOUR_BLACK);
    Mem_Copy((u32 *) MEM_CBB(0), (u32 *) gfxdata1_Tiles, GFXDATA1_TILE_SIZE);
}

//------------------------------------------------------------------------------------ 

u16	 	Background_TileFromGraphic(u16 nGraphic)
{
	return(gfxdata1_Map[nGraphic]);
}

//------------------------------------------------------------------------------------ 

void	Background_Font1Print(int nXCo, int nYCo, char *szMessage)
{
	BACKGROUND_TYPE	*pBg;
	u8				*pSrc;
	u16				*pDest;
	u16				uGfxIndex;

	pBg = &Background_Info[BACKGROUND_TEXT];

	pDest = (u16 *) MEM_SBB(pBg->uSbb) + (nYCo<<5) + nXCo;
	pSrc = szMessage;
	while (*pSrc != STRING_TERMINATOR)
	{
		uGfxIndex = (*pSrc) - GFX_FONT_1_START_CHAR + GFX_FONT_1;
		*pDest++ = gfxdata1_Map[uGfxIndex];
		pSrc++;
	}
}

//------------------------------------------------------------------------------------ 

void	Background_Print(int nBackground, int nXCo, int nYCo, char *szMessage)
{
	BACKGROUND_TYPE	*pBg;
	u8				*pSrc;
	u16				*pDest;
	u16				uGfxIndex;

	pBg = &Background_Info[nBackground];

	pDest = (u16 *) MEM_SBB(pBg->uSbb) + (nYCo<<5) + nXCo;
	pSrc = szMessage;
	while (*pSrc != STRING_TERMINATOR)
	{
		uGfxIndex = (*pSrc) - GFX_FONT_1_START_CHAR + GFX_FONT_1;
		*pDest++ = gfxdata1_Map[uGfxIndex];
		pSrc++;
	}
}

//------------------------------------------------------------------------------------ 
