//------------------------------------------------------------------------

// palette
// Rich Heasman May 2002

//------------------------------------------------------------------------

#include	"gba.h"

//-----------------------------------------------------------------------

// colours for palette

enum
{
	COLOUR_BACKGROUND,
	COLOUR_BLACK,
	COLOUR_DARK_GREEN,		
	COLOUR_DARK_CYAN,		
	COLOUR_DARK_RED,			
	COLOUR_DARK_PURPLE,		
	COLOUR_BROWN,			
	COLOUR_GREY,				
	COLOUR_DARK_GREY,		
	COLOUR_BLUE,	 			
	COLOUR_GREEN, 			
	COLOUR_CYAN,				
	COLOUR_RED,				
	COLOUR_PURPLE,			
	COLOUR_ORANGE,			
	COLOUR_WHITE,			
	COLOUR_DARK_BLUE,		
	COLOUR_YELLOW,			

	COLOUR_PLAYER_LEFT,
	COLOUR_PLAYER_RIGHT,
	COLOUR_PLAYER_UP,
	COLOUR_PLAYER_DOWN,

	COLOUR_BEHIND = 32,
	COLOUR_BEHIND_1,
	COLOUR_BEHIND_2,

	COLOUR_FILL = 64,
	COLOUR_LINE,
	COLOUR_BOX_1,
	COLOUR_BOX_2,

	COLOUR_BAD = 128
};

//-----------------------------------------------------------------------

void	Palette_Init(void);
void	Palette_Start(int nLevel);
void	Palette_Update(void);
void	Palette_Render(void);
void	Palette_Copy(int nDest,int nSrc);

//-----------------------------------------------------------------------

