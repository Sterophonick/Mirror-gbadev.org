/////////////////////////////////////////////////////////////////////////////
//
// Qix
// Rich Heasman July 2002
//
/////////////////////////////////////////////////////////////////////////////

//-------------------------------------------------------------------------

#include 	"gba.h"
#include 	"qix.h"

#include 	"gfx.h"
#include 	"pixel.h"
#include 	"palette.h"
#include 	"debug.h"
#include 	"rnd.h"
#include 	"player.h"

//-------------------------------------------------------------------------

#define	QIX_MAX				20
#define	QIX_TRAILS			10
#define	QIX_NOT_USED		-1
#define	QIX_STUCK_COUNT		5
#define	QIX_LEVELS			15

enum
{
	QIX_DEAD,
	QIX_INIT,
	QIX_REDIRECT,
	QIX_ALIVE
};

typedef struct
{
	int			nType;
	int			nX0[QIX_TRAILS];
	int			nY0[QIX_TRAILS];
	int			nDX0;
	int			nDY0;
	int			nX1[QIX_TRAILS];
	int			nY1[QIX_TRAILS];
	int			nDX1;
	int			nDY1;

	int			nUpdateLength;
	int			nMaxLength;
	int			nMaxSpeed;
	int			nRedirectChance;

	BOOL		boRender;
	int			nIndex;
	int			nUpdateCount;
	int			nStuckCount;
} QIX_TYPE;

static	int			nQixActive;
static	QIX_TYPE	Qix[QIX_MAX];

typedef struct
{
	int			nQixs;
	int			nUpdateLength;
	int			nMaxLength;
	int			nMaxSpeed;
	int			nRedirectChance;
} QIX_LEVEL_TYPE;

//-------------------------------------------------------------------------

void	Qix_Init(void)
{
	Qix_Clear();
}	

//-------------------------------------------------------------------------

void	Qix_Update(void)
{
	int			nQix;
	QIX_TYPE	*pQix;
	int			nX0;
	int			nY0;
	int			nX1;
	int			nY1;
	int			nNX0;
	int			nNY0;
	int			nNX1;
	int			nNY1;
	int			nDX;
	int			nDY;
	int			nTrails;
	int			nSpeed;
	BOOL		boCrossedLine;
	BOOL		boCrossedFill;
	BOOL		boQixFatal;

	boQixFatal = Player_Killable();
	for (nQix = 0; nQix < nQixActive; nQix++)
	{
		pQix = &Qix[nQix];
		switch (pQix->nType)
		{
			case QIX_DEAD :
			{
				break;
			}
			case QIX_INIT :
			{
				for (nTrails = 0; nTrails < QIX_TRAILS; nTrails++)
				{
					pQix->nX0[nTrails] = QIX_NOT_USED;
				}
				pQix->nIndex = 0;
				pQix->nUpdateCount = 0;
				pQix->boRender = FALSE;

				pQix->nX0[pQix->nIndex] = GFX_PLAY_X0 + Rnd(GFX_PLAY_WIDTH-2) + 1;
				pQix->nY0[pQix->nIndex] = GFX_PLAY_Y0 + Rnd(GFX_PLAY_HEIGHT-2) + 1;
				pQix->nX1[pQix->nIndex] = pQix->nX0[pQix->nIndex];
				pQix->nY1[pQix->nIndex] = pQix->nY0[pQix->nIndex];
				pQix->nType = QIX_REDIRECT;
//				break;						// fall through on purpose
			}
			case QIX_REDIRECT :
			{
				nSpeed = pQix->nMaxSpeed;
				pQix->nDX0 = (1 + Rnd(nSpeed)) * (Rnd(2)*2-1);
				pQix->nDY0 = (1 + Rnd(nSpeed)) * (Rnd(2)*2-1);
				pQix->nDX1 = (1 + Rnd(nSpeed)) * (Rnd(2)*2-1);
				pQix->nDY1 = (1 + Rnd(nSpeed)) * (Rnd(2)*2-1);
				pQix->nType = QIX_ALIVE;
//				break;						// fall through on purpose
			}
			case QIX_ALIVE :
			{
				pQix->nUpdateCount++;
				if (pQix->nUpdateCount >= pQix->nUpdateLength)
				{
					pQix->nUpdateCount = 0;
					pQix->boRender = TRUE;

					nX0 = pQix->nX0[pQix->nIndex];
					nY0 = pQix->nY0[pQix->nIndex];
					nX1 = pQix->nX1[pQix->nIndex];
					nY1 = pQix->nY1[pQix->nIndex];

					nNX0 = nX0 + pQix->nDX0;
					nNY0 = nY0 + pQix->nDY0;
					nNX1 = nX1 + pQix->nDX1;
					nNY1 = nY1 + pQix->nDY1;

					if (nNX0 <= GFX_PLAY_X0)  pQix->nDX0 = -pQix->nDX0;
					if (nNX0 >= GFX_PLAY_X1)  pQix->nDX0 = -pQix->nDX0;
					if (nNY0 <= GFX_PLAY_Y0)  pQix->nDY0 = -pQix->nDY0;
					if (nNY0 >= GFX_PLAY_Y1)  pQix->nDY0 = -pQix->nDY0;
					if (nNX1 <= GFX_PLAY_X0)  pQix->nDX1 = -pQix->nDX1;
					if (nNX1 >= GFX_PLAY_X1)  pQix->nDX1 = -pQix->nDX1;
					if (nNY1 <= GFX_PLAY_Y0)  pQix->nDY1 = -pQix->nDY1;
					if (nNY1 >= GFX_PLAY_Y1)  pQix->nDY1 = -pQix->nDY1;

					nNX0 = nX0 + pQix->nDX0;
					nNY0 = nY0 + pQix->nDY0;
					nNX1 = nX1 + pQix->nDX1;
					nNY1 = nY1 + pQix->nDY1;

					Pixel_TestQix(nNX0, nNY0, nX0, nY0, &boCrossedLine, &boCrossedFill);
					if (boCrossedFill || (!boQixFatal && boCrossedLine))
					{
						nNX0 = nX0;
						nNY0 = nY0;
						pQix->nType = QIX_REDIRECT;
					}
					Pixel_TestQix(nNX1, nNY1, nX1, nY1, &boCrossedLine, &boCrossedFill);
					if (boCrossedFill || (!boQixFatal && boCrossedLine))
					{
						nNX1 = nX1;
						nNY1 = nY1;
						pQix->nType = QIX_REDIRECT;
					}

					nDX = abs(nNX0 - nNX1);
					nDY = abs(nNY0 - nNY1);

					if (nDX > pQix->nMaxLength) 
					{
						nNX0 = nX0;
						nNX1 = nX1;
						pQix->nType = QIX_REDIRECT;
					}
					if (nDY > pQix->nMaxLength) 
					{
						nNY0 = nY0;
						nNY1 = nY1;
						pQix->nType = QIX_REDIRECT;
					}

					Pixel_TestQix(nNX0, nNY0, nNX1, nNY1, &boCrossedLine, &boCrossedFill);
					if (boCrossedFill || (!boQixFatal && boCrossedLine))
					{
						nNX0 = nX0;
						nNX1 = nX1;
						nNY0 = nY0;
						nNY1 = nY1;
						pQix->nType = QIX_REDIRECT;
						pQix->nStuckCount++;
						if (pQix->nStuckCount >= QIX_STUCK_COUNT)
						{
							nNX0 = (nNX0 + nNX1)/2;
							nNY0 = (nNY0 + nNY1)/2;
							nNX1 = nNX0;
							nNY1 = nNY0;
						}
					}
					else
					{
						pQix->nStuckCount = 0;
					}

					if (Rnd(256) < pQix->nRedirectChance)
					{
						pQix->nType = QIX_REDIRECT;
					}	

					if (boQixFatal)
					{
						if (boCrossedLine)
						{
							Player_KillRequest();
						}
					}
						
					pQix->nIndex++;
					if (pQix->nIndex >= QIX_TRAILS)
					{
						pQix->nIndex = 0;
					}

					pQix->nX0[pQix->nIndex] = nNX0;
					pQix->nY0[pQix->nIndex] = nNY0;
					pQix->nX1[pQix->nIndex] = nNX1;
					pQix->nY1[pQix->nIndex] = nNY1;

					break;
				}
			}
		}
	}
}					 




//-------------------------------------------------------------------------

void	Qix_Render(void)
{
	int			nQix;
	QIX_TYPE	*pQix;
	int			nX0;
	int			nY0;
	int			nX1;
	int			nY1;
	int			nPrevious;

	Pixel_SetPen(COLOUR_BAD);
	for (nQix = 0; nQix < nQixActive; nQix++)
	{
		pQix = &Qix[nQix];			 
		if ((pQix->nType == QIX_ALIVE || pQix->nType == QIX_REDIRECT) 		
		 && (pQix->boRender))
		{
			pQix->boRender = FALSE;
			nPrevious = pQix->nIndex + 1;
			if (nPrevious >= QIX_TRAILS)
			{
				nPrevious = 0;
			}
			nX0 = pQix->nX0[nPrevious];
			nY0 = pQix->nY0[nPrevious];
			nX1 = pQix->nX1[nPrevious];
			nY1 = pQix->nY1[nPrevious];
			if (nX0 != QIX_NOT_USED)
			{
				Pixel_DrawXOR(nX0, nY0, nX1, nY1);
			}

			nX0 = pQix->nX0[pQix->nIndex];
			nY0 = pQix->nY0[pQix->nIndex];
			nX1 = pQix->nX1[pQix->nIndex];
			nY1 = pQix->nY1[pQix->nIndex];

			Pixel_DrawXOR(nX0, nY0, nX1, nY1);
		}
	}
}	

//-------------------------------------------------------------------------

void	Qix_Clear(void)
{
	int	nQix;

	for (nQix = 0; nQix < QIX_MAX; nQix++)
	{
		Qix[nQix].nType = QIX_DEAD;
	}
}

//-------------------------------------------------------------------------

static	QIX_LEVEL_TYPE	Qix_LevelData[QIX_LEVELS + 1] = {
	{ 1,	1,	80,	2,	20},	//Level 0
	{ 0,	0,	0,	0,	0},		//Level 1
	{ 1,	2,	40,	2,	5},		//Level 2
	{ 0,	0,	0,	0,	0},		//Level 3
	{ 1,	1,	40,	2,	5},		//Level 4
	{ 1,	1,	80,	5,	5},		//Level 5
	{ 0,	0,	0,	0,	0},		//Level 6
	{ 1,	1,	45,	3,	5},		//Level 7
	{ 0,	0,	0,	0,	0},		//Level 8
	{ 1,	1,	50,	4,	5},		//Level 9
	{ 0,	0,	0,	0,	0},		//Level 10

	{ 2,	1,	30,	2,	5},		//Level 11
	{ 1,	1,	40,	3,	5},		//Level 12
	{ 2,	2, 150, 2,	5},		//Level 13
	{ 3,	1,	15, 2,	1},		//Level 14
	{ 8,	1,	10, 5,	5},		//Level 15 
};
	
void	Qix_Start(int nLevel)
{
	int				nQix;
	QIX_TYPE		*pQix;
	QIX_LEVEL_TYPE	*pLevelData;

	Qix_Clear();

	if (nLevel > 0)
	{
		nLevel = ((nLevel-1) % QIX_LEVELS) + 1;
	}
	pLevelData = &Qix_LevelData[nLevel];

	nQixActive = pLevelData->nQixs;

	for (nQix = 0; nQix < nQixActive; nQix++)
	{
		pQix = &Qix[nQix];			 
		pQix->nType = QIX_INIT;

		pQix->nUpdateLength = pLevelData->nUpdateLength;
		pQix->nMaxLength = pLevelData->nMaxLength;
		pQix->nMaxSpeed = pLevelData->nMaxSpeed;
		pQix->nRedirectChance = pLevelData->nRedirectChance;
	}
}	

//-------------------------------------------------------------------------

