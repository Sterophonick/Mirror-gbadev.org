//------------------------------------------------------------------------------------

// display
// Rich Heasman July 2002

//------------------------------------------------------------------------------------

#include 	"gba.h"
#include 	"display.h"

#include 	"string.h"
#include 	"background.h"
#include 	"button.h"
#include 	"timer.h"
#include 	"blend.h"
#include 	"attract.h"

//------------------------------------------------------------------------------------

#define		DISPLAY_FILLED_XCO	0
#define		DISPLAY_LEVEL_XCO	12
#define		DISPLAY_LIVES_XCO	23

static int			nDisplayPercentage;
static int 			nDisplayLives;
static int 			nDisplayLevel;
static int 			nDisplayScore;

static BOOL			boDisplayPercentage;
static BOOL			boDisplayLives;
static BOOL			boDisplayLevel;
static BOOL			boDisplayBonus;
static BOOL			boDisplayBlendingOut;

static uint			uDisplayTimer;
static const uint	uDisplayPercentageTimerLen = 20;
static const uint	uDisplayLevelTimerLen = 200;
static const uint	uDisplayLivesTimerLen = 100;

#define	DISPLAY_SCORE_BLANK		"000000"

//------------------------------------------------------------------------------------

void	Display_Init(void)
{
	boDisplayPercentage = FALSE;
	boDisplayLives = FALSE;
	boDisplayLevel = FALSE;
	Blend_TextOut();
}	

//------------------------------------------------------------------------------------

void	Display_Update(void)
{
	if (boDisplayBlendingOut)
	{
		if (Blend_Done())
		{
			boDisplayBlendingOut = FALSE;

			boDisplayPercentage = FALSE;
			boDisplayLevel = FALSE;
			boDisplayLives = FALSE;
		}
	}
	else
	{
		if (boDisplayPercentage || boDisplayLevel || boDisplayLives)
		{
			if (Timer_Mature(&uDisplayTimer))
			{
				Blend_TextOut();
				boDisplayBlendingOut = TRUE;
			}
		}
	}
}	

//------------------------------------------------------------------------------------

void	Display_Render(void)
{
	char	szMessage[STRING_LEN_MAX];
	char	szNumber[STRING_LEN_MAX];
	int		nBackground;
	int		nLives;
	int		nMessageLength;
	int		nNumberLength;

	if (!Attract_Active())
	{
		if (boDisplayPercentage || !boDisplayLevel)
		{
			String_FromInt(szMessage, nDisplayPercentage);
		  	String_Cat(szMessage, "%");
			nBackground = BACKGROUND_DISPLAY;
			Background_Print( nBackground, DISPLAY_FILLED_XCO+1,1, "Filled");
			Background_Print( nBackground, DISPLAY_FILLED_XCO+3,2, szMessage);
		}

		if (boDisplayLevel || (!boDisplayPercentage && !boDisplayLives))
		{
			String_FromInt(szMessage, nDisplayLevel);
			nBackground = BACKGROUND_DISPLAY;
			Background_Print( nBackground, DISPLAY_LEVEL_XCO+1,1, "Level");
			Background_Print( nBackground, DISPLAY_LEVEL_XCO+3,2, szMessage);

			if (boDisplayBonus)
			{
				Background_Print( nBackground, DISPLAY_LEVEL_XCO+1,8, "Bonus");
				Background_Print( nBackground, DISPLAY_LEVEL_XCO+1,9, "Round");
			}
		}
		if (!boDisplayLevel && !boDisplayPercentage)
		{
			String_FromInt(szNumber, nDisplayScore);
			String_Copy(szMessage, DISPLAY_SCORE_BLANK );
			nMessageLength = sizeof(DISPLAY_SCORE_BLANK) - 1;
			nNumberLength = String_Length(szNumber);
			String_Copy(szMessage + (nMessageLength - nNumberLength), szNumber);
			nBackground = BACKGROUND_DISPLAY;
			Background_Print( nBackground, DISPLAY_LEVEL_XCO+1,1, "Score");
			Background_Print( nBackground, DISPLAY_LEVEL_XCO  ,2, szMessage);
		}

		if (boDisplayLives || (!boDisplayPercentage && !boDisplayLevel))
		{
			nLives = nDisplayLives - 1;
			if (nLives < 0)
			{
				nLives = 0;
			}
			String_FromInt(szMessage, nLives);
			nBackground = BACKGROUND_DISPLAY;
			Background_Print( nBackground, DISPLAY_LIVES_XCO+1,1, "Lives");
			Background_Print( nBackground, DISPLAY_LIVES_XCO+3,2, szMessage);
		}
	}
}

//------------------------------------------------------------------------------------

void	Display_PercentageSet(int nPercentage)
{
	if (nDisplayPercentage != nPercentage && nPercentage != 0)
	{
		boDisplayPercentage = TRUE;
		boDisplayLives = FALSE;
		boDisplayLevel = FALSE;
	   	Timer_Set(&uDisplayTimer, uDisplayPercentageTimerLen);
		Blend_TextIn();
	}
	nDisplayPercentage = nPercentage;
}	

//------------------------------------------------------------------------------------

void	Display_LivesSet(int nLives)
{
	nDisplayLives = nLives;
	boDisplayLives = TRUE;
	boDisplayPercentage = FALSE;
	boDisplayLevel = FALSE;
   	Timer_Set(&uDisplayTimer, uDisplayLivesTimerLen);
	Blend_TextIn();
}	

//------------------------------------------------------------------------------------

void	Display_LevelSet(int nLevel)
{
	nDisplayLevel = nLevel;
	boDisplayLevel = TRUE;
	boDisplayPercentage = FALSE;
	boDisplayLives = FALSE;
   	Timer_Set(&uDisplayTimer, uDisplayLevelTimerLen);
	Blend_TextIn();
}	

//------------------------------------------------------------------------------------

void	Display_ScoreSet(int nScore)
{
	nDisplayScore = nScore;
}	

//------------------------------------------------------------------------------------

void	Display_BonusSet(BOOL boBonus)
{
	boDisplayBonus = boBonus;
}	

//------------------------------------------------------------------------------------




