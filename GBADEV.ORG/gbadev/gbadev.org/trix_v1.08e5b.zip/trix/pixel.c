//------------------------------------------------------------------------------------

// pixel ops on a tile based background, (almost mode 4 but allows multiple backgrounds)
// Rich Heasman May 2002

//------------------------------------------------------------------------------------
// thanks,
// Staringmonkey for Breshenham alg
// Patrick Melody for flood fill
//------------------------------------------------------------------------------------

#include	"gba.h"
#include	"pixel.h"

#include	"gfx.h"
#include	"palette.h"
#include	"button.h"
#include	"debug.h"
#include	"error.h"
#include	"vblank.h"
#include	"mem.h"

//------------------------------------------------------------------------------------

static u8	*pPixelScreen;
static uint	uPixelColour;
static uint	uPixelColourHigh;
static int 	nPixelsFilled;

static u8 	*pPixelDestX[GFX_SCREEN_PIXEL_WIDTH];
static u16	nPixelOffsetY[GFX_SCREEN_PIXEL_HEIGHT];


//------------------------------------------------------------------------------------

void	Pixel_Init(uint uScreenBase, uint uTileBase)
{						 
	uint	uSize;
	uint	uCount;
	u16		*pDest;
	u16		uTile;
	u8		*pDestX;
	int		nX;
	int		nY;
	int		nOffset;

	pPixelScreen = (u8 *) MEM_SBB(uTileBase);
	uSize = GFX_TILE_MAP_WIDTH * GFX_SCREEN_TILE_HEIGHT;
	pDest = (u16 *) MEM_SBB(uScreenBase);
	uTile = uTileBase * 0x800 / 64;
	for (uCount = 0; uCount < uSize ; uCount++)
	{
		*pDest++ = uTile++;
	}

	// prestore offsets for optimisation
	for (nX = 0; nX < GFX_SCREEN_PIXEL_WIDTH; nX++)
	{
		pDestX = pPixelScreen;
		pDestX += (nX & 6);
		pDestX += (nX >> 3) << 6;		    
		pPixelDestX[nX] = pDestX;
	}
	for (nY = 0; nY < GFX_SCREEN_PIXEL_HEIGHT; nY++)
	{
		nOffset = (nY & 7) << 3;
		nOffset += (nY >> 3) << 11;
		nPixelOffsetY[nY] = nOffset;
	}

	nPixelsFilled = 0;

	Pixel_SetPen(COLOUR_BACKGROUND);
	Pixel_ScreenClear();
}

//------------------------------------------------------------------------------------

void	Pixel_SetPen(uint uColour)
{
	uPixelColour = uColour;
	uPixelColourHigh = uColour << 8;
}	

//------------------------------------------------------------------------------------

void	Pixel_Plot(int nX, int nY)
{
	u8		*pDest;
	u16		uPrevious;

	pDest = pPixelScreen;

	pDest += (nX & 6);
	pDest += (nX >> 3) << 6;
	pDest += (nY & 7) << 3;
	pDest += (nY >> 3) << 11;

	uPrevious = *(u16 *) pDest;

	if (nX & 1)	
	{
		*(u16 *)pDest = (uPixelColour << 8) + (uPrevious & 0xFF);
	}
	else 
	{
		*(u16 *)pDest = (uPrevious & 0xFF00) + uPixelColour;
	}
}	
		    
//------------------------------------------------------------------------------------

void	Pixel_PlotXOR(int nX, int nY)
{
	u8		*pDest;
	u16		uPrevious;

	pDest = pPixelScreen;

	pDest += (nX & 6);
	pDest += (nX >> 3) << 6;
	pDest += (nY & 7) << 3;
	pDest += (nY >> 3) << 11;

	uPrevious = *(u16 *) pDest;

	if (nX & 1)
	{
		*(u16 *)pDest = uPrevious ^ uPixelColourHigh;
	}
	else 
	{
		*(u16 *)pDest = uPrevious ^ uPixelColour;
	}
}	

//------------------------------------------------------------------------------------

uint	Pixel_Get(int nX, int nY)
{
	u8		*pDest;
	u16		uPrevious;
	uint	uColour;

	pDest = pPixelScreen;

	pDest += (nX & 6);
	pDest += (nX >> 3) << 6;
	pDest += (nY & 7) << 3;
	pDest += (nY >> 3) << 11;

	uPrevious = *(u16 *) pDest;

	if (nX & 1)	
	{
		uColour = uPrevious >> 8;
	}
	else 
	{
		uColour = uPrevious & 0xFF;
	}

	return(uColour);
}	
		    
//------------------------------------------------------------------------------------

void	Pixel_Draw(int nX0, int nY0, int nX1, int nY1)
{
	int i, deltax, deltay, numpixels;
	int d, dinc1, dinc2;
	int x, xinc1, xinc2;
	int y, yinc1, yinc2;

	deltax = abs(nX1 - nX0);
	deltay = abs(nY1 - nY0);

	if(deltax >= deltay)
	{
		numpixels = deltax + 1;
		d = (2 * deltay) - deltax;
		dinc1 = deltay << 1;
		dinc2 = (deltay - deltax) << 1;
		xinc1 = 1;
		xinc2 = 1;
		yinc1 = 0;
		yinc2 = 1;
	}
	else
	{
		numpixels = deltay + 1;
		d = (2 * deltax) - deltay;
		dinc1 = deltax << 1;
		dinc2 = (deltax - deltay) << 1;
		xinc1 = 0;
		xinc2 = 1;
		yinc1 = 1;
		yinc2 = 1;
	}

	if(nX0 > nX1)
	{
		xinc1 = -xinc1;
		xinc2 = -xinc2;
	}
	if(nY0 > nY1)
	{
		yinc1 = -yinc1;
		yinc2 = -yinc2;
	}

	x = nX0;
	y = nY0;

	for(i = 1; i < numpixels; i++)
	{
		Pixel_Plot(x, y);

		if(d < 0)
		{
			d = d + dinc1;
			x = x + xinc1;
			y = y + yinc1;
		}
		else
		{
			d = d + dinc2;
			x = x + xinc2;
			y = y + yinc2;
		}
	}
}	

//------------------------------------------------------------------------------------

void	Pixel_DrawXOR(int nX0, int nY0, int nX1, int nY1)
{
	int i, deltax, deltay, numpixels;
	int d, dinc1, dinc2;
	int x, xinc1, xinc2;
	int y, yinc1, yinc2;

	deltax = abs(nX1 - nX0);
	deltay = abs(nY1 - nY0);

	if(deltax >= deltay)
	{
		numpixels = deltax + 1;
		d = (2 * deltay) - deltax;
		dinc1 = deltay << 1;
		dinc2 = (deltay - deltax) << 1;
		xinc1 = 1;
		xinc2 = 1;
		yinc1 = 0;
		yinc2 = 1;
	}
	else
	{
		numpixels = deltay + 1;
		d = (2 * deltax) - deltay;
		dinc1 = deltax << 1;
		dinc2 = (deltax - deltay) << 1;
		xinc1 = 0;
		xinc2 = 1;
		yinc1 = 1;
		yinc2 = 1;
	}

	if(nX0 > nX1)
	{
		xinc1 = -xinc1;
		xinc2 = -xinc2;
	}
	if(nY0 > nY1)
	{
		yinc1 = -yinc1;
		yinc2 = -yinc2;
	}

	x = nX0;
	y = nY0;

	for(i = 1; i < numpixels; i++)
	{
		Pixel_PlotXOR(x, y);

		if(d < 0)
		{
			d = d + dinc1;
			x = x + xinc1;
			y = y + yinc1;
		}
		else
		{
			d = d + dinc2;
			x = x + xinc2;
			y = y + yinc2;
		}
	}
}	


//------------------------------------------------------------------------------------

void	Pixel_TestQix(int nX0, int nY0, int nX1, int nY1, BOOL *pCrossedLine, BOOL *pCrossedFill)
{
	int 	i, deltax, deltay, numpixels;
	int 	d, dinc1, dinc2;
	int 	x, xinc1, xinc2;
	int 	y, yinc1, yinc2;
	int		nColour;

	deltax = abs(nX1 - nX0);
	deltay = abs(nY1 - nY0);

	if(deltax >= deltay)
	{
		numpixels = deltax + 1;
		d = (2 * deltay) - deltax;
		dinc1 = deltay << 1;
		dinc2 = (deltay - deltax) << 1;
		xinc1 = 1;
		xinc2 = 1;
		yinc1 = 0;
		yinc2 = 1;
	}
	else
	{
		numpixels = deltay + 1;
		d = (2 * deltax) - deltay;
		dinc1 = deltax << 1;
		dinc2 = (deltax - deltay) << 1;
		xinc1 = 0;
		xinc2 = 1;
		yinc1 = 1;
		yinc2 = 1;
	}

	if(nX0 > nX1)
	{
		xinc1 = -xinc1;
		xinc2 = -xinc2;
	}
	if(nY0 > nY1)
	{
		yinc1 = -yinc1;
		yinc2 = -yinc2;
	}

	x = nX0;
	y = nY0;

	*pCrossedLine = FALSE;
	*pCrossedFill = FALSE;

	for(i = 1; i < numpixels; i++)
	{
		nColour = Pixel_Get(x, y);
		if (nColour >= COLOUR_PLAYER_LEFT && nColour <= COLOUR_PLAYER_DOWN)
		{
			*pCrossedLine = TRUE;
		}
		if (nColour & COLOUR_FILL)
		{
			*pCrossedFill = TRUE;
		}

		if(d < 0)
		{
			d = d + dinc1;
			x = x + xinc1;
			y = y + yinc1;
		}
		else
		{
			d = d + dinc2;
			x = x + xinc2;
			y = y + yinc2;
		}
	}
}	

//------------------------------------------------------------------------------------

void	Pixel_Rectangle(int nX0, int nY0, int nX1, int nY1)
{
	int	nX;
	int	nY;

	for (nY = nY0; nY <= nY1; nY++)
	{
		for (nX = nX0; nX <= nX1; nX++)
		{
			Pixel_Plot(nX, nY);
		}
	}
}	

//------------------------------------------------------------------------------------

void	Pixel_ScreenClear(void)
{
	u32 	*pDest;
	uint	uSize;
	u8		uValue;

	pDest = (u32 *) pPixelScreen;
	uSize = GFX_TILE_MAP_WIDTH * 8 * GFX_SCREEN_PIXEL_HEIGHT;
	uValue = uPixelColour;
	Mem_Set(pDest, uValue, uSize);
}	

//------------------------------------------------------------------------------------
//
// Non-recursive flood fill
// Fills space with set colour, returns number of other colour found in region (i.e. qix pixels)
// Optimised and game specific version
//

#define	PIXEL_STACK_SIZE			32

uint 	Pixel_Fill(u32 *pFuncAddr, int nX0, int nY0)
{
	uint 	uColour1;
	uint 	uColour2;
	int 	nX;
	int 	nY;
	int 	nLeft;
	int 	nRight;
	int 	nLoop;
	int		nCount;
	int 	nOtherColour;
	u8		*pDest;
	u16		uPrevious;
	int 	PixelStack[PIXEL_STACK_SIZE];
	int 	nPixelStackIndex;

	nOtherColour = 0;
	nPixelStackIndex = 0;
	nPixelsFilled = 0;
 	uColour2 = 0;

	PixelStack[nPixelStackIndex++] = nX0;
	PixelStack[nPixelStackIndex++] = nY0;

	while (nPixelStackIndex > 0)
	{
		nY = PixelStack[--nPixelStackIndex];
		nX = PixelStack[--nPixelStackIndex];

		pDest = pPixelDestX[nX];
		pDest += nPixelOffsetY[nY];
		uPrevious = *(u16 *) pDest;
		if (nX & 1)		uColour1 = uPrevious >> 8;
		else 			uColour1 = uPrevious & 0xFF;
		uColour1 &= ~COLOUR_BAD;

		if (uColour1 != COLOUR_LINE)
		{
			nCount = nX;
			do {
				pDest = pPixelDestX[nCount];
				pDest += nPixelOffsetY[nY];
				uPrevious = *(u16 *) pDest;
				if (nCount & 1)	uColour1 = uPrevious >> 8;
				else 			uColour1 = uPrevious & 0xFF;

				if ((uColour1 & ~COLOUR_BAD) != COLOUR_LINE)
				{
					if (uColour1 & COLOUR_BAD)
					{
						nOtherColour++;
						if (nCount & 1)	*(u16 *)pDest = ((uPixelColour << 8) + (uPrevious & 0xFF)) ^ COLOUR_BAD << 8;
						else 			*(u16 *)pDest = ((uPrevious & 0xFF00) + uPixelColour) ^ COLOUR_BAD;
					}
					else
					{
						if (nCount & 1)	*(u16 *)pDest = (uPixelColour << 8) + (uPrevious & 0xFF);
						else 			*(u16 *)pDest = (uPrevious & 0xFF00) + uPixelColour;
					}
					nCount++;
					nPixelsFilled++;
				}

			} while ((uColour1 & ~COLOUR_BAD) != COLOUR_LINE);
			nRight = nCount - 1;

			nCount = nX - 1;
			do {
				pDest = pPixelDestX[nCount];
				pDest += nPixelOffsetY[nY];
				uPrevious = *(u16 *) pDest;
				if (nCount & 1)	uColour1 = uPrevious >> 8;
				else 			uColour1 = uPrevious & 0xFF;

				if ((uColour1 & ~COLOUR_BAD) != COLOUR_LINE)
				{
					if (uColour1 & COLOUR_BAD)
					{
						nOtherColour++;
						if (nCount & 1)	*(u16 *)pDest = ((uPixelColour << 8) + (uPrevious & 0xFF)) ^ COLOUR_BAD << 8;
						else 			*(u16 *)pDest = ((uPrevious & 0xFF00) + uPixelColour) ^ COLOUR_BAD;
					}
					else
					{
						if (nCount & 1)	*(u16 *)pDest = (uPixelColour << 8) + (uPrevious & 0xFF);
						else 			*(u16 *)pDest = (uPrevious & 0xFF00) + uPixelColour;
					}
					nCount--;
					nPixelsFilled++;
				}

			} while ((uColour1 & ~COLOUR_BAD) != COLOUR_LINE);
			nLeft = nCount + 1;

			if (nLeft != nRight) 
			{
				nY++;
				for (nLoop = nLeft + 1; nLoop <= nRight; nLoop++) 
				{
					pDest = pPixelDestX[nLoop - 1];
					pDest += nPixelOffsetY[nY];
					uPrevious = *(u16 *) pDest;
					if ((nLoop - 1) & 1)	uColour1 = uPrevious >> 8;
					else 					uColour1 = uPrevious & 0xFF;
					uColour1 &= ~COLOUR_BAD;

					pDest = pPixelDestX[nLoop];
					pDest += nPixelOffsetY[nY];
					uPrevious = *(u16 *) pDest;
					if (nLoop & 1)	uColour2 = uPrevious >> 8;
					else 			uColour2 = uPrevious & 0xFF;
					uColour2 &= ~COLOUR_BAD;

					if (uColour1 != COLOUR_LINE
					 && uColour1 != uPixelColour 
					 &&	uColour2 == COLOUR_LINE)
					{
						PixelStack[nPixelStackIndex++] = nLoop - 1;
						PixelStack[nPixelStackIndex++] = nY;
					}
				}
				if (uColour2 != COLOUR_LINE  
				 && uColour2 != uPixelColour)
				{
					PixelStack[nPixelStackIndex++] = nRight;
					PixelStack[nPixelStackIndex++] = nY;
				}

				nY -= 2;
				for (nLoop = nLeft + 1; nLoop <= nRight; nLoop++) 
				{
					pDest = pPixelDestX[nLoop - 1];
					pDest += nPixelOffsetY[nY];
					uPrevious = *(u16 *) pDest;
					if ((nLoop - 1) & 1)	uColour1 = uPrevious >> 8;
					else 					uColour1 = uPrevious & 0xFF;
					uColour1 &= ~COLOUR_BAD;

					pDest = pPixelDestX[nLoop];
					pDest += nPixelOffsetY[nY];
					uPrevious = *(u16 *) pDest;
					if (nLoop & 1)		uColour2 = uPrevious >> 8;
					else 				uColour2 = uPrevious & 0xFF;
					uColour2 &= ~COLOUR_BAD;

					if (uColour1 != COLOUR_LINE
					 && uColour1 != uPixelColour
					 && uColour2 == COLOUR_LINE)
					{
						PixelStack[nPixelStackIndex++] = nLoop - 1;
						PixelStack[nPixelStackIndex++] = nY;
					}
				}

				if (uColour2 != COLOUR_LINE
				 && uColour2 != uPixelColour)
				{
					PixelStack[nPixelStackIndex++] = nRight;
					PixelStack[nPixelStackIndex++] = nY;
				}
			} 
			else 
			{
				pDest = pPixelDestX[nLeft];
				pDest += nPixelOffsetY[nY + 1];
				uPrevious = *(u16 *) pDest;
				if (nLeft & 1)		uColour1 = uPrevious >> 8;
				else 				uColour1 = uPrevious & 0xFF;
				uColour1 &= ~COLOUR_BAD;

				pDest = pPixelDestX[nLeft];
				pDest += nPixelOffsetY[nY - 1];
				uPrevious = *(u16 *) pDest;
				if (nLeft & 1)		uColour2 = uPrevious >> 8;
				else 				uColour2 = uPrevious & 0xFF;
				uColour2 &= ~COLOUR_BAD;

				if (uColour1 != uPixelColour)
				{
					PixelStack[nPixelStackIndex++] = nLeft;
					PixelStack[nPixelStackIndex++] = nY + 1;
				}
				if (uColour2 != uPixelColour)
				{
					PixelStack[nPixelStackIndex++] = nLeft;
					PixelStack[nPixelStackIndex++] = nY - 1;
				}
			}
		}
	}

	return(nOtherColour);
}

//------------------------------------------------------------------------------------

uint	Pixel_FilledGet(void)
{
	return(nPixelsFilled);	
}	

//------------------------------------------------------------------------------------
//
// Non-recursive flood fill
// NON - OPTIMISED VERSION - OUT OF DATE -
//
//void 	Pixel_StackPush(int nX, int nY);
//void 	Pixel_StackPull(int *pX, int *pY);
//
//#define	PIXEL_STACK_SIZE			32
//#define	PIXEL_STACK_SIZE_SAFETY		8
//#define	PIXEL_STACK_CHECK_VALUE		0xFF
//
//int		PixelStack[PIXEL_STACK_SIZE+PIXEL_STACK_SIZE_SAFETY];
//int		nPixelStackIndex;
//
//uint 	nPixelStackIndexBiggest = 0;
//
////------------------------------------------------------------------------------------
//
//void 	Pixel_StackPush(int nX, int nY)
//{
//	PixelStack[nPixelStackIndex++] = nX;
//	PixelStack[nPixelStackIndex++] = nY;
//
//	if (nPixelStackIndex>nPixelStackIndexBiggest)
//	{
//		nPixelStackIndexBiggest = nPixelStackIndex;
//		Debug_Display(nPixelStackIndexBiggest);
//	}
//}	
//
////------------------------------------------------------------------------------------
//
//void 	Pixel_StackPull(int *pX, int *pY)
//{
//	*pY = PixelStack[--nPixelStackIndex];
//	*pX = PixelStack[--nPixelStackIndex];
//}	
//
////------------------------------------------------------------------------------------
//
//// Fills space with set colour
//
//void	Pixel_Fill(int nX0, int nY0)
//{
//	uint 	uColour1;
//	uint 	uColour2;
//	uint 	uColourBound;
//	int 	nX;
//	int 	nY;
//	int 	nLeft;
//	int 	nRight;
//	int 	nLoop;
//	int		nCount;
//	BOOL	boOtherColour;
//
//	boOtherColour = FALSE;
//	nPixelStackIndex = 0;
//	PixelStack[PIXEL_STACK_SIZE] = PIXEL_STACK_CHECK_VALUE;
//	uColourBound = COLOUR_LINE;
// 	uColour2 = 0;
//
//	Pixel_StackPush(nX0, nY0);
//
//	while (nPixelStackIndex > 0)
//	{
//		Pixel_StackPull(&nX, &nY);
//
//		if (Pixel_Get(nX, nY) != uColourBound) 
//		{
//			nCount = nX;
//			do {
//				uColour1 = Pixel_Get(nCount, nY);
//				if (uColour1 != uColourBound)
//				{
//					Pixel_Plot(nCount, nY);
//					nCount++;
//				}
//			} while (uColour1 != uColourBound);
//			nRight = nCount - 1;
//
//			nCount = nX - 1;
//			do {
//				uColour1 = Pixel_Get(nCount, nY);
//				if (uColour1 != uColourBound)
//				{
//					Pixel_Plot(nCount, nY);
//					nCount--;
//				}
//			} while (uColour1 != uColourBound);
//			nLeft = nCount + 1;
//
//			if (nLeft != nRight) 
//			{
//				nY++;
//				for (nLoop = nLeft + 1; nLoop <= nRight; nLoop++) 
//				{
//					uColour1 = Pixel_Get(nLoop - 1, nY);
//					uColour2 = Pixel_Get(nLoop, nY);
//					if (uColour1 != uColourBound 
//					 && uColour1 != uPixelColour 
//					 && uColour2 == uColourBound)
//					{
//						Pixel_StackPush(nLoop - 1, nY);
//					}
//				}
//				if (uColour2 != uColourBound 
//				 && uColour2 != uPixelColour)
//				{
//					Pixel_StackPush(nRight, nY);
//				}
//
//				nY -= 2;
//				for (nLoop = nLeft + 1; nLoop <= nRight; nLoop++) 
//				{
//					uColour1 = Pixel_Get(nLoop - 1, nY);
//					uColour2 = Pixel_Get(nLoop, nY);
//					if (uColour1 != uColourBound 
//					 && uColour1 != uPixelColour 
//					 && uColour2 == uColourBound)
//					{
//						Pixel_StackPush(nLoop - 1, nY);
//					}
//				}
//				if (uColour2 != uColourBound 
//				 && uColour2 != uPixelColour)
//				{
//					Pixel_StackPush(nRight, nY); 
//				}
//			} 
//			else 
//			{
//				uColour1 = Pixel_Get(nLeft, nY + 1);
//				uColour2 = Pixel_Get(nLeft, nY - 1);
//				if (uColour1 != uPixelColour)
//				{
//					Pixel_StackPush(nLeft, nY + 1);
//				}
//				if (uColour2 != uPixelColour)
//				{
//					Pixel_StackPush(nLeft, nY - 1);
//				}
//			}
//		}
//	}
//
//	if (PixelStack[PIXEL_STACK_SIZE] != PIXEL_STACK_CHECK_VALUE)
//	{
//		Error_Fatal("Pixel stack exhausted");
//	}
//}
//	
//------------------------------------------------------------------------------------
