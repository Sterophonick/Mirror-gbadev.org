
----
Trix
----

v1.0 - 26 July 2002 - First Version

by Rich Heasman (richardheasman AT hotmail.com)

This game is freeware

---------------------------

What? Get 75%
How? Dpad - Move; A - Start Draw, Hold A - Slow Draw

---------------------------

Thanks to:

Taito			: for Qix
Jeff Frohwein   : for MultiBoot, crt0, lnkscript, FAQ, b2x
Tubooboo        : for HAM (v1.40)
Forgotten       : for VisualBoyAdvance
Tom Happ        : for Cowbite spec
Markus          : for Gfx2Gba (v0.10)
Credo			: for Gbarm
Staringmonkey	: for pixel and sound examples
Patrick Melody 	: for flood fill
Dark Fader		: for sound examples
gbadev.org		: for various info

---------------------------





