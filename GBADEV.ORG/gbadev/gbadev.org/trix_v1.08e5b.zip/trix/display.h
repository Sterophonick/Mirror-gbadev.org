//------------------------------------------------------------------------------------

// display
// Rich Heasman July 2002

//------------------------------------------------------------------------------------

void	Display_Init(void);
void	Display_Update(void);
void	Display_Render(void);

void	Display_PercentageSet(int nPercentage);
void	Display_LivesSet(int nLives);
void	Display_LevelSet(int nLevel);
void	Display_ScoreSet(int nScore);
void	Display_BonusSet(BOOL boBonus);

//------------------------------------------------------------------------------------
