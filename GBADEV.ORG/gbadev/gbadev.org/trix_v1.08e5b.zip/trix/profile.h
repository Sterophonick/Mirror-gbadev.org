//------------------------------------------------------------------------------------

// profile
// Rich Heasman April 2002

//------------------------------------------------------------------------------------

void	Profile_Init(void);
void	Profile_Render(void);
void	Profile_Point(char *szMessage);
void	Profile_Mark(char *szMessage);
void	Profile_Hold(int nLength);

//------------------------------------------------------------------------------------
