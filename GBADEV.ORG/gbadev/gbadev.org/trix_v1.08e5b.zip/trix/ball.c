/////////////////////////////////////////////////////////////////////////////
//
// Ball
// Rich Heasman June 2002
//
/////////////////////////////////////////////////////////////////////////////

#include 	"gba.h"
#include 	"ball.h"

#include 	"sprite.h"
#include 	"gfx.h"
#include 	"gfxdata2.h"
#include 	"pixel.h"
#include 	"palette.h"
#include 	"debug.h"
#include 	"rnd.h"
#include 	"player.h"
#include 	"soundfx.h"
#include 	"attract.h"

//-------------------------------------------------------------------------

#define	BALL_MAX		20
#define	BALL_LEVELS		15

enum
{
	BALL_DEAD,
	BALL_INTERNAL,
	BALL_EXTERNAL
};

typedef struct
{
	int			nType;
	SPRITE_TYPE	*pSprite;
	int			nX;
	int			nY;
	int			nDX;
	int			nDY;
	int			nPreviousX;
	int			nPreviousY;
} BALL_TYPE;

static	int			nBallsActive;
static	BALL_TYPE	Ball[BALL_MAX];

typedef struct
{
	int		nInternal;
	int		nExternal;
} BALL_LEVEL_TYPE;

//-------------------------------------------------------------------------

void	Ball_Init(void)
{
	int	nBall;

	for (nBall = 0; nBall < BALL_MAX; nBall++)
	{
		Ball[nBall].nType = BALL_DEAD;
		Ball[nBall].pSprite = Sprite_Create(GFX_BALL_INTERNAL, 0, GFX_SCREEN_PIXEL_HEIGHT);
	}
}	

//-------------------------------------------------------------------------

void	Ball_Update(void)
{
	int			nBall;
	BALL_TYPE	*pBall;
	uint		uColour;
	BOOL		boKill;

	for (nBall = 0; nBall < nBallsActive; nBall++)
	{
		pBall = &Ball[nBall];
		boKill = FALSE;

		if (pBall->nType == BALL_EXTERNAL)
		{
			uColour	= Pixel_Get(pBall->nX + pBall->nDX, pBall->nY);
			if (uColour & COLOUR_FILL)
			{
		 		pBall->nDX = -pBall->nDX;
			}

			uColour	= Pixel_Get(pBall->nX, pBall->nY + pBall->nDY);
			if (uColour & COLOUR_FILL)
			{
		 		pBall->nDY = -pBall->nDY;
			}

			uColour	= Pixel_Get(pBall->nX + pBall->nDX, pBall->nY);
			if (!(uColour & COLOUR_FILL))
			{
				pBall->nX += pBall->nDX;
			}

			uColour	= Pixel_Get(pBall->nX, pBall->nY + pBall->nDY);
			if (!(uColour & COLOUR_FILL))
			{
				pBall->nY += pBall->nDY;
			}
		}
		else  // BALL_INTERNAL
		{
			uColour	= Pixel_Get(pBall->nX + pBall->nDX, pBall->nY);
			if (!(uColour & COLOUR_FILL))
			{
		 		pBall->nDX = -pBall->nDX;
			}

			uColour	= Pixel_Get(pBall->nX, pBall->nY + pBall->nDY);
			if (!(uColour & COLOUR_FILL))
			{
		 		pBall->nDY = -pBall->nDY;
			}

			uColour	= Pixel_Get(pBall->nX + pBall->nDX, pBall->nY);
			if (uColour & COLOUR_FILL)
			{
				pBall->nX += pBall->nDX;
			}

			uColour	= Pixel_Get(pBall->nX, pBall->nY + pBall->nDY);
			if (uColour & COLOUR_FILL)
			{
				pBall->nY += pBall->nDY;
			}
		}

		uColour	= Pixel_Get(pBall->nX, pBall->nY);
		if ((uColour == COLOUR_PLAYER_LEFT)
		 || (uColour == COLOUR_PLAYER_RIGHT)
		 || (uColour == COLOUR_PLAYER_UP)
		 || (uColour == COLOUR_PLAYER_DOWN))
		{
			boKill = TRUE;
		}

		if (Player_AtPosition(pBall->nX, pBall->nY))
		{
			boKill = TRUE;
		}

		if (boKill)
		{
			Player_KillRequest();
		}
	}
}					 

//-------------------------------------------------------------------------

void	Ball_Render(void)
{
	int			nBall;
	BALL_TYPE	*pBall;

	Pixel_SetPen(COLOUR_BAD);
	for (nBall = 0; nBall < nBallsActive; nBall++)
	{
		pBall = &Ball[nBall];
		if (pBall->nType != BALL_DEAD)
		{
			if (pBall->nPreviousX != -1)
			{
				Pixel_PlotXOR(pBall->nPreviousX, pBall->nPreviousY);
			}
			Pixel_PlotXOR(pBall->nX, pBall->nY);
			Sprite_PositionSet(pBall->pSprite, pBall->nX - GFX_BALL_WIDTH/2, pBall->nY - GFX_BALL_HEIGHT/2);

			pBall->nPreviousX = pBall->nX;
			pBall->nPreviousY = pBall->nY;
		}
	}
}	

//-------------------------------------------------------------------------

void	Ball_Clear(void)
{
	int				nBall;
	BALL_TYPE		*pBall;

	for (nBall = 0; nBall < BALL_MAX; nBall++)
	{
		pBall = &Ball[nBall];

		pBall->nType = BALL_DEAD;
		Sprite_PositionSet(pBall->pSprite, 0, GFX_SCREEN_PIXEL_HEIGHT);
	}
}	

//-------------------------------------------------------------------------

static	BALL_LEVEL_TYPE		Ball_LevelData[BALL_LEVELS + 1] = {
	{ 1,	1 },		//Level 0
	{ 0,	1 },		//Level 1
	{ 0,	0 },		//Level 2
	{ 1,	2 },		//Level 3
	{ 0, 	0 },		//Level 4
	{ 0,	0 },		//Level 5
	{ 2,	3 },		//Level 6
	{ 0,	0 }, 		//Level 7
	{ 3,	4 },		//Level 8
	{ 0,	0 },		//Level 9
	{ 1,	8 },		//Level 10

	{ 1,	0 },		//Level 11
	{ 1,	1 },		//Level 12
	{ 0,	0 },		//Level 13
	{ 1,	0 },		//Level 14
	{ 0,	0 },		//Level 15

	};
		
void	Ball_Start(int nLevel)
{
	int				nBall;
	BALL_TYPE		*pBall;
	BALL_LEVEL_TYPE	*pLevelData;
	int				nInternal;
	int				nExternal;

	if (nLevel > 0)
	{
		nLevel = ((nLevel-1) % BALL_LEVELS) + 1;
	}
	pLevelData = &Ball_LevelData[nLevel];
	nInternal = pLevelData->nInternal;
	nExternal = pLevelData->nExternal;

	Ball_Clear();

	nBallsActive = nInternal + nExternal;
	if (nBallsActive > BALL_MAX)
	{
		nBallsActive = BALL_MAX;
	}

	for (nBall = 0; nBall < nBallsActive; nBall++)
	{
		pBall = &Ball[nBall];

		if (nBall < nInternal)
		{
			pBall->nType = BALL_INTERNAL;
			Sprite_FrameSet(pBall->pSprite, GFX_BALL_INTERNAL);

			pBall->nX = GFX_PLAY_X0 + Rnd(GFX_PLAY_WIDTH-2) + 1;
			pBall->nY = GFX_PLAY_Y0 + Rnd(GFX_PLAY_HEIGHT-2) + 1;

			if (Rnd(2) == 0)
			{
				pBall->nX = GFX_PLAY_X0;
				if (Rnd(2) == 0)
				{
					pBall->nX = GFX_PLAY_X1;
				}
			}
			else
			{
				pBall->nY = GFX_PLAY_Y0;
				if (Rnd(2) == 0)
				{
					pBall->nY = GFX_PLAY_Y1;
				}
			}
		}
		else // External
		{
			pBall->nType = BALL_EXTERNAL;
			Sprite_FrameSet(pBall->pSprite, GFX_BALL_EXTERNAL);

			pBall->nX = GFX_PLAY_X0 + Rnd(GFX_PLAY_WIDTH-2) + 1;
			pBall->nY = GFX_PLAY_Y0 + Rnd(GFX_PLAY_HEIGHT-2) + 1;
		}

		pBall->nDX = Rnd(2) * 2 - 1;
		pBall->nDY = Rnd(2) * 2 - 1;
		pBall->nPreviousX = -1;
		pBall->nPreviousY = -1;
	}
}	

//-------------------------------------------------------------------------
