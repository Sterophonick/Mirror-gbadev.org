/////////////////////////////////////////////////////////////////////////////
//
// Fuse
// Rich Heasman June 2002
//
/////////////////////////////////////////////////////////////////////////////

#include 	"gba.h"
#include 	"fuse.h"

#include 	"sprite.h"
#include 	"gfx.h"
#include 	"gfxdata2.h"
#include 	"pixel.h"
#include 	"palette.h"
#include 	"debug.h"

//-------------------------------------------------------------------------

#define	FUSE_ENABLED		TRUE
//#define	FUSE_ENABLED		FALSE

static SPRITE_TYPE	*pFuseSprite;
static BOOL			boFuseActive;
static int			nFuseX;
static int			nFuseY;

//-------------------------------------------------------------------------

void	Fuse_Init(void)
{
	pFuseSprite = Sprite_Create(GFX_FUSE, 0, GFX_SCREEN_PIXEL_HEIGHT);
}

//-------------------------------------------------------------------------

void	Fuse_Update(void)
{
	uint	uColour;

	if (boFuseActive)
	{
		uColour	= Pixel_Get(nFuseX, nFuseY);
		if (uColour == COLOUR_PLAYER_LEFT) 	nFuseX += -1;
		if (uColour == COLOUR_PLAYER_RIGHT) nFuseX += 1;
		if (uColour == COLOUR_PLAYER_UP) 	nFuseY += -1;
		if (uColour == COLOUR_PLAYER_DOWN) 	nFuseY += 1;
	}
}	

//-------------------------------------------------------------------------

void	Fuse_Render(void)
{
	if (boFuseActive)
	{
		Sprite_PositionSet(pFuseSprite, nFuseX - GFX_FUSE_WIDTH/2, nFuseY - GFX_FUSE_HEIGHT/2);
	}
	else
	{
		Sprite_PositionSet(pFuseSprite, 0, GFX_SCREEN_PIXEL_HEIGHT);
	}
}

//-------------------------------------------------------------------------

void	Fuse_Stop(void)
{
	boFuseActive = FALSE;
}	

//-------------------------------------------------------------------------

void	Fuse_Start(int nX, int nY)
{
	if (FUSE_ENABLED)
	{
		if (!boFuseActive)
		{
			nFuseX = nX;
			nFuseY = nY;
			boFuseActive = TRUE;
		}
	}
}

//-------------------------------------------------------------------------

BOOL	Fuse_Collision(int nX, int nY)
{
	BOOL boCollision;

	boCollision = FALSE;
	if (boFuseActive && nX == nFuseX && nY == nFuseY)
	{
		boCollision = TRUE;
	}

	return(boCollision);
}	

//-------------------------------------------------------------------------

BOOL	Fuse_Active(void)
{
	return(boFuseActive);
}	

//-------------------------------------------------------------------------
