//------------------------------------------------------------------------

// debug
// Rich Heasman May 2002

//------------------------------------------------------------------------

#include	"gba.h"
#include	"debug.h"

#include	"background.h"
#include	"string.h"

#define	DEBUG_DISPLAY_MAX			20
#define	DEBUG_DISPLAY_STRING_LEN	10

typedef struct
{
	char	*szName;
	int		nValue;	
} DEBUG_TYPE;

static	DEBUG_TYPE	DebugDisplay[DEBUG_DISPLAY_MAX];
static	int			nDebugDisplay;

//------------------------------------------------------------------------

void	Debug_Init(void)
{
	nDebugDisplay = 0;
}	

//------------------------------------------------------------------------

void	Debug_Render(void)
{
	int		nDebug;
	int		nY;
	char	szMessage[STRING_LEN_MAX];

	nY = 19;
	for (nDebug = 0; nDebug < nDebugDisplay; nDebug++)
	{
		String_Copy(szMessage, DebugDisplay[nDebug].szName);
		szMessage[DEBUG_DISPLAY_STRING_LEN] = STRING_TERMINATOR;
		Background_Font1Print( 1, nY, szMessage);
		String_FromInt(szMessage, DebugDisplay[nDebug].nValue);
	    Background_Font1Print( DEBUG_DISPLAY_STRING_LEN + 2, nY, szMessage);
		nY--;
	}
}	

//------------------------------------------------------------------------

void	Debug_DisplayValueInt(char *szName, int nValue)
{
	int		nDebug;

	nDebug = 0;
	while (nDebug < nDebugDisplay && DebugDisplay[nDebug].szName != szName)
	{
		nDebug++;
	}

	if (nDebugDisplay < DEBUG_DISPLAY_MAX)
	{
		DebugDisplay[nDebug].szName = szName;
		DebugDisplay[nDebug].nValue = nValue;
		if (nDebug >= nDebugDisplay)
		{
			nDebugDisplay++;
		}
	}
}	

//-----------------------------------------------------------------------

