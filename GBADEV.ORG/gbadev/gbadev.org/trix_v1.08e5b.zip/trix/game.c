/////////////////////////////////////////////////////////////////////////////
//
// Game flow control
// Rich Heasman June 2002
//
/////////////////////////////////////////////////////////////////////////////

#include 	"gba.h"
#include 	"game.h"

#include 	"button.h"
#include 	"string.h"
#include 	"background.h"
#include 	"palette.h"
#include 	"pixel.h"
#include 	"gfx.h"
#include 	"fuse.h"
#include 	"ball.h"
#include 	"qix.h"
#include 	"player.h"
#include 	"debug.h"
#include 	"display.h"
#include 	"attract.h"
#include 	"rnd.h"
#include 	"timer.h"
#include 	"soundfx.h"

//-------------------------------------------------------------------------

enum
{
	GAME_INIT,
	GAME_WAIT_START,
	GAME_PLAYING_INIT,
	GAME_WAIT_NEXT,
	GAME_PLAY_DELAY,
	GAME_PLAYING,
	GAME_SUCCESS,
	GAME_OVER
};

//-------------------------------------------------------------------------

static	int			nGameStatus;
static	int			nGameLevel;

static	BOOL		boGamePressDisplay;
static	uint		uGamePressTimer;
static	const uint	uGamePressTimerLength = 40;
static	uint		uGameDelayTimer;
static	const uint	uGameDelayTimerLength = 100;

static	uint		uGameAttractTimer;
static	const uint	uGameAttractTimerLength = 60 * 60;
static	uint		uGameAttractQixTimer;
static	const uint	uGameAttractQixTimerLength = 60 * 28;
static	BOOL		boGameAttractQixStarted;

//-------------------------------------------------------------------------

void	Game_Init(void)
{
	Player_Init();
	Fuse_Init();
	Ball_Init();
	Qix_Init();
	Display_Init();

	nGameStatus = GAME_INIT;
}

//-------------------------------------------------------------------------

void	Game_Update(void)
{
	switch (nGameStatus)
	{
		case GAME_INIT :
		{
			Attract_Start();
			Game_ScreenStart();
			Pixel_SetPen(COLOUR_BAD);
			Pixel_Plot(GFX_PLAY_X0 + 1, GFX_PLAY_Y0 + 1);
			Ball_Clear();
			Qix_Clear();
			Player_Start(0);
			Palette_Start(0);
			Timer_Set(&uGamePressTimer, 0);
			boGamePressDisplay = FALSE;
			Timer_Set(&uGameAttractTimer, uGameAttractTimerLength);
			Timer_Set(&uGameAttractQixTimer, uGameAttractQixTimerLength);
			boGameAttractQixStarted = FALSE;
			nGameStatus= GAME_WAIT_START;
			break;
		}
		case GAME_WAIT_START :
		{
			Player_Update();
			Qix_Update();
			Ball_Update();
			Display_Update();
			if (Timer_Mature(&uGamePressTimer))
			{
				Timer_Set(&uGamePressTimer, uGamePressTimerLength);
				boGamePressDisplay = !boGamePressDisplay;
			}
			if (Timer_Mature(&uGameAttractTimer))
			{
				nGameStatus = GAME_INIT;
			}
			if (!boGameAttractQixStarted)
			{
				if (Timer_Mature(&uGameAttractQixTimer))
				{
					Qix_Start(0);
					Ball_Start(0);
					boGameAttractQixStarted = TRUE;
				}
			}
			if (Button_PressedDebounced(BUTTON_START))
			{
				Attract_Stop();
				nGameLevel = 1;
				Display_LevelSet(nGameLevel);
				Player_Begin();
				nGameStatus = GAME_PLAYING_INIT;
			}
			break;
		}
		case GAME_PLAYING_INIT :
		{
			Player_Start(nGameLevel);
			Ball_Start(nGameLevel);
			Qix_Start(nGameLevel);
			Palette_Start(nGameLevel);
			Display_LevelSet(nGameLevel);
			Fuse_Stop();
			Timer_Set(&uGameDelayTimer, uGameDelayTimerLength);
			SoundFX_Make(SOUNDFX_CHANNEL_A, SOUNDFX_NEW_LEVEL);
			nGameStatus = GAME_PLAY_DELAY;
			break;
		}
		case GAME_PLAY_DELAY :
		{
			if (Timer_Mature(&uGameDelayTimer))
			{
				nGameStatus = GAME_PLAYING;
			}
			break;
		}

		case GAME_WAIT_NEXT :
		{
			if (Button_PressedDebounced(BUTTON_START)
			 || Button_PressedDebounced(BUTTON_A))
			{
				Player_Continue();
				nGameStatus = GAME_PLAYING;
			}
			break;
		}
		case GAME_PLAYING :
		{
			Player_Update();
			Fuse_Update();
			Ball_Update();
			Qix_Update();
			Display_Update();

			if (!Player_Alive())
			{
				nGameStatus = GAME_WAIT_NEXT;
			}
			if (Player_LivesGet() == 0)
			{
				nGameStatus = GAME_OVER;
			}
			if (Player_LevelComplete())
			{
				Player_CompleteScore();
				SoundFX_Make(SOUNDFX_CHANNEL_A, SOUNDFX_DONE);
				nGameStatus = GAME_SUCCESS;
			}
			break;
		}
		case GAME_SUCCESS :
		{
			if (Button_PressedDebounced(BUTTON_START)
			 || Button_PressedDebounced(BUTTON_A))
			{
				nGameLevel++;
				nGameStatus = GAME_PLAYING_INIT;
			}
			break;
		}
		case GAME_OVER :
		{
			if (Button_PressedDebounced(BUTTON_START)
			 || Button_PressedDebounced(BUTTON_A))
			{
				nGameStatus = GAME_INIT;
			}
			break;
		}
	}
}

//-------------------------------------------------------------------------

void	Game_Render(void)
{		
	Player_Render();
	Fuse_Render();
	Ball_Render();
	Qix_Render();
	Display_Render();

	switch (nGameStatus)
	{
		case GAME_INIT :
		{
			break;
		}
		case GAME_WAIT_START :
		{
			if (boGamePressDisplay)
			{
			    Background_Font1Print( 5,5, "PRESS START TO PLAY");
			}
			break;
		}
		case GAME_PLAYING_INIT :
		{
			Game_ScreenStart();
			break;
		}
		case GAME_PLAYING :
		{
			break;
		}
		case GAME_SUCCESS :
		{
		    Background_Font1Print( 8,10, "LEVEL COMPLETE");
			break;
		}
		case GAME_OVER :
		{
		    Background_Font1Print( 10,10, "GAME OVER");
			break;
		}
	}
}	

//-------------------------------------------------------------------------

void	Game_ScreenStart(void)
{
	Pixel_SetPen(COLOUR_BEHIND_1);
	Pixel_ScreenClear();
	Pixel_SetPen(COLOUR_LINE);
	Pixel_Draw(GFX_PLAY_X0, GFX_PLAY_Y0, GFX_PLAY_X1, GFX_PLAY_Y0);
	Pixel_Draw(GFX_PLAY_X1, GFX_PLAY_Y0, GFX_PLAY_X1, GFX_PLAY_Y1);
	Pixel_Draw(GFX_PLAY_X1, GFX_PLAY_Y1, GFX_PLAY_X0, GFX_PLAY_Y1);
	Pixel_Draw(GFX_PLAY_X0, GFX_PLAY_Y1, GFX_PLAY_X0, GFX_PLAY_Y0);
}	

//-------------------------------------------------------------------------
