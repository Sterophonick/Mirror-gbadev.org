//------------------------------------------------------------------------------------

// Menu
// Rich Heasman April 2002

//------------------------------------------------------------------------------------

#include 	"gba.h"
#include 	"menu.h"

#include 	"vblank.h"
#include 	"button.h"
#include 	"game.h"
#include 	"interrupt.h"
#include	"background.h"
#include	"timer.h"

enum
{
	MENU_INIT,
	MENU_INFO_WAIT,
	MENU_INGAME
};

enum
{
	MENU_DEV_OFF,
	MENU_DEV_ON
};

enum
{
	MENU_DEV_RESET,					// to save the on/off switch�

	MENU_DEV_MAX
};

static uint			uMenuState;
static uint			uMenuDevState;
static uint			uMenuDevOption;

static uint			uMenuInfoTimer;
static const uint	uMenuInfoTimerLen 	= 180;

#define	MENU_VERSION_STRING	"v1.0 26 July 2002"

//------------------------------------------------------------------------------------

void	Menu_Init(void)
{
	uMenuDevOption = MENU_DEV_RESET;
	uMenuDevState = MENU_DEV_OFF;
	uMenuState = MENU_INIT;
}

//------------------------------------------------------------------------------------

void	Menu_Update(void)
{
    switch(uMenuState)
	{
		case MENU_INIT :
		{
		   	Timer_Set(&uMenuInfoTimer, uMenuInfoTimerLen);
			uMenuState = MENU_INFO_WAIT;
			break;
		}
		case MENU_INFO_WAIT :
		{
			if (Timer_Mature(&uMenuInfoTimer))
			{
				uMenuState = MENU_INGAME;
			}
			break;
		}
		case MENU_INGAME :
		{
			break;
		}
	}

    switch(uMenuDevState)
    {
    	case MENU_DEV_OFF:
    	{
			if (Button_PressedDebounced(BUTTON_SELECT))
			{
				uMenuDevState = MENU_DEV_ON;
			}
    		break;
    	}
    	case MENU_DEV_ON:
    	{
			if (Button_PressedDebounced(BUTTON_SELECT))
			{
				uMenuDevState = MENU_DEV_OFF;
			}
			if (Button_PressedDebounced(BUTTON_DOWN))
			{
				if (uMenuDevOption < MENU_DEV_MAX-1)
				{
					uMenuDevOption++;
				}
			} 
			if (Button_PressedDebounced(BUTTON_UP))
			{
				if (uMenuDevOption > 0)
				{
					uMenuDevOption--;
				}
			} 
			if (Button_PressedDebounced(BUTTON_A))
			{
				switch (uMenuDevOption)
				{
					case MENU_DEV_RESET:
					{
						Interrupt_HWReset();
						break;
					}
				}
			}
			break;
    	}
    }
}


//------------------------------------------------------------------------------------

void	Menu_Render(void)
{
    switch(uMenuState)
	{
		case MENU_INIT :
		{
			break;
		}
		case MENU_INFO_WAIT :
		{
		    Background_Font1Print( 1,15, "Trix" );
		    Background_Font1Print( 1,16, MENU_VERSION_STRING);
		    Background_Font1Print( 1,17, "By Rich Heasman");
		    Background_Font1Print( 1,18, "This game is freeware");
			break;	
		}
		case MENU_INGAME :
		{
			break;
		}
	}

    switch(uMenuDevState)
    {
    	case MENU_DEV_OFF:
    	{
    		break;
    	}
    	case MENU_DEV_ON:
    	{
		    Background_Font1Print( 9,7, 	"Development");
		    Background_Font1Print( 9,8, 	"-----------");
		    Background_Font1Print( 9,10, 	"HW Reset");

		    Background_Font1Print( 7, 10 + uMenuDevOption, ">");
    		break;
    	}
	}
}

//------------------------------------------------------------------------------------

