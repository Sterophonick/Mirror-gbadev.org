//------------------------------------------------------------------------

// error
// Rich Heasman June 2002

//------------------------------------------------------------------------

#include 	"gba.h"
#include	"error.h"

#include	"background.h"
#include	"gfx.h"

//------------------------------------------------------------------------

void	Error_Init(void)
{
}	

//-----------------------------------------------------------------------

void	Error_Fatal(char *szMessage)
{
    Background_Font1Print( 1,1, "FATAL ERROR");
    Background_Font1Print( 1,2, szMessage);
	Gfx_Update();

	while(TRUE);		// HALT
}	

//-----------------------------------------------------------------------
