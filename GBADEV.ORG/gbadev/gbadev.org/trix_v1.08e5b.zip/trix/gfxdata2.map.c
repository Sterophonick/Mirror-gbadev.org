/*
 * 1x4 map data
 */
const unsigned short gfxdata2_Map[4]={
0x0000, 0x0001, 0x0002, 0x0003
};

