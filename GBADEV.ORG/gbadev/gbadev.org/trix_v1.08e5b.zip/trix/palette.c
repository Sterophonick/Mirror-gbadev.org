//------------------------------------------------------------------------

// palette
// Rich Heasman May 2002

//------------------------------------------------------------------------

#include	"gba.h"
#include	"palette.h"

#include	"button.h"
#include	"string.h"
#include	"background.h"
#include	"rnd.h"

//-----------------------------------------------------------------------

//#define	PALETTE_MODIFY	TRUE
#define	PALETTE_MODIFY	FALSE

static	int		nPalettePreLine;
static	int		nPaletteLine;
static	int		nPaletteQix;
static	int		nPaletteBehind;
static	int		nPaletteBox1;
static	int		nPaletteBox2;

static	int		nPaletteIndex;

typedef	struct
{
	int	nBehind;
	int	nBox1;
	int	nBox2;
} PALETTE_LEVEL_TYPE;

#define	PALETTE_DATA_LEVELS 5

//-----------------------------------------------------------------------


static	PALETTE_LEVEL_TYPE	pPaletteLevelData[PALETTE_DATA_LEVELS + 1] = {
	{COLOUR_GREY, 		COLOUR_DARK_PURPLE,	COLOUR_DARK_PURPLE },	//Level 0
	{COLOUR_GREEN, 		COLOUR_DARK_BLUE,	COLOUR_PURPLE }, 		//Level 1
	{COLOUR_GREY, 		COLOUR_DARK_GREEN,	COLOUR_BROWN },			//Level 2
	{COLOUR_GREEN,		COLOUR_DARK_BLUE, 	COLOUR_PURPLE }, 		//Level 3
	{COLOUR_GREY, 		COLOUR_DARK_GREEN,	COLOUR_BROWN },			//Level 4
	{COLOUR_CYAN, 		COLOUR_RED,			COLOUR_DARK_PURPLE },	//Level 5
};

//-----------------------------------------------------------------------

void	Palette_Init(void)
{
	nPalettePreLine = COLOUR_YELLOW;
	nPaletteLine = COLOUR_WHITE;
	nPaletteQix = COLOUR_BLACK;
	Palette_Start(0);
	nPaletteIndex = 0;
}	

//-----------------------------------------------------------------------


void	Palette_Start(int nLevel)
{
	if (nLevel > 0)
	{
		nLevel = ((nLevel-1) % PALETTE_DATA_LEVELS) + 1;
	}

	nPaletteBehind = pPaletteLevelData[nLevel].nBehind;
	nPaletteBox1 = pPaletteLevelData[nLevel].nBox1;
	nPaletteBox2 = pPaletteLevelData[nLevel].nBox2;
}	

//-----------------------------------------------------------------------

void	Palette_Update(void)
{
	int 	nDColour;

	if (PALETTE_MODIFY)
	{
		if (Button_PressedDebounced(BUTTON_SELECT)) 
		{
			nPaletteIndex++;
			if (nPaletteIndex >= 4)
			{
				nPaletteIndex = 0;
			}
		}

		nDColour = 0;
		if (Button_PressedDebounced(BUTTON_L)) nDColour = -1;
		if (Button_PressedDebounced(BUTTON_R)) nDColour = 1;

		if (nPaletteIndex == 0) nPaletteBehind += nDColour;
		if (nPaletteIndex == 1) nPaletteBox1 += nDColour;
		if (nPaletteIndex == 2) nPaletteBox2 += nDColour;
	}
}	

//-----------------------------------------------------------------------

void	Palette_Render(void)
{
	char	szMessage[STRING_LEN_MAX];

	Palette_Copy( COLOUR_BEHIND_1, nPaletteBehind);
	Palette_Copy( COLOUR_BEHIND_2, nPaletteBehind);
	Palette_Copy( COLOUR_PLAYER_LEFT, nPalettePreLine);
	Palette_Copy( COLOUR_PLAYER_RIGHT, nPalettePreLine);
	Palette_Copy( COLOUR_PLAYER_UP, nPalettePreLine);
	Palette_Copy( COLOUR_PLAYER_DOWN, nPalettePreLine);
	Palette_Copy( COLOUR_LINE, nPaletteLine);
	Palette_Copy( COLOUR_BOX_1, nPaletteBox1);
	Palette_Copy( COLOUR_BOX_2, nPaletteBox2);
	Palette_Copy( COLOUR_BAD ^ COLOUR_BEHIND_1, nPaletteQix);
	Palette_Copy( COLOUR_BAD ^ COLOUR_BEHIND_2, nPaletteQix);
	Palette_Copy( COLOUR_BAD ^ COLOUR_LINE, nPaletteQix);

	if (PALETTE_MODIFY)
	{
		String_FromInt(szMessage, nPaletteBehind);
	    Background_Font1Print( 1, 4, szMessage);
		String_FromInt(szMessage, nPaletteBox1);
	    Background_Font1Print( 1, 5, szMessage);
		String_FromInt(szMessage, nPaletteBox2);
	    Background_Font1Print( 1, 6, szMessage);
	}
}	

//-----------------------------------------------------------------------

void	Palette_Copy(int nDest, int nSrc)
{
	u16	*pDest;
	u16	*pSrc;

	pSrc  = (u16 *) MEM_PAL_BG + nSrc;
	pDest = (u16 *) MEM_PAL_BG + nDest;
	*pDest = *pSrc;
}	

//-----------------------------------------------------------------------
