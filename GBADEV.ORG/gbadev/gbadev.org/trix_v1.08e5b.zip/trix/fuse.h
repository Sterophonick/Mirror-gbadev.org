/////////////////////////////////////////////////////////////////////////////
//
// Fuse
// Rich Heasman June 2002
//
/////////////////////////////////////////////////////////////////////////////

//-------------------------------------------------------------------------

void	Fuse_Init(void);
void	Fuse_Update(void);
void	Fuse_Render(void);
void	Fuse_Stop(void);
void	Fuse_Start(int nX, int nY);
BOOL	Fuse_Collision(int nX, int nY);
BOOL	Fuse_Active(void);

//-------------------------------------------------------------------------
