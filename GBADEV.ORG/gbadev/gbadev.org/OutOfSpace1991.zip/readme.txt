hi 

this is a 3d demo(game) V0.1 :)

name: Out of Space

50000 polys/sec in game

coded by Version/Majic12
gfx by Rack
3ds convert Ph0x 