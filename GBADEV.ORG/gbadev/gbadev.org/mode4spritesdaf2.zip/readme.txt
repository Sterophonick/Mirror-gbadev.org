------------------------------
Mode 4 and sprites
------------------------------

File:		mode4sprites.bin
Program:		Plots a picture and a sprite
Author:		Johan Jansen (Jenswa)
Contact:		awsnej@hotmail.com
Site:		http://www.geocities.com/flashsite_jrj/gba (could be down)
		

-----------------------------
About this bin-file:
This bin file is created for learning purposes. The screenmode used is mode 4,
it cotains a background picture and a blue ghost sprite.
I hope this will give some newbies like me some advantage in making games
in mode 4.

---------------
Features:
Picture in background 2
A blue ghost sprite
and key input

---------------
Controlls:
Used the arrow keys to move (at least if it was a pc game) so:
LEFT, RIGHT, UP and DOWN are the keys to move the blue ghost.

------------------
Debugging:
This file has only been tested on VisualBoyAdvance, so not on real hardware,
it works fine with VisualBoyAdvance, if somebody is planning to test this on
real hardware, please let me know.

----------------
Thanks to:

Forgotten (VisualBoyAdvance)
Jason Wilkins (Dev-Kit Advance)
Eloist (gba.h)
GBAjunkie
Dovoto
Nokturn
GBADEV.org (their new forum is great for beginners like me)
darkcloud
several gbadev forums members who told me to use tiles 512 and above,
which i also found in CowBite Virtual Harware Spec and GBATEK.

---------
Links:

These are some helpfull links if you are a gba beginner, just like me.

http://www.gbadev.org
http://www.devrs.com/gba
http://www.gbaemu.com/gba
http://www.gbajunkie.co.uk
http://www.loirak.com
http://www.gamedev.net
http://www.thepernproject.com
http://www.cs.rit.edu/~tjh8300/CowBite/CowBiteSpec.htm (CowBite Virtual Harware Spec)
http://www.work.de/nocash/gbatek.htm - gbatek html version (GBATEK)

----------------
Jenswa


-----------------
Disclaimer:
This game is freeware. This software is provided 'as is' with no warranty or guarantees of
any kind, you use this software at your own risk. You accept all responsibility for any 
damage caused as a result of using this software. The author is not liable for any costs 
incurred as a result of using this software.

