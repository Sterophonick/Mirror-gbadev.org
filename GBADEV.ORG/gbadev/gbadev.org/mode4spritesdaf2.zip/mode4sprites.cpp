////////////////////////////////////////////////////////////////////////////
//File:		mode4sprites.cpp
//Description:	displaying sprites in mode 4
//Author:		Jenswa
//Time:		about 2 hours
//
////////////////////////////////////////////////////////////////////////////

//general stuff and definitions
#include "gba.h"		//GBA register definitions
#include "dispcnt.h"		//REG_DISPCNT register #defines
#include "keypad.h"	//gba button registers
#include "sprites.h"		//sprite definitions

//gfx stuff
#include "ghost.h"		//cotains data and palette for ghost sprite
#include "picture.h"		//cotains data and palette for the background

//create an OAM variable and make it point to the address of OAM
u16* OAM = (u16*)0x7000000;

//some variables
int ghostx = 120;
int ghosty = 80;

// Mode 4 is 240(120)x160 by 8bit
void PlotPixel(int x,int y, unsigned short int c)	
{ 
	VideoBuffer[(y) *120 + (x)] = (c); 
}

//wait for the screen to stop drawing
void WaitForVsync()
{
	while((volatile u16)REG_VCOUNT != 160){}
}

//create the array of sprites
OAMEntry sprites[128];

//Copy sprite array to OAM
void CopyOAM()
{
	u16 loop;
	u16* temp;
	temp = (u16*)sprites;
	for(loop=0; loop < 128*4; loop++)
	{
		OAM[loop] = temp[loop];
	}
}

// Set sprites off screen
void InitializeSprites()
{
	u16 loop;
	for (loop = 0; loop < 128; loop++)
	{
		sprites[loop].attribute0 = 160;	//y > 159
		sprites[loop].attribute1 = 240;	//x > 239
	}
}

//move the sprite
void MoveSprite(OAMEntry* sp, int x, int y)
{
	if(x < 0)			//if it is off the left correct
		x = 512 + x;
	if(y < 0)			//if off the top correct
		y = 256 + y;

	sp->attribute1 = sp->attribute1 & 0xFE00;  //clear the old x value
	sp->attribute1 = sp->attribute1 | x;

	sp->attribute0 = sp->attribute0 & 0xFF00;  //clear the old y value
	sp->attribute0 = sp->attribute0 | y;
}

//loads the palette of the objects
void LoadOBJPalette()
{
	int x;
	for(x=0; x< 256; x++)
	{
		OBJPaletteMem[x] = ghostPalette[x];
	}
}

//draws the background picture to the screen (also initializes palette)
void DrawBG()
{
	int x,y;

	for(x=0; x < 256; x++)
	{
		BGPaletteMem[x] = picturePalette[x];
	}

	for(y=0; y < 160; y++)
	{
		for(x=0; x < 120; x++)
		{
			PlotPixel(x,y,pictureData[y*120+x]);
		}
	}
}

//GetInput
void GetInput()
{
	if(KEY_DOWN(KEYUP))	//up pressed on the gamepad
	{
		ghosty--;
	}
	if(KEY_DOWN(KEYDOWN))	//down pressed on the gamepad
	{
		ghosty++;
	}
	if(KEY_DOWN(KEYLEFT))	//left pressed on the gamepad
	{
		ghostx--;
	}
	if(KEY_DOWN(KEYRIGHT))	//right pressed on the gamepad
	{
		ghostx++;
	}
}

int main()
{

        SetMode(MODE_4 | OBJ_ENABLE | OBJ_MAP_1D | BG2_ENABLE);

	int x;
	DrawBG();
	LoadOBJPalette();
	InitializeSprites();

	sprites[0].attribute0 = COLOR_256 | SQUARE | ghosty;
	sprites[0].attribute1 = SIZE_16 | ghostx;
	sprites[0].attribute2 = 512;			//pointer to tile where sprite starts, the first 512 tiles aren't available in mode 4

	for(x = 8192; x < 8320; x++)		//load ball sprite
	{
		OAMData[x] = ghostData[x-8192];
	}

	while(1){
		GetInput();				//check if one of the buttons is pressed
		MoveSprite(&sprites[0], ghostx, ghosty);		//moves the ghost sprite around the screen
		CopyOAM();				//copy sprite data in memory
		WaitForVsync();				//wait for the screen to stop drawing

	}

}
