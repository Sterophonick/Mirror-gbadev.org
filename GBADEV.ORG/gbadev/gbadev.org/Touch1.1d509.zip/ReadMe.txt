Touch! Readme file version 1.1

Touch! History
==============
Feb.  8, 2003 v 1.1 The binary is now less than 95KB.
Jan. 16, 2003 v 1.0 Touch! is released

PLEASE ENCLOSE THIS FILE WHEN DISTRIBUTING THE TOUCH! PACKAGE
The package Touch.zip contains: touch.gba and ReadMe.txt

Testing
=======
This program was successfully tested on VisualBoyAdvance 1.3.1 and an actual GBA with a 128mb Flash Card.
This program was not tested on a multi-boot cable, so I don't know if it will work.

How To Play
===========
The playing instructions are located in the instructions section of the game.

License Stuff
=============
This game is free for personal (NON COMMERCIAL) use on your GBA and/or GBA emulator.

Any party(ies) interested in commercial use of Touch! must contact me and get my permission.

DISCLAIMER!
===========
I am not responsible for any possible loss of data or damage to you or any equipment.  That is to say if you're driving a car and playing Touch! on your GBA and get into an accident IT'S NOT MY FAULT! Basically:

This software is provided 'as-is', without any express or implied warranty. In no event shall the authors be held liable for any damages arising from the use of this software.

FEEDBACK
========
Send me your thoughts (good and bad are welcome), or questions about Touch! or just let me know you've tried the game.

Not So Famous Last Words
========================
I hope you enjoy Touch!

Dave Mejia
J_Dave_Mejia@yahoo.com
