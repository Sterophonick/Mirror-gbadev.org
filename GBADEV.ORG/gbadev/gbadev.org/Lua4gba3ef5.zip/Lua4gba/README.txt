Lua4gba by Torlus - http://torlus.com/
===============================================================================

1. About
2. Contents
3. Instructions
4. Comments
5. Credits

===============================================================================
1. About
===============================================================================

Lua4gba is a quick port of Lua (http://www.lua.org/) for the Gameboy Advance.
Lua is a powerful scripting language with many high-level features, used in 
many projects.

(Well, I wouldn't have started it if I had googled a bit before, and found out 
that a similar project already existed : GBALua (http://www.gatesboy.com/Lua/).
Anyway, it only took me about two hours to have it running, so it is not such
a waste of time, and therefore, I'm releasing it.)

This project is based on Lua 5.0.2 so is more up to date than GBALua 
(based on 4.0 version of Lua) and was made using DevkitARM.

One thing interesting about it, is that it uses the Lua source tree as-is, with 
only one small (necessary) modification for console output. So this whole project
should be considered as kind of tutorial on how to embed Lua into your projects.

It uses Damian Yerrick's GBFS for script embedding.

===============================================================================
2. Contents
===============================================================================

The archive contains the following folders :
lua/                           Lua 5.0.2 source
gba/                           GBA-specific source, and Lua startup code
tools/                         Windows/Linux build of GBFS tools, with source
misc/                          Some stuff handy for porting purposes
                               (See "Comments" section)

At the root of the archive, you will find :
demo.bat                       Script to build the sample Lua demo
demo.gba                       The GBA ROM of the demo
Lua4gba.gba                    The Lua4gba GBA ROM without script
script.lua                     Sample Lua script for the demo
Makefile
README.txt

===============================================================================
3. Instructions
===============================================================================

To build the Lua4gba demo, just run the "demo.bat" script. It will output a
"demo.gba" ROM, that you can run on your console or favorite emulator.
Its source is rather self-explanatory :
* It uses GBFS tool "padbin" to adjust the Lua4gba.gba ROM size to a multiple
of 256 (this alignement is needed by GBFS to find its root entry).
* It builds a temporary GBFS file containing the "script.lua" Lua source.
* The GBFS file is appened to the Lua4gba.gba into a new file "demo.gba"

To build the Lua4gba.gba file, you _need_ a proper installation of devitPro,
containing DevkitARM and libgba. Using the "devkitPro updater" with default
settings works perfectly.

You might use another toolchain, provided that it features some minimal libc 
requirements :
* floating-point support (in software of course).
* working memory allocation routines (like malloc(), realloc(), free()).
* a working sprintf(). It should be the case if the two previous requirements
are met.

However, it is possible to get rid of these requirements, provided that you
change some stuff in the source. See the "Comments" section below.

===============================================================================
4. Comments
===============================================================================

Compared to some porting stuff I've done before, especially on Sun's Java KVM
(see my Java4gba project on my website), this one was really easy, mostly for
two reasons :
* Lua is designed to be embedded, so its requirements are minimal, and the 
source code has been organized to enable easy porting.
* The devkitARM toolchain does most of the work by providing working C library
functions.

However, if you want to use another toolchain, or port Lua to another platform 
without all these features, here are some tricks :
* Lua uses two memory functions, l_realloc() and l_free(). If these functions 
are not defined, they default to realloc() and free(). You can simply define
them (example source code can be found in the misc/ folder, although I wouldn't
recommend its use for other purpose than testing).
* Lua uses sprintf(). Usually, implementations of *printf() functions use 
malloc(), so check your C-library's implemntation. You can still have a look at 
the source provided in the misc/ folder.
* Many lightweight implementations of *printf() functions (including the one
located in the misc/ folder) do not implement floating point numbers formatting.
Once again, the Lua team has done it right : float formatting is not used, apart
for one case that can be avoided. By default, Lua will use sprintf() for floating
point numbers formatting, but if you define the lua_number2str() function, then
you can avoid this issue.
* Lua uses some libm (math) functions. All of these are used in lmathlib.c.
* Lua uses some other libc functions, but all of them are easy to replace, if 
you want to get rid of it in order to have a very small system.

I wanted to do this project when I saw the Lua player project for PSP. It brings
a very fast and enjoyable way to develop for it : once in USB mode, you can edit
from your computer the script stored in PSP's memory stick, then just restart
the Lua player and see directly the result... really really nice.
So I thought that it would be possible to do the same for GBA using either a mbv2
or xboo cable, with the file server support. If anyone is interested in such a
thing, please let me know, and I may do it.
But honestly, such a project isn't very interesting for GBA, due to the console's
poor processing power. It's not much interesting on NDS too, as it is at the moment
not possible to edit directly the script on NDS from your computer.
The only handheld I see (and own) where this project could be interesting, is 
the GP32. I already did some USB stuff for my PandaForth project, so it would be
possible to do somthing similar to the Lua player for PSP.
Well, yet another project to do... stay tuned :)

===============================================================================
5. Credits
===============================================================================

Many thanks to :
- Lua team.
    http://www.lua.org/
- WinterMute, for DevkitARM, libgba, xboo, and clean Makefile.
    http://devkitpro.org/
- Damian Yerrick, for GBFS.
    http://www.pineight.com/
- All infomation sites about GBA, as usual...
    http://www.gbadev.org/
    http://www.devrs.com/
    http://www.work.de/nocash/gbatek.htm
