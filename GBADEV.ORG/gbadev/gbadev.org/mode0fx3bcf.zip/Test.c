/******************************
*							  *
*	Mode0 Color Effects		  *	
*							  *
*	by Vova and Serge		  *	
*	February 2001			  *
*	sorok@btinternet.com      *
*							  *
******************************/


typedef unsigned char u8;
typedef unsigned short u16;
typedef unsigned long u32;

typedef signed char s8;
typedef signed short s16;
typedef signed long s32;

long i,x,y;

extern u8 pic;
extern u16 pl;

u16 *pal=(u16*)0x5000000;
u16 *tmp_pal;

u8 *tiles=(u8*)0x6004000;
u8 *bg_data;

u16  *m0=(u16*)0x6000000;

void C_entry(void)
{

       *(u32*)0x4000000=0x0300;

       *(u16*)0x4000008=0x00c5;
       *(u16*)0x400000a=0x0184;

	   *(u16*)0x4000050=0x01c2;
	   *(u16*)0x4000054=0x0010;
	   
	   bg_data = (u8*)(&pic);
	   tmp_pal = (u16*)(&pl);

	   for (i=0;i<256;i++) pal[i]=tmp_pal[i];

	   for(i=0;i<64*600;i++) tiles[i]=bg_data[i];
	
	   for (y=0;y<20;y++) 
		   for (x=0;x<30;x++) {
			   m0[y*32+x]=y*30+x;
			   m0[1024+(19-y)*32+(29-x)]=y*30+x+3072;
		
		   }

	   *(u16*)0x4000050=0x01c2;//fade-out
	   *(u16*)0x4000054=0x0010;
	   for (x=15;x>=0;x--) {
		for (i=0;i<10000;i++) {}
			*(u16*)0x4000054=x;
	   }

	   for (i=0;i<100000;i++) {}
	   		
	   *(u16*)0x4000050=0x0142;//a-blend
	   *(u16*)0x4000052=0x1000;
	   for (x=0;x<16;x++) {
		for (i=0;i<10000;i++) {}
			*(u16*)0x4000052=256*(16-x)+x;
	   }

	   for (i=0;i<100000;i++) {}

	   for (x=0;x<16;x++) {//mosaic
		for (i=0;i<10000;i++) {}
			*(u16*)0x0400004C=16*x+x;
	   }

	   for (i=0;i<100000;i++) {}

	   *(u16*)0x4000050=0x0142;//!a-blend
	   *(u16*)0x4000052=0x0010;
	   for (x=15;x>0;x--) {
		for (i=0;i<10000;i++) {}
			*(u16*)0x4000052=256*(16-x)+x;
	   }

	   for (i=0;i<100000;i++) {}

	   *(u16*)0x4000050=0x0182;//fade-in
	   *(u16*)0x4000054=0x0000;
	   for (x=0;x<16;x++) {
		for (i=0;i<10000;i++) {}
			*(u16*)0x4000054=x;
	   }

	   *(u16*)0x4000054=0x0010;
	   *(u16*)0x400004C=0;
	   
	   for (i=0;i<100000;i++) {}

	   for (x=15;x>0;x--) {//!fade-in
		for (i=0;i<10000;i++) {}
			*(u16*)0x4000054=x;
	   }

	   for (i=0;i<100000;i++) {}

	   *(u16*)0x4000050=0x0142;//a-blend
	   *(u16*)0x4000052=0x1000;
	   for (x=0;x<16;x++) {
		for (i=0;i<10000;i++) {}
			*(u16*)0x4000052=256*(16-x)+x;
	   }

	   while(1){}

}