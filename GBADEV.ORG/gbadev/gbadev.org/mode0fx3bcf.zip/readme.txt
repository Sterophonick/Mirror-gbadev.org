*********************************
*				*
*   Mode0 Color Effects Demo    *
*	by Vova and Serge	*
*	  February 2001		*
*     sorok@btinternet.com	*
*	    ver 1.0		*
*				*
*********************************

This demo illustrates all background color effects for mode0:
1) Tiles rotation
2) Mosaic
3) Fade-in
4) Fade-out
5) a-Blending

Works with iGBA 0.5 beta.

Special thanks to JeffF, TwinD, Joat, Nokturn, Eloist and other 
nice people from #gbadev channel @ EFNet.

Any comments are welcome.