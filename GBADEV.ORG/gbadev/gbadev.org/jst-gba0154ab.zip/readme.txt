JST-GBA (Just Some Tool) By Fad

Size......: 20k
Platform..: Windows

A rather basic and pointless util. This is for those who want to detect: the image size, territory and the editing of headers in a GBA binary image.

-Fad

fad@wrinklie.com