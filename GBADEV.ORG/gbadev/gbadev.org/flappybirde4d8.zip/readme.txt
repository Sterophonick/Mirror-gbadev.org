 Flappy Bird for Game Boy Advance
              v1.0

    djedditt (Jay van Hutten)
        djedditt@msn.com
   http://www.jayvanhutten.com


About
----------------
Hi there,

We all know Flappy Bird, and I decided to bring it to my favourite
Nintendo handheld. I wanted to make it as close to the original as
possible and therefore the game is played in portrait mode. Sorry
emulator users! If you flash it to a cartridge, set the save type
to SRAM and save size to 64 kbit.

Written in C, compiled with DevKitARM.

Enjoy!


Controls
----------------
- Use the right button on the d-pad to flap
- For a soft reset, press A + B + START + SELECT
- Hold SELECT when booting to delete your save data


Distribution
----------------
You can distribute this rom for free as long as you keep
this readme.txt with it. If you do, please let me know via e-mail
so I can get some stats. Do not sell this game.


Shoutouts
----------------
0xC0DE
MrBlinky
Cearn


Version history
----------------
Version 1.0 (Dec 29, 2014)
- Initial release