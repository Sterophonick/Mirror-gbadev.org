------------------------------------
EYEBORG ADVANCE DEMO
�2003 PAUL TIMSON - REALITY FAKERS
www.realityfakers.tk
------------------------------------

------------------------------------
This is just a quick demo release of a game I`ve been working on for the GBA, using Dev Kit advance (G++ via VC++6 IDE). The final game will have 80+levels, tutorial mode, music/sound and proper game over sequences etc.

Any feedback from this demo could go to make the final better. Please note it is my first attempt at any GBA programming and I`m still learning C++. It is not intended to be an overly complex game ;)
------------------------------------

------------------------------------
I wrote `EYE-BORG` in 1993 for the Amiga using Basic (AMOS) along with a couple of other games that found their way into the public domain or licenceware areas. I thought the simple gameplay of eyeborg would suit the handheld marvel that is the GBA (SP).

The object of the game is to collect all the stars on a level within the given number of moves, as you move the number (bottom right) decreases, when it is your last move the `move` arrow icon will turn red to warn you - this last move must be used to reach the `open` exit (chequered flag tile). When you make your move you will not stop until you hit a solid tile so choose your direction carefully!

D-Pad = move around
Start = Pause (A to continue - select to quit)

The game saves progress after every 3 levels.

Any non-obvious faults/bug reports can be mailed to me at pault2003@ntlworld.com , stuff like the gfx being too dark etc (I tested this on an SP so it may look dark on an original GBA or too light on an Afterburner GBA etc), game not saving, not even working, anything that may be causing troubles. Note that the tutorial mode has been disabled as it is not finished yet, it is not a bug . . I know about it!!

Also note it will proably play a little fast in EMULATORS - if you can, then put it on your flash cart and try it on a real GBA.. much better :)

The gfx are not final and will change in later levels (spread over four `areas`.

thanks for trying it out - please visit www.realityfakers.tk for more games and updates soon.
------------------------------------

Reality Fakers �2003 - www.realityfakers.tk

