 -------------------------------------------- 
 - { oOo TANK ZONE oOo }       V1.0 16Jan02 -
 -                                          -
 - TankZone is -o%%o- Freeware -o%%o-       -
 - Author :  consolecoder@hotmail.com       -
 -                                          -
 - Gfx ripped from -|- Conflict Zone -|-    -
 - I used "libgba" made by Dancotter        -
 --------------------------------------------

 The game :
 ----------

 Would you be strong enough to go through the 16 levels of the game ??

 The number a the top is the number of ennemis left.

 At mission 5 and 13 you have limited ammos, the number of ammo is written at the bottom.
 At mission 7 and 15 you must protect the "P" building.

 Sorry no sound for the moment. The game may be very dark on real hardware.

 The source :
 ------------

 One file for the whole game. The game use "libgba" made by Dancotter.
 Sorry comments are in french but write me if you want a complete translation.
 For graphics conversions, I used utils provided with libgba.
 For complilation, I used "gccgba" (http://gccgba.gbacode.net/).
 Go there for complete tutorial about how to install and use it (http://www.ifrance.com/edorul/)

------------------------------------------------------------------------------------------------------
Version francaise :

 -------------------------------------------- 
 - { oOo TANK ZONE oOo }       V1.0 16Jan02 -
 -                                          -
 - TankZone est -o%%o- Freeware -o%%o-      -
 - Auteur :  consolecoder@hotmail.com       -
 -                                          -
 - Gfx repris de   -|- Conflict Zone -|-    -
 - J'ai utilis� "libgba" par Dancotter      -
 --------------------------------------------

 Le jeu :
 --------

 Seras tu assez fort pour passer les 16 niveaux du jeu ??

 Le nombre en haut est le nombre d'ennemis restants.

 A la mission 5 et 13, il y a des munitions limit�es (nombre en bas).
 A la mission 7 et 15, il faut proteger le batiment marqu� "P".

 Desol�, pas de son pour le moment. Le jeu est tres sombre sur une vraie GBA.

 Les sources :
 -------------
 
 Un seul fichier pour tout le jeu. Le jeu utilise "libgba" par Dancotter.
 Tous les commentaires sont en francais, petits veinards.
 Pour les conversions graphiques, j'ai utilis� les petits utils de libgba.
 Pour la compilation j'ai utilis� "gccgba" (http://gccgba.gbacode.net/) interfac� dans VisualC++.
 Pour savoir comment utiliser gccgba, il y a un excellent tutorial la : http://www.ifrance.com/edorul/
 Tout en francais egalement.

