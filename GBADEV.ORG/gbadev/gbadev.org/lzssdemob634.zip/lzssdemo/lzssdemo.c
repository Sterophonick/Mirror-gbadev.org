// Test BIOS lzss decompressor function
// just a few lines to display a compressed image
// july 2003 andre perrot
// ovaron@gmx.net
//
// compiled using gcc-devkitadvance and jeff's linker script 1.3
//

#include "gba.h"
#include "compressed.h"					// lzss data in u8 compressed[4808]

#include <stdlib.h>


#define SetMode(mode)    (REG_DISPCNT = mode)
#define BG2ENABLE      0x400         //Enable background 2
#define SCREENMODE4    0x4           //Enable screen mode 4

u16 *theVideoBuffer = (u16*)VideoBuffer;
u16 *theScreenPalette = (u16*)BGPaletteMem;

void bios_lzss( char* src, char* dest )
// bios lzss dekompressor function
{
	asm volatile(   "mov r0, %0;"
			"mov r1, %1;"
			"swi 0x110000;"
			: // no ouput
			: "r" (src), "r" (dest)
                        : "r0", "r1" );
}


int AgbMain()
{
	SetMode(SCREENMODE4 | BG2ENABLE);

	u16 i=0;
	for ( i = 0; i < 256; i++ )			// load image palette
		theScreenPalette[ i ] = znohrPalette[ i ];

	// reserve temporary space to expand image because bios function
	// cannot expand directly to video ram
	u16* buffer = (u16*)malloc( 38400 );

	// compressed data is 4808 bytes and will expand to 38400 bytes :-)
	bios_lzss( (char*)compressed, (char*)buffer);	// call bios function

	// Use DMA3 to copy image date from buffer to video ram
	REG_DM3SAD   = (u32)buffer;			// source
	REG_DM3DAD   = (u32)theVideoBuffer;		// destination
	REG_DM3CNT_L = 19200;				// length: (240*160)/2 = 19200 u16 words
	REG_DM3CNT_H = 0x8000;				// start dma

	free( buffer );					// buffer only temporary needed you can free it if you dont need it again

	HALT();						// Do it once only
}

