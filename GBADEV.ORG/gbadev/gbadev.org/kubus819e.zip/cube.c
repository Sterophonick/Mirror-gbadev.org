/*
===================================================
=
= 3D DEMO BY HUGO SMITS AKA 0XC0DE.
=
= It's a nice spinning cube, nothing too special
= but I thought this source might be usefull to
= some who are learning 3D and stuff.
=
= I would like to thank the following people :
=
= Ravity, Darkfader and Steffie
=
= cheers! :-)
=
===================================================
*/



#include "Sincos.c"			 // sin and cos tables
#include "gfx\bg_steffie.c"	 // background

unsigned short *v_buffer;    // this is the buffer adress
int vframe = 1;              // this is the buffer frame


/*
ASCII art .. hooray
  
  1----------5
  |\        /|
  | 0------4 |
  | |      | |
  | |      | |
  | |      | |
  | 2------6 |
  |/        \|
  3----------7

*/
#define Sar(a,b) (((a)<0) ? -(-(a)>>(b)) : ((a)>>(b))) // shift ar. right
#define Mul(a,b) (long)(a)*(b)


		
int projected[8][3]; // fake buffer

int vertices[8][3] =
{
  -32,-32,-32, // 0
  -32,-32, 32, // 1
  -32, 32,-32, // 2
  -32, 32, 32, // 3
   32,-32,-32, // 4
   32,-32, 32, // 5
   32, 32,-32, // 6
   32, 32, 32, // 7
};


//
// NOTE: in order for the backface culling to work correctly,
//       make sure the polygons are sorted out well. order them
//   	 like tiles (back to back).
//
int faces[12][3] =
{
	{1,3,5,},
	{5,3,7,},

	{7,3,6,},
	{2,6,3,},

	{2,0,6,},
	{0,4,6,},

	{0,1,4,},
	{1,5,4,},

	{3,1,2,},
	{1,0,2,},

	{6,4,7,},
	{4,5,7,}


};



/*
=================
= PlotPixel
=================
*/
void PlotPixel(int x,int y, unsigned short int c) 
{ 
	((unsigned short*)v_buffer)[y * 120 + x] = (c | c << 8); 
}



/*
=================
= DrawLine
=================
*/
void DrawLine(int x1,int x2,int y,unsigned short kleur)
{
	int i;
	int offset = 120 * y;

	for (i = x1; i < x2; i++)
		v_buffer[offset + i] = kleur | kleur << 8;
}



/*
=================
= DrawPolygon
=================
*/
void DrawPolygon(int x1,int y1,int x2,int y2,int x3,int y3,int kleur)
{
	int swap,l,r,y,s,e;

	if(y1 > y2)
	{
		swap = y1;
		y1 = y2;
		y2 = swap;

		swap = x1;
		x1 = x2;
		x2 = swap;
	}

	if(y1 > y3)
	{
		swap = y1;
		y1 = y3;
		y3 = swap;

		swap = x1;
		x1 = x3;
		x3 = swap;
	}

	if(y2 > y3)
	{
		swap = y2;
		y2 = y3;
		y3 = swap;

		swap = x2;
		x2 = x3;
		x3 = swap;
	}

	if(y3 - y1 != 0) l = (((x3 - x1) << 8) / (y3 - y1));
	else l = 0;

	if(y2 - y1 != 0) r = (((x2 - x1) << 8) / (y2 - y1));
	else r = 0;

	s = x1 << 8;
	e = x1 << 8;

	for(y = y1; y < y2; y++)
	{
		if(s > e)
		{
			DrawLine(e >> 8,s >> 8,y,kleur);
		}
		else
		{
			DrawLine(s >> 8,e >> 8,y,kleur);
		}

		s += r;
		e += l;
	}

	if(y3 - y2 != 0) r = (((x3 - x2) << 8) / (y3 - y2));
	else r = 0;

	s = x2 << 8;


	for(y = y2; y < y3; y++)
	{
		if(s > e)
		{
			DrawLine(e >> 8,s >> 8,y,kleur);
		}
		else
		{
			DrawLine(s >> 8,e >> 8,y,kleur);
		}

		s += r;
		e += l;
	}
}



/*
=================
= IsVisible
=================
*/
int IsVisible(int x1, int  y1,  int x2,  int y2, int x3, int y3)
{

  //
  // this does the backface culling stuff.
  // it works great, if you got your polygons well sorted out.
  //

  int dx1 = x3 - x1;
  int dy1 = y3 - y1;
  int dx2 = x3 - x2;
  int dy2 = y3 - y2;

  if  ((dx1*(dy2-dy1) - (dx2-dx1)*dy1 ) > 0)
     return 0;
  else
     return 1;
}


/*
=================
= RotateAndProject
=================
*/
void RotateAndProject(int camx,int camy,int camz,int rx,int ry,int rz)
{

	//
	// learned this from a demo by Darkfader (http://darkfader.net)
	// It works pretty damn good.
	//

	int cx,cy,cz,sx,sy,sz;
	long dist;
	int v;

	cx = ctab[rx%256]; cy = ctab[ry%256]; cz = ctab[rz%256];
	sx = stab[rx%256]; sy = stab[ry%256]; sz = stab[rz%256];

	for (v=0; v < 8; v++)
	{
		long x1,y1,z1;
		long xx,yy;
		long zz;

		x1 = Mul(cy, vertices[v][0]) - Mul(sy, vertices[v][2]);
		x1 = Sar(x1,7);

		z1 = Mul(sy, vertices[v][0]) + Mul(cy, vertices[v][2]);
		z1 = Sar(z1,7);

		xx = Mul(cz, x1            ) + Mul(sz, vertices[v][1]);
		xx = Sar(xx,7);

		y1 = Mul(cz, vertices[v][1]) - Mul(sz, x1            );    
		y1 = Sar(y1,7);

		yy = Mul(sx, z1            ) + Mul(cx, y1            );
		yy = Sar(yy,7);

		zz = Mul(cx, z1            ) - Mul(sx, y1            );
		zz = Sar(zz,7) + 256;


		zz += dist;


		//
		// translate the cords and put them in my fake buffer. 
		//
		projected[v][0] = 120 + Sar(((xx + camx) * (zz - camz)), 8);
		projected[v][1] =  80 + Sar(((yy + camy) * (zz - camz)), 8);
	}
}



/*
=================
= drawFaces
=================
*/
void drawFaces()
{
	int f;
	int color;
	int x1,y1,x2,y2,x3,y3;

	for(f = 0; f <= 12; f++)
	{ 
		x1 = projected[	faces[f][0] ][0] >> 1; // I use >>1 because we plot 2 pixels...
		y1 = projected[	faces[f][0] ][1];

		x2 = projected[	faces[f][1] ][0] >> 1;
		y2 = projected[	faces[f][1] ][1];

		x3 = projected[	faces[f][2] ][0] >> 1;
		y3 = projected[	faces[f][2] ][1];

		color = f >> 1; // we want 2 polies to have the same color.

		if(IsVisible(x1,y1,x2,y2,x3,y3) == 1)
				DrawPolygon(x1,y1,x2,y2,x3,y3,1 + color);
	}

}



/*
=================
= bg
=================
*/
void bg(void)
{
	// dma rocks! 
	*(volatile unsigned long*)0x40000D4 = (unsigned long)bg_steffieBitmap;
	*(unsigned long*)0x40000d8 = (unsigned long)v_buffer;
	*(volatile unsigned long*)0x40000DC = 0x80000000 | 120*160;
}



/*
=================
= buffer
=================
*/
void buffer(void)
{
	//
	// switch buffers
	// 
    if (vframe == 1)
		v_buffer = (unsigned short*)0x6000000; // buffer 1
    else
    	v_buffer = (unsigned short*)0x600A000; // buffer 0
 
    *(unsigned short*)0x4000000= 0x0404 | (vframe << 4) | 0x1000 | 0x40;
		
    vframe = 1 - vframe;
}



/*
=================
= AgbMain
=================
*/
void AgbMain(void)
{
	
	int rx=0, ry=0, rz=0;

	int p;

  	*(unsigned short*)0x4000000= 0x0404 | (vframe << 4) | 0x1000 | 0x40;
  
	

	for(p = 0; p < 255; p++)
		((unsigned short*)0x05000000)[p] = bg_steffiePalette[p];
	

  
    while(1)
    {
	
		// rotate mesh
		ry+=1;
		rx+=1;
		rz+=1;

		RotateAndProject(60,0,0,rx,ry,rz);

		// draw bg
		bg();

		// change buffer
		buffer();

		// draw faces
		drawFaces();


	  	while((*((unsigned int volatile *) 0x04000006))!=159);
	 	while((*((unsigned int volatile *) 0x04000006))==159);
    }
}
