---------------------
Mosiac Demo
---------------------

File:		mosaic.bin
Program:		mosaic test
Author:		Johan Jansen (Jenswa)
Contact:		awsnej@hotmail.com
Site:		http://www.geocities.com/flashsite_jrj/gba (could be down)
		

-----------------------------
About this bin-file:
I've created this bin file for learning purposes.
Playing with some features of the gba,
like the force blank command, nothing special.
And of course mosaic effect, which I've achieved this week.
Many homebrew gba devr's will already know how to use
this feature, but maybe for some beginners like me
it's usefull to have demo of the mosaic effect.
The code itself is quite simple, so there aren't many comments.
If you can code it in a more efficient way, feel free to do so.

I've tested this file only on VisualBoyAdvance, but it works!


---------------
Features:
Picture in mode4	(picture comes from my game for pc)
FORCE_BLANK
MOSAIC effect	(level goes from 0 to 17)


---------------
Controlls:
START+SELECT for a force blank (reset the rom if you want the picture again)
UP and DOWN for resp. increase and decrease mosaic till a maximum
A,B,L,R for setting the maximum of the mosaic level to a value resp. 5,9,13,17
LEFT and RIGHT for resp. maxumum of the mosaic level min and plus (called: finetunning)


----------------
Thanks to:
Forgotten (VisualBoyAdvance)
Jason Wilkins (Dev-Kit Advance)
Eloist (gba.h)
GBAjunkie (some great tutorials to start with, dovoto, dispcnt.h)
Dovoto (dispcnt.h, pcx2gba, mosaic.h!) 
Nokturn (lot's of things)
GBADEV.org (they have lots of sources and updates around gba, always usefull)
devrs.com/gba (Jeff Frohweins gba development page)
Loirak Development (they have a good tutorial to start coding for  gba)
Brian Sowers (used his keypad.h instead of Nokturns and he helped me with detecting a single press)


---------
Links:
These are some helpfull links if you are a gba beginner, just like me.

http://www.gbadev.org
http://www.devrs.com/gba
http://www.gbaemu.com/gba
http://www.gbajunkie.co.uk
http://www.loirak.com
http://www.gamedev.net
http://www.thepernproject.com


----------------
Jenswa

