////////////////////////////////////////////////////////////////////////////
//File:		mosaic.cpp
//Description:	mosaic test
//Date:		31 - November - 2002
//Author:		Jenswa
//Thanks to:	gbajunkie, nokturn, dovoto and brian sowers
////////////////////////////////////////////////////////////////////////////


#include "gba.h"		//GBA register definitions
#include "keypad.h"	//button registers
#include "dispcnt.h"		//REG_DISPCNT register #defines
#include "mosaic.h"		//mosaic effects


#include "title.h"		//the pic at the background


#define BG_MOSAIC_ENABLE		0x40

///////////////////////////////////


u8 mosaic =0;		//mosaic level
u8 maxmosaic=10;		//maximum mosaic level



void PlotPixel(int x,int y, unsigned short int c)
{
	VideoBuffer[(y) * 120 + (x)] = (c);
}



//wait for the screen to stop drawing
void WaitForVsync()
{
	while((volatile u16)REG_VCOUNT != 160){}
}


//A button was pressed at the gba
void GetInput()
{

	if(KEY( KEY_UP))
	{
		if(mosaic < maxmosaic){
			mosaic++;
			REG_MOSAIC = SetMosaic(mosaic,mosaic,0,0);
		}
	}

	if(KEY( KEY_DOWN))
	{
		if(mosaic > 0){
			mosaic--;
			REG_MOSAIC = SetMosaic(mosaic,mosaic,0,0);
		}
	}

	// set a maxmosaic level by using A,B,L,R

	if(KEY(KEY_A))
	{
		maxmosaic = 5;
	}

	if(KEY(KEY_B))
	{
		maxmosaic = 9;
	}

	if(KEY(KEY_L))
	{
		maxmosaic = 13;
	}

	if(KEY(KEY_R))
	{
		maxmosaic = 17;
	}

	// or finetune by using RIGHT and LEFT

	if(KEY(KEY_LEFT) && maxmosaic > 0)
	{
		maxmosaic--;
	}

	if(KEY(KEY_RIGHT) && maxmosaic < 17)
	{
		maxmosaic++;
	}



	if(KEY(KEY_START) && KEY(KEY_SELECT))
	{
		SetMode(FORCE_BLANK);

	}

}



int main()
{
	int i;
	int x, y;

        SetMode(MODE_4 | BG2_ENABLE); //set mode 4 and enable background 2

	for(i = 0; i < 256; i++)                 //256 entries allowed
		BGPaletteMem[i] = titlePalette[i]; //load the palette into palette memory

	
		for(y = 0; y < 160; y++)                  //screen height
		{
			for(x = 0; x < 120; x++)          //screen width
			{
				PlotPixel(x,y, titleData[y*120+x]);	//load image data into
			}				//memory pixel by pixel

		}


	// enable the mosaic effect of bg2
	REG_BG2CNT = BG_MOSAIC_ENABLE;




	while(1)		//main loop
	{
		GetInput();				//Checks for key presses
		WaitForVsync();				//waits for the screen to stop drawing
	}
}

