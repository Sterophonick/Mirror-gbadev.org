ANDROID 2 ADVANCE
=================

 This is the 1st and final release of A2A. The game IS COMPLETE with FULL SFX
which I took time to get as accurate as possible to the origonal spectrum game.
Written in 100% ARM assembler, the game also features an options screen where you
can change the background graphics if using 8x8 pixel block mode or change to 6x6
pixel block mode and have a 24x24 maze window.

Mike

