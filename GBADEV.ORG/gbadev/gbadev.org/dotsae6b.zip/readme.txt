This is the classic pencil and paper game of dots, to be played on a game boy advance (or emulator).

controls:
A - draws your line
L/R - rotates your line
Start - restarts the game


The game uses battery backup to keep your current game in progress, even if you restart. 
You must press the start button to begin a new game.

For anyone that happens to look at the source or how it works:  it's pretty wrong.  
I used this as a learning project for GBA development, and there's a number of things
that I was doing quite "incorrectly."  Waiting for VBlank wrong, not waiting for VBlank
to draw stuf, using u16 or u8 datatypes when I should have been just using plain integers.
Stuff that only gba developer types would care about, but is wrong nonetheless.