Much of this code is from a standard GBA library that I have been working on.   
Thus, not all of it is called from this dots program.

Also, various snippets of code were written by other people...the assembly routines and GBA headers, specifically, I pulled from tutorials linked to from www.gbadev.org.
