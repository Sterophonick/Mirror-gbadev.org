#ifndef __DOTS_H_
#define __DOTS_H_

#define WIDTH 10
#define HEIGHT 10

#define HORIZ 1
#define VERT 2


#ifndef true
//lets define these guys if we haven't included some header that
//already defines them....
#define true 1
#define false 0

typedef unsigned char u8;
typedef int bool;
#endif

//we have a grid of 100 dots
//a dot can have a vlue of 0,1,2,or 3
//1 = horizontal line to the right
//2 = vertical line down


void dotsClearDots();


#define SQUARE_UR 1
#define SQUARE_LL 2
#define SQUARE_LR 4
//returns an int indicating whether the line completed a square...
//0 = none
//1 = completed square to upper-right
//2 = completed square to lower-left
//4 = completed square to lower-right

int dotsDrawLine(int x, int y, int direction);

int dot(int x, int y);
int setDot(int x, int y, int state);

#endif
