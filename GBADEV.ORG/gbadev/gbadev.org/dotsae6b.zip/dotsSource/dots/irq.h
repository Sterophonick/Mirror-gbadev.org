#ifndef GBA_IRQ_H

#define GBA_IRQ_H

 
typedef void (*fp)();
 

#define IRQ_VBLANK          1

#define IRQ_HBLANK          2

#define IRQ_VCOUNT          4

#define IRQ_TIMER_0         8

#define IRQ_TIMER_1         16

#define IRQ_TIMER_2         32

#define IRQ_TIMER_3         64

#define IRQ_SIO            128

#define IRQ_DMA0         256

#define IRQ_DMA1         512

#define IRQ_DMA2         1024

#define IRQ_DMA3         2048

#define IRQ_KEYBOARD    4096

#define IRQ_CART         8192

 

 

void IRQ_Set(int irqs, fp irq_handle);

void IRQ_Disable(int irqs);

 

#endif

