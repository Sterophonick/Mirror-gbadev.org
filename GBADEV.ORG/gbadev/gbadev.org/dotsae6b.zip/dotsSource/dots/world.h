#ifndef _WORLD_H_
#define _WORLD_H_

#include "bg.h"

Bg worldMap;

void initMap(u16 * mapColorMap, u8 * mapGfx, u8 * mapMap);

void scrollMapTo(int x, int y);
void scrollMapBy(s16 x, s16 y);

int getTileAtScreenXY(u16 x, u16 y);
int getTileAtMapXY(u16 x, u16 y);

s16 getMapScrollY();
s16 getMapScrollX();

void calcMap();
void updateMap();

#endif
