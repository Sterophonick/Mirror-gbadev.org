#ifndef _BIOS_H_
#define _BIOS_H_

int swi_reset();
int swi_vblank();


#endif
