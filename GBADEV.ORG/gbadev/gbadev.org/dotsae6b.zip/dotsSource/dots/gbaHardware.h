#ifndef _gbatech_h_
#define _gbatech_h_

#include "gbaIncludes/gba.h"
#include "gbaIncludes/keypad.h"
#include "gbaIncludes/screenModes.h"
#include "gbaIncludes/dispcnt.h"
#include "gbaIncludes/sprites.h"

#include <stdlib.h>

#include "hardware.h"

#define MAXSPRITES 128
#define false 0
#define true !false

//#define SCREEN_WIDTH 239
//#define SCREEN_HEIGHT 159
#define MAGIC_WRAPAROUND_X 512
#define MAGIC_WRAPAROUND_Y 256

typedef  OAMEntry gbaSprite;

typedef struct
{
	u16 startFrame;
	bool isDead;
	bool attachedWorld;
	gbaSprite * gbs;
	s32 worldX;
	s32 worldY;
} hSprite;




#endif
