Anguna - an action/adventure game

This is a top down adventure, very zelda-esque.

The first level (this demo) is escaping from a dungeon. After that will be an overworld with approximately 4 more dungeons to explore.

Controls:
direction pad to move.
A to attack
B - (in the future, use alternate items)
L/R - (in the future, swap alternate items)
Start - pause/see subscreen
Select - restarts game!

A few tips:

1.  There are various secret passages and items that might be revealed when all enemies in a room are killed.

2.  there are also secret passages that you can only find by just walking through walls

3.  most enemies might randomly drop food...one ALWAYS drops food (if you are running low on life, finding him will come in handy)

4.  There is a way to increase your attack power.  If you are having trouble with the ugly fire-breathing-crocodile-looking-thing, make sure you've picked up the attack powerup item.


Current game status:
-Right now, only the first dungeon is finished.  When you finish the dungeon, the demo starts over.

-You can only start a new game, there is no support for "continue" or save games yet.

-The music is only a placeholder.  More/better is being made.

-More enemies and tilesets to come.  

-Also to come:  alternate usable items, more attack/defense/life powerups, etc

-Possibly to come:  a minimap of the dungeons


Please let me know your comments.  I definitely want feedback on how to improve the game.  Although one thing I DON'T want feedback on is the graphics, unless you are an artist and want to help!

Nathan
nathantolbert@gmail.com
gauauu on gbadev

