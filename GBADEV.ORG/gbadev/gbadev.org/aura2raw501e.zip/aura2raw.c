/*
  Converts NewTek Aura [2] Palette (ascii) to raw GBA palette.

  2001 Humasect (humasect@home.com)
 */

#include <stdio.h>
#include <string.h>

typedef unsigned short u16;
u16 palette[256];

#if 0
typedef union entry_u
{
  struct
  {
	char r :5;
	char g :5;
	char b :5;
  }components;
  unsigned short value;
}entry_t;
#endif

int main (int argc, char **argv)
{
  FILE *f;
  char buf[256];
  int red, green, blue, i;


  if (argc < 3) {
    fprintf(stderr, "Usage: aura2raw <aurapal> <gbaoutpal>\n");
    return 1;
  }

  //
  // Read source palette
  //

  f = fopen(argv[1], "r");
  if (!f) {
	fprintf(stderr, "Can't open source palette\n");
	return 1;
  }

  fscanf(f, "%s\n", buf);
  if (strncmp(buf, "[Palette]", 9)) {
    fprintf(stderr, "Source palette not the right format (%s)\n", buf);
    fclose(f);
    return 1;
  }
  
  // read the palette
  memset(palette, 0, 256 * sizeof(u16));
  for (i=0 ; i<256 ; i++) {
    float v[3];
    fscanf(f, "RGB=%f %f %f\n", &v[0], &v[1], &v[2]);
    red = v[0] * 255;
    green = v[1] * 255;
    blue = v[2] * 255;
    palette[i] = (((red & 248)>>3) | ((green & 248)<<2) | ((blue & 248)<<7));
  }

  fclose(f);

  //
  // Write out palette
  //

  f = fopen(argv[2], "wb");
  if (!f) {
	fprintf(stderr, "Can't write GBA palette to %s\n", argv[2]);
	fclose(f);
	return 1;
  }

  fwrite(palette, sizeof(u16), 256, f);
  fclose(f);
  printf("\twrote palette to %s\n", argv[2]);

  return 0;
}
