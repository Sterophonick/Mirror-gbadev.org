/******************************
*							  *
*	Music Playback Demo		  *	
*							  *
*	by Vova and Serge		  *	
*	March 2001			      *
*	sorok@btinternet.com      *
*							  *
******************************/

int music[10], music_a[10];

typedef unsigned char u8;
typedef unsigned short u16;
typedef unsigned long u32;

typedef signed char s8;
typedef signed short s16;
typedef signed long s32;

long i,x,y;

extern u8 pic;
extern u16 pl;

u16 *pal=(u16*)0x5000000;
u16 *tmp_pal;

u8 *tiles=(u8*)0x6004000;
u8 *bg_data;

u16  *m0=(u16*)0x6000000;

void C_entry(void)
{

       *(u32*)0x4000000=0x0100;

       *(u16*)0x4000008=0x0084;
       
	   bg_data = (u8*)(&pic);
	   tmp_pal = (u16*)(&pl);

	   for (i=0;i<256;i++) pal[i]=tmp_pal[i];
		   
	   for(i=0;i<64*600;i++) tiles[i]=bg_data[i];
	   
	   for (y=0;y<20;y++) 
		   for (x=0;x<30;x++) m0[y*32+x]=y*30+x;
			   
		//Music Pattern for Channel 1
		music[0]=1046;
		music[1]=1155;
		music[2]=1253;
		music[3]=1297;
		music[4]=1379;
		music[5]=1452;
		music[6]=1517;
		music[7]=1546;

		//Music Pattern for Channel 2
		music_a[0]=1046;
		music_a[1]=986;
		music_a[2]=1046;
		music_a[3]=1155;
		music_a[4]=1253;
		music_a[5]=1297;
		music_a[6]=1379;
		music_a[7]=1452;

		 *(u16*)0x4000082 = 0x0002;
		 *(u16*)0x4000084 = 0x0080;
		 *(u16*)0x4000080 = 0x3377;
		 *(u16*)0x4000060 = 0x0008;
		 *(u16*)0x4000062 = 0xf030;
		 *(u16*)0x4000068 = 0xf030;
		 *(u16*)0x4000064 = 32768+music[0];
		 *(u16*)0x400006C = 32768+music_a[0];
		 
		 for (x=0;x<8;x++) {
			 for (i=0;i<500000;i++) {}
			 *(u16*)0x4000064=music[x];
			 *(u16*)0x400006C=music_a[x];
		 }
		 
	   while(1){}

}