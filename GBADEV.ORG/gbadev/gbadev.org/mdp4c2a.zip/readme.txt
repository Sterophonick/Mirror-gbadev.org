*********************************
*				*
*      Music Playback Demo      *
*	by Vova and Serge	*
*	  March 2001		*
*     sorok@btinternet.com	*
*   http://www.gbadev.f2s.com	*
*	    ver 1.0		*
*				*
*********************************

Simple example of music playback. Uses two channels - Sound 1 and Sound 2.
MIDI Sound Table can be downloaded from JeffF's site.

Works on hw and VGBA 0.3

Special Thanks to nice people from #gbadev channel @EFNet.

Any comments are welcome.