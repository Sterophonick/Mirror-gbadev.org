Updates:
-Fixed the 'artifact' sprite in the top left corner
-Slowed down the level editor a bit (it ran too fast before)
-Added some more pre-made levels
-Added a starting location tile in the level editor


Programmed and art by Matthew Gummo
tomonkeyistoeror@aol.com

Object to the game:
You have to walk through the entire level without going
over a location you have already been at.

Contols:

Menus:
start		  : confirms selection
L and R		  : changes tile set for saved levels
up, down	  : move up or down 1
left, right	  : move up or down 19

In Game:
up,down,left,right: move in that direction
L and R		  : rotate left and right
A and B		  : zoom in and out
select		  : defualt setting for zoom and rotation
start and select  : restart puzzle
start,select,a,b  : quit out of the level

Random Level:
L and R    	  : change number of blanks
start		  : generate level

Level editor:
A		  : place a block down
B		  : remove a block
select		  : set intial location of player
start		  : exit, will ask to save level


Things that suck in the game:
-the menu, I didn't think that menus are what makes a game great so I didn't spend much time on it.
-only one sprite (different colors tho). Was ment for the space level, but I'm not a great drawer so just pretend your a space pilot (you know you wanted to anyway).
  
