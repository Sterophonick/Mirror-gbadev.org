 ________  ________  ________  ________  ________  ________  ________
/________//________//________//________//________//________//________/

                      ___ ___ ___ __  __  ___ ____ _  _
                     / . / __/ __/, //, \/   /_ __/ |/ /
                    / __/ __/ __/, </  </ ^ /_//_/  / /
                   /_/ /___/___/___/_/\_\/_/____/_/__/
                                               ___
                     _    _ _  _ ___ __  ___  /__ \
                    | |/|/ / // / __/, \/ __/    > >
                    |     / _  / __/  </ __/   /_/
                    |_/|_/_//_/___/_/\_\__/   _
                                             /_/

                   http://gameboyadv.cjb.net
 ________  ________  ________  ________  ________  ________  ________
/________//________//________//________//________//________//________/
    _ _                                                        _ _
   / / /                   Bitmap to ROM image                \ \ \
  / / /                         v. 1.0                         \ \ \
 /_/_/                                                          \_\_\
 \ \ \                       by Peebrain                        / / /
  \ \ \                                                        / / /
   \_\_\                    April 13, 2002                    /_/_/
 ________  ________  ________  ________  ________  ________  ________
/________//________//________//________//________//________//________/

Contents of bmp2rom.zip
                   _
   bmp2rom.bas    / /   Qbasic source code
  bmp2rom.exe    / /   The compiled execuatble
 readme.txt     /_/   The file you're looking at
 ________  ________  ________  ________  ________  ________  ________
/________//________//________//________//________//________//________/

Comments

I wrote this tool in about an hour.  The tool itself is written in
Qbasic and was compiled with Qb 4.5.  The source is included and is
called bmp2rom.bas *gasp*.  The tool will convert a 24-bit bitmap into
a gba file ready to run on hardware or an emulator.  I wrote it so I
could make pics and see what they looked like on the hardware quickly.
Feel free to edit/use/abuse it to your liking.  I could care less what
you do with the source.

Some of the data in the source I made with a small C program (in
bmp2rom.bas at the end).  I compiled it with -S and edited the .s file
a little.  Then I assembled the .s file to get those 13 lines of hex
code.  If you want the .s file or the original .cpp/.c files, let me
know.  I didn't think they deserved to be included... no big deal
really.

Hope this tool speeds up some dev'rs projects a little bit.

- Peebrain

the_peebrain at hotmail dot com

http://gameboyadv.cjb.net
 ________  ________  ________  ________  ________  ________  ________
/________//________//________//________//________//________//________/

Command Line parameters for bmp2rom.exe:

bmp2rom.exe c:\pics\input.bmp

This will make input.gba file in the same directory.  There is no
error checking, so please make sure your bitmaps are 24-bit and
240 x 160 resolution.  If they aren't, who knows what'll happen :-P.
 ________  ________  ________  ________  ________  ________  ________
/________//________//________//________//________//________//________/