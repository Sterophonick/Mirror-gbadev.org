
Some words about this reference guide...

This was never intended to be a FULL, detailed documentation over the GBA, but merely, as the guide�s name claims, a quick reference guide.
The information found here can very well be faulty, but I do doubt it, since registers described are taken out of the official Nintendo documentation
(which I naturally deleted the second after I memorized every letter in it... :).
I�ve taken the liberty to leave out certain information, registers, bits etc., making this text even more of a quick reference, targeted at the most used registers and functions of the GBA.
In short, I have refined and retyped explanations for each register, leaving only the vital straight facts.
I strongly recommend people wanting to learn EVERY ASPECT of the GBA to find more detailed documentation.
Same goes for all you who are new to the GBA - this reference guide is for the already acquainted programmer.

Flames, rants, typos and errors, praises, advices to quit the GBA-scene etc. can be mailed to djinn@o12.org.

Thank you.   � Djinn/WD

