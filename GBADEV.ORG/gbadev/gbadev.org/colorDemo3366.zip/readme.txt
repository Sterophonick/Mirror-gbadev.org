 ________  ________  ________  ________  ________  ________  ________
/________//________//________//________//________//________//________/

                      ___ ___ ___ __  __  ___ ____ _  _
                     / . / __/ __/, //, \/   /_ __/ |/ /
                    / __/ __/ __/, </  </ ^ /_//_/  / /
                   /_/ /___/___/___/_/\_\/_/____/_/__/
                                               ___
                     _    _ _  _ ___ __  ___  /__ \
                    | |/|/ / // / __/, \/ __/    > >
                    |     / _  / __/  </ __/   /_/
                    |_/|_/_//_/___/_/\_\__/   _
                                             /_/

                      http://www.pbwhere.com
 ________  ________  ________  ________  ________  ________  ________
/________//________//________//________//________//________//________/
    _ _                                                        _ _
   / / /                       colorDemo                      \ \ \
  / / /                         v. 1.0                         \ \ \
 /_/_/                                                          \_\_\
 \ \ \                       by Peebrain                        / / /
  \ \ \                                                        / / /
   \_\_\                     March 18, 2003                   /_/_/
 ________  ________  ________  ________  ________  ________  ________
/________//________//________//________//________//________//________/

Contents of colorDemo.zip
                            _
   colorDemo.gba           / /   The ROM
  colorDemo.txt           / /   The file you're looking at
 colorDemo-source.zip    /_/   The source code
 ________  ________  ________  ________  ________  ________  ________
/________//________//________//________//________//________//________/

Comments

Whipped up this demo to look at the color capabilities of the GBA in
a nice pseudo-GUI environment.  It has three "sub"-demos.  Use L and
R to cycle through the demos.  The source is included as well.  I tend
to write a lot of Qbasic code to do some tedious work, so I put those
in there as well.  Any questions, e-mail me at the address below.

Edit Color:
  Simple enough, just use the D-pad to change the R, G, and B values
  of the color displayed at the bottom.

Gamma:
  CORRECT gamma calculation.  I've heard a lot of people saying that
  gamma correction is a multiplication (i.e., a linear graph), when
  in fact it is a EXPONENTIAL function.  So here is a CORRECT gamma
  demo.  It's based off a pre-calculated table, which I generated
  with gammaTable.bas (Qbasic source code).

  The theory behind gamma correction can be seen at (where I got my
  information):
     http://freespace.virgin.net/hugo.elias/graphics/x_gamma.htm

Sub-Pixels:
  Simple demo where you toggle to either view the design with or with-
  out sub-pixels.  Sub-pixels are based off the fact that the GBA LCD
  has a column per Red, Green, and Blue.  Therefore, 3 columns per
  pixel like this (this is 3 pixels by 3 pixels in size):

                       BGR BGR BGR
                       BGR BGR BGR
                       BGR BGR BGR

  Therefore, if we put the red on full blast (31) on one pixel, and the
  blue and green on 31 in the pixel to the right of it, it will display
  a white cube, but shifted to the left 1/3 of a pixel.  It's hard to
  describe without actual images - but the important part is that you
  can only view this effect on the GBA itself.  You can find more
  information by surfing around at www.gbadev.org.

Public domain, modify/delete/(ab)use etc... at your own risk.

- Peebrain

peebrain[SHIFT+2]pbwhere.com

http://www.pbwhere.com
 ________  ________  ________  ________  ________  ________  ________
/________//________//________//________//________//________//________/

Additional notes:

Compile via the command line:
  2gba colorDemo

 ________  ________  ________  ________  ________  ________  ________
/________//________//________//________//________//________//________/