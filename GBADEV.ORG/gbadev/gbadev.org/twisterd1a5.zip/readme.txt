
This is my first GBA effect demo. I call it Twister. Run it and you'll see why :)
It works fine in igba, tho it's SLOW.

Thanks to WayneKerr for his help with getting a compiler and so on.
greets to everyone on #gbadev on efnet, and #scene.se, #swedescene, #coders on ircnet.

  / 
 / ector / medieval  (ector^mdl)
/
    henrik_83_@hotmail.com