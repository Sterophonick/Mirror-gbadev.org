CoG Front End 1.01 by HpJcHobbes
--------------------------------

This is a basic front end for "Converter Of Graphics" aka CoG. I made is because there were just too many options for CoG and I got tired of typing in all the command lines. It is still in it's infant form, so there are bound to be some bugs and such. I am also going to be adding more options and features and try to get better error detection in the program. If you want to submit a bug, suggestion, or question, you can drop me an email at: HpJcHobbes@cox.net


How to use:

Just extract the file, "CoGFrontEnd.exe" to the directory where CoG.exe is stored. You can also extract to a seperate location and just copy the command line from the program, but that is a bit more work!