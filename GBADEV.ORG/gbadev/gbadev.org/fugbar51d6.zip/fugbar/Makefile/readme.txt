
At the very top of your makefile, you can include the following,
modified to suit your needs:

# [ Napalm fuGBAr Header Settings ] ///////////////////////////////////
TITLE		= "SILLY GAME !"
GAMECODE	= ASGE
MAKERCODE	= NP
UNITCODE	= 0x11
DEVICETYPE	= 0x22
MASKROM		= 0x33
PADDATA		= "NAPALM 2001 !   "
PADDING		= 1

# [ fuGBAr Makefile ] /////////////////////////////////////////////////
include		npm_fugbar.mk



Then at the point where you finalize your build, you can simply add
$(FUGBARFIX) <file to fix>.  For example:

elf2bin: $(DEST)
		$(OBJCOPY) -v -O binary $(DEST) $(DESTBIN) $(ECHOERROR)
		$(FUGBARFIX) $(DESTBIN)
