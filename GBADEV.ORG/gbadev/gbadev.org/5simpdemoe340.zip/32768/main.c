/*	Coder:		Decay
	E-mail:		thefountainofdecay@hotmail.com
	Home Page:	http://members.tripod.co.uk/GBCE/index.html (note case)
	File:		Main.c
	Date:		26/01/2002
	Purpose:	very simple demo to show all 32768 colours using mode 3 on the gba
*/

//list defines
#define REG_DISPCNT *(unsigned short*)0x4000000	//this controls vid mode, bkgs, objs etc
#define MODE_0 0x0	//set mode 0 - tiled, bkgs 0123, no rot/scale
#define MODE_1 0x1	//set mode 1 - tiled, bkgs 012, rot/scale 2
#define MODE_2 0x2	//set mode 2 - tiled, bkgs 23,  rot/scale 23
#define MODE_3 0x3	//set mode 3 - 16bit buffer (enable bkg 2 to use)
#define MODE_4 0x4	//set mode 4 - 8bit buffer, double bufferable
#define MODE_5 0x5	//set mode 5 - 16bit buffer, double bufferable at 160x128
#define BKG0_ENABLE 0x100	//enable bkg 0
#define BKG1_ENABLE 0x200	//enable bkg 1	 
#define BKG2_ENABLE 0x400	//enable bkg 2
#define BKG3_ENABLE 0x800	//enable bkg 3
#define OBJ_ENABLE 0x1000 	//enable objects
#define VRAM (unsigned short*)0x6000000

int main(void)
{
	unsigned short *VideoBuffer=VRAM;	//set up a pointer to VRAM
	char r,g,b;

	REG_DISPCNT=(MODE_3|BKG2_ENABLE);	//set screen mode 3, enable bkg2 for 16bit buffer
	for (r=0;r<32;r++)	//cycle through the colours
	{
		for (g=0;g<32;g++)
		{
			for (b=0;b<32;b++)
			{
				*VideoBuffer++= r+(g<<5)+(b<<10);	//bitshift them to bgr format and shove into VRAM
			}
		}
	}
}
