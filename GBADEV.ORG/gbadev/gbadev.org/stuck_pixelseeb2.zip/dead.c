/* Copyright 2005 Damian Yerrick

Permission is hereby granted, free of charge, to any person obtaining
a copy of this software and associated documentation files (the
"Software"), to deal in the Software without restriction, including
without limitation the rights to use, copy, modify, merge, publish,
distribute, sublicense, and/or sell copies of the Software, and to
permit persons to whom the Software is furnished to do so, subject to
the following conditions:

The above copyright notice and this permission notice shall be
included in all copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND,
EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES
OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND
NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS
BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN
AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF
OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS
IN THE SOFTWARE.

*/


#include <sys/types.h>
#include "pin8gba.h"

#define DISPLAY_MAP 31


extern const unsigned char text_chr[];
extern const unsigned int text_chr_len;


const char initial_scr[] =
"GBA Stuck Pixel Fixer 0.1\n"
"� 2005 Damian Yerrick\n"
"\n"
"This program comes with\n"
"ABSOLUTELY NO WARRANTY.\n"
"Reproduction and distribution\n"
"are permitted subject to\n"
"specific conditions.  See\n"
"the manual for details.\n"
"\n"
"HEALTH WARNING:  This program\n"
"uses a flashing screen.\n"
"If flashing lights give you\n"
"seizures, look away!\n"
"\n"
"Press A to continue.";

const char instruct_scr[] =
"1. Turn the GBA over (or\n"
"   close the GBA SP or\n"
"   Nintendo DS case).\n"
"\n"
"2. To start or stop the\n"
"   sequence, press the L or R\n"
"   shoulder button.";

/* upcvt_4bit() ************************
   Convert a 1-bit font to GBA 4-bit format.
*/
static void upcvt_4bit(void *dst, const u8 *src, size_t len)
{
  u32 *out = dst;

  for(; len > 0; len--)
  {
    u32 dst_bits = 0;
    u32 src_bits = *src++;
    u32 x;

    for(x = 0; x < 8; x++)
    {
      dst_bits <<= 4;
      dst_bits |= src_bits & 1;
      src_bits >>= 1;
    }
    *out++ = dst_bits;
  }
}


void display_scr(const char *s)
{
  unsigned int x = 0, y = 0;

  for(y = 0; y < 20; y++)
    for(x = 0; x < 30; x++)
      MAP[DISPLAY_MAP][y][x] = ' ';

  for(x = 0, y = 1;
      y < 20 && *s != 0;
      s++)
  {
    unsigned int c = *s & 0xff;

    if(c == '\n')
    {
      x = 0;
      y++;
    }
    else if(x < 30)
      MAP[DISPLAY_MAP][y][x++] = c;
  }
}


void isr(void);
static void setup_isr(void)
{
  /* set the ISR */
  SET_MASTER_ISR(isr);
  /* turn on interrupt sources */
  LCDSTAT = LCDSTAT_VBLIRQ;  /* vbl interrupt */
  /* turn on interrupt controller */
  INTMASK = INT_VBLANK;
  INTENABLE = 1;
}


void wait4vbl(void)
{
  asm volatile("swi 0x05");
}

static const unsigned short flashing_colors[6] =
{
  RGB(31, 0, 0), RGB(31,31, 0), RGB(31,31,31),
  RGB( 0,31,31), RGB( 0, 0,31), RGB( 0, 0, 0)
};


static const u32 sawwave[4] =
{
  0x12110000,0x67453322,0xDDCCAB89,0xFFFFEEDE
};


static void set_bias(void)
{
  asm volatile("mov r2, #2; lsl r2, #8; swi 0x19" ::: "r0", "r1", "r2", "r3");
  SETSNDRES(1);
}


void init_sound(void)
{
  //turn on sound circuit
  SNDSTAT = SNDSTAT_ENABLE;
  //full volume, enable sound 3 to left and right
  DMGSNDCTRL = DMGSNDCTRL_LVOL(7) | DMGSNDCTRL_RVOL(7) |
               DMGSNDCTRL_LTRI | DMGSNDCTRL_RTRI;
  // Overall output ratio - Full
  DSOUNDCTRL = DSOUNDCTRL_DMG100;
  set_bias();

  TRICTRL = TRICTRL_2X32 | TRICTRL_BANK(1) | TRICTRL_ENABLE;
  TRIWAVERAM[0] = sawwave[0];
  TRIWAVERAM[1] = sawwave[1];
  TRIWAVERAM[2] = sawwave[2];
  TRIWAVERAM[3] = sawwave[3];
  TRILENVOL = 0;
  TRIFREQ = (2048 - 1097) | FREQ_RESET | FREQ_HOLD;
  TRICTRL = TRICTRL_2X32 | TRICTRL_BANK(0) | TRICTRL_ENABLE;
  TRIWAVERAM[0] = sawwave[0];
  TRIWAVERAM[1] = sawwave[0];
  TRIWAVERAM[2] = sawwave[0];
  TRIWAVERAM[3] = sawwave[0];
}



int main(void)
{
  unsigned int last_joy = 0x3ff;
  int phase = -1;

  upcvt_4bit(PATRAM4(0, 0), text_chr, text_chr_len);
  setup_isr();
  display_scr(initial_scr);
  PALRAM[0] = RGB( 0, 0, 0);
  PALRAM[1] = RGB(31,31,31);
  BGCTRL[0] = BGCTRL_PAT(0) | BGCTRL_NAME(DISPLAY_MAP);
  wait4vbl();
  LCDMODE = 0 | LCDMODE_BG0;

  init_sound();

  /* wait for press A */
  while(!(JOY & JOY_A))
    wait4vbl();
  while(JOY & JOY_A)
    wait4vbl();
  display_scr(instruct_scr);


  while(1)
  {
    unsigned int j = JOY ^ 0x3FF;
    unsigned int jnew = j & ~last_joy;

    last_joy = j;

    if(jnew & (JOY_L | JOY_R))
    {
      phase = (phase >= 0) ? -1 : 0;

      /* turn on sound */
      if(phase >= 0)
        TRILENVOL = TRILENVOL_100;
      else
        TRILENVOL = 0;
    }
    if(phase >= 0)
    {
      LCDMODE = 0;
      PALRAM[0] = flashing_colors[phase++];
      if(phase >= 6)
        phase = 0;
    }
    else
    {
      LCDMODE = 0 | LCDMODE_BG0;
      PALRAM[0] = RGB( 0, 0, 0);
    }
    wait4vbl();
  }

  while(1);
}

