Now There's A Frood Who Really Knows Where His Towel Is

This is my first GBA program, a port of a demo I wrote
for the Atari ST about 11 years ago, when I was but a
youth and coding for a demo crew called The Watchmen.

It's pretty ugly, and it was probably a lot more fun to
write than it is to look at (I'm not trying to put you
off or anything).

This was really just a practice for me, so I can get to
know the Gameboy Advance hardware a little. Having said
that, I have never actually touched a real-life GBA, so
I only know that it works with VisualBoyAdvance.


chrisb of The Watchmen - http://www.designed-for.tv/twm/
