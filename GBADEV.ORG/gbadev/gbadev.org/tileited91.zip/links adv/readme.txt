Tile-it (aka Links)
by JP2010 (Jason Perry thesoysauceKid@hotmail.com)

controls:
 d-pad: move cursor
 a: rotate tile (clockwise)
 b: hold down and press the d-pad to replace selected tile with d-pad tile

Here are the files needed to compile this game. I used Ham 2.8 when I made this so I don't know if it will compile with later versions. Feel free to edit/add/remove any features you want. The comments are probably indecipherable to anyone but me, but the code is pretty much straightfoward. Please email me comments/praises/flames that you have to thesoysaucekid@hotmail.com)

enjoy