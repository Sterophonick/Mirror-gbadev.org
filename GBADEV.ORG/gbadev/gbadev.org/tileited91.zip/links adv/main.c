/*********************************************************************************
 * Includes
 ********************************************************************************/
// Basically, first, as on top of all HAM files, the most
// important include is the mygba.h, which contains all the
// macro definitions, and the HAMlib function prototypes.
#include "mygba.h"

//rules and structs for links
#include "game.h"
//graphics and palette
#include "palette.pal.c"
#include "signs.raw.c"
#include "background.raw.c"
//sprite.pal.c is the palette for cursor.raw.c & gameover.raw.c
#include "sprite.pal.c"
#include "cursor.raw.c"
#include "gameover.raw.c"

#include "title.raw.c"

/*********************************************************************************
 * MULTIBOOT is interesting.
 * If you write this on the top of your main file,
 * the GBA ROM you build will automatically be capable of running both
 * from FLA carts and, in addition directly over the MBV2 cable.
 * If you do not need this, simply comment it out.
 ********************************************************************************/
MULTIBOOT


/*********************************************************************************
 * Globals
 ********************************************************************************/
u8 g_keyState;
u8 g_prevKeyState;
xyPos g_cursor;
u8 g_cursorGfx;
u8 g_updateGfx = 0;
u8 g_updateBoard = 0;
u8 g_exit = 0;
u32 g_timer = 30;
u16 g_displayMap[PLAYFIELD_WIDTH*2][PLAYFIELD_HEIGHT*2];
u16 g_backgroundMap[32][32];
 

/*********************************************************************************
 * Prototypes
 ********************************************************************************/
void init_game(void);
u8 getKeyState(void);
void getInput(void);
void updateBoard(void);
void start_game(void);
void vblFun(void);
void tm0Fun(void);
void updateGraphics(void);
void gameover();

/*********************************************************************************
 * Program entry point
 ********************************************************************************/
int main(void)
{
  // Initialize HAMlib
  // Then we call the single most important function of ham, ham_Init .
  // This function must be called first thing when working with HAMlib,
  // because all ham_* functions will only work correctly after this has been called.
  // Behaviour of HAMlib is undefined if you comment this out.
  ham_Init();
  
  
  //Display title
  M_TIM0CNT_TIMER_START
  ham_SetBgMode(3);
  ham_LoadBitmap  (&title_Bitmap);
  
  
  while(getKeyState() != GS_PAUSE){
  }
  
  //set all the modes for game
  init_game();
  //configures all game related variables
  start_game();
  
  //start timer Interrupt
  M_TIM0CNT_IRQ_ENABLE
  M_TIM0CNT_SPEED_SELECT_SET(2)
  
  // Loop
  while(1) {
    getInput();
    updateBoard();
    
    
    if(g_exit){
      gameover();
    }
  } //end game loop
    return 0;
}

//
void init_game() {
    g_updateGfx = 0;
    ham_ResetBg();
    ham_SetBgMode(0);   //tiled. 4 layers. no rotation
    ham_bg[3].ti = ham_InitTileEmptySet(64,1,1);
    ham_InitText(3);    //text will appear on the third layer
    
    ham_LoadBGPal256(&g_palette);
    ham_LoadObjPal256(&g_objPalette);
   
    g_cursorGfx = ham_CreateObj(&g_cursorImg,0,1,OBJ_MODE_NORMAL,1,0,0,0,0,0,0,0,0);
   
    ham_CopyObjToOAM();
   
    ham_bg[0].ti =  ham_InitTileSet(&g_tiles, SIZEOF_16BIT(g_tiles), 1,1);
    ham_bg[0].mi = ham_InitMapEmptySet(0,0);
    
    ham_bg[1].ti = ham_InitTileSet(&g_background, SIZEOF_16BIT(g_background), 1, 1);
    ham_bg[1].mi = ham_InitMapEmptySet(0,0);
    
    
    
    //start building of background (which is actually one layer above playing field)
    int x;
    int y;
    for(x = 0; x < (PLAYFIELD_WIDTH*2); x++){
        for(y = 0; y < (PLAYFIELD_HEIGHT*2); y++) {
            g_backgroundMap[y][x] = 0;
        }
    }
    
    for(x = 0; x < 12; x++){
        for(y = 0; y < 20; y++) {
            g_backgroundMap[y][x+(PLAYFIELD_WIDTH*2)] = 1;
        }
    }
    
    for(x = 0; x < 30; x++){
            g_backgroundMap[PLAYFIELD_HEIGHT*2][x] = 49;
            g_backgroundMap[PLAYFIELD_HEIGHT*2+1][x] = 57;
    }
    
    //end bulding of background

    map_fragment_info_ptr map;
    map = ham_InitMapFragment(&g_backgroundMap, 32, 32, 0, 0, 32, 32, 0);
    ham_InsertMapFragment(map,1,0,0);
    ham_InitBg(1, 1, 2, 0);

    
    ham_StartIntHandler(INT_TYPE_VBL, vblFun);
    ham_StartIntHandler(INT_TYPE_TIM0,tm0Fun);
}

//configures all game related variables
void start_game() {
    srand(F_TIM0COUNT_GET_CURRENT_VALUE);
    g_cursor.x = 3;
    g_cursor.y = 3;
    g_score = 0;
    g_timer = 180;
    g_exit=0;
    
    createPlayfield();
    g_updateGfx = 1;
    g_updateBoard = 1;

    ham_DrawText(20,0, "score:");
    ham_DrawText(20,2,"time:");
}

void updateBoard(){
  u8 x;
  u8 y;

  if(g_updateBoard) {
    //before we evaluate the links... clear out the .bLinked data from the playfield
    for(x = 0; x < PLAYFIELD_WIDTH; x++) {
      for(y = 0; y < PLAYFIELD_HEIGHT; y++) {
        g_playfield[x][y].bLinked = 0;
      }
    }

    if(evaluateLinks(&g_linkerPos[0])) {
    //our linkers linked!! now lets tally score
      g_score += delink();
      newLinkers();
      g_updateBoard = 1;
    }else{
    //link one didn't link
      evaluateLinks(&g_linkerPos[1]);
      g_updateBoard=0;
    }
      g_updateGfx=1;
    }
}

void getInput() {
  g_prevKeyState=g_keyState;
  g_keyState = getKeyState();

  if(g_prevKeyState != g_keyState) {
    switch(g_keyState) {
      case GS_NOTHING: break; //do nothing
      case GS_SEL_TILE:   break;
      case GS_RPLC_UP:    replacePiece(&g_cursor, DIR_UP); g_updateBoard=1; break;
      case GS_RPLC_DOWN:  replacePiece(&g_cursor, DIR_DOWN); g_updateBoard=1; break;
      case GS_RPLC_LEFT:  replacePiece(&g_cursor, DIR_LEFT); g_updateBoard=1; break;
      case GS_RPLC_RIGHT: replacePiece(&g_cursor, DIR_RIGHT); g_updateBoard=1; break;
      case GS_ROTATE:  rotatePiece(&g_cursor); g_updateBoard=1; break;
      case GS_MVCUR_UP:  moveCursor(&g_cursor, DIR_UP); g_updateBoard=1; break;
      case GS_MVCUR_DOWN : moveCursor(&g_cursor,DIR_DOWN); g_updateBoard=1; break;
      case GS_MVCUR_LEFT:  moveCursor(&g_cursor, DIR_LEFT); g_updateBoard=1; break;
      case GS_MVCUR_RIGHT: moveCursor(&g_cursor, DIR_RIGHT);  g_updateBoard=1; break;
      case GS_PAUSE: break;
      default: break; //do nothing
    }
  }
    
}

u8 getKeyState() {
    if(F_CTRLINPUT_START_PRESSED) { return GS_PAUSE; }
    
    if(F_CTRLINPUT_SELECT_PRESSED){ return GS_PAUSE; }
    
    if (F_CTRLINPUT_B_PRESSED) {
        if(F_CTRLINPUT_UP_PRESSED) { return GS_RPLC_UP; }else
        if(F_CTRLINPUT_DOWN_PRESSED) { return GS_RPLC_DOWN; }else
        if(F_CTRLINPUT_LEFT_PRESSED) { return GS_RPLC_LEFT; }else
        if(F_CTRLINPUT_RIGHT_PRESSED) { return GS_RPLC_RIGHT; }else
        if(F_CTRLINPUT_A_PRESSED) { return GS_ROTATE; }
        else{ return GS_SEL_TILE; }
    }
    
    if(F_CTRLINPUT_A_PRESSED) { return GS_ROTATE; }else
    if(F_CTRLINPUT_UP_PRESSED) { return GS_MVCUR_UP; }else
    if(F_CTRLINPUT_DOWN_PRESSED) { return GS_MVCUR_DOWN; }else
    if(F_CTRLINPUT_LEFT_PRESSED) { return GS_MVCUR_LEFT; }else
    if(F_CTRLINPUT_RIGHT_PRESSED) { return GS_MVCUR_RIGHT; }
    
    return GS_NOTHING;
}

void vblFun() {
    if(g_updateGfx) {
       updateGraphics();
       g_updateGfx = 0;
    }
}

void tm0Fun() {
    u8 min, sec;
    g_timer--;
    
    if(g_timer == 0){g_exit = 1; return;}
    min = g_timer/60;
    sec = g_timer%60;
    
    ham_DrawText(20,3, "%d:%.2d", min, sec);
}


void updateGraphics() {
    u8 x;
    u8 y;

  ham_DrawText(20,1, "%9d", g_score);
    
    for(x = 0; x < PLAYFIELD_WIDTH; x++) {
        for(y = 0; y < PLAYFIELD_HEIGHT; y++) {
            switch(g_playfield[x][y].piece) {
                case NULLSPACE:
                    g_displayMap[y*2][x*2] = 0;
                    g_displayMap[y*2][(x*2)+1] = 1;
                    g_displayMap[(y*2)+1][x*2] = 2;
                    g_displayMap[(y*2)+1][(x*2)+1] = 3;
                    break;
                case ALL_PIECE:
                    if(g_playfield[x][y].bLinked) {
                        g_displayMap[y*2][x*2] = 132;
                        g_displayMap[y*2][(x*2)+1] = 133;
                        g_displayMap[(y*2)+1][x*2] = 134;
                        g_displayMap[(y*2)+1][(x*2)+1] = 135;
                    }else{
                        g_displayMap[y*2][x*2] = 4;
                        g_displayMap[y*2][(x*2)+1] = 5;
                        g_displayMap[(y*2)+1][x*2] = 6;
                        g_displayMap[(y*2)+1][(x*2)+1] = 7;
                    }
                    break;
                case NeSeSwNw_PIECE:
                    if(g_playfield[x][y].bLinked){
                        g_displayMap[y*2][x*2] = 136;
                        g_displayMap[y*2][(x*2)+1] = 137;
                        g_displayMap[(y*2)+1][x*2] = 138;
                        g_displayMap[(y*2)+1][(x*2)+1] = 139;
                    }else{
                        g_displayMap[y*2][x*2] = 8;
                        g_displayMap[y*2][(x*2)+1] = 9;
                        g_displayMap[(y*2)+1][x*2] = 10;
                        g_displayMap[(y*2)+1][(x*2)+1] = 11;
                    }
                    break;
                case NESW_PIECE:
                    if(g_playfield[x][y].bLinked){
                        g_displayMap[y*2][x*2] = 140;
                        g_displayMap[y*2][(x*2)+1] = 141;
                        g_displayMap[(y*2)+1][x*2] = 142;
                        g_displayMap[(y*2)+1][(x*2)+1] = 143;
                    }else{
                        g_displayMap[y*2][x*2] = 12;
                        g_displayMap[y*2][(x*2)+1] = 13;
                        g_displayMap[(y*2)+1][x*2] = 14;
                        g_displayMap[(y*2)+1][(x*2)+1] = 15;
                    }
                    break;
                case NS_PIECE:
                    if(g_playfield[x][y].bLinked){
                        g_displayMap[y*2][x*2] = 144;
                        g_displayMap[y*2][(x*2)+1] = 145;
                        g_displayMap[(y*2)+1][x*2] = 146;
                        g_displayMap[(y*2)+1][(x*2)+1] = 147;
                    }else{
                        g_displayMap[y*2][x*2] = 16;
                        g_displayMap[y*2][(x*2)+1] = 17;
                        g_displayMap[(y*2)+1][x*2] = 18;
                        g_displayMap[(y*2)+1][(x*2)+1] = 19;
                    }
                    break;
                case EW_PIECE:
                    if(g_playfield[x][y].bLinked){
                        g_displayMap[y*2][x*2] = 148;
                        g_displayMap[y*2][(x*2)+1] = 149;
                        g_displayMap[(y*2)+1][x*2] = 150;
                        g_displayMap[(y*2)+1][(x*2)+1] = 151;
                    }else{
                        g_displayMap[y*2][x*2] = 20;
                        g_displayMap[y*2][(x*2)+1] = 21;
                        g_displayMap[(y*2)+1][x*2] = 22;
                        g_displayMap[(y*2)+1][(x*2)+1] = 23;
                    }
                    break;
                case NNeSNw_PIECE:
                    if(g_playfield[x][y].bLinked){
                        g_displayMap[y*2][x*2] = 152;
                        g_displayMap[y*2][(x*2)+1] = 153;
                        g_displayMap[(y*2)+1][x*2] = 154;
                        g_displayMap[(y*2)+1][(x*2)+1] = 155;
                    }else{
                        g_displayMap[y*2][x*2] = 24;
                        g_displayMap[y*2][(x*2)+1] = 25;
                        g_displayMap[(y*2)+1][x*2] = 26;
                        g_displayMap[(y*2)+1][(x*2)+1] = 27;
                    }
                    break;
                case NeESeW_PIECE:
                    if(g_playfield[x][y].bLinked) {
                        g_displayMap[y*2][x*2] = 156;
                        g_displayMap[y*2][(x*2)+1] = 157;
                        g_displayMap[(y*2)+1][x*2] = 158;
                        g_displayMap[(y*2)+1][(x*2)+1] = 159;
                    }else{
                        g_displayMap[y*2][x*2] = 28;
                        g_displayMap[y*2][(x*2)+1] = 29;
                        g_displayMap[(y*2)+1][x*2] = 30;
                        g_displayMap[(y*2)+1][(x*2)+1] = 31;
                    }
                    break;
                case NSeSSw_PIECE:
                    if(g_playfield[x][y].bLinked){
                        g_displayMap[y*2][x*2] = 160;
                        g_displayMap[y*2][(x*2)+1] = 161;
                        g_displayMap[(y*2)+1][x*2] = 162;
                        g_displayMap[(y*2)+1][(x*2)+1] = 163;
                    }else{
                        g_displayMap[y*2][x*2] = 32;
                        g_displayMap[y*2][(x*2)+1] = 33;
                        g_displayMap[(y*2)+1][x*2] = 34;
                        g_displayMap[(y*2)+1][(x*2)+1] = 35;
                    }
                    break;
                case ESwWNw_PIECE:
                    if(g_playfield[x][y].bLinked){
                        g_displayMap[y*2][x*2] = 164;
                        g_displayMap[y*2][(x*2)+1] = 165;
                        g_displayMap[(y*2)+1][x*2] = 166;
                        g_displayMap[(y*2)+1][(x*2)+1] = 167;
                    }else{
                        g_displayMap[y*2][x*2] = 36;
                        g_displayMap[y*2][(x*2)+1] = 37;
                        g_displayMap[(y*2)+1][x*2] = 38;
                        g_displayMap[(y*2)+1][(x*2)+1] = 39;
                    }
                    break;
                case SW_PIECE:
                    if(g_playfield[x][y].bLinked){
                        g_displayMap[y*2][x*2] = 168;
                        g_displayMap[y*2][(x*2)+1] = 169;
                        g_displayMap[(y*2)+1][x*2] = 170;
                        g_displayMap[(y*2)+1][(x*2)+1] = 171;
                    }else{
                        g_displayMap[y*2][x*2] = 40;
                        g_displayMap[y*2][(x*2)+1] = 41;
                        g_displayMap[(y*2)+1][x*2] = 42;
                        g_displayMap[(y*2)+1][(x*2)+1] = 43;
                    }
                    break;
                case NW_PIECE:
                    if(g_playfield[x][y].bLinked){
                        g_displayMap[y*2][x*2] = 172;
                        g_displayMap[y*2][(x*2)+1] = 173;
                        g_displayMap[(y*2)+1][x*2] = 174;
                        g_displayMap[(y*2)+1][(x*2)+1] = 175;
                    }else{
                        g_displayMap[y*2][x*2] = 44;
                        g_displayMap[y*2][(x*2)+1] = 45;
                        g_displayMap[(y*2)+1][x*2] = 46;
                        g_displayMap[(y*2)+1][(x*2)+1] = 47;
                    }
                    break;
                case NE_PIECE:
                    if(g_playfield[x][y].bLinked){
                        g_displayMap[y*2][x*2] = 176;
                        g_displayMap[y*2][(x*2)+1] = 177;
                        g_displayMap[(y*2)+1][x*2] = 178;
                        g_displayMap[(y*2)+1][(x*2)+1] = 179;
                    }else{
                        g_displayMap[y*2][x*2] = 48;
                        g_displayMap[y*2][(x*2)+1] = 49;
                        g_displayMap[(y*2)+1][x*2] = 50;
                        g_displayMap[(y*2)+1][(x*2)+1] = 51;
                    }
                    break;
                case ES_PIECE:
                    if(g_playfield[x][y].bLinked){
                        g_displayMap[y*2][x*2] = 180;
                        g_displayMap[y*2][(x*2)+1] = 181;
                        g_displayMap[(y*2)+1][x*2] = 182;
                        g_displayMap[(y*2)+1][(x*2)+1] = 183;
                    }else{
                        g_displayMap[y*2][x*2] = 52;
                        g_displayMap[y*2][(x*2)+1] = 53;
                        g_displayMap[(y*2)+1][x*2] = 54;
                        g_displayMap[(y*2)+1][(x*2)+1] = 55;
                    }
                    break;
                case SSwW_PIECE:
                    if(g_playfield[x][y].bLinked){
                        g_displayMap[y*2][x*2] = 184;
                        g_displayMap[y*2][(x*2)+1] = 185;
                        g_displayMap[(y*2)+1][x*2] = 186;
                        g_displayMap[(y*2)+1][(x*2)+1] = 187;
                    }else{
                        g_displayMap[y*2][x*2] = 56;
                        g_displayMap[y*2][(x*2)+1] = 57;
                        g_displayMap[(y*2)+1][x*2] = 58;
                        g_displayMap[(y*2)+1][(x*2)+1] = 59;
                    }
                    break;
                case NWNw_PIECE:
                    if(g_playfield[x][y].bLinked){
                        g_displayMap[y*2][x*2] = 188;
                        g_displayMap[y*2][(x*2)+1] = 189;
                        g_displayMap[(y*2)+1][x*2] = 190;
                        g_displayMap[(y*2)+1][(x*2)+1] = 191;
                    }else{
                        g_displayMap[y*2][x*2] = 60;
                        g_displayMap[y*2][(x*2)+1] = 61;
                        g_displayMap[(y*2)+1][x*2] = 62;
                        g_displayMap[(y*2)+1][(x*2)+1] = 63;
                    }
                    break;
                case NNeE_PIECE:
                    if(g_playfield[x][y].bLinked){
                        g_displayMap[y*2][x*2] = 192;
                        g_displayMap[y*2][(x*2)+1] = 193;
                        g_displayMap[(y*2)+1][x*2] = 194;
                        g_displayMap[(y*2)+1][(x*2)+1] = 195;
                    }else{
                        g_displayMap[y*2][x*2] = 64;
                        g_displayMap[y*2][(x*2)+1] = 65;
                        g_displayMap[(y*2)+1][x*2] = 66;
                        g_displayMap[(y*2)+1][(x*2)+1] = 67;
                    }
                    break;
                case ESeS_PIECE:
                    if(g_playfield[x][y].bLinked){
                        g_displayMap[y*2][x*2] = 196;
                        g_displayMap[y*2][(x*2)+1] = 197;
                        g_displayMap[(y*2)+1][x*2] = 198;
                        g_displayMap[(y*2)+1][(x*2)+1] = 199;
                    }else{
                        g_displayMap[y*2][x*2] = 68;
                        g_displayMap[y*2][(x*2)+1] = 69;
                        g_displayMap[(y*2)+1][x*2] = 70;
                        g_displayMap[(y*2)+1][(x*2)+1] = 71;
                    }
                    break;
                case NeSNw_PIECE:
                    if(g_playfield[x][y].bLinked){
                        g_displayMap[y*2][x*2] = 200;
                        g_displayMap[y*2][(x*2)+1] = 201;
                        g_displayMap[(y*2)+1][x*2] = 202;
                        g_displayMap[(y*2)+1][(x*2)+1] = 203;
                    }else{
                        g_displayMap[y*2][x*2] = 72;
                        g_displayMap[y*2][(x*2)+1] = 73;
                        g_displayMap[(y*2)+1][x*2] = 74;
                        g_displayMap[(y*2)+1][(x*2)+1] = 75;
                    }
                    break;
                case NeSeW_PIECE:
                    if(g_playfield[x][y].bLinked){
                        g_displayMap[y*2][x*2] = 204;
                        g_displayMap[y*2][(x*2)+1] = 205;
                        g_displayMap[(y*2)+1][x*2] = 206;
                        g_displayMap[(y*2)+1][(x*2)+1] = 207;
                    }else{
                        g_displayMap[y*2][x*2] = 76;
                        g_displayMap[y*2][(x*2)+1] = 77;
                        g_displayMap[(y*2)+1][x*2] = 78;
                        g_displayMap[(y*2)+1][(x*2)+1] = 79;
                    }
                    break;
                case NSeSw_PIECE:
                    if(g_playfield[x][y].bLinked){
                        g_displayMap[y*2][x*2] = 208;
                        g_displayMap[y*2][(x*2)+1] = 209;
                        g_displayMap[(y*2)+1][x*2] = 210;
                        g_displayMap[(y*2)+1][(x*2)+1] = 211;
                    }else{
                        g_displayMap[y*2][x*2] = 80;
                        g_displayMap[y*2][(x*2)+1] = 81;
                        g_displayMap[(y*2)+1][x*2] = 82;
                        g_displayMap[(y*2)+1][(x*2)+1] = 83;
                    }
                    break;
                case ESwNw_PIECE:
                    if(g_playfield[x][y].bLinked){
                        g_displayMap[y*2][x*2] = 212;
                        g_displayMap[y*2][(x*2)+1] = 213;
                        g_displayMap[(y*2)+1][x*2] = 214;
                        g_displayMap[(y*2)+1][(x*2)+1] = 215;
                    }else{
                        g_displayMap[y*2][x*2] = 84;
                        g_displayMap[y*2][(x*2)+1] = 85;
                        g_displayMap[(y*2)+1][x*2] = 86;
                        g_displayMap[(y*2)+1][(x*2)+1] = 87;
                    }
                    break;
                case NESw_PIECE:
                    if(g_playfield[x][y].bLinked){
                        g_displayMap[y*2][x*2] = 216;
                        g_displayMap[y*2][(x*2)+1] = 217;
                        g_displayMap[(y*2)+1][x*2] = 218;
                        g_displayMap[(y*2)+1][(x*2)+1] = 219;
                    }else{
                        g_displayMap[y*2][x*2] = 88;
                        g_displayMap[y*2][(x*2)+1] = 89;
                        g_displayMap[(y*2)+1][x*2] = 90;
                        g_displayMap[(y*2)+1][(x*2)+1] = 91;
                    }
                    break;
                case ESNw_PIECE:
                    if(g_playfield[x][y].bLinked){
                        g_displayMap[y*2][x*2] = 220;
                        g_displayMap[y*2][(x*2)+1] = 221;
                        g_displayMap[(y*2)+1][x*2] = 222;
                        g_displayMap[(y*2)+1][(x*2)+1] = 223;
                    }else{
                        g_displayMap[y*2][x*2] = 92;
                        g_displayMap[y*2][(x*2)+1] = 93;
                        g_displayMap[(y*2)+1][x*2] = 94;
                        g_displayMap[(y*2)+1][(x*2)+1] = 95;
                    }
                    break;
                case NeSW_PIECE:
                    if(g_playfield[x][y].bLinked){
                        g_displayMap[y*2][x*2] = 224;
                        g_displayMap[y*2][(x*2)+1] = 225;
                        g_displayMap[(y*2)+1][x*2] = 226;
                        g_displayMap[(y*2)+1][(x*2)+1] = 227;
                    }else{
                        g_displayMap[y*2][x*2] = 96;
                        g_displayMap[y*2][(x*2)+1] = 97;
                        g_displayMap[(y*2)+1][x*2] = 98;
                        g_displayMap[(y*2)+1][(x*2)+1] = 99;
                    }
                    break;
                case NSeW_PIECE:
                    if(g_playfield[x][y].bLinked){
                        g_displayMap[y*2][x*2] = 228;
                        g_displayMap[y*2][(x*2)+1] = 229;
                        g_displayMap[(y*2)+1][x*2] = 230;
                        g_displayMap[(y*2)+1][(x*2)+1] = 231;
                    }else{
                        g_displayMap[y*2][x*2] = 100;
                        g_displayMap[y*2][(x*2)+1] = 101;
                        g_displayMap[(y*2)+1][x*2] = 102;
                        g_displayMap[(y*2)+1][(x*2)+1] = 103;
                    }
                    break;
                case ESW_PIECE:
                    if(g_playfield[x][y].bLinked){
                        g_displayMap[y*2][x*2] = 232;
                        g_displayMap[y*2][(x*2)+1] = 233;
                        g_displayMap[(y*2)+1][x*2] = 234;
                        g_displayMap[(y*2)+1][(x*2)+1] = 235;
                    }else{
                        g_displayMap[y*2][x*2] = 104;
                        g_displayMap[y*2][(x*2)+1] = 105;
                        g_displayMap[(y*2)+1][x*2] = 106;
                        g_displayMap[(y*2)+1][(x*2)+1] = 107;
                    }
                    break;
                case NSW_PIECE:
                    if(g_playfield[x][y].bLinked){
                        g_displayMap[y*2][x*2] = 236;
                        g_displayMap[y*2][(x*2)+1] = 237;
                        g_displayMap[(y*2)+1][x*2] = 238;
                        g_displayMap[(y*2)+1][(x*2)+1] = 239;
                    }else{
                        g_displayMap[y*2][x*2] = 108;
                        g_displayMap[y*2][(x*2)+1] = 109;
                        g_displayMap[(y*2)+1][x*2] = 110;
                        g_displayMap[(y*2)+1][(x*2)+1] = 111;
                    }
                    break;
                case NEW_PIECE:
                    if(g_playfield[x][y].bLinked){
                        g_displayMap[y*2][x*2] = 240;
                        g_displayMap[y*2][(x*2)+1] = 241;
                        g_displayMap[(y*2)+1][x*2] = 242;
                        g_displayMap[(y*2)+1][(x*2)+1] = 243;
                    }else{
                        g_displayMap[y*2][x*2] = 112;
                        g_displayMap[y*2][(x*2)+1] = 113;
                        g_displayMap[(y*2)+1][x*2] = 114;
                        g_displayMap[(y*2)+1][(x*2)+1] = 115;
                    }
                    break;
                case NES_PIECE:
                    if(g_playfield[x][y].bLinked){
                        g_displayMap[y*2][x*2] = 244;
                        g_displayMap[y*2][(x*2)+1] = 245;
                        g_displayMap[(y*2)+1][x*2] = 246;
                        g_displayMap[(y*2)+1][(x*2)+1] = 247;
                    }else{
                        g_displayMap[y*2][x*2] = 116;
                        g_displayMap[y*2][(x*2)+1] = 117;
                        g_displayMap[(y*2)+1][x*2] = 118;
                        g_displayMap[(y*2)+1][(x*2)+1] = 119;
                    }
                    break;
                case NeSw_PIECE:
                    if(g_playfield[x][y].bLinked){
                        g_displayMap[y*2][x*2] = 248;
                        g_displayMap[y*2][(x*2)+1] = 249;
                        g_displayMap[(y*2)+1][x*2] = 250;
                        g_displayMap[(y*2)+1][(x*2)+1] = 251;
                    }else{
                        g_displayMap[y*2][x*2] = 120;
                        g_displayMap[y*2][(x*2)+1] = 121;
                        g_displayMap[(y*2)+1][x*2] = 122;
                        g_displayMap[(y*2)+1][(x*2)+1] = 123;
                    }
                    break;
                case NwSe_PIECE:
                    if(g_playfield[x][y].bLinked){
                        g_displayMap[y*2][x*2] = 252;
                        g_displayMap[y*2][(x*2)+1] = 253;
                        g_displayMap[(y*2)+1][x*2] = 254;
                        g_displayMap[(y*2)+1][(x*2)+1] = 255;
                    }else{
                        g_displayMap[y*2][x*2] = 124;
                        g_displayMap[y*2][(x*2)+1] = 125;
                        g_displayMap[(y*2)+1][x*2] = 126;
                        g_displayMap[(y*2)+1][(x*2)+1] = 127;
                    }
                    break;
                case LINKER:
                    g_displayMap[y*2][x*2] = 128;
                    g_displayMap[y*2][(x*2)+1] = 129;
                    g_displayMap[(y*2)+1][x*2] = 130;
                    g_displayMap[(y*2)+1][(x*2)+1] = 131;
                    break;
            }
        }
    }

    map_fragment_info_ptr map;
    map = ham_InitMapFragment(&g_displayMap, PLAYFIELD_WIDTH*2, PLAYFIELD_HEIGHT*2, 0, 0, PLAYFIELD_WIDTH*2, PLAYFIELD_HEIGHT*2, 0);
    ham_InsertMapFragment(map,0,0,0);
    ham_InitBg(0, 1, 3, 0);
    
    //update cursor
    ham_SetObjX(g_cursorGfx, g_cursor.x*16);
    ham_SetObjY(g_cursorGfx, g_cursor.y*16);
    ham_CopyObjToOAM();
}

void gameover() {
  u8 goSprite;
  u8 y;
  u16 t;
  M_TIM0CNT_TIMER_STOP
  ham_DrawText(20,3, "0:00");
  y = 0; 
  goSprite = ham_CreateObj(&gameover_Bitmap,1,3,OBJ_MODE_NORMAL,1,0,0,0,0,0,0,165,223);
  ham_CopyObjToOAM();
  while(y != 80){
    t = 0;
    while(t != 1024*8){t++;} //stupid hack to slow down the scrolling of the gameover sprite
    ham_SetObjY(goSprite,y+223);
    ham_CopyObjToOAM();
    y++;
  }
  ham_DeleteObj(goSprite);
  
  ham_DrawText(18,10, "Press start");
  ham_DrawText(18,11, "to replay.");

  while(getKeyState() != GS_PAUSE){}

  ham_DrawText(18,10, "           ");
  ham_DrawText(18,11, "          ");

//restart every thing
  M_TIM0CNT_TIMER_START
  
  start_game();
}
/* END OF FILE */
