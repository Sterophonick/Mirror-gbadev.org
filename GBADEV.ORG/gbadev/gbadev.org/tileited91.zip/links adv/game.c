#include "game.h"

/*
* g_playfield[0][0] will be the top-left corner of the playing field.
*/
void createPlayfield() {
  int x,y;
  for(x = 0; x < PLAYFIELD_WIDTH; x++) {
    for(y = 0; y < PLAYFIELD_HEIGHT; y++) {
      g_playfield[x][y].bLinked = 0;
      if(x == 0 || x == PLAYFIELD_WIDTH-1 || y == PLAYFIELD_HEIGHT-1) {
        //clear the left, bottom, and right most areas to create a border of null space
        g_playfield[x][y].piece = NULLSPACE;
      }else{
        g_playfield[x][y].piece = randomPiece();
      }
    }
  }

//for right now, we statically put in the LINKERS
  newLinkers();
}

/* As each direction on a game piece is represented by a bit, all
 * that needs to be done is to shift the bits over to the right twice
 */
void rotatePiece(xyPos* p_xy) {
  //invalidate piece
  g_playfield[p_xy->x][p_xy->y].bLinked = 0;

  //since it seems we can't rotate bits (bits that "fall off" during the shift appear
  // on the opposite side they fell off), we'll have to cheat

  //save the 2 least sig fig
  u8 savedBits = g_playfield[p_xy->x][p_xy->y].piece & 0x03;
  //shift the bits so they are now the most sig figs
  savedBits <<= 6;
  //now shift the gamepiece bits to make room for the saved bits
  g_playfield[p_xy->x][p_xy->y].piece >>= 2;
  //place the new piece into the playfield
  g_playfield[p_xy->x][p_xy->y].piece += savedBits;
}
/* */
void newLinkers() {
  //remove old linkers from playfield
  g_playfield[g_linkerPos[0].x][g_linkerPos[0].y].piece = NULL;
  g_playfield[g_linkerPos[1].x][g_linkerPos[1].y].piece = NULL;
  
  g_linkerPos[0].y = rand()%(PLAYFIELD_HEIGHT-1);
  if(g_linkerPos[0].y == (PLAYFIELD_HEIGHT-1)) {
    g_linkerPos[0].x = rand()%(PLAYFIELD_WIDTH-1);
  }else{
    g_linkerPos[0].x = rand()%2?0:PLAYFIELD_WIDTH-1;
  }
  
  do {
      g_linkerPos[1].y = rand()%(PLAYFIELD_HEIGHT-1);
    if(g_linkerPos[1].y == (PLAYFIELD_HEIGHT-1)) {
      g_linkerPos[1].x = rand()%(PLAYFIELD_WIDTH-1);
    }else{
      g_linkerPos[1].x = rand()%2?0:PLAYFIELD_WIDTH-1;
    }
  }while((g_linkerPos[0].x == g_linkerPos[1].x) && (g_linkerPos[0].y == g_linkerPos[1].y));
  
  //add new linkers to playfield
 // ham_DrawText(0,10, "%d,%d", g_linkerPos[0].x, g_linkerPos[0].y);
  //ham_DrawText(0,11, "%d,%d", g_linkerPos[1].x, g_linkerPos[1].y);
  g_playfield[g_linkerPos[0].x][g_linkerPos[0].y].piece = LINKER;
  g_playfield[g_linkerPos[1].x][g_linkerPos[1].y].piece = LINKER;
}

/*
 * p_xy: position of the current selected tile
 * DirMove: which direction to swith piece
 */
void replacePiece(xyPos* p_xy, DirMove moveTo){
    switch(moveTo) {
        case DIR_UP:
            //nake sure we are not "leaving" the playfield.
            if(p_xy->y == 0){
            }else{
                playfield tmp;
                tmp = g_playfield[p_xy->x][p_xy->y-1];
                g_playfield[p_xy->x][p_xy->y -1] = g_playfield[p_xy->x][p_xy->y];
                g_playfield[p_xy->x][p_xy->y] = tmp;
            }
            break;
        case DIR_DOWN:
            //make sure we are not entering the "restricted" zone
            if(p_xy->y == PLAYFIELD_HEIGHT - 2){
            }else{
                playfield tmp;
                tmp = g_playfield[p_xy->x][p_xy->y+1];
                g_playfield[p_xy->x][p_xy->y+1] = g_playfield[p_xy->x][p_xy->y];
                g_playfield[p_xy->x][p_xy->y] = tmp;
            }
            break;
        case DIR_LEFT:
            //make sure we are not entering the "restricted" zone
            if(p_xy->x == 1){
            }else{
                playfield tmp;
                tmp = g_playfield[p_xy->x-1][p_xy->y];
                g_playfield[p_xy->x-1][p_xy->y] = g_playfield[p_xy->x][p_xy->y];
                g_playfield[p_xy->x][p_xy->y] = tmp;
            }
            break;
        case DIR_RIGHT:
            //make sure we are not entering the "restricted" zone
            if(p_xy->x == PLAYFIELD_WIDTH-2){
            }else{
                playfield tmp;
                tmp = g_playfield[p_xy->x+1][p_xy->y];
                g_playfield[p_xy->x+1][p_xy->y] = g_playfield[p_xy->x][p_xy->y];
                g_playfield[p_xy->x][p_xy->y] = tmp;
            }
            break;
    }
}

/*
 * When we move the cursor around the playfield, we want to make sure it doesn't go
 * into the "restricted" areas where the linkers reside.
 */
void moveCursor(xyPos* cursor, DirMove moveTo) {
    switch(moveTo) {
        case DIR_UP:
            if(cursor->y == 0){
            }else{
                cursor->y -= 1;
            }
            break;
        case DIR_DOWN:
            if(cursor->y == PLAYFIELD_HEIGHT - 2){
            }else{
                cursor->y += 1;
            }
            break;
        case DIR_LEFT:
            if(cursor->x == 1){
            }else{
                cursor->x -= 1;
            }
            break;
        case DIR_RIGHT:
            if(cursor->x == PLAYFIELD_WIDTH - 2){
            }else{
                cursor->x += 1;
            }
    }
}

/*
 * evaluateLinks is THE function that determines all the tiles that are linked to each other.
 * Before this function is used, make sure that the playfield .blinked data is zeroed out.
 */
u8 evaluateLinks(xyPos* curLink) {
  u8 curPiece = g_playfield[curLink->x][curLink->y].piece;
  u8 retVal = 0; //our return value, if 1 we have a path between linkers
  s8 x,y;
  
  //link current piece
  g_playfield[curLink->x][curLink->y].bLinked = 1;
  
  for(x = -1; x < 2; x++){
    for(y = -1; y < 2; y++){
      //is the piece we are looking at valid
      if((curLink->x+x > PLAYFIELD_WIDTH-1) ||(curLink->y+y > PLAYFIELD_HEIGHT-1)) {
      }else{
          u8 bLinked;
          u8 nxtPiece;
          xyPos nxtPos;
          bLinked = 0;
          nxtPos.x = curLink->x+x;
          nxtPos.y = curLink->y+y;
          nxtPiece = g_playfield[nxtPos.x][nxtPos.y].piece;
          
          if(g_playfield[nxtPos.x][nxtPos.y].bLinked != 1) {
            if((x == -1) && (y == -1)){ //north west
              if((curPiece & 0x01 || curPiece == LINKER) && (nxtPiece & 0x10 || nxtPiece == LINKER)){
                bLinked = 1;
              }
            }else if ((x == -1) && (y == 0)){ // west
              if((curPiece & 0x02 || curPiece == LINKER) && (nxtPiece & 0x20 || nxtPiece == LINKER)){
                bLinked = 1;
              }
            }else if ((x == -1) && (y == 1)){ //south west
              if((curPiece & 0x04 || curPiece == LINKER) && (nxtPiece & 0x40 || nxtPiece == LINKER)){
                bLinked = 1;
              }
            }else if ((x == 0) && (y == -1)){ //north
              if((curPiece & 0x80 || curPiece == LINKER) && (nxtPiece & 0x08  || nxtPiece == LINKER)){
                bLinked = 1;
              }
            }else if ((x == 0) && (y == 0)){  //center
              //do nothing
            }else if ((x == 0) && (y == 1)){  //south
              if((curPiece & 0x08 || curPiece == LINKER) && (nxtPiece & 0x80 || nxtPiece == LINKER)){
                bLinked = 1;
              }
            }else if ((x == 1) && (y == -1)){  //north east
              if((curPiece & 0x40 || curPiece == LINKER) && (nxtPiece & 0x04 || nxtPiece == LINKER)){
                bLinked = 1;
              }
            }else if ((x == 1) && (y == 0)){ //east
              if((curPiece & 0x20 || curPiece == LINKER) && (nxtPiece & 0x02 || nxtPiece == LINKER)) {
                bLinked = 1;
              }
            }else if ((x == 1) && (y == 1)){  //south east
              if((curPiece & 0x10 || curPiece == LINKER) && (nxtPiece & 0x01 || nxtPiece == LINKER)) {
                bLinked = 1;
              }
            }
            
            if(bLinked == 1){
              if(nxtPiece == LINKER) { return 1;}
                if(retVal == 0) { retVal = evaluateLinks(&nxtPos); }else{ evaluateLinks(&nxtPos); }
            }
          }
        }
        
    } //end for y
  } //end for x
  
  return retVal;
}

u8 randomPiece() {
    u8 rnd1;
    u8 rnd2;
    rnd1 = rand()%9; //this gives us a number between 0-8 (there are 9 'sets' of tiles)

    switch(rnd1) {
        case 0: //nonrotatable set 0
            rnd2 = rand()%3;
            if(rnd2 == 0) {
                return ALL_PIECE;
            }else if(rnd2 == 1){
                return NeSeSwNw_PIECE;
            }else{
                return NESW_PIECE;
            }
            break;
        case 1:  //rotatable set 1
            rnd2 = rand()%2;
            if(rnd2 == 0) {
                return NS_PIECE;
            }else{
                return EW_PIECE;
            }
            break;
        case 2: //rotatable set 2
            rnd2 = rand()%4;
            if(rnd2 == 0) {
                return NNeSNw_PIECE;
            }else if(rnd2 == 1){
                return NeESeW_PIECE;
            }else if(rnd2 == 2){
                return NSeSSw_PIECE;
            }else{
                return ESwWNw_PIECE;
            }
            break;
        case 3: //rotatable set 3
            rnd2 = rand()%4;
            if(rnd2 == 0) {
                return SW_PIECE;
            }else if(rnd2 == 1){
                return NW_PIECE;
            }else if(rnd2 == 2){
                return NE_PIECE;
            }else{
                return ES_PIECE;
            }
            break;
        case 4: //rotatable set 4
            rnd2 = rand()%4;
            if(rnd2 == 0) {
                return SSwW_PIECE;
            }else if(rnd2 == 1){
                return NWNw_PIECE;
            }else if(rnd2 == 2){
                return NNeE_PIECE;
            }else{
                return ESeS_PIECE;
            }
            break;
        case 5: //rotatable set 5
            rnd2 = rand()%4;
            if(rnd2 == 0) {
                return NeSNw_PIECE;
            }else if(rnd2 == 1){
                return NeSeW_PIECE;
            }else if(rnd2 == 2){
                return NSeSw_PIECE;
            }else{
                return ESwNw_PIECE;
            }
            break;
        case 6: //rotatable set 6
            rnd2 = rand()%4;
            if(rnd2 == 0) {
                return NESw_PIECE;
            }else if(rnd2 == 1){
                return ESNw_PIECE;
            }else if(rnd2 == 2){
                return NeSW_PIECE;
            }else{
                return NSeW_PIECE;
            }
            break;
        case 7: //rotatable set 7
            rnd2 = rand()%4;
            if(rnd2 == 0) {
                return ESW_PIECE;
            }else if(rnd2 == 1){
                return NSW_PIECE;
            }else if(rnd2 == 2){
                return NEW_PIECE;
            }else{
                return NES_PIECE;
            }
            break;
        case 8:
            rnd2 = rand()%4;
            if(rnd2 == 0) {
                return NeSw_PIECE;
            }else{
                return NwSe_PIECE;
            }
            break;
        default:
            return NULLSPACE;
            break;
    }
    return NULLSPACE;
}

/*
* delink goes through the playfield, finds all of the linked pieces, adds them up and replaces them
* with new pieces
* return value is the score recieved
*/
u32 delink() {
  u8 x;
  u8 y;
  u32 retVal = 0;

  for(x = 0; x < PLAYFIELD_WIDTH; x++){
    for(y = 0; y < PLAYFIELD_HEIGHT; y++) {
      if(g_playfield[x][y].piece != LINKER) {
        if(g_playfield[x][y].bLinked){
          g_playfield[x][y].piece = randomPiece();
          g_playfield[x][y].bLinked=0;
          retVal += 100;
        }
      }
    }
  }
  
  return retVal;
}

