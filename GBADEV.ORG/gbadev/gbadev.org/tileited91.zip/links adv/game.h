#ifndef GAME_LINKS
#define GAME_LINKS

#include "mygba.h"

//key state definitions. while in game
#define GS_NOTHING      0    //no keys pressed
#define GS_SEL_TILE     1    //B pressed
#define GS_RPLC_UP      2    //B + UP
#define GS_RPLC_DOWN    3    //B + DOWN
#define GS_RPLC_LEFT    4    //B + LEFT
#define GS_RPLC_RIGHT   5    //B + RIGHT
#define GS_ROTATE       6    //A pressed
#define GS_MVCUR_UP     7    //up pressed
#define GS_MVCUR_DOWN   8    //down pressed
#define GS_MVCUR_LEFT   9    //left pressed
#define GS_MVCUR_RIGHT  10   //right pressed
#define GS_EXIT         11   //select pressed
#define GS_PAUSE        12   //start pressed

//xyPos used to store an items x and y position
typedef struct {
    u8 x;
    u8 y;
}xyPos;

enum bonus {bnNone, bnPlus, bnMinus, bnTimePlus, bnMulti};

//playfield struct
typedef struct {
    u8 piece;
    u8 bLinked; //0 = not linked, 1 = linked to a linker
    u8 bonus;
} playfield;

/*
game pieces for board.
All piece rotate in a clockwise fasion
The prefix tells what directions it connects:
N-north S-south E-east W-west Ne-northEast Se-southEast Nw-northWest Sw-Southwest

As there are 8 directions and 8 bits in a byte, each individual bit represents a direction.
From most sig fig bit to least, the directions go (N,Ne,E,Se,S,Sw,W,Nw)
As all link pieces will have at least two link sides (two 1 bits), values 0 and 1 are
used as a NULLSPACE and LINKER respectivly.
*/

#define NULLSPACE 0         //nothing in this space
#define LINKER 1           //the items that need to be "linked"

//nonrotatable set
#define ALL_PIECE  255        //value in binary = 11111111
#define NeSeSwNw_PIECE 85     //value in binary = 01010101
#define NESW_PIECE 170        //value in binary = 10101010
//rotatable set 1
#define NS_PIECE 136          //value in binary = 10001000
#define EW_PIECE 34           //value in binary = 00100010
//rotatable set 2
#define NNeSNw_PIECE 201      //value in binary = 11001001
#define NeESeW_PIECE 114      //value in binary = 01110010
#define NSeSSw_PIECE 156      //value in binary = 10011100
#define ESwWNw_PIECE 39       //value in binary = 00100111
//rotatable set 3
#define SW_PIECE 10           //value in binary = 00001010
#define NW_PIECE 130          //value in binary = 10000010
#define NE_PIECE 160          //value in binary = 10100000
#define ES_PIECE 40           //value in binary = 00101000
//rotatable set 4
#define SSwW_PIECE 14         //value in binary = 00001110
#define NWNw_PIECE 131        //value in binary = 10000011
#define NNeE_PIECE 224        //value in binary = 11100000
#define ESeS_PIECE 56         //value in binary = 00111000
//rotatable set 5
#define NeSNw_PIECE 73        //value in binary = 01001001
#define NeSeW_PIECE 82        //value in binary = 01010010
#define NSeSw_PIECE 148       //value in binary = 10010100
#define ESwNw_PIECE 37        //value in binary = 00100101
//rotatable set 6
#define NESw_PIECE 164        //value in binary = 10100100
#define ESNw_PIECE 41         //value in binary = 00101001
#define NeSW_PIECE 74         //value in binary = 01001010
#define NSeW_PIECE 146        //value in binary = 10010010
//rotatable set 7
#define ESW_PIECE 42          //value in binary = 00101010
#define NSW_PIECE 138         //value in binary = 10001010
#define NEW_PIECE 162         //value in binary = 10100010
#define NES_PIECE 168         //value in binary = 10101000
//rotatable set 8
#define NeSw_PIECE 68         //value in binary = 01000100
#define NwSe_PIECE 17         //value in binary = 00010001




#define PLAYFIELD_WIDTH 9
#define PLAYFIELD_HEIGHT 9

typedef enum {
  DIR_UP = 0,
  DIR_DOWN,
  DIR_LEFT,
  DIR_RIGHT
}DirMove;

//game variables
playfield g_playfield[PLAYFIELD_WIDTH][PLAYFIELD_HEIGHT];
xyPos g_curserPos;  //cursor position on playfield.
xyPos g_linkerPos[2];  //for the moment we will only have two linkers
u32 g_score;

void createPlayfield();
void replacePiece(xyPos*, DirMove);
void moveCursor(xyPos*, DirMove);
void rotatePiece(xyPos*);
u8 evaluateLinks(xyPos*);  //determines wether linkers have been linked
u8 randomPiece();
u32 delink();
void newLinkers();
#endif
