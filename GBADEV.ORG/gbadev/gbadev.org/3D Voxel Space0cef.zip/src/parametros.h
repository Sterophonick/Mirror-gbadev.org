//Solo los usa el generador
#define varbaja 256
#define varalta 64

//Los usa el generador y el ROM
#define minstep 8
#define maxstep 512

#define minaltura 32
#define stepaltura 10
#define numalturas 16

#define MODE5_HEIGHT 128
#define MODE5_WIDTH 160

//Solo los usa el ROM



