extern const u8 rawprof[];
extern const u16 rawcolor[];
extern const u16 rawback[];
extern const u8 matrizalturas[];
extern const u16 matrizx[];
