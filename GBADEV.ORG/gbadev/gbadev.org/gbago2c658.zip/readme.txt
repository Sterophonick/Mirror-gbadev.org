----------------------------------------------------------------------
   
GBAGO v2.0
Copyright (C) 2003 by Scott E. Lininger <scott@scottlininger.com>

Based on GNUGO 1.2
(c) Free Software Foundation (FSF)
http://www.gnu.org/software/gnugo/gnugo.html

----------------------------------------------------------------------

This program is free software; you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation; either version 2 of the License, or
(at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.

----------------------------------------------------------------------

TO COMPILE:

Get the source code file from www.thingker.com.

Run the three batch files at the top of the top directory, and if you're
lucky it will compile. 

	1-BuildGnuGoFirst.bat
	2-ThenBuildTheRest.cmd
	3-FinallyCleanupFiles.bat

(Sorry, I'm still learning all this makefile stuff, so it might be a 
bit hairy for you.) If you happen to be a makefile guru who can build 
me a better option, I'd be grateful!

Now, you will definitely need Krawall to compile this thing, unless
you want to go in and comment out all Krawall-related stuff.

http://mind.riot.org/krawall/

----------------------------------------------------------------------

Much thanks go out to Skaven, who writes wonderful music and makes it
available for free! http://www.futurecrew.com/skaven/












