Racer V2.0 Readme file
By Premandrake
Homepage: http://www.fortunecity.com/rivendell/soldier/619/gba.html
Email: premandrake@hotmail.com

Introduction
------------

It's been a very long time since I released the original racer, this one has been
sitting on my hard drive for a year, was cleaing stuff up and I figured I should
release it :).

I will release the source to this if there is sufficient interest, but it looks like
there is plenty of source out there already.

Keys are very simple:
Directional pad turns your car
A button accelerates
B button brakes

Features
--------

- Mode7-like track by using Mode 2 and HDMA
- Parrallax backgrounds
- Actual gameplay (ie. the number of coins you have effects turning and acceleration)
- Much improved collision detection
- Full sound engine (using direct sound)
	- Supports up to 32 dynamic channels, mixed at 22Khz, 16bits
	- Support for most xm effects

The default tune included with Racer is a nice final fantasy remix.  I'm sorry, but
I've lost the name of the file and author, if anyone recognizes it please let me know
and I'll be sure to list them here.

Map Editor
----------

Racer also comes with a simple editor to play around with, simply start racerConv.exe
and open the map.map file included and go to town.

Instructions:
- Arrow keys to move around map
- To place a block down click on the tile palette to select your tile then click 
  on the map.
- After creating a new map you will need to import a tileset, this can be any
  256x256x8 bitmap.  Try exporting the tileset after opening map.map to see what I mean.
- The export palette option takes a 256 color bmp and produces a .c file with the
  palette in an array.  This is mainly useful for programmers.
- The import bitmap option will let you automatically convert a bitmap into a map.  Be
  careful to not go over 224 tiles though, as I use the last few for the hills&trees you
  see in the background.

Greets
------

Jeff Frohwein - The page is incredible
#pratt crew
All members of #gbadev on EFNet (I'm there as gladius)