----------------------------------
             YAKUZA (2004)
    PC/GBA Demo Crew, est. 1991
           www.yakuza.de.be
----------------------------------

The second and last release for the
GBA.

Not finished. It was just a test of
Mode 3 - the only 15 Bit Color Mode
on a GBA. This mode doesn't support
hardware double buffering, and
because of its size (75k) you
can't use the fast iRam for the
software buffer. 
This makes this mode slow - and 
using it a challenge :-)

                   George Stark
---------------------------------- 