X BY Y BITMAP SCROLLER

*** Do not distribute this ROM without this README... ***


USE THE CURSOR KEYS TO SCROLL THE IMAGE.


8/Jun/2001
UPDATE : This demo has been tested on real hardware and now includes source code...


This is my third GBA demo.

Seeing how the Demo of Tony Hawk's Pro Skater 2 has really upped the ANTE graphically, I've decided to try to produce some graphics that wouldn't look out of place in a PC 2D game.  (At smaller resolutions of course!)

What I've produced is a fairly rough little demo which allows a bitmap of any size to be scrolled around
the screen, using memory managment techniques.  DMAing in tiles from ROM as they are needed.  Even without any optimisation it runs quite smoothly and swiftly.  Every now and then it distorts, but nothing that a little tidying up wouldn't fix.

As you can see, the engine does not rely on duplicate tiles and repeating patterns.  And therefore should be fantasic for producing some amazing in game graphics.

Thanks to all source code contributors who I've borrowed lots of little pieces.  Thanks all.

Also thanks again Matt Tighe for the PCX2GBA program and also to AGENTQ for his technical documentation.

As always, "A game will be coming soon, I promise!"  HA!




The_Letter_M
hallmb@yahoo.com