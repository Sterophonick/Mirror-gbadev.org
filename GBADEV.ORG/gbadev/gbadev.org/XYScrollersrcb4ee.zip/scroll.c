//---------------------------------------------//
//  Full Screen Scroller by The_Letter_M       //
//  Adapted for GBA Real Hardware 8/Jun/2001   //
//  Email:hallmb@yahoo.com                     //
//---------------------------------------------//



#include "gba.h"     // defines the GBA registers
#include "savage.h"  //
#include "block.h"    // contains a graphic split into 32x16 blocks for DMAing

#define image_width 480
#define image_height 592

#define image_block_width 15  // number of blocks across for the image
#define image_block_height 37 // number of blocks down for the image

#define block_size_x 4   // each block is 4 tiles across
#define block_size_y 2   // each block is 2 tiles down

#define screen_width 240
#define screen_height 160

#define block_screen_x 9  // number of blocks across the screen to display
#define block_screen_y 11  // number of blocks down the screen to display


// declaration of global variables
int x_offset, y_offset, delta_x, delta_y;
int current_buffer, back_buffer;  // current buffer being displayed
u16 block_map[2][9][11];   // 2 buffers, 10 blocks across, 12 blocks down...  NOT SURE ABOUT THIS...
u16 buffer_position[2][2]; // 2 buffers, x and y position

// declaration of VRAM pointers
u16 *tpal=(u16*)0x05000000; // background palette pointer
u8 *tiles=(u8*)0x06000000; // tiles pointer
u16 *map0=(u16*)0x0600E000; // tile map pointer
//u16 *map0=(u16*)0x0600F000; // tile map pointer
//u16 *map0=(u16*)0x0600F800; // tile map pointer





#define DMA3SAD     *(u32*)0x040000d4   // Define DMA 3 Source
#define DMA3DAD     *(u32*)0x040000d8   // Define DMA 3 Destination
#define DMA3CNT     *(u32*)0x040000dc   // Define DMA 3 data amount


// VSYNC function by Eloist
void WaitForVSync()
{
  __asm
   {
    mov 	r0, #0x4000006
    scanline_wait:
     ldrh	r1, [r0]
     cmp	r1, #160
    bne 	scanline_wait
   }
}



void DMA3Call(u32* Src,u32* Dst,u32 Cnt)			
{
	DMA3SAD = (u32)Src;  
	DMA3DAD = (u32)Dst;  
	DMA3CNT = Cnt;       				
}




void InitBuffer(int btdx, int btdy)
// this procedure copies across the appropriate 9x11 block matrix into the specified buffer...
// x and y represent the BLOCK X and BLOCK Y.
{

  int i1,i2,x1,y1,x2,y2;

  int next_free_block;

  next_free_block = 0;

  for (y1=0;y1<block_screen_y;y1++) {
    for (x1=0;x1<block_screen_x;x1++) {
      
      // i1 contains the BLOCK NUMBER that is to be displayed
      i1 = ((y1+btdy) * image_block_width) + x1 + btdx;

      // instead of doing a direct DMA here, what we need to do is look up an array to see if the 
      // block is already in memory...
      // Note that I should be adapting to use all the DMA channels so that I use 1,2,3,1,2,3,...
      // but it works fine as is.  Will tune later if required....

      DMA3Call((u32*)blockBlk+16+(i1*128), (u32*)tiles+16+(next_free_block*128), (0x84000000 + (block_size_x*block_size_y*16)));

      // copy across the correct tile numbers into the tilemap
      i2 = 1 + (next_free_block*8);
      for (y2=0;y2<2;y2++) {
        for (x2=0;x2<4;x2++) {
          if ((x1*block_size_x) < 32) {
            map0[((y1*block_size_y)+y2)*32+(x1*block_size_x)+x2+(current_buffer*2048)] = i2;
          } 
          else {
            map0[((y1*block_size_y)+y2)*32+(x1*block_size_x)+x2+1024-32+(current_buffer*2048)] = i2;
          }
          i2++; 
        }
      }

      // store the block map away for later retrieval...
      block_map[current_buffer][x1][y1] = next_free_block;
      next_free_block++;

    }
  }

  buffer_position[current_buffer][0] = btdx;
  buffer_position[current_buffer][1] = btdy;

}


void MoveBuffer(int move_x, int move_y)
// this procedure draws the next scroll position into the spare buffer....
// be careful when calling this to ensure that the blocks that are going to be replaced
// are not being displayed on the screen at the time....

// assumption : move_x and move_y are -1,0,1.....

{


  int block_no,i1,x1,y1,x2,y2,x3,y3;
  int change_flag;



  // first update the buffer position variables

  buffer_position[back_buffer][0] = buffer_position[current_buffer][0] + move_x;
  buffer_position[back_buffer][1] = buffer_position[current_buffer][1] + move_y;



  // first off we've got to update the block_map data structure...
  
  for (y1=0;y1<block_screen_y;y1++) {
    for (x1=0;x1<block_screen_x;x1++) {

      change_flag = 0;
      
      x2 = x1 - move_x;
      if (x2 < 0) {
        x2 = x2 + block_screen_x;
        change_flag = 1;
      };

      if (x2 >= block_screen_x) {
        x2 = x2 - block_screen_x;
        change_flag = 1;
      };

      y2 = y1 - move_y;
      if (y2 < 0) {
        y2 = y2 + block_screen_y;
        change_flag = 1;
      };
      if (y2 >= block_screen_y) {
        y2 = y2 - block_screen_y;
        change_flag = 1;
      };

      block_map[back_buffer][x2][y2] = block_map[current_buffer][x1][y1];

      

      // copy across the correct tile numbers into the tilemap


      block_no = 1 + (block_map[back_buffer][x2][y2]*8);


      for (y3=0;y3<2;y3++) {
        for (x3=0;x3<4;x3++) {
          if ((x2*block_size_x) < 32) {
            map0[((y2*block_size_y)+y3)*32+(x2*block_size_x)+x3+(back_buffer*2048)] = block_no;
          } 
          else {
            map0[((y2*block_size_y)+y3)*32+(x2*block_size_x)+x3+1024-32+(back_buffer*2048)] = block_no;
          }
          block_no++; 
        };
      };


      if (change_flag == 1) {
        i1 = ((y2+buffer_position[back_buffer][1]) * image_block_width) + x2 + buffer_position[back_buffer][0];
        DMA3Call((u32*)blockBlk+16+(i1*128), (u32*)tiles+16+(block_map[back_buffer][x2][y2]*128), (0x84000000 + (block_size_x*block_size_y*16)));
      };



    };
  };
}


void SwapBuffer()
{

  int temp;
  temp = current_buffer;
  current_buffer = back_buffer;
  back_buffer = temp;

}

void C_Entry()
{
  
  int i;
  int t1,t2;
  int current_level=0;
  int x,y;
  int move_x,move_y;
  int swap_buffer_flag;


  REG_BG0CNT =  0xC080 + 0x1C00;      // tiles @ x600F000, map @ x6000000, 64x64 tilemap
  REG_DISPCNT = 0x0140;	     // mode 0, display BG0 and NO sprites



  // Setup the palette
  // Note that I am not doing any palette swapping based on location
  // one 256 colour palette for the entire graphic.
  DMA3Call((u32*)blockPal, (u32*)tpal, 0x84000080);	

  // copy in tile 0,0 (the "blank" tile)
  DMA3Call((u32*)blockBlk, (u32*)tiles, (0x84000000 + 16));





  current_buffer = 0;
  back_buffer = 1;

  // initialise buffer 1 with the top left part of the graphic...
  InitBuffer(0, 0);

  x_offset = 0;
  y_offset = 0;
  delta_x = 0;
  delta_y = 0;


  while (1) {


    move_x = 0;
    move_y = 0;
    swap_buffer_flag = 0;

    if (!(REG_P1 & J_DOWN))     // down
    {
      REG_P1 |= J_DOWN;
      if (y_offset < (image_height-screen_height)) {
        y_offset++;
        delta_y++;
        if (delta_y >= 16) {
          delta_y = delta_y - 16;
          move_y = 1;
          swap_buffer_flag = 1;
        };
      }
    };


    if (!(REG_P1 & J_UP))     // up
    {
      REG_P1 |= J_UP;
      if (y_offset > 0) {
        y_offset--;
        delta_y--;
        if (delta_y < 0) {
          delta_y = delta_y + 16;
          move_y = -1;
          swap_buffer_flag = 1;
        }
      }
    };


    if (!(REG_P1 & J_RIGHT))     // down
    {
      REG_P1 |= J_RIGHT;
      if (x_offset < (image_width-screen_width)) {
        x_offset++;
        delta_x++;
        if (delta_x >= 32) {
          delta_x = delta_x - 32;
          move_x = 1;
          swap_buffer_flag = 1;
        };
      }
    };


    if (!(REG_P1 & J_LEFT))     // up
    {
      REG_P1 |= J_LEFT;
      if (x_offset > 0) {
        x_offset--;
        delta_x--;
        if (delta_x < 0) {
          delta_x = delta_x + 32;
          move_x = -1;
          swap_buffer_flag = 1;
        };
      }
    };
    

    WaitForVSync();



    if (swap_buffer_flag == 1) {
      MoveBuffer(move_x,move_y);
      SwapBuffer();
    }

    REG_BG0VOFS = delta_y  + (current_buffer*256);
    REG_BG0HOFS = delta_x;



  }


}