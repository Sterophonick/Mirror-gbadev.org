// Savage.h - Main Include File
// -------------------------------------------
// PCX2GBA Structure Definitions
// Copyright (C)Savage Development
// By Matthew Tighe

typedef struct gbaBlockHeader
{
	u8 dbType;		// Resource Type
	u8 dbFormat;		// Resource Format Flags
	u16 dwSize;		// Header size including extra header
	u32 ddLength;

	u16 dwWidth;		// Width of block (pixels)
	u16 dwHeight;		// Height
	u16 dwNumber;		// Number of blocks in resource
	u16 dwFlags;		// Flags ie colour depth

} BLKHEADER;

typedef struct gbaMapHeader
{
	u8 dbType;		// Resource Type
	u8 dbFormat;		// Resource Format Flags
	u16 dwSize;		// Header size including extra header.
	u32 ddLength;

	u16 dwWidth;		// Width of map (blocks)
	u16 dwHeight;		// Height
	u16 dwBlockSize;	// Size of blocks
	u16 dwFlags;		// Flags ie colour depth

} MAPHEADER;

typedef struct gbaPalHeader
{
	u8 dbType;		// Resource Type
	u8 dbFormat;		// Resource Format Flags
	u16 dwSize;		// Header size including extra header.
	u32 ddLength;		// Data length

	u16 dwColours;		// Number of colours in palette.

} PALHEADER;

#define RES_TYPE_BIN 0
#define RES_TYPE_BLOCKS 1
#define RES_TYPE_MAP 2
#define RES_TYPE_PALETTE 3

#define RES_FORMAT_RAW 0
#define RES_FORMAT_RLE 1

#define RES_PALLTTE_256 0
#define RES_PALETTE_16 1