
Virtual Ball Fighters Advance Demo 10/01/2003
XTeam Software Solution

www.xteamsoftware.com
info@xteamsoftware.com

-----------------------
STORY
-----------------------
Siggy, a skull- rock musician, is the organizer of a special event, The Virtual Ball Fighters Tournament with a grand prize of one million dollars. 

Only the one with the fastest reflexes will have a chance in a tetris like format, where you must align 3 or more balls of the same color. 
This will cause an explosion, which will cause damage to your opponent. Gain extra bonuses by exploding the balls with letters on them. Drain your opponent of all his energy and become the victor. 

-----------------------
FEATURES ( COMPLETE VERSION )
-----------------------

- 8 fighters with 8 backgrounds. 
- 1 or 2 Players 
- 6 Game Modes 
	( Single ) 
        ( 1 Vs 1 ) 
        ( Story ) 
        ( Battle ) 
        ( Survival ) 
        ( Time Dead ) 
        ( Mortal ) 

- 4 Difficult levels 
- 8 Artificial Intelligence Level 
- 10 Features for every Fighter 
	Name, Age, Job 
        Power ( The power of the blows ) 
        Speed ( The initial speed of the balls ) 
        Rotation ( The rotation speed and movement of the balls ) 
	Energy ( The starting energy ) 
        Intelligence ( Type of artificial intelligence ) 
        Luck ( The chance of receiving the bonus ) 
        Special ( Special ability of the character ) 

- 8 musics ( once for background ) + 3 musics on the game 
- Over 2.5 Mb of Incredible animations. 
- More than 100 frames of animation for every fighter. 
- Very intuitive control method. 