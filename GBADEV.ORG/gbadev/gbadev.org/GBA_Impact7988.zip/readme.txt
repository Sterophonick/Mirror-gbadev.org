title: space impact clone
version: 0.6
coded by: gener gabasa

controls:
  d-pad = move up/down/left/right
  a = shoot
