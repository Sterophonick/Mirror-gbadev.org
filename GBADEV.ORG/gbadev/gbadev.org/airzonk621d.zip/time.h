;macro for gba timing
;By: Andrew Holbrook
;when inputing milliseconds use 66 for 1 millisecond, 65535 is about 1 second.
@macro Wait Seconds,milliseconds, arglabel, arglabel2
ldr r0,= Seconds

ldr r4,=0x400010A
ldr r5,=(2|128)
strh r5,[r4]

ldr r4,= 0x400010E
ldr r5,= (4|128)
strh r5,[r4]

ldr r3,= 0x400010C

arglabel
ldrh r4,[r3]
cmp r4,r0
BLT arglabel


ldr r5,=milliseconds
ldr r3,=0x4000108
ldr r4,=0
strh r4,[r3]
arglabel2
ldrh r4,[r3]
cmp r4,r5
BLT arglabel2


ldr r4,=0x400010A
ldr r5,=0
strh r5,[r4]
ldr r4,= 0x400010E
strh r5,[r4]
ldr r4,=0x400010C
strh r5,[r4]
ldr r4,=0x4000108
strh r5,[r4]

@endm

