:Programmed By: Andrew Holbrook

Character sprites were taken from Air Zonk... the rest is mine :P.

This game is the result of me messing around with gba assembly... hope it comes in handy!

I'll be happy to answer any questions!

E-Mail: songokuru2@yahoo.com