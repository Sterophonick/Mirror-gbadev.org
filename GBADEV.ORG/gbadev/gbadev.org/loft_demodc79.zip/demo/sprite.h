#ifndef HEADER_SPRITE
#define HEADER_SPRITE

//Atribute0 stuff
#define ROTATION_FLAG 		0x100
#define SIZE_DOUBLE		0x200
#define MODE_NORMAL     	0x0
#define MODE_TRANSPARENT	0x400
#define MODE_WINDOWED		0x800
#define MOSAIC			0x1000
#define COLOR_16		0x0000
#define COLOR_256		0x2000
#define SQUARE			0x0
#define TALL			0x8000
#define WIDE			0x4000
	
//Atribute1 stuff
#define ROTDATA(n)		((n) << 9)
#define HORIZONTAL_FLIP		0x1000
#define VERTICAL_FLIP		0x2000
#define SIZE_8			0x0
#define SIZE_16			0x4000
#define SIZE_32			0x8000
#define SIZE_64			0xC000

//atribute2 stuff

#define PRIORITY(n)		((n) << 10)
#define PALETTE(n)		((n) << 12)


typedef struct tagOAMEntry
{
	u16 attribute0;
	u16 attribute1;
	u16 attribute2;
	u16 attribute3;
}OAMEntry,*pOAMEntry;

typedef struct tagRotData
{
		
	u16 filler1[3];
	u16 pa;

	u16 filler2[3];
	u16 pb;	
		
	u16 filler3[3];
	u16 pc;	

	u16 filler4[3];
	u16 pd;
}RotData,*pRotData;


/********************************************/
volatile u16* OAM;
pOAMEntry sprites;

void initSprites (pOAMEntry);
void syncOAMWith (pOAMEntry);
 
u8   sprite_available [MAX_SPRITES];
 
u8   next_sprite     (int look);
void suppress_sprite (u8 index);

/*****************************************/
typedef struct {
    s16       x;
    s16       y;
    s16       sx;
    s16       sy;
    u8        index;
    thread_t *behaviors;
    u8        behav_num;
    event_t   destroy;
    u8        dead;
}
struct_sprite_t, *sprite_t;

sprite_t  new_sprite          (s16 speed,int look);
void      alloc_behaviors     (sprite_t,u8);
void      suspend_sprite      (sprite_t);
void      resume_sprite       (sprite_t);
void      kill_sprite         (sprite_t);
int       dist2               (sprite_t,sprite_t);

extern module inertia,
              bounce_on_borders,
              sync_sprite,
              destroy_sprite,
              collide,
              friction,
              move;

void go_right (sprite_t,s16);
void go_left  (sprite_t,s16);
void go_up    (sprite_t,s16);
void go_down  (sprite_t,s16);

#endif
