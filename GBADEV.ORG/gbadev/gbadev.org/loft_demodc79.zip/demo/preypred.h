extern module predator, prey;

extern int max_pred_speed;
extern int kill_dist2;
extern int predator_visibility;
extern int pred_run_step;

extern int max_prey_speed;
extern int prey_visibility;
extern int prey_run_step;

