This is a demo of a prey-predator for the gba. 
It has been tested with VisualBoyAdvance running on Linux
(executable: demo.gba).

------------------------------------------------------------------
- Predator moves using the arrow keys. New preys are automatically created.
- Predator is put in an automatic chasing mode with key 'a' (z) 
  and put in manual mode with 'b' (x).
- More predators can be created with 'l' (a), and more preys with 'r' (s).

------------------------------------------------------------------
The various files are described in content.txt. Some come from dovoto :
www.agbdev.net/thePERNproject. Many thanks to him !
See its tutorial for introduction to the gba. 

------------------------------------------------------------------
The purpose of the demo is to investigate the use of concurrent 
programming for embedded system, such as the gba. More precisely, 
one uses "FairThreads" which is a special case of thread-based 
framework. Basic information on FairThreads can be found at
http://www.inria.fr/mimosa/rp/FairThreads.
For coding the demo, one uses a variant of FairThreads called LOFT. 
LOFT is briefly described in the file loft.txt.

------------------------------------------------------------------
Contact and feedback: frederic.boussinot@sophia.inria.fr

------------------------------------------------------------------
Acknowledgments:
dovoto@thepernproject.com, 
jean-ferdy.susini@emn.fr, 
damien.ciabrini@sophia.inria.fr
