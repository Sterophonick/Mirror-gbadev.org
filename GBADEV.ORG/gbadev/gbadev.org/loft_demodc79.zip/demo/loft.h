#include <stdlib.h>
#ifndef NULL
#define NULL 0
#endif

typedef char (*automaton_t)();

/**********************************/
typedef struct item_cell_t
{
  void                *item;
  struct item_cell_t  *next;
}
*item_cell_t;


typedef struct item_list_t
{
  int                 length;
  item_cell_t         first;
  item_cell_t         last;
}
*item_list_t;

/**********************************/
typedef struct _broadcast_t
{
  struct _event_t    *event;
  int                 pure;
  void               *value;
}
*broadcast_t;


/**************** API *************/
typedef struct _thread_t *thread_t;

typedef struct _scheduler_t
{
   item_list_t        actual;
   thread_t           current; 
   
   item_list_t        to_link;
   item_list_t        to_stop;
   item_list_t        to_suspend;
   item_list_t        to_resume;
   item_list_t        to_deallocate;   
   
   item_list_t        to_broadcast;

   char               eoi;
   char               move;
   int                instant;

   item_list_t        timer;   
}
*scheduler_t;

#define EVENT_VALUES_CHUNK 10

typedef struct _event_t
{
   int                instant;
   int                max;
   int                length;
   void             **values;
   item_list_t        waiting;
   scheduler_t        scheduler;
}
*event_t;

struct _thread_t
{
   automaton_t        automaton;
   void              *locals;
   char               status;
   char               suspended;
   event_t            signal;
   thread_t           called;
   char               code;
   thread_t           self;
   int                deadline;
   scheduler_t        scheduler;   
}
;

#define OK       0
#define ETIMEOUT 2
#define ENEXT    3
#define EBADLINK 4

scheduler_t implicit_scheduler     (void);
scheduler_t current_scheduler      (void);

scheduler_t scheduler_create       (void);
void        start                  (scheduler_t);

event_t     event_create           (void);
event_t     event_create_in        (scheduler_t);

void        generate               (event_t);
void        generate_value         (event_t,void*);

void        stop                   (thread_t);
void        suspend                (thread_t);
void        resume                 (thread_t);

#define local(k) (_local_vars->k)

int          return_code           (void);

void         add                   (thread_t);
void         add_in                (scheduler_t,thread_t);

thread_t     self                  (void);


/**********************************/
void        loft_initialize        (void);
void        loft_react             (scheduler_t);
void        thread_deallocate      (thread_t);
void        event_deallocate       (event_t);
void        scheduler_deallocate   (scheduler_t);

/**********************************/
/******* INTERNALS ****************/
#define _TERM   0
#define _CONT   1
#define _COOP   2
#define _RTRN   3
#define _WAIT   4

/**********************************/
thread_t     make_thread       (automaton_t,void *locals);

/**********************************/
void        *mymalloc          (size_t size);
void        *myrealloc         (void *ptr, size_t size);
void         myexit            (int n);
int          malloc_status;

/**********************************/
#define DEFINE_AUTOMATON(a) char a##_fun (a##_ _local_vars)

#define BEGIN_AUTOMATON\
      while (1) {\
         switch (_local_vars->_state)\
         {	    

#define STATE(n)\
            case n: SET_STATE(n);

#define END_AUTOMATON\
            default: THE_END\
         }\
      }

#define SET_STATE(n) _local_vars->_state=n

#define GOTO_NEXT    {SET_STATE(_local_vars->_state+1); return _COOP;}
#define GOTO(n)      {SET_STATE(n); return _COOP;}
#define IMMEDIATE(n) {SET_STATE(n); break;}
#define THE_END      {SET_STATE(-1); generate (self()->signal); return _TERM;}

/**********************************/
int      event_values_length   (event_t);
void    *nth_of_event_values   (event_t,int);
int      is_present            (event_t);

/**********************************/
void     add_to_timer          (scheduler_t,thread_t);
void     register_thread       (event_t,thread_t);

/**********************************/
