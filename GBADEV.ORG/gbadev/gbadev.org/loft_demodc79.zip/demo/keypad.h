/***********************\
* 	Keypad.h	*
*	by dovoto	*
*			*
\***********************/

#ifndef KEYPAD_H
#define KEYPAD_H

#define KEY_A 		1
#define KEY_B 		2
#define KEY_SELECT	4
#define KEY_START 	8
#define KEY_RIGHT 	16
#define KEY_LEFT 	32
#define KEY_UP 		64
#define KEY_DOWN 	128
#define KEY_R		256
#define KEY_L 		512

volatile u32* KEYS;

/*************************************/
/* added by fb */
/*************************************/
typedef void (*callback_t)();

event_t
   up_pressed,
   down_pressed,
   left_pressed,
   right_pressed,
   a_pressed,
   b_pressed,
   r_pressed,
   l_pressed;

int  pressed_key (int key);
void wait_key    (int key);

module key_handler, key_processing;

#endif
