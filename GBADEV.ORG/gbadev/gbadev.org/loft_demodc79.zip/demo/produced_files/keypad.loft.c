#line 1 "keypad.loft"
#include "loft.h"
// gba.h by eloist (from dovoto)




typedef unsigned char  u8;
typedef unsigned short u16;
typedef unsigned long  u32;

typedef signed char  s8;
typedef signed short s16;
typedef signed long  s32;

typedef unsigned char  byte;
typedef unsigned short hword;
typedef unsigned long  word;

u32* OAMmem;
u16* VideoBuffer;
u16* OAMData;
u16* BGPaletteMem;
u16* OBJPaletteMem;
		
















































































































































































u16 u16rand (int max);



















volatile u32* KEYS;




typedef void (*callback_t)();

event_t
   up_pressed,
   down_pressed,
   left_pressed,
   right_pressed,
   a_pressed,
   b_pressed,
   r_pressed,
   l_pressed;

int  pressed_key (int key);
void wait_key    (int key);

thread_t key_handler_create ();
thread_t key_processing_create ();

#line 244





volatile u32* KEYS = (volatile u32*)0x04000130;


void wait_key (int key) {
   while (*KEYS & key){}
}

int pressed_key (int key) {
    return !(*KEYS & key);
}


void create_key_events (void)
{
    a_pressed     = event_create ();
    b_pressed     = event_create ();
    up_pressed    = event_create ();
    down_pressed  = event_create ();
    left_pressed  = event_create ();
    right_pressed = event_create ();
    r_pressed     = event_create ();
    l_pressed     = event_create ();
}


/*********** module key_handler *********/
typedef struct key_handler_data_
{
    int _state;
} *key_handler_data_;
char key_handler_automaton (key_handler_data_ _local_vars)
{
BEGIN_AUTOMATON

#line 275
STATE(0) {if (!(1)) IMMEDIATE (4);}

#line 285
STATE(1) {
      if (pressed_key (1 ))     generate (a_pressed);
      if (pressed_key (2 ))     generate (b_pressed);
      if (pressed_key (64 ))    generate (up_pressed);  
      if (pressed_key (128 ))  generate (down_pressed); 
      if (pressed_key (32 ))  generate (left_pressed);
      if (pressed_key (16 )) generate (right_pressed);
      if (pressed_key (256 ))     generate (r_pressed);
      if (pressed_key (512 ))     generate (l_pressed);
   }

#line 286
STATE(2) {GOTO_NEXT;}
STATE(3) {IMMEDIATE (0);}
STATE(4);
END_AUTOMATON
}
thread_t key_handler_create_in (scheduler_t _sched)
{
   thread_t _thread;
   key_handler_data_ _locals = mymalloc (sizeof (struct key_handler_data_));
   _thread = make_thread (key_handler_automaton,_locals);
   _locals->_state = 0;
   _thread->self = _thread;
   add_in (_sched,_thread);
   return _thread;
}
thread_t key_handler_create (void)
{
    return key_handler_create_in (implicit_scheduler ());
}
/**** end of module key_handler *********/
#line 288



/*********** module key_processing *********/
typedef struct key_processing_data_
{
    event_t _loc0;
    int _loc1;
    
#line 291
event_t key_pressed;
    
#line 291
callback_t callback;
    int _state;
} *key_processing_data_;
char key_processing_automaton (key_processing_data_ _local_vars)
{
BEGIN_AUTOMATON

#line 292
STATE(0) {if (!(1)) IMMEDIATE (10);}

#line 293
STATE(1) {local(_loc0)=local(key_pressed);}
STATE(2) {
   event_t event = local(_loc0);
   if (event->scheduler != current_scheduler ()) {
      self()->code = EBADLINK;
   } else if (!is_present (event)) {
      register_thread (event,self());
      return _WAIT;
   }
}

#line 296
STATE(3) {
      local(callback) ();
   }

#line 297
STATE(4) {local(_loc1) = 10;}
STATE(5) {if (local(_loc1)<=0) IMMEDIATE(8);}

#line 297
STATE(6) {GOTO_NEXT;}
STATE(7) {local(_loc1)--; IMMEDIATE (5);}
STATE(8)
STATE(9) {IMMEDIATE (0);}
STATE(10);
END_AUTOMATON
}
thread_t key_processing_create_in (scheduler_t _sched,
#line 291
event_t key_pressed,
#line 291
callback_t callback)
{
   thread_t _thread;
   key_processing_data_ _locals = mymalloc (sizeof (struct key_processing_data_));
   _locals->key_pressed = key_pressed;
   _locals->callback = callback;
   _thread = make_thread (key_processing_automaton,_locals);
   _locals->_state = 0;
   _thread->self = _thread;
   add_in (_sched,_thread);
   return _thread;
}
thread_t key_processing_create (
#line 291
event_t key_pressed,
#line 291
callback_t callback)
{
    return key_processing_create_in (implicit_scheduler (),key_pressed,callback);
}
/**** end of module key_processing *********/
#line 299



