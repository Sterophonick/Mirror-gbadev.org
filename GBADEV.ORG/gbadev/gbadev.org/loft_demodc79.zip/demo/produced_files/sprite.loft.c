#line 1 "sprite.loft"
#include "loft.h"
// gba.h by eloist (from dovoto)




typedef unsigned char  u8;
typedef unsigned short u16;
typedef unsigned long  u32;

typedef signed char  s8;
typedef signed short s16;
typedef signed long  s32;

typedef unsigned char  byte;
typedef unsigned short hword;
typedef unsigned long  word;

u32* OAMmem;
u16* VideoBuffer;
u16* OAMData;
u16* BGPaletteMem;
u16* OBJPaletteMem;
		
















































































































































































u16 u16rand (int max);






//Atribute0 stuff











	
//Atribute1 stuff








//atribute2 stuff





typedef struct tagOAMEntry
{
	u16 attribute0;
	u16 attribute1;
	u16 attribute2;
	u16 attribute3;
}OAMEntry,*pOAMEntry;

typedef struct tagRotData
{
		
	u16 filler1[3];
	u16 pa;

	u16 filler2[3];
	u16 pb;	
		
	u16 filler3[3];
	u16 pc;	

	u16 filler4[3];
	u16 pd;
}RotData,*pRotData;



volatile u16* OAM;
pOAMEntry sprites;

void initSprites (pOAMEntry);
void syncOAMWith (pOAMEntry);
 
u8   sprite_available [128 ];
 
u8   next_sprite     (int look);
void suppress_sprite (u8 index);


typedef struct {
    s16       x;
    s16       y;
    s16       sx;
    s16       sy;
    u8        index;
    thread_t *behaviors;
    u8        behav_num;
    event_t   destroy;
    u8        dead;
}
struct_sprite_t, *sprite_t;

sprite_t  new_sprite          (s16 speed,int look);
void      alloc_behaviors     (sprite_t,u8);
void      suspend_sprite      (sprite_t);
void      resume_sprite       (sprite_t);
void      kill_sprite         (sprite_t);
int       dist2               (sprite_t,sprite_t);

extern thread_t inertia_create ();
thread_t bounce_on_borders_create ();
thread_t sync_sprite_create ();
thread_t destroy_sprite_create ();
thread_t collide_create ();
thread_t friction_create ();
thread_t move_create ();

#line 299


void go_right (sprite_t,s16);
void go_left  (sprite_t,s16);
void go_up    (sprite_t,s16);
void go_down  (sprite_t,s16);




volatile u16* OAM = (u16*)0x7000000;


void InitializeSprites (void) // from dovoto
{
   int loop;
   for(loop = 0; loop < 128 ; loop++){
      sprites[loop].attribute0 = 160;  //y to > 159
      sprites[loop].attribute1 = 240;  //x to > 239
   }
}

void CopyOAM (void) // from devoto
{
   u16 loop;
   u16* temp;
   temp = (u16*)sprites;
   for(loop = 0; loop < 128 *4; loop++) {
	OAM[loop] = temp[loop];
   }
}

void MoveSprite(OAMEntry* sp, int x, int y) // from dovoto
{
   if(x < 0) x = 512 + x;
   if(y < 0) y = 256 + y;

   sp->attribute1 = sp->attribute1 & 0xFE00;  //clear the old x value
   sp->attribute1 = sp->attribute1 | x;
	
   sp->attribute0 = sp->attribute0 & 0xFF00;  //clear the old y value
   sp->attribute0 = sp->attribute0 | y;
}


u8 next_sprite (int look)
{
   u8 i;
   for (i=0;i< 128 ;i++) {
      if (sprite_available[i]) {
         sprite_available[i] = 0;
         sprites[i].attribute2 = look;
         return i;
      }
   }
   return 0;
}

void suppress_sprite (u8 index)
{
   sprite_available[index] = 1;
   MoveSprite (&sprites[index],-20,-20);
}


sprite_t new_sprite (s16 speed,int look)
{ 
    sprite_t s   = mymalloc (sizeof (struct_sprite_t));
    s->x         = u16rand(210 );
    s->y         = u16rand(130 );
    s->sx        = u16rand(speed);
    s->sy        = u16rand(speed);
    s->index     = next_sprite (look);
    s->destroy   = event_create ();
    s->dead      = 0;
    return s;
}

void alloc_behaviors (sprite_t s,u8 n)
{
    s->behav_num = n;
    s->behaviors = mymalloc (n*sizeof (thread_t));
}

void suspend_sprite (sprite_t s)
{ 
   int i;
   for (i=0;i<s->behav_num;i++) suspend (s->behaviors[i]);
}

void resume_sprite (sprite_t s)
{ 
   int i;
   for (i=0;i<s->behav_num;i++) resume (s->behaviors[i]);
}


void kill_sprite (sprite_t s)
{
    generate (s->destroy);
    s->dead = 1;
}


/*********** module destroy_sprite *********/
typedef struct destroy_sprite_data_
{
    
#line 403
sprite_t s;
    int _state;
} *destroy_sprite_data_;
char destroy_sprite_automaton (destroy_sprite_data_ _local_vars)
{
BEGIN_AUTOMATON

#line 408
STATE(0) {
    int i;
    sprite_t s = local(s);
    for (i=0;i<s->behav_num;i++) stop (s->behaviors[i]);
}

#line 409
STATE(1) {GOTO_NEXT;}

#line 419
STATE(2) {
    int i;
    sprite_t s = local(s);
    suppress_sprite (s->index);
    for (i=0;i<s->behav_num;i++) thread_deallocate (s->behaviors[i]);
    event_deallocate (s->destroy);
    free (s->behaviors);
    free (s);
    thread_deallocate (self ());
};
END_AUTOMATON
}
thread_t destroy_sprite_create_in (scheduler_t _sched,
#line 403
sprite_t s)
{
   thread_t _thread;
   destroy_sprite_data_ _locals = mymalloc (sizeof (struct destroy_sprite_data_));
   _locals->s = s;   _thread = make_thread (destroy_sprite_automaton,_locals);
   _locals->_state = 0;
   _thread->self = _thread;
   add_in (_sched,_thread);
   return _thread;
}
thread_t destroy_sprite_create (
#line 403
sprite_t s)
{
    return destroy_sprite_create_in (implicit_scheduler (),s);
}
/**** end of module destroy_sprite *********/
#line 420




int dist2 (sprite_t s1,sprite_t s2)
{  
   int dx = s2->x - s1->x;
   int dy = s2->y - s1->y;
   return dx*dx+dy*dy; 
}




/*********** module inertia *********/
typedef struct inertia_data_
{
    
#line 434
sprite_t s;
    int _state;
} *inertia_data_;
char inertia_automaton (inertia_data_ _local_vars)
{
BEGIN_AUTOMATON

#line 435
STATE(0) {if (!(1)) IMMEDIATE (4);}

#line 440
STATE(1) {
      sprite_t s = local(s);	
      s->x += s->sx/ 10 ;
      s->y += s->sy/ 10 ;
   }

#line 441
STATE(2) {GOTO_NEXT;}
STATE(3) {IMMEDIATE (0);}
STATE(4);
END_AUTOMATON
}
thread_t inertia_create_in (scheduler_t _sched,
#line 434
sprite_t s)
{
   thread_t _thread;
   inertia_data_ _locals = mymalloc (sizeof (struct inertia_data_));
   _locals->s = s;   _thread = make_thread (inertia_automaton,_locals);
   _locals->_state = 0;
   _thread->self = _thread;
   add_in (_sched,_thread);
   return _thread;
}
thread_t inertia_create (
#line 434
sprite_t s)
{
    return inertia_create_in (implicit_scheduler (),s);
}
/**** end of module inertia *********/
#line 443



/*********** module friction *********/
typedef struct friction_data_
{
    int _loc0;
    
#line 446
sprite_t s;
    int _state;
} *friction_data_;
char friction_automaton (friction_data_ _local_vars)
{
BEGIN_AUTOMATON

#line 447
STATE(0) {if (!(1)) IMMEDIATE (9);}

#line 448
STATE(1) {local(_loc0) = 10;}
STATE(2) {if (local(_loc0)<=0) IMMEDIATE(5);}

#line 448
STATE(3) {GOTO_NEXT;}
STATE(4) {local(_loc0)--; IMMEDIATE (2);}
STATE(5)

#line 455
STATE(6) {
      sprite_t s = local(s);	
      if (s->sx >0) s->sx--; 
      if (s->sx <0) s->sx++;
      if (s->sy >0) s->sy--;
      if (s->sy <0) s->sy++;
   }

#line 456
STATE(7) {GOTO_NEXT;}
STATE(8) {IMMEDIATE (0);}
STATE(9);
END_AUTOMATON
}
thread_t friction_create_in (scheduler_t _sched,
#line 446
sprite_t s)
{
   thread_t _thread;
   friction_data_ _locals = mymalloc (sizeof (struct friction_data_));
   _locals->s = s;   _thread = make_thread (friction_automaton,_locals);
   _locals->_state = 0;
   _thread->self = _thread;
   add_in (_sched,_thread);
   return _thread;
}
thread_t friction_create (
#line 446
sprite_t s)
{
    return friction_create_in (implicit_scheduler (),s);
}
/**** end of module friction *********/
#line 458



/*********** module bounce_on_borders *********/
typedef struct bounce_on_borders_data_
{
    
#line 461
sprite_t s;
    int _state;
} *bounce_on_borders_data_;
char bounce_on_borders_automaton (bounce_on_borders_data_ _local_vars)
{
BEGIN_AUTOMATON

#line 462
STATE(0) {if (!(1)) IMMEDIATE (4);}

#line 481
STATE(1) {
      sprite_t s = local(s);	
      if(s->x < 10 ) { 
         s->sx = -s->sx; 
         s->x = 10 ;
      }
      if(s->y < 10 ) { 
         s->sy = -s->sy; 
         s->y = 10 ;
      }
      if(s->x > 210 ) { 
         s->sx = -s->sx; 
         s->x = 210 ;
      }
      if(s->y > 130 ) { 
         s->sy = -s->sy; 
         s->y = 130 ;
      }
   }

#line 482
STATE(2) {GOTO_NEXT;}
STATE(3) {IMMEDIATE (0);}
STATE(4);
END_AUTOMATON
}
thread_t bounce_on_borders_create_in (scheduler_t _sched,
#line 461
sprite_t s)
{
   thread_t _thread;
   bounce_on_borders_data_ _locals = mymalloc (sizeof (struct bounce_on_borders_data_));
   _locals->s = s;   _thread = make_thread (bounce_on_borders_automaton,_locals);
   _locals->_state = 0;
   _thread->self = _thread;
   add_in (_sched,_thread);
   return _thread;
}
thread_t bounce_on_borders_create (
#line 461
sprite_t s)
{
    return bounce_on_borders_create_in (implicit_scheduler (),s);
}
/**** end of module bounce_on_borders *********/
#line 484



static void synchronize (sprite_t s)
{
   sprites[s->index].attribute0 = 0x2000  | s->y;
   sprites[s->index].attribute1 = 0x4000  | s->x | ((s->sx>0) ? 0 : 0x1000 ) ;
}

/*********** module sync_sprite *********/
typedef struct sync_sprite_data_
{
    
#line 493
sprite_t s;
    int _state;
} *sync_sprite_data_;
char sync_sprite_automaton (sync_sprite_data_ _local_vars)
{
BEGIN_AUTOMATON

#line 494
STATE(0) {if (!(1)) IMMEDIATE (4);}

#line 495
STATE(1) {synchronize (local(s));}

#line 496
STATE(2) {GOTO_NEXT;}
STATE(3) {IMMEDIATE (0);}
STATE(4);
END_AUTOMATON
}
thread_t sync_sprite_create_in (scheduler_t _sched,
#line 493
sprite_t s)
{
   thread_t _thread;
   sync_sprite_data_ _locals = mymalloc (sizeof (struct sync_sprite_data_));
   _locals->s = s;   _thread = make_thread (sync_sprite_automaton,_locals);
   _locals->_state = 0;
   _thread->self = _thread;
   add_in (_sched,_thread);
   return _thread;
}
thread_t sync_sprite_create (
#line 493
sprite_t s)
{
    return sync_sprite_create_in (implicit_scheduler (),s);
}
/**** end of module sync_sprite *********/
#line 498




typedef void (*move_t) (sprite_t,s16);

void go_right (sprite_t s,s16 dist)
{
   s->x += dist;
   if (s->x > 210 ) s->x = 210 ;
}
void go_left (sprite_t s,s16 dist)
{
   s->x -= dist;
   if (s->x < 10 ) s->x = 10 ;
}
void go_up (sprite_t s,s16 dist)
{
   s->y -= dist;
   if (s->y < 10 ) s->y = 10 ;
}
void go_down (sprite_t s,s16 dist)
{
   s->y += dist;
   if (s->y > 130 ) s->y = 130 ;
}

/*********** module move *********/
typedef struct move_data_
{
    event_t _loc1;
    
#line 525
sprite_t s;
    
#line 525
event_t event;
    
#line 525
move_t fun;
    
#line 525
int dist;
    int _state;
} *move_data_;
char move_automaton (move_data_ _local_vars)
{
BEGIN_AUTOMATON

#line 526
STATE(0) {if (!(1)) IMMEDIATE (6);}

#line 527
STATE(1) {local(_loc1)=local(event);}
STATE(2) {
   event_t event = local(_loc1);
   if (event->scheduler != current_scheduler ()) {
      self()->code = EBADLINK;
   } else if (!is_present (event)) {
      register_thread (event,self());
      return _WAIT;
   }
}

#line 528
STATE(3) { local(fun) (local(s),local(dist)); }

#line 529
STATE(4) {GOTO_NEXT;}
STATE(5) {IMMEDIATE (0);}
STATE(6);
END_AUTOMATON
}
thread_t move_create_in (scheduler_t _sched,
#line 525
sprite_t s,
#line 525
event_t event,
#line 525
move_t fun,
#line 525
int dist)
{
   thread_t _thread;
   move_data_ _locals = mymalloc (sizeof (struct move_data_));
   _locals->s = s;
   _locals->event = event;
   _locals->fun = fun;
   _locals->dist = dist;
   _thread = make_thread (move_automaton,_locals);
   _locals->_state = 0;
   _thread->self = _thread;
   add_in (_sched,_thread);
   return _thread;
}
thread_t move_create (
#line 525
sprite_t s,
#line 525
event_t event,
#line 525
move_t fun,
#line 525
int dist)
{
    return move_create_in (implicit_scheduler (),s,event,fun,dist);
}
/**** end of module move *********/
#line 531



int min_collision = 400;

static void collision (sprite_t s1,sprite_t s2)
{  
   u16 dx = s2->x - s1->x;
   u16 dy = s2->y - s1->y;

   if (dist2 (s1,s2) > min_collision) return;

   s1->sx = -s1->sx;
   s1->sy = -s1->sy;
   
   if (dx>0) go_left (s1,dx); else go_right (s1,-dx);
   if (dy>0) go_up (s1,dy); else go_down (s1,-dy);
}

/*********** module collide *********/
typedef struct collide_data_
{
    event_t _loc2;
    int _loc3;
    void** _loc4;
    
#line 550
sprite_t me;
    
#line 550
event_t collide_evt;
    
#line 551
sprite_t other;
    
#line 551
int i;
    
#line 551
int exit;
    int _state;
} *collide_data_;
char collide_automaton (collide_data_ _local_vars)
{
BEGIN_AUTOMATON

#line 553
STATE(0) {if (!(1)) IMMEDIATE (10);}

#line 557
STATE(1) {
       local(i) = 0;
       local(exit) = 0;
    }

#line 558
STATE(2) {generate_value (local(collide_evt),(void*)local(me));}

#line 559
STATE(3) {if (!(!local(exit))) IMMEDIATE (8);}

#line 560
STATE(4) {   local(_loc2)=local(collide_evt);   local(_loc3)=local(i);   local(_loc4)=(void**)&local(other);}
STATE(5) {
   scheduler_t sched = current_scheduler ();
   event_t event = local(_loc2);
   int n = local(_loc3);
   int len = event_values_length (event);
   if (event->scheduler != sched) {
      self()->code = EBADLINK;
   } else if (is_present (event) && len > n) {
      (*local(_loc4)) = nth_of_event_values (event,n);
      self()->code = OK;
   } else if (sched->eoi) {
      self()->code = ENEXT;
      GOTO_NEXT;
   } else return _CONT;
}

#line 568
STATE(6) {
           if (return_code () == OK) {
              if (local(me) != local(other)) collision (local(me),local(other));
              local(i)++;
           } else {
              local(exit) = 1;
           }
        }
STATE(7) {IMMEDIATE (3);}
STATE(8)
STATE(9) {IMMEDIATE (0);}
STATE(10);
END_AUTOMATON
}
thread_t collide_create_in (scheduler_t _sched,
#line 550
sprite_t me,
#line 550
event_t collide_evt)
{
   thread_t _thread;
   collide_data_ _locals = mymalloc (sizeof (struct collide_data_));
   _locals->me = me;
   _locals->collide_evt = collide_evt;
   _thread = make_thread (collide_automaton,_locals);
   _locals->_state = 0;
   _thread->self = _thread;
   add_in (_sched,_thread);
   return _thread;
}
thread_t collide_create (
#line 550
sprite_t me,
#line 550
event_t collide_evt)
{
    return collide_create_in (implicit_scheduler (),me,collide_evt);
}
/**** end of module collide *********/
#line 572

