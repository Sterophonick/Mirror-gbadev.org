#line 1 "preypred.loft"
#include "loft.h"
// gba.h by eloist (from dovoto)




typedef unsigned char  u8;
typedef unsigned short u16;
typedef unsigned long  u32;

typedef signed char  s8;
typedef signed short s16;
typedef signed long  s32;

typedef unsigned char  byte;
typedef unsigned short hword;
typedef unsigned long  word;

u32* OAMmem;
u16* VideoBuffer;
u16* OAMData;
u16* BGPaletteMem;
u16* OBJPaletteMem;
		
















































































































































































u16 u16rand (int max);






//Atribute0 stuff











	
//Atribute1 stuff








//atribute2 stuff





typedef struct tagOAMEntry
{
	u16 attribute0;
	u16 attribute1;
	u16 attribute2;
	u16 attribute3;
}OAMEntry,*pOAMEntry;

typedef struct tagRotData
{
		
	u16 filler1[3];
	u16 pa;

	u16 filler2[3];
	u16 pb;	
		
	u16 filler3[3];
	u16 pc;	

	u16 filler4[3];
	u16 pd;
}RotData,*pRotData;



volatile u16* OAM;
pOAMEntry sprites;

void initSprites (pOAMEntry);
void syncOAMWith (pOAMEntry);
 
u8   sprite_available [128 ];
 
u8   next_sprite     (int look);
void suppress_sprite (u8 index);


typedef struct {
    s16       x;
    s16       y;
    s16       sx;
    s16       sy;
    u8        index;
    thread_t *behaviors;
    u8        behav_num;
    event_t   destroy;
    u8        dead;
}
struct_sprite_t, *sprite_t;

sprite_t  new_sprite          (s16 speed,int look);
void      alloc_behaviors     (sprite_t,u8);
void      suspend_sprite      (sprite_t);
void      resume_sprite       (sprite_t);
void      kill_sprite         (sprite_t);
int       dist2               (sprite_t,sprite_t);

extern thread_t inertia_create ();
thread_t bounce_on_borders_create ();
thread_t sync_sprite_create ();
thread_t destroy_sprite_create ();
thread_t collide_create ();
thread_t friction_create ();
thread_t move_create ();

#line 299


void go_right (sprite_t,s16);
void go_left  (sprite_t,s16);
void go_up    (sprite_t,s16);
void go_down  (sprite_t,s16);



extern thread_t predator_create ();
thread_t prey_create ();

#line 308


extern int max_pred_speed;
extern int kill_dist2;
extern int predator_visibility;
extern int pred_run_step;

extern int max_prey_speed;
extern int prey_visibility;
extern int prey_run_step;




int max_pred_speed      = 20;
int kill_dist2          = 200;
int predator_visibility = 40000;
int pred_run_step       = 1;

int max_prey_speed      = 30;
int prey_visibility     = 8000;
int prey_run_step       = 3;


static void chase (sprite_t me,sprite_t target)
{
   s16 dx = target->x - me->x;
   s16 dy = target->y - me->y;
   int d2 = dist2 (me,target);

   if (d2 < kill_dist2) { 
      generate (target->destroy);
      target->dead = 1;
      return;
   }
   if (dx>0 && me->sx < max_pred_speed) {
           me->sx += pred_run_step;
   }
   else if (dx<0 && -max_pred_speed <  me->sx) {
           me->sx -= pred_run_step;
   }
   if (dy>0 && me->sy < max_pred_speed) {
           me->sy += pred_run_step;
   }
   else if (dy<0 && -max_pred_speed < me->sy) {
           me->sy -= pred_run_step;
   }
}

/*********** module predator *********/
typedef struct predator_data_
{
    event_t _loc0;
    int _loc1;
    void** _loc2;
    
#line 357
sprite_t me;
    
#line 357
event_t pred_evt;
    
#line 357
event_t prey_evt;
    
#line 358
sprite_t other;
    
#line 359
sprite_t closest;
    
#line 360
int min;
    
#line 361
int i;
    
#line 362
int finished;
    int _state;
} *predator_data_;
char predator_automaton (predator_data_ _local_vars)
{
BEGIN_AUTOMATON

#line 364
STATE(0) {if (!(1)) IMMEDIATE (13);}

#line 370
STATE(1) {
       local(i) = 0;
       local(finished) = 0;
       local(min) = predator_visibility;
       generate_value (local(pred_evt),(void*)local(me));
    }

#line 371
STATE(2) {if (!(!local(finished))) IMMEDIATE (11);}

#line 372
STATE(3) {   local(_loc0)=local(prey_evt);   local(_loc1)=local(i);   local(_loc2)=(void**)&local(other);}
STATE(4) {
   scheduler_t sched = current_scheduler ();
   event_t event = local(_loc0);
   int n = local(_loc1);
   int len = event_values_length (event);
   if (event->scheduler != sched) {
      self()->code = EBADLINK;
   } else if (is_present (event) && len > n) {
      (*local(_loc2)) = nth_of_event_values (event,n);
      self()->code = OK;
   } else if (sched->eoi) {
      self()->code = ENEXT;
      GOTO_NEXT;
   } else return _CONT;
}

#line 373
STATE(5) {if (!(local(me)->dead)) IMMEDIATE (8);}

#line 373

#line 373
STATE(6) {IMMEDIATE(-1);}
STATE(7) {IMMEDIATE(8);}

STATE(8)

#line 387
STATE(9) {
           if (return_code () == OK) {
              int d2 = dist2 (local(me),local(other));
              if (local(me) != local(other) && d2 < local(min)) {
                 local(min) = d2;
                 local(closest) = local(other);
              }
              local(i)++;
           } else {
               local(finished) = 1;
               if (local(min) < predator_visibility && !local(closest)->dead) 
                          chase (local(me),local(closest));
           }
        }
STATE(10) {IMMEDIATE (2);}
STATE(11)
STATE(12) {IMMEDIATE (0);}
STATE(13);
END_AUTOMATON
}
thread_t predator_create_in (scheduler_t _sched,
#line 357
sprite_t me,
#line 357
event_t pred_evt,
#line 357
event_t prey_evt)
{
   thread_t _thread;
   predator_data_ _locals = mymalloc (sizeof (struct predator_data_));
   _locals->me = me;
   _locals->pred_evt = pred_evt;
   _locals->prey_evt = prey_evt;
   _thread = make_thread (predator_automaton,_locals);
   _locals->_state = 0;
   _thread->self = _thread;
   add_in (_sched,_thread);
   return _thread;
}
thread_t predator_create (
#line 357
sprite_t me,
#line 357
event_t pred_evt,
#line 357
event_t prey_evt)
{
    return predator_create_in (implicit_scheduler (),me,pred_evt,prey_evt);
}
/**** end of module predator *********/
#line 391




static void run_away (sprite_t me,sprite_t target)
{
   s16 dx = me->x - target->x;
   s16 dy = me->y - target->y;
   if (dx>0 && me->sx < max_prey_speed) {
           me->sx += prey_run_step;
   } else if (dx<0 && -max_prey_speed <  me->sx) {
           me->sx -= prey_run_step;
   }
   if (dy>0 && me->sy < max_prey_speed) {
           me->sy += prey_run_step;
   } else if (dy<0 && -max_prey_speed < me->sy) {
           me->sy -= prey_run_step;
   }
}


/*********** module prey *********/
typedef struct prey_data_
{
    event_t _loc3;
    int _loc4;
    void** _loc5;
    
#line 412
sprite_t me;
    
#line 412
event_t pred_evt;
    
#line 412
event_t prey_evt;
    
#line 413
sprite_t other;
    
#line 414
sprite_t closest;
    
#line 415
int min;
    
#line 416
int i;
    
#line 417
int finished;
    int _state;
} *prey_data_;
char prey_automaton (prey_data_ _local_vars)
{
BEGIN_AUTOMATON

#line 419
STATE(0) {if (!(1)) IMMEDIATE (13);}

#line 425
STATE(1) {
       local(i) = 0;
       local(finished) = 0;
       local(min) = prey_visibility;
       generate_value (local(prey_evt),(void*)local(me));
    }

#line 426
STATE(2) {if (!(!local(finished))) IMMEDIATE (11);}

#line 427
STATE(3) {   local(_loc3)=local(pred_evt);   local(_loc4)=local(i);   local(_loc5)=(void**)&local(other);}
STATE(4) {
   scheduler_t sched = current_scheduler ();
   event_t event = local(_loc3);
   int n = local(_loc4);
   int len = event_values_length (event);
   if (event->scheduler != sched) {
      self()->code = EBADLINK;
   } else if (is_present (event) && len > n) {
      (*local(_loc5)) = nth_of_event_values (event,n);
      self()->code = OK;
   } else if (sched->eoi) {
      self()->code = ENEXT;
      GOTO_NEXT;
   } else return _CONT;
}

#line 428
STATE(5) {if (!(local(me)->dead)) IMMEDIATE (8);}

#line 428

#line 428
STATE(6) {IMMEDIATE(-1);}
STATE(7) {IMMEDIATE(8);}

STATE(8)

#line 442
STATE(9) {
           if (return_code () == OK) {
              int d2 = dist2 (local(me),local(other));
              if (local(me) != local(other) && d2 < local(min)) {
                 local(min) = d2;
                 local(closest) = local(other);
              }
              local(i)++;
           } else {
              local(finished) = 1;
              if (local(min) < prey_visibility) 
                  run_away (local(me),local(closest));
           }
        }
STATE(10) {IMMEDIATE (2);}
STATE(11)
STATE(12) {IMMEDIATE (0);}
STATE(13);
END_AUTOMATON
}
thread_t prey_create_in (scheduler_t _sched,
#line 412
sprite_t me,
#line 412
event_t pred_evt,
#line 412
event_t prey_evt)
{
   thread_t _thread;
   prey_data_ _locals = mymalloc (sizeof (struct prey_data_));
   _locals->me = me;
   _locals->pred_evt = pred_evt;
   _locals->prey_evt = prey_evt;
   _thread = make_thread (prey_automaton,_locals);
   _locals->_state = 0;
   _thread->self = _thread;
   add_in (_sched,_thread);
   return _thread;
}
thread_t prey_create (
#line 412
sprite_t me,
#line 412
event_t pred_evt,
#line 412
event_t prey_evt)
{
    return prey_create_in (implicit_scheduler (),me,pred_evt,prey_evt);
}
/**** end of module prey *********/
#line 446



