#line 1 "fb26.loft"
#include "loft.h"


// gba.h by eloist (from dovoto)




typedef unsigned char  u8;
typedef unsigned short u16;
typedef unsigned long  u32;

typedef signed char  s8;
typedef signed short s16;
typedef signed long  s32;

typedef unsigned char  byte;
typedef unsigned short hword;
typedef unsigned long  word;

u32* OAMmem;
u16* VideoBuffer;
u16* OAMData;
u16* BGPaletteMem;
u16* OBJPaletteMem;
		
















































































































































































u16 u16rand (int max);



















volatile u32* KEYS;




typedef void (*callback_t)();

event_t
   up_pressed,
   down_pressed,
   left_pressed,
   right_pressed,
   a_pressed,
   b_pressed,
   r_pressed,
   l_pressed;

int  pressed_key (int key);
void wait_key    (int key);

thread_t key_handler_create ();
thread_t key_processing_create ();

#line 251







//Atribute0 stuff











	
//Atribute1 stuff








//atribute2 stuff





typedef struct tagOAMEntry
{
	u16 attribute0;
	u16 attribute1;
	u16 attribute2;
	u16 attribute3;
}OAMEntry,*pOAMEntry;

typedef struct tagRotData
{
		
	u16 filler1[3];
	u16 pa;

	u16 filler2[3];
	u16 pb;	
		
	u16 filler3[3];
	u16 pc;	

	u16 filler4[3];
	u16 pd;
}RotData,*pRotData;



volatile u16* OAM;
pOAMEntry sprites;

void initSprites (pOAMEntry);
void syncOAMWith (pOAMEntry);
 
u8   sprite_available [128 ];
 
u8   next_sprite     (int look);
void suppress_sprite (u8 index);


typedef struct {
    s16       x;
    s16       y;
    s16       sx;
    s16       sy;
    u8        index;
    thread_t *behaviors;
    u8        behav_num;
    event_t   destroy;
    u8        dead;
}
struct_sprite_t, *sprite_t;

sprite_t  new_sprite          (s16 speed,int look);
void      alloc_behaviors     (sprite_t,u8);
void      suspend_sprite      (sprite_t);
void      resume_sprite       (sprite_t);
void      kill_sprite         (sprite_t);
int       dist2               (sprite_t,sprite_t);

extern thread_t inertia_create ();
thread_t bounce_on_borders_create ();
thread_t sync_sprite_create ();
thread_t destroy_sprite_create ();
thread_t collide_create ();
thread_t friction_create ();
thread_t move_create ();

#line 350


void go_right (sprite_t,s16);
void go_left  (sprite_t,s16);
void go_up    (sprite_t,s16);
void go_down  (sprite_t,s16);



extern thread_t predator_create ();
thread_t prey_create ();

#line 359


extern int max_pred_speed;
extern int kill_dist2;
extern int predator_visibility;
extern int pred_run_step;

extern int max_prey_speed;
extern int prey_visibility;
extern int prey_run_step;






event_t prey_evt, pred_evt;


/*********** module prey_sprite *********/
typedef struct prey_sprite_data_
{
    event_t _loc0;
    
#line 379
sprite_t s;
    int _state;
    thread_t _run;
} *prey_sprite_data_;
char prey_sprite_automaton (prey_sprite_data_ _local_vars)
{
BEGIN_AUTOMATON

#line 390
STATE(0) {
    sprite_t s = new_sprite (0,0 );
    alloc_behaviors (s,5);
    s->behaviors[0] = inertia_create (s);
    s->behaviors[1] = bounce_on_borders_create (s);
    s->behaviors[2] = prey_create (s,pred_evt,prey_evt);
    s->behaviors[3] = sync_sprite_create (s);
    s->behaviors[4] = collide_create (s,prey_evt);

    local(s) = s;
}

#line 391
STATE(1) {local(_loc0)=local(s)->destroy;}
STATE(2) {
   event_t event = local(_loc0);
   if (event->scheduler != current_scheduler ()) {
      self()->code = EBADLINK;
   } else if (!is_present (event)) {
      register_thread (event,self());
      return _WAIT;
   }
}

#line 392
STATE(3) {   thread_t th = destroy_sprite_create (local(s));
   local(_run) = th;}
STATE(4) {
   event_t event = local(_run)->signal;
   if (event->scheduler != current_scheduler ()) {
      self()->code = EBADLINK;
   } else if (local(_run)->status != _TERM && !is_present (event)) {
      register_thread (event,self());
      return _WAIT;
   }
   local(_run) = NULL;
}

#line 393
STATE(5) {thread_deallocate (self ());};
END_AUTOMATON
}
thread_t prey_sprite_create_in (scheduler_t _sched)
{
   thread_t _thread;
   prey_sprite_data_ _locals = mymalloc (sizeof (struct prey_sprite_data_));
   _thread = make_thread (prey_sprite_automaton,_locals);
   _locals->_state = 0;
   _thread->self = _thread;
   add_in (_sched,_thread);
   return _thread;
}
thread_t prey_sprite_create (void)
{
    return prey_sprite_create_in (implicit_scheduler ());
}
/**** end of module prey_sprite *********/
#line 394



/*********** module predator_sprite *********/
typedef struct predator_sprite_data_
{
    event_t _loc1;
    event_t _loc2;
    
#line 398
thread_t inertia;
    int _state;
} *predator_sprite_data_;
char predator_sprite_automaton (predator_sprite_data_ _local_vars)
{
BEGIN_AUTOMATON

#line 413
STATE(0) {
    sprite_t s = new_sprite (0,8 );

    predator_create (s,pred_evt,prey_evt);
    sync_sprite_create (s);
    move_create (s,right_pressed,go_right,pred_run_step);
    move_create (s,left_pressed,go_left,pred_run_step);
    move_create (s,up_pressed,go_up,pred_run_step);
    move_create (s,down_pressed,go_down,pred_run_step);
    bounce_on_borders_create (s);
    collide_create (s,pred_evt);

    local(inertia) = inertia_create (s);
    suspend (local(inertia));
}

#line 414
STATE(1) {if (!(1)) IMMEDIATE (11);}

#line 415
STATE(2) {local(_loc1)=a_pressed;}
STATE(3) {
   event_t event = local(_loc1);
   if (event->scheduler != current_scheduler ()) {
      self()->code = EBADLINK;
   } else if (!is_present (event)) {
      register_thread (event,self());
      return _WAIT;
   }
}

#line 416
STATE(4) {resume (local(inertia));}

#line 417
STATE(5) {GOTO_NEXT;}

#line 418
STATE(6) {local(_loc2)=b_pressed;}
STATE(7) {
   event_t event = local(_loc2);
   if (event->scheduler != current_scheduler ()) {
      self()->code = EBADLINK;
   } else if (!is_present (event)) {
      register_thread (event,self());
      return _WAIT;
   }
}

#line 419
STATE(8) {suspend (local(inertia));}

#line 420
STATE(9) {GOTO_NEXT;}
STATE(10) {IMMEDIATE (1);}
STATE(11);
END_AUTOMATON
}
thread_t predator_sprite_create_in (scheduler_t _sched)
{
   thread_t _thread;
   predator_sprite_data_ _locals = mymalloc (sizeof (struct predator_sprite_data_));
   _thread = make_thread (predator_sprite_automaton,_locals);
   _locals->_state = 0;
   _thread->self = _thread;
   add_in (_sched,_thread);
   return _thread;
}
thread_t predator_sprite_create (void)
{
    return predator_sprite_create_in (implicit_scheduler ());
}
/**** end of module predator_sprite *********/
#line 422





/*********** module automatic *********/
typedef struct automatic_data_
{
    event_t _loc3;
    int _loc4;
    void** _loc5;
    int _loc6;
    int _loc7;
    
#line 427
int delay;
    
#line 428
sprite_t other;
    int _state;
} *automatic_data_;
char automatic_automaton (automatic_data_ _local_vars)
{
BEGIN_AUTOMATON

#line 429
STATE(0) {if (!(1)) IMMEDIATE (19);}

#line 430
STATE(1) {   local(_loc3)=prey_evt;   local(_loc4)=0;   local(_loc5)=(void**)&local(other);}
STATE(2) {
   scheduler_t sched = current_scheduler ();
   event_t event = local(_loc3);
   int n = local(_loc4);
   int len = event_values_length (event);
   if (event->scheduler != sched) {
      self()->code = EBADLINK;
   } else if (is_present (event) && len > n) {
      (*local(_loc5)) = nth_of_event_values (event,n);
      self()->code = OK;
   } else if (sched->eoi) {
      self()->code = ENEXT;
      GOTO_NEXT;
   } else return _CONT;
}

#line 431
STATE(3) {if (!(return_code () == ENEXT)) IMMEDIATE (16);}

#line 431

#line 432
STATE(4) {local(_loc6) = local(delay);}
STATE(5) {if (local(_loc6)<=0) IMMEDIATE(8);}

#line 432
STATE(6) {GOTO_NEXT;}
STATE(7) {local(_loc6)--; IMMEDIATE (5);}
STATE(8)

#line 433
STATE(9) {local(_loc7) = 3 ;}
STATE(10) {if (local(_loc7)<=0) IMMEDIATE(13);}

#line 433
STATE(11) {prey_sprite_create ();}
STATE(12) {local(_loc7)--; IMMEDIATE (10);}
STATE(13)

#line 434
STATE(14) {GOTO_NEXT;}
STATE(15) {IMMEDIATE(16);}

STATE(16)

#line 436
STATE(17) {GOTO_NEXT;}
STATE(18) {IMMEDIATE (0);}
STATE(19);
END_AUTOMATON
}
thread_t automatic_create_in (scheduler_t _sched,
#line 427
int delay)
{
   thread_t _thread;
   automatic_data_ _locals = mymalloc (sizeof (struct automatic_data_));
   _locals->delay = delay;   _thread = make_thread (automatic_automaton,_locals);
   _locals->_state = 0;
   _thread->self = _thread;
   add_in (_sched,_thread);
   return _thread;
}
thread_t automatic_create (
#line 427
int delay)
{
    return automatic_create_in (implicit_scheduler (),delay);
}
/**** end of module automatic *********/
#line 438





/*********** module GBA_main *********/
typedef struct GBA_main_data_
{
    int _state;
} *GBA_main_data_;
char GBA_main_automaton (GBA_main_data_ _local_vars)
{
BEGIN_AUTOMATON

#line 464
STATE(0) {
    prey_evt = event_create ();
    pred_evt = event_create ();

    create_key_events ();
    key_handler_create ();
    automatic_create (50 );
    predator_sprite_create ();

    key_processing_create (l_pressed,predator_sprite_create);
    key_processing_create (r_pressed,prey_sprite_create);

    max_pred_speed      = 10;
    kill_dist2          = 200;
    predator_visibility = 40000;
    pred_run_step       = 2;

    max_prey_speed      = 30;
    prey_visibility     = 8000;
    prey_run_step       = 3;
};
END_AUTOMATON
}
thread_t GBA_main_create_in (scheduler_t _sched)
{
   thread_t _thread;
   GBA_main_data_ _locals = mymalloc (sizeof (struct GBA_main_data_));
   _thread = make_thread (GBA_main_automaton,_locals);
   _locals->_state = 0;
   _thread->self = _thread;
   add_in (_sched,_thread);
   return _thread;
}
thread_t GBA_main_create (void)
{
    return GBA_main_create_in (implicit_scheduler ());
}
/**** end of module GBA_main *********/
#line 465



