#line 1 "rand.loft"
#include "loft.h"
// gba.h by eloist (from dovoto)




typedef unsigned char  u8;
typedef unsigned short u16;
typedef unsigned long  u32;

typedef signed char  s8;
typedef signed short s16;
typedef signed long  s32;

typedef unsigned char  byte;
typedef unsigned short hword;
typedef unsigned long  word;

u32* OAMmem;
u16* VideoBuffer;
u16* OAMData;
u16* BGPaletteMem;
u16* OBJPaletteMem;
		
















































































































































































u16 u16rand (int max);




u16 u16rand (int max)
{
   return (u16)(((float)max)*rand()/RAND_MAX); 
}

