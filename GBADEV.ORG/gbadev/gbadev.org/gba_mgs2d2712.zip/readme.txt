The game controls are:

Menu	: Hold down L. Press left right to toggle between Weapons and items.
	  Then press up and down to change them.

Item	: If ration is selected then pressing B will recover all health
	  If scope is selected, hold down B and press d pad in direction
	  that you are facing.

Weapon : HOld down R to aim and press A to fire
