
Mental Mickey (or coin adventure)
------------------------------------------------------

Code:     	John Ward
Other bits:  	Lee Bonner
Level editor:	John Ward

Fantastic music/sound player by Sergej Kravcenko - www.codewaves.com


Normal platform game rules apply;

Jump, Speed up, move left and right.


(Somebody give me a job please)
ward_john@btinternet.com

October 2002.