/*
	Some parts of this code come from xmatrix for gba from "Adam"
	already taken from the screensaver xmatrix by Jamie Zawinski (true)
	etc ... already taken from .... and from ...
	and finaly from my fisrt cpc 6128 Asm routines  (false these old
	routines will be used in future OS W6000in a few century)
	:-D 
*/

#include "cossin.h"	// Precalculated Cos / Sin tables.
#include "bg.h"		// Background texture

typedef unsigned short int uint16;
typedef unsigned int uint;
typedef unsigned char bool;

#define TRUE (0 == 0)
#define FALSE (0 == 1)
#define VRAM        0x06000000
#define BCK_M5_VRAM 0x0600A000
#define PAL	    0x05000000
#define REG_BG0CNT  0x04000008
#define REG_BG1CNT  0x0400000a
#define REG_BLDCNT  0x04000050
#define REG_BLDY    0x04000054
#define REG_JP      0x04000130
#define REG_DISPCNT *(uint16*)0x04000000
#define SetMode(Mode) REG_DISPCNT=(Mode)
#define MODE_3	    0x03	//   240*160 15bits
#define MODE_4	    0x04	//   240*160 8bits indexed palette
#define MODE_5	    0x05	//   160*128 15bits :-O	
#define BACKBUFFER  0x010	
#define BG2_ENABLE  0x0400
#define RGB(r,g,b) ((r)+((g)<<5)+((b)<<10))

void waitretrace(void);
void WaitVBlank (void);
uint16 jp_getstate(void);
void Copy32 (int *src,int *dst,unsigned int nb);
void Clear32 (int *src,unsigned int nb);
void M3_PutPixel (int x,int y, uint16 color);
void M5_PutPixel (int x,int y, uint16 color);
void M5_DirtyDrawSprite (int x,int y,int w,int h,unsigned short *src,unsigned short *dst);
void M5_DirtyDrawBlock(int x,int y,int w,int h,unsigned short *src,unsigned short *dst);
void SwapScreen (void);
int abs (int value);
void SendPal (short *pal);
void M4_PutPixel (int x,int y, unsigned char color);

void LOUPE (short *source,short *desti,int x,int y);

uint16 *ActualVideoBuffer;
unsigned int _rsa = 0x76237;
unsigned int _rsb = 0x1;
unsigned int random(void);
short Pal [256];
short shape [30]= {0,0,0,1,1,1,2,2,2,3,3,4,4,5,5,6,7,8,9,10,12,14,16,18,20,22,24,26,28,30};

short incr [3600];

int main()
{
int i,o,x1,y1,x2,y2;

SetMode (MODE_4 | BG2_ENABLE);
ActualVideoBuffer = (uint16*)0x600A000;// BCK_M5_VRAM;



for (i=0;i<256;i++)
  {
  Pal [i] = (((cmap [i][0])>>3) | ((cmap [i][1]>>3)<<5) | ((cmap [i][2]>>3)<<10));
  }
SendPal (Pal);
for (i=0;i<3600;i++)
  {
  incr [i]=255;   /* pour masquage des bords de loupe */
  }
        
for (i=0;i<30;i++)
  {
  for (o=0;o<360;o++)
  {
  x1= 30 + ((i *  Cos [o])>>7);
  y1= 30 + ((i *  Sin [o])>>7);
  x2= 30 + ((shape[i] *  Cos [o])>>7);
  y2= 30 + ((shape[i] *  Sin [o])>>7);
   incr [(y1*60)+x1]=y2*240+x2;
  }
}

x1=0;
y1=0;
x2=2;
y2=2;
while (1) 
  {
  Copy32((int*)bg,(int*) ActualVideoBuffer,9600);
  LOUPE ((short*)bg,(short*)ActualVideoBuffer,x1,y1);
  x1+=x2;
  if ((x1<1) || (x1>179)) x2 *= -1;
  y1+=y2;
  if ((y1<1) || (y1>99)) y2 *= -1;
  WaitVBlank();
  SwapScreen ();
  }
  return(0);
}

/* returns joypad state */
uint16 jp_getstate(void)
{
  return(~*((uint16 *)REG_JP));
}

void waitretrace(void)
{
  while(!((*((volatile uint16 *)0x04000004) & (1<<0))));
  return;
}

void M3_PutPixel (int x,int y, uint16 color)
{
ActualVideoBuffer[(y*240)+x] = color;
}

void M5_PutPixel (int x,int y, uint16 color)
{
ActualVideoBuffer[(y*160)+x] = color;
}

void Copy32 (int *src,int *dst,unsigned int nb)
{
unsigned int i=0;

for (i=0;i<nb;i++)
  {
  *dst= *src;
  dst++;
  src++;
  }
}

void Clear32 (int *src,unsigned int nb)
{
unsigned int i=0;

for (i=0;i<nb;i++)
  {
  *src=0;
  src++;
  }
}

void M5_DirtyDrawSprite (int x,int y,int w,int h,unsigned short *src,unsigned short *dst)
{
unsigned int i,o;
unsigned int idst;

idst =(y*160)+x;
for (i=0;i<h;i++)
  {
  for (o=0;o<w;o++)
    {
    if (*src != 0) 
      {
       dst [idst] = *src;
      } 
    idst++;
    src++;
    } 
  idst += (160-w);	// jmp next line
  }
}

void M5_DirtyDrawBlock(int x,int y,int w,int h,unsigned short *src,unsigned short *dst)
{
unsigned int i,o;
unsigned int idst;

idst =(y*160)+x;
for (i=0;i<h;i++)
  {
  for (o=0;o<w;o++)
    {
    dst [idst] = *src;
    idst++;
    src++;
    } 
  idst += (160-w);	// jmp next line
  }
}


int abs (int value)
{
if (value <0) return (value* -1);
else return (value);
}

void SwapScreen ()
{
if (REG_DISPCNT & BACKBUFFER)
  {
  
  REG_DISPCNT &= ~BACKBUFFER;
  ActualVideoBuffer = (uint16*) BCK_M5_VRAM;
  }
else
  {
  
  REG_DISPCNT |= BACKBUFFER;
  ActualVideoBuffer = (uint16*) VRAM;
  }
}

void WaitVBlank (void)
{
while (*(volatile uint16*)0x4000006<160) {};
}

void LOUPE (short *source,short *desti,int x,int y)
{
int deph;
int i,o;
char col;
int ptr =0;

source += ((y*240)+x)>>1;
for (i=0;i<59;i++)
    {
    for (o=0;o<60;o++)
        {
        deph =incr [ptr++];
	if (deph != 255)
          {
	  if (deph & 1)
	    {
	    col = *(source+(deph>>1))>>8;
	    }
	  else
	    {
	    col = *(source+(deph>>1)) & 0x00ff;
	    }
	  M4_PutPixel (x+o,y+i,col);		
	  }
        }
     }
}


void SendPal (short *pal)
{
int i;
short  *PalPtr=(short *)PAL;

for (i=0;i<256;i++)
  PalPtr [i] = pal [i];  
}

/*   
    With this we can plot in (240*160) resolution.
*/
void M4_PutPixel (int x,int y, unsigned char color)
{
short col;
unsigned int dst;

dst = (y*120)+(x>>1);
col = ActualVideoBuffer [dst];
if (x & 1)	// impair value
  {
  col &=0xff;
  col |= (color<<8);  
  }
else
  {
  col &=0xff00;
  col |= color;
  }
ActualVideoBuffer[dst] = col;
}

#ifdef __GNUC__
static void __gccmain() { }
#endif
