Marvel vs Capcom 2 - Advance Experiment
----------------------------------------
	(Competition version)

** Although my entry was disqualified from the competition due to copyright issues (read: 
   ripped gfx :P), this is the same demo I submitted.  I was going to improve it before 
   releasing it, but it really needs to be re-written to get any noticeable improvement.
   Expect the next release to feature at least one fully playable character - just don't 
   hold your breath! ;)  **

**** Congratulations to the creators of the winning entries - great work! =D ****



This demo created by:	Daniel Prati   [ dan_prati@hotmail.com ]
Original game:		Capcom

(All graphics were captured via emulation, and converted & touched up by me.)



Introduction
-----------------------------
Hello GBA fans!  This is my entry for GBAdev.org's competition.  This project was started to 
test the feasability of converting a game as graphically over-the-top as Capcom's recent 
fighting games.  It's essentially a semi-playable conversion of Capcom's outstanding fighting 
game "Marvel vs Capcom 2".  It's HEAVILY cut down due to the 1MB competition limit (and also 
due to the time I had to work on it!), but it includes the following features:

* Up to 6 simultaneously animated characters (128x128 pixels in size)
* 3-layer parallax scrolling background
* Special and Super moves for each character
* Projectiles and beam attacks
* Character tagging, assists and super combos
* Pause mode  :P

The included characters are:
 - IronMan
 - Juggernaut
 - Sentinel
 - Ryu
 - Hulk
 - Blackheart

These characters were chosen mostly for their size and the variety of their attacks - since 
the main aim of this project was to see how far the GBA's sprite hardware can be pushed, they
made a good selection.  ;)

There is no actual 'attacking', in so far as actually doing damage to other characters. This 
is both due to the 1MB limit, and the fact that I couldn't be bothered writing collision 
detection code just yet!  :P

Unfortunately, I have also not had enough time to fully implement all the Super attacks - 
while the characters will still perform their animation, some of the resultant projectiles/
beams/etc will not occur.



Controls
-----------------------------
Since the 1MB limit prevents more than a handful of frames of animation or each character,
they are limited to standing and perorming one of two different attack moves.  The D-pad 
instead allows you to scroll the screen around, so you can see the parallax scrolling in 
action.  The controls are as follows:


A button  - Perform Special attack
B button  - Perform Super attack
L trigger - Call Alpha Partner Assist
R trigger - Call Beta Partner Assist

L+B       - Tag with Alpha Partner 
R+A       - Tag with Beta Partner
L+R       - Team Super

Start     - Pause
Select    - Toggle control to other team


For those of you unfamiliar with MvC2, here's some additional explanations:

"Assists" cause a team-mate to jump in alongside your character, perform a special attack, 
and then jump out again.

"Tagging" with a partner will cause your current character to jump out, and your team-mate to 
jump in to replace him.

"Team Super" causes all available team members to jump in and perform their super attacks 
together. (your partners will jump out again once they've finished their attack)



Known Bugs/Issues
-----------------------------
there are a few graphical glitches when performing certain cominations of moves with certain 
characters - this is mostly due to unoptimised code, and will be fixed in future (this 
includes Team Super attacks).  

Hulk's Super move sometimes causes other characters' sprites to break, repeating the top half 
of the character in the bottom half - I have not had time to fix this yet...  :(

Slowdown will occur briefly if you activate the Team Super attacks for both teams - this could 
be fixed with future code revisions, however (IMHO) the GBA can't handle enough sprites to 
support six characters all doing simultaneous Super attacks (due to the crazy number of 
projectiles!).

As stated above, some super attacks are not finished.  This, unfortunately, is due to time 
constraints and should be implemented in the next release. (the extra graphics for these 
attacks are actually compiled into the binary...)



Final Comments
-----------------------------
From the development of this project, I believe the GBA is quite capable of handling a game of
this magnitude.  Along the way, I have thought of a number of improvements and optimisations 
that should allow smooth and glitch-free graphics, while also freeing up enough processor time 
for collisions and AI.  Considering the number of lacklustre conversions already released on 
the system, I have found that working on this project has really opened my eyes as to the 
future potential of the GameBoy Advance.

Regardless of the technical issues, I hope you enjoy this demo!



Thanks
-----------------------------
* Huge thanks to GBAdev.org for starting this competition in the first place - it's great to see 
the GBA scene taken seriously!  :P

* Thanks of course to Capcom for creating such a great game for me to attempt to duplicate!  :)

* Thanks to Razoola (CPS2Shock) and ElSemi (Nebula) for providing me with a way to capture the 
graphics!  ;)

* Greetings go out to everyone in the GBA dev scene!  Good luck in the competition!  =D



Feel free to email me with questions, comments, threats, etc...  ;)

Original graphics, characters, their likenesses, etc are copyright �Capcom and �Marvel Comics
Everything else is copright �Daniel Prati 2002



