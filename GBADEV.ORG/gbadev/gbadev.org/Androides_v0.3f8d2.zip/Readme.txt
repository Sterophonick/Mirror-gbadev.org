Androides
---------

v0.3 Octobre 2004 

Androides is a conversion of the T08 hit from the 80's
It has been created by W. Hennebois from Infogrames in 1985... 20 years old..
I have been really happy to port this great piece af arcade game to GBA.


Goal
----
Collect every gift in whitout been touched by your ennemies
There is the 10 original levels.
You can expand it to whatever you want by editing a FILE.DAT and include in 
your rom whitout compiling with AddLevel.exe. Keep an original androides.gba file for security!!

Thanks to:
----------
my wife and 4 children	: to support me and my homebrew madness.. ;)
Infogrames				: for the original software (Willima hennebois)
D. Coulom				: for his great universal Thomson emulator (http://dcmoto.free.fr)
PlayerAdvance.org		: for their existence .. :-)
gbadev.org              : for their contents

TODO:
-----
-Sound
-Music
-Saves
-Old/New school switch:
 - new gfx
 - multiplay
 - more items
 - more levels
 - ...


Report wahtever you want to : xflash.homebrew@free.fr




-=xFlasH=-