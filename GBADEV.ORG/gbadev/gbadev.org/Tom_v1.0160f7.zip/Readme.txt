Title: The Adventues of Tom Sawyer
Version: 1.01
Developed by: Dan Whitman (kyp4)


About ATS:
    I wrote this little adventure game back in eigth grade (1998) in good old DOS C
for an English project at school. I thought it would be a fun project to convert it
to the GBA. Included in the zip is the original DOS version.

Story:
 Read the opening screens

Controls:
 Read the opening screens

Other:
 If you are interesting in the source code for ATS (GCC) email me at kyp4@yahoo.com
and I will send it to you!