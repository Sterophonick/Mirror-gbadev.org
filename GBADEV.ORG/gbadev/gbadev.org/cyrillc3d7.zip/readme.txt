Cyrill the Barbarian - Koob@another.com
------------------------------------------------------------
October 27 2002

Excuse the name, just made it up.

This demo works best in VBA, because of the audio lib. Should work on hardware..

All programming and graphics by me (Kuba) except for the grass tiles which I borrowed and edited from somewhere that borrowed and edited them, so I guess thats ok for now, and the picture of conan the barbarian off some book somewhere.

Quite simply, slay everything! Have a look at the to-do list at the end if you're particularly interested in future plans...


In game controls

Start - Turns music on/off
A - Slash
B - Kick (use this on dead monsters to get them out the way ;)
L - Block (I'll implement it one day...)
R - Run.


CREDITS

Music by Ken!

This demo was made using the HAM library (very good, check it out) - www.ngine.de
Graphics were made using a program called Blender - www.blender3d.com (STEEP learning curve, but hey)
Krawall Audio library - not sure where you get that. Type krawall into a search engine! Will be implemented with HAM soon

***
Without sounding desperate, please, for the love of God, someone get me out of doing data entry for a living, I have done my time...
***


TO DO (in no particular order)

Polish up monsters ai
Implement block
bring the troll to life (and imminent death)
Loads more monsters (my dragon will rock)
Improve existing world graphics - trees, grass etc
Re-do main characters sprite (not too happy with the colours at the mo)
Add a computer controlled player 2 (a team-mate)
Implement a world map
Throw in an rpg element.
Loads of other stuff i can't think of right now

A loose plot -
fighting in a arena to get money (possibly starting point, win your freedom? Lions, tigersm gladiators, chained to your partner..)
Travel the lands, get a horse, conquer things, challange the gods, that sort of stuff.
Either ransack villages or take on evil people.

Only take a day or two.