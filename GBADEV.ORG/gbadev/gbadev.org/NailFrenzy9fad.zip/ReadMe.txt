Nail Frenzy Rom (14/02/05)
--------------------------


How to run Nail Frenzy
----------------------
Get a GBA emulator such as BoycottAdvance and run the included NailFrenzy.bin in it.  Or upload the NailFrenzy.bin to a GBA flash cartridge.  A variety of GBA emulators can be downloaded at http://www.emulator-zone.com/doc.php/gba/


Game objective
--------------
Very simple idea.  You have a hand which has been diseased with never ending finger nail disease.  With the aid of Pac-Dude, chomp on your finger nails to keep them as short as possible.  Be careful, because if your nails get too long its game over.  Also it will be the end if Pac-Dude bites your fingers, as he has titanium fangs that can bite through the hardest of hard tanks.


Controls
--------
Up	- Move Pac-Dude up
Down	- Move Pac-Dude down
B	- Gets Pac-Dude to start chomping
Hold B	- Gets Pac-Dude to chomp repeatedly


Contact
-------

Have something to say about Nail Frenzy??  Mail me on njsgreen@lycos.co.uk or visit http://splendid.kamari.co.uk/ for more splendid demos :)

