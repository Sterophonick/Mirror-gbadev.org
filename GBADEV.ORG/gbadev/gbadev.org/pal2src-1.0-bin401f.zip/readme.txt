---------------------
 pal2src v1.0 readme
---------------------

This package should have included the following files:

  pal2src                <-- The compiled Linux version of pal2src
  pal2src.exe            <-- The DOS/Windows version of pal2src
  readme.txt             <-- The file you're reading right now

If it didn't then let me know!  See Contact Information below.

--------------------
 About This Program
--------------------

This tool converts Jasc palettes into source code that can be
inserted into a GBA project.  This application will accept both 16
and 256 color palettes and output a C-style array of the appropriate
size.  No optimizations are made to reduce the size of the palette so
you get exactly what you want and not what I think you want.  There
are several options, all of which are available by running
'pal2src --help' or if you're lazy like me, just direct your eyes
a couple of inches south and read below:

Usage : pal2src [options] filename

Converts a palette into source code format.

  -c               Output variable as constant data.
  -d arg           Sets the output directory (default = .).
                   This option is ignored if you use the -f option.
  -f arg           Set the output filename to 'arg'.  All output is
                   directed to this file even if multiple input files
                   are specified.
  -h               Create header files along with the source output.
  -v arg           Set the name of the variable to hold palette data.
                   Only valid when one input file is specified.
  --help           Displays this help message and exits.
  --version        Displays pal2src's version information and exits.

Send bugs and comments to Erik Gillespie <rattles@yakko.cs.wmich.edu>

---------------------
 Contact Information
---------------------

If you want to get a hold of me to request a feature, put in a bug
report, make comments (I like getting emails that people actually use
my programs :) then send me an email:

   rattles@yakko.cs.wmich.edu

You can always get the newest version of pal2src and most of my other
software from my web site:

   http://yakko.cs.wmich.edu/~rattles/
