==============================================================
Announcement
==============================================================

After a canceled deal and a broken contract deceptions, DHG Games members finally decided to distribute Motocross Challenge for free. We put a lot of efforts to get the game to this complete Gold state and it won't be totally wasted if you play it! 

If you want to distribute the game for free from your own website, please view the distribution section below.

We hope you will enjoy the game,

The DHG Games crew.


==============================================================
Distribution Rules
==============================================================

You can distribute Motocross Challenge for free. Please email ddguert@hotmail.com if you do so
in order for us to get some stats on the game distribution.

In no case Motrocross Challenge can be sole or ported to any platform wihout DHGGames explicit conscent. Game concept remains the entire property of DHG Games.


==============================================================
Controls
==============================================================

L : Hold to do tricks (must be combined with other controls)
A : Turbo
B : Gas
R : Brake

	Tricks :

		Left 		: Superman
		Right 		: TrickNacNac
		Up + Right 	: TrickDeadBody
		Down 		: TrickLazyBoy
		Up 		: NoFooter
		Up + Left	: Nothing


==============================================================
Cheats
==============================================================

We'll wait for the game to be played a bit before communicating them ;-)





