---------------------------------------------------------
                       Y A K U Z A 
	    Demo-Group
	      est. in 1991

active Members: George Stark
Members h.c.:      Delta, Sigma, 
                              ToXiC Trancer
                              Scale , Oracle
---------------------------------------------------------
Diz is the second release of the nice
firecube intro. The first release 
didn't look like a 240x160 resolution.
The reason was my misunderstanding
of the Mode4-Adressing .. now I know it
right and I guess it really sucks .. I
guess I will never use it again ...

I didn't change the source much, because
all of the algorithms were written for the
right resolution .. but you didn't see it :-)

It's a little bit slow, cause all algos use
clipping conditions  .. but I wasn't in the mood
for making it visible :-)

By the way I compressed the little picture using
a simple RLE-Compression algorithm to
minimize the filesize...

And last some technical overview:

Real-Mode 4 Demo: 

some vector rotation,
shading, fire algorithm, using pictures,
using compression,Interpolation 
and so on ... and still not really
optimized ... G.S./Yakuza 
-------------------------------------------------------