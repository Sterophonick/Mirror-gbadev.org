This is a screen shot of a work in progress update of my earlier voxel engine.
It has now been improved to be full screen and works in Mode 5, runs 
faster, and also can handle background textures e.g. the sky
Keys are:
	up : move forware
	down : move back
	left : strafe left
	right : strafe right
	start, select : increase decrease quality
	R.L : increase/decrease veiwing area
featuring all the colours available. 
Any comments contact me on dm93@hotmail.com