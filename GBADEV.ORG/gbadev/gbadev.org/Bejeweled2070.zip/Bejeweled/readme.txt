Bejeweled v 1.0 by flynt2002stone

This is a port of Bejeweled I made to test out my skills on the GBA. It is my first
game ever, and I am very proud of it. However, It still lacks several things like
a timer, saving of highscores (highscores at all for that matter)
sound and other goodies. Still, the game logic should work 100% now. Be on the look-
out for updates in the future. A big thanks to all of you who wrote tutorials for
us beginners. This is so much fun to do!

My email adress is thegamefreak0134@yahoo.com
my forum name is thegamefreak0134

PleasePleasePLEASE let me know if you find a bug of any kind. I have
debuggers playing with it here, but something could still be amiss.
Thanks!

Controls:

D+Pad - Move cursor / Swap jewels
A - Select Jewel
B - De-Select Jewel
Start - Pass Title Screen

Have fun! Future releases to come as I learn more about GBA programming.

History:

1.0 - First Fully Playable Version
	-Fixed slight animation problem
	-Completely reworked animation process to conserve tile space
	-Added scoring system
	-Added Display of combos and chains

0.7 - Initial Release
	-Game logic should work now. Recognises all sizes of chains and combos.
	-Cursor movement
	-Some animation.
	-All jewels drawn by hand.
	-Background drawn by hand.
	-Cool text drawn (drumroll) by hand.

Cheese is good.