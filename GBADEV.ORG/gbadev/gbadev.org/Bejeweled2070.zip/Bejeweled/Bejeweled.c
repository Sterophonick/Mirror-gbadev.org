#include "stdlib.h"
#include "gba.h"
#include "JewelBoard.h"
#include "Jewel2.h"
#include "title.h"
#include "pressstart.h"

#include "Jewel3.h"
#include "Jewel4.h"
#include "Jewel5.h"
#include "Jewel6.h"
#include "Jewel7.h"
#include "Jewel8.h"
#include "Jewel9.h"

void InitializeSprites(void);
void CopyOAM(void);
void MoveSprite(OAMEntry* sp, int x, int y);
void MoveCursor(void);
void SelectCursor(void);
void CheckBoard(void);
void BeDropped(void);
void ShowScore(void);
void ShowCombo(void);
void ShowChain(void);
void Reset1(void);
void Reset2(void);

OAMEntry sprites[128];



u16 xcursor = 16;
u16 ycursor = 16;
u16 holdit = 0;
u16 gorb = 0;
u16 currentscore = 0;
u16 score = 0;
u16 chain = 0;
u16 combo = 0;
u16 currentcombo = 0;
u16 currentchain = 0;

int main() {

	u16 loop;

	SetMode(MODE_4 | BG2_ENABLE | OBJ_ENABLE | OBJ_MAP_1D );

	for (loop = 0; loop < 256; loop++) {
		OBJ_PaletteMem[loop] = pressstartPalette[loop];
	}
	
	for (loop = 0; loop < 256; loop++) {
		BG_PaletteMem[loop]=titlePalette[loop];
	}

	
	
	memcpy( (u16 *)0x6000000, &titleData, sizeof(titleData) );

	memcpy( (u16 *)0x06014000, &pressstartData, sizeof(pressstartData) );

	sprites[0].attribute0 = COLOR_256 | WIDE | 140;
	sprites[0].attribute1 = SIZE_64 | 88;
	sprites[0].attribute2 = 512;

	CopyOAM();

	u16 starter = 0;
	u16 startcount = 0;
	u16 randomizer = 0;

	while (starter == 0) {
		if (keyDown(KEY_START)) {
			starter = 1;
		}
		randomizer = ((rand()%7)*8) + 512;
		startcount = startcount + 1;
		if (startcount > 30) {
			sprites[0].attribute2 = 0;
		}
		if (startcount > 65) {
			sprites[0].attribute2 = 512;
			startcount = 0;
		}
		WaitForVsync();
		CopyOAM();
	}

	sprites[0].attribute2 = 0;
	CopyOAM();

	
	
	
	for (loop = 0; loop < 256; loop++) {
		OBJ_PaletteMem[loop] = Jewel2Palette[loop];
	}

	for (loop = 0; loop < 256; loop++) {
		BG_PaletteMem[loop]=JewelBoardPalette[loop];
	}

		memcpy( (u16 *)0x6000000, &JewelBoardData, sizeof(JewelBoardData) );



	memcpy( (u16 *)0x06014000, &Jewel2Data, sizeof(Jewel2Data) );
	
	u16 xjewel = 0;
	u16 yjewel = 0;
	u16 randjewel;
	
	while (yjewel < 8) {
		while (xjewel < 8) {
			randjewel = ((rand()%7)*8) + 512;
			sprites[xjewel + 1 + (yjewel*8)].attribute0 = COLOR_256 | SQUARE | (yjewel*16) + 16;
			sprites[xjewel + 1 + (yjewel*8)].attribute1 = SIZE_16 | (xjewel*16) + 16;
			sprites[xjewel + 1 + (yjewel*8)].attribute2 = randjewel;
			xjewel = xjewel + 1;
		}
		xjewel = 0;
		yjewel = yjewel + 1;
	}

	CheckBoard();

	sprites[0].attribute0 = COLOR_256 | SQUARE | ycursor;
	sprites[0].attribute1 = SIZE_16 | xcursor;
	sprites[0].attribute2 = 512 + (8*63);
    
	//Remember! Numbers start at 624
	//and increase by 4!

	sprites[66].attribute0 = COLOR_256 | TALL | 18;
	sprites[66].attribute1 = SIZE_8 | 171;
	sprites[66].attribute2 = 0;

	sprites[67].attribute0 = COLOR_256 | TALL | 18;
	sprites[67].attribute1 = SIZE_8 | 179;
	sprites[67].attribute2 = 0;

	sprites[68].attribute0 = COLOR_256 | TALL | 18;
	sprites[68].attribute1 = SIZE_8 | 187;
	sprites[68].attribute2 = 0;

	sprites[69].attribute0 = COLOR_256 | TALL | 18;
	sprites[69].attribute1 = SIZE_8 | 195;
	sprites[69].attribute2 = 0;

	sprites[70].attribute0 = COLOR_256 | TALL | 18;
	sprites[70].attribute1 = SIZE_8 | 203;
	sprites[70].attribute2 = 624;

	sprites[71].attribute0 = COLOR_256 | TALL | 54;
	sprites[71].attribute1 = SIZE_8 | 171;
	sprites[71].attribute2 = 0;

	sprites[72].attribute0 = COLOR_256 | TALL | 54;
	sprites[72].attribute1 = SIZE_8 | 179;
	sprites[72].attribute2 = 0;

	sprites[73].attribute0 = COLOR_256 | TALL | 54;
	sprites[73].attribute1 = SIZE_8 | 187;
	sprites[73].attribute2 = 0;

	sprites[74].attribute0 = COLOR_256 | TALL | 54;
	sprites[74].attribute1 = SIZE_8 | 195;
	sprites[74].attribute2 = 0;

	sprites[75].attribute0 = COLOR_256 | TALL | 54;
	sprites[75].attribute1 = SIZE_8 | 203;
	sprites[75].attribute2 = 0;

		sprites[76].attribute0 = COLOR_256 | TALL | 90;
	sprites[76].attribute1 = SIZE_8 | 171;
	sprites[76].attribute2 = 0;

	sprites[77].attribute0 = COLOR_256 | TALL | 90;
	sprites[77].attribute1 = SIZE_8 | 179;
	sprites[77].attribute2 = 0;

	sprites[78].attribute0 = COLOR_256 | TALL | 90;
	sprites[78].attribute1 = SIZE_8 | 187;
	sprites[78].attribute2 = 0;

	sprites[79].attribute0 = COLOR_256 | TALL | 90;
	sprites[79].attribute1 = SIZE_8 | 195;
	sprites[79].attribute2 = 0;

	sprites[80].attribute0 = COLOR_256 | TALL | 90;
	sprites[80].attribute1 = SIZE_8 | 203;
	sprites[80].attribute2 = 0;

	ShowScore();

	while(1) {
		WaitForVsync();
		CopyOAM();
		if (keyDown(KEY_START)) {
			BeDropped();
		}
		MoveCursor();
		SelectCursor();
	}

		return 0;

}

void InitializeSprites(void)
{
	u16 loop;
	for(loop = 0; loop < 128; loop++) {
		sprites[loop].attribute0 = 160;
		sprites[loop].attribute1 = 240;
	}
}

void CopyOAM(void)
{
	u16 loop;
	u16* temp;
	temp = (u16*)sprites;
	for(loop = 0;loop < 128*4; loop++) {
		OAM_Mem[loop] = temp[loop];
	}
}

void MoveSprite(OAMEntry* sp, int x, int y)
{
	sp->attribute1 = sp->attribute1 & 0xFE00;
	sp->attribute1 = sp->attribute1 | x;

	sp->attribute0 = sp->attribute0 & 0xFF00;
	sp->attribute0 = sp->attribute0 | y;

}

void MoveCursor(void) {
	

	if(keyDown(KEY_LEFT) && xcursor > 16) {
		xcursor = xcursor - 16;
	}

	if(keyDown(KEY_RIGHT) && xcursor < 16*8) {
		xcursor = xcursor + 16;
	}
	
	if(keyDown(KEY_UP) && ycursor > 16) {
		ycursor = ycursor - 16;
	}

	if(keyDown(KEY_DOWN) && ycursor < 16*8) {
		ycursor = ycursor + 16;
	}


		sprites[0].attribute0 = COLOR_256 | SQUARE | ycursor;
		sprites[0].attribute1 = SIZE_16 | xcursor;
		sprites[0].attribute2 = 512 + (8*63);

		CopyOAM();

		while (keyDown(KEY_LEFT) || keyDown(KEY_RIGHT) || keyDown(KEY_UP)
			|| keyDown(KEY_DOWN)) {
		}

	

}

void SelectCursor(void) {
	if (keyDown(KEY_A)) {
		sprites[0].attribute2 = sprites[(((xcursor-16)/16)+1) + ((((ycursor-16)/16))*8)].attribute2 + (8*7);
		CopyOAM();
		while ((keyDown(KEY_RIGHT) || keyDown(KEY_LEFT) || keyDown(KEY_UP) || keyDown(KEY_DOWN) || keyDown(KEY_B)) == 0) {
		}
		s16 xdirection = 1;
		s16 ydirection = 1;
		if (keyDown(KEY_LEFT) && xcursor > 16) {
			xdirection = 0;
		}

		if (keyDown(KEY_RIGHT) && xcursor < 16*8) {
			xdirection = 2;
		}

		if (keyDown(KEY_UP) && ycursor > 16) {
			ydirection = 0;
		}

		if (keyDown(KEY_DOWN) && ycursor < 16*8) {
			ydirection = 2;
		}
		
		if (xdirection == 0 || ydirection == 0 || xdirection == 2 || ydirection == 2) {
		
		// Hooray for logic nightmares!!!

		sprites[0].attribute2 = 0;

		u16 xmover = ((xcursor-16)/16)+1;
		u16 ymover = (((ycursor-16)/16))*8;
		u16 counter01 = 0;
		
			while (counter01 < 16) {
				sprites[xmover + ymover].attribute0 = COLOR_256 | SQUARE | ycursor + (counter01*(ydirection-1));
				sprites[xmover + ymover].attribute1 = SIZE_16 | xcursor + (counter01*(xdirection-1));
				sprites[xmover + ymover + (xdirection-1) + ((ydirection-1)*8)].attribute0 = COLOR_256 | SQUARE | ycursor + ((ydirection-1)*16) + (counter01*(ydirection-1)*(0-1));
				sprites[xmover + ymover + (xdirection-1) + ((ydirection-1)*8)].attribute1 = SIZE_16 | xcursor +  ((xdirection-1)*16) +(counter01*(xdirection-1)*(0-1));
				counter01 = counter01 + 1;
				WaitForVsync();
				CopyOAM();
			}

		sprites[xmover + ymover].attribute0 = COLOR_256 | SQUARE | ycursor;
		sprites[xmover + ymover].attribute1 = SIZE_16 | xcursor;
		sprites[xmover + ymover + (xdirection-1) + ((ydirection-1)*8)].attribute0 = COLOR_256 | SQUARE | ycursor + ((ydirection-1)*16);
		sprites[xmover + ymover + (xdirection-1) + ((ydirection-1)*8)].attribute1 = SIZE_16 | xcursor +  ((xdirection-1)*16);


		u16 savesprite = sprites[xmover + ymover].attribute2;
		sprites[xmover + ymover].attribute2 = sprites[xmover + ymover + (xdirection-1) + ((ydirection-1)*8)].attribute2;
		sprites[xmover + ymover + (xdirection-1) + ((ydirection-1)*8)].attribute2 = savesprite;
		
		gorb = 0;
		CheckBoard();
		if (gorb == 0) {
		u16 xmover = ((xcursor-16)/16)+1;
		u16 ymover = (((ycursor-16)/16))*8;
		u16 counter01 = 0;
		
			while (counter01 < 16) {
				sprites[xmover + ymover].attribute0 = COLOR_256 | SQUARE | ycursor + (counter01*(ydirection-1));
				sprites[xmover + ymover].attribute1 = SIZE_16 | xcursor + (counter01*(xdirection-1));
				sprites[xmover + ymover + (xdirection-1) + ((ydirection-1)*8)].attribute0 = COLOR_256 | SQUARE | ycursor + ((ydirection-1)*16) + (counter01*(ydirection-1)*(0-1));
				sprites[xmover + ymover + (xdirection-1) + ((ydirection-1)*8)].attribute1 = SIZE_16 | xcursor +  ((xdirection-1)*16) +(counter01*(xdirection-1)*(0-1));
				counter01 = counter01 + 1;
				WaitForVsync();
				CopyOAM();
			}

		sprites[xmover + ymover].attribute0 = COLOR_256 | SQUARE | ycursor;
		sprites[xmover + ymover].attribute1 = SIZE_16 | xcursor;
		sprites[xmover + ymover + (xdirection-1) + ((ydirection-1)*8)].attribute0 = COLOR_256 | SQUARE | ycursor + ((ydirection-1)*16);
		sprites[xmover + ymover + (xdirection-1) + ((ydirection-1)*8)].attribute1 = SIZE_16 | xcursor +  ((xdirection-1)*16);


		u16 savesprite = sprites[xmover + ymover].attribute2;
		sprites[xmover + ymover].attribute2 = sprites[xmover + ymover + (xdirection-1) + ((ydirection-1)*8)].attribute2;
		sprites[xmover + ymover + (xdirection-1) + ((ydirection-1)*8)].attribute2 = savesprite;
		


		}
		
		
		
		}
				

	}
}

void CheckBoard(void) {
u16 badboard = 0;
combo = 0;
currentcombo = 0;
currentchain = 0;
chain = 0;
while (badboard == 0) {
	currentcombo = combo;
	combo = combo + 1;
	
	badboard = 1;
	
	u16 xcheck = 0;
	u16 ycheck = 0;
	u16 zcheck;
	

	while (ycheck < 8) {
		while (xcheck < 6) {
			if (sprites[xcheck + (ycheck*8) + 1].attribute2 == sprites[xcheck + (ycheck*8) + 2].attribute2 && sprites[xcheck + (ycheck*8) + 1].attribute2 == sprites[xcheck + (ycheck*8) + 3].attribute2 && xcheck < 7) {
				zcheck = sprites[xcheck + (ycheck*8) + 1].attribute2;
				badboard = 0;
				gorb = 1;
					while (sprites[xcheck + (ycheck*8) + 1].attribute2 == zcheck && xcheck < 8) {
						sprites[xcheck + (ycheck*8) + 1].attribute2 = sprites[xcheck + (ycheck*8) + 1].attribute2 + (8*7);
						xcheck = xcheck + 1;
						chain = chain + 1;
					}
			}
			xcheck = xcheck + 1;
		}
		xcheck = 0;
		ycheck = ycheck + 1;
	}
	xcheck = 0;
	ycheck = 0;
	// Yay!! More Logic Hell! 
	// You'd think  I would have taken the easy way
	// out with a two-dimentional array by now, but
	// hey, this works well enough, why change it?
		while (xcheck < 8) {
		while (ycheck < 6) {
			if (  (sprites[xcheck + (ycheck*8) + 1].attribute2 == sprites[xcheck + (ycheck*8) + 9].attribute2  || sprites[xcheck + (ycheck*8) + 1].attribute2 == sprites[xcheck + (ycheck*8) + 9].attribute2 + (8*7)  || sprites[xcheck + (ycheck*8) + 1].attribute2 == sprites[xcheck + (ycheck*8) + 9].attribute2 - (8*7)) && (sprites[xcheck + (ycheck*8) + 1].attribute2 == sprites[xcheck + (ycheck*8) + 17].attribute2 || sprites[xcheck + (ycheck*8) + 1].attribute2 == sprites[xcheck + (ycheck*8) + 17].attribute2 + (8*7)  || sprites[xcheck + (ycheck*8) + 1].attribute2 == sprites[xcheck + (ycheck*8) + 17].attribute2 - (8*7))  && ycheck < 7) {
				zcheck = sprites[xcheck + (ycheck*8) + 1].attribute2;
				badboard = 0;
				gorb = 1;
					while ((sprites[xcheck + (ycheck*8) + 1].attribute2 == zcheck || sprites[xcheck + (ycheck*8) + 1].attribute2 == zcheck + (8*7)  || sprites[xcheck + (ycheck*8) + 1].attribute2 == zcheck - (8*7)) && ycheck < 8) {
						if (((sprites[xcheck + (ycheck*8) + 1].attribute2 == zcheck) || (sprites[xcheck + (ycheck*8) + 1].attribute2 == zcheck + (8*7)) || (sprites[xcheck + (ycheck*8) + 1].attribute2 == zcheck - (8*7))) && sprites[xcheck + (ycheck*8) + 1].attribute2 < 512 + (8*7)) {
							sprites[xcheck + (ycheck*8) + 1].attribute2 = sprites[xcheck + (ycheck*8) + 1].attribute2 + (8*7);
						}
							ycheck = ycheck + 1;
							chain = chain + 1;
						
					}
			}
			ycheck = ycheck + 1;
		}
		ycheck = 0;
		xcheck = xcheck + 1;
	}

	u16 counter = 1;
	zcheck = 0;
	u16 goaway = 0;

	score = score + (chain * combo);
	
	

	if (badboard == 0) {
		ShowCombo();
		ShowChain();
		ShowScore();
		chain = 0;
		WaitForVsync();
		CopyOAM();
		WaitForVsync();
		CopyOAM();
		WaitForVsync();
		CopyOAM();
		WaitForVsync();
		CopyOAM();
		WaitForVsync();
		CopyOAM();
	}
	
	while (zcheck < 7 && goaway == 0 && badboard == 0) {
	
		goaway = 0;
		
		if (counter == 1) {
		memcpy( (u16 *)0x06014700, &Jewel3Data, sizeof(Jewel3Data) );
		}
		if (counter == 2) {
		memcpy( (u16 *)0x06014700, &Jewel4Data, sizeof(Jewel4Data) );
		}
		if (counter == 3) {
		memcpy( (u16 *)0x06014700, &Jewel5Data, sizeof(Jewel5Data) );
		}
		if (counter == 4) {
		memcpy( (u16 *)0x06014700, &Jewel6Data, sizeof(Jewel6Data) );
		}
		if (counter == 5) {
		memcpy( (u16 *)0x06014700, &Jewel7Data, sizeof(Jewel7Data) );
		}
		if (counter == 6) {
		memcpy( (u16 *)0x06014700, &Jewel8Data, sizeof(Jewel8Data) );
		}
		if (counter == 7) {
		memcpy( (u16 *)0x06014700, &Jewel9Data, sizeof(Jewel9Data) );
		}

		counter = counter + 1;
		WaitForVsync();
		CopyOAM();
		WaitForVsync();
		CopyOAM();
		WaitForVsync();
		CopyOAM();
		WaitForVsync();
		CopyOAM();
		WaitForVsync();
		CopyOAM();
		zcheck = zcheck + 1;
	}
	if (badboard == 0) {
	BeDropped();
	memcpy( (u16 *)0x06014000, &Jewel2Data, sizeof(Jewel2Data) );
	}

}


	Reset1();
	Reset2();
	CopyOAM();
	
	
}

void BeDropped(void) {
	u16 dropcheck = 0;
	while (dropcheck == 0) {
	dropcheck = 1;
	u16 xdrop = 0;
	u16 ydrop = 8;

	while (xdrop < 8) {
		while (ydrop >= 1) {
			if (sprites[xdrop + ((ydrop-1)*8) + 1].attribute2 > 560) {
				dropcheck = 0;
				while (ydrop >= 2) {
					sprites[xdrop + ((ydrop-1)*8) + 1].attribute2 = sprites[xdrop + ((ydrop-2)*8) + 1].attribute2;
					ydrop = ydrop - 1;
				}
				sprites[xdrop + ((ydrop-1)*8) + 1].attribute2 = ((rand()%7)*8) + 512;
			}
		ydrop = ydrop - 1;


		}
	ydrop = 8;
	xdrop = xdrop + 1;
	
	}
		WaitForVsync();
		CopyOAM();
		WaitForVsync();
		CopyOAM();
		WaitForVsync();
		CopyOAM();
		WaitForVsync();
		CopyOAM();
		WaitForVsync();
		CopyOAM();	
		WaitForVsync();
		CopyOAM();
		WaitForVsync();
		CopyOAM();
		WaitForVsync();
		CopyOAM();
		WaitForVsync();
		CopyOAM();
		WaitForVsync();
		CopyOAM();


	}
	while (keyDown(KEY_START)) {
	}






}

void ShowScore(void) {
	u16 plusone = 0;
	while (score > currentscore) {
		plusone = 0;
		if (currentscore + 100 < score) {
			if (sprites[68].attribute2 == 0) {
			sprites[68].attribute2 = 624;
			}
			sprites[68].attribute2 = sprites[68].attribute2 + 4;
			plusone = 1;
			currentscore = currentscore + 100;
		}
		if (currentscore + 10 < score && plusone == 0) {
			if (sprites[69].attribute2 == 0) {
			sprites[69].attribute2 = 624;
			}
			sprites[69].attribute2 = sprites[69].attribute2 + 4;
			plusone = 1;
			currentscore = currentscore + 10;
		}
		if (plusone == 0) {


		currentscore = currentscore + 1;
		sprites[70].attribute2 = sprites[70].attribute2 + 4;
		}
		if (sprites[70].attribute2 > 624 + (9*4)) {
			sprites[70].attribute2 = 624;
			if (sprites[69].attribute2 == 0) {
			sprites[69].attribute2 = 624;
			}
			sprites[69].attribute2 = sprites[69].attribute2 + 4;
		}
		if (sprites[69].attribute2 > 624 + (9*4)) {
			sprites[69].attribute2 = 624;
			if (sprites[68].attribute2 == 0) {
			sprites[68].attribute2 = 624;
			}
			sprites[68].attribute2 = sprites[68].attribute2 + 4;
		}

		if (sprites[68].attribute2 > 624 + (9*4)) {
			sprites[68].attribute2 = 624;
			if (sprites[67].attribute2 == 0) {
			sprites[67].attribute2 = 624;
			}
			sprites[67].attribute2 = sprites[67].attribute2 + 4;
		}

		if (sprites[67].attribute2 > 624 + (9*4)) {
			sprites[67].attribute2 = 624;
			if (sprites[66].attribute2 == 0) {
			sprites[66].attribute2 = 624;
			}
			sprites[66].attribute2 = sprites[66].attribute2 + 4;
		}
		WaitForVsync();
		CopyOAM();
	}




}
	
void ShowCombo(void) {
	u16 plusone = 0;
	currentcombo = 0;
	Reset1();
	while (combo > currentcombo) {
		plusone = 0;
		if (currentcombo + 100 < combo) {
			if (sprites[73].attribute2 == 0) {
			sprites[73].attribute2 = 624;
			}
			sprites[73].attribute2 = sprites[73].attribute2 + 4;
			plusone = 1;
			currentcombo = currentcombo + 100;
		}
		if (currentcombo + 10 < combo && plusone == 0) {
			if (sprites[74].attribute2 == 0) {
			sprites[74].attribute2 = 624;
			}
			sprites[74].attribute2 = sprites[74].attribute2 + 4;
			plusone = 1;
			currentcombo = currentcombo + 10;
		}
		if (plusone == 0) {


		currentcombo = currentcombo + 1;
		if (sprites[75].attribute2 == 0) {
			sprites[75].attribute2 = 624;
			}
		sprites[75].attribute2 = sprites[75].attribute2 + 4;
		}
		if (sprites[75].attribute2 > 624 + (9*4)) {
			sprites[75].attribute2 = 624;
			if (sprites[74].attribute2 == 0) {
			sprites[74].attribute2 = 624;
			}
			sprites[74].attribute2 = sprites[74].attribute2 + 4;
		}
		if (sprites[74].attribute2 > 624 + (9*4)) {
			sprites[74].attribute2 = 624;
			if (sprites[73].attribute2 == 0) {
			sprites[73].attribute2 = 624;
			}
			sprites[73].attribute2 = sprites[73].attribute2 + 4;
		}

		if (sprites[73].attribute2 > 624 + (9*4)) {
			sprites[73].attribute2 = 624;
			if (sprites[72].attribute2 == 0) {
			sprites[72].attribute2 = 624;
			}
			sprites[72].attribute2 = sprites[72].attribute2 + 4;
		}

		if (sprites[72].attribute2 > 624 + (9*4)) {
			sprites[72].attribute2 = 624;
			if (sprites[71].attribute2 == 0) {
			sprites[71].attribute2 = 624;
			}
			sprites[71].attribute2 = sprites[71].attribute2 + 4;
		}
		
	}




}	

void ShowChain(void) {
	u16 plusone = 0;
	currentchain = 0;
	Reset2();
	while (chain > currentchain) {
		plusone = 0;
		if (currentchain + 100 < chain) {
			if (sprites[78].attribute2 == 0) {
			sprites[78].attribute2 = 624;
			}
			sprites[78].attribute2 = sprites[78].attribute2 + 4;
			plusone = 1;
			currentchain = currentchain + 100;
		}
		if (currentchain + 10 < chain && plusone == 0) {
			if (sprites[79].attribute2 == 0) {
			sprites[79].attribute2 = 624;
			}
			sprites[79].attribute2 = sprites[79].attribute2 + 4;
			plusone = 1;
			currentchain = currentchain + 10;
		}
		if (plusone == 0) {


		currentchain = currentchain + 1;
		if (sprites[80].attribute2 == 0) {
			sprites[80].attribute2 = 624;
			}
		sprites[80].attribute2 = sprites[80].attribute2 + 4;
		}
		if (sprites[80].attribute2 > 624 + (9*4)) {
			sprites[80].attribute2 = 624;
			if (sprites[79].attribute2 == 0) {
			sprites[79].attribute2 = 624;
			}
			sprites[79].attribute2 = sprites[79].attribute2 + 4;
		}
		if (sprites[79].attribute2 > 624 + (9*4)) {
			sprites[79].attribute2 = 624;
			if (sprites[78].attribute2 == 0) {
			sprites[78].attribute2 = 624;
			}
			sprites[78].attribute2 = sprites[78].attribute2 + 4;
		}

		if (sprites[78].attribute2 > 624 + (9*4)) {
			sprites[78].attribute2 = 624;
			if (sprites[77].attribute2 == 0) {
			sprites[77].attribute2 = 624;
			}
			sprites[77].attribute2 = sprites[77].attribute2 + 4;
		}

		if (sprites[77].attribute2 > 624 + (9*4)) {
			sprites[77].attribute2 = 624;
			if (sprites[76].attribute2 == 0) {
			sprites[76].attribute2 = 624;
			}
			sprites[76].attribute2 = sprites[76].attribute2 + 4;
		}
		
	}




}

void Reset1(void) {
	sprites[71].attribute0 = COLOR_256 | TALL | 54;
	sprites[71].attribute1 = SIZE_8 | 171;
	sprites[71].attribute2 = 0;

	sprites[72].attribute0 = COLOR_256 | TALL | 54;
	sprites[72].attribute1 = SIZE_8 | 179;
	sprites[72].attribute2 = 0;

	sprites[73].attribute0 = COLOR_256 | TALL | 54;
	sprites[73].attribute1 = SIZE_8 | 187;
	sprites[73].attribute2 = 0;

	sprites[74].attribute0 = COLOR_256 | TALL | 54;
	sprites[74].attribute1 = SIZE_8 | 195;
	sprites[74].attribute2 = 0;

	sprites[75].attribute0 = COLOR_256 | TALL | 54;
	sprites[75].attribute1 = SIZE_8 | 203;
	sprites[75].attribute2 = 0;
}

void Reset2(void) {

		sprites[76].attribute0 = COLOR_256 | TALL | 90;
	sprites[76].attribute1 = SIZE_8 | 171;
	sprites[76].attribute2 = 0;

	sprites[77].attribute0 = COLOR_256 | TALL | 90;
	sprites[77].attribute1 = SIZE_8 | 179;
	sprites[77].attribute2 = 0;

	sprites[78].attribute0 = COLOR_256 | TALL | 90;
	sprites[78].attribute1 = SIZE_8 | 187;
	sprites[78].attribute2 = 0;

	sprites[79].attribute0 = COLOR_256 | TALL | 90;
	sprites[79].attribute1 = SIZE_8 | 195;
	sprites[79].attribute2 = 0;

	sprites[80].attribute0 = COLOR_256 | TALL | 90;
	sprites[80].attribute1 = SIZE_8 | 203;
	sprites[80].attribute2 = 0;

}




