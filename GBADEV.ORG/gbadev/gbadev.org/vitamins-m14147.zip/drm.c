/*

drm.c
Vitamins, a falling pills game

Copyright 2000-2003 Damian Yerrick

This program is free software; you can redistribute it and/or
modify it under the terms of the GNU General Public License
as published by the Free Software Foundation; either version 2
of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to 
  Free Software Foundation, Inc., 59 Temple Place - Suite 330,
  Boston, MA  02111-1307, USA.
GNU licenses can be viewed online at http://www.gnu.org/copyleft/

You may contact Damian Yerrick via the web form at
  http://www.pineight.com/

*/


#include <stdlib.h>
#include <string.h>
#include "pin8gba.h"
#include "gbfs.h"
MULTIBOOT


int fracmul(signed int x, signed int frac);
void gblz_unpack(const void *src, void *dst);


typedef enum PlayerState
{
  STATE_INACTIVE,
  STATE_NEW_PIECE,
  STATE_FALLING_PIECE,
  STATE_CHECK,
  STATE_CHECKED,
  STATE_FALL,
  STATE_BOULDERS,
  STATE_GAMEOVER
} PlayerState;

enum {
  COLOR_GRAY = 0,
  COLOR_RED = 010,
  COLOR_YELLOW = 020,
  COLOR_BLUE = 030,
  COLOR_MASK = 070,

  CONN_VIRUS = 000,
  CONN_SINGLE = 001,
  CONN_LHALF = 002,
  CONN_RHALF = 003,
  CONN_THALF = 004,
  CONN_BHALF = 005,
  CONN_CLEARED = 006,
  CONN_MASK = 007
};


typedef long fixed;



typedef struct Player
{
  fixed x;     // 0 = left; 7 << 16 = right
  fixed y;     // 0 = bottom; 15 << 16 = top
  unsigned int bgdirty_rows;
  char piece1, piece2; // color of primary and secondary piece
  char next1, next2; // next piece coming
  PlayerState state;
  int clock;
  unsigned int seed; // for random numbers.
  short flip; // 90deg anticlockwise rotation from east
  short nVIR; // viruses left to kill
  short virScore; // score for next virus
  short chainCount;
  short level;
  short initialLevel;
  short n_pieces; // number of pieces dropped determines speed of game
  int score;
  signed char repeatTime[10];
  unsigned char field[16][8];
} Player;


typedef struct Globals
{
  const GBFS_FILE *dat;
  Player p;
} Globals;

Globals g;
extern int retrace_count;


#define PF_MAP 20

#define FIELD_WID 8
#define FIELD_HT 16
#define ORIGIN_X 11
#define ORIGIN_Y 18



static const int flipCos[8] = {1, 0, -1, 0, 1, 0, -1, 0};
static const int flipSin[8] = {0, 1, 0, -1, 0, 1, 0, -1};





void wait4vbl(void)
{
#if 1
  asm volatile("mov r2, #0; swi 0x05" ::: "r0", "r1", "r2", "r3");
#else
  while(LCD_Y != 160);
#endif
  while(LCD_Y != 161);
}


void isr(void);
void setup_isr(void)
{
  /*
  saved_isr = GET_MASTER_ISR();
  */
  /* set the ISR */
  SET_MASTER_ISR(isr);
  /* turn on interrupt sources */
  LCDSTAT = LCDSTAT_VBLINT;
  /* turn on interrupt controller */
  INTMASK = INT_VBLANK;
  INTENABLE = 1;
}





/* upcvt_4bit() ************************
   Convert a 1-bit font to GBA 4-bit format.
*/
void upcvt_4bit(void *dst, const u8 *src, size_t len)
{
  u32 *out = dst;

  for(; len > 0; len--)
  {
    u32 dst_bits = 0;
    u32 src_bits = *src++;
    u32 x;

    for(x = 0; x < 8; x++)
    {
      dst_bits <<= 4;
      dst_bits |= src_bits & 1;
      src_bits >>= 1;
    }
    *out++ = dst_bits;
  }
}


/* itoa_lpad() *************************
   Convert n into a string of len characters, left-padded with
   lpad_chr.  buf points to a buffer of at least (len + 1) chars.
*/
void itoa_lpad(char *buf, size_t len, int n, int lpad_chr)
{
  int sign_char = lpad_chr;

  /* handle negative integers */
  if(n < 0)
  {
    n = -n;
    sign_char = '-';
  }

  /* terminate the string */
  buf[len] = 0;

  /* extract each digit */
  do {
    unsigned int tenths = fracmul(n, (0xffffffffUL)/10+1);
    int ncomp = tenths * 10;

    if(ncomp > n)
    {
      --tenths;
      ncomp -= 10;
    }
    /* assumes compiler can optimize n % 10 and n / 10 into one op
       also assumes digits appear consecutively in 0123456789 order
       (this is true of ascii) */
    buf[--len] = (n - ncomp) + '0';
    n = tenths;
  } while(n && len);

  /* write sign */
  if(len)
    buf[--len] = sign_char;

  /* left pad */
  while(len)
    buf[--len] = lpad_chr;
}


/* nttextout() *************************
   Write the given text to a nametable.
*/
void nttextout(u32 nt, u32 x, u32 y, u32 c, const char *str)
{
  while(*str)
    MAP[nt][y][x++] = (*str++ & 0xff) | c;
}


/* ayn() *******************************
   Random number generator based on one from
   http://random.mat.sbg.ac.at/~charly/server/node3.html
*/
static unsigned int ayn(Player *p)
{
  p->seed = p->seed * 2147001325 + 715136305;
  return p->seed >> 17;
}


/* draw_row() **************************
   Draws a line of blocks in a player's field.

In octal:

000-007 nothing
010     red virus
011     red pill
012     red lhalf
013     red rhalf
014     red thalf
015     red bhalf
016     red cleared
017     nothing
020-027 yellow
030-037 blue

*/
static void draw_row(Player *this, int y)
{
  unsigned int i;
  unsigned short *vrdest = MAP[PF_MAP][ORIGIN_Y - y] + ORIGIN_X;

  if(y < 0 || y >= FIELD_HT)
    return;

  /* blit the blocks */
  for(i = 0; i < FIELD_WID; i++)
  {
    unsigned int blk = this->field[y][i];

    if(blk)
    {
      unsigned int maj = blk >> 3;
      unsigned int min = blk & CONN_MASK;
      if(min != 0)  /* if not a virus */
      {
        blk = (maj << 12) | min;
      }
      else  /* if it is a virus */
      {
        blk = (maj << 12) | maj | 8;
      }
    }
    *vrdest++ = blk;
  }
}


static void add_dirty_row(Player *this, int y)
{
  if(y >= 0 && y < FIELD_HT)
    this->bgdirty_rows |= 1 << y;
}


static void draw_dirty_rows(Player *this)
{
  int y;
  unsigned int dirt = this->bgdirty_rows;

  for(y = 0; y < FIELD_HT; y++)
  {
    if(dirt & 1)
      draw_row(this, y);
    dirt >>= 1;
  }
  this->bgdirty_rows = 0;
}


static void draw_meters(Player *p)
{
  u16 *const next_dst = MAP[PF_MAP][ORIGIN_Y - FIELD_HT - 1] + (ORIGIN_X + (FIELD_WID / 2) - 1);

  /* draw next piece */
  next_dst[0] = (p->next1 << 12) | CONN_LHALF;
  next_dst[1] = (p->next2 << 12) | CONN_RHALF;

  /* draw score */
  char buf[32];

  itoa_lpad(buf, 8, g.p.score, ' ');
  nttextout(PF_MAP, 0, 7, 0x0000, buf);
  itoa_lpad(buf, 8, g.p.nVIR, ' ');
  nttextout(PF_MAP, 0, 9, 0x0000, buf);

  itoa_lpad(buf, 2, g.p.level, ' ');
  nttextout(PF_MAP, 3, 19, 0x0000, buf);
#if 0
  format_time(buf, 8, p.playTime);
  nttextout(PF_MAP, 5, 19, 0x0000, buf);
#endif
}


/* draw_capsule() **********************
   Draw the falling capsule.
*/
static void draw_capsule(Player *p)
{
  /* x and y location of capsule */
  int xloc = ORIGIN_X * 8 + (p->x >> 13);
  int yloc = ORIGIN_Y * 8 + 1 - (p->y >> 13);
  int c1 = p->piece1, c2 = p->piece2;

  if(p->state != STATE_FALLING_PIECE)
  {
    OAM[0].y = OAM[1].y = OAM_HIDDEN;
    return;
  }


  switch(p->flip)
  {
  case 0:
    OAM[0].y = yloc | OAM_16C | OAM_SQUARE;
    OAM[0].x = xloc | OAM_SIZE0;
    OAM[0].tile = CONN_LHALF | OAM_PAL(c1);
    OAM[1].y = yloc | OAM_16C | OAM_SQUARE;
    OAM[1].x = (xloc + 8) | OAM_SIZE0;
    OAM[1].tile = CONN_RHALF | OAM_PAL(c2);
    break;

  case 1:
    OAM[0].y = yloc | OAM_16C | OAM_SQUARE;
    OAM[0].x = xloc | OAM_SIZE0;
    OAM[0].tile = CONN_BHALF | OAM_PAL(c1);
    OAM[1].y = ((yloc - 8) & 0xff) | OAM_16C | OAM_SQUARE;
    OAM[1].x = xloc | OAM_SIZE0;
    OAM[1].tile = CONN_THALF | OAM_PAL(c2);
    break;

  case 2:
    OAM[0].y = yloc | OAM_16C | OAM_SQUARE;
    OAM[0].x = xloc | OAM_SIZE0;
    OAM[0].tile = CONN_RHALF | OAM_PAL(c1);
    OAM[1].y = yloc | OAM_16C | OAM_SQUARE;
    OAM[1].x = (xloc - 8) | OAM_SIZE0;
    OAM[1].tile = CONN_LHALF | OAM_PAL(c2);
    break;

  case 3:
    OAM[0].y = yloc | OAM_16C | OAM_SQUARE;
    OAM[0].x = xloc | OAM_SIZE0;
    OAM[0].tile = CONN_THALF | OAM_PAL(c1);
    OAM[1].y = (yloc + 8) | OAM_16C | OAM_SQUARE;
    OAM[1].x = xloc | OAM_SIZE0;
    OAM[1].tile = CONN_BHALF | OAM_PAL(c2);
    break;
  }
}


static void putblock(Player *this, int x, int y, int c)
{
  if(x >= 0 && x < FIELD_WID && y >= 0 && y < FIELD_HT)
  {
    add_dirty_row(this, y);
    this->field[y][x] = c;
  }
}


static void setup_drm_screen(void)
{
  unsigned int x;
  const char top_line1[] = {12,7,7,15,0,0,14,7,7,13};
  const char top_line0[] = {2,13,0,0,12,3};

  wait4vbl();
  LCDMODE = LCDMODE_BLANK;
  for(x = 0; x < 128; x++)
    OAM[x].y = OAM_HIDDEN;

  /* clear the screen */
  for(x = 0; x < 640; x++)
    MAP[PF_MAP][0][x] = 0;

  /* sides of pf */
  for(x = ORIGIN_Y - FIELD_HT + 1; x <= ORIGIN_Y; x++)
    MAP[PF_MAP][x][ORIGIN_X + FIELD_WID] = MAP[PF_MAP][x][ORIGIN_X - 1] = 8;

  /* bottom of pf */
  MAP[PF_MAP][ORIGIN_Y + 1][ORIGIN_X - 1] = 14;
  for(x = ORIGIN_X; x < ORIGIN_X + FIELD_WID; x++)
    MAP[PF_MAP][ORIGIN_Y + 1][x] = 7;
  MAP[PF_MAP][ORIGIN_Y + 1][ORIGIN_X + FIELD_WID] = 15;

  /* top of pf */
  for(x = 0; x < 10; x++)
    MAP[PF_MAP][ORIGIN_Y - FIELD_HT][x + ORIGIN_X - 1] = top_line1[x];
  for(x = 0; x < 6; x++)
    MAP[PF_MAP][ORIGIN_Y - FIELD_HT - 1][x + ORIGIN_X + 1] = top_line0[x];

  nttextout(PF_MAP, 1,  6, 0x0000, "Score:");
  nttextout(PF_MAP, 1,  8, 0x0000, "Virus:");
  nttextout(PF_MAP, 1, 19, 0x0000, "Lv");
  draw_meters(&g.p);

  BGCTRL[0] = BGCTRL_PAT(0) | BGCTRL_16C | BGCTRL_NAME(PF_MAP);
  LCDMODE = 0 | LCDMODE_BG0 | LCDMODE_SPR;
}


/* mk_viruses() ***********************
   Add nVIR viruses to player's field.
*/
static void mk_viruses(Player *p, int nVIR)
{
  int x, y;
  int maxY = (176 + nVIR) / 20;
  int c = ((ayn(p) * 3) >> 15) + 1;
  int targetVir;
  int failures = 200;

  p->bgdirty_rows = -1;

  for(y = 0; y < FIELD_HT; y++)
    for(x = 0; x < FIELD_WID; x++)
      p->field[y][x] = 0;

  while(nVIR > 0)
  {
    targetVir = (c << 3) | CONN_VIRUS;
    x = (ayn(p) * FIELD_WID) >> 15;
    y = (ayn(p) * maxY) >> 15;
    if(p->field[y][x] != 0)
      x = x ^ 4;
    if(p->field[y][x] != 0)
      x = x ^ 2;
    if(p->field[y][x] != 0)
      x = x ^ 1;
    if(p->field[y][x] != 0)
    {
      continue;
    }

    /* If it absolutely can't place any more viruses, bail. */
    if(failures < 0)
    {
      p->nVIR -= nVIR;
      nVIR = 0;
      p->field[0][0] = COLOR_GRAY | CONN_SINGLE;
      break;
    }


    /* Make sure there aren't any three-in-a-rows (oox xoo) */
    if(x >= 2 &&
       p->field[y][x - 1] == targetVir &&
       p->field[y][x - 2] == targetVir)
    {
      failures--;
      continue;
    }

    if(x < FIELD_WID - 2 &&
       p->field[y][x + 1] == targetVir &&
       p->field[y][x + 2] == targetVir)
    {
      failures--;
      continue;
    }

    if(y >= 2 &&
       p->field[y - 1][x] == targetVir &&
       p->field[y - 2][x] == targetVir)
    {
      failures--;
      continue;
    }

    if(y < FIELD_HT - 2 &&
       p->field[y + 1][x] == targetVir &&
       p->field[y + 2][x] == targetVir)
    {
      failures--;
      continue;
    }

    /* Allow some three-in-a-rows (oxo) for really dense virus levels. */
    if(failures > 150)
    {
      if(y >= 1 && y < FIELD_HT - 1 &&
         p->field[y - 1][x] == targetVir &&
         p->field[y + 1][x] == targetVir)
      {
        failures--;
        continue;
      }

      if(x >= 1 && x < FIELD_WID - 1 &&
         p->field[y][x - 1] == targetVir &&
         p->field[y][x + 1] == targetVir)
      {
        failures--;
        continue;
      }
    }


    /* Funny, the name of one of the most popular programming
       languages on the planet means "Move to the next color." */
    c++;
    if(c > 3)
      c -= 3;

    p->field[y][x] = targetVir;
    nVIR--;
  }
}




static const unsigned char gamma_table[16] =
{
  0, 6, 11, 14, 16, 18, 20, 21, 23, 25, 26, 27, 28, 29, 30, 31
};


static void setup_drm_palette(void)
{
  unsigned int y;

  PALRAM[0] = RGB(21, 23, 23);
  for(y = 1; y < 16; y++)
  {
    unsigned int hi = gamma_table[(y <= 13) ? y + 2 : 15];
    unsigned int lo = gamma_table[(y >= 6) ? y - 6 : 0];
    unsigned int mid = gamma_table[y - 1];

    PALRAM[y + 256] = PALRAM[y] = RGB(mid, mid, mid);
    PALRAM[y + 272] = PALRAM[y + 16] = RGB(hi, lo, lo);  /* red pill */
    PALRAM[y + 288] = PALRAM[y + 32] = RGB(hi, hi, lo);  /* yellow pill */
    PALRAM[y + 304] = PALRAM[y + 48] = RGB(lo, lo, hi);  /* blue pill */
  }
}


void init_drm(void)
{
  setup_isr();
}


void NewGame(void)
{
  g.p.score = 0;
  g.p.level = 0;
  g.p.next1 = 1;
  g.p.next2 = 2;
}


void load_text_tiles(void)
{
  unsigned int size;
  const void *data = gbfs_get_obj(g.dat, "text.chr", &size);
  upcvt_4bit(VRAM + 16*32, data, size);
}


void animate_viruses(unsigned int frame)
{
  unsigned char *src = gbfs_copy_obj(VRAM, g.dat, "pills.chr");

  memcpy(VRAM + 9 * 16, src + (frame ? 800 : 288), 96);

}


void NewLevel(void)
{
  setup_drm_palette();
  gbfs_copy_obj(VRAM, g.dat, "pills.chr");
  gbfs_copy_obj((u16 *)0x06010000, g.dat, "pills.chr");
  load_text_tiles();
  g.p.nVIR = g.p.level > 20 ? 84 : (g.p.level + 1) * 4;
  g.p.seed = 1103515245 * retrace_count + 12345;
  mk_viruses(&g.p, g.p.nVIR);
  setup_drm_screen();
  draw_dirty_rows(&g.p);
  g.p.n_pieces = 0;
  g.p.state = STATE_NEW_PIECE;
  g.p.clock = retrace_count + 60;
}


void NewPiece(Player *this)
{
  this->x = ((FIELD_WID - 1) / 2) << 16;
  this->y = (FIELD_HT << 16) - 0x1000;
  this->piece1 = this->next1;
  this->piece2 = this->next2;
  this->next1 = ((ayn(this) * 3) >> 15) + 1;
  this->next2 = ((ayn(this) * 3) >> 15) + 1;
  this->flip = 0;
  this->state = STATE_FALLING_PIECE;
  this->n_pieces++;
  draw_meters(this);
}


void make_repeats(char *repeatTime, int j, int autoDelay, int autoRate)
{
  int i;

  for(i = 0; i < 10; i++)
  {
    if(j & 0x01)
    {
      repeatTime[i]++;
      if(repeatTime[i] >= autoDelay)
        repeatTime[i] -= autoRate;
    }
    else
    {
      repeatTime[i] = 0;
    }
    j >>= 1;
  }
}


/* CheckOverlap() **********************
   Checks if a piece is overlapping the walls of the playfield
   or blocks.
*/
static int CheckOverlap(Player *this, int x, int y, int flip)
{
  y >>= 16;
  x >>= 16;
  if(x < 0 || x >= FIELD_WID ||
     x + flipCos[flip] < 0 || x + flipCos[flip] >= FIELD_WID ||
     y < 0 || y + flipSin[flip] < 0)
    return 1;
  if(y < FIELD_HT && this->field[y][x])
    return 1;
  if(y + flipSin[flip] < FIELD_HT)
    if(this->field[y + flipSin[flip]][x + flipCos[flip]])
      return 1;
  return 0;
}


/* Try2Flip ****************************
   Tries several positions for rotating a piece into place.
*/
static void Try2Flip(Player *this, unsigned int f4)
{
  int cosine = flipCos[f4] << 16;
  int sine   = flipSin[f4] << 16;
  int curCos = flipCos[this->flip] << 16;
  int curSin = flipSin[this->flip] << 16;

  if(!CheckOverlap(this, this->x, this->y, f4))
  {
    this->flip = f4;
  }
  else
//   o
//  *O     ->    *oO
  if(!CheckOverlap(this, this->x, this->y, f4 ^ 2))
  {
    this->x -= cosine;
    this->y -= sine;
    this->flip = f4;
  }
  else
//   o           oO
//  *O*    ->    * *
  if(!CheckOverlap(this, this->x + curCos,
                   this->y + curSin, f4))
  {
    this->x += curCos;
    this->y += curSin;
    this->flip = f4;
  }
  else
//  *o           *oO
//  *O*    ->    * *
  if(!CheckOverlap(this, this->x + curCos,
                   this->y + curSin, f4 ^ 2))
  {
    this->x += curCos - cosine;
    this->y += curSin - sine;
    this->flip = f4;
  }
  else
//  *o*          *O*
//  *O*    ->    *o*
  {
    this->x += curCos;
    this->y += curSin;
    this->flip ^= 2;
  }

#if 0
  PlayEffect(flipSnd);
#endif
}


/* freeze_piece() **********************
   Locks a piece into place.
*/
static void freeze_piece(Player *p)
{
  int x = p->x >> 16;
  int y = p->y >> 16;

  switch(p->flip)
  {
  case 0:
    if(y < FIELD_HT)
    {
      putblock(p, x,     y, p->piece1 << 3 | CONN_LHALF);
      putblock(p, x + 1, y, p->piece2 << 3 | CONN_RHALF);
    }
    break;
  case 1:
    if(y + 1 < FIELD_HT)
    {
      putblock(p, x, y,     p->piece1 << 3 | CONN_BHALF);
      putblock(p, x, y + 1, p->piece2 << 3 | CONN_THALF);
    }
    else if(y < FIELD_HT)
      putblock(p, x, y, p->piece1 << 3 | CONN_SINGLE);
    break;
  case 2:
    if(y < FIELD_HT)
    {
      putblock(p, x,     y, p->piece1 << 3 | CONN_RHALF);
      putblock(p, x - 1, y, p->piece2 << 3 | CONN_LHALF);
    }
    break;
  case 3:
    if(y < FIELD_HT)
    {
      putblock(p, x, y,     p->piece1 << 3 | CONN_THALF);
      putblock(p, x, y - 1, p->piece2 << 3 | CONN_BHALF);
    }
    else if(y - 1 < FIELD_HT)
      putblock(p, x, y - 1, p->piece2 << 3 | CONN_SINGLE);
    break;
  }

#if 0
  PlayEffect(dropSnd);
#endif
  p->virScore = 1;
  p->chainCount = 0;

}


/* CheckLines() ************************
 * Checks for four blocks in a row vertically or horizontally.
 * Returns number of lines found.
 */
static int CheckLines(Player *this)
{
  int x, y, j, c, found = 0, foundVir = 0;

  /* look for horizontal matches */
  for(y = 0; y < FIELD_HT; y++)
  {
    for(x = 0; x < FIELD_WID - 3; x++)
    {
      c = this->field[y][x] & COLOR_MASK;
      if(c >= 010 && c < 050)
      {
        /* look for a match */
        for(j = 1; j < 4; j++)
          if((this->field[y][x + j] & COLOR_MASK) != c)
            j = 99;

        if(j < 20)  /* if we've found one */
        {
          found = 1;
#if 0
          if(this->context->garbage)
            this->going[this->chainCount++] = c;
#endif
          j = 0;

          /* find length of match */
          while(x + j < FIELD_WID &&
                (this->field[y][x + j] & COLOR_MASK) == (c & COLOR_MASK))
          {
            c = this->field[y][x + j];
            putblock(this, x + j, y, (c & COLOR_MASK) | CONN_CLEARED);

            /* remove boulders */
            if(y > 0 && this->field[y - 1][x + j] == (COLOR_GRAY | CONN_SINGLE))
            {
              putblock(this, x + j, y - 1, 0);
              this->nVIR--;
              this->score += this->virScore;
              this->virScore <<= 1;
            }
            if(y < FIELD_HT - 1 && this->field[y + 1][x + j] == (COLOR_GRAY | CONN_SINGLE))
            {
              putblock(this, x + j, y + 1, 0);
              this->nVIR--;
            }

            /* remove viruses */
            if((c & 07) == CONN_VIRUS)
            {
              this->nVIR--;
              foundVir = 1;
              this->score += this->virScore;
              this->virScore <<= 1;
            }
            j++;
          }
          /* j = length of horizontal match whose left side is (x, y) */
          /* remove boulders on end caps */
          if(x + j < FIELD_WID && this->field[y][x + j] == (COLOR_GRAY | CONN_SINGLE))
          {
            putblock(this, x + j, y, 0);
            this->nVIR--;
            this->score += this->virScore;
            this->virScore <<= 1;
          }
          if(x >= 1 && this->field[y][x - 1] == (COLOR_GRAY | CONN_SINGLE))
          {
            putblock(this, x - 1, y, 0);
            this->nVIR--;
            this->score += this->virScore;
            this->virScore <<= 1;
          }
          x += j - 1; // go to end of cleared row
        }
      }
    }
  }

  for(x = 0; x < FIELD_WID; x++)
  {
    for(y = 0; y < FIELD_HT - 3; y++)
    {
//      if((this->field[y][x] & 7) == 7)
//        continue;
      c = this->field[y][x] & 070;
      if(c >= 010 && c < 050)
      {
        for(j = 1; j < 4; j++)
          if((this->field[y + j][x] & 070) != c)
            j = 99;

        if(j < 20)
        {
          found = 1;
#if 0
          if(this->context->garbage)
            this->going[this->chainCount++] = c;
#endif
          j = 0;

          while(y + j < FIELD_HT &&
                (this->field[y + j][x] & COLOR_MASK) == (c & COLOR_MASK))
          {
            c = this->field[y + j][x];
            putblock(this, x, y + j, (c & COLOR_MASK) | CONN_CLEARED);

            /* remove boulders */
            if(x > 0 && this->field[y + j][x - 1] == (COLOR_GRAY | CONN_SINGLE))
            {
              putblock(this, x - 1, y + j, 0);
              this->nVIR--;
              this->score += this->virScore;
              this->virScore <<= 1;
            }
            if(x < FIELD_WID - 1 && this->field[y + j][x + 1] == (COLOR_GRAY | CONN_SINGLE))
            {
              putblock(this, x + 1, y + j, 0);
              this->nVIR--;
              this->score += this->virScore;
              this->virScore <<= 1;
            }

            if((c & CONN_MASK) == CONN_VIRUS) /* virus */
            {
              this->nVIR--;
              foundVir = 1;
              this->score += this->virScore;
              this->virScore <<= 1;
            }
            j++;
          }
          /* j = length of vertical match whose top is (x, y) */
          /* remove boulders on end caps */
          if(y + j < FIELD_HT && this->field[y + j][x] == (COLOR_GRAY | CONN_SINGLE))
          {
            putblock(this, x, y + j, 0);
            this->nVIR--;
            this->score += this->virScore;
            this->virScore <<= 1;
          }
          if(y >= 1 && this->field[y - 1][x] == (COLOR_GRAY | CONN_SINGLE))
          {
            putblock(this, x, y - 1, 0);
            this->nVIR--;
            this->score += this->virScore;
            this->virScore <<= 1;
          }
          y += j - 1; // go to end of cleared row
        }
      }
    }
  }

#if 0
  if(foundVir)
    PlayEffect(virusSnd);
  else if(found)
    PlayEffect(clearSnd);
#endif
  return found;
}


static void CheckLinesCleanup(Player *this)
{
  int x, y;

  /* remove cleared blocks */
  for(y = 0; y < FIELD_HT; y++)
    for(x = 0; x < FIELD_WID; x++)
      if((this->field[y][x] & CONN_MASK) == CONN_CLEARED)
        putblock(this, x, y, 0);

  /* close up open half-pills */
  for(y = 0; y < FIELD_HT; y++)
    for(x = 0; x < FIELD_WID; x++)
      switch(this->field[y][x] & CONN_MASK)
      {
      case CONN_LHALF:
        if((this->field[y][x + 1] & 7) != CONN_RHALF)
          putblock(this, x, y, (this->field[y][x] & COLOR_MASK) | CONN_SINGLE);

        break;

      case CONN_RHALF:
        if((this->field[y][x - 1] & 7) != CONN_LHALF)
          putblock(this, x, y, (this->field[y][x] & COLOR_MASK) | CONN_SINGLE);

        break;

      case CONN_THALF: // top half
        if((this->field[y - 1][x] & 7) != CONN_BHALF)
          putblock(this, x, y, (this->field[y][x] & COLOR_MASK) | CONN_SINGLE);

        break;

      case CONN_BHALF:
        if((this->field[y + 1][x] & 7) != CONN_THALF)
          putblock(this, x, y, (this->field[y][x] & COLOR_MASK) | CONN_SINGLE);

        break;

      }
}


/* Fall() ******************************
 * Moves floating pills down one space.
 */
static int Fall(Player *this)
{
  int x, y;
  int fallen = 0;

  for(y = 0; y < FIELD_HT - 1; y++)
    for(x = 0; x < FIELD_WID; x++)
      /* if there's something to move down */
      if(this->field[y][x] == 0 &&
         this->field[y + 1][x] != 0 &&
         (this->field[y + 1][x] & CONN_MASK) != CONN_VIRUS &&
         (this->field[y + 1][x] & CONN_MASK) != CONN_RHALF)
      {
        /* Handle horizontal capsules. */
        if((this->field[y + 1][x] & 7) == CONN_LHALF)
        {
          if(this->field[y][x + 1]) // If there isn't space for the pill,
            x++; // skip it.
          else
          {
            this->field[y][x] = this->field[y + 1][x];
            this->field[y + 1][x] = 0;
            x++;
            this->field[y][x] = this->field[y + 1][x];
            this->field[y + 1][x] = 0;
            add_dirty_row(this, y);
            add_dirty_row(this, y + 1);
            fallen = 1;
          }
        }
        else  /* Handle everything else. */
        {
          this->field[y][x] = this->field[y + 1][x];
          this->field[y + 1][x] = 0;
          add_dirty_row(this, y);
          add_dirty_row(this, y + 1);
          fallen = 1;
        }
      }

  return fallen;
}


static void GameOver(Player *this)
{
  nttextout(PF_MAP, 11, 9, 0x0000, "  GAME  ");
  nttextout(PF_MAP, 11, 10, 0x0000, "  OVER  ");
  this->state = STATE_GAMEOVER;
  this->clock = retrace_count + 300;
}


/* still gradually porting this from the PC */
static int Play(void)
{
  int done = 0, rVal = 0;
  Player *me;

  NewLevel();

  while(!done)
  {
    int j = JOY ^ 0x3ff;

    me = &g.p;

    make_repeats(me->repeatTime, j, 14, 2);

#if 0
    if(me->repeats[3])  /* if start was pressed */
    {
      tim.pause = 1;
      klear(screen);
      textout_centre(screen, g.lucidgray,
                     "game paused.  [esc] resume, [o]ptions, or [q]uit",
                     256 + g.xOff, g.yOff + 160, -1);

      switch(readkey() >> 8)
      {
      case KEY_Q:
        done = 1;
        break;
      case KEY_A:
      case KEY_O:
        Options();
        break;
      default:
        break;
      }

      set_palette(g.pal);
      for(j = 0; j < 2; j++)
        draw_meters(&(g.p[j]));
      tim.pause = 0;
      blit(g.backbuf, screen, 0, 0, g.xOff, g.yOff, 512, 384);
      break;
    }
#endif

    if((retrace_count & 0x0f) == 0)
    {
      animate_viruses((retrace_count >> 4) & 1);
    }

    switch(me->state)
    {
      case STATE_INACTIVE:
        break;


      case STATE_NEW_PIECE:
        if(me->field[FIELD_HT - 1][FIELD_WID / 2 - 1] ||
           me->field[FIELD_HT - 1][FIELD_WID / 2])
        {
          GameOver(me);
          break;
        }
          
        if(me->clock - retrace_count <= 0)
          NewPiece(me);
        break;

      case STATE_FALLING_PIECE:

        /* check for keypresses and act on them */
        if(me->repeatTime[1] == 1) // B: flip left
          Try2Flip(me, (me->flip + 1) & 0x03);

        if(me->repeatTime[0] == 1) // A: flip right
          Try2Flip(me, (me->flip + 3) & 0x03);

        if(me->repeatTime[7]) // move down
          me->y &= 0xffff8000;

        if(me->repeatTime[5] == 1 || me->repeatTime[5] == 13) // move left
        {
          if(!CheckOverlap(me, me->x - 0x10000, me->y, me->flip))
          {
//            PlayEffect(moveSnd);
            me->x -= 0x10000;
          }
          else
            me->repeatTime[5] = 12; // let player slide the block in
        }


        if(me->repeatTime[4] == 1 || me->repeatTime[4] == 13) // move right
        {
          if(!CheckOverlap(me, me->x + 0x10000, me->y, me->flip))
          {
//            PlayEffect(moveSnd);
            me->x += 0x10000;
          }
          else
            me->repeatTime[4] = 12; // let player slide the block in
        }

        me->y -= 2200 + me->n_pieces * 17;
        if(CheckOverlap(me, me->x, me->y, me->flip))
        {
          me->y += 2200 + me->n_pieces * 17;
          freeze_piece(me);
          me->state = STATE_CHECK;
          me->clock = retrace_count + 15;
        }
        break;

      case STATE_CHECK:
        if(me->clock - retrace_count > 0)
          break;
        if(CheckLines(me))
        {
          draw_meters(me);
          me->state = STATE_CHECKED;
        }
        else
        {
          CheckLinesCleanup(me);
          me->state = STATE_NEW_PIECE;
        }
        
        me->clock = retrace_count + 10;
        break;

      case STATE_CHECKED:
        if(me->clock - retrace_count > 0)
          break;
        CheckLinesCleanup(me);

        if(me->nVIR <= 0  /* && (!g.puyo || !g.garbage) */ )
        {
          done = 1;
          rVal = 0;
        }
        me->state = STATE_FALL;
        break;

      case STATE_FALL:
        if(me->clock - retrace_count > 0)
          break;
        if(Fall(me))
        {
#if 0
          if(g.puyo && me->comingHead)
            me->state = STATE_BOULDERS;
#endif
        }
        else
          me->state = STATE_CHECK;

        me->clock = retrace_count + 10;
        break;

      case STATE_GAMEOVER:
        if(me->clock - retrace_count > 0)
          break;

        done = 1;
        rVal = -1;
        break;

    }

    wait4vbl();
    draw_capsule(me);
#if 0
    music_play();
#endif
    draw_dirty_rows(&g.p);

  }

  return rVal;
}


void Title(void)
{
  int i;

  wait4vbl();
  LCDMODE = LCDMODE_BLANK;
  PALRAM[0] = RGB(31,31,31);
  PALRAM[1] = RGB( 0, 0, 0);

  load_text_tiles();
  for(i = 0; i < 640; i++)
  {
    MAP[PF_MAP][0][i] = 0;
  }
  nttextout(PF_MAP, 11,  4, 0x0000, "VITAMINS");
  nttextout(PF_MAP,  2,  6, 0x0000, "Milestone  1: Playability");
  nttextout(PF_MAP,  1,  7, 0x0000, "missing all sorts of goodies");
  nttextout(PF_MAP,  1,  9, 0x0000, "(This is the first full Dr.M");
  nttextout(PF_MAP,  0, 10, 0x0000, "clone on GBA, published before");
  nttextout(PF_MAP,  0, 11, 0x0000, "Nintendo's own GBA/GCN port.)");
  nttextout(PF_MAP,  3, 14, 0x0000, "[ Press START to play ]");
  nttextout(PF_MAP,  2, 17, 0x0000, "Copr. 2003 Damian Yerrick");
  nttextout(PF_MAP,  3, 18, 0x0000, "See COPYING for license");

  BGCTRL[0] = BGCTRL_PAT(0) | BGCTRL_16C | BGCTRL_NAME(PF_MAP);
  BGSCROLL[0].x = 0;
  BGSCROLL[0].y = 0;
  LCDMODE = 0 | LCDMODE_BG0 | LCDMODE_SPR;

  g.p.repeatTime[0] = 1;
  g.p.repeatTime[3] = 1;

  do {
    wait4vbl();
    make_repeats(g.p.repeatTime, (JOY ^ 0x3ff), 14, 2);
  } while(g.p.repeatTime[0] != 1 && g.p.repeatTime[3] != 1);
}


int main(void)
{
  setup_isr();

  g.dat = find_first_gbfs_file(find_first_gbfs_file);
  if(!g.dat)
  {
    LCDMODE = 0;
    PALRAM[0] = RGB(31, 0, 0);
    while(1) wait4vbl();
  }

  while(1)
  {
    Title();

    NewGame();

    while(Play() >= 0 && g.p.level < 20)
      g.p.level++;
  }
}
