                  _________________________________
              _,-'                |                `-._
            ,'                    |                    `.
           /   __    __ _   _     |       _              \
          |    \ \  / /|_|_| |_ ___ _ _ _|_|_ _   ___     |
          |     \ \/ / | |_   _|__ | ' ' | | ' `./ __|    |
          |      \  /  | | | | / _ | | | | | || |\__ \    |
          |       \/   |_|  \_|\___|_|_|_|_|_||_||___/    |
           \                      |                      /
            `._                   |                   _,'
               `-.________________|________________,-'

           Vitamins:  The FIRST Drug Matching Game for GBA


Nintendo is planning to introduce a GameCube title containing Dr.
Mario, Yoshi's Cookie, and Panel de Pon (Tetris Attack).  Apparently
it will have an unlockable feature allowing the player to transfer
the games to a Game Boy Advance system by booting the GBA off the
GCN in joybus mode.

Well, thanks to the pin eight crew, now you can have a limited
version of Dr. Mario for GBA BEFORE NINTENDO RELEASES IT!

Vitamins is a Dr. M clone for PC, part of the freepuzzlearena
package.  Developed independently from Nintendo's program, Vitamins
offers crisp control, sharp graphics, and freedom. And now it's
coming to the GBA.

This is Vitamins Milestone 1, the initial preview release intended
primarily to establish FIRST POST! of drug matching on the GBA
platform.  It can run in VisualBoyAdvance, from a flash cartridge,
or from multiboot.


=== Building ===

If you're just running the included binary (drm.mb), skip this
section.  But if you're interested in helping to develop Vitamins,
read on:

My development environment is Microsoft Windows 2000 + Devkit Advance
(http://www.io.com/~fenix/devkitadv), with the GBFS tools 
(http://www.pineight.com/gba/#gbfs) installed into the PATH.

Until I get around to writing a makefile, here's what you have to do:

1. Open a command prompt.
2. Insert ...\devkitadv\bin and ...\gbfs\tools into the PATH.
3. cd ...\drm
4. mkg
5. mk


=== Goal ===

The goal of Vitamins is to destroy all the little space invaders
floating in the bottle.  Colored pills fall from the mouth of the
bottle; carefully place four in a row to destroy like-colored
invaders.


=== Controls ===

Left, Right, Down:  Move capsule
B: Rotate capsule anticlockwise
A: Rotate capsule clockwise


=== Future ===

I plan to add the following features in a future version:
 * pausing the game
 * background wallpaper
 * difficulty menu
 * saving high scores
 * integration with PogoShell and Puzzle Arena Shell
 * polish, polish, polish
 * music
 * sound effects

I plan NOT to add the following features until a free GBA emulator
supports them:
 * Game Link support
 * non-laggy sound


=== Legal ===

� 2003 Damian Yerrick.

Pin Eight and Vitamins are trademarks of Damian Yerrick.  Nintendo,
GameCube, Dr. Mario, and Game Boy are trademarks of Nintendo.


I got first post.  Eat it Nintendo.
