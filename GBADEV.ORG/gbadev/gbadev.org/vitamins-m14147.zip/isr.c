volatile int retrace_count = 0;

#include "pin8gba.h"

void isr(void)
{
  unsigned int interrupts = INTACK;

  INTENABLE = 0;

  if(interrupts & INT_VBLANK)
  {
    retrace_count++;
  }
  BIOS_INTACK = interrupts;
  INTACK = interrupts;
  INTENABLE = 1;
}
