////////////////////////////////////////////////////////////////////////////
//File:		saving.cpp
//Date:		21 - 02 - 2003
//Program:	File for understanding the save function inside the cartrigde SRAM
//Author:		Jenswa
//Thanks to:	gbajunkie, nokturn, dovoto,
////////////////////////////////////////////////////////////////////////////


#include "gba.h"
#include "dispcnt.h"
#include "keypad.h"
#include "sprites.h"
#include "sram.h"

//gfx
#include "objpalette.h"	//OBJPalette
#include "numbers.h"	//number 0 - 9


//create an OAM variable and make it point to the address of OAM
u16* OAM = (u16*)0x7000000;

//create the array of sprites
OAMEntry sprites[128];

//variable for offset in SRAM
u16 offset = 0;

//variable for score
int score;

//wait for the screen to stop drawing
void WaitForVsync()
{
	while((volatile u16)REG_VCOUNT != 160){}
}

//Copy sprite array to OAM
void CopyOAM()
{
	u16 loop;
	u16* temp;
	temp = (u16*)sprites;
	for(loop=0; loop < 128*4; loop++)
	{
		OAM[loop] = temp[loop];
	}
}

//sprite strucure, for animation of the sprite
typedef struct
{
	u16 xpos;		//x position
	u16 ypos;		//y position
	u16 spriteFrame[9];	//total frames
	int activeFrame;	//which frame is active
}Sprite;

//Declare some sprites
Sprite scorecounter1;
Sprite scorecounter2;

// Set sprites off screen
void InitializeSprites()
{
	int x;
	for (x = 0; x < 128; x++)
	{
		sprites[x].attribute0 = 160;	//y > 159
		sprites[x].attribute1 = 240;	//x > 239
	}
}

//loads the OBJPalette
void LoadOBJPalette(){
	int x;
	for(x=0; x < 256; x++){
		OBJPaletteMem[x] = OBJPalette[x];
	}
}

//controlls the counters for the score
void UpdateCounters()
{
	int tens = (score/10)%10;
	int units = score%10;

	sprites[0].attribute2 = scorecounter1.spriteFrame[units];
	sprites[1].attribute2 = scorecounter2.spriteFrame[tens];
}

//checks the keypad on the gba
void GetInput(){

	if(KEY_DOWN(KEYUP)){
		if(score >= 0 && score < 99){
			score++;
		}
	}
	if(KEY_DOWN(KEYDOWN)){
		if(score > 0 && score <= 99){
			score--;
		}
	}
	if(KEY_DOWN(KEYSTART)){
		SaveInt(offset,score);
	}
	if(KEY_DOWN(KEYSELECT)){
		score = LoadInt(offset);
	}
}



int main()
{

	int x;

	SetMode(MODE_0 | OBJ_ENABLE | OBJ_MAP_1D);

	LoadOBJPalette();

	//score counter 1
	sprites[0].attribute0 = COLOR_256 | SQUARE | 0;
	sprites[0].attribute1 = SIZE_8 | 16;
	sprites[0].attribute2 = 594;			//pointer to tile where sprite starts

	scorecounter1.spriteFrame[0] = 594;
	scorecounter1.spriteFrame[1] = 596;
	scorecounter1.spriteFrame[2] = 598;
	scorecounter1.spriteFrame[3] = 600;
	scorecounter1.spriteFrame[4] = 602;
	scorecounter1.spriteFrame[5] = 604;
	scorecounter1.spriteFrame[6] = 606;
	scorecounter1.spriteFrame[7] = 608;
	scorecounter1.spriteFrame[8] = 610;
	scorecounter1.spriteFrame[9] = 612;
	scorecounter1.activeFrame = 594;

	//score counter 2
	sprites[1].attribute0 = COLOR_256 | SQUARE | 0;
	sprites[1].attribute1 = SIZE_8 | 8;
	sprites[1].attribute2 = 594;			//pointer to tile where sprite starts

	scorecounter2.spriteFrame[0] = 594;
	scorecounter2.spriteFrame[1] = 596;
	scorecounter2.spriteFrame[2] = 598;
	scorecounter2.spriteFrame[3] = 600;
	scorecounter2.spriteFrame[4] = 602;
	scorecounter2.spriteFrame[5] = 604;
	scorecounter2.spriteFrame[6] = 606;
	scorecounter2.spriteFrame[7] = 608;
	scorecounter2.spriteFrame[8] = 610;
	scorecounter2.spriteFrame[9] = 612;
	scorecounter2.activeFrame = 594;

//load numbers zero to nine
	for(x = 9504; x < 9824; x++)
	{
		OAMData[x] = numbersData[x-9504];
	}

	//Load the previous stored value
	score = LoadInt(offset);

	//main loop
	while(1){
		UpdateCounters();
		GetInput();
		CopyOAM();
	}
}
