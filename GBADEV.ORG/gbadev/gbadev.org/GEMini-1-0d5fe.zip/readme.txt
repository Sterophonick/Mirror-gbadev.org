
*** GEMini ver1.0 ***
*** 15 April 2005 ***

 Well, it finally happened: I actually finished one of the dozens of projects I start on :/ This is a GBA version of the many block-shuffling-and-matching puzzlers available on the internet.

 Development time of 12 days, couple hours a day. Code by me, graphics by me (apologies, I'm NO artist ok), voices by a DJ friend of mine, Ray Mankelow. Tested extensively on VisualBoyAdvance, NoCash, two GBAs, 3 GBA SPs and 1 DS (and did I get some funny looks in GameZone when I asked the attendant if I could test my flashcart in their display DS). Coded in C with some splashes of assembler, with VisualHAM being the IDE of choice. I refuse to use HAM itself though, as I see no reason to confuse a nice simple system like the GBA with an addon graphics library! On the other hand, as the GBA's a bit of a challenge for decent sound playback, I'm very grateful for the excellent MASO sound library. It's a bit eccentric, but otherwise ace. If you're getting sick of Krawall, give it a try.

 Full sourcecode will be forthcoming in a couple of weeks, it's fairly tidy at the moment but needs a brief dusting. Also I'll have a tutorial for integrating an interrupt-driven MASO with GCC too, as I found it to be unnecessarily painful, and I'm sure others could benefit. Watch this space.

 Version 1.1 will have a full credits list of the music I used; it's all PD stuff from www.modarchive.com. If you spot a track of yours that you don't want included here, let me know and I'll replace it. I did fire off emails to all the addresses I could find in the selected mods, but after nearly two weeks I haven't got a single reply. Not that I was REALLY expecting any, as some of the music comes from 1993... Oh well. I tried.

 Oh yeah. If you're putting this on a flashcart, make sure you tell your flashing software that the game uses SRAM for saving. I use a SuperCard for development, and its' SRAM's as easy to write to as VisualBoyAdvance's. This of course means that my writing routines didn't work in most other carts, as they seem FAR pickier... Hopefully FIXED. FOREVER.

 Comments, suggestions, hatemail, lawsuits, etc. to ayden@paradise.net.nz

 - Ayden Wolf (Smayds)



SOME NICE LINKIES:

 - retroremakes.com           Oh, the 80's ambiance!
 - gbadev.org                 Tons of great GBA stuff.
 - pdroms.de                  The best collection of freeware GBA roms anywhere.
 - jharbour.com/gameboy/      Taught me everything I know, this site did. TA!
