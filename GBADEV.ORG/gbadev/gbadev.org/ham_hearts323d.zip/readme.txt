HAM Tutorial Hearts
10/21/2002


Author
------

Aaron Rogers
Email: ham@aaronrogerscom
Website: www.aaronrogers.com/ham


Introduction
------------

This is the Hearts game I made for the GbaDev.org 
competition (deadline Oct 21st, 2002).


Rules Of The Game
-----------------

The rules for this game are based on the rules 
from the GbaDev.org competition announcement.
There is one difference noted at the end.  These 
rules are basically the standard for Hearts.

* The player with the 2 of Clubs leads first.
* The Queen of Spades cannot be played on the 
  first trick.
* Hearts cannot be played on the first trick 
  unless the player has no other suit.
* If a players wins all of the Hearts and the 
  Queen of Spades, known as 'Shooting The Moon,'
  that player will get no points and all of the 
  other players will get 26.
* A game is over when one of the players gets 
  100 points.  The player with the least amount 
  of points wins.

The popular version of the rules of Hearts can 
be found at the following website:
http://www.pagat.com/reverse/hearts.html

NOTE: This game differs from the rules of the 
game for the GameDev.org competition in one way:
When passing cards, they are not always passed 
to the left.  Instead, they are first passed 
left, then right, then across and finally no 
cards are passed.  This cycle continues every 
deal.


Keys
----

DURING THE GAME
 A Button:     (Un)Selects a card to play (or pass)
 Left & Right: Move the pointer left or right
 Start:        During the passing phase, to 
               finalize passing or receiving
 Select:       Reset the game

SCORING SCREENS
  A Button:     Move on to the next screen
  Start Button: Move on to the next screen


Credits
-------

* Of course I must give credit to Emmanuel 
  Schleussinger for creating the HAM library.
  I used it with C++ to create this game.
  http://www.ngine.de/ham.html

* I based my AI off of the following website.
  When I say 'based' I do not mean that I used 
  any code from the website - just ideas.
  http://student.cns.uni.edu/~symonds/hearts.html

* As for the graphics, I used GPL graphics from 
  the PySol cardset from the following site:
  http://www.oberhumer.com/opensource/pysol/
