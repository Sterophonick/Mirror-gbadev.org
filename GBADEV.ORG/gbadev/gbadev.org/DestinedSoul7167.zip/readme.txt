Destined Soul
by Edmund
This is my third demo!

To GBADev.org
Please only make the ginsingtome@hotmail.com email available to people.
Thanks
Edmund