#include <string.h>

#ifndef JEWELCRASH_H
#define JEWELCRASH_H

//grid constants
#define GRID_HEIGHT 18
#define GRID_WIDTH 10
#define INPUT_DELAY 10
#define JEWEL_X_START_POS 4
#define JEWEL_Y_START_POS 1

//shape constants
#define T_SHAPE 1
#define L_SHAPE 2
#define SQ_SHAPE 3
#define LN_SHAPE 4
#define PL_SHAPE 5
#define PL2_SHAPE 6

//our jewel constants
#define BLANK_JEWEL 0
#define RED_JEWEL 2
#define YELLOW_JEWEL 4
#define GREEN_JEWEL 6
#define CYAN_JEWEL 8
#define BLUE_JEWEL 10
#define PURPLE_JEWEL 12

//animation constants
#define EXP_0 14
#define EXP_1 16
#define EXP_2 18
#define EXP_3 20

//fontmap constants
#define FONT_A 22
#define FONT_B 24
#define FONT_C 26
#define FONT_D 28
#define FONT_E 30
#define FONT_F 32
#define FONT_G 34
#define FONT_H 36
#define FONT_I 38
#define FONT_J 40
#define FONT_K 42
#define FONT_L 44
#define FONT_M 46
#define FONT_N 48
#define FONT_O 50
#define FONT_P 52
#define FONT_Q 54
#define FONT_R 56
#define FONT_S 58
#define FONT_T 60
#define FONT_U 62
#define FONT_V 64
#define FONT_W 68
#define FONT_X 70
#define FONT_Y 72
#define FONT_Z 74
#define FONT_0 76
#define FONT_1 78
#define FONT_2 80
#define FONT_3 82
#define FONT_4 84
#define FONT_5 86
#define FONT_6 88
#define FONT_7 90
#define FONT_8 92
#define FONT_9 94

typedef struct
{
	u16 cell[3][3];
	int x;
	int y;
	bool falling;
	char shape;

}Jewelset;

u8 sprite_count = 0;

u16* OAM = (u16*)0x7000000;
OAMEntry sprites[128];
pRotData rotData = (pRotData)sprites;
Bg bg2;

void CopyOAM()
{
	u16 loop;
	u16* temp;
	temp = (u16*)sprites;
	for(loop = 0; loop < 128*4; loop++)

	{
		OAM[loop] = temp[loop];
	}
}

void InitializeSprites()
{
	u16 loop;
	for(loop = 0; loop < 128; loop++)
	{
		sprites[loop].attribute0 = 160;
		sprites[loop].attribute1 = 240;
	}
}

void WaitForVsync()
{
	while((volatile u16)REG_VCOUNT != 160);
}

int PlotText(const char *text, const int x, const int y, OAMEntry *sprites, int sprite_count)
{
	if (((strlen(text) * 8) + x ) > SCREEN_WIDTH)
		return sprite_count;

	for (int i = 0; i < strlen(text); i++)
	{
		sprites[sprite_count].attribute0 = COLOR_256 | SQUARE | y;
		sprites[sprite_count].attribute1 = SIZE_8 | x + (i * 8);
		sprites[sprite_count].attribute2 = BLANK_JEWEL;

		//this plots chars a..z
		if (((int)text[i] > 96) && ((int)text[i] < 123))
			sprites[sprite_count].attribute2 = (((int)text[i]) * 2) - 172;
		//this plots nums 0..9
		if (((int)text[i] > 47) && ((int)text[i] < 58))
			sprites[sprite_count].attribute2 = (((int)text[i]) * 2) - 22; 

		sprite_count++;
	}
	return sprite_count;
}

int inline DrawSprite(const int sprite_index, const int x_offset, const int y_offset, const int x_cell, const int y_cell, OAMEntry * sprites, Jewelset * jewel)
{
	if (jewel->cell[x_cell][y_cell] > 0)
	{
		sprites[sprite_index].attribute0 = COLOR_256 | SQUARE | ((jewel->y + y_offset) * 8) + 8;
		sprites[sprite_index].attribute1 = SIZE_8 | ((jewel->x  + x_offset) * 8) + 16;
		sprites[sprite_index].attribute2 = jewel->cell[x_cell][y_cell];
	}
	else
	{
		sprites[sprite_index].attribute0 = COLOR_256 | SQUARE | 160;
		sprites[sprite_index].attribute1 = SIZE_8 | 240;
		sprites[sprite_index].attribute2 = 0;
	}

		return 0;
}

u8 ConvertSpriteToBG(const int sprite)
{
	switch (sprite)
	{
		case (BLANK_JEWEL):
			return 0x00;
			break;
		case (RED_JEWEL):
			return 0x01;
			break;
		case (YELLOW_JEWEL):
			return 0x02;
			break;
		case (GREEN_JEWEL):
			return 0x03;
			break;
		case (CYAN_JEWEL):
			return 0x04;
			break;
		case (BLUE_JEWEL):
			return 0x05;
			break;
		case (PURPLE_JEWEL):
			return 0x06;
			break;
		default:
			return 0x00;
			break;
	}
  }

int RenderBG(Bg *bg, unsigned char * grid)
{
	for (int grid_y = 0; grid_y < GRID_HEIGHT; grid_y++)
	{
		for (int grid_x = 0; grid_x < GRID_WIDTH; grid_x+=2)
			bg->mapData[((grid_y * 16) + 16 + (grid_x/2)) + 1] = ConvertSpriteToBG(grid[(grid_y * GRID_WIDTH) + grid_x])+(ConvertSpriteToBG(grid[(grid_y * GRID_WIDTH) + grid_x + 1])<<8);
	
	}

	return 0;
}


int RenderGrid (OAMEntry * sprites, unsigned char * grid)
{
	//render the blocks on the grid to the background

	int sprite_grid_count = sprite_count;

	for (int grid_y = 0; grid_y < GRID_HEIGHT; grid_y++)
	{
		for (int grid_x = 0; grid_x < GRID_WIDTH; grid_x++)
		{
			if (grid[(grid_y * GRID_WIDTH) + grid_x])
			{
				sprites[sprite_grid_count].attribute0 = COLOR_256 | SQUARE | (grid_y * 8) + 8;
				sprites[sprite_grid_count].attribute1 = SIZE_8 | (grid_x * 8) + 16;		
				sprites[sprite_grid_count].attribute2 = grid[(grid_y * GRID_WIDTH) + grid_x];
				sprite_grid_count++;
			}
		}
	}

}


int inline GetRandomShape()
{
	int t = rand()%6+1;
	switch (t)
	{
	case (1):
			return T_SHAPE;
			break;
	case (2):
			return L_SHAPE;
			break;
	case (3):
			return SQ_SHAPE;
			break;
	case (4):
			return LN_SHAPE;
			break;
	case (5):
			return PL_SHAPE;
			break;
	case (6):
			return PL2_SHAPE;
			break;
	default:
			return 0;
			break;
	}
}

int SetShape(const int shape, Jewelset * jewel)
{
	jewel->shape = shape;

	switch (shape)
	{
		case (T_SHAPE):
		{
			jewel->cell[0][0] = 0;
			jewel->cell[0][1] = RED_JEWEL;
			jewel->cell[0][2] = 0;
			jewel->cell[1][0] = RED_JEWEL;
			jewel->cell[1][1] = RED_JEWEL;
			jewel->cell[1][2] = 0;
			jewel->cell[2][0] = 0;
			jewel->cell[2][1] = RED_JEWEL;
			jewel->cell[2][2] = 0;
		}
		break;
		case (L_SHAPE):
		{
			jewel->cell[0][0] = 0;
			jewel->cell[0][1] = 0;
			jewel->cell[0][2] = 0;
			jewel->cell[1][0] = YELLOW_JEWEL;
			jewel->cell[1][1] = YELLOW_JEWEL;
			jewel->cell[1][2] = YELLOW_JEWEL;
			jewel->cell[2][0] = YELLOW_JEWEL;
			jewel->cell[2][1] = 0;
			jewel->cell[2][2] = 0;
		}
		break;
		case (SQ_SHAPE):
		{
			jewel->cell[0][0] = GREEN_JEWEL;
			jewel->cell[0][1] = GREEN_JEWEL;
			jewel->cell[0][2] = 0;
			jewel->cell[1][0] = GREEN_JEWEL;
			jewel->cell[1][1] = GREEN_JEWEL;
			jewel->cell[1][2] = 0;
			jewel->cell[2][0] = 0;
			jewel->cell[2][1] = 0;
			jewel->cell[2][2] = 0;
		}
		break;
		case (LN_SHAPE):
		{
			jewel->cell[0][0] = 0;
			jewel->cell[0][1] = 0;
			jewel->cell[0][2] = 0;
			jewel->cell[1][0] = CYAN_JEWEL;
			jewel->cell[1][1] = CYAN_JEWEL;
			jewel->cell[1][2] = CYAN_JEWEL;
			jewel->cell[2][0] = 0;
			jewel->cell[2][1] = 0;
			jewel->cell[2][2] = 0;
		}
		break;
		case (PL_SHAPE):
		{
			jewel->cell[0][0] = 0;
			jewel->cell[0][1] = BLUE_JEWEL;
			jewel->cell[0][2] = 0;
			jewel->cell[1][0] = 0;
			jewel->cell[1][1] = BLUE_JEWEL;
			jewel->cell[1][2] = BLUE_JEWEL;
			jewel->cell[2][0] = 0;
			jewel->cell[2][1] = 0;
			jewel->cell[2][2] = BLUE_JEWEL;
		}
		break;
		case (PL2_SHAPE):
		{
			jewel->cell[0][0] = 0;
			jewel->cell[0][1] = 0;
			jewel->cell[0][2] = PURPLE_JEWEL;
			jewel->cell[1][0] = 0;
			jewel->cell[1][1] = PURPLE_JEWEL;
			jewel->cell[1][2] = PURPLE_JEWEL;
			jewel->cell[2][0] = 0;
			jewel->cell[2][1] = PURPLE_JEWEL;
			jewel->cell[2][2] = 0;
		}
		break;
	}
}

int PickJewelSet(Jewelset * jewel)
{
	int shape = GetRandomShape();
	SetShape(shape,jewel);

	jewel->x = JEWEL_X_START_POS;
	jewel->y = JEWEL_Y_START_POS;
	jewel->falling = true;

	return 0;
}

int ClearSprites(OAMEntry * sprites, int low, int high)
{
	for (low; low <= high; low++)
	{
		sprites[low].attribute0 = COLOR_256 | SQUARE | 160;	
		sprites[low].attribute1 = SIZE_8 | 240;		
		sprites[low].attribute2 = BLANK_JEWEL;
	}
}

int MoveLeft(Jewelset * jewel, unsigned char * grid)
{
	bool moveLeft = true;

	if (jewel->cell[2][0] || jewel->cell[2][1] || jewel->cell[2][2])
	{
		if (jewel->x > 0)
		{
			if ((grid[(jewel->y -1) * GRID_WIDTH + jewel->x] && jewel->cell[2][0]) || (grid[jewel->y * GRID_WIDTH + jewel->x] && jewel->cell[2][1]) || (grid[(jewel->y + 1) * GRID_WIDTH + jewel->x] && jewel->cell[2][2]))
				moveLeft = false;
		}
		else
			moveLeft = false;
	}


	if (jewel->cell[1][0] || jewel->cell[1][1] || jewel->cell[1][2])
	{
		if (jewel->x > 0)
		{
			if ((grid[(jewel->y -1) * GRID_WIDTH + jewel->x - 1] && jewel->cell[1][0]) || (grid[jewel->y * GRID_WIDTH + jewel->x - 1] && jewel->cell[1][1]) || (grid[(jewel->y + 1) * GRID_WIDTH + jewel->x - 1] && jewel->cell[1][2]))
				moveLeft = false;
		}
		else
			moveLeft = false;
	}
	
	if (jewel->cell[0][0] || jewel->cell[0][1] || jewel->cell[0][2])
	{
		if (jewel->x > 1)
		{
			if ((grid[(jewel->y -1) * GRID_WIDTH + jewel->x - 2] && jewel->cell[0][0]) || (grid[jewel->y * GRID_WIDTH + jewel->x - 2] && jewel->cell[0][1]) || (grid[(jewel->y + 1) * GRID_WIDTH + jewel->x - 2] && jewel->cell[0][2]))
				moveLeft = false;
		}
		else
			moveLeft = false;
	}

	if (moveLeft) jewel->x -= 1;
	return 0;
}

int MoveRight(Jewelset * jewel, unsigned char * grid)
{
	bool moveRight = true;

	if (jewel->cell[0][0] || jewel->cell[0][1] || jewel->cell[0][2])
	{
		if (jewel->x < GRID_WIDTH)
			//if we are at least 1 space out from the left wall
		{
			if ((grid[(jewel->y -1) * GRID_WIDTH + jewel->x] && jewel->cell[0][0]) || (grid[jewel->y * GRID_WIDTH + jewel->x] && jewel->cell[0][1]) || (grid[(jewel->y + 1) * GRID_WIDTH + jewel->x] && jewel->cell[0][2]))
				moveRight = false;
		}
		else
			moveRight = false;
	}
	
	if (jewel->cell[1][0] || jewel->cell[1][1] || jewel->cell[1][2])
	{
		if (jewel->x < GRID_WIDTH -1 )
			//if we are at least 1 space out from the left wall
		{
			if ((grid[(jewel->y -1) * GRID_WIDTH + jewel->x + 1] && jewel->cell[1][0]) || (grid[jewel->y * GRID_WIDTH + jewel->x + 1] && jewel->cell[1][1]) || (grid[(jewel->y + 1) * GRID_WIDTH + jewel->x + 1] && jewel->cell[1][2]))
				moveRight = false;
		}
		else
			moveRight = false;
	}

	if (jewel->cell[2][0] || jewel->cell[2][1] || jewel->cell[2][2])
	{
		if (jewel->x < GRID_WIDTH - 2)
			//if we are at least 2 spaces out from the right wall
		{
			if ((grid[(jewel->y -1) * GRID_WIDTH + jewel->x + 2] && jewel->cell[2][0]) || (grid[jewel->y * GRID_WIDTH + jewel->x + 2] && jewel->cell[2][1]) || (grid[(jewel->y + 1) * GRID_WIDTH + jewel->x + 2] && jewel->cell[2][2]))
				moveRight = false;
		}
		else
			moveRight = false;
	}

	if (moveRight) jewel->x += 1;

	return 0;
}

int MoveDown(Jewelset * jewel, unsigned char * grid)
{
	if (jewel->cell[0][0] || jewel->cell[1][0] || jewel->cell[2][0])
	{
		if (jewel->y < GRID_HEIGHT)
		{
			if ((grid[(jewel->y) * GRID_WIDTH + jewel->x - 1] && jewel->cell[0][0]) || (grid[(jewel->y) * GRID_WIDTH + jewel->x] && jewel->cell[1][0]) || (grid[(jewel->y) * GRID_WIDTH + (jewel->x + 1)] && jewel->cell[2][0]))
				jewel->falling = false;
		}
		else
			jewel->falling = false;
	}
	
	if (jewel->cell[0][1] || jewel->cell[1][1] || jewel->cell[2][2])
	{
		if (jewel->y < GRID_HEIGHT -1)
		{
			if ((grid[(jewel->y + 1 ) * GRID_WIDTH + jewel->x - 1] && jewel->cell[0][1]) || (grid[(jewel->y + 1) * GRID_WIDTH + jewel->x] && jewel->cell[1][1]) || (grid[(jewel->y + 1) * GRID_WIDTH + (jewel->x + 1)] && jewel->cell[2][1]))
				jewel->falling = false;
		}
		else
			jewel->falling = false;
	}
	
	if (jewel->cell[0][2] || jewel->cell[1][2] || jewel->cell[2][2])
	{
		if (jewel->y < GRID_HEIGHT -2)
		{
			if ((grid[(jewel->y + 2) * GRID_WIDTH + jewel->x - 1] && jewel->cell[0][2]) || (grid[(jewel->y + 2) * GRID_WIDTH + jewel->x] && jewel->cell[1][2]) || (grid[(jewel->y + 2) * GRID_WIDTH + (jewel->x + 1)] && jewel->cell[2][2]))
				jewel->falling = false;
		}
		else
			jewel->falling = false;
	}

	if (jewel->falling) jewel->y += 1;

}

int RotateClockwise(Jewelset * jewel, unsigned char * grid)
{
	if (jewel->y <= 0 || jewel->y == GRID_HEIGHT - 1)
		return 0;

	if (jewel->shape == SQ_SHAPE)
		return 0;

	//protect against rotating bottom layer beyond left boundary
	if ((jewel->cell[0][2] || jewel->cell[1][2] || jewel->cell[2][2]) && jewel->x == 0)
		return 0;

	//protect against rotating top layer beyond right boundary
	if ((jewel->cell[0][0] || jewel->cell[1][0] || jewel->cell[2][0]) && jewel->x == GRID_WIDTH - 1)
		return 0;

	if (jewel->cell[0][0] && grid[((jewel->y - 1) * GRID_WIDTH) + jewel->x + 1])
		return 0;

	if (jewel->cell[1][0] && grid[((jewel->y) * GRID_WIDTH) + jewel->x + 1])
		return 0;

	if (jewel->cell[2][0] && grid[((jewel->y + 1) * GRID_WIDTH) + jewel->x + 1])
		return 0;

	if (jewel->cell[0][1] && grid[((jewel->y - 1) * GRID_WIDTH) + jewel->x])
		return 0;

	if (jewel->cell[2][1] && grid[((jewel->y + 1) * GRID_WIDTH) + jewel->x])
		return 0;

	if (jewel->cell[0][2] && grid[((jewel->y - 1) * GRID_WIDTH) + jewel->x - 1])
		return 0;

	if (jewel->cell[1][2] && grid[((jewel->y) * GRID_WIDTH) + jewel->x - 1])
		return 0;

	if (jewel->cell[2][2] && grid[((jewel->y + 1) * GRID_WIDTH) + jewel->x - 1])
		return 0;

	int cell_0_0 = jewel->cell[0][0];
	int cell_1_0 = jewel->cell[1][0];

	jewel->cell[0][0] = jewel->cell[0][2];
	jewel->cell[1][0] = jewel->cell[0][1];
	jewel->cell[0][1] = jewel->cell[1][2];
	jewel->cell[0][2] = jewel->cell[2][2];
	jewel->cell[1][2] = jewel->cell[2][1];
	jewel->cell[2][2] = jewel->cell[2][0];
	jewel->cell[2][0] = cell_0_0;
	jewel->cell[2][1] = cell_1_0;

	return 0;
}

int RotateCounter(Jewelset * jewel, unsigned char * grid)
{
	if (jewel->y <= 0 || jewel->y == GRID_HEIGHT - 1)
		return 0;

	if (jewel->shape == SQ_SHAPE)
		return 0;

	//protect against rotating bottom layer beyond right boundary
	if ((jewel->cell[0][2] || jewel->cell[1][2] || jewel->cell[2][2]) && jewel->x == GRID_WIDTH - 1)
		return 0;

	//protect against rotating top layer beyond right boundary
	if ((jewel->cell[0][0] || jewel->cell[1][0] || jewel->cell[2][0]) && jewel->x == 0)
		return 0;

	if (jewel->cell[0][0] && grid[((jewel->y + 1) * GRID_WIDTH) + jewel->x - 1])
		return 0;

	if (jewel->cell[1][0] && grid[((jewel->y) * GRID_WIDTH) + jewel->x - 1])
		return 0;

	if (jewel->cell[2][0] && grid[((jewel->y - 1) * GRID_WIDTH) + jewel->x - 1])
		return 0;

	if (jewel->cell[0][1] && grid[((jewel->y + 1) * GRID_WIDTH) + jewel->x])
		return 0;

	if (jewel->cell[2][1] && grid[((jewel->y - 1) * GRID_WIDTH) + jewel->x])
		return 0;

	if (jewel->cell[0][2] && grid[((jewel->y + 1) * GRID_WIDTH) + jewel->x + 1])
		return 0;

	if (jewel->cell[1][2] && grid[((jewel->y) * GRID_WIDTH) + jewel->x + 1])
		return 0;

	if (jewel->cell[2][2] && grid[((jewel->y - 1) * GRID_WIDTH) + jewel->x + 1])
		return 0;

	int cell_2_2 = jewel->cell[2][2];
	int cell_1_2 = jewel->cell[1][2];
	int cell_2_1 = jewel->cell[2][1];
	int cell_2_0 = jewel->cell[2][0];

	jewel->cell[2][2] = jewel->cell[0][2];
	jewel->cell[1][2] = jewel->cell[0][1];
	jewel->cell[0][2] = jewel->cell[0][0];
	jewel->cell[2][1] = cell_1_2;
	jewel->cell[0][1] = jewel->cell[1][0];
	jewel->cell[2][0] = cell_2_2;
	jewel->cell[1][0] = cell_2_1;
	jewel->cell[0][0] = cell_2_0;

	return 0;
}


int AddToGrid(Jewelset * jewel, unsigned char  * grid)
{
	if (jewel->cell[0][0]) grid[((jewel->y - 1) * GRID_WIDTH) + (jewel->x - 1)] = jewel->cell[0][0];
	if (jewel->cell[1][0]) grid[((jewel->y - 1) * GRID_WIDTH) + jewel->x] = jewel->cell[1][0];
	if (jewel->cell[2][0]) grid[((jewel->y - 1) * GRID_WIDTH) + (jewel->x + 1)] = jewel->cell[2][0];

	if (jewel->cell[0][1]) grid[(jewel->y * GRID_WIDTH) + (jewel->x - 1)] = jewel->cell[0][1];
	if (jewel->cell[1][1]) grid[(jewel->y * GRID_WIDTH) + jewel->x] = jewel->cell[1][1];
	if (jewel->cell[2][1]) grid[(jewel->y * GRID_WIDTH) + (jewel->x + 1)] = jewel->cell[2][1];

	if (jewel->cell[0][2]) grid[((jewel->y + 1) * GRID_WIDTH) + (jewel->x - 1)] = jewel->cell[0][2];
	if (jewel->cell[1][2]) grid[((jewel->y + 1) * GRID_WIDTH) + jewel->x] = jewel->cell[1][2];
	if (jewel->cell[2][2]) grid[((jewel->y + 1) * GRID_WIDTH) + (jewel->x + 1)] = jewel->cell[2][2];

}

int CheckCombos(Jewelset * jewel, unsigned char * grid, OAMEntry * sprites, u16 *lines)
{

	int this_score = 0;

	for (int y = 0; y < GRID_HEIGHT; y++)
	{
		bool fill_row = true;
		for (int x = 0; x < GRID_WIDTH; x++)
		{
			fill_row = (grid[(y * GRID_WIDTH) + x] > BLANK_JEWEL);
			if (!fill_row)
				break;
		}

		if (fill_row)
		{
			this_score += 1;
			//we have found a row
			ClearSprites(sprites, 0, 8);

			for (int x = 0; x < GRID_WIDTH; x++)
				grid[(y * GRID_WIDTH) + x] = EXP_0;

			RenderGrid(sprites,grid);
			for (int p = 0; p < 30000; p++);
			WaitForVsync();			//waits for the screen to stop drawing
			CopyOAM();			//Copies sprite array into OAM.

			for (int x = 0; x < GRID_WIDTH; x++)
				grid[(y * GRID_WIDTH) + x] = EXP_1;

			RenderGrid(sprites,grid);
			for (int p = 0; p < 30000; p++);
			WaitForVsync();			//waits for the screen to stop drawing
			CopyOAM();			//Copies sprite array into OAM.


			for (int x = 0; x < GRID_WIDTH; x++)
				grid[(y * GRID_WIDTH) + x] = EXP_2;

			RenderGrid(sprites,grid);
			for (int p = 0; p < 30000; p++);
			WaitForVsync();			//waits for the screen to stop drawing
			CopyOAM();			//Copies sprite array into OAM.

			for (int x = 0; x < GRID_WIDTH; x++)
				grid[(y * GRID_WIDTH) + x] = EXP_3;

			RenderGrid(sprites,grid);
			for (int p = 0; p < 30000; p++);
			WaitForVsync();			//waits for the screen to stop drawing
			CopyOAM();			//Copies sprite array into OAM.

			for (int x = 0; x < GRID_WIDTH; x++)
				grid[(y * GRID_WIDTH) + x] = BLANK_JEWEL;

			RenderGrid(sprites,grid);
			for (int p = 0; p < 30000; p++);
			WaitForVsync();			//waits for the screen to stop drawing
			CopyOAM();			//Copies sprite array into OAM.
				
			//now push everything down a row
			for (int i = (y - 1); i >= 0; i--)
			{
				for (int x = 0; x < GRID_WIDTH; x++)
					grid[((i + 1) * GRID_WIDTH) + x] = grid[(i * GRID_WIDTH) + x];

			}		
			RenderGrid(sprites, grid);
			ClearSprites(sprites, sprite_count,127);
			WaitForVsync();
			CopyOAM();
		}

	}

	*lines+= this_score;

	switch (this_score)
	{
		case(0):
			return 0;
			break;
		case(1):
			return 100;
			break;
		case(2):
			return 500;
			break;
		case(3):
			return 2000;
			break;
	}

}

int CheckLevel(u16 lines, u8 *level)
{
	int t;
	
	if (lines < 10)
		t = 1;
	if (lines >= 10)
		t = 2;
	if (lines >= 25)
		t = 3;
	if (lines >= 50)
		t = 4;
	if (lines > 100)
		t = 5;
	if (lines > 200)
		t = 6;
	if (lines > 300)
		t = 7;
	if (lines > 400)
		t = 8;
	if (lines > 500)
		t = 9;
	
	*level = t;
}

#endif
