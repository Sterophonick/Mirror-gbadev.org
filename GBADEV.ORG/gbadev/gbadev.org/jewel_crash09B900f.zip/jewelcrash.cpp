#include <stdio.h>
#include <stdlib.h>
#include "gba.h"
#include "keypad.h"
#include "dispcnt.h"
#include "bg.h"
#include "sprites.h"
#include "jewels.h"
#include "explosion.h"
#include "fontmap.h"
#include "palette.h"
#include "background.h"
#include "backgroundMap.c"
#include "jewelcrash.h"

int main(void)
{
	u16 loop;
	int frame_delay = 32;
	u16 score = 0;
	u8 level = 1;
	u16 lines = 0;	
	u16 time_seed = 0;

	//grid playing area
	unsigned char grid [GRID_WIDTH * GRID_HEIGHT];

	for (int i; i < (GRID_WIDTH * GRID_HEIGHT); i++)
	{
		grid[i] = 0;
	}

	SetMode(MODE_1 | OBJ_ENABLE | OBJ_MAP_1D); //set mode 1 and enable sprites and 1d mapping


	InitializeSprites();                       //set all sprites off screen (stops artifact)

	for (loop = 0; loop < 224; loop++)
	{
		OAMData[loop] = jewelsData[loop];
	}

	for (loop = 224; loop < 352; loop++)
	{
		OAMData[loop] = explosionData[loop - 224];
	}

	for (loop = 352; loop < 1504; loop++)
	{
		OAMData[loop] = fontmapData[loop - 352];
	}

	for(loop = 0; loop < 256; loop++)          //load the sprite palette into memory
		OBJPaletteMem[loop] = palette[loop];

	while((*KEYS) & KEY_START)
	{
		time_seed++;
		if (time_seed >= 256) time_seed = 0;
		sprite_count = PlotText("jewel crash",72,16, sprites, sprite_count);
		sprite_count = PlotText("written by ",72,32, sprites, sprite_count);
		sprite_count = PlotText("daniel crowley wilson",40,48,sprites, sprite_count);
		sprite_count = PlotText("may 2003",80,64,sprites, sprite_count);
		sprite_count = PlotText("press start button",48,120,sprites, sprite_count);
		WaitForVsync();			//waits for the screen to stop drawing
		CopyOAM();			//Copies sprite array into OAM.
		sprite_count = 0;
	}

	InitializeSprites();

	bg2.number = 2;					//background number 0-3
	bg2.charBaseBlock = 0;          //tile data position (right at the start of the available memory on 16Kb boundary)
	bg2.screenBaseBlock = 27;		//map data position on 2Kb boundary
	bg2.colorMode = BG_COLOR_256;   //256-colour background
	bg2.size = ROTBG_SIZE_256x256;  //size of map
	bg2.mosaic = 0;                 //not enabled
	bg2.x_scroll = 0;			//scrolling variables
	bg2.y_scroll = 0;

	//Point to correct tile and map data, update the Background and Display registers accordingly
    EnableBackground(&bg2);

	for(loop = 0; loop < 256; loop++)
		BGPaletteMem[loop] = backgroundPalette[loop];     //load the background palette into memory

	for(loop = 0; loop < background_WIDTH * background_HEIGHT /2; loop++)  //load tile image data
		bg2.tileData[loop] = backgroundData[loop];

	//load the map image data
	u16 *map;
	map = (u16*)backgroundMap;
	
	for(loop = 0; loop < 32*32/2; loop++) //32x32 tiles /2 because 16 bit copy
		bg2.mapData[loop] = map[loop];
	
	srand(time_seed);
	
	//init a Jewelset
	Jewelset jewel;
	Jewelset nextjewel;

	PickJewelSet(&jewel);
	PickJewelSet(&nextjewel);

	nextjewel.x = 13;
	nextjewel.y = 15;

	int framecount = 1;
	bool FlagLeft = false;
	bool FlagRight = false;
	bool FlagDown = false;
	bool FlagCounter = false;
	bool FlagClockwise = false;
	bool FlagStart = false;
	
	for (int i = 0; i < 30000; i++);

	while(1)                                //main loop
    {
		//pause loop
		if(!((*KEYS) & KEY_START))
		{
			while(1)
			{ 
				WaitForVsync(); 
				if(!(*KEYS & KEY_START)) break; 
			}
		}


		//get inputs
		if(!((*KEYS) & KEY_LEFT)) FlagLeft = true;            
		if(!((*KEYS) & KEY_RIGHT)) FlagRight = true;            
		if(!((*KEYS) & KEY_DOWN)) FlagDown = true;            
		if(!((*KEYS) & KEY_A)) FlagCounter = true;
		if(!((*KEYS) & KEY_B)) FlagClockwise = true;

		if (framecount % INPUT_DELAY == 0)
		{
			//get inputs
			if(FlagLeft)
			{
				FlagLeft = false;
				MoveLeft(&jewel, grid);            
			}
			if(FlagRight)
			{
				FlagRight = false;
				MoveRight(&jewel, grid);            
			}
			if (FlagCounter && ((*KEYS) & KEY_A)) // note the additional check here to see if the key is still being held down
			{
				FlagCounter = false;
				RotateCounter(&jewel, grid);
			}

			if(FlagClockwise && ((*KEYS) & KEY_B)) // note the additional check here to see if the key is still being held down
			{
				FlagClockwise = false;
				RotateClockwise(&jewel, grid);
			}

		}

		if (framecount % (INPUT_DELAY/2) == 0)
		{
			if(FlagDown)
			{
				FlagDown = false;
				MoveDown(&jewel, grid);            
			}
		}
		
		if (framecount == frame_delay)
		{
			framecount = 1;
			MoveDown(&jewel, grid);
		}
		framecount++;

		//game ai
		if (grid[2 * GRID_WIDTH + JEWEL_X_START_POS])
		{
			PlotText("game  over",16,72,sprites, sprite_count);
			AddToGrid(&jewel, grid);
			RenderBG(&bg2, grid);
		}
		else
		{
			//render next frame
			DrawSprite(0,-1,-1,0,0, sprites, &jewel);
			DrawSprite(1,-1,0,0,1, sprites, &jewel);
			DrawSprite(2,-1,1,0,2, sprites, &jewel);
			DrawSprite(3,0,-1,1,0, sprites, &jewel);
			DrawSprite(4,0,0,1,1, sprites, &jewel);
			DrawSprite(5,0,1,1,2, sprites, &jewel);
			DrawSprite(6,1,-1,2,0, sprites, &jewel);
			DrawSprite(7,1,0,2,1, sprites, &jewel);
			DrawSprite(8,1,1,2,2, sprites, &jewel);

			DrawSprite(9,-1,-1,0,0, sprites, &nextjewel);
			DrawSprite(10,-1,0,0,1, sprites, &nextjewel);
			DrawSprite(11,-1,1,0,2, sprites, &nextjewel);
			DrawSprite(12,0,-1,1,0, sprites, &nextjewel);
			DrawSprite(13,0,0,1,1, sprites, &nextjewel);
			DrawSprite(14,0,1,1,2, sprites, &nextjewel);
			DrawSprite(15,1,-1,2,0, sprites, &nextjewel);
			DrawSprite(16,1,0,2,1, sprites, &nextjewel);
			DrawSprite(17,1,1,2,2, sprites, &nextjewel);

			sprite_count = 18;

			sprite_count = PlotText("next",112,98, sprites, sprite_count);
			sprite_count = PlotText("score",180,18, sprites, sprite_count);
			char score_buffer[7];
			sprintf(score_buffer,"%d",score);
			sprite_count = PlotText(score_buffer,180,40, sprites, sprite_count);
			sprite_count = PlotText("level",180,64, sprites, sprite_count);
			char level_buffer[2];
			sprintf(level_buffer,"%d",level);
			sprite_count = PlotText(level_buffer,180,88, sprites, sprite_count);
			sprite_count = PlotText("lines",180,110, sprites, sprite_count);
			char lines_buffer[7];
			sprintf(lines_buffer,"%d",lines);
			sprite_count = PlotText(lines_buffer,180,134, sprites, sprite_count);

			//increment score for each  jewel in lowest line
			if (!(jewel.falling))
			{
				if (jewel.cell[0][2] || jewel.cell[1][2] || jewel.cell[2][2])
				{
					if (jewel.cell[0][2]) score++;
					if (jewel.cell[1][2]) score++;
					if (jewel.cell[2][2]) score++;
				}
				else
				{
					if (jewel.cell[0][1] || jewel.cell[1][1] || jewel.cell[2][1])
					{
						if (jewel.cell[0][1]) score++;
						if (jewel.cell[1][1]) score++;
						if (jewel.cell[2][1]) score++;
					}
					else
					{
						if (jewel.cell[0][0] || jewel.cell[1][0] || jewel.cell[2][0])
						{
							if (jewel.cell[0][0]) score++;
							if (jewel.cell[1][0]) score++;
							if (jewel.cell[2][0]) score++;
						}
					}
				}		

				AddToGrid(&jewel, grid);
				RenderBG(&bg2, grid);
				score += CheckCombos(&jewel, grid, sprites, &lines);
				CheckLevel(lines, &level);
				RenderBG(&bg2, grid);
				jewel = nextjewel;
				jewel.x = JEWEL_X_START_POS;
				jewel.y = JEWEL_Y_START_POS;
				PickJewelSet(&nextjewel);
				nextjewel.x = 13;
				nextjewel.y = 15;
			}
		}

		WaitForVsync();			//waits for the screen to stop drawing
		CopyOAM();			//Copies sprite array into OAM.

	}//end while
	return 0;

}
