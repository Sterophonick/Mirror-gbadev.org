Jewel Crash v0.9 Beta
by Daniel Crowley - Wilson

dan@machinerider.com
www.machinerider.com

License
========================================
This program is freeware. Feel free to do what you like with it, as long as you don't try to sell it. If you redistribute the binary and/or the source, please keep this readme file intact.

About
========================================
This is my first GBA game. I decided to start with something simple, hence a clone of that very famous game that debuted on the original Gameboy. It's not incredibly original, but it does work the way you'd expect, which was all I was looking for. Combine one or more horizontal columns of jewels to detonate the line and score points.

Points scores are as follows:
1 point per jewel that lands on the playing grid
100 points for 1 line of jewels
500 points for 2 lines of jewels
2000 points for 3 lines of jewels

There are 9 levels. Each increase will cause the jewels to fall at a faster rate. You can't clock this game; Once you get to Level 9 there it will stay until your inevitable demise. I suppose you could consider the game clocked if you manage to overflow the score buffer ;p


Controls
========================================
Controls are pretty common

Left	Move Left
Right	Move Right
Down	Push Blocks down
A	Rotate Counter-Clockwise
B	Rotate Clockwise
Start	Pauses Game

Known Issues
========================================
There's a pretty nasty bug that mucks up the background tiles at an undetermined time. I think it has something to do with exploding a row when you are quite high up the y axis, but as yet I'm still working on it. If anyone knows what I'm doing wrong, please email me and show me my mistakes, it's the only way I'll learn.

The Start button feels a bit "sticky"... not sure if this is because It's running too fast on the VirtualBoyAdvance emulator. As of yet I don't have a flashlinker and haven't tested this out on a real life GBA.

Thanks
========================================
Special thanks go out to all involved at www.gbadev.org. The best source of GBA development info I've found on the web. Extra special thanks go out to gbajunkie; his tutorials are what got me up and coding and got this beta out in less that 3 weeks.

 

