Finally, the download you have been waiting for :)

The first and only real unlicenced GBA game. It took a lot of hard work
by all involved. Read the entire story on http://2004Mbit.gbadev.org or
http://gbadev.org and have a great time playing it!

This archive may be distributed only in its original form.

Thanks to everyone who supported the game project and gba development.

The GBADEV.ORG Team