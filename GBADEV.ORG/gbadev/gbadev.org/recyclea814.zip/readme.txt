Recycle Bin (unfinished version) by Nocturnal

Credits
-------
code:
  neon

gfx:
  starfish
  neon

music:
  lug00ber / kvasigen

Additional credits
------------------
hitmen - modplayer

Note
----
This demo was written for the console compo at Underscore 2002 in
Gothenburg, Sweden. There were only one entry in that compo (mine)
so it participated in the wild compo instead, where it placed 
second. Unfortunately I didn't have time to finish it before the
deadline so it got some bugs, like noise when switching parts.

I was planning to release a final version, but right after the wild
compo had been shown my laptop harddrive died. I've lost all the
source, not only for this demo, but for everything I've written for
the GBA. Fortunately the demo was still on my flash cartridge, so 
I've decided to release the unfinished version.

The demo is about 1 MB, but I didn't remember if it was larger than
1MB so I dumped 2 MB.

neon
geir@bjerke.org
