/*																							98
 * main.c Torn Desktop Demo (c) copyright Mike Wynn 2001 [03 Oct 2001]
 */

#include "gba.h"
#include "gba_io.h"

#include <string.h>
#include <stdio.h>
#include <stdlib.h>
#include <malloc.h>
#include <math.h>

DisplayInfo displayInfo;
BGInfo background[4];

void setBGPalette( Word index, PaletteEntryPtr entryPtr )
{
	Halfword entry;
	if ( index >= 256 ) return;
	entry = (((entryPtr->red>>3)&0x1F)<<10)|(((entryPtr->green>>3)&0x1F)<<5)|((entryPtr->blue>>3)&0x1F);
	BG_PAL[index] = entry;
}

void setOBJPalette( Word index, PaletteEntryPtr entryPtr )
{
	Halfword entry;
	if ( index >= 256 ) return;
	entry = (((entryPtr->red>>3)&0x1F)<<10)|(((entryPtr->green>>3)&0x1F)<<5)|((entryPtr->blue>>3)&0x1F);
	OBJ_PAL[index] = entry;
}

void zeroOam( void )
{
	OamEntryPtr ramOam;
	int index;

	ramOam = OBJ_DATA;

	for( index = 127; index >= 0; index-- )
	{
		ramOam[index].y    = 160;
		ramOam[index].x    = 240;
		ramOam[index].tile = 0;
		ramOam[index]._ignore = 0; // zero the rotate data too.
	}
}

void moveRomOam( OamEntryPtr romOam, int index, int x, int y )
{
	OamEntryPtr ramOam;

	ramOam = OBJ_DATA;
	if ( x < 0 ) x = 512 + x;
	if ( y < 0 ) y = 256 + y;

	ramOam[index].y    = OBJ_MAKE_Y( romOam->y, y );
	ramOam[index].x    = OBJ_MAKE_X( romOam->x, x );
//	ramOam[index].tile = romOam->tile;
}

void initRomOam( OamEntryPtr romOam, int index, int x, int y )
{
	OamEntryPtr ramOam;

	ramOam = OBJ_DATA;
	if ( x < 0 ) x = 512 + x;
	if ( y < 0 ) y = 256 + y;

	ramOam[index].y    = OBJ_MAKE_Y( romOam->y, y );
	ramOam[index].x    = OBJ_MAKE_X( romOam->x, x );
	ramOam[index].tile = romOam->tile;
}

void moveRamOam( int index, int x, int y )
{
	OamEntryPtr ramOam;

	ramOam = OBJ_DATA;
	if ( x < 0 ) x = 512 + x;
	if ( y < 0 ) y = 256 + y;

	ramOam[index].y    = OBJ_MAKE_Y( ramOam[index].y, y );
	ramOam[index].x    = OBJ_MAKE_X( ramOam[index].x, x );
//	ramOam[index].tile = romOam->tile;
}

void initRamOam( int index, int x, int y, int shape, int size, int tile, int priority, int palette )
{
	OamEntryPtr ramOam;

	ramOam = OBJ_DATA;
	if ( x < 0 ) x = 512 + x;
	if ( y < 0 ) y = 256 + y;

	ramOam[index].y    = OBJ_MAKE_Y( OBJ_MAKE_SHAPE( shape ), y );
	ramOam[index].x    = OBJ_MAKE_X(  OBJ_MAKE_SIZE( size  ), x );
	ramOam[index].tile = OBJ_CREATE_TILE( tile, palette, priority );
}

void setRamOamSize( int index, int size )
{
	OBJ_DATA[index].x = OBJ_MAKE_X( OBJ_DATA[index].x, size );
}

void setRamOamPalette( int index, int palette )
{
	OBJ_DATA[index].tile = OBJ_UPDATE_PALETTE( OBJ_DATA[index].tile, palette );
}

void setRamOamPriority( int index, int priority )
{
	OBJ_DATA[index].tile = OBJ_UPDATE_PRIORITY( OBJ_DATA[index].tile, priority );
}

void setRamOamTile( int index, int tile )
{
	OBJ_DATA[index].tile = OBJ_MAKE_TILE( OBJ_DATA[index].tile, tile );
}

Halfword  getOamTileNumber( int index )
{
	return (OBJ_DATA[index].tile)&OBJ_TILE_MASK;
}

/*
 * wait for the next vertical blank (N.B. we may still be in the last one
 * if we have not been doing a lot of work.
 */
void 
wait4Vsync()
{
	register Word disp;
	do
	{
		disp = DISPSTAT;
	}
	while( disp & STAT_VBL_MASK );
	do
	{
		disp = DISPSTAT;
	}
	while( !(disp & STAT_VBL_MASK) );
}

Halfword 
readKeys()
{
	/* GBA input are active low so invert */
	return ~(PADREG);
}

void 
loadSpriteDataFromRom( const Halfword * romPtr )
{
	loadPartialSpriteDataFromRom( 0, romPtr, 16*1024 );
}

void
loadPartialSpriteDataFromRom( Word vRamOffset, const Halfword * romPtr, Word count )
{
	HalfwordPtr dest;

	if ( vRamOffset > VRAM_OBJ_SIZE )
	{
		return; /* we can not do the copy */
	}

	dest = VRAM_OBJ_BASE + (vRamOffset>>1);
	if ( ((vRamOffset>>1) + count) > (VRAM_OBJ_SIZE>>1) )
	{
		count = (VRAM_OBJ_SIZE - vRamOffset)>>1;
	}

	while( count )
	{
		count--;
		dest[count] = romPtr[count];
	}
}

void 
loadTilesFromRom( Word vRamOffset, const Halfword * romPtr, Word count )
{
	HalfwordPtr dest;

	if ( vRamOffset > VRAM_SIZE )
	{
		return; /* we can not do the copy */
	}

	dest = VRAM_BASE + (vRamOffset>>1);
	if ( ((vRamOffset>>1) + count) > (VRAM_SIZE>>1) )
	{
		count = (VRAM_SIZE - vRamOffset)>>1;
	}

	while( count )
	{
		count--;
 		dest[count] = romPtr[count];
	}
}

void 
clearMap( Word vRamOffset, Word count, Halfword value )
{
	HalfwordPtr dest;

	/* N.B. vRamOffset if a byte offset */

	dest = VRAM_BASE + (vRamOffset>>1);

	if ( ((vRamOffset>>1) + count) > (VRAM_SIZE>>1) )
	{
		count = (VRAM_SIZE - vRamOffset)>>1;
	}

	while( count )
	{
		count--;
		dest[count] = value;
	}
}

void loadBGPalette( const Halfword * romPtr, Word firstIndex, Word length )
{
	if ( firstIndex >= 256 ) return;
	if ( (firstIndex + length) > 256 ) length = 256 - firstIndex;
	halfwordCopy( BG_PAL + firstIndex, romPtr, length );
}

void loadOBJPalette( const Halfword * romPtr, Word firstIndex, Word length )
{
	if ( firstIndex >= 256 ) return;
	if ( (firstIndex + length) > 256 ) length = 256 - firstIndex;
	halfwordCopy( OBJ_PAL + firstIndex, romPtr, length );
}

void 
halfwordCopy( HalfwordPtr dest, const Halfword * src, Word count )
{
	while( count )
	{
		count--;
		dest[count] = src[count];
	}
}

void 
halfwordSet( HalfwordPtr dest, Word count, Halfword value )
{
	while( count )
	{
		count--;
		dest[count] = value;
	}
}

void 
initialiseMode( Halfword mode, int bg0, int bg1, int bg2, int bg3, int objects, int sequentialSprites )
{
	mode = DISP_MODE( mode );
	if ( bg0 ) mode |= DISP_BG0;
	if ( bg1 ) mode |= DISP_BG1;
	if ( bg2 ) mode |= DISP_BG2;
	if ( bg3 ) mode |= DISP_BG3;

	if ( objects ) mode |= DISP_OBJ;

	if ( sequentialSprites ) mode |= DISP_OAM_1D;

	DISPCNT = mode;
	/* display control mode setting */
	displayInfo.displayControl = mode;
}

void 
initialiseBG( Word bgIndex, Word mapbase, Word charbase, Halfword size, Halfword colourDepth )
{
	BGInfoPtr bg;
	Halfword  settings;

	bg = &(background[bgIndex&3]);

	/* by default set each */
	settings = BG_CHARBASE( charbase ) | BG_MAPBASE( mapbase ) | size | colourDepth | BG_PRIORITY( bgIndex ); 

	switch( size )
	{
	case BG_TEXT_32x32:
		bg->tileWidth  = 32;
		bg->tileHeight = 32;
		break;
	case BG_TEXT_32x64:
		bg->tileWidth  = 32;
		bg->tileHeight = 64;
		break;
	case BG_TEXT_64x32:
		bg->tileWidth  = 64;
		bg->tileHeight = 32;
		break;
	case BG_TEXT_64x64:
		bg->tileWidth  = 64;
		bg->tileHeight = 64;
		break;
	}

	switch ( bgIndex )
	{
	case 0:
		BG0CNT = settings;
		BG0X = 0;
		BG0Y = 0;
		break;
	case 1:
		BG1CNT = settings;
		BG1X = 0;
		BG1Y = 0;
		break;
	case 2:
		BG2CNT = settings;
		BG2X = 0;
		BG2Y = 0;
		break;
	case 3:
		BG3CNT = settings;
		BG3X = 0;
		BG3Y = 0;
		break;
	}

	bg->controlSettings = settings;
	bg->mapBase  = VRAM_BASE + (mapbase>>1);
	bg->charBase = VRAM_BASE + (charbase>>1);
}

void 
msgPrint( Word bgIndex, int x, int y, Halfword palette, const unsigned char * msg )
{
	BGInfoPtr bg;
	Word index;
	Word end;
	HalfwordPtr mapbase;
	int left;

	bg = &(background[bgIndex&3]);

	/* unsigned comparison i.e ((y < 0) || (y >= tile height)) */
	if ( ((Word)y) >= bg->tileHeight )
	{
		return; /* no way can this cause display*/
	}
	if ( x > (int)bg->tileWidth )
	{
		return; /* no possibiliy to print */
	}
	/* scan to get the char on map */
	while( x < 0 )
	{
		if ( !(*msg) ) return; /* end of msg before we can print it */
		msg++; 
		x++;
	}
	/* sort out the index N.B. this is HalfWord NOT a Byte index */
	index = y * 32 + x;
	/* adjust if 64*64 */
	if ((y > 32) && bg->tileWidth == 64) index += 1024;
	/* adjust if 64*32 or 64*64 */
	if (x > 32) index += 1024;

	end = index + (bg->tileWidth - x);

	mapbase = bg->mapBase;
	palette <<= 12;
	if ( bg->controlSettings & BG_COLOUR_256 )
	{
		/* in 256 colour mode the font uses 2 tiles slots*/
		/* 16 colour mode */
		while ( *msg )
		{
			if ( index == end ) return;
			mapbase[index++] = (((*msg)<<1)|palette);
			msg++;
		}
	}
	else
	{
		/* 16 colour mode */
		while ( *msg )
		{
			if ( index == end ) return;
			mapbase[index++] = (*msg|palette);
			msg++;
		}
	}
}

void 
tilePut( Word bgIndex, int x, int y, Halfword palette, Halfword tile )
{
	BGInfoPtr bg;
	Word index;

	bg = &(background[bgIndex&3]);

	/* unsigned comparison i.e ((y < 0) || (y >= tile height)) */
	if ( ((Word)y) >= bg->tileHeight )
	{
		return; /* no way can this cause display*/
	}
	/* unsigned comparison i.e ((x < 0) || (x >= tile height)) */
	if ( ((Word)x) >= bg->tileWidth )
	{
		return; /* no way can this cause display*/
	}
	/* sort out the index N.B. this is HalfWord NOT a Byte index */
	index = y * 32 + x;
	/* adjust if 64*64 */
	if ((y > 32) && bg->tileWidth == 64) index += 1024;
	/* adjust if 64*32 or 64*64 */
	if (x > 32) index += 1024;

	bg->mapBase[index] = (tile|(palette<<12));
}

Halfword 
tileGet( Word bgIndex, int x, int y )
{
	BGInfoPtr bg;
	Word index;

	bg = &(background[bgIndex&3]);

	/* unsigned comparison i.e ((y < 0) || (y >= tile height)) */
	if ( ((Word)y) >= bg->tileHeight )
	{
		return 0; /* no way can this cause display*/
	}
	/* unsigned comparison i.e ((x < 0) || (x >= tile height)) */
	if ( ((Word)x) >= bg->tileWidth )
	{
		return 0; /* no way can this cause display*/
	}
	/* sort out the index N.B. this is HalfWord NOT a Byte index */
	index = y * 32 + x;
	/* adjust if 64*64 */
	if ((y > 32) && bg->tileWidth == 64) index += 1024;
	/* adjust if 64*32 or 64*64 */
	if (x > 32) index += 1024;

	return (bg->mapBase[index]&0x3FF);
}

Word
tilePixelIndexGet( Word bgIndex, int x, int y )
{
	Word tile;
	Word index;

	tile = tileGet( bgIndex, x>>3, y>>3 );
	index = ((y&7)<<1)+((tile&0x3FF)<<4);
	if ( x & 4 )
	{
		return (((background[bgIndex&3]).charBase[1+index])>>((x&3)<<2)) & 0xF;
	}
	else
	{
		return (((background[bgIndex&3]).charBase[index])>>((x&3)<<2)) & 0xF;
	}
}


void 
tilePutFliped( Word bgIndex, int x, int y, int vf, int hf, Word palette, Halfword tile )
{
	BGInfoPtr bg;
	Word index;

	bg = &(background[bgIndex&3]);

	/* unsigned comparison i.e ((y < 0) || (y >= tile height)) */
	if ( ((Word)y) >= bg->tileHeight )
	{
		return; /* no way can this cause display*/
	}
	/* unsigned comparison i.e ((x < 0) || (x >= tile height)) */
	if ( ((Word)x) >= bg->tileWidth )
	{
		return; /* no way can this cause display*/
	}
	/* sort out the index N.B. this is Halfword NOT a Byte index */
	index = y * 32 + x;
	/* adjust if 64*64 */
	if ((y > 32) && bg->tileWidth == 64) index += 1024;
	/* adjust if 64*32 or 64*64 */
	if (x > 32) index += 1024;
	
	palette = (palette<<12);
	if ( vf ) palette |= (1<<11);
	if ( hf ) palette |= (1<<10);

	bg->mapBase[index] = (tile|palette);
}

void 
tileFullPutWrap( Word bgIndex, int x, int y, Halfword tile )
{
	BGInfoPtr bg;
	Word index;

	bg = &(background[bgIndex&3]);

	/* unsigned comparison i.e ((y < 0) || (y >= tile height)) */
	if ( ((Word)y) >= bg->tileHeight )
	{
		while ( y < 0 )
		{
			y += bg->tileHeight;
		}
		while ( y >= (int)bg->tileHeight )
		{
			y -= bg->tileHeight;
		}
	}
	/* unsigned comparison i.e ((x < 0) || (x >= tile height)) */
	if ( ((Word)x) >= bg->tileWidth )
	{
		while ( x < 0 )
		{
			x += bg->tileWidth;
		}
		while ( x >= (int)bg->tileWidth )
		{
			x -= bg->tileWidth;
		}
	}
	/* sort out the index N.B. this is HalfWord NOT a Byte index */
	index = y * 32 + x;
	/* adjust if 64*64 */
	if ((y > 32) && bg->tileWidth == 64) index += 1024;
	/* adjust if 64*32 or 64*64 */
	if (x > 32) index += 1024;

	bg->mapBase[index] = tile;
}

Halfword 
tileFullGetWrap( Word bgIndex, int x, int y )
{
	BGInfoPtr bg;
	Word index;

	bg = &(background[bgIndex&3]);

	/* unsigned comparison i.e ((y < 0) || (y >= tile height)) */
	if ( ((Word)y) >= bg->tileHeight )
	{
		while ( y < 0 )
		{
			y += bg->tileHeight;
		}
		while ( y >= (int)bg->tileHeight )
		{
			y -= bg->tileHeight;
		}
	}
	/* unsigned comparison i.e ((x < 0) || (x >= tile height)) */
	if ( ((Word)x) >= bg->tileWidth )
	{
		while ( x < 0 )
		{
			x += bg->tileWidth;
		}
		while ( x >= (int)bg->tileWidth )
		{
			x -= bg->tileWidth;
		}
	}
	/* sort out the index N.B. this is HalfWord NOT a Byte index */
	index = y * 32 + x;
	/* adjust if 64*64 */
	if ((y > 32) && bg->tileWidth == 64) index += 1024;
	/* adjust if 64*32 or 64*64 */
	if (x > 32) index += 1024;

	return bg->mapBase[index];
}

