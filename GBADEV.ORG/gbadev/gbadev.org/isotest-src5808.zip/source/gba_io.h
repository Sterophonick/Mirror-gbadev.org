#ifndef GBA_IO_SYSTEM_HEADER /* { */
#define GBA_IO_SYSTEM_HEADER

/*
 * gba_io.h Torn Desktop Demo support files (c) copyright Mike Wynn 2001 [03 Oct 2001]
 */

#include "gba.h"

typedef struct DisplayInfo_s {
	Halfword    displayControl;
} DisplayInfo, * DisplayInfoPtr;

typedef struct BGinfo_s {
	HalfwordPtr mapBase;
	HalfwordPtr charBase;
	Halfword    tileWidth;
	Halfword    tileHeight;
	Halfword    controlSettings;
	Halfword    _private; /* makes this into a 16 bytes struct */
} BGInfo, * BGInfoPtr;

typedef struct PaletteEntry_s {
	Byte red;
	Byte green;
	Byte blue;
	Byte _ignore;
} PaletteEntry, * PaletteEntryPtr;

extern DisplayInfo displayInfo;
extern BGInfo background[4];

extern void wait4Vsync();
extern Halfword readKeys();
extern void loadSpriteDataFromRom( const Halfword * romPtr );
extern void loadPartialSpriteDataFromRom( Word vRamOffset, const Halfword * romPtr, Word count );
extern void loadTilesFromRom( Word vRamOffset, const Halfword * romPtr, Word count );
extern void clearMap( Word vRamOffset, Word length, Halfword value );
extern void loadBGPalette( const Halfword * romPtr, Word firstIndex, Word length );
extern void loadOBJPalette( const Halfword * romPtr, Word firstIndex, Word length );
extern void halfwordCopy( HalfwordPtr dest, const Halfword * src, Word count );
extern void halfwordSet( HalfwordPtr dest, Word count, Halfword value );

extern void initialiseMode( Halfword mode, int bg0, int bg1, int bg2, int bg3, int objects, int sequentialSprites );
extern void initialiseBG( Word bgIndex, Word mapbase, Word charbase, Halfword size, Halfword colourDepth );
extern void msgPrint( Word bgIndex, int x, int y, Halfword palette, const unsigned char * msg );
extern void tilePut( Word bgIndex, int x, int y, Halfword palette, Halfword tile );
extern void tilePutFliped( Word bgIndex, int x, int y, int vf, int hf, Word palette, Halfword tile );
extern Word tilePixelIndexGet( Word bgIndex, int x, int y );
extern Halfword tileGet( Word bgIndex, int x, int y );
extern Halfword tileFullGetWrap( Word bgIndex, int x, int y );
extern void 	 tileFullPutWrap( Word bgIndex, int x, int y, Halfword tile );


extern void setBGPalette( Word index, PaletteEntryPtr entryPtr );
extern void setOBJPalette( Word index, PaletteEntryPtr entryPtr );

extern void zeroOam( void );
extern void moveRomOam( OamEntryPtr romOam, int index, int x, int y );
extern void initRomOam( OamEntryPtr romOam, int index, int x, int y );
extern void moveRamOam( int index, int x, int y );
extern void initRamOam( int index, int x, int y, int shape, int size, int tile, int priority, int palette );
extern void setRamOamSize( int index, int size );
extern void setRamOamPalette( int index, int palette );
extern void setRamOamPriority( int index, int priority );
extern void setRamOamTile( int index, int tile );
extern Halfword getOamTileNumber( int index );

#endif /* } GBA_IO_SYSTEM_HEADER */


