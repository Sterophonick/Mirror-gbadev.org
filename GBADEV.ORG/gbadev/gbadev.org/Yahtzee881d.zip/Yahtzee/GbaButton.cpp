#include "GbaButton.hpp"

//////////////////////////////////////////////////////////////////////////////////////////
//
// GbaButton
//
//  Arm all of the buttons for one shot on construction.
//
GbaButton::GbaButton()
{
    // Arm all ten buttons
    for(int i=0; i<10; i++ ) m_Arm[i] = TRUE;
}

//////////////////////////////////////////////////////////////////////////////////////////
//
// OneShot
//
// button (i) - the button to one shot
// buttonPress (i) - the state of the button
//
//  This method returns a true on the first occurence of a button press.  It does not
// return true on a held button.
//
bool GbaButton::OneShot(u8 button, bool buttonPress)
{
    bool keyPress = FALSE;
    bool value = FALSE;
    
    if ( buttonPress ) {
        keyPress = TRUE;
        
        if ( m_Arm[button] ) {
            m_Arm[button] = FALSE;
            value = TRUE;
        }
    }
    
    if ( !keyPress ) m_Arm[button] = TRUE;
    
    return value;
}
