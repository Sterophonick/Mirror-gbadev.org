#include "GbaFont.hpp"
#include "font.h"
#include "fontColor.h"

//////////////////////////////////////////////////////////////////////////////////////////
//
// GbaFont
//
//  Initialize the color palette for the fonts.  Default the font background color to
// black.
//
GbaFont::GbaFont(unsigned short mode)
{
    unsigned short* paletteMem = (unsigned short*)0x5000000;
    
    paletteMem[FONT_BLACK] = Rgb(0,0,0);
    paletteMem[FONT_WHITE] = Rgb(31,31,31);
    paletteMem[FONT_RED]   = Rgb(31,0,0);
    paletteMem[FONT_GREEN] = Rgb(0,31,0);
    paletteMem[FONT_BLUE]  = Rgb(0,0,31);
    
    // Set the video buffer
    m_VideoBuffer = (unsigned short*)0x6000000;
    
    // Default the background color to black
    SetBackGroundColor(FONT_BLACK);
    
    // Set the video mode
    m_Mode = mode;
}

//////////////////////////////////////////////////////////////////////////////////////////
//
// DrawPixel3
//
// Draws a pixel in mode 3
//
void GbaFont::DrawPixel3(int x, int y, unsigned short color)
{
    m_VideoBuffer[y * 240 + x] = color;
}

//////////////////////////////////////////////////////////////////////////////////////////
//
// DrawPixel4
//
// Draws a pixel in video mode 4
//
void GbaFont::DrawPixel4(int x, int y, unsigned char color)
{
    unsigned short pixel;
    unsigned short offset = (y * 240 + x) >> 1;
    pixel = m_VideoBuffer[offset];
    
    if (x & 1)
        m_VideoBuffer[offset] = (color << 8) + (pixel & 0x00FF);
    else
        m_VideoBuffer[offset] = (pixel & 0xFF00) + color;
}

//////////////////////////////////////////////////////////////////////////////////////////
//
// DrawPixel5
//
// Draws a pixel in video mode 5
//
void GbaFont::DrawPixel5(int x, int y, unsigned short color)
{
    m_VideoBuffer[y * 160 + x] = color;
}

//////////////////////////////////////////////////////////////////////////////////////////
//
// Print
//
// Prints a string using the hard-coded font
//
void GbaFont::Print(int left, int top, char *str, unsigned short color)
{
    int pos = 0;
    while (*str)
    {
        DrawChar(left + pos, top, *str++, color);
        pos += 8;
    }
}
//////////////////////////////////////////////////////////////////////////////////////////
//
// DrawChar
//
// Draws a character one pixel at a time
//
void GbaFont::DrawChar(int left, int top, char letter, unsigned short color)
{
    int x, y;
    int draw;
    unsigned short fontColor;
    
    for(y = 0; y < 8; y++)
    for (x = 0; x < 8; x++)
    {
        // grab a pixel from the font char
        draw = fontHarbour[(letter-32) * 64 + y * 8 + x];
        
        // if pixel = 1, then draw it else draw the background color
        fontColor = m_BackGroundColor;
        if (draw) fontColor = color;

        // Call the correct DrawPixel method
		switch ( m_Mode ) {
		case 3:
			DrawPixel3(left + x, top + y, fontColor);
			break;
		case 4:
            DrawPixel4(left + x, top + y, fontColor);
            break;
  		case 5:
            DrawPixel5(left + x, top + y, fontColor);
            break;
        }
    }
}

