#include <mygba.h>

//////////////////////////////////////////////////////////////////////////////////////////
class GbaString
{
public:
	GbaString(char *str) { strcpy(m_Str,str); m_HorizontalPixelSize = 8; }
	~GbaString() {}

    char * StrPtr()   { return m_Str; }
    u16 Length()      { return strlen(m_Str); }
    u16 PixelLength() { return m_HorizontalPixelSize*Length(); }
    
    void SetX(u16 x)        { m_X = x; }
    void SetY(u16 y)        { m_Y = y; }
    void SetColor(u8 color) { m_Color = color; }
    
    u16 X()                { return m_X; }
    u16 Y()                { return m_Y; }
    unsigned short Color() { return m_Color; }

private:
    char m_Str[8];
    u8 m_HorizontalPixelSize;
    u16 m_X;
    u16 m_Y;
    unsigned short m_Color;
};
