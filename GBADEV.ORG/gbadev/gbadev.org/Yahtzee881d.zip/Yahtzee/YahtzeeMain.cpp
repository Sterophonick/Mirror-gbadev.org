// The Main HAM Library
#include <mygba.h>

#include <stdio.h>

// Game Engine
#include "Yahtzee.hpp"

// Graphics Includes
#include "gfx/holdOutline.raw.c"
#include "gfx/die.raw.c"
#include "gfx/die.pal.c"

// Helper classes
#include "GbaFont.hpp"
#include "GbaString.hpp"
#include "GbaButton.hpp"

#include "fontColor.h"

// Global Variables
u8 g_DiceObj[5];        // The holder of the 5 dice bitmap objects
u8 g_HoldObj;           // The magenta hold box around the dice

GbaString *g_ScoreStr[13];  // The score header strings

const u8 g_VideoMode = 4;
u16 g_X[5];         // X values for the 5 dice
u16 g_Y = 10;       // Y value of the dice
u16 g_Counter = 0;  // Counter for random number seed
bool g_RollDice = FALSE;        // Flag for the dice to be rolled
bool g_StartGame = FALSE;       // Flag that the game has started
bool g_CreateYahtzee = TRUE;   // Create the Yahtzee engine only once
bool g_MoveHold = FALSE;        // The hold box has moved
bool g_StartText = TRUE;        // Flag to draw Press Start text to user
bool g_HeldDice[5];             // The hold state for each die
short g_Hold = 0;               // Hold box cursor index

// This Yahtzee class manages the game
Yahtzee *g_Yahtzee;           // Dice game engine
GbaFont *g_Font;                // Manage text displayed
GbaButton *g_ButtonManager;     // The GBA button manager

// Function Prototypes
void RunGame();     // VBL function to run the game
void QueryKeys();  // Query the GBA buttons
void Print(GbaString *str);     // Easily print a GbaString
void SetHolds();                // Draw the HOLD text under dice
void ShowScore();               // Display the scores
void WipeLine(u16 y);           // Blanks out a horizontal line
void MoveScoreLeft(bool moveScoreLeft);     // Move score cursor left or right
void PrintGameOver(unsigned short color);
void PrintPressStart(unsigned short color);

//////////////////////////////////////////////////////////////////////////////////////////
//
//  Yahtzee for GBA
//
//  Trey Arthur
//  12/23/2004
//  trey_arthur@yahoo.com
//
// Code for the fonts:  "Programming The Nintendo Game Boy Advance" by Jonathan S. Harbour
//  http://www.jharbour.com/gameboy/default.aspx
//
// Originally built with Visual HAM v2.8
//  http://www.ngine.de/site/index.php
//
// Dice animation from online tutorial by Aaron Rogers: http://www.aaronrogers.com/ham/
//
int main()
{
    // Initialize HAMlib
    ham_Init();
    
    // Setup the background mode
    ham_SetBgMode(g_VideoMode);
    
    // Initialize the sprite palette
    ham_LoadObjPal((void*)die_Palette, 256);

    // Create the sprite and store the object number
    int xstart=13;
    
    // Set up the 5 dice
    for(int i=0; i<5; i++) {
        g_X[i] = i*32 + (i+1)*xstart;
        g_DiceObj[i] = ham_CreateObj((void*)die_Bitmap,0,2,
                                 OBJ_MODE_NORMAL,1,0,0,0,0,1,0,g_X[i],g_Y);
    }
    
    g_HoldObj = ham_CreateObj((void*)holdOutline_Bitmap,0,2,
        OBJ_MODE_NORMAL,1,0,0,0,0,0,0,xstart,g_Y);

    // Draw the sprite
    ham_CopyObjToOAM();
    
    // Create the font and button managers
    g_Font = new GbaFont(g_VideoMode);
    g_ButtonManager  = new GbaButton();
    
    // Start the VBL interrupt handler
    ham_StartIntHandler(INT_TYPE_VBL,(void *)RunGame);
    
    // Infinite loop to keep the program running
    while(1) {}

    return 0;
} // End of main()

//////////////////////////////////////////////////////////////////////////////////////////
//
// RunGame
//
//  Interupt function that runs the game.
//
void RunGame()
{
    bool copyObj = FALSE;
    
    // If the Roll dice button has been pressed and the game has started,
    //  then roll the dice and draw what was rolled.
    if ( g_RollDice && g_StartGame ) {
        // Roll the dice and return the die values (via dice).  Pass in g_HeldDice so the
        // game knows the dice the user has held.
        u8 *dice;
        dice = g_Yahtzee->Roll( g_HeldDice );
      
        // Display the current roll to the user.
        char rollStr[8] = "ROLL: 0";
        sprintf( rollStr,  "ROLL: %d",g_Yahtzee->RollCount() );
        g_Font->Print(1,70,rollStr ,FONT_BLUE);
      
        // Update the dice bitmaps based on the roll
        for(int i=0; i<5; i++) {
            ham_UpdateObjGfx(g_DiceObj[i],
                (void*)&die_Bitmap[1024*dice[i]]);  // 1024 = 32*32; the size of the die
        }
        
        // Notification that the sprite has changed
        copyObj = TRUE;
        
        // Reset the roll dice flag
        g_RollDice = FALSE;
    }
    
    // The Hold box was moved
    if ( g_MoveHold ) {
        g_MoveHold = FALSE;
        ham_SetObjX( g_HoldObj , g_X[g_Hold] );
        copyObj = TRUE;
    }
    
    // Tell the user to press the start button to begin the game
    if ( g_StartText ) {
        g_StartText = FALSE;
        PrintPressStart(FONT_WHITE);
    }
    
    if ( copyObj ) ham_CopyObjToOAM(); // Copy block sprite to hardware
    
    QueryKeys(); // Check for button presses

    // Just run a counter around for seeding the random number generator
    g_Counter++;
    if ( g_Counter > 64000 ) g_Counter = 0;
    
    return;
} 

//////////////////////////////////////////////////////////////////////////////////////////
//
// QueryKeys
//
//  This function checks if any of the GBA buttons have been pressed.  A class is used
// (GbaButton) to determine the button state.  The main purpose of the GbaButton class
// is to detect when a button is pressed (and not held).
//
void QueryKeys()
{
    // The Left and right on the D pad move the hold selection box
    // If it is time to score, it move the score selection
    if ( g_ButtonManager->OneShotLeft() )
    {
        if ( g_Yahtzee->RollCount() != 3 ) {
            g_MoveHold = TRUE;
            g_Hold--;
            if ( g_Hold < 0 ) g_Hold = 4;
        } else {
            if ( g_StartGame ) MoveScoreLeft(TRUE);
        }
    }
    if ( g_ButtonManager->OneShotRight() )
    {
        if ( g_Yahtzee->RollCount() != 3 ) {
            g_MoveHold = TRUE;
            g_Hold++;
            if ( g_Hold > 4 ) g_Hold = 0;
        } else {
            if ( g_StartGame ) MoveScoreLeft(FALSE);
        }

    }

    // Start the game
    if( g_ButtonManager->Start() )
    {
        // The start button has been pressed to create the game engine
        if ( !g_StartGame ) {
            // Create the Yahtzee only once
            if ( g_CreateYahtzee ) {
                g_CreateYahtzee = FALSE;
                g_Yahtzee = new Yahtzee(g_Counter);
            }
            
            // Reset the game
            g_Yahtzee->Reset();
            
            g_StartGame = TRUE;

            // Black out the start game text
            PrintPressStart(FONT_BLACK);
            
            g_ScoreStr[0] = new GbaString("ONE");
            g_ScoreStr[1] = new GbaString("TWO");
            g_ScoreStr[2] = new GbaString("THREE");
            g_ScoreStr[3] = new GbaString("FOUR");
            g_ScoreStr[4] = new GbaString("FIVE");
            g_ScoreStr[5] = new GbaString("SIX");

            g_ScoreStr[6] = new GbaString("3-K");
            g_ScoreStr[7] = new GbaString("4-K");
            g_ScoreStr[8] = new GbaString("FULL");
            g_ScoreStr[9] = new GbaString("SMS");
            g_ScoreStr[10]= new GbaString("LGS");
            g_ScoreStr[11]= new GbaString("CH");
            g_ScoreStr[12]= new GbaString("YATZEE");
            
            // Set the upper score strings
            u16 x = 1;
            u16 y = 80;
            const u8 space = 8;
            for(u8 i=0; i<6; i++) {
                g_ScoreStr[i]->SetX(x);
                g_ScoreStr[i]->SetY(y);
                g_ScoreStr[i]->SetColor( FONT_GREEN );
                
                Print( g_ScoreStr[i] );
                  
                x += g_ScoreStr[i]->PixelLength() + space;
            }
            g_ScoreStr[0]->SetColor( FONT_WHITE );
            Print( g_ScoreStr[0] );
            
            // Wipe out the score line if any score are there
            WipeLine(y + 10);
            
            // Set the lower score strings
            x = 1;
            y = 100;
            for(u8 i=6; i<13; i++) {
                g_ScoreStr[i]->SetX(x);
                g_ScoreStr[i]->SetY(y);
                g_ScoreStr[i]->SetColor( FONT_GREEN );

                Print( g_ScoreStr[i] );

                x += g_ScoreStr[i]->PixelLength() + space;
            }

            // Wipe out the lower scores
            WipeLine(y + 10);
            
            // Clear all of the holds
            for(int i=0; i<5; i++) g_HeldDice[i] = FALSE;
            
            // Remove the Game Over text since this is the start of a new game
            PrintGameOver(FONT_BLACK);
            
            // Show the score
            ShowScore();
            
            // Roll the dice
            g_RollDice = TRUE;
        }
    }

    // The A button is used to roll the dice
    if ( g_ButtonManager->OneShotA() )
    {
        if ( g_StartGame ) {
            // You must enter a score before rolling again
            if ( g_Yahtzee->RollCount() != 3 ) {
                g_RollDice = TRUE;
            }
        }
    }
    
    // The B button is used to score
    if ( g_ButtonManager->OneShotB() )
    {
        if ( g_StartGame ) {
            // The user has requested the turn be scored
            u16 score = g_Yahtzee->ScoreSelection();
            char scoreStr[8] = "0";
            
            // Copy the score to a char string for printing on the screen
            sprintf( scoreStr,"%d",score );
            
            // Get the index of the score requested (ie, Ones, Twos, Full House, etc)
            short ic = g_Yahtzee->ScoreIndex();
            
            // A blue color shows the score has been recorded for this game
            g_ScoreStr[ ic ]->SetColor( FONT_BLUE );
            Print( g_ScoreStr[ic] );
            
            // Print the score in white
            g_Font->Print(g_ScoreStr[ic]->X(),g_ScoreStr[ic]->Y()+10,scoreStr,FONT_WHITE);

            // Show the current score
            ShowScore();

            // Clear holds
            for(u8 i=0; i<5; i++) g_HeldDice[i] = FALSE;
            SetHolds();
            
            // After scoring, see if the game is over
            if( g_Yahtzee->GameOver() ) {
                g_StartGame = FALSE;
                
                PrintGameOver(FONT_WHITE);
            } else {
                ic = g_Yahtzee->MoveScoreRight();
                g_ScoreStr[ic]->SetColor( FONT_WHITE );
                Print(g_ScoreStr[ic]);

                g_RollDice = TRUE;
            }
        }
    }
    
    // The up on the D pad selects or unselects a die to hold
    if ( g_ButtonManager->OneShotUp() )
    {
        if ( g_StartGame ) {
            g_HeldDice[g_Hold] = !g_HeldDice[g_Hold];

            SetHolds();

        }
    }

    // Move the score selection left or right
    if ( g_ButtonManager->OneShotL() )
    {
        if ( g_StartGame ) MoveScoreLeft(TRUE);
    }
    
    if ( g_ButtonManager->OneShotR() )
    {
        if ( g_StartGame ) MoveScoreLeft(FALSE);
    }

    return;
} 

//////////////////////////////////////////////////////////////////////////////////////////
//
// Print
//
//  Print is a conveinence function for easily printing GbaString class
//
void Print(GbaString *str)
{
    g_Font->Print(str->X(),str->Y(),str->StrPtr(),str->Color());
}

//////////////////////////////////////////////////////////////////////////////////////////
//
// ShowScore
//
//   Display the score to the user
//
void ShowScore()
{
    u16 y = 130;
    u16 score     = g_Yahtzee->Score();
    u8 upperScore = g_Yahtzee->UpperScore();

    // Clear out the old text
    char scoreStr[16] = "               ";
    g_Font->Print(1,y,scoreStr,FONT_BLACK);
    g_Font->Print(1,y+10,scoreStr,FONT_BLACK);
    
    sprintf( scoreStr,"SCORE: %d",score );
    g_Font->Print(1,y,scoreStr,FONT_WHITE);
    
    sprintf( scoreStr,"UPPER SCORE: %d",upperScore );
    g_Font->Print(1,y+10,scoreStr,FONT_WHITE);
    
    g_Font->Print(18*8,y+10,"*BONUS*",FONT_BLUE);
    if ( g_Yahtzee->Bonus() ) g_Font->Print(18*8,y+10,"*BONUS*",FONT_WHITE);
}

//////////////////////////////////////////////////////////////////////////////////////////
//
// SetHolds
//
//  Draws the HOLD text under the user selected held dice
//
void SetHolds()
{
    for(u8 i=0; i<5; i++) {
        u16 x = g_X[i];
        u16 y = g_Y + 35;

        if ( g_HeldDice[i] ) g_Font->Print(x,y,"HOLD",FONT_WHITE);
        else                 g_Font->Print(x,y,"HOLD",FONT_BLACK);
    }
}

//////////////////////////////////////////////////////////////////////////////////////////
//
// WipeLine
//
//  y (i) - clears the horizontal line specified by y
//
//  Clears a line
//
void WipeLine(u16 y)
{
    for(u16 x=1; x<241; x += 8) g_Font->Print(x,y," ",FONT_WHITE);
}

//////////////////////////////////////////////////////////////////////////////////////////
//
// MoveScoreLeft
//
//  moveScoreLeft (i) - if true, move the text to the left.  false to the right
//
//  Move the score text left or right
//
void MoveScoreLeft(bool moveScoreLeft)
{
    // Move the score selection left or right
    if ( moveScoreLeft )
    {
        short ic = g_Yahtzee->MoveScoreLeft();
        g_ScoreStr[ic]->SetColor( FONT_WHITE );
        Print(g_ScoreStr[ic]);

        short ip = g_Yahtzee->ScoreIndexLast();
        g_ScoreStr[ip]->SetColor( FONT_GREEN );
        Print(g_ScoreStr[ip]);
    } else {
        short ic = g_Yahtzee->MoveScoreRight();
        g_ScoreStr[ic]->SetColor( FONT_WHITE );
        Print(g_ScoreStr[ic]);

        short ip = g_Yahtzee->ScoreIndexLast();
        g_ScoreStr[ip]->SetColor( FONT_GREEN );
        Print(g_ScoreStr[ip]);
    }
}

//////////////////////////////////////////////////////////////////////////////////////////
//
// PrintPressStart
//
//  color (i) - pass the desired color for the text
//
//  Prints Press Start text in the specified color
//
void PrintPressStart(unsigned short color)
{
    g_Font->Print(70,80,"PRESS START",color);
    
    g_Font->Print(20,100,"L-R:      MOVE SCORE CURSOR",color);
    g_Font->Print(20,110,"<- ->:    MOVE HOLD CURSOR",color);
    g_Font->Print(20,120,"UP ARROW: HOLD DIE",color);
    g_Font->Print(20,130,"A:        ROLL DICE",color);
    g_Font->Print(20,140,"B:        SCORE TURN",color);
}

//////////////////////////////////////////////////////////////////////////////////////////
//
// PrintGameOver
//
//  color (i) - pass the desired color for the text
//
//  Prints Game Over text in the specified color
//
void PrintGameOver(unsigned short color)
{
    g_Font->Print(75,50,"GAME OVER",color);
}

/* END OF FILE */
