#include "Yahtzee.hpp"
#include <stdlib.h>

#ifndef TRUE
#define TRUE -1
#endif

#ifndef FALSE
#define FALSE 0
#endif

/////////////////////////////////////////////////////////////////////////////////////////
//
// Yahtzee
//
//  Seed the random number generator
//
Yahtzee::Yahtzee(u16 seed)
{
	// Seed the random number generator with time.
    srand( seed );
    
    // Reset the game values to start the game.
    Reset();
}

/////////////////////////////////////////////////////////////////////////////////////////
//
// Reset
//
//  Request to start the game
//
void Yahtzee::Reset()
{
    m_RollCount = 0;
    m_ScoreIndex = 0;
    m_ScoreIndexLast = 0;
    m_Score = 0;
    m_UpperScore = 0;
    m_Turn = 13;
    m_ArmBonus = TRUE;
    
    for(u8 i=0; i<5; i++) m_Dice[i] = 0;
    for(u8 i=0; i<13;i++) m_ScoreAvailable[i] = TRUE;
}

//////////////////////////////////////////////////////////////////////////////////////////
//
// Roll
//
//  input held dice
//  return u8 *dice - output the value of the roll (minus one)
//
//  Request the dice to be rolled
//
u8 *Yahtzee::Roll(bool *hold)
{
    // Increment the roll counter for the turn
    m_RollCount++;
    
    // Only 3 rolls per turn
    if ( m_RollCount > 3 ) m_RollCount = 1;
    
    // Roll the 5 dice that are not held
   	for ( int i=0; i<5; i++) {
   	    if ( !hold[i] ) m_Dice[i] = rand()%6;
	}
	
	// return the dice values
	return m_Dice;
}

//////////////////////////////////////////////////////////////////////////////////////////
//
// MoveScoreLeft
//
//  The user wants to move the score cursor to the item to the left.  The score cursor is
// moved by the user to tell the game which category to score the turn with.
//
short Yahtzee::MoveScoreLeft()
{
    // Store the where Score Index is
    m_ScoreIndexLast = m_ScoreIndex;
    
    // Decrement the score index until it lands on an unscored item.
    // If all of the items have been score (m_Turn is false), then drop out of the loop.
    // This prevents an infinite loop at the end of the game.
    do {
        m_ScoreIndex--;
        
        // Loop the score cursor to the other end
        if ( m_ScoreIndex < 0 ) m_ScoreIndex = 12;
    } while ( !m_ScoreAvailable[ m_ScoreIndex ] && m_Turn );
    
    return m_ScoreIndex;
}
//////////////////////////////////////////////////////////////////////////////////////////
//
// MoveScoreRight
//
//  The user wants to move the score cursor to the item to the right
//
short Yahtzee::MoveScoreRight()
{
    // Store the last score index
    m_ScoreIndexLast = m_ScoreIndex;
    
    // Increment the score cursor until it lands on an unscored item.
    // If all of the items have been score (m_Turn is false), then drop out of the loop.
    // This prevents an infinite loop at the end of the game.
    do {
        m_ScoreIndex++;
        
        // Loop the score cursor to the other end
        if ( m_ScoreIndex > 12 ) m_ScoreIndex = 0;
    } while ( !m_ScoreAvailable[ m_ScoreIndex ] && m_Turn );

    return m_ScoreIndex;
}
//////////////////////////////////////////////////////////////////////////////////////////
//
// ScoreSelection
//
//  Record the score based on what the user wants to score the selection as.  The
// member variable m_ScoreIndex is used to store what score selection the user
// has selected.
//
u16 Yahtzee::ScoreSelection()
{
    u16 score = 0;
    
    m_Turn--;
    m_ScoreAvailable[ m_ScoreIndex ] = FALSE;
            
    // The variable m_ScoreIndex is what the user selected for the score.
    switch(m_ScoreIndex) {
        case e_One:
        case e_Two:
        case e_Three:
        case e_Four:
        case e_Five:
        case e_Six:
            score = CalcScore( m_ScoreIndex );
            m_UpperScore += score;
            break;
        case e_3Kind:
            score = CalcKindScore(3);
            break;
        case e_4Kind:
            score = CalcKindScore(4);
            break;
        case e_FullHouse:
            score = CalcFullHouse();
            break;
        case e_SmallStr:
            score = CalcStraight( TRUE );
            break;
        case e_LargeStr:
            score = CalcStraight( FALSE );
            break;
        case e_Chance:
            for(u8 i=0; i<5; i++) score += (m_Dice[i] + 1);
            break;
        case e_Yatzee:
        	bool yahtzee =
                (m_Dice[0] == m_Dice[1]) &&
        		(m_Dice[1] == m_Dice[2]) &&
        		(m_Dice[2] == m_Dice[3]) &&
        		(m_Dice[3] == m_Dice[4]);
       		if ( yahtzee ) score = 50;
            break;
    }

    // See if the upper score bonus of 35 pts should be awarded
    if ( Bonus() && m_ArmBonus ) {
        // Only add the bonus once per game
        m_ArmBonus = FALSE;

        m_UpperScore += 35;
    }
    
    // Add the current selection to the total score
    m_Score += score;
    
    // Setting the roll count to 0 ends the turn (in case the user scores the turn
    //  before the third roll).
    m_RollCount = 0;
    
    return score;
}

//////////////////////////////////////////////////////////////////////////////////////////
//
// CalcScore
//
//  dieValue (i) - if one, caculate the ones score, etc.
//
//  This method calculates the upper scores (ones, twos, etc)
//
u16 Yahtzee::CalcScore(u8 dieValue)
{
	u16 score = 0;

    // Only count the dieValue for the upper scores
	for ( u8 i=0; i<5; i++ )
		if ( m_Dice[i] == dieValue ) score += ( dieValue + 1 );

	return score;
}


//////////////////////////////////////////////////////////////////////////////////////////
//
// CalcKindScore
//
//  kind (i) - if 3, then score 3 of kind.  if 4, then score 4 of a kind.
//
//  Calculate 3 of a kind or 4 of a kind.
//
u16 Yahtzee::CalcKindScore(u8 kind)
{
    // If addDice is true, then we have 3 or 4 of a kind.
	bool addDice = FALSE;
	// check is used to count the same value amoung the dice
	u8 check;

	for( u8 i=0; i<3; i++ ) {
		check = 1;
		for( u8 j=i+1; j<5; j++ ){
			if ( m_Dice[i] == m_Dice[j] ) check++;
		}
		if ( check >= kind ) addDice = TRUE;
	}

    // To score 3 or 4 of a kind, add all of the dice
	u16 score = 0;
	if ( addDice )
		for ( u8 k=0; k<5; k++ )  score += (m_Dice[k] + 1);

	return score;
}

/////////////////////////////////////////////////////////////////////////////////////////
//
// CalcFullScore
//
//  Calculate a full house score (3 of kind and 2 of a kind)
//
u16 Yahtzee::CalcFullHouse()
{
	u8 value1 = m_Dice[0];
	u8 value2 = 10;
	u8 check1 = 0;
	u8 check2 = 0;
	bool fullHouse;

    // First check if there are 2 different types of values
	for(u8 i=1; i<5; i++)
		if( m_Dice[i] != value1 ) value2 = m_Dice[i];

    // There must be 3 of one value and 2 of the other value
	for(u8 j=0; j<5; j++) {
		if (m_Dice[j] == value1)
			check1++;
		else if (m_Dice[j] == value2)
			check2++;
	}

	u16 score = 0;
	fullHouse = ( (check1 == 3) && (check2 == 2) ) ||
		( (check1 == 2) && (check2 == 3) );
	if ( fullHouse ) score = 25;

	return score;
}

//////////////////////////////////////////////////////////////////////////////////////////
//
// CalcStraight
//
//  smallStraight (i) - if true, then score as a small straight.  Otherwise score as a
// large straight.
//
//  Returns the score for either a small or large straight.
//
u16 Yahtzee::CalcStraight(bool smallStraight)
{
	bool one   = FALSE;
	bool two   = FALSE;
	bool three = FALSE;
	bool four  = FALSE;
	bool five  = FALSE;
	bool six   = FALSE;

    // Check the dice for the face values
	for(u8 i=0; i<5; i++) {
		switch ( m_Dice[i] ) {
		case 0:
			one = TRUE;
			break;
		case 1:
			two = TRUE;
			break;
		case 2:
			three = TRUE;
			break;
		case 3:
			four = TRUE;
			break;
		case 4:
			five = TRUE;
			break;
		case 5:
			six = TRUE;
			break;
		}
	}

	u16 score = 0;	
	// There are only 3 ways to get a small straight: 1-4, 2-5 or 3-6
	if ( smallStraight ) {
		bool smStr1 = one && two && three && four;
		bool smStr2 = two && three && four && five;
		bool smStr3 = three && four && five && six;

		if ( smStr1 || smStr2 || smStr3 ) score = 30;
    // There are only 2 large straights: 1-5 or 2-6
	} else {
		bool lgStr1 = one && two && three && four && five;
		bool lgStr2 = two && three && four && five && six;

		if ( lgStr1 || lgStr2 ) score = 40;
	}

	return score;
}

