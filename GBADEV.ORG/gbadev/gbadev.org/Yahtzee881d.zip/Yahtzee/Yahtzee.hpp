
typedef     unsigned char           u8;
typedef     unsigned short int      u16;

//////////////////////////////////////////////////////////////////////////////////////////
class Yahtzee
{
public:
	Yahtzee(u16 seed);
	~Yahtzee() {}

    enum {
        e_One = 0,
        e_Two,
        e_Three,
        e_Four,
        e_Five,
        e_Six,
        e_3Kind,
        e_4Kind,
        e_FullHouse,
        e_SmallStr,
        e_LargeStr,
        e_Chance,
        e_Yatzee
    };
    
    void Reset();
	u8 *Roll(bool *hold);
	u8 RollCount()   { return m_RollCount; }
	u8 UpperScore () { return m_UpperScore; }
	u16 Score()      { return m_Score; }
	u16 ScoreSelection();
	short MoveScoreLeft();
	short MoveScoreRight();
	short ScoreIndex()     { return m_ScoreIndex; }
	short ScoreIndexLast() { return m_ScoreIndexLast; }
	bool Bonus()           { return (m_UpperScore > 62); }
	bool GameOver()        { return !m_Turn; }
	
private:
    u16 CalcScore(u8 dieValue);
    u16 CalcKindScore(u8 kind);
    u16 CalcFullHouse();
    u16 CalcStraight(bool smallStraight);
    
    bool m_ArmBonus;
    bool m_ScoreAvailable[13];
    u8 m_Dice[5];
    u8 m_RollCount;
    u8 m_Turn;
    u8 m_UpperScore;
    short m_ScoreIndex;
    short m_ScoreIndexLast;
    u16 m_Score;
};
