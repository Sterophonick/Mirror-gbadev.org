Yahtzee for GBA

Trey Arthur
trey_arthur@yahoo.com
12/23/2004

This is a single player GBA version of the game Yahtzee.  The main purpose for writing this was to learn
to program the GBA.  In other words, it isn't sexy.  And to add to your disappointment, there is no sound.  
But, you have the source so have at it.

If you have comments or additions, I would be interested in hearing about them.  But if you make additions
and are too lazy to send them, that's cool too.

The controls are:

L & R moves the score cursor.  Use this to select which you want to score the turn.
A is used to roll
B is used to score
The left and right arrow will move the hold box cursor.  On the third roll, it will move the score cursor.
The up arrow is used to select a die to hold.
