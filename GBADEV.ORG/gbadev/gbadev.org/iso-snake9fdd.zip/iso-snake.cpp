////////////////////////////////////////////////////////////////////////////
//File:		iso-snake.cpp
//Description:	isometric snake game
//Date:		13 - 08 - 2003
//Author:		Jenswa
//Thanks to:	gbajunkie, dovoto and nokturn
////////////////////////////////////////////////////////////////////////////


//general declarations
#include "gba.h"		//GBA register definitions
#include "dispcnt.h"		//REG_DISPCNT register defines
#include "keypad.h"	//keypad defines
#include "sprites.h"		//sprite defines
#include "fade.h"		//background fades
#include "background.h"	//background defines

//dma stuff
#include "dma.h"		//dma defines
#include "dma.c"		//dma copy function

//gfx
#include "palette.h"		//tgf 256 colour palette
#include "title.h"		//8-bit title screen with it's palette
#include "food.h"		//food for the snake
#include "tale.h"		//iso block for the tale
#include "headright.h"	//head with eyes on the right side
#include "headleft.h"	//head with eyes on the left side

//bgs
#include "numbers.h"	//number 0 - 9
#include "numbers.c"	//map for 2 counters
#include "font.h"		//font for text in a background
#include "fontpause.c"	//background with text (pause)
#include "fontend.c"	//background with text (hiscores)
#include "tiles.h"		//tiles for background levels.
#include "lp.c"		//pause level
#include "lj.c"		//level with text: Jenswa
#include "lg.c"		//level with text: GBADEV
#include "lc.c"		//level with text: COMPO
#include "l1.c"		//1st background level.
#include "l2.c"		//2nd background level.
#include "l3.c"		//3rd background level.


//let's make it multiboot, just for fun! (uncomment it)
//don't foget to fix it with gbafix from darkfader
#define MULTIBOOT int __gba_multiboot;
//MULTIBOOT


//create an OAM variable and make it point to the address of OAM
u16* OAM = (u16*)0x7000000;

//create the array of sprites (128 is the maximum)
OAMEntry sprites[128];


//variables used for the game
const int xpos = 112;	//starting x position
const int ypos = 72;		//starting y position
int speed = 8;		//pixel it moves per turn
int xspeed = speed;		//move in x
int yspeed = speed/2;	//move in y
int walk = 0;		//direction it's moving in
int t = 0;			//t used as timer (could also have used build in timer)

int foodx = 64;		//x coordinates from food
int foody = 32;		//y coordinates from food

int score = 0;		//score
int hiscore[5];		//array hiscore used for the end
bool pos = 0;		//determines the position of the scores
int pointers[10];		//array used for pointers of numbers
int max = 100;		//maximum number of blocks, following the head
int size = 2;		//number of blocks, following the head (number one is skipped)
int lastx[100];		//all x coordinates from the sprite
int lasty[100];		//all y coordinates from the sprite
int lastdir[100];		//direction of the sprite
int clonex[100];		//a clone of lastx[100]
int cloney[100];		//a clone of lasty[100]
int lowx[100];		//all x coordinates sorted
int lowy[100];		//all y coordinates sorted
int lowdir[100];		//the direction of the accompanying sprite

unsigned long seed = 13;	//the seed for random

u8 bg = 0;			//used for browsing through the backgrounds

//variables used for font display
int place;				//starting positions of the name
int letter;				//starting letter of name
int position[5];			//positions of name
int index;				//which place of the hiscore

//booleans for single keypresses
bool keyup;
bool keydown;
bool keya;
bool keyb;
bool keystart;

bool pause = false;		//pause the game
bool play = true;		//used for zhe soft-reset
bool end = false;		//used for the ending screen
bool text = false;		//used for entering a hiscore

void Walk(void);		//function prototype


//clear VideoBuffer with some unused VRAM or something like that
//don't know if this is a 'clean' function
void ClearBuffer()
{
	REG_DM3SAD = 0x06010000;				//Source Address - Some unused VRAM
	REG_DM3DAD = 0x06000000;				//Destination Address - Front buffer
	REG_DM3CNT = 240*160/4 | DMA_32NOW;
}

//wait for the screen to stop drawing
void WaitForVsync()
{
	while((volatile u16)REG_VCOUNT != 160){}
}

//Wait until the start key is pressed
void WaitForStart()
{
	while (1)
		if( keystart == false && KEY_DOWN(KEYSTART) )
		{
			keystart = true;
			return;
		}

}

//Copy sprite array to OAM
void CopyOAM()
{
	REG_DM3SAD = (u32)sprites;
	REG_DM3DAD = (u32)OAM;
	REG_DM3CNT = 128 * 4 | DMA_16NOW;
}

// Set sprites off screen
void InitializeSprites()
{
	u16 loop;
	for (loop = 0; loop < 128; loop++)
	{
		sprites[loop].attribute0 = 160;	//y > 159
		sprites[loop].attribute1 = 240;	//x > 239
	}
}

//move the sprite
void MoveSprite(OAMEntry* sp, int x, int y)
{
	sp->attribute1 = sp->attribute1 & 0xFE00;  //clear the old x value
	sp->attribute1 = sp->attribute1 | x;

	sp->attribute0 = sp->attribute0 & 0xFF00;  //clear the old y value
	sp->attribute0 = sp->attribute0 | y;
}

//set counters to a score (less than 999)
void SetScore(int score, s8 pos)
{
	int hundreds = (score/100)%10;
	int tens = (score/10)%10;
	int units = score%10;

	switch (pos){
		case 0:
			//playing counters full
			numbers[0] = pointers[hundreds];
			numbers[1] = pointers[tens];
			numbers[2] = pointers[units];
			//pause counters empty
			numbers[306] = 0;
			numbers[307] = 0;
			numbers[308] = 0;
			break;
		case 1:
			//pause counters full
			numbers[306] = pointers[hundreds];
			numbers[307] = pointers[tens];
			numbers[308] = pointers[units];
			//playing counters empty
			numbers[0] = 0;
			numbers[1] = 0;
			numbers[2] = 0;
			break;
		default:
			break;
	}
}

//set score
void SetCounter()
{
	//score is the score of the current game
	SetScore(score,pos);

	//update the map
	REG_DM3SAD = (u32) numbers; 
	REG_DM3DAD = (u32) ScreenMem2; 
	REG_DM3CNT = 32*32/2 | DMA_32NOW;
}

//display the hiscores at the right position
void HiscoreDisplayOn()
{
	//set all tiles in the array correct

	numbers[0] = 0;
	numbers[1] = 0;
	numbers[2] = 0;

	for(int i=0; i < 5; i++){
		numbers[ (7+i)*32+19 ] = pointers[ (hiscore[i]/100)%10 ];
		numbers[ (7+i)*32+20 ] = pointers[ (hiscore[i]/10)%10 ];
		numbers[ (7+i)*32+21 ] = pointers[ (hiscore[i]/1)%10 ];
	}

	//update the map
	REG_DM3SAD = (u32) numbers; 
	REG_DM3DAD = (u32) ScreenMem2; 
	REG_DM3CNT = 32*32/2 | DMA_32NOW;

}

//remove the hiscores from the screen
void HiscoreDisplayOff()
{
	//set all tiles correct, thus empty

	for(int i=0; i < 5; i++){
		for(int j=0; j < 3; j++){
			numbers[ (7+i)*32 + 19 + j] = 0;
		}
	}

	//update the map
	REG_DM3SAD = (u32) numbers; 
	REG_DM3DAD = (u32) ScreenMem2; 
	REG_DM3CNT = 32*32/2 | DMA_32NOW;

}

//a function for a pseudo-random number
signed long random(signed long min, signed long max) 
{ 
	seed *= 69069; 
	return min + ((max - min + 1) * (seed >> 16)) / 0x10000; 
}

//move all sprites which are used
void MoveSprites()
{
	for(int x=0; x < size; x++){
		MoveSprite(&sprites[x], lowx[x], lowy[x]);
		sprites[x].attribute2 |= PRIORITY(2);
	}
}

//Place the food block at a pseudo-random position
void SetFood()
{
	//create a boolean named henk
	bool henk = false;

	//a while loop, food x and y will be set as long as it's not placed
	// in the snake or one of the four corners
	while (henk == false){
		//food x and y get a pseudo-random number
		foodx = (u8)(random(0,14)) * 16;
		foody = (u8)(random(0,9)) * 16;
		//boolean henk is true, to quite the loop
		henk = true;
		if( (foodx == 0 && foody == 0) || (foodx == 224 && foody == 144) || (foody == 0 && foodx == 224) || (foody == 144 && foodx == 0) ){
			//if the food block is in one of the corners
			//we won't quit the loop
			henk = false;
		}
		for(int i=1; i < size; i++){
			if(foodx == lastx[i] && foody == lasty[i]){
				//if the food block is in the snake
				//we won't quit the loop
				henk = false;
			}
		}
	}
}

//checks for a collision with the food block
void CheckForFood()
{
	//collision with the food block
	if(lastx[1] == foodx && lasty[1] == foody){
		if(size < max - 1){
			score++;
			size++;
		}
		SetFood();
	}
	SetCounter();
}

//function to browse through backgrounds
void BrowseBG()
{
	bg++;
	if(bg > 5){
		bg=0;
	}

	switch(bg){
		case 0:
			//loads map with text: Jenswa
			REG_DM3SAD = (u32) lj; 
			REG_DM3DAD = (u32) ScreenMem0; 
			REG_DM3CNT = 32*32/2 | DMA_32NOW;
			break;
		case 1:
			//loads the first map
			REG_DM3SAD = (u32) l1; 
			REG_DM3DAD = (u32) ScreenMem0; 
			REG_DM3CNT = 32*32/2 | DMA_32NOW;
			break;
		case 2:
			//loads map with text: GBADEV
			REG_DM3SAD = (u32) lg; 
			REG_DM3DAD = (u32) ScreenMem0; 
			REG_DM3CNT = 32*32/2 | DMA_32NOW;
			break;
		case 3:
			//loads the 2nd map
			REG_DM3SAD = (u32) l2; 
			REG_DM3DAD = (u32) ScreenMem0; 
			REG_DM3CNT = 32*32/2 | DMA_32NOW;
			break;
		case 4:
			//loads map with text: COMPO
			REG_DM3SAD = (u32) lc; 
			REG_DM3DAD = (u32) ScreenMem0; 
			REG_DM3CNT = 32*32/2 | DMA_32NOW;
			break;
		case 5:
			//loads the 3rd map
			REG_DM3SAD = (u32) l3; 
			REG_DM3DAD = (u32) ScreenMem0; 
			REG_DM3CNT = 32*32/2 | DMA_32NOW;
			break;
	default:
		break;
	}


}

//reset the snake head, kill the tales and place food right
void ResetSnake()
{
	//actions
	for(int y=0; y < size; y++){
		lastx[y] = 240;
		lasty[y] = 160;
		lowx[y] = 240;
		lowy[y] = 160;
		}
	walk=0;
	MoveSprites();
	if(lasty[0] >= lasty[1]){
		lastx[1] = xpos;
		lasty[1] = ypos;
		lowx[1] = xpos;
		lowy[1] = ypos;
		lastx[0] = foodx;
		lasty[0] = foody;
		lowx[0] = foodx;
		lowy[0] = foody;
	}
	else{
		lastx[0] = xpos;
		lasty[0] = ypos;
		lowx[0] = xpos;
		lowy[0] = ypos;
		lastx[1] = foodx;
		lasty[1] = foody;
		lowx[1] = foodx;
		lowy[1] = foody;
	}
	MoveSprites();
	//decrease size
	size=2;
	SetCounter();
	//wait a little
	SleepQ(32);
}

//ending screen stuff
void End()
{
	if( end == false ){

		//move food once more
		SetFood();
		Walk();
		MoveSprites();
		CopyOAM();

		//calculate position of the name

		text = false;
		int i=0;
		while(i < 5 && text == false){
			if(score > hiscore[i]){
				for(int j=4; j > (i-1) ; j--){
					//this must also be done for the names (which is kinda messy)
					int spot = position[j] - 1;
					int previous = position[j-1] - 1;
					for( int k=0; k < 6;k++){
						fontend[spot+k] = fontend[previous+k];
					}
					//hiscore will be set to the one above him
					hiscore[j] = hiscore[j-1];
				}
				//clear the corresponding name at hiscore[i]
				for(int l=0; l < 6; l++){
					fontend[ position[ i] + l - 1 ] = 0;
				}
				hiscore[i] = score;
				//set starting position of place
				index = i;
				place = position[index];
				//set starting letter
				letter = 0;
				//enable text writing for name
				text = true;
				//quit the loop
				break;
			}
			i++;
		}

		//reset old score
		score = 0;

		//set display mode, dont enable objects
		SetMode(MODE_0 | BG1_ENABLE | BG3_ENABLE | OBJ_MAP_1D);
		FadeOut(1);

		//palette entry 3 (red) will be replaced by palette entry 9 (white)
		BGPaletteMem[3] = BGPaletteMem[9];

		//set hiscore array on
		HiscoreDisplayOn();
		//palette entry 3 (red) will be replaced by palette entry 9 (white)
		BGPaletteMem[3] = BGPaletteMem[9];
	
		//show ending screen
		//loads the map: fontend
		REG_DM3SAD = (u32) fontend; 
		REG_DM3DAD = (u32) ScreenMem3; 
		REG_DM3CNT = 32*32/2 | DMA_32NOW;
		//set right display mode for the ending screen
		SetMode(MODE_0 | BG0_ENABLE | BG1_ENABLE | OBJ_MAP_1D);

		FadeIn(1);
		end = true;
		pause = true;
	}
}

//read the gba keypad for font display
void GetFontInput()
{

	//character up
	if( !keyup && KEY_DOWN(KEYUP) && text ){
		keyup = true;
		//do keyup actions
		letter++;
		if(letter > 26){
			letter-=27;
		}
	}
	if( !KEY_DOWN(KEYUP)){
		keyup = false;
	}

	//character down
	if( !keydown && KEY_DOWN(KEYDOWN) && text ){
		keydown = true;
		//do keydown actions
		letter--;
		if(letter < 0){
			letter+=27;
		}
	}
	if( !KEY_DOWN(KEYDOWN)){
		keydown = false;
	}

	//next letter
	if( !keya && KEY_DOWN(KEYA) && text ){
		keya = true;
		//do keya actions
		if(place < (position[index] + 4) ){
			place++;
			letter = fontend[place];
		}
	}
	if( !KEY_DOWN(KEYA)){
		keya = false;
	}

	//previous letter
	if( !keyb && KEY_DOWN(KEYB) && text ){
		keyb = true;
		//do keyb actions
		if(place > position[index] ){
			place--;
			letter = fontend[place];
		}
	}
	if( !KEY_DOWN(KEYB)){
		keyb = false;
	}


	//end character input
	if( !keystart && KEY_DOWN(KEYSTART) ){
		keystart = true;
		FadeOut(1);
		end = false;
		BrowseBG();
		//playing position of counters
		pos = 0;
		//set hiscore array off
		HiscoreDisplayOff();
		//palette entry 3 (red) will be replaced with the original
		BGPaletteMem[3] = palette[3];
		//enable bg3 and bg1 and disable bg2 and bg0 (prolly is faster c code for)
		SetMode(MODE_0 | BG1_ENABLE | BG3_ENABLE | OBJ_ENABLE | OBJ_MAP_1D);
		pause = false;
		FadeIn(1);
	}
	if( !KEY_DOWN(KEYSTART) ){
		keystart = false;
	}

}

//copy the updated array to screen
void FontDisplay()
{
	//if we're in the scorebord
	if( position[index] != 0){
		//apply the letter to the map
		fontend[place] = letter;

		//loads the array
		REG_DM3SAD = (u32) fontend; 
		REG_DM3DAD = (u32) ScreenMem3; 
		REG_DM3CNT = 32*32/2 | DMA_32NOW;
	}
}

//read the gba keypad
void GetInput()
{
	if(walk == 0 && pause == 0){

		if(KEY_DOWN(KEYLEFT)){
			walk = 4;
		}
		if(KEY_DOWN(KEYRIGHT)){
			walk = 2;
		}
		if(KEY_DOWN(KEYUP)){
			walk = 1;
		}
		if(KEY_DOWN(KEYDOWN)){
			walk = 3;
		}
	}

	//if going up, you can turn left or right
	if(lastdir[1] == 1 && walk == 1 && pause == 0){
		if(KEY_DOWN(KEYRIGHT)){
			walk = 2;
		}
		if(KEY_DOWN(KEYLEFT)){
			walk = 4;
		}
	}

	//if going down, you can turn left or right
	if(lastdir[1] == 3 && walk == 3 && pause == 0){
		if(KEY_DOWN(KEYRIGHT)){
			walk = 2;
		}
		if(KEY_DOWN(KEYLEFT)){
			walk = 4;
		}
	}

	//if going right, you can turn up or down
	if(lastdir[1] == 2 && walk == 2 && pause == 0){
		if(KEY_DOWN(KEYUP)){
			walk = 1;
		}
		if(KEY_DOWN(KEYDOWN)){
			walk = 3;
		}
	}

	//if going left, you can turn up or down
	if(lastdir[1] == 4 && walk == 4 && pause == 0){
		if(KEY_DOWN(KEYUP)){
			walk = 1;
		}
		if(KEY_DOWN(KEYDOWN)){
			walk = 3;
		}
	}

	//zhe pauze button
	if( keystart == false && KEY_DOWN(KEYSTART) ){
		if(pause == false){
			//pause position of counters
			pos = 1;
			//palette entry 3 (red) will be replaced by palette entry 9 (white)
			BGPaletteMem[3] = BGPaletteMem[9];
			//loads the map: fontpause
			REG_DM3SAD = (u32) fontpause; 
			REG_DM3DAD = (u32) ScreenMem3; 
			REG_DM3CNT = 32*32/2 | DMA_32NOW;
			//enable bg0, bg1 and bg2 and disable bg3 (prolly is faster c code for)
			SetMode(MODE_0 | BG0_ENABLE | BG1_ENABLE | BG2_ENABLE | OBJ_ENABLE | OBJ_MAP_1D);
			pause = true;
		}
		else if(pause == true){
			//playing position of counters
			pos = 0;
			//palette entry 3 (red) will be replaced with the original
			BGPaletteMem[3] = palette[3];
			//enable bg3 and bg1 and disable bg2 and bg0 (prolly is faster c code for)
			SetMode(MODE_0 | BG1_ENABLE | BG3_ENABLE | OBJ_ENABLE | OBJ_MAP_1D);
			pause = false;
		}
		keystart = true;
	}
	if( !KEY_DOWN(KEYSTART)){
		keystart = false;
	}

	//zhe zoft-rezet button (A+B+START+SELECT)
	if( KEY_DOWN(KEYA) && KEY_DOWN(KEYB) && KEY_DOWN(KEYSTART) && KEY_DOWN(KEYSELECT) ){
		play = false;
	}
}

//moving the sprites coordinates
void Walk()
{

	t++;
	if(t>8 && pause == 0){

		lastdir[1] = walk;

		for(int i = size; i > 1; i--){
			lastx[i] = lastx[i-1];
			lasty[i] = lasty[i-1];
			lastdir[i] = lastdir[i-1];
		}

		//move the snake head
		if(lastdir[1] == 2){
			lastx[1]+=xspeed;
			lasty[1]-=yspeed;
		}
		else if(lastdir[1] == 3){
			lastx[1]+=xspeed;
			lasty[1]+=yspeed;
		}
		else if(lastdir[1] == 4){
			lastx[1]-=xspeed;
			lasty[1]+=yspeed;
		}
		else if(lastdir[1] == 1){
			lastx[1]-=xspeed;
			lasty[1]-=yspeed;
		}

		//check if the snake is left of the play area
		if(lastx[1] < 0){
			ResetSnake();
			End();
		}
		//check if the snake is right of the play area
		else if(lastx[1] > 224){
			ResetSnake();
			End();
		}
		//check if the snake is above the play area
		else if(lasty[1] < 0){
			ResetSnake();
			End();
		}
		//check if the snake is below of the play area
		else if(lasty[1] > 144){
			ResetSnake();
			End();
		}

		//food sprite
		lastx[0] = foodx;
		lasty[0] = foody;
		lastdir[0] = 5;

		//important use a clone of last (x,y) not last (x,y) itself.
		for(int i=0; i < size; i++){
			clonex[i] = lastx[i];
			cloney[i] = lasty[i];
		}

		//sorting array last (x,y) in array low (x,y)
		for(int i=0; i < size; i++){
			int maxy = 0;
			int index = 0;
			for(int j=0; j < size; j++){
				int y = cloney[j];
				if( y >=maxy){
					maxy = y;
					index = j;
				}
			}
			lowdir[i] = lastdir[index];
			lowx[i] = clonex[index];
			lowy[i] = maxy;
			clonex[index] = -1;
			cloney[index] = -1;
		}

		//setting the tile pointer right
		for(int i =0; i < size; i++){
			if(lowdir[i] == 5){
				sprites[i].attribute2 = 8;
			}
			else if(lowdir[i] == 3){
				sprites[i].attribute2 = 24;
			}
			else if(lowdir[i] == 4){
				sprites[i].attribute2 = 16;
			}
			else{
				sprites[i].attribute2 = 0;
			}
		}

		t=0;
	}
}

//checks for a collision with the tale
void CheckForTale()
{
	//head collides with tale of the snake
	for(int x = 2; x < size; x++){
		if( lastx[1] == lastx[x] && lasty[1] == lasty[x]){
			ResetSnake();
			End();
		}
	}
}


//main starting point from ROM
int main()
{
	//create starting positions of hisocres
	for(int x=0; x < 5; x++){
		position[x] = (7+x)*32 + 8;
	}
	//fill the hiscore array with some values
	for(int x=0; x < 5; x++){
		hiscore[x] = 85 - x*15;
	}

	//Enable background 2 and set mode to mode 4
	SetMode(MODE_4 | OBJ_MAP_1D | BG2_ENABLE);

	//loads the background palette
	DMACopy(3, (void*)titlePalette, (void*)BGPaletteMem, 128, DMA_32NOW);

	//draw some pictures in mode 4 and do some fades
	FadeOut(0);
	//draw title screen, actually, just copy the data into the right memory position with a dma transfer
	DMACopy(3, (void *)titleData, (void *)VideoBuffer, 19200, DMA_16NOW);
	FadeIn(2);
	WaitForStart();
	FadeOut(2);

	//clear buffer
	ClearBuffer();

	//load the (objects) sprite palette
	DMACopy(3, (void*)palette, (void*)OBJPaletteMem, 256, DMA_16NOW);

	InitializeSprites();

	int x;

	//setting lowx and lowy right, so the blocks will be invisible
	for(x=0; x < max; x++){
		lowx[x] = 240;
		lowy[x] = 160;
	}

	//x- and y-position of the food
	lastx[0] = foodx;
	lasty[0] = foody;
	lowx[0] = foodx;
	lowy[0] = foody;

	//x- and y-position of the head
	lastx[1] = xpos;
	lasty[1] = ypos;
	lowx[1] = xpos;
	lowy[1] = ypos;

	//setup 100 16x16 sprites
	for(x = 0; x < max; x++){
		sprites[x].attribute0 = COLOR_256 | SQUARE | lowy[x];
		sprites[x].attribute1 = SIZE_16 | lowx[x];
	}
	//on start up, sprite zero is the food, so point it to the food tile
	sprites[0].attribute2 = 8;

	//load tale sprite image
	DMACopy(3, (void*)taleData, (void*)OAMData, 128, DMA_16NOW);
	//load food sprite image
	DMACopy(3, (void*)foodData, (void*)(OAMData+128), 128, DMA_16NOW);
	//load headleft sprite image
	DMACopy(3, (void*)headleftData, (void*)(OAMData + 256), 128, DMA_16NOW);
	//load headright sprite image
	DMACopy(3, (void*)headrightData, (void*)(OAMData + 384), 128, DMA_16NOW);

	//array, containing the pointers of the counters
	for(x = 0; x < 10; x++){
		pointers[x] = x+1;
	}

	//loads the bg palette into memory
	REG_DM3SAD = (u32) palette; 
	REG_DM3DAD = (u32) BGPaletteMem; 
	REG_DM3CNT = 128 | DMA_32NOW;

	//loads the bg tiles into character memory 1
	REG_DM3SAD = (u32) tilesData;
	REG_DM3DAD = (u32) CharMem1;
	REG_DM3CNT = tiles_WIDTH*tiles_HEIGHT/4 | DMA_32NOW;

	//loads the number tiles into character memory 2
	REG_DM3SAD = (u32) numbersData;
	REG_DM3DAD = (u32) CharMem2;
	REG_DM3CNT = numbers_WIDTH*numbers_HEIGHT/4 | DMA_32NOW;

	//loads the font tiles into character memory 3
	REG_DM3SAD = (u32) fontData;
	REG_DM3DAD = (u32) CharMem3;
	REG_DM3CNT = font_WIDTH*font_HEIGHT/4 | DMA_32NOW;


	//Settings for bg3
	//sets BG registers right for BG3
	REG_BG3CNT = CHAR_BASE(1) | SCREEN_BASE(0) | BG_COLOR_256 | BG_PRIORITY(2);
	//loads the map wit text: Jenswa
	REG_DM3SAD = (u32) lj; 
	REG_DM3DAD = (u32) ScreenMem0; 
	REG_DM3CNT = 32*32/2 | DMA_32NOW;

	//Settings for bg2
	//sets BG registers right for BG2
	REG_BG2CNT = CHAR_BASE(1) | SCREEN_BASE(1) | BG_COLOR_256 | BG_PRIORITY(2);
	//loads the map: lp
	REG_DM3SAD = (u32) lp; 
	REG_DM3DAD = (u32) ScreenMem1; 
	REG_DM3CNT = 32*32/2 | DMA_32NOW;

	//Setting for bg1
	//sets BG registers right for BG1
	REG_BG1CNT = CHAR_BASE(2) | SCREEN_BASE(2) | BG_COLOR_256 | BG_PRIORITY(0);
	//loads the map: numbers
	REG_DM3SAD = (u32) numbers; 
	REG_DM3DAD = (u32) ScreenMem2; 
	REG_DM3CNT = 32*32/2 | DMA_32NOW;

	//Setting for bg0
	//sets BG registers right for BG0
	REG_BG0CNT = CHAR_BASE(3) | SCREEN_BASE(3) | BG_COLOR_256 | BG_PRIORITY(1);
	//loads the map: fontpause
	REG_DM3SAD = (u32) fontpause; 
	REG_DM3DAD = (u32) ScreenMem3; 
	REG_DM3CNT = 32*32/2 | DMA_32NOW;
	//not really necessairy, the map is loaded on pause press

	//set display mode, dont enable objects already
	SetMode(MODE_0 | BG1_ENABLE | BG3_ENABLE | OBJ_MAP_1D);

	//wait a little
	SleepQ(16);
	//Fade In, to play
	FadeIn(2);

	//set display mode again and enable objects this time
	SetMode(MODE_0 | BG1_ENABLE | BG3_ENABLE | OBJ_ENABLE | OBJ_MAP_1D);


	//main loop
	while(play == true)
	{
		if(end == false){
			//playing the game
			GetInput();			//read the gba keypad
			CheckForFood();			//collision with food
			CheckForTale();			//collision with tale
			Walk();				//change xpos and ypos
			MoveSprites();			//move all sprites
			CopyOAM();			//copies sprite data
			WaitForVsync();			//wait for the screen to stop drawing
		}
		else if(end == true){
			//hiscore screen
			GetFontInput();			//read the gba keypad
			FontDisplay();			//copy the text to the screen
			WaitForVsync();			//wait for the screen to stop drawing
		}
	}


}
