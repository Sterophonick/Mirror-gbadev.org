#ifndef BACKGROUND_H
#define BACKGROUND_H

//Tile memory sections
u16* CharMem0 = (u16*)0x6000000;
u16* CharMem1 = (u16*)0x6004000;
u16* CharMem2 = (u16*)0x6008000;
u16* CharMem3 = (u16*)0x600C000;

//Map memory sections
u16* ScreenMem0 = (u16*)0x6000000;
u16* ScreenMem1 = (u16*)0x6000800;
u16* ScreenMem2 = (u16*)0x6001000;
u16* ScreenMem3 = (u16*)0x6001800;

#define BG_PRIORITY(x)		x
#define CHAR_BASE(n)		n<<2
#define SCREEN_BASE(n)		n<<8

#define BG_MOSAIC_ENABLE		0x40
#define BG_COLOR_256		0x80
#define BG_COLOR_16		0x0

#define TEXTBG_SIZE_256x256	0x0
#define TEXTBG_SIZE_512x256	0x4000
#define TEXTBG_SIZE_256x512	0x8000
#define TEXTBG_SIZE_512x512	0xC000

#define ROTBG_SIZE_128x128		0x0
#define ROTBG_SIZE_256x256		0x4000
#define ROTBG_SIZE_512x512		0x8000
#define ROTBG_SIZE_1024x1024	0xC000

#define WRAPAROUND		0x2000

typedef struct BG
{
	int x,y,n;
}BG;

//updates the horizontal offset (HOFS) and vertical offset (VOFS) from BG
void UpdateBG(BG *bg)
{
	switch(bg->n)
	{
	case 0:
		REG_BG0HOFS = bg->x;
		REG_BG0VOFS = bg->y;
		break;
	case 1:
		REG_BG1HOFS = bg->x;
		REG_BG1VOFS = bg->y;
		break;
	case 2:
		REG_BG2HOFS = bg->x;
		REG_BG2VOFS = bg->y;
		break;
	case 3:
		REG_BG3HOFS = bg->x;
		REG_BG3VOFS = bg->y;
		break;
	default:
		break;
	}
}


#endif
