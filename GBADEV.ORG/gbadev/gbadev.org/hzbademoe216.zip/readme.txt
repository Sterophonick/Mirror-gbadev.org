HAZARD BALL ADVANCE  18/08/06
===================

Demo release 1.0


Hi,

Thank you for playing Hazard Ball, I hope you enjoy the demo I have released.

The full game is fully developed and has been ready for publishing for a few long months, with no luck in finding a potential publisher on my own I now release a demo in hope that my game gets noticed.

My contact information is at the bottom of this readme.


Features:
---------
Hazard Ball has 4 modes of play;

Adventure mode is a series of very large levels packed with combinations of puzzles and challenges.

Puzzle mode is a mode featuring many mini-levels, the aim is to collect all the gems to open the exit.

Co-operative mode is the 2-player equivalent of Adventure mode.  Using a link cable you can connect up 2 GBA units to play with a friend to help each other reach the goal. (2 gamepaks required)

Tilt and Roll mode makes use of a 3-axis motion sensor supplied by kionix, if you are lucky enough to own one of these then you can enjoy a extremely fun new mode.  The rules of this mode is similar to, both, the Adventure and Puzzle modes.  Your aim is to collect all the gems to open the exit and make your way there.  The difference is that you can use gravity to make the ball jump over obstacles! - just don't blame me if you accidentally let go of the GBA unit during play ;)


Levels:
		RELEASE	|	DEMO
			|
Adventure	20	|	1
Puzzle		75	|	12
Co-operative	10	|	1
Tilt & Roll	10	|	1
			|
Total		115	|	15


Controls:
---------
All modes except Tilt and Roll

DPAD:		(move) Roll the ball in the direction
A:		(action) Hold down to build construction blocks
			 While falling push to regenerate.
B:		(booster) Hold down while moving in a direction to boost.
L:		(mine) Press to plant a mine
R:		(rollspin) While still hold R and press a direction to rollspin

START:		pause the game / view mini-map


Tilt and Roll mode (Kionix accelerometer required)

MOVE: physically tilt the GBA unit to roll in the direction of tilt.
(note: there is an indicator to show the current tilt position)

JUMP: a quick jolt to the unit upwards (or towards yourself) to make the ball jump.
(note: to jump the ball must be in motion)

L / R: brake, use this to stabilise the ball.


contact 
-------

email:	gba@hazardball.com
web:	www.hazardball.com


Special thanks to the GBADEV.ORG community.