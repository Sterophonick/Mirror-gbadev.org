// CopperBars 2001!  
// A demo from my dos days, rehashed since I've long since lost the original source.
// Nothing special, nothing fancy, but every demo machine needs one.
// This should probably work on real hardware, but I promise nothing (doh, I forgot the -rw-base
// in the linker command on the first release)
// If I wern't so lazy, I'd rewrite this in asm. You could probably shoehorn this into
// 256 bytes if you wanted to.

// How to compile:
//  zarmasm -CPU ARM7TDMI -Littleend start.asm
//  zarmcc -c -Wall -Otime -ansic -fpu none -Littleend -cpu ARM7TDMI -apcs /narrow/noswst copper.c -o copper.o
//  zarmlink -bin -first start.o start.o copper.o -map -ro-base 0x08000000 -rw-base 0x03000000 -o copper.bin

// Some basic types
typedef unsigned char u8;
typedef unsigned short u16;
typedef unsigned long u32;

// A nice simple gradient with a sort of halo effect on each end
u8 table[21] = {0, 4, 9, 11, 3, 10, 16, 21, 25, 29, 31, 29, 25, 21, 16, 10, 3, 11, 9, 4, 0};

int GBA_main() {
  u16 cur_y, c;
  int t;
  int y1, y2, y3;
  int d1, d2, d3;

  // Set the video mode to #4, 240x160x256 bitmap mode
  *(u32 *)(0x04000000) = 4;
 
  // Initialize the copper bars position and velocity
  y1 = 10;   d1 = 1;
  y2 = 80;   d2 = 2;
  y3 = 150;  d3 = -1;

  while (1) {
    // Draw a frame
    for (cur_y = 0; cur_y < 160; cur_y++) {
      // Wait until its a new line
      __asm {
		mov 	r0, #0x4000006
      wait2:	ldrh	r1, [r0]
		cmp	r1, cur_y
		bne 	wait2
      }

      // Calculate the 3 copper bars contributions to the current color
      t = (cur_y-y1);
      if ((t<-10)||(t>10)) t=10;
      c = table[t+10];

      t = (cur_y-y2);
      if ((t<-10)||(t>10)) t=10;
      c += table[t+10] << 5;

      t = (cur_y-y3);
      if ((t<-10)||(t>10)) t=10;
      c += table[t+10] << 10;

      // Set the background color
      *(u16 *)(0x05000000) = c;
    }

    // Update the y positions
    y1 += d1; if ((y1>150) || (y1<10)) d1 = -d1;
    y2 += d2; if ((y2>150) || (y2<10)) d2 = -d2;
    y3 += d3; if ((y3>150) || (y3<10)) d3 = -d3;
  }

  return 0;
}