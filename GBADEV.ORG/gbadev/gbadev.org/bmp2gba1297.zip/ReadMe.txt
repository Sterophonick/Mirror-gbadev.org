READ! v1.00

*Known bugs*

* preview window will get messed when not streched
* 256 color bitmaps only
* bitmap must be equal or bigger than 240*160
* can't selcet multiple files
* 64 bitmaps each time only (should be enough though)
* wrong ICON
* your bug here...

*miscellaneous*

E-mail: nafdahli@hotmail.com


*C code (not tested)*

u16 *video_buffer = (u16 *)VRAM_BASE;
u16 *pal  = (u16 *)BG_PAL;
u16 *kill = (u16 *)Data;

int x, y, i;

SetMode(MODE4 | DISP_BG2);

for(i = 0 ; i < 256 ; i++)
{
	pal[i] = Palette[i];
}

for(y = 0 ; y < 160 ; y++) 
{
	for(x = 0 ; x < 120 ; x++)
	{
		video_buffer[y*120+x] = kill[y*120+x];
	}
}