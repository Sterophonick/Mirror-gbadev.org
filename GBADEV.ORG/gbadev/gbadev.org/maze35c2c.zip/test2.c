/********************************************************
*	Just a quick mode 4 demo  version 0.3
*
*		  by devoto
*
		added a raycasting engine.  Only the walls for now and
		VERY unoptomised.  Texture mapping will be added in next version
		then optomization.  Runs very slow.  Best with VGBA.

  
*		
********************************************************/

// Gba.h has all the register definitions
#include "gba.h"//from Eloist Wire cube Demo
#include <math.h>

//Some direction defines 
#define UP 1
#define LEFT 2
#define DOWN 3
#define RIGHT 4
#define PI 3.14159
#define SPEED 5
#define RADIAN(n) ((float)n/(float)180*PI)

#define WALL_HEIGHT 64           // Height of wall in pixels
#define VIEWER_DISTANCE 128      // Viewer distance from screen
#define VIEWPORT_LEFT 0         // Dimensions of viewport
#define VIEWPORT_RIGHT 120
#define VIEWPORT_TOP 0
#define VIEWPORT_BOT 160
#define VIEWPORT_HEIGHT 160    
#define VIEWPORT_CENTER 80

//Key Definitions from Nokturn's key demo
#define KEY_A 1
#define KEY_B 2
#define KEY_SELECT 4
#define KEY_START 8
#define KEY_RIGHT 16
#define KEY_LEFT 32
#define KEY_UP 64
#define KEY_DOWN 128
#define KEY_R 256
#define KEY_L 512
int* KEYS = (int*)0x04000130;


//memory offset of the palette mem and video
u16 *palette_mem = (u16*)0x5000000;
u16* Video_Buffer16 = (u16*)0x600A000;

//maze data. same old map
const char map[16][16]={
	{1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1},
	{1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1},
	{1,0,1,0,1,1,1,0,1,0,1,0,1,1,0,1},
	{1,0,1,0,1,0,0,0,1,1,1,0,1,1,0,1},
	{1,0,1,0,0,0,1,0,0,0,1,0,0,1,0,1},
	{1,0,1,1,1,0,1,0,1,0,1,1,1,1,0,1},
	{1,0,0,0,0,0,0,0,1,0,0,0,0,0,0,1},
	{1,0,1,1,1,0,1,0,1,1,1,0,1,1,0,1},
	{1,0,1,0,0,0,1,1,0,0,1,0,1,1,0,1},
	{1,0,1,0,1,0,1,1,1,1,1,0,1,1,0,1},
	{1,0,1,0,1,0,0,0,0,0,0,0,0,0,0,1},
	{1,0,1,1,1,0,1,0,1,0,1,1,1,1,0,1},
	{1,0,0,0,1,0,1,0,1,0,0,0,0,1,0,1},
	{1,0,1,1,1,0,1,1,1,1,1,1,1,1,0,1},
	{1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1},
	{1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1}
};

//structure to hold a position

typedef struct xy {
	float x,y;
}xy;

//current position and such

struct xy pos={5*64,5*64};  //added fine coordanants.  64 units per grid position

int direction=180;   //in degrees
int height = 32;     //used to simulate walking

int mode = 0x04;  //current video mode.  Mode 4 apears to be a linear
                  //8 bit palette mode with a back buffer at 0x600A000.  You can
		  //Switch to back buffer by orring *(0x4000000) with
		  //0x10.  Cannot write bytes to video memory. 

//Declerations
void WaitForVsync(void);
void Move(int Direction);			       	//moves fwd or back
int Get_Input(void);					//reads PAD and changes Direction
void Clear_Buffer(void);				//duh
void Wait(int time);					//waits
void Flip(void);					//flips back -> front / front->back
void drawmaze(int xview,int yview,float viewing_angle,
                 int viewer_height);//draws maze at variable height and angle
///////////////// C code entry (main())/////////////////////
int C_entry()
{
	int i;//counter
	//setup the display mode
	REG_DISPCNT = mode;   //set screen mode(REG_DISPCNT = *0x4000000)
	REG_DISPSTAT = 0x02;  //Not sure
	
	//Palette is 256 16 bit entries:  bbbbbgggggrrrrr-
	palette_mem[32] = 31<<10;  //blue for roof.
	palette_mem[0] = 31;       //sets palette 0 to red(background)
	for(i = 1; i < 32; i++)
		palette_mem[i] = (i<<10)+(i<<5)+(i);//32 shades of grey for cheep lighting
	
	
/////////////////MAIN LOOP////////////////////	
	while (1)
	 {
	
	float view_angle;  //angle player is facing

	Clear_Buffer();
	Move(Get_Input());	//get_input returns direction if up or down was
					//pressed, 0 otherwise.				
	view_angle = ((float)direction/(float)180*PI); // convert direction to radians
	drawmaze(pos.x,pos.y,view_angle,height);//draws it
	WaitForVsync();
	Flip();               	//swap front and back buffers
	//Wait(300);		//wait a bit
	}
}
//////////////////////////////////////////////

///////WaitForVsync//////////////////////////
void WaitForVsync(void)
{
	__asm 
	{
		mov 	r0, #0x4000006   //0x4000006 is vertical trace counter when it hits 					 //160 the vblanc starts
		scanline_wait:
		ldrh	r1, [r0]
		cmp	r1, #160
		bne 	scanline_wait
	}			
}

///////////////DRAWMAZE////////////////////////
void drawmaze(int xview,
                 int yview,float viewing_angle,
                 int viewer_height)

// Draws a raycast image in the viewport of the maze represented
// in array MAP[], as seen from position XVIEW, YVIEW by a
// viewer looking at angle VIEWING_ANGLE where angle 0 is due
// north. (Angles are measured in radians.).  Works on 90 degree
// walls at grid boundries only

{
  // Variable declarations:

  int sy,offset;       // Pixel y position and offset
  float xd,yd;         // Distance to next wall in x and y
  int grid_x,grid_y;   // Coordinates of x and y grid lines
  float xcross_x,xcross_y; // Ray intersection coordinates
  float ycross_x,ycross_y;
  unsigned int xdist,ydist; // Distance to x and y grid lines
  int xmaze,ymaze;     // Map location of ray collision
  int distance;        // Distance to wall along ray
  
 
  int column,y2,x2,xdiff,ydiff,height,bot,top,i,color;
  float column_angle,radians,x,y,slope;

  // Loop through all columns of pixels in viewport:

  for (column=VIEWPORT_LEFT; column<VIEWPORT_RIGHT; column++) {

    // Calculate horizontal angle of ray relative to
    //  center ray:

     column_angle=atan((float)(column-60)
                         / VIEWER_DISTANCE);

    // Calculate angle of ray relative to maze coordinates

    radians=viewing_angle+column_angle;

    // Rotate endpoint of ray to viewing angle:

    x2 = 1024 * (cos(radians));
    y2 = 1024 * (sin(radians));

    // Translate relative to viewer's position:

    x2+=xview;
    y2+=yview;

    // Initialize ray at viewer's position:

    x=xview;
    y=yview;

    // Find difference in x,y coordinates along ray:

    xdiff=x2-xview;
    ydiff=y2-yview;

    // Cheat to avoid divide-by-zero error:

    if (xdiff==0) xdiff=1;

    // Get slope of ray:

    slope = (float)ydiff/xdiff;

    // Cheat (again) to avoid divide-by-zero error:

    if (slope==0.0) slope=.0001;

    // Cast ray from grid line to grid line:

    for (;;) {

      // If ray direction positive in x, get next x grid line:

      if (xdiff>0) grid_x=((int)x & 0xffc0)+64;

      // If ray direction negative in x, get last x grid line:

      else grid_x=((int)x & 0xffc0) - 1;

      // If ray direction positive in y, get next y grid line:

      if (ydiff>0) grid_y=((int)y & 0xffc0) +64;

      // If ray direction negative in y, get last y grid line:

      else grid_y=((int)y & 0xffc0) - 1;

      // Get x,y coordinates where ray crosses x grid line:

      xcross_x=grid_x;
      xcross_y=y+slope*(grid_x-x);

      // Get x,y coordinates where ray crosses y grid line:

      ycross_x=x+(grid_y-y)/slope;
      ycross_y=grid_y;

      // Get distance to x grid line:

      xd=xcross_x-x;
      yd=xcross_y-y;
      xdist=sqrt(xd*xd+yd*yd);

      // Get distance to y grid line:

      xd=ycross_x-x;
      yd=ycross_y-y;
      ydist=sqrt(xd*xd+yd*yd);

      // If x grid line is closer...

      if (xdist<ydist) {

        // Calculate maze grid coordinates of square:

        xmaze=xcross_x/64;
        ymaze=xcross_y/64;

        // Set x and y to point of ray intersection:

        x=xcross_x;
        y=xcross_y;

        // Is there a maze cube here? If so, stop looping:

        if (map[xmaze][ymaze]) break;
      }
      else { // If y grid line is closer:

        // Calculate maze grid coordinates of square:

        xmaze=ycross_x/64;
        ymaze=ycross_y/64;

        // Set x and y to point of ray intersection:

        x=ycross_x;
        y=ycross_y;

        // Is there a maze cube here? If so, stop looping:

        if (map[xmaze][ymaze]) break;
      }
    }

    // Get distance from viewer to intersection point:

    xd=x-xview;
    yd=y-yview;
    distance=(long)sqrt(xd*xd+yd*yd)*cos(column_angle);
    if (distance==0) distance=1;

    // Calculate visible height of wall:


    height = VIEWER_DISTANCE * WALL_HEIGHT / distance;

    // Calculate bottom of wall on screen:

    bot = VIEWER_DISTANCE * viewer_height
               / distance + VIEWPORT_CENTER;

    // Calculate top of wall on screen:

    top = bot - height;

    // Clip wall to viewport:

    if (top < VIEWPORT_TOP) {
      height -= (VIEWPORT_TOP - top);
      top = VIEWPORT_TOP;
    }
    if ((top + height) > VIEWPORT_BOT) {
      height -= (bot - VIEWPORT_BOT);
    }

    // Find video offset of top pixel in wall column:

    offset = top * 120 + column;

    // Loop through all pixels in wall column:

    //this is were the lighting takes place.  told you it was cheep.
	color = (float)31 * ((float)64/(float)distance);
	if(color>31)color = 31;
	
	
	for (i=0; i<height; i++) {

      // Set wall pixels to white:
		
      Video_Buffer16[offset]=color+(color<<8);

      // Advance to next vertical pixel:

      offset+=120;
    }
  }
}


////////////////////////////////////////////////////////

///////////////Get Input////////////////////////////////
int Get_Input(void)
{
	int d = 0; //keep track of delta

//key bits are reset when a key is pressed.  Apperantly they must be set back to 0;

	if(!((*KEYS) & KEY_UP))        //is UP bit 0?
	{
		d = UP;			//need to Move UP
		(*KEYS) |= KEY_UP;      //reset KEY_UP bit to 1
	}
	if(!((*KEYS) & KEY_DOWN))
	{
		d = DOWN;	
		(*KEYS) |= KEY_DOWN;
	}
	if(!((*KEYS) & KEY_LEFT))
	{
		direction -= 3;
		if(direction < 0)
			direction = 359;

		(*KEYS) |= KEY_LEFT;
	}
	if(!((*KEYS) & KEY_RIGHT))
	{
		direction += 3;
		if(direction > 359)
			direction = 0;

		(*KEYS) |= KEY_RIGHT;
	}
	if(!((*KEYS) & KEY_A))
	{
		//do A button stuff here
	}
	return d;
}

/////////////////////////////////////////////////////////

////////////////////MOVE/////////////////////////////////
void Move(int d)
{
	static int hdelta = -2;
	struct xy old;  //holds initial xy incase we try to move into a wall
	old.x = pos.x;
	old.y = pos.y;

	if(d == UP)
	{
		pos.x += SPEED * cos(RADIAN(direction));     //move forward
		pos.y += SPEED * sin(RADIAN(direction));		
		height += hdelta;
		if(height > 34 || height < 30)
			hdelta = -hdelta;
	}
	if(d == DOWN)
	{
		pos.x -= SPEED * cos(RADIAN(direction));     //Move back
		pos.y -= SPEED * sin(RADIAN(direction));		
		height += hdelta;
		if(height > 34 || height < 30)
			hdelta = -hdelta;
	}
	if(map[(int)pos.x>>6][(int)pos.y>>6])     //inside a wall move back
	{
		pos.x = old.x;
		pos.y = old.y;
	}
}

void Clear_Buffer(void)
{
	int i;
	int* Video_Buffer32 = (int*)Video_Buffer16;  //make it a 32 bit pointer 

	if(mode == 0x4)
	{
		for(i = (240*160/4); i>(240*160/4/2); i-=4)   //32 bit is faster
		{	
			Video_Buffer32[i] = 0;      //unroll it a little
			Video_Buffer32[i+1] = 0;
			Video_Buffer32[i+2] = 0;
			Video_Buffer32[i+3] = 0;
		}//end for
		for(i = (240*160/4/2); i>=0; i-=4)   //32 bit is faster
		{	
			Video_Buffer32[i] = 32+(32<<8)+(32<<16)+(32<<24);      //unroll it a little
			Video_Buffer32[i+1] = 32+(32<<8)+(32<<16)+(32<<24);
			Video_Buffer32[i+2] = 32+(32<<8)+(32<<16)+(32<<24);
			Video_Buffer32[i+3] = 32+(32<<8)+(32<<16)+(32<<24);
		}//end for
	}//end if
}// end Clear_Buffer

void Wait(int time)
{
	int i1,i2,temp;
	for(i1 = 0; i1 < time; i1++)
		for(i2 = 0; i2 < time; i2++)
			temp = i1*i2;
}//end Wait


void Flip(void)
{
	if(REG_DISPCNT == 0x04)
	{
		REG_DISPCNT |= 0x10;   //flip to back
		Video_Buffer16 = (u16*)0x6000000;  //draw to front
	}
	else
	{
		REG_DISPCNT = 0x04; //flip to front
		Video_Buffer16 = (u16*)0x600A000; //draw to back
	}//end ifelse
}//end flip

