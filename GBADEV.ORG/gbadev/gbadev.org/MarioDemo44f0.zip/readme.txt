
----------------------------------------------------------
|                                                        |
|                      MARIO DEMO                        |
|              by Romain Goupil 08/24/2002               |
|                  romaingoupil@wanadoo.fr               |
|                                                        |
----------------------------------------------------------

This is unfinished 2D platform game engine.

The intro artwork is made by Olivia Brun (oliola@wanadoo.fr).

Requirements
  This game run on any emulator and on real hardware.

Please send feedback and suggestions to
  romaingoupil@free.fr

Thanks to Forgotten for his great emulator.

Mario character is trademark of Nintendo.

