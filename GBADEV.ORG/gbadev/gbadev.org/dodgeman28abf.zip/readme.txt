Dodgeman 2 - The Demo!
"Quick and Dirty" Instruction Manual
Game Developed By: Adam "Holmfry" Holmes

Introduction
------------

This game is a follow-up to a game I wrote in Visual Basic waaaaaaaaaaay back in high school, which became a huge hit (amongst my friends, that is).  I began writing this sequel as an introduction for myself into the world of GBA development.  This package contains a complete 2 level demo of the game.  My future plans for this project are outlined briefly below.

Controls
--------

Press left to move Dodgeman left
Press right to move Dodgeman right

..it's really that simple.. just be ready after pressing START at the title screen.. the action starts right away!

How to Play
-----------

As the name of the game implies - dodge stuff.

You get 3 hits.  Once your life bar (top left corner) runs out, that's it!  The first level lasts for about 35 seconds, the 2nd.... ?? I'll leave that to you to find out.

Future Plans for Dodgeman
-------------------------

In the complete version of the game, there will be:

- some very interesting powerups, giving Dodgeman extra speed, temporary invincibility and even FIREPOWER!  (plus extra hidden cheats, of course!)

- at LEAST 50 levels (my goal is 100+)

- enemy falling patterns will be randomized

- SOUND

- I would like to explore a linked multiplayer battle mode!

----------------------------------------------------------------------------------------------

Remember, this is only a demo - and my first forray into the crazy world of Gameboy Advance development!  I hope you enjoy it!  Also, stay tuned for a much larger project that I have in the works :)

- Holmfry

