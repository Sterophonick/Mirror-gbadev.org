//Implement input_handler class
//Code with comments           197
//Code without comments        146
//Total rows                   241

#include "h/input_handler.h"


input_handler::input_handler()
{
	keys = (int*)0x04000130;

	//All start with the value of false
	a_pressed = b_pressed = start_pressed = select_pressed = l_pressed = r_pressed = up_pressed = \
	down_pressed = left_pressed = right_pressed = a_wpressed = b_wpressed = start_wpressed = \
	select_wpressed = l_wpressed = r_wpressed = up_wpressed = down_wpressed = left_wpressed = \
	right_wpressed = false;

}


bool
input_handler::is_pressed(button key_pressed)
{
/*	if(!(*keys & key_pressed))
		return true;
	else
		return false;
*/
	switch(key_pressed){
		case KEY_A:
			return a_pressed;
			break;
		case KEY_B:
			return b_pressed;
			break;
		case KEY_L:
			return l_pressed;
			break;
		case KEY_R:
			return r_pressed;
			break;
		case KEY_SELECT:
			return select_pressed;
			break;
		case KEY_START:
			return start_pressed;
			break;
		case KEY_UP:
			return up_pressed;
			break;
		case KEY_DOWN:
			return down_pressed;
			break;
		case KEY_LEFT:
			return left_pressed;
			break;
		case KEY_RIGHT:
			return right_pressed;
			break;
		default:
			return false;
			break;
	}

}


void
input_handler::update()
{
	//If A is pressed
	if(!(*keys & KEY_A))
	{
		//It it was pressed even before ignore it for now
		if(a_wpressed)
			a_pressed = false;
		//If it wasn't pressed before consider it pressed
		else
			a_pressed = a_wpressed = true;
	}
	//If not pressed reset related variabile
	else
		a_pressed = a_wpressed = false;



	//If B is pressed
	if(!(*keys & KEY_B))
	{
		//It it was pressed even before ignore it for now
		if(b_wpressed)
			b_pressed = false;
		//If it wasn't pressed before consider it pressed
		else
			b_pressed = b_wpressed = true;
	}
	//If not pressed reset related variabile
	else
		b_pressed = b_wpressed = false;



	//If START is pressed
	if(!(*keys & KEY_START))
	{
		//It it was pressed even before ignore it for now
		if(start_wpressed)
			start_pressed = false;
		//If it wasn't pressed before consider it pressed
		else
			start_pressed = start_wpressed = true;
	}
	//If not pressed reset related variabile
	else
		start_pressed = start_wpressed = false;



	//If SELECT is pressed
	if(!(*keys & KEY_SELECT))
	{
		//It it was pressed even before ignore it for now
		if(select_wpressed)
			select_pressed = false;
		//If it wasn't pressed before consider it pressed
		else
			select_pressed = select_wpressed = true;
	}
	//If not pressed reset related variabile
	else
		select_pressed = select_wpressed = false;



	//If L is pressed
	if(!(*keys & KEY_L))
	{
		//It it was pressed even before ignore it for now
		if(l_wpressed)
			l_pressed = false;
		//If it wasn't pressed before consider it pressed
		else
			l_pressed = l_wpressed = true;
	}
	//If not pressed reset related variabile
	else
		l_pressed = l_wpressed = false;



	//If R is pressed
	if(!(*keys & KEY_R))
	{
		//It it was pressed even before ignore it for now
		if(r_wpressed)
			r_pressed = false;
		//If it wasn't pressed before consider it pressed
		else
			r_pressed = r_wpressed = true;
	}
	//If not pressed reset related variabile
	else
		r_pressed = r_wpressed = false;



	//If UP is pressed
	if(!(*keys & KEY_UP))
	{
		//It it was pressed even before ignore it for now
		if(up_wpressed)
			up_pressed = false;
		//If it wasn't pressed before consider it pressed
		else
			up_pressed = up_wpressed = true;
	}
	//If not pressed reset related variabile
	else
		up_pressed = up_wpressed = false;



	//If DOWN is pressed
	if(!(*keys & KEY_DOWN))
	{
		//It it was pressed even before ignore it for now
		if(down_wpressed)
			down_pressed = false;
		//If it wasn't pressed before consider it pressed
		else
			down_pressed = down_wpressed = true;
	}
	//If not pressed reset related variabile
	else
		down_pressed = down_wpressed = false;



	//If LEFT is pressed
	if(!(*keys & KEY_LEFT))
	{
		//It it was pressed even before ignore it for now
		if(left_wpressed)
			left_pressed = false;
		//If it wasn't pressed before consider it pressed
		else
			left_pressed = left_wpressed = true;
	}
	//If not pressed reset related variabile
	else
		left_pressed = left_wpressed = false;



	//If RIGHT is pressed
	if(!(*keys & KEY_RIGHT))
	{
		//It it was pressed even before ignore it for now
		if(right_wpressed)
			right_pressed = false;
		//If it wasn't pressed before consider it pressed
		else
			right_pressed = right_wpressed = true;
	}
	//If not pressed reset related variabile
	else
		right_pressed = right_wpressed = false;

}


//True if all direction keys are released, false otherwise
bool
input_handler::alldirreleased()
{
	return(!((is_pressed(KEY_UP)) || (is_pressed(KEY_DOWN)) || (is_pressed(KEY_LEFT))
		|| (is_pressed(KEY_RIGHT))));
}


