//Main file
//Code with comments           40
//Code without comments        21
//Total rows                   55

//Class that handle the snake data
#include "h/snake_play_data.h"

//Class that handle the input
#include "h/input_handler.h"

//Graphics handler
#include "h/graphics.h"

#include "h/main.h"

//GLOBAL VARIABILE/FUNCTIONS
//Keep the status of the game. At the beginning the game start with the menu
status game_status = MENU_START;

//Wait for the screen to stop drawing
void WaitForVsync(){while((volatile u16)REG_VCOUNT != 160){}}

int
main(void)
{
	//GAME BOY ADVANCE SYSTEM INITIALITION

	//Mode 1 = Tile mode with background 0-1-2 available and rotation and scaling on 2
	//Sprite enalbed
	//1D for sprite graphic's memory
	SetMode(MODE_1 | OBJ_ENABLE | OBJ_MAP_1D);

	//Input handler
    input_handler i;

	//Update-game-data handler
	snake_play_data p;

	//Graphic handler
	graphics g;


	//MAIN LOOP
	while(1)
	{
		i.update();
		p.update(i);
		g.update(p);
	}

	//For ANSI rules respect
	return 0;
}

