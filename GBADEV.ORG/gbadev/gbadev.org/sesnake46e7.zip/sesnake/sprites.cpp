/*
Implement sprite_handler class
Code with comments           145
Code without comments         86
Total rows                   215
*/
#include "h/sprites.h"

void
sprite_handler::clear()
{
	data_used = used = 0;

	//To clear OAM I set sprites to off screen
	for(short i = 0; i < 128; i++)
	{
		oam_mem[i].attribute0 = 160; //y > 159
		oam_mem[i].attribute1 = 240; //x > 239
	}

	//I inizialize the OAM with this data
	copy2OAM();

}

/*
Add a sprite in OAM and return the index into the vector. Return -1 on coordinate error,
-2 on other type of error.
(the index must be used to refer at the sprite's attribute)
x_coord           X coordinate of the sprite (must be a number between 0-512)
y_coord           Y coordinate of the sprite (must be a number between 0-255)
enable_rotation   true if the sprite must accept rotation and/or scaling parameters
double_size       true to enable the drawing of sprite bigger than usual
sprite_w          the width of the sprite (must be equal to 8, 16, 32 or 64)
sprite_h          the height of the sprite (must be equal to 8, 16, 32 or 64)
char_number       the location of the sprite's data (the value returned by add_sprite_data)
priority          the priority of the sprite (on the z axis) (must be a value between 0-3)
palette_number    the palette number (ignored if the number of color is 256)(the value returned by add_sprite_palette)
*/
int
sprite_handler::add_sprite_attr(int x_coord, int y_coord, bool enable_rotation, bool double_size, int sprite_w, int sprite_h, int char_number, int priority, int palette_number)
{
	//Control of the correctness of the parameters
	if((x_coord < 0) || (x_coord > 512) || (y_coord < 0) || (y_coord > 255))
		return -1;

	if((n_of_color != 16) && (n_of_color != 256))
		return -2;

	if((sprite_w != 64) && (sprite_w != 32) && (sprite_w != 16) && (sprite_w != 8))
		return -2;

	if((sprite_h != 64) && (sprite_h != 32) && (sprite_h != 16) && (sprite_h != 8))
		return -2;

	if((priority < 0) || (priority > 3))
		return -2;

	if(used == 128)
		return -2;

	ch_attr(used, x_coord, y_coord, enable_rotation, double_size, sprite_w, sprite_h, char_number, priority, palette_number);

	//Incremented becouse of the sprite added (done now to avoid to write always used - 1 in the previos instructions)
	used++;

	return (used - 1);
}


/*
Copy oam_mem (the shadow OAM) into OAM
*/
void
sprite_handler::copy2OAM()
{
	u16 *OAM = (u16*) OAMmem;
	u16 *temp = (u16 *) oam_mem;

	for (u16 loop = 0; loop < 512; loop++)
		OAM[loop] = temp[loop];
}

/*
Load the palette into memory.
Return the number of the palette if it's a 16-color palette, otherwise 0.
palette      the palette to copy in memory
n_of_color   the number of color of the palette (must be equal to 16 or 256)
*/
int
sprite_handler::add_sprite_palette(const u16 palette[], int n_of_color)
{
	//TO DO handle 16-color palette
	u16 *palette_add = OBJPaletteMem;

	for(u16 loop = 0; loop < n_of_color; loop++)
		palette_add[loop] = palette[loop];

	return 0;
}


/*
Add the image data of a sprite into OAMData. Return the position into OAMData or -1 on error.
data       the vector that contains image data
sprite_w   the width of the sprite (must be equal to 8, 16, 32 or 64)
sprite_h   the height of the sprite (must be equal to 8, 16, 32 or 64)
*/
int
sprite_handler::add_sprite_data(const u16 data[], int sprite_w, int sprite_h)
{
	//TO DO Assumption : sprite_w and sprite_h are always equal at 8 so they are ignored and color = 256

	u16 *OAM = OAMData;
	//n is equal to the offset into OAMData (it depends from the sprite's number)
	int n = 32 * (data_used / 2);//Each 8x8 256 color sprite needs 64 bytes of space

	for(int loop = 0; loop < 32; loop++)
		OAM[loop + n] = data[loop];

	data_used += 2;

	return (data_used - 2);
}


/*
Update the position of a sprite.
sprite_id         the index of the sprite (0-127)
new_x             the new x position
new_y             the new y position
*/
void
sprite_handler::updatepos(int sprite_id, int new_x, int new_y)
{
	oam_mem[sprite_id].attribute1 &= 0xFF00;
	oam_mem[sprite_id].attribute0 &= 0xFF00;

	oam_mem[sprite_id].attribute1 |= new_x;
	oam_mem[sprite_id].attribute0 |= new_y;
}

/*
Change the attributes of a sprite.index is position into the vector. All the other parameters are equivalent of those used in
add_sprite_attr
*/
void
sprite_handler::ch_attr(int index, int x_coord, int y_coord, bool enable_rotation, bool double_size, int sprite_w, int sprite_h, int char_number, int priority, int palette_number)
{
	//Initialization of shadow oam of the new sprite
	oam_mem[index].attribute0 = y_coord;

	//From now attribute0 is initialize

	if(n_of_color == 16)
	{
		oam_mem[index].attribute0 |= COLOR_16;
		oam_mem[index].attribute2 = PALETTE(palette_number);
	}
	else
	{
		oam_mem[index].attribute0 |= COLOR_256;
		oam_mem[index].attribute2 = 0;
	}

	//From now attribute2 is initialize

	if(enable_rotation)
		oam_mem[index].attribute0 |= ROTATION_FLAG;

	if(double_size)
		oam_mem[index].attribute0 |= SIZE_DOUBLE;

	if(sprite_w == sprite_h)
	{
		oam_mem[index].attribute0 |= SQUARE;

		switch(sprite_w)
		{
			case 8:
				oam_mem[index].attribute1 = SIZE_8;
				break;
			case 16:
				oam_mem[index].attribute1 = SIZE_16;
				break;
			case 32:
				oam_mem[index].attribute1 = SIZE_32;
				break;
			case 64:
				oam_mem[index].attribute1 = SIZE_64;
				break;
			default:
				break;
		}
	}

	if(sprite_w > sprite_h)
	{
		oam_mem[index].attribute0 |= WIDE;
		//TO DO attribute1 object's shape and initialization
	}

	if(sprite_w < sprite_h)
	{
		oam_mem[index].attribute0 |= TALL;
		//TO DO attribute1 object's shape and initialization
	}

	//From now attribute1 is initialize

	oam_mem[index].attribute1 |= x_coord;

	oam_mem[index].attribute2 |= (char_number | PRIORITY(priority));
}

