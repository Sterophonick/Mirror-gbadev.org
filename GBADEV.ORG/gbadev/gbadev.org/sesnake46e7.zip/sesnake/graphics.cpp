//Implement graphics class
//Code with comments           156
//Code without comments         87
//Total rows                   202
#include "h/graphics.h"

//File containing data and palette of the sprite
#include "h/sprite_palette.h"
#include "h/sprite_data.h"

//File containing data and palette of the background
#include "h/background.h"
#include "h/tile_sfondo.h"


graphics::graphics()
{
	//Loading of all sprite data and palette
	sprite_man.add_sprite_palette(spritepal, 256);

	sprite_man.add_sprite_data(head_updata, 8, 8);//position in OAM memory = 0
	sprite_man.add_sprite_data(head_downdata, 8, 8);//position in OAM memory = 2
	sprite_man.add_sprite_data(head_rightdata, 8, 8);//position in OAM memory = 4
	sprite_man.add_sprite_data(head_leftdata, 8, 8);//position in OAM memory = 6

	sprite_man.add_sprite_data(body_updata, 8, 8);//position in OAM memory = 8
	sprite_man.add_sprite_data(body_downdata, 8, 8);//position in OAM memory = 10
	sprite_man.add_sprite_data(body_rightdata, 8, 8);//position in OAM memory = 12
	sprite_man.add_sprite_data(body_leftdata, 8, 8);//position in OAM memory = 14

	sprite_man.add_sprite_data(tail_updata, 8, 8);//position in OAM memory = 16
	sprite_man.add_sprite_data(tail_downdata, 8, 8);//position in OAM memory = 18
	sprite_man.add_sprite_data(tail_rightdata, 8, 8);//position in OAM memory = 20
	sprite_man.add_sprite_data(tail_leftdata, 8, 8);//position in OAM memory = 22

	//Insect sprite data
	sprite_man.add_sprite_data(insetto1_data, 8, 8);//position in OAM memory = 24
	sprite_man.add_sprite_data(insetto2_data, 8, 8);//position in OAM memory = 26


	//Copy into the system the background palette
	bgh.copypalette(alltilepal);

	/*
	Initialition of background 2.
	The tile data is in position 0, the map data in position 28.
	It's 256x256 background that start at position 120-80.
	256 color and mosaic and wraparound disabled
	*/
	bgh.init(2, 0, 28, 256, 120, 80, false, true, false, 2);


	//Copy into the system the tiles used to create the backgrounds
	bgh.copytile(2, alltiledata, TILE_DATA_W, TILE_DATA_H);

	//Enable visualition of the background
	bgh.enablebg(2);
}


//Display all the graphics
void
graphics::update(snake_play_data& data)
{
	//If we are in the menu
	if((game_status == MENU_START) || (game_status == MENU_SPEED))
		update_menu(data);
	//if we are during the game
	else
		update_game(data);
}


void
graphics::update_game(snake_play_data& data)
{
	piece* sinfo = data.getsnakeinfo();

	while (sinfo != NULL)
	{
		//If the piece is uninitialized (its data isn't present in OAM)
		if(sinfo->vec_pos == -1)
			//Initialize it
			sinfo->vec_pos = sprite_man.add_sprite_attr(sinfo->x, sinfo->y, false, false, 8, 8, sinfo->part, 0, 0);
		else
			//Update it
			sprite_man.ch_attr(sinfo->vec_pos, sinfo->x, sinfo->y, false, false, 8, 8, sinfo->part, 0, 0);

		sinfo = sinfo->next;
	}

	//Display insect
	int x, y, t, v;
	data.getinsinfo(&x, &y, &t, &v);

	//find the insect type and corrispondent sprite data
	if(t == 0)
		t = 24;
	else
		t = 26;

	//Create or update insect info into OAM
	if(v == -1)
	{
		v = sprite_man.add_sprite_attr(x, y, false, false, 8, 8, t, 0, 0);

		data.setinsvecpos(v);
	}
	else
		sprite_man.ch_attr(v, x, y, false, false, 8, 8, t, 0, 0);


	//Display the point amount
	int p = data.getpoint();

	for(int i = 0; i < 4; i++)
	{
		snake_game_bg[45 - i] = 0x0A + (p % 10);
		p = p / 10;
	}


	//if GAME_PAUSE
	if(game_status == GAME_PAUSE)
	{
		snake_game_bg[53] = 0x19;//P
		snake_game_bg[54] = 0x14;//A
		snake_game_bg[55] = 0x1D;//U
		snake_game_bg[56] = 0x1B;//S
		snake_game_bg[57] = 0x17;//E
	}
	//if GAME_OVER
	else if(game_status == GAME_OVER)
	{
		snake_game_bg[50] = 0x03;//G
		snake_game_bg[51] = 0x14;//A
		snake_game_bg[52] = 0x04;//M
		snake_game_bg[53] = 0x17;//E
		snake_game_bg[54] = 0x02;//space
		snake_game_bg[55] = 0x18;//O
		snake_game_bg[56] = 0x05;//V
		snake_game_bg[57] = 0x17;//E
		snake_game_bg[58] = 0x1A;//R

	}
	//be sure there's nothing written
	else
	{
		snake_game_bg[50] = snake_game_bg[51] = snake_game_bg[52] = snake_game_bg[53] = snake_game_bg[54] = snake_game_bg[55] = snake_game_bg[56] = snake_game_bg[57] = snake_game_bg[58] = 0x02;
	}

	//Wait for Vsync before doing screen changes
	WaitForVsync();

	//Update the map value, only if necessary
	bgh.copymap(2, snake_game_bg);

	sprite_man.copy2OAM();

}

void
graphics::update_menu(snake_play_data& data)
{
	sprite_man.clear();
	sprite_man.copy2OAM();

	//If we are on the start voice
	if(game_status == MENU_START)
	{
		//draw the hand on the START position
		snake_menu_bg[265] = 0x20;
		snake_menu_bg[266] = 0x21;
		snake_menu_bg[297] = 0x2A;
		snake_menu_bg[298] = 0x2B;

		//Be sure it isn't on the SPEED position
		snake_menu_bg[361] = snake_menu_bg[362] = snake_menu_bg[393] = snake_menu_bg[394] = 0x02;
	}
	//else we are on the speed voice
	else
	{
		//draw the hand on the SPEED position
		snake_menu_bg[361] = 0x20;
		snake_menu_bg[362] = 0x21;
		snake_menu_bg[393] = 0x2A;
		snake_menu_bg[394] = 0x2B;

		//be sure it isn't on the START position
		snake_menu_bg[265] = snake_menu_bg[266] = snake_menu_bg[297] = snake_menu_bg[298] = 0x02;
	}

	//Set map value at the actual speed value
	snake_menu_bg[371] = 0x0A + data.getspeed();


	//Wait for Vsync before doing screen changes
	WaitForVsync();

	//Update the map value, only if necessary
	bgh.copymap(2, snake_menu_bg);
}
