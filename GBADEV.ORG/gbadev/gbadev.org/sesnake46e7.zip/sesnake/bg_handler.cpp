/*
Implements bg_handler class
Code with comments           117
Code without comments         75
Total rows                   143
*/

#include "h/bg_handler.h"


/*
Initialize a background.
bg_number       the number of the background (must be between 0-3)
tile_pos        number of the character base block containing the tile data (must be between 0-3)
map_pos         number of the screen base block containing the map data (must be between 0-31)
bg_size         size of the background (must be 128 for 128x128 map or 256 for 256x256 map)
x_pos           initial x position of the background
y_pos           initial y position of the background
mosaic          true to enable mosaic effect, false otherwise
color256        true if the background is 256 color, false otherwise
wrap_around     true to enable wrap around, false otherwise
priority        priority of the background (must be between 0-3)
*/
void
bg_handler::init(int bg_number, int tile_pos, int map_pos, int bg_size, int x_pos, int y_pos, bool mosaic, bool color256, bool wrap_around, int priority)
{
	//TO DO : controls of input, activation of mosaic and wrap around actions and delete useless part of code and stucture

	bg[bg_number].number = bg_number;
	bg[bg_number].charBaseBlock = tile_pos;
	bg[bg_number].screenBaseBlock = map_pos;

	if(color256)
		bg[bg_number].colorMode = BG_COLOR_256;
	else
		bg[bg_number].colorMode = BG_COLOR_16;

	if(bg_size == 128)
		bg[bg_number].size = ROTBG_SIZE_128x128;
	else
		bg[bg_number].size = ROTBG_SIZE_256x256;

	bg[bg_number].mosaic = 0;
	bg[bg_number].wraparound = 0;

	bg[bg_number].x_scroll = x_pos;
	bg[bg_number].y_scroll = y_pos;

	bg[bg_number].tileData = (u16 *)CharBaseBlock(tile_pos);
	bg[bg_number].mapData = (u16 *)ScreenBaseBlock(map_pos);
}

/*
Copy all the data in the appropriate register and enable the visualition of the background.
number          the number of the background (must be between 0-3)
*/
void
bg_handler::enablebg(int n)
{
	//TO DO : handle all the register attribute

	u16 tmp = bg[n].size | (bg[n].charBaseBlock << CHAR_SHIFT) | (bg[n].screenBaseBlock << SCREEN_SHIFT) | bg[n].colorMode;

	switch(n)
	{
		case 0:
			REG_BG0CNT = tmp;
			REG_DISPCNT |= BG0_ENABLE;
			break;
		case 1:
			REG_BG1CNT = tmp;
			REG_DISPCNT |= BG1_ENABLE;
			break;
		case 2:
			REG_BG2CNT = tmp;
			REG_DISPCNT |= BG2_ENABLE;
			break;
		case 3:
			REG_BG3CNT = tmp;
			REG_DISPCNT |= BG3_ENABLE;
			break;
		default:
			break;
	}
}


/*
Copy the palette into memory.
pal             the palette that must be copied
*/
void
bg_handler::copypalette(const u16 *pal)
{
	u16 *bg_pal = BGPaletteMem;

	for(u16 loop = 0; loop < 256; loop++)
		bg_pal[loop] = pal[loop];
}


/*
Copy the map of the selected background into memory
number          the number of the background (must be between 0-3)
map             the pointer at the map
*/
void
bg_handler::copymap(int number, const u8 *map)
{
	u16 *tmp = (u16*) map;

	for(u16 loop = 0; loop < ((32 * 32) / 2); loop++)
		bg[number].mapData[loop] = tmp[loop];
}


/*
As above, but this version copy only the first ntocopy elements of vector map
*/
void
bg_handler::copymap(int number, const u8 *map, int ntocopy)
{
	u16 *tmp = (u16*) map;

	for(u16 loop = 0; loop < ntocopy; loop++)
		bg[number].mapData[loop] = tmp[loop];

}


/*
Copy the tile data of the selected background into memory
number          the number of the background (must be between 0-3)
tiledata        the pointer at the tile data
*/
void
bg_handler::copytile(int number, const u16 *tiledata, int w, int h)
{
	u16 *tmp = (u16*) tiledata;

	for(u16 loop = 0; loop < ((w * h) / 2); loop++)
		bg[number].tileData[loop] = tmp[loop];
}
