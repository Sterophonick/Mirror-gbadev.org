/*
Contains important definition
Code with comments           24
Code without comments         6
Total rows                   36
*/

#ifndef MAIN_H
#define MAIN_H

/*
Enumeration to define in which status the game is

MENU_START during the initial menu (on the START option)
MENU_SPEED during the initial menu (on the SPEED option)
GAME_PLAY  during the game (the player is using the snake)
GAME_PAUSE during the game the player press the START button and the game goes is paused and in this
           status
*/
enum status {MENU_START, MENU_SPEED, GAME_PLAY, GAME_PAUSE, GAME_OVER};



//GLOBAL VARIABILE

//Keep the status of the game.
extern status game_status;


//GLOBAL FUNCTIONS

//Wait for the screen to stop drawing
void WaitForVsync();


#endif
