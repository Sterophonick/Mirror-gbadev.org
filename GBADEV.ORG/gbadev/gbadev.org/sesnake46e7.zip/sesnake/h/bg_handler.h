/*
Class that handle all the 4 background
Code with comments           59
Code without comments        19
Total rows                   72
*/

#ifndef BERNA_BG_H
#define BERNA_BG_H

#include "gba.h"
#include "dispcnt.h"
#include "video_tools.h"
#include "Bg.h"

class bg_handler
{
	public:
		bg_handler(){}
		~bg_handler(){}

		/*
		Initialize a background.
		bg_number       the number of the background (must be between 0-3)
		tile_pos        number of the character base block containing the tile data (must be between 0-3)
		map_pos         number of the screen base block containing the map data (must be between 0-31)
		bg_size         size of the background (must be 128 for 128x128 map or 256 for 256x256 map)
		x_pos           initial x position of the background
		y_pos           initial y position of the background
		mosaic          true to enable mosaic effect, false otherwise
		color256        true if the background is 256 color, false otherwise
		wrap_around     true to enable wrap around, false otherwise
		priority        priority of the background (must be between 0-3)
		*/
		void init(int bg_number, int tile_pos, int map_pos, int bg_size, int x_pos, int y_pos, bool mosaic, bool color256, bool wrap_around, int priority);

		/*
		Copy all the data in the appropriate register and enable the visualition of the background.
		number          the number of the background (must be between 0-3)
		*/
		void enablebg(int number);

		/*
		Copy the palette into memory.
		pal             the palette that must be copied
		*/
		void copypalette(const u16 *pal);

		/*
		Copy the map of the selected background into memory
		number          the number of the background (must be between 0-3)
		map             the pointer at the map
		*/
		void copymap(int number, const u8 *map);

		/*
		As above, but this version copy only the first ntocopy elements of vector map
		*/
		void copymap(int number, const u8 *map, int ntocopy);

		/*
		Copy the tile data of the selected background into memory
		number          the number of the background (must be between 0-3)
		tiledata        the pointer at the tile data
		*/
		void copytile(int number, const u16 *tiledata, int w, int h);

	private:
		Bg bg[4];
};

#endif
