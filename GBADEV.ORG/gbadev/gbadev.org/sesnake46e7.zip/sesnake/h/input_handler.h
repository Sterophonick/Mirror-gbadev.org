/*
Class that handle the input information
Code with comments           26
Code without comments        15
Total rows                   32
*/

#ifndef INPUT_HANDLER
#define INPUT_HANDLER

enum button{NO_BUTTON = 0, KEY_A = 1, KEY_B = 2, KEY_SELECT = 4, KEY_START = 8, KEY_RIGHT = 16, KEY_LEFT = 32, KEY_UP = 64, KEY_DOWN = 128, KEY_R = 256, KEY_L = 512};

class input_handler
{
	public:
		input_handler();
		bool is_pressed(button key_pressed); //True if the button passed as input is pressed, false otherwise
		void update(); //Update the input status
		bool alldirreleased(); //True if all direction keys are released, false otherwise
	private:
		volatile int* keys;

		//Contains info about a button. True if it's pressed, false otherwise. They are updated by function update()
		bool a_pressed, b_pressed, start_pressed, select_pressed, l_pressed, r_pressed, up_pressed,\
		down_pressed, left_pressed, right_pressed;

		//Contains info about a button. True if it was pressed at the precedent call to update(), false otherwise. They are updated by function update()
		bool a_wpressed, b_wpressed, start_wpressed, select_wpressed, l_wpressed, r_wpressed,\
		up_wpressed, down_wpressed, left_wpressed, right_wpressed;
};

#endif
