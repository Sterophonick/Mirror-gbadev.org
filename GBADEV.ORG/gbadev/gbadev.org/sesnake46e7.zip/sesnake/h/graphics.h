//Handle the graphics of the game
//Implements bg_handler class
//Code with comments           25
//Code without comments        17
//Total rows                   30

#ifndef GRAPHICS_H
#define GRAPHICS_H

#include "main.h"
#include "sprites.h"
#include "snake_play_data.h"
#include "bg_handler.h"

class graphics{
	public:
		graphics();
		void update(snake_play_data& data);
	private:
		//Sprite handler. Used to display all the snake pieces
		sprite_handler sprite_man;
		//Background handler. Used to display background
		bg_handler bgh;

		//FUNCTIONS
		void update_menu(snake_play_data& data);
		void update_game(snake_play_data& data);
};

#endif
