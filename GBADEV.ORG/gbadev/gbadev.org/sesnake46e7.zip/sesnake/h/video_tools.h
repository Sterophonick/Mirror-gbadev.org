/*
Contains all the struct and definition on graphic not present in other header files
Code with comments           37
Code without comments        26
Total rows                   47
*/

#ifndef VIDEO_TOOLS
#define VIDEO_TOOLS

#include "gba.h"

//define the screen width and height values to be used
#define SCREEN_WIDTH	240
#define SCREEN_HEIGHT   160

//colour convertion (converts a RGB colour to a 15-bit BGR value used by the GBA)
#define RGB16_BGR(r, g, b) ((r)+(g<<5)+(b<<10))


//attribute0 #defines
#define ROTATION_FLAG		0x100
#define SIZE_DOUBLE			0x200
#define MODE_NORMAL			0x0
#define MODE_TRANSPARENT	0x400
#define MODE_WINDOWED		0x800
#define MOSAIC				0x1000
#define COLOR_16			0x0000
#define COLOR_256			0x2000
#define SQUARE				0x0
#define TALL				0x4000
#define WIDE				0x8000

//attribute1 #defines
#define ROTDATA(n)			((n)<<9)
#define HORIZONTAL_FLIP		0x1000
#define VERTICAL_FLIP		0x2000
#define SIZE_8				0x0
#define SIZE_16				0x4000
#define SIZE_32				0x8000
#define SIZE_64				0xC000

//atrribute2 #defines
#define PRIORITY(n)	        ((n)<<10)
#define PALETTE(n)			((n)<<12)

#endif
