/*
Class that handle all the data about the snake and its drawing
Code with comments            94
Code without comments         40
Total rows                   126
*/

#ifndef SNAKE_PLAY_DATA
#define SNAKE_PLAY_DATA

#include "gba.h"
#include "input_handler.h"
#include "main.h"


//DATA TYPE DEFINITION

//the direction of the piece (it needs to decide if rotate or not the piece)
enum direction{DIR_UP, DIR_DOWN, DIR_LEFT, DIR_RIGHT, NO_DIR};

//The type of the piece
enum bodypart{S_HEAD_UP = 0, S_HEAD_DOWN = 2, S_HEAD_RIGHT = 4, S_HEAD_LEFT = 6,
		S_BODY_UP = 8, S_BODY_DOWN = 10, S_BODY_RIGHT = 12, S_BODY_LEFT = 14,
		S_TAIL_UP = 16, S_TAIL_DOWN = 18, S_TAIL_RIGHT = 20, S_TAIL_LEFT = 22};


//data that describe a piece of the snake
typedef struct tpiece{
		int x, y; //Position of the pieces (x must be between 16-216, y between 24-136)
		direction dir; //Needed both to decide how increment x and y and for displaying it
		int waitpos; //While it's >0 this piece must stop
		int vec_pos; //position returned from add_sprite_attr (-1 if uninitialized)
		bodypart part; //the type of the piece
		tpiece *next; //Pointer at the next piece (NULL if it's the last)
		tpiece *prec; //Pointer at the precedent piece (NULL if it's the first)
	}piece;


class snake_play_data
{
	public:
		snake_play_data();
		~snake_play_data();

		//Free all memory occupied
		void destroy(void);

		/*
		Update the position of the snake or the status of the game
		*/
		void update(input_handler& input);

		/*
		Return all the info about the snake pieces
		*/
		piece* getsnakeinfo(){return snake;}

		/*
		Return the speed of the snake
		*/
		int getspeed(){return speed;}

		/*
		Memorize the insect info on the variabiles passed
		*/
		void getinsinfo(int *x, int *y, int *t, int *v){(*x) = ins_x; (*y) = ins_y; (*t) = ins_type; (*v) = ins_vec_pos;}

		//Set the position of the insect
		void setinsvecpos(int pos){ins_vec_pos = pos;}

		//Return the point amount
		int getpoint(){return point;}

	private:
		enum cell_status{FREE, SNAKE, INSECT};

		cell_status camp[26][15];

		//the speed of the snake (between 1-3)
		int speed;

		//the number of point
		int point;

		//A list containing all the pieces the snake is composed
		piece *snake;
		piece *lastp;

		/*
		Insect data:
			ins_x          x position
			ins_y          y position
			ins_type       type (0 or 1)
			ins_vec_pos    position into OAM (-1 if no position is set)
		*/
		int ins_x, ins_y, ins_type, ins_vec_pos;

		//PRIVATE FUNCTIONS

		//Update the position of all snake's pieces
		void updatepos_pos(input_handler& input);

		//Control if there's direction change
		void updatepos_dir_change(input_handler& input);

		//Control if the snake collide with itself or insect
		//Return 0 if no collision, 2 if it collide with itself
		int updatepos_collision(input_handler& input);

		//Initialize all the piece's data
		void init_snake();

		/*
		Update the position of the snake. Return 0 on an ok process, 1 if the snake eat an insect and
		2 if it died (against itself or the edges)
		*/
		int updatepos(input_handler& input);

		//Create a new insect
		void newins();

		//Add a piece at the snake (used when an insect is eaten)
		void addpiece();
};

#endif
