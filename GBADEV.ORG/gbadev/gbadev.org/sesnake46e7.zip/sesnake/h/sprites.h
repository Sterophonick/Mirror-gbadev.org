/*
Class that handle the sprite's memory (OAM, OAMData and OBJPaletteMem)
OAM = Object Attribute Memory
Code with comments            87
Code without comments         33
Total rows                   104
*/

#ifndef BERNA_SPRITES_H
#define BERNA_SPRITES_H

#include "gba.h"
#include "video_tools.h"

class sprite_handler
{
	public:
		//256 colors are used
		sprite_handler():n_of_color(256){clear();}
		//color_number colors are used (must be equal to 16 or 256)
		sprite_handler(int color_number):n_of_color(color_number){clear();}
		~sprite_handler(){}

		//Clear all the sprite_handler data
		void clear();

		/*
		Load the palette into memory.
		Return the number of the palette if it's a 16-color palette, otherwise 0.
		palette      the palette to copy in memory
		n_of_color   the number of color of the palette (must be equal to 16 or 256)
		*/
		int add_sprite_palette(const u16 palette[], int n_of_color);

		/*
		Add the image data of a sprite into OAMData. Return the position into OAMData or -1 on error.
		data       the vector that contains image data
		sprite_w   the width of the sprite (must be equal to 8, 16, 32 or 64)
		sprite_h   the height of the sprite (must be equal to 8, 16, 32 or 64)
		*/
		int add_sprite_data(const u16 data[], int sprite_w, int sprite_h);

		/*
		Add a sprite in OAM and return the index into the vector. Return -1 on coordinate error,
		-2 on other type of error.
		(the index must be used to refer at the sprite's attribute)
		x_coord           X coordinate of the sprite (must be a number between 0-512)
		y_coord           Y coordinate of the sprite (must be a number between 0-255)
		enable_rotation   true if the sprite must accept rotation and/or scaling parameters
		double_size       true to enable the drawing of sprite bigger than usual
		sprite_w          the width of the sprite (must be equal to 8, 16, 32 or 64)
		sprite_h          the height of the sprite (must be equal to 8, 16, 32 or 64)
		char_number       the location of the sprite's data (the value returned by add_sprite_data)
		priority          the priority of the sprite (on the z axis) (must be a value between 0-3)
		palette_number    the palette number (ignored if the number of color is 256)(the value returned by add_sprite_palette)
		*/
		int add_sprite_attr(int x_coord, int y_coord, bool enable_rotation, bool double_size, int sprite_w, int sprite_h, int char_number, int priority, int palette_number);


		/*
		Change the attributes of a sprite.index is position into the vector. All the other parameters are equivalent of those used in
		add_sprite_attr
		*/
		void ch_attr(int index, int x_coord, int y_coord, bool enable_rotation, bool double_size, int sprite_w, int sprite_h, int char_number, int priority, int palette_number);


		/*
		Copy oam_mem (the shadow OAM) into OAM
		*/
		void copy2OAM();

		/*
		Update the position of a sprite.
		sprite_id         the index of the sprite (0-127)
		new_x             the new x position
		new_y             the new y position
		*/
		void updatepos(int sprite_id, int new_x, int new_y);

	private:

		//sprite structure definitions
		typedef struct tagOAMEntry
		{
			u16 attribute0;
			u16 attribute1;
			u16 attribute2;
			u16 attribute3;
		}OAMEntry, *pOAMEntry;


		//Shadow OAM
		OAMEntry oam_mem[128];
		//Number of oam_mem entry used
		int used;
		//Number of color the sprite system use (must be equal to 16 or 256)
		int n_of_color;
		//Contains the state of OAMData 8x8 cells (256 colors so 1024/2 = 512)
		u8 oamdata_status[512];
		//Number of oamdata_status entry used
		int data_used;
};

#endif
