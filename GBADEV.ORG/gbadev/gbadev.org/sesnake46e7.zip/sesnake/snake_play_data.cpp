//Implements snake_play_data class
//Code with comments           402
//Code without comments        350
//Total rows                   546
#include <stdlib.h>

#include "h/snake_play_data.h"

#define START_POS_X 96
#define START_POS_Y 80

#define INIT_PIECES 5

snake_play_data::snake_play_data()
{
	init_snake();

	speed = 1;

	point = 0;

	//Initialize insect
	newins();

	ins_vec_pos = -1;

	//activate a Time Control Register to obtain a seed for rand()
	(REG_TM0CNT) =  0x0080; // ==> 0000-0000-1000-0000
}


void
snake_play_data::init_snake()
{
	int i = 1;

	snake = new(piece);

	snake->x = START_POS_X;
	snake->y = START_POS_Y;
	snake->dir = DIR_RIGHT;
	snake->waitpos = 0;
	snake->part = S_HEAD_RIGHT;
	snake->prec = NULL;
	snake->vec_pos = -1;

	lastp = snake;
	piece *tmp2;

	while(i < INIT_PIECES)
	{
		tmp2 = new(piece);

		tmp2->x = lastp->x - 8;
		tmp2->y = lastp->y;
		tmp2->dir = DIR_RIGHT;
		tmp2->waitpos = 0;

		if((i + 1) != INIT_PIECES)
			tmp2->part = S_BODY_RIGHT;
		else
			tmp2->part = S_TAIL_RIGHT;

		tmp2->vec_pos = -1;
		tmp2->prec = lastp;

		lastp->next = tmp2;

		lastp = tmp2;

		i++;
	}

	lastp->next = NULL;

	//Give at rand a seed to start
	srand((unsigned int) REG_TM0D);
}

//I free all the memory taken for the snake structure
snake_play_data::~snake_play_data(void)
{
	destroy();
}


void
snake_play_data::destroy(void)
{
	piece *tmp;

	while(snake != NULL)
	{
		tmp = snake;

		snake = snake->next;

		delete(tmp);
	}

	snake = lastp = NULL;
}


/*
Update the position of the snake or the status of the game
*/
void
snake_play_data::update(input_handler& input)
{
	if((game_status == MENU_START) || (game_status == MENU_SPEED))
	{
		//If the down/up key is pressed the hand and the status must be changed
		if((input.is_pressed(KEY_DOWN)) || (input.is_pressed(KEY_UP)))
		{
			//From MENU_START we goes to MENU_SPEED
			if(game_status == MENU_START)
				game_status = MENU_SPEED;
			//From MENU_SPEED we goes to MENU_START
			else
				game_status = MENU_START;
		}
		//If the left/right key is pressed and the hand is on SPEED then it must be changed
		else if(((input.is_pressed(KEY_LEFT)) || (input.is_pressed(KEY_RIGHT)))
			   && (game_status == MENU_SPEED))
		{
			//If left decrease the speed or wrap around it at the max
			if(input.is_pressed(KEY_LEFT))
			{
				if(speed == 1)
					speed = 2;
				else
					speed = 1;
			}
			//If right increase the speed or wrap around it at the min
			else
			{
				if(speed == 2)
					speed = 1;
				else
					speed = 2;
			}
		}
		//If the START, A or B button is pressed on START then the game must be started
		else if(((input.is_pressed(KEY_START)) || (input.is_pressed(KEY_A)) || (input.is_pressed(KEY_B)))
		&& (game_status == MENU_START) && (input.alldirreleased()))
		{
			game_status = GAME_PLAY;

			init_snake();

			point = 0;

			//Initialize insect
			newins();

			ins_vec_pos = -1;
		}

	}
	//otherwise we are during the game
	else if (game_status == GAME_OVER)
	{
		//if a A, B, START or SELECT is pressed then return to MENU_START
		if((input.is_pressed(KEY_A)) || (input.is_pressed(KEY_B)) || (input.is_pressed(KEY_START))
			|| (input.is_pressed(KEY_SELECT)))
		{
			speed = 1;

			destroy();

			game_status = MENU_START;
		}
	}
	else if(game_status == GAME_PLAY)
	{
		//If START is pressed the game goes in pause
		if(input.is_pressed(KEY_START))
		{
			game_status = GAME_PAUSE;
			return;
		}

		int result = updatepos(input);

		if(result == 2)
			game_status = GAME_OVER;
		//if an unsect was eaten then increase point, create a new insect and increase lenght of the snake
		else if(result == 1)
		{
			point += speed;

			//If all 128 OAM position are occupied, avoid to add another piece
			if((point / speed) < 120)
				addpiece();

			newins();
		}
	}
	else if(game_status == GAME_PAUSE)
	{
		if(input.is_pressed(KEY_START))
			game_status = GAME_PLAY;
	}
}


/*
Update the position of the snake. Return 0 on an ok process, 1 if the snake eat an insect and
2 if it died (against itself or the edges)
*/
int
snake_play_data::updatepos(input_handler& input)
{
	//Update the position of all snake's pieces
	updatepos_pos(input);

	//x must be between 16-216, y between 24-136)
	if((snake->x < 16) || (snake->x > 216) || (snake->y < 24) || (snake->y > 136))
		return 2;

	//Control if there's direction change
	updatepos_dir_change(input);

	//Control if the snake collide with itself or insect
	return updatepos_collision(input);
}


//Update the position of all snake's pieces
void
snake_play_data::updatepos_pos(input_handler& input)
{
	piece *tmp = lastp;
	direction nextdir;
	int next_x, next_y;

	while(tmp != NULL)
	{
		if(tmp->prec != NULL)
		{
			nextdir = tmp->prec->dir;
			next_x = tmp->prec->x;
			next_y = tmp->prec->y;
		}

		if(tmp->waitpos == 0)
		{
			switch(tmp->dir)
			{
					case DIR_UP:
						tmp->y -= speed;
						break;
					case DIR_DOWN:
						tmp->y += speed;
						break;
					case DIR_LEFT:
						tmp->x -= speed;
						break;
					case DIR_RIGHT:
						tmp->x += speed;
						break;
			}


			if((tmp->prec != NULL) && (tmp->dir != nextdir))
			{
				//direction RIGHT
				if((tmp->dir == DIR_RIGHT) && (nextdir == DIR_UP) && (tmp->x == next_x))
				{
					tmp->dir = DIR_UP;

					if(tmp->part == S_BODY_RIGHT)
						tmp->part = S_BODY_UP;
					else
						tmp->part = S_TAIL_UP;
				}

				if((tmp->dir == DIR_RIGHT) && (nextdir == DIR_DOWN) && (tmp->x == next_x))
				{
					tmp->dir = DIR_DOWN;

					if(tmp->part == S_BODY_RIGHT)
						tmp->part = S_BODY_DOWN;
					else
						tmp->part = S_TAIL_DOWN;
				}

				//direction UP
				if((tmp->dir == DIR_UP) && (nextdir == DIR_LEFT) && (tmp->y == next_y))
				{
					tmp->dir = DIR_LEFT;

					if(tmp->part == S_BODY_UP)
						tmp->part = S_BODY_LEFT;
					else
						tmp->part = S_TAIL_LEFT;
				}

				if((tmp->dir == DIR_UP) && (nextdir == DIR_RIGHT) && (tmp->y == next_y))
				{
					tmp->dir = DIR_RIGHT;

					if(tmp->part == S_BODY_UP)
						tmp->part = S_BODY_RIGHT;
					else
						tmp->part = S_TAIL_RIGHT;
				}

				//direction DOWN
				if((tmp->dir == DIR_DOWN) && (nextdir == DIR_LEFT) && (tmp->y == next_y))
				{
					tmp->dir = DIR_LEFT;

					if(tmp->part == S_BODY_DOWN)
						tmp->part = S_BODY_LEFT;
					else
						tmp->part = S_TAIL_LEFT;
				}

				if((tmp->dir == DIR_DOWN) && (nextdir == DIR_RIGHT) && (tmp->y == next_y))
				{
					tmp->dir = DIR_RIGHT;

					if(tmp->part == S_BODY_DOWN)
						tmp->part = S_BODY_RIGHT;
					else
						tmp->part = S_TAIL_RIGHT;
				}

				//direction LEFT
				if((tmp->dir == DIR_LEFT) && (nextdir == DIR_UP) && (tmp->x == next_x))
				{
					tmp->dir = DIR_UP;

					if(tmp->part == S_BODY_LEFT)
						tmp->part = S_BODY_UP;
					else
						tmp->part = S_TAIL_UP;
				}

				if((tmp->dir == DIR_LEFT) && (nextdir == DIR_DOWN) && (tmp->x == next_x))
				{
					tmp->dir = DIR_DOWN;

					if(tmp->part == S_BODY_LEFT)
						tmp->part = S_BODY_DOWN;
					else
						tmp->part = S_TAIL_DOWN;
				}

			}
		}
		else
			tmp->waitpos -= speed;


		tmp = tmp->prec;
	}
}


//Control if there's direction change
void
snake_play_data::updatepos_dir_change(input_handler& input)
{
	static direction pendent_dir = NO_DIR;

	if(pendent_dir == NO_DIR)
	{
		//Change pendent_dir if a button is pressed
		if((input.is_pressed(KEY_UP)) && ((snake->dir == DIR_LEFT) || (snake->dir == DIR_RIGHT)))
		{
			pendent_dir = DIR_UP;
		}
		else if((input.is_pressed(KEY_DOWN)) && ((snake->dir == DIR_LEFT) || (snake->dir == DIR_RIGHT)))
		{
			pendent_dir = DIR_DOWN;
		}
		else if((input.is_pressed(KEY_LEFT)) && ((snake->dir == DIR_UP) || (snake->dir == DIR_DOWN)))
		{
			pendent_dir = DIR_LEFT;
		}
		else if((input.is_pressed(KEY_RIGHT)) && ((snake->dir == DIR_UP) || (snake->dir == DIR_DOWN)))
		{
			pendent_dir = DIR_RIGHT;
		}
	}


	//Actuate pendent_dir if the snake is in a position correct
	if((pendent_dir == DIR_UP) && ((snake->x % 8) == 0))
	{
		snake->dir = DIR_UP;
		snake->part = S_HEAD_UP;
		pendent_dir = NO_DIR;
	}
	else if((pendent_dir == DIR_DOWN) && ((snake->x % 8) == 0))
	{
		snake->dir = DIR_DOWN;
		snake->part = S_HEAD_DOWN;
		pendent_dir = NO_DIR;
	}
	else if((pendent_dir == DIR_LEFT) && ((snake->y % 8) == 0))
	{
		snake->dir = DIR_LEFT;
		snake->part = S_HEAD_LEFT;
		pendent_dir = NO_DIR;
	}
	else if((pendent_dir == DIR_RIGHT) && ((snake->y % 8) == 0))
	{
		snake->dir = DIR_RIGHT;
		snake->part = S_HEAD_RIGHT;
		pendent_dir = NO_DIR;
	}
}


//Control if the snake collide with itself or insect
//Return 0 if no collision, 2 if it collide with itself
int
snake_play_data::updatepos_collision(input_handler& input)
{
	//Coordinates of the head piece
	int x1 = snake->x,
	x2 = snake->x + 8,
	y1 = snake->y,
	y2 = snake->y + 8;

	piece* tmp = snake->next->next->next;

	while(tmp != NULL)
	{
		if((x1 > tmp->x) && (x1 < (tmp->x + 8)) && (y1 > tmp->y) && (y1 < (tmp->y + 8)))
			return 2;

		if((x1 > tmp->x) && (x1 < (tmp->x + 8)) && (y2 > tmp->y) && (y2 < (tmp->y + 8)))
			return 2;

		if((x2 > tmp->x) && (x2 < (tmp->x + 8)) && (y1 > tmp->y) && (y1 < (tmp->y + 8)))
			return 2;

		if((x2 > tmp->x) && (x2 < (tmp->x + 8)) && (y2 > tmp->y) && (y2 < (tmp->y + 8)))
			return 2;

		//Insect collide
		if((x1 == (ins_x + 4)) && (y1 == ins_y))
			return 1;

		if((x2 == (ins_x + 4)) && (y1 == ins_y))
			return 1;

		if((y1 == (ins_y + 4)) && (x1 == ins_x))
			return 1;

		if((y2 == (ins_y + 4)) && (x1 == ins_x))
			return 1;

		tmp = tmp->next;
	}

	return 0;
}


void
snake_play_data::newins()
{
	int i, k;

	//Init camp matrix
	for(i = 0; i < 26; i++)
		for(k = 0; k < 15; k++)
			camp[i][k] = FREE;

	piece *tmp = snake;

	while(tmp != NULL)
	{
		camp[(tmp->x / 8) - 2][(tmp->y / 8) - 3] = SNAKE;

		tmp = tmp->next;
	}

	int count = 0;

	//Init camp matrix
	for(i = 0; i < 26; i++)
		for(k = 0; k < 15; k++)
			if(camp[i][k] == FREE)
				count++;

	count = (rand() % count) + 1;
	i = k = 0;

	while(count != 0)
	{
		if(camp[i][k] == FREE)
			count--;

		if(count != 0)
		{
			k++;

			if(k == 15)
			{
				k = 0;
				i++;
			}
		}
	}


	ins_x = (i * 8) + 16;
	ins_y = (k * 8) + 24;

	ins_type = (ins_type == 0) ? (1) : (0);
}


void
snake_play_data::addpiece()
{
	//Piece after which attach the new one
	piece *tmp = lastp->prec;

	//The new piece
	piece *newp = new piece;

	//The new one has same position, dir and apparence but waitpos = 8 to stop for a while
	newp->x = tmp->x;
	newp->y = tmp->y;
	newp->dir = tmp->dir;
	newp->waitpos = 8;
	newp->vec_pos = -1;
	newp->part = tmp->part;

	//Attach it to the list
	newp->prec = tmp;
	newp->next = lastp;
	tmp->next = newp;
	lastp->prec = newp;

	//The last piece itself must the wait
	lastp->waitpos = 8;
}
