@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
@                       FUERZA AEREA                                @
@                                                                   @
@                 - Date    :  18-05-2003                           @
@                 - Version :  1.0                                  @
@                 - Autor   :  mononoque                            @
@                                                                   @
@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@

---------------------------------------------------------------------
   Gameplay:
     D-pad        - Move ship
     A button     - Shoot
     B button     - Bomb
     START button - Pause
---------------------------------------------------------------------
   Powerups:
     P - Power
     B - Bomb
---------------------------------------------------------------------
   Web:
     www.geocities.com/mononoque2k3
---------------------------------------------------------------------
   E-mail:
     mononoque77@hotmail.com
---------------------------------------------------------------------
   Thanks to:
     Jeff Frohwein   : for MultiBoot, crt0, lnkscript, FAQ, b2x (v1.7)
     Forgotten       : for VisualBoyAdvance
     Tom Happ        : for Cowbite spec
     Staringmonkey   : for pixel and sound examples
     Dark Fader	     : for sound examples
     gbadev.org	     : for various info
---------------------------------------------------------------------
