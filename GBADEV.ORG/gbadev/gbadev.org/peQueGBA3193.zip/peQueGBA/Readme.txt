;=======================================================================
; peQue.asm
; (c) 2004 Clivefb AT hotmail DOT com
;
; 3D Flat Cube, 1 color per face,
; 12bits+ Sin/Cos resolution, 1024 entry array and 2 rotations angles (2,1,1)
; in 560 bytes (Thumb + Arm code) (400 bytes without the Nintendo logo data)
;
; assembled with ARM2.50 SDK
; needs a GBA bios file to be executed on an emulator
;=======================================================================

Background
This program comes from a competition we launched with 3 other programmers of the video game company I am working for.

Basically, the rules were the following:
have a rotating 3D cube with the minimum exe size. We started the competition with C sources compiled in thumb code. But rapidly, people moved to full assembly thumb code (and a little bit of ARM code for sin/cos tables generation). Thumb code is interesting for code size because each opcode is 16bits (compared to ARM opcodes of 32 bits length) and there are still interesting opcodes.
Please note, that the rules stated that the sin/cos table should have 1024 entries with at least 12 bits precision (for those who think: "why the hell didn't they use the bios builtin sincos functions ??").

I know that it's still possible to make a more shrinked version (I didn't won the prize :() but I think I spent enough time on this stupid competition :)
However, without the Nintendo logo at the start of the file which can't be skipped since the Bios checks its byte by byte before jumping to the beginning of the user code (and some more misc datas), the real code sizes 400 bytes.
The code could run really faster if moving and executing it to/from WRAM, but speed was not an issue for the competition ;)
The edge filling algorithm could be improved in size with some test of every pixel in the frame buffer being inside the face or not, but this really kills a lot more the drawing time !!

I hope this program will be usefull to those who start coding in asm on the GBA and want to mix thumb and Arm code.
Notice that the program should work on a real GBA with a flashable cartridge (it won't work using a // cable).

If you have comments or questions, fell free to email me.

Tested with VisualBoyAdvance v1.7.1 and MappyVM v0.9 build 1808, release 3