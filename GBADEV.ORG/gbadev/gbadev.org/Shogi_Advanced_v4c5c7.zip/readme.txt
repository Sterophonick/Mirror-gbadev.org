//------------------------------------------------------------------------------------------
//Shogi Advanced Version: 1
//By: Daniel Fowler
//email: daniel@fowlers.net
//
//This product is meant for free distribution for the enjoyment and feedback of fellow game
//developers.  If you have any Questions, comments or suggestions please email me.
//------------------------------------------------------------------------------------------

I am releasing this version in order to receive feedback from the internet community. It is
not a finished product.

Keys:
Arrows:	used to move the cursors around the screen in order to select and move pieces.
A: 	Used to select.
B: 	Used to cancel actions (not undo) and bring you back to the default board and 
	selection cursor.
START:	used to reset/save/load the shogi game.

If you do not know how to play shogi, I have provided a brief guide in shogi_guid.txt

Known Bugs:
1.	An artifact appears in the top left of the screen when played using the Visual Boy 
	Advanced Emulator.
2.	When played on a Game Boy SP the blue movement cursor seems to become unaligned with
	the other graphics when it moves to the right.  The actual X and Y values seem to be
	correct but the sprite seems slightly out of place.
4.	This is a two player game but does not currently support any sort of wired or 
	wireless multiplayer hardware.  Simply pass the Game Boy or keyboard to a friend 
	after your move.
5.	There is absolutely no sound.  I want to add a "clack" sound later when I figure out 
	how to use the Game boy's sound hardware.

I am a new to the world of game development and hope to fix all of these issues in time.  
Don't hold your breath however because I am also a student and have other worries.  If you 
can offer any advice that would help me fix these issues or find problems I didn't cover, 
you are welcomed to email me.

One thing that I don�t expect to add anytime soon is an AI opponent.  Sorry but that may be 
beyond me.

  