ThingPONG

Copyright (c) 2004-2005 Scott Lininger

This is a little PONG game that uses multiboot and SIO code 
for play via the linkcable. You can learn more at 
www.thingker.com.

You can email me at scott[zat]scottlininger[doot]com