#ifndef _GBADEFS_H_
#define _GBADEFS_H_

typedef unsigned char u8;
typedef unsigned short u16;
typedef unsigned long u32;

typedef signed char s8;
typedef signed short s16;
typedef signed long s32;

typedef unsigned char byte;
typedef unsigned short hword;
typedef unsigned long word;

#endif /* _GBADEFS_H_ */
