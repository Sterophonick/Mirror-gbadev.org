/*
Copyright (c) 2004 Alberto Demichelis

This software is provided 'as-is', without any 
express or implied warranty. In no event will the 
authors be held liable for any damages arising from 
the use of this software.

Permission is granted to anyone to use this software 
for any purpose, including commercial applications, 
and to alter it and redistribute it freely, subject 
to the following restrictions:

		1. The origin of this software must not be 
		misrepresented; you must not claim that 
		you wrote the original software. If you 
		use this software in a product, an 
		acknowledgment in the product 
		documentation would be appreciated but is 
		not required.

		2. Altered source versions must be plainly 
		marked as such, and must not be 
		misrepresented as being the original 
		software.

		3. This notice may not be removed or 
		altered from any source distribution.

*/
#include <string.h>
#include "gbadefs.h"
#include "xfs.h"

#define NODE_TYPE_DIR	0xD1
#define NODE_TYPE_FILE	0xF1

typedef struct {
	u16 type;
	u32 nodesize;
	u32 payloadsize;
	char name[30];
}FSNode;

static int TraversePath(FSNode* node,const char *path,GBA_File *out)
{
	u32 i, idx;
	char temp[33];
	u8 *base;
	i = 0;
	while(path[i] != '\0' && path[i]!='/') {
		temp[i]=path[i];
		i++;
	}
	temp[i]='\0';
	base = (u8*)(node+1);
	idx = 0;
	while(idx < node->nodesize)
	{
		FSNode *child = (FSNode *)&base[idx];
		if(path[i] == '/') {
			if(child->type == NODE_TYPE_DIR && (strcmp(temp,child->name) == 0))	{
				return TraversePath(child,&path[i+1],out);
			}
		}
		else {
			if(child->type == NODE_TYPE_FILE && (strcmp(temp,child->name) == 0)) {
				out->data = (child+1);
				out->size = child->payloadsize;
				return 1;
			}
		}
		idx += child->nodesize + sizeof(FSNode);
	}
	return 0; 

}

int GBA_GetFile(void* fs, const char *path,GBA_File *out)
{
	return TraversePath((FSNode*)fs,&path[ (path[0]=='/')?1:0 ],out);
}
