Brotzeit 1.0
============

-- exoticorn/farbrausch (exoticorn@epost.de) --

After a long absent from gba coding, I am (reasonably) proud to
present "Brotzeit", a tiny, fast mandelbrot & julia viewer.
It is written in 100% ARM assembler and should work both as a
regular rom and a multiboot image.

The controls are as follows:

D-Pad     : Move the zoom window
A Button  : Zoom in
B Button  : Zoom out
Start     : Reset position and zoom
Select    : Toggle between Mandelbrot and Julia mode
R Button  : Show center of zoom window

When switching to Julia mode the center of the zoom window is
used as the Julia fixpoint. Choosing one at the borders of the
mandelbrot set gives the most interesting results.

The source to this tiny tool is included, although it uses my
own unreleased assembler. Adapting it to a different assembler
should be easy enough, though, if you really want to.

Copyright (c) 2004 Dennis Ranke

Permission is hereby granted, free of charge, to any person obtaining a copy of
this software and associated documentation files (the "Software"), to deal in
the Software without restriction, including without limitation the rights to
use, copy, modify, merge, publish, distribute, sublicense, and/or sell copies
of the Software, and to permit persons to whom the Software is furnished to do
so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
