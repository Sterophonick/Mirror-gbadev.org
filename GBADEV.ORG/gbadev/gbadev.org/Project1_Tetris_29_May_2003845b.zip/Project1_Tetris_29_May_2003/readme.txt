Author : Choopan Rattanapoka (choopanr@hotmail.com)
Data   : May 29, 2003
Game   : Tetris :)


About me :
==========
	This is my first attempt at making a game for the GBA.Its a tetris clone done in mode 4.
This game is aimed for trying to use graphics mode 4, random function and keyboard controling. 
I hope my source can help someone to start programming in GBA.

About game :
============
	In game :-
		keypad down  : To Move block down.
		Keypad left  : To Move block to the left.
		keypad right : To Move block to the right.
		keypad start : To pause the game.	
		keypad A     : To rotate block by clock wise direction.
		keypad B     : To rotate block by reward clock wise direction.

Enjoy :)
     



