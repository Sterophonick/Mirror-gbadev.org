This is a project I have invested a lot of hours in. It's a Namco's Pacman clone called Pacoman. It features 5 levels of increasing difficult, intelligent ghosts, full 512x512 maze and hi-score saving. It has some bugs though, but they're minor, and it lacks sound because I have not been able to make it :(. But I hope you can enjoy it playing so much like I enjoyed making it.

My webpage is http://cydoniasystems.tripod.com for more information don't hesitate visiting it or emailing me to taiyou_prod@hotmail.com

Thanks :)