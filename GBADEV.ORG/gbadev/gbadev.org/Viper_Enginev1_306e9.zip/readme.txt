//  //  //  //////  //////  //////
// //  //  //  //  //      //  //      
////  //  //////  ////    //////     
///  //  //      //      //  \\      
//  //  //      /////// //   //  

Version 1.3 By: Devin Clarke a.k.a Royale00

Info:
I have optimized filled triangle drawing code(it is in c will porbably try to get it into asm). This engine also supports texture mapping but at this moment its is still very slow(as it uses floating point numbers) but the main focus of this engine now is flat shaded polygons. Dont be surprised if you see a starfox like demo soon!(I know I was suppose to release source code  and I will but I am still unhappy with performance but expect a source code release soon)

Technical:
HiColor 15 bits per pixel (no palettes for textures and images)
CrossFading
Full 3D Engine
Texture Support
Mode 5(only mode 5 support now as I cant get mode 3 page flipping fast enough)
Double Buffering
Bitmap scrolling
Polygon Sorting
ZBuffer(this still needs alot of work)

Compatiblity:
Runs with Mappy(Kinda of slow)
I suggest the following below
Runs with BoyCott Advanced (100%)
Runs with Visual GameBoy Advanced 0.6 (100%)
Runs on Real GBA (100%)

Todo:
-Make some type of model format\editor as cubes are getting boring.
-Make triangle rendering code faster

Thanks:
First and fore most thanks to GBADEV.ORG and DEVRS.COM for the vast
amount of programming information for the Game Boy Advanced platform.Also thanks to *Pete*(Dooby) as I have based my poly sorting code on his cube demo(Z normal determines if face is drawn).Aslo thanks to *Jaap* as I have based my text drawing code from his SoCrates package.Thanks to all of you who provide source code, demos, and documents on
GBA programming. Also thanks to all of you who took the time to read this far. 

Email: Royale00@hotmail.com
