Wolverine 0.1 - 04/23/01

By Azazello
(azazello@itineris.net)

Just left/right moves for the moment.....

This little gba program use some graphics riped
from X-Men Vs Street Fighter (by Capcom), and from KOF 96 (SNK corp).

Greets to all #gbadev people.