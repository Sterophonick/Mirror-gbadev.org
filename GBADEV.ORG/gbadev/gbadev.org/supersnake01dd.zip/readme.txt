April 2001

SuperSnake for the GameBoy Advance - made by Insider of Defect 
insider@andreaswiencke.de

... with help from gfxLib by Jeff Frohwein. Compiles with GCC.
It's my first GBA program and my first program made in C, so dont judge too hard, please.
This Game was originally written in asm for the Amiga (http://www.wi.hs-wismar.de/~wiencke/supersnake.asm), binary 
can be found on the Aminet. Later it was remade in Java as an applett (http://www.wi.hs-wismar.de/~wiencke/supersnake_english.html). 
Inspiratin comes from a very old Robotron-Computer game I was mad about as a child.

This is known to work on iGBA 0.8. Any chance that it runs on hardware?