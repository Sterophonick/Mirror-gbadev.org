// April 2001
//
// SuperSnake for the GameBoy Advance - made by Insider of Defect 
// insider@andreaswiencke.de
//
// ... with help from gfxLib by Jeff Frohwein. Compiles with GCC.
// It's my first GBA program and my first program made in C, so dont judge too hard, please.
//
// This Game was originally written in asm for the Amiga (http://www.wi.hs-wismar.de/~wiencke/supersnake.asm), binary 
// can be found on the Aminet. Later it was remade in Java as an applett (http://www.wi.hs-wismar.de/~wiencke/supersnake_english.html). 
// Inspiratin comes from a very old Robotron-Computer game I was mad about as a child.
//
// This is known to work on iGBA 0.8. Any chance that it runs on hardware?

typedef     unsigned char           u8;
typedef     unsigned short int      u16;
typedef     unsigned int            u32;
typedef     unsigned long long int  u64;
typedef     signed char             s8;
typedef     signed short int        s16;
typedef     signed int              s32;
typedef     signed long long int    s64;

extern void gfxPixel(u8 px, u8 py, u16 colr, u32 addr);
extern void gfxLine(u8 x1, u8 y1, u8 x2, u8 y2, u16 colr, u32 addr);

#define DISPLAY_Y 	*(u32*)0x04000006
#define DISP_LCDC_OFF  0x80
#define DISP_MODE_3    3
#define DISP_MODE_4    4
#define DISP_MODE_5    5
#define DISP_BG2_ON    0x0400
#define REG_BASE    0x4000000
#define REG_DISPCNT (REG_BASE + 0x0)
#define REG_STAT    (REG_BASE + 0x4)
#define RGB(r,g,b) ((((b)>>3)<<10)+(((g)>>3)<<5)+((r)>>3))
#define DMA3SAD		*(u32*)0x040000d4
#define DMA3DAD		*(u32*)0x040000d8
#define DMA3CNT		*(u32*)0x040000dc
#define P1		*(u16*)0x04000130
#define VRAM 		0x6000000
#define J_A		0x0001
#define J_B		0x0002
#define J_SELECT	0x0004
#define J_START		0x0008
#define J_RIGHT		0x0010
#define J_LEFT		0x0020
#define J_UP		0x0040
#define J_DOWN		0x0080
#define J_R		0x0100
#define J_L		0x0200
#define key_reg	(*(u16*)0x04000130)

#define stone 1
#define fruit 2
#define snake 3
#define space 4
#define snakehead 5
#define	false 0
#define true 1
#define boolean int
#define MaxSnakeLength	100
#define crashLevel	25
#define direction	int
#define up	1
#define down	2
#define left	3
#define right	4
#define buttonA	5
#define buttonB 6
#define buttonStart	7
#define buttonSelect	8

#include "levels.c"
#include "subs/jpeg5.c"			// JPEG decompression code
#include "snake.c"			// the title screen
#include "ziegel.c"			// the wall
#include "kirsche.c"			// the cherry

//we wait by wasting time, this is not beautiful
void Wait(int time) {
	
	int i,j;
	int tmp;
	
	for(i=1;i<time;i++) {
		for(j=1;j<time;j++) {
			tmp=i/j;
		}
	}
}

void clearPlayfield() {
	int i;
	for(i=6;i<=155;i++) {
		gfxLine(21,i,219,i,RGB(0,0,0),VRAM);
	}
}

//I know this is very ugly, but is does what it is supposed to, so who cares ?
void drawElement(int x, int y, int what_to_draw) {
	if (what_to_draw==fruit) {			//draw a fruit
		gfxPixel(x+0,y,RGB(0,114,54),VRAM); 
		gfxPixel(x+1,y,RGB(141,198,63),VRAM);
		gfxPixel(x+2,y,RGB(141,198,63),VRAM);		//we pixel our pictures on the screen
		gfxPixel(x+3,y,RGB(0,114,54),VRAM);		//the elements are 4x6 pixel in size ...
		gfxPixel(x+0,y+1,RGB(141,198,63),VRAM);		//... and have been "drawn" in gimp
		gfxPixel(x+1,y+1,RGB(0,114,54),VRAM); 		
		gfxPixel(x+2,y+1,RGB(0,114,54),VRAM); 
		gfxPixel(x+3,y+1,RGB(141,198,63),VRAM);
		gfxPixel(x+0,y+2,RGB(0,0,0),VRAM);
		gfxPixel(x+1,y+2,RGB(255,0,0),VRAM);
		gfxPixel(x+2,y+2,RGB(255,0,0),VRAM);
		gfxPixel(x+3,y+2,RGB(0,0,0),VRAM);
		gfxPixel(x+0,y+3,RGB(255,0,0),VRAM);
		gfxPixel(x+1,y+3,RGB(242,101,34),VRAM);
		gfxPixel(x+2,y+3,RGB(242,101,34),VRAM);
		gfxPixel(x+3,y+3,RGB(255,0,0),VRAM);
		gfxPixel(x+0,y+4,RGB(255,0,0),VRAM);
		gfxPixel(x+1,y+4,RGB(242,101,34),VRAM);
		gfxPixel(x+2,y+4,RGB(242,101,34),VRAM);
		gfxPixel(x+3,y+4,RGB(255,0,0),VRAM);
		gfxPixel(x+0,y+5,RGB(0,0,0),VRAM);
		gfxPixel(x+1,y+5,RGB(255,0,0),VRAM);
		gfxPixel(x+2,y+5,RGB(255,0,0),VRAM);
		gfxPixel(x+3,y+5,RGB(0,0,0),VRAM);
	}
	
	if (what_to_draw==snake) {				//draw the snakes body
		gfxPixel(x+0,y,RGB(0,0,0),VRAM); 
		gfxPixel(x+1,y,RGB(0,174,239),VRAM);
		gfxPixel(x+2,y,RGB(0,174,239),VRAM);
		gfxPixel(x+3,y,RGB(0,0,0),VRAM);
		gfxPixel(x+0,y+1,RGB(0,174,239),VRAM); 
		gfxPixel(x+1,y+1,RGB(68,140,203),VRAM);
		gfxPixel(x+2,y+1,RGB(68,140,203),VRAM);
		gfxPixel(x+3,y+1,RGB(0,174,239),VRAM);
		gfxPixel(x+0,y+2,RGB(68,140,203),VRAM); 
		gfxPixel(x+1,y+2,RGB(68,140,203),VRAM);
		gfxPixel(x+2,y+2,RGB(68,140,203),VRAM);
		gfxPixel(x+3,y+2,RGB(68,140,203),VRAM);
		gfxPixel(x+0,y+3,RGB(68,140,203),VRAM); 
		gfxPixel(x+1,y+3,RGB(68,140,203),VRAM);
		gfxPixel(x+2,y+3,RGB(68,140,203),VRAM);
		gfxPixel(x+3,y+3,RGB(68,140,203),VRAM);
		gfxPixel(x+0,y+4,RGB(0,174,239),VRAM); 
		gfxPixel(x+1,y+4,RGB(68,140,203),VRAM);
		gfxPixel(x+2,y+4,RGB(68,140,203),VRAM);
		gfxPixel(x+3,y+4,RGB(0,174,239),VRAM);
		gfxPixel(x+0,y+5,RGB(0,0,0),VRAM); 
		gfxPixel(x+1,y+5,RGB(0,174,239),VRAM);
		gfxPixel(x+2,y+5,RGB(0,174,239),VRAM);
		gfxPixel(x+3,y+5,RGB(0,0,0),VRAM);
	}
	
	if (what_to_draw==snakehead) {				//draw the snakes head
		gfxPixel(x+0,y,RGB(0,0,0),VRAM); 
		gfxPixel(x+1,y,RGB(0,174,239),VRAM);
		gfxPixel(x+2,y,RGB(0,174,239),VRAM);
		gfxPixel(x+3,y,RGB(0,0,0),VRAM);
		gfxPixel(x+0,y+1,RGB(0,174,239),VRAM); 
		gfxPixel(x+1,y+1,RGB(0,255,255),VRAM);
		gfxPixel(x+2,y+1,RGB(0,255,255),VRAM);
		gfxPixel(x+3,y+1,RGB(0,174,239),VRAM);
		gfxPixel(x+0,y+2,RGB(0,255,255),VRAM); 
		gfxPixel(x+1,y+2,RGB(0,255,255),VRAM);
		gfxPixel(x+2,y+2,RGB(0,255,255),VRAM);
		gfxPixel(x+3,y+2,RGB(0,255,255),VRAM);
		gfxPixel(x+0,y+3,RGB(0,255,255),VRAM); 
		gfxPixel(x+1,y+3,RGB(0,255,255),VRAM);
		gfxPixel(x+2,y+3,RGB(0,255,255),VRAM);
		gfxPixel(x+3,y+3,RGB(0,255,255),VRAM);
		gfxPixel(x+0,y+4,RGB(0,174,239),VRAM); 
		gfxPixel(x+1,y+4,RGB(0,255,255),VRAM);
		gfxPixel(x+2,y+4,RGB(0,255,255),VRAM);
		gfxPixel(x+3,y+4,RGB(0,174,239),VRAM);
		gfxPixel(x+0,y+5,RGB(0,0,0),VRAM); 
		gfxPixel(x+1,y+5,RGB(0,174,239),VRAM);
		gfxPixel(x+2,y+5,RGB(0,174,239),VRAM);
		gfxPixel(x+3,y+5,RGB(0,0,0),VRAM);;
	}
	
	if (what_to_draw==stone) {					//draw a stone
		gfxPixel(x+0,y,RGB(223,223,223),VRAM); 
		gfxPixel(x+1,y,RGB(223,223,223),VRAM);
		gfxPixel(x+2,y,RGB(223,223,223),VRAM);
		gfxPixel(x+3,y,RGB(204,204,204),VRAM);
		gfxPixel(x+0,y+1,RGB(223,223,223),VRAM); 
		gfxPixel(x+1,y+1,RGB(204,202,202),VRAM);
		gfxPixel(x+2,y+1,RGB(204,202,202),VRAM);
		gfxPixel(x+3,y+1,RGB(179,177,177),VRAM);
		gfxPixel(x+0,y+2,RGB(223,223,223),VRAM); 
		gfxPixel(x+1,y+2,RGB(204,202,202),VRAM);
		gfxPixel(x+2,y+2,RGB(204,202,202),VRAM);
		gfxPixel(x+3,y+2,RGB(179,177,177),VRAM);
		gfxPixel(x+0,y+3,RGB(223,223,223),VRAM); 
		gfxPixel(x+1,y+3,RGB(204,202,202),VRAM);
		gfxPixel(x+2,y+3,RGB(204,202,202),VRAM);
		gfxPixel(x+3,y+3,RGB(179,177,177),VRAM);
		gfxPixel(x+0,y+4,RGB(223,223,223),VRAM); 
		gfxPixel(x+1,y+4,RGB(204,202,202),VRAM);
		gfxPixel(x+2,y+4,RGB(204,202,202),VRAM);
		gfxPixel(x+3,y+4,RGB(179,177,177),VRAM);
		gfxPixel(x+0,y+5,RGB(179,177,177),VRAM); 
		gfxPixel(x+1,y+5,RGB(166,164,164),VRAM);
		gfxPixel(x+2,y+5,RGB(166,164,164),VRAM);
		gfxPixel(x+3,y+5,RGB(166,164,164),VRAM);
	}
	
	if (what_to_draw==space) {					//delete element by drawing a space
		gfxPixel(x+0,y,RGB(0,0,0),VRAM); 
		gfxPixel(x+1,y,RGB(0,0,0),VRAM);
		gfxPixel(x+2,y,RGB(0,0,0),VRAM);
		gfxPixel(x+3,y,RGB(0,0,0),VRAM);
		gfxPixel(x+0,y+1,RGB(0,0,0),VRAM); 
		gfxPixel(x+1,y+1,RGB(0,0,0),VRAM);
		gfxPixel(x+2,y+1,RGB(0,0,0),VRAM);
		gfxPixel(x+3,y+1,RGB(0,0,0),VRAM);
		gfxPixel(x+0,y+2,RGB(0,0,0),VRAM); 
		gfxPixel(x+1,y+2,RGB(0,0,0),VRAM);
		gfxPixel(x+2,y+2,RGB(0,0,0),VRAM);
		gfxPixel(x+3,y+2,RGB(0,0,0),VRAM);
		gfxPixel(x+0,y+3,RGB(0,0,0),VRAM); 
		gfxPixel(x+1,y+3,RGB(0,0,0),VRAM);
		gfxPixel(x+2,y+3,RGB(0,0,0),VRAM);
		gfxPixel(x+3,y+3,RGB(0,0,0),VRAM);
		gfxPixel(x+0,y+4,RGB(0,0,0),VRAM); 
		gfxPixel(x+1,y+4,RGB(0,0,0),VRAM);
		gfxPixel(x+2,y+4,RGB(0,0,0),VRAM);
		gfxPixel(x+3,y+4,RGB(0,0,0),VRAM);
		gfxPixel(x+0,y+5,RGB(0,0,0),VRAM); 
		gfxPixel(x+1,y+5,RGB(0,0,0),VRAM);
		gfxPixel(x+2,y+5,RGB(0,0,0),VRAM);
		gfxPixel(x+3,y+5,RGB(0,0,0),VRAM);
	}
}

char* resolveLevel(int number) {

	char* level=level1;
	switch (number) {
		case 1: 	level=level1;	break;
		case 2:		level=level2; 	break;
		case 3:		level=level3; 	break;
		case 4:		level=level4; 	break;
		case 5:		level=level5; 	break;
		case 6:		level=level6; 	break;
		case 7:		level=level7; 	break;
		case 8:		level=level8; 	break;
		case 9:		level=level9; 	break;
		case 10:	level=level10; 	break;
		case 11:	level=level11; 	break;
		case 12:	level=level12; 	break;
		case 13:	level=level13; 	break;
		case 14:	level=level14; 	break;
		case 15:	level=level15; 	break;
		case 16:	level=level16; 	break;
		case 17:	level=level17; 	break;
		case 18:	level=level18; 	break;
		case 19:	level=level19; 	break;
		case 20:	level=level20; 	break;
		case 21:	level=level21; 	break;
		case 22:	level=level22; 	break;
		case 23:	level=level23; 	break;
		case 24:	level=level24; 	break;
		case 25:	level=level25; 	break;
	}

	return level;
}

int drawLevel(int number) {
	
	int i,j;
	int fruits=0;				//the number of fruits there are in the level
	char* level=resolveLevel(number); 	//give us a pointer to the actual Level;
	
	clearPlayfield();			//cleans the middle of the screen
	
	// draw the Level "number" onto the screen
	for(i=0;i<50;i++) {
		for(j=0;j<25;j++) {
			if (level[j*50+i]=='#') drawElement(20+i*4,5+j*6,stone);
			if (level[j*50+i]=='p'){
				drawElement(20+i*4,5+j*6,fruit);
				fruits++;
			}
		}
	}	
	return fruits;
}

void drawSnake(int snakeX[MaxSnakeLength], int snakeY[MaxSnakeLength], int snakeLength) {
	int i;
	for(i=1;i<=snakeLength;i++) {
		if (i==1) drawElement(20+snakeX[i]*4,5+snakeY[i]*6,snakehead); 	//the first elementis the head of the snake
		else drawElement(20+snakeX[i]*4,5+snakeY[i]*6,snake);		//draw the body
	}		
}

u16 getKeys() {					//I took this from the BKG example by Warder1
	direction dir=0;
	u16 button=P1;
	P1 |= 0x03FF;
	if (button) {
		if (!(button & J_LEFT))		dir=up;
		if (!(button & J_RIGHT))	dir=down;
		if (!(button & J_UP))		dir=left;
		if (!(button & J_DOWN))		dir=right;
		if (!(button & J_A))		dir=buttonA;	
		if (!(button & J_B))		dir=buttonB;
		if (!(button & J_START))	dir=buttonStart;
	}
	return dir;
}


void drawWall(){
	(void) gfxJpeg(0,0,&ziegel[0], (u8*)VRAM);		// Draw a JPEG picture to the screen.
}

void drawTitel(){
	(void) gfxJpeg(0,0,&SnakeTitel[0], (u8*)VRAM);	// Draw a JPEG picture to the screen.
}

void AgbMain(void) {

	int i;					//index for loops
	int level=1;				//we start at level 1
	int fruits;				//how many fruits are in the level?
	int snakeX[MaxSnakeLength];		//these two store the coordinates of the ...
	int snakeY[MaxSnakeLength];		//... single elements of the snake
	int snakeLength;			//the actual length of the snake
	int delX=0;				//these are temporary variables
	int delY=0;
	char foundElement;			//holds the contents of the level at the position of the snakes head
	char* actualLevel;			//a pointer to the actual Level
	char copiedLevel[1251];			//this will hold a copy of a level
	int index;				//gives us as element within a level
	direction pad=0;			//the keyboard input
	direction runDirection=0;		//the direction we currently move to			
	boolean crash=false;			//becomes true when we die
	boolean finished=false;			//becomes true when we eat all fruit	
	
	*(u16 *)REG_DISPCNT = DISP_MODE_3 | DISP_LCDC_OFF; // LCDC OFF
	// Setup mode 3 graphics
	*(u16 *)REG_DISPCNT = DISP_MODE_3 | DISP_BG2_ON;
	*(u16 *)REG_STAT = 0;

	drawTitel();			//draw the title screen ...	
	while(pad!=buttonStart) {	//... and wait for the 'start' key to be pressed
		pad=getKeys();
	}
	drawWall();			//and now draw the border onto the screen
	
	while (1) { // we never quit this game, its too good... :-)
		
		pad=0;					//direction the user pressed
		runDirection=0;				//diretion we are going to at the moment
		crash=false;				//snake is alive ...
		finished=false;				//.. and we are not finished, because we did not start yet
		if (level==25) level=1;			//no end animation here ... just a restart ;-)

		fruits=drawLevel(level);		//draw fruits and stones on the screen and count them
		
		// set the initial snake
	    	snakeX[1]=1;snakeY[1]=10;		//remember: snakeX[1] holds the X-Position of snakes Head
	    	snakeX[2]=1;snakeY[2]=11;		//snakeX[snakeLength] represents the Tail
	    	snakeX[3]=1;snakeY[3]=12;
	    	snakeX[4]=1;snakeY[4]=13;
	    	snakeLength=4;				//we did set 4 elements, so the snakes length is 4
		
		//im not happy with that, but we need a workaround here because of buggy level-converting ...
		// .. the snake must be set onto a different position
		if (level==16) {
			snakeY[1]=20;		
	    		snakeY[2]=21;		
	    		snakeY[3]=22;
	    		snakeY[4]=23;
		}
		
		//wait for a keypress then start
		while(pad) {
			pad=getKeys();
		}
		
		actualLevel=resolveLevel(level); 				//give us a pointer to the actual Level
		for (i=0;i<1251;i++) {
				copiedLevel[i]=actualLevel[i];			//and make a copy
		}
		
	 	while(crash==false && finished==false) { //main loop within a level, runs until accident or level is finished
			
			index=snakeX[1]+snakeY[1]*50;				//element at snakes head
			drawSnake(snakeX,snakeY,snakeLength); 			//draw the snake on the screen
			foundElement=copiedLevel[index];			//gets the element (fruit, stone, nothing) at the snakes head	
			
			//did we found something to eat?
			if (foundElement=='p') {				//yes we found "pfruit" ... in the levels fruits are marked as 'p'
				fruits--;					//there is now one fruit less ...
	      			snakeLength++;					//... and the snake grew a bit
				copiedLevel[index]=' '; 			//remove the fruit 
			}
			else {							//nothing was found
				delX=snakeX[snakeLength];			//save the LastElement into delX ...
				delY=snakeY[snakeLength];			//... and delY
			}
		
			//if we ran into a stone, set the death-status variable
			//stones are marked as '#'
			if (foundElement=='#') crash=true;
			
			//another possibility to die is we runing into the border, we check hat now
			if (snakeX[1]==-1 || snakeX[1]==50 || snakeY[1]==-1 || snakeY[1]==25) crash=true;  
			
			//or did we maybe bite ourself? if yes, we die
			for (i=2;i<snakeLength;i++) {
				if (snakeX[1]==snakeX[i] && snakeY[1]==snakeY[i] && snakeX[1]!=1 && snakeY[1]!=1) {
					crash=true;
				}
			}
			
			//now copy the 2nd element of the snake to the 3rd element, the 3rd to the 4th ...
			//this makes the snake move - direction doesnt matter here
			for (i=snakeLength; i>1; i--) {
		    		snakeX[i]=snakeX[i-1];
		    		snakeY[i]=snakeY[i-1];
			}
			
			//make the last element of the snake disappear because this makes he snake move
			//if 'DelX' is set we know we found a fruit. We dont delete the last element then ...
			//... because the snake needs to grow in this case
			if(delX!=0) {
				drawElement(20+delX*4,5+delY*6,space);
			}
			
			// Pause the game so that the snake does not crawl with lightspeed
			Wait(200);
			
			//get the direction the gamer has pressed 
			runDirection=pad;
			pad=getKeys();
			if (pad==0) pad=runDirection;	//if nothing is pressed, move further
			
			//now we are trying to improve reaction time with checking if the payer
			//pressed a new direction while we wait
			runDirection=pad;
			pad=getKeys();	
			if (pad==0) pad=runDirection;	//if nothing is pressed, move further	
			//and we wait again
			Wait(200);
			
			runDirection=pad;
			pad=getKeys();	
			if (pad==0) pad=runDirection;	//if nothing is pressed, move further	
			//and we wait again
			Wait(200);
			
			runDirection=pad;
			pad=getKeys();	
			if (pad==0) pad=runDirection;	//if nothing is pressed, move further	
			//and we wait again
			Wait(200);
			
			runDirection=pad;
			pad=getKeys();	
			if (pad==0) pad=runDirection;	//if nothing is pressed, move further	
			//and we wait again
			Wait(200);
			
			//only the first element goes into a certain direction
			if (pad==up) {snakeX[1]=(snakeX[1]-1);}		//alter the first element (the head) of the snake 
			if (pad==left) {snakeY[1]=(snakeY[1]-1);}	//depending on the key pressed
			if (pad==down) {snakeX[1]=(snakeX[1]+1);}
			if (pad==right) {snakeY[1]=(snakeY[1]+1);}
			if (pad==buttonA) finished=true;		//skip a level
			
			if(fruits==0) finished=true;			//if all is eaten, finish the level
			
		} // while(crash==false && finished==false)
		
		//if we reach this point something happened - we died or we finished the level
		
		if (crash==true){		//we died ...
			drawLevel(crashLevel);	//... so show a picture
			Wait(1000);	
			clearPlayfield();	
			drawWall();		//and draw the wall again on the screen
		}
		if (finished==true) level++;	//one level up
		
	} // while(1)   	
} //AgbMain
