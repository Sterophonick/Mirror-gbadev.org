Hey,

good news ! The current holder of Atomix IP has kindly granted RMStudio the right to distribute this version
of the game. It contains a credit to Thalion, the original developer. If you already got the previous version,
please get this one as it is the "official" one !

This is a remake of Atomixm, a very addictive puzzle game from Thalion which appeared on C64, Amiga,
ST and PC. The graphics were extracted from the Amiga version and the sound is a remix module of the original
one. This time it uses the excellent MASO sound system (http://mas0.rox.free.fr) as sound engine.

There is a cool feature in the RMStudio page at startup. If you press 'Select', you can choose the
gamma correction level (very useful if you do not have an SP) with 'Right' and 'Left'. Once the level is
chosen, just press 'Start' to return to the original screen.
From startup page, press 'Start' to go to the game, showing the original intro (see how Albert's right ear is
scratched... it's just the same in the original !).
From here, just press 'Start' to begin the game.

The goal is to reassemble the molecule you see in the bottom left part of the screen using the dispersed atoms
in the allowed amound of time. Every six levels, you have a bonus level. You can not lose in such a level even
if time falls to zero. However, in the other levels, it means that the game is over... and you have to start
all it over !
You have 30 molecules to complete. They are all identical to the ones of the original.

To do so, you need to move the atoms which are spread all over the screen. For this you have a cursor, identified
by a hand. To focus on an atom, the index must point inside the atom. When done, if you press 'A', the cursor
disappears, and the atom becomes selected. To release it, just press 'A' again, the cursor will come back at the
same position.
Once an atom is selected, you can move it. Just use the direction cross to move it in the direction you want.
But when you start moving an atom in one direction, it will go on, until it meets a block in the level or
another atom. So frequently, you will have to move already correctly placed atoms just to help placing other
ones.
As soon as all the atoms are assembled the same way they are shown in the bottom left stamp, the atoms will explode,
and you will be awarded some points depending on the amount of time left. If this is too long because you are
really good at this game, just press 'A' to speed up the countdown ! You are then redirected to the next level and
molecule. 


If you fail in assembling a molecule in the given time, just press 'Start' to come back to the intro screen.

Big thanks to Greg for his excellent modplayer and don't forget to check his website !


michael.el-baki@laposte.net
My pseudo in the gbadev forum is bomberman.
