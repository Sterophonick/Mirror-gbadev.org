GBACON
------

What is it ?
------------
GBACON is a simple sprite stripper for Gameboy Advance Programmers.
It supports all sprite sizes of the Gameboy Advance sprite hardware.
it will save 2 files
1) the palette or .gap
2) the sprites or .gas

just type GBACON for more info on command line flags.

Limitations
-----------
GBACON only supports 256 colour PCX files as input
therefore all sprites will be 256 colour.
the width and height MUST be a multiple of the sprite size you want.
the sprites must be layed out on the sprite size boundries
see included pcx for an idea what i mean

NOTE
----
If it doesn't work for you then please let me know .
I have tested it extensively but you never know :)

TODO
----
Support 16 colour sprites
Extract Tiles & Maps for Backrounds

CONTACT
-------
deadsoul@stormloader.com




