Why, hello there.  I was working at some shady game company and
had some time in between projects, so I started fooling around
and made this little game demo.  My then roomate Patt Grifith did
most of the assets for me, technical assistance was provided by
co-worker Russ Prince, long time gbadev readers might remember
him.  I got bored of it and started working on some other demo
that I might get around to submitting to you guys.  I'm guessing
this was a little bit over a year ago.  I was cleaning up my western
digital and I came across the binary, so I thought I would submit
it, along with a long winded readme.  Concerning the game, theres
not much to say, done all in Mode 1, made with the official noa
devkits, works on hardware obviously, um theres a BG1HOFS or a
V_Wait or something in there to.  Enjoy.


-= C. Brandon Patterson =-
