/////////////////////////////////////////////
//Jenswa.cpp
//Example from Jenswa
//Sprite Animation
//Thanks to:
//Gbajunkie, Dovoto, Eloist, Nokturn
////////////////////////////////////////////

#include "gba.h"	//GBA register definitions
#include "keypad.h"  //button registers
#include "dispcnt.h"    //REG_DISPCNT register #defines
#include "sprite_info.h"       //gbajunkies generic sprite header file
#include "ghost.h"  //coloured ghost animation
#include "palette.h"   //palette data


//create an OAM variable and make it point to the address of OAM
u16* OAM = (u16*)0x7000000;

//create the array of sprites (128 is the maximum)
OAMEntry sprites[128];

//create the rotation and scaling array (overlaps the OAMEntry array memory)
pRotData rotData = (pRotData)sprites;

//declare ypos and xpos
s16 xpos = 120;
s16 ypos = 80;

//Copy sprite array to OAM
void CopyOAM()
{
	u16 loop;
	u16* temp;
	temp = (u16*)sprites;
	for(loop=0; loop < 128*4; loop++)
	{
		OAM[loop] = temp[loop];
	}
}

//sprite strucure, for animation of the sprite
typedef struct
{
	u16 xpos;		//x position
	u16 ypos;		//y position
	u16 spriteFrame[4];	//total frames
	int activeFrame;	//which frame is active
}Sprite;

Sprite ghost;		//create an instance

//A button was pressed at the gba
void GetInput()
{
	if(!(*KEYS & KEY_UP))                   //if the UP key is pressed
	{
	ghost.activeFrame++;
	if(ghost.activeFrame > 3)
	{
		ghost.activeFrame = 0;
	}
	sprites[0].attribute2 = ghost.spriteFrame[ghost.activeFrame];

        	if(ypos > 0)
        		ypos--;
	}
	if(!(*KEYS & KEY_DOWN))                 //if the DOWN key is pressed
	{
	ghost.activeFrame++;
	if(ghost.activeFrame > 3)
	{
		ghost.activeFrame = 0;
	}
	sprites[0].attribute2 = ghost.spriteFrame[ghost.activeFrame];

        	if(ypos < 144)
        		ypos++;
	}
	if(!(*KEYS & KEY_LEFT))                 //if the LEFT key is pressed
	{
	ghost.activeFrame++;
	if(ghost.activeFrame > 3)
	{
		ghost.activeFrame = 0;
	}
	sprites[0].attribute2 = ghost.spriteFrame[ghost.activeFrame];

        	if(xpos > 0)
        		xpos--;
	}
	if(!(*KEYS & KEY_RIGHT))                //if the RIGHT key is pressed
	{
	ghost.activeFrame++;
	if(ghost.activeFrame > 3)
	{
		ghost.activeFrame = 0;
	}
	sprites[0].attribute2 = ghost.spriteFrame[ghost.activeFrame];

        	if(xpos < 224)
        		xpos++;
	}
	if(!(*KEYS & KEY_A))                	//if the A key is pressed
	{}
	if(!(*KEYS & KEY_B))                	//if the B key is pressed
	{}
	if(!(*KEYS & KEY_L))                	//if the L key is pressed
	{}
	if(!(*KEYS & KEY_R))                	//if the R key is pressed
	{}
	if(!(*KEYS & KEY_SELECT))               //if the SELECT key is pressed
	{}
	if(!(*KEYS & KEY_START))                //if the START key is pressed
	{}
}

//move the sprite
void MoveSprite(OAMEntry* sp, int x, int y)
{
	if(x < 0)			//if it is off the left correct
		x = 512 + x;
	if(y < 0)			//if off the top correct
		y = 256 + y;

	sp->attribute1 = sp->attribute1 & 0xFE00;  //clear the old x value
	sp->attribute1 = sp->attribute1 | x;

	sp->attribute0 = sp->attribute0 & 0xFF00;  //clear the old y value
	sp->attribute0 = sp->attribute0 | y;
}


// Set sprites off screen
void InitializeSprites()
{
	u16 loop;
	for (loop = 0; loop < 128; loop++)
	{
		sprites[loop].attribute0 = 160;	//y > 159
		sprites[loop].attribute1 = 240;	//x > 239
	}
}

//wait for the screen to stop drawing
void WaitForVsync()
{
	while((volatile u16)REG_VCOUNT != 160){}
}

int main()
{
	u16 loop;	//generic loop variable


	SetMode(MODE_1 | OBJ_ENABLE | OBJ_MAP_1D);

	for(loop = 0; loop < 256; loop++)		//load palette into memory
	OBJPaletteMem[loop] = Palette[loop];


	InitializeSprites();

	sprites[0].attribute0 = COLOR_256 | SQUARE | ypos;
	sprites[0].attribute1 = SIZE_16 | xpos;
	sprites[0].attribute2 = 0;			//pointer to tile where sprite starts

	ghost.spriteFrame[0] = 0;
	ghost.spriteFrame[1] = 8;
	ghost.spriteFrame[2] = 16;
	ghost.spriteFrame[3] = 24;
	ghost.activeFrame = 0;

for(loop = 0; loop < 512; loop++)		//load sprite image data
{
	OAMData[loop] = ghostData[loop];
}

	while(1)		//main loop
	{
		GetInput();		//Checks for key presses
		MoveSprite(&sprites[0], xpos, ypos);	//moves sprite 0 around the screen
		WaitForVsync();		//waits for the screen to stop drawing
		CopyOAM();		//copies sprite array into memory
	}
}

