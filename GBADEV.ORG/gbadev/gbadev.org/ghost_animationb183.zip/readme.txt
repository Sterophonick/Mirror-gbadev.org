-------------------------
Ghost animation
-------------------------

File:		jenswa.bin (didn't want to write other make.bat file)
Program:		Moving a coloured ghost sprite
DemoNr:		01
Author:		Johan Jansen (Jenswa)
Contact:		awsnej@hotmail.com
Site:		http://www.geocities.com/flashsite_jrj/hooghaar (not about gba)

-----------------------------
About this bin-file:

This is my first working gba example,
it also displays the sprites correct this time.

It is created with a gcc compiler, DevKitAdvance, nice compiler guys.
Coded with c or c++ (I don't know, since that's new to me).

It's created after reading chapter four from gbajunkies tutorials,
sprite display, animation and multiple sprites.

This file contains one sprites (actually four for the animation of the ghost).
The ghost can move into eight directions, as it does,
it changes colour.
And it stops at the screen bounds/edges.

Source files included, even make.bat (change your DevKitAdv path before using,
otherwise it won't work, but you probably knew that all).

----------------
Thanks to:

Forgotten (VisualBoyAdvance)
Jason Wilkins (Dev-Kit Advance)
Eloist (gba.h)
GBAjunkie (tutorial, dovoto, dispcnt.h, sprite_info.h)
Dovoto (pcx2sprite, dispcnt.h, sprite_info.h) 
Noktrun (keypad.h)
GBADEV.org

----------------
About me:

The name is:
Johan Jansen,

I am new to gba-coding as well as c/c++ coding,
so it's kind a journey for me to create something simple like this.

I wanted to start with ham, but ham wouldn't instal at my pc.

So I began using arm, cause the goldroad compiler is real nice,
but ran out of tutorials.

Then I spotted the tutorial set from gbajunkie at gbadev.org,
with installation procedures for DevKitAdvance,
so I tried that.
Keep up the good work gbajunkie :-)

Mainly i create games with a very simple program
and I've created a nice game with that. (platform game, windows, http://www.geocities.com/flashsite_jrj/hooghaar)
My main purpose is to bring out a port from it
to the gba.

When I've created some more of this examples,
perhaps I'll open a gba site also.
To keep everyone posted on my game.

But first I'll start with 'learning' the background
at the gba.

Jenswa