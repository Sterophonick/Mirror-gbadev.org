;MODES
@define MODE_0 0x00
@define MODE_3 0x03

@define OBJ_MAP_2D 0x00
@define OBJ_MAP_1D 0x040

@define BG0_ENABLE 0x0100
@define BG1_ENABLE 0x0200 
@define BG2_ENABLE 0x0400
@define BG3_ENABLE 0x0800
@define OBJ_ENABLE 0x01000 
@define WIN1_ENABLE 0x02000 
@define WIN2_ENABLE 0x04000
@define WINOBJ_ENABLE 0x08000
@define VRAM 0x06000000
@define VPAL 0x05000000
@define REG_DISPCNT 0x04000000

;Sprites
@define ROTATION_FLAG 0x100
@define SIZE_DOUBLE 0x200
@define MODE_NORMAL 0x0
@define MODE_TRANSPERANT 0x400
@define MODE_WINDOWED 0x800
@define MOSAIC 0x1000
@define COLOR_16 0x0000
@define COLOR_256 0x2000
@define SQUARE 0x0
@define TALL 0x8000
@define WIDE 0x4000

@define HORIZONTAL_FLIP 0x1000
@define VERTICAL_FLIP 0x2000
@define SIZE_8 0x0
@define SIZE_16 0x4000
@define SIZE_32 0x8000
@define SIZE_64 0xC000
@define OAM 0x07000000 
@define OBJPAL 0x5000200
@define CHARMEM 0x6010000
@define CHARMEM_MODE3 0x6012BFD

;KEYPAD

@define KEY_A 1
@define KEY_B 2
@define KEY_SELECT 4
@define KEY_START 8
@define KEY_RIGHT 16
@define KEY_LEFT 32
@define KEY_UP 64
@define KEY_DOWN 128
@define KEY_R 256
@define KEY_L 512
@define KEYS 0x04000130