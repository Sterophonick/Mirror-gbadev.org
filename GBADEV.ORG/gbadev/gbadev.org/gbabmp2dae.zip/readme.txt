GBA Bitmap Converter
by Stephen Stair (sgstair@hotmail.com)
http://gbdev.8k.com


Here is a little tool for converting bitmap images to GBA-compatible files.  It can only read 24bit and 8bit bitmaps, but will eventually read other formats as well.

This program is written entirely in Assembly language ('cause that's my thing  =P)

It will export 24bit and 8bit bmps to 16bit GBA bitmap mode
It will export 8bit bmps to 8bit GBA format
it can also convert 8bit bmps to 256 color tiles, for use with GBA MapEditor

Eventually I'll code a palette reducer for the 24 bit format, but that's a future project  =)
It will also eventually be able to handle 16 color tiles, but that's also a future project

SMALL NOTE: If you want to save your bitmaps to character mode at this time, save your bitmap in 8BIT (256 color) format!!

Have fun!

