{\rtf1\mac\ansicpg10000\cocoartf102
{\fonttbl\f0\fnil\fcharset77 Monaco;}
{\colortbl;\red255\green255\blue255;}
\margl1440\margr1440\vieww9000\viewh9000\viewkind0
\pard\tx720\tx1440\tx2160\tx2880\tx3600\tx4320\tx5040\tx5760\tx6480\tx7200\tx7920\tx8640\ql\qnatural

\f0\fs20 \cf0 A Zelda Demo --> By Alex Pagliaro / Dark Cloud (12/23/02)\
\
This is a small demo of sprite animation, backgrounds, and sprite+background collision using graphics from the Legend of Zelda.  It works pretty well except for one small bug which I can't seem to figure out.  But you probably won't encounter it.  I might make the source code public if I clean it up a bit first.  Email me at dark_cloud@mac.com if you would like me to send you the source to this demo.}