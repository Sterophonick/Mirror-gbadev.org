JESPA 3D ENGINE ver 1.368 FOR GAME BOY ADVANCE
-----------------------------------------------

Hi,

My last release for jespa3d engine,

Controls:
---------

UP/DOWN/LEFT/RIGHT : Move the player.
A/B		   : JUMP/DOWN the player
L/R		   : View UP/DOWN the view.
START		   : Fly mode.
SELECT		   : View info.


New features
------------


- Rendering sprites in 8 views
- Fast rendering for sprites not power of 2.




E@Mail Contact:

u1034294@correu.udg.es

or,

jespa003@hotmail.com
  

