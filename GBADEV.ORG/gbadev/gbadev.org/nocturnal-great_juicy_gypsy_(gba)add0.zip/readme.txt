Great Juicy Gypsy by Nocturnal

Credits
-------
code:
  neon

gfx:
  xhale
  mir
  neon

music:
  optic & tecon / planet jazz
  (optic was not credited in the credits part, sorry)

Additional credits
------------------
hitmen - modplayer

www.nocturnal.no

