//another stupid experiment, a fractal generator
//using the ARM SDK
//
//
//15 April 2001
// Richard "Ries" van der Brugge / rvdbrugge@yahoo.com
//


//include standard routines

#include "rieslib.h"
#include <math.h>

#define XRES 240
#define YRES 160
#define XSIZE 240
#define YSIZE 160
#define ITER 20

//generates a julia set
void Fractal(){
   float x0,y0,p,q,xs,ys,xsq,ysq,xmin,xmax,ymin,ymax;
   int x,y,iter=ITER,s=3;
   int xoff,yoff;
   unsigned int i;
   long a;
   xmin=-1.5;
   ymin=-1.5;
   xmax=1.5;
   ymax=1.5;

   xoff=(XRES-XSIZE)>>1;
   yoff=(YRES-YSIZE)>>1;


   xs=(xmax-xmin)/XSIZE;
   ys=(ymax-ymin)/YSIZE;
   while (1) {
      a++;
      p=1.5-sin(a/26.6)*3;
      q=1.5-cos(a/31.15)*3;
      for (y=0;y<=YSIZE/2;y++) {
         for (x=0;x<=XSIZE;x++) {
            y0=ymax-y*ys;
            x0=xmin+x*xs;
            for (i=1;i<iter && (ysq=y0*y0)+(xsq=x0*x0)<4;i++) {
               y0=q+(x0*y0)+(x0*y0);
               x0=p+xsq-ysq;
            }
            i=(i==ITER) ? 1 : --i%255;
            DrawPixel (x,y,i+43);
            DrawPixel (XSIZE-x,YSIZE-y,i+43);
         }
      }


   }//wend
}//end



//********************************************************************************
//entry from startup asm code, probably the only original bit in this source all others use c_entry :)))
//this is the replacement for the main() stuff you find in other C programs
//********************************************************************************
void StartHere()
{
int i;


SetDisplayMode4On();
ClearScreen();
//create a grayscale palette from 0 to 32
CreatePalette();
Fractal();
//loop forever
while(1){
	VSync();
	}//wend
}//end starthere
