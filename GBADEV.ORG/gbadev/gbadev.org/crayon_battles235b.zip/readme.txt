///////////////////////////////////////////////
// Crayon Battles ////////////////////////////
/////////////////////////////////////////////
// Coded By Subice /////////////////////////
// Art Take from Crayon Shin Chan 1 ///////
//////////////////////////////////////////
// All Art (C) 1994 Bandai //////////////
// All Code (c) 2001 Subice/////////////
// Gba is copyrighted by Nintendo /////
//////////////////////////////////////
/////////////////////////////////////

Keys(intro):
B Button - To advance any text
Start Button - To start game

Keys(in game):
B Button - Rock
A Button - Paper
R Trigger - Scissors

Notes:
This is a small mini game I made to start showing companies but I could 
not keep it all to my self any longer. If you work with a southern
california developer and know you are looking for gba programmers just email
me for the source code but you must prove you work with a company.

Another Note:
If you want to chage quotes there at the end of the header.
0x204f0

========================================
== www.agbdev.net = Subice@agbdev.net ==
========================================