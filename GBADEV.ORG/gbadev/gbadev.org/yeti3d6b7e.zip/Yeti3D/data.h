#ifndef __DATA_H__
#define __DATA_H__
#include "yeti.h"
extern const texture_t textures[];
extern const lua_t lua;
extern const int reciprocal[];
#endif
