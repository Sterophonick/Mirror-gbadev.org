// monster.cpp: implementation of the CMonster class.
//
//////////////////////////////////////////////////////////////////////
#include "gba.h"
#include "monster.h"
#include "map.h"

extern CMap g_LevelMap; 
extern CMonster g_monsters[NUM_OF_MONSTERS]; // monsters aware of other players

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

CMonster::CMonster()
{
	m_actortype = MONSTER;
}

// generate number from 0 - 2<<16 (65536)
u16 CMonster::GBA_Random()
{
	static	u32	seed1 = 0x5324879f;
	static	u32	seed2 = 0xb78d0945;

	u32 sum;

	// Add the two seeds together
	sum = seed1 + seed2;

	// If the add generated a carry, increment
	// the result of the addition.
	if (sum < seed1 || sum < seed2) sum++;

	// Seed2 becomes old seed1, seed1 becomes result
	seed2 = seed1;
	seed1 = sum;

	// Return the result of the addition
	return (u16) ((sum >> 6) & 0xffff);
}


// generates a number from 1 to number of generators
// loops through map looking for them and puts the monster at the correct one
void CMonster::SetToRandomGenerator()
{
	int gen_count = 0;
	int loopy, loopx; 
	u16 randnum = (GBA_Random()>>13)+1; // number from 1-8

	for (loopy = 0; loopy < level_HEIGHT; loopy++)
	{
		for (loopx = 0; loopx < level_WIDTH ; loopx++)
		{
			if (g_LevelMap.TileType(loopx, loopy) == GENERATOR) // generator
			{
				gen_count++;
				if (gen_count == randnum)
				{
					setPos(loopx, loopy);
					break;
				}
			}
		}
	}
	m_health = 99;
}

// checks monster
// resets them to random position at a generator is dead
void CMonster::UpdatePosition()
{

	if (m_health == 0)
	{
		// dead monster
		SetToRandomGenerator();
		return;
	}
	if (m_move_point != 0) return; // within animation cycle don't move

	// not dead or being animated
	// so continue moving in current direction
	bool bMoveallowed = Move(m_direction);
	
	if (bMoveallowed == false) RandomTurn(); // didn't move so randomly turn

}

// change direction randomly
void CMonster::RandomTurn()
{
	u16 randnum2 = GBA_Random()>>15; // 0-2
	if (randnum2 == 1) 
	{
		Turn_Left();
	}
	else if (randnum2 == 2)
	{
		Turn_Right();
	}
	else 
	{
		Turn_Around();
	}
}

// do monster move checks before passing control to generic move
bool CMonster::Move(Direction move_direction)
{
	int mloop;
	m_direction = move_direction; // always face direction
	// check against all other monsters first
	for (mloop = 0; mloop<NUM_OF_MONSTERS; mloop++) // loop through rest of the monsters
	{
		if (   g_monsters[mloop].getX() == getTargetX(move_direction)
			&& g_monsters[mloop].getY() == getTargetY(move_direction))
		{
			//monster/monster collision!!
			return false;
		}
	}

	// monsters can't move through doors
	int Next_tile = g_LevelMap.TileType(getTargetX(move_direction), 
		                            getTargetY(move_direction));
	if(Next_tile == H_DOOR || Next_tile == V_DOOR) return false; // check for doors

	// generic move code
	return CActor::Move(move_direction);
}

