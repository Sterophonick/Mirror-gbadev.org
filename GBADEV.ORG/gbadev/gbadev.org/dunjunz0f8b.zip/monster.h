// monster.h: interface for the CMonster class.
//
//////////////////////////////////////////////////////////////////////
#ifndef MONSTER_H
#define MONSTER_H

#include "actor.h"

class CMonster : public CActor
{
public:
	CMonster();
	virtual ~CMonster() {};

	void RandomTurn(void);	
	void UpdatePosition(void);
	bool Move(Direction move_direction);
private:
	u16 GBA_Random(void);
	void SetToRandomGenerator(void);
};
#endif

