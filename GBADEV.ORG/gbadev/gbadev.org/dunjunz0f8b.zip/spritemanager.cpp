// spritemanager.cpp: implementation of the CSpriteMan class.
//
//////////////////////////////////////////////////////////////////////
#include "gba.h"
#include "spritemanager.h"
#include "print.h"
#include "sprite_graphics.h"

///////////////////Globals/////////////////////////
CMonster g_monsters[NUM_OF_MONSTERS];
CGame g_theGame;
extern CHero g_players[NUM_OF_PLAYERS]; // weapons in player
extern CMap g_LevelMap; 

u16* OAM = (u16*)0x7000000;
OAMEntry sprites[128];

///////////////WaitForVSync////////////////////////
void WaitForVSync(void)
{
	while(*((volatile unsigned short*)0x04000004) & (1<<0));
	while(!((*((volatile unsigned short*)0x04000004) & (1<<0))));
}


//run once at the start of the program
// loads all neccesary graphics
void CSpriteMan::Initialisation()
{

	u16 loop;
    int x;

	//*********** load sprite graphics ************
	for(loop = 0; loop < 256; loop++)
		OBJPaletteMem[loop] = spritesPalette[loop];
	 //load sprite image data 
	for(loop = 0; loop < sprites_HEIGHT * sprites_WIDTH /2; loop++)
       	OAMData[loop] = spritesData[loop];

	// ******* Setup up Sprites
	InitializeSprites();
	
	//*********** setup player sprites ************
	for (x = 0; x<NUM_OF_PLAYERS; x++)
	{
		sprites[x].attribute0 = COLOR_256 | SQUARE | ROTATION_FLAG;// setup sprite info, 256 colour, shape and y-coord
		sprites[x].attribute1 = SIZE_16 | ROTDATA(x);//   size 16x16 and x-coord
		g_players[x].m_ibaseframe = 16*x; // character frame is held in the class so it can be reset later on
		g_players[x].pOAMSprite = &sprites[x];
		g_players[x].m_rotindex = x;
		g_players[x].m_rotData = (pRotData)sprites;
	}

	//*********** setup monster sprites ************
	int Offset = NUM_OF_PLAYERS;
	for (x = 0; x<NUM_OF_MONSTERS; x++)
	{
		sprites[x+Offset].attribute0 = COLOR_256 | SQUARE | ROTATION_FLAG; //setup sprite info, 256 colour, shape and y-coord
		sprites[x+Offset].attribute1 = SIZE_16 | ROTDATA(x+Offset);          //size 16x16 and x-coord
		g_monsters[x].m_ibaseframe = 64; // character frame is held in the class so it can be reset later on
		g_monsters[x].pOAMSprite = &sprites[x+Offset];
		g_monsters[x].m_rotindex = x+Offset;
		g_monsters[x].m_rotData = (pRotData)sprites;
	}


	//*********** setup weapon sprites ************
	Offset += NUM_OF_MONSTERS;
	for (x = 0; x<NUM_OF_PLAYERS; x++) // set up players weapons
	{
		for (int y = 0; y<MAX_NUM_OF_WEAPONS; y++)
		{
			sprites[y+x+Offset].attribute0 = COLOR_256 | SQUARE ;//| ROTATION_FLAG;//setup sprite info, 256 colour, shape and y-coord
			sprites[y+x+Offset].attribute1 = SIZE_16 ;//| ROTDATA(y+x+Offset);   //size 16x16 and x-coord
			g_players[x].m_weapons[y].m_ibaseframe = 128+(x*16);
			g_players[x].m_weapons[y].pOAMSprite = &sprites[y+x+Offset];
		}
	}

	// cloud when monster hit
	Offset += NUM_OF_PLAYERS*MAX_NUM_OF_WEAPONS;
	sprites[126].attribute0 = COLOR_256;
	sprites[126].attribute1 = SIZE_16;
	sprites[126].attribute2 = 80;

	// player types
	g_players[0].m_actortype = RANGER;
	g_players[1].m_actortype = BARBARIAN;
	g_players[2].m_actortype = MAGE;
	g_players[3].m_actortype = FIGHTER;

	for (x = 0; x<NUM_OF_PLAYERS; x++) 
	{ 
		// set up players
		g_players[x].Initialisation();
	}
	for (x = 0; x<NUM_OF_PLAYERS; x++) 
	{ 
		// set up monsters
		g_monsters[x].Initialisation();
	}
}

// runs before each level
void CSpriteMan::SetupBeforeLevel()
{
	int x;

	// set current hero to first character
	// game will move automatically to first available
	m_CurrentPlayer = 0;

	//set up players
	for (x = 0; x<NUM_OF_PLAYERS; x++) 
	{ 
		// set up players
		g_players[x].SetupBeforeLevel();
	}

	//setup monsters - will respawn when they have 0 health
	for (x = 0; x<NUM_OF_MONSTERS; x++)
	{
		g_monsters[x].SetupBeforeLevel();
		g_monsters[x].setHealth(0);
	}
	
}

// resets characters to starting stats
// at start of game and after death
void CSpriteMan::Reset()
{
	//players
	for (int x = 0; x<NUM_OF_PLAYERS; x++) 
	{ 
		// set up players
		g_players[x].Reset();
	}
}

// get player key strokes
void CSpriteMan::GetInput()
{
	//player - position updated every 2nd frame, every frame with boot of speed
	if (g_theGame.getTimer() % g_players[m_CurrentPlayer].getFrameRate() == 0) 
	{
		if(!(*KEYS & KEY_UP))
		{
			g_players[m_CurrentPlayer].Move(UP);
		}
		else if(!(*KEYS & KEY_DOWN))
		{
			g_players[m_CurrentPlayer].Move(DOWN);
		}
		else if(!(*KEYS & KEY_LEFT))
		{
			g_players[m_CurrentPlayer].Move(LEFT);
		}
		else if(!(*KEYS & KEY_RIGHT))
		{
			g_players[m_CurrentPlayer].Move(RIGHT);
		}
		if(!(*KEYS & KEY_A))
		{
			g_players[m_CurrentPlayer].Fire();
		}
		if(!(*KEYS & KEY_B))
		{
			g_players[m_CurrentPlayer].UseMagic();
		}

	}
	if(!(*KEYS & KEY_R))
	{
		//  move to next character
		GetAvailableCharacter(1);
	}
	if(!(*KEYS & KEY_L))
	{
		//  move to last character
		GetAvailableCharacter(-1);
	}

}

// moves the currently used player to the next available slot
// NB: currently should be used with HasTheQuestFailed and AllCharactersExited
void CSpriteMan::GetAvailableCharacter(int step)
{
	int iFirstPlayer = m_CurrentPlayer;
	// move to next or previous
	do{
		m_CurrentPlayer+=step;
		if(m_CurrentPlayer == -1) m_CurrentPlayer = 3;
		if(m_CurrentPlayer == 4)  m_CurrentPlayer = 0;
		if (iFirstPlayer == m_CurrentPlayer) break; // just to prevent eternal loop
	}while (!(g_players[m_CurrentPlayer].IsAvailable()));

}
// update positions of monsters and weapons
// characters are actually updated with the GetInput function
// updateposition on a player checks status
// game status is also updated from here
void CSpriteMan::UpdatePositions()
{
	//Players
	for (int ploop = 0; ploop < NUM_OF_PLAYERS; ploop++)
	{
		g_players[ploop].UpdatePosition();
		//players weapons
		for (int wloop = 0; wloop < MAX_NUM_OF_WEAPONS; wloop++)
		{
			g_players[ploop].m_weapons[wloop].UpdatePosition();
		}
	}
	//monsters - position updated every 5th frame
	if (g_theGame.getTimer() % 5 == 0)
	{
		for (int mloop = 0; mloop < NUM_OF_MONSTERS; mloop++)
		{
			g_monsters[mloop].UpdatePosition();
		}
	}
	CheckGameStatus();
}

// check for alldead, next_level or unavailable character
void CSpriteMan::CheckGameStatus()
{

	if (HasTheQuestFailed()) 
	{
		// quest failed
		g_theGame.m_Status = ALLDEAD;
		if (g_LevelMap.getCurrentLevel() == NUMBERLEVELS) // finished - TODO add chalice!!
		{
			g_theGame.m_Status = COMPLETE;
		}
	}
	else if (AllCharactersExited()) // (or dead)
	{
		// time for next level
		g_LevelMap.nextLevel();
		g_theGame.m_Status = NEXT_LEVEL;
		if (g_LevelMap.getCurrentLevel() == NUMBERLEVELS) // finished - TODO add chalice!!
		{
			g_theGame.m_Status = COMPLETE;
		}
	}else if (!g_players[m_CurrentPlayer].IsAvailable()) {
		// current character not available
		// move to next
		GetAvailableCharacter(1);
	}

}

// loop through players and check whether they are all dead or not playing
bool CSpriteMan::HasTheQuestFailed()
{

	// check for all character death
	bool bHasTheQuestFailed = true;
	for (int ploop = 0; ploop < NUM_OF_PLAYERS; ploop++)
	{
		if (g_players[ploop].getIsPlaying() == true) // player is playing 
		{
			if (g_players[ploop].getIsDead() == false) // and player is not dead
			{
				bHasTheQuestFailed = false; // atleast one player still alive
				break;
			}
		}
	}
	return bHasTheQuestFailed;

}

// check for all character exited (some maybe dead, atleast one through exit)
// NB: if all players aren't ALLDEAD then must be next level
bool CSpriteMan::AllCharactersExited()
{
//	if (HasTheQuestFailed() == true) return false; // shouldn't ever happen already tested

	bool bAllPlayersExitedOrDead = true;
	for (int ploop = 0; ploop < NUM_OF_PLAYERS; ploop++)
	{
		if (g_players[ploop].IsAvailable())
		{
			bAllPlayersExitedOrDead = false; // atleast one player still not exited
			break;
		}
	}
	return bAllPlayersExitedOrDead;
}


void CSpriteMan::CheckCollisions()
{
	CheckActorCollisions();
	CheckTileCollisions();
}

// iterates through all monsters, heros and weapons checking for collisions
void CSpriteMan::CheckActorCollisions()
{
	int wloop, mloop, ploop;

	//reset dust cloud
	sprites[126].attribute0 = COLOR_256 | 240;
	sprites[126].attribute1 = SIZE_16 | 160;
	
	// MONSTER collisions
	for (mloop = 0; mloop<NUM_OF_MONSTERS; mloop++)
	{
		for (ploop = 0; ploop<NUM_OF_PLAYERS; ploop++)
		{
			if (g_players[ploop].IsAvailable())
			{
				if (CheckForCollision(&g_monsters[mloop], &g_players[ploop])) // check players
				{
					//player/monster collision!!
					g_players[ploop].alterHealth(-(5-(g_players[ploop].getDefense()/2))); //calculated with defense
					g_monsters[mloop].RandomTurn(); // monster moves off
				}

				for (wloop = 0; wloop<MAX_NUM_OF_WEAPONS; wloop++) // check monsters/weapons
				{
					if (CheckForCollision(&g_monsters[mloop], &g_players[ploop].m_weapons[wloop]))
					{
						//weapon/monster collision!!
						g_monsters[mloop].alterHealth(-(g_players[ploop].getAttack()*10)); // calculated with attack
						g_players[ploop].Increase_Score(1);
						g_players[ploop].m_weapons[wloop].Hide(); // weapon disappears
						if (g_monsters[mloop].WithinCurrentView())
						{
							// dust cloud appears over monster
							sprites[126].attribute0 = COLOR_256 | (g_monsters[mloop].getY() % 8) * VIEW_SIZE_Y;
							sprites[126].attribute1 = SIZE_16 | (g_monsters[mloop].getX() % 8) * VIEW_SIZE_X;
						}
					}
				}
			}
		}
	}

	//CHARACTER collisions - search through each characters weapons and check against all other characters
	for (ploop = 0; ploop<NUM_OF_PLAYERS; ploop++)//firing player
	{
		for (wloop = 0; wloop<MAX_NUM_OF_WEAPONS; wloop++) //weapons
		{
			for (int ploop2 = 0; ploop2<NUM_OF_PLAYERS; ploop2++)//other players (who may be hit)
			{
				if (g_players[ploop2].IsAvailable())
				{
					if (CheckForCollision(&g_players[ploop2], &g_players[ploop].m_weapons[wloop]))
					{
						//weapon/character collision!!
						g_players[ploop2].alterHealth(-10);
						g_players[ploop].m_weapons[wloop].Hide();
					}
				}
			}
		}
	}
}

// detect pickups for current player
void CSpriteMan::CheckTileCollisions()
{

	for (int ploop = 0; ploop<NUM_OF_PLAYERS; ploop++)
	{
		g_players[ploop].CheckTileCollisions();
	}

}

// helper function to check a collision between two actors
bool CSpriteMan::CheckForCollision(CActor* actor1, CActor* actor2)
{
	// ignore actors that are frozen
	if (actor1->getFreeze() == true || actor2->getFreeze() == true)
	{
		return false;
	}

	//check for a collision
	if (actor1->getX() == actor2->getX()
		&& actor1->getY() == actor2->getY())
	{
		return true;
	}else{
		return false;
	}
}

// output all actors to the screen
void CSpriteMan::RenderGraphics()
{
	for (int ploop = 0; ploop<NUM_OF_PLAYERS; ploop++)
	{
		g_players[ploop].Render();
		for (int wloop = 0; wloop<MAX_NUM_OF_WEAPONS; wloop++)
		{
			g_players[ploop].m_weapons[wloop].Render();
		}
	}
	
	for (int mloop = 0; mloop<NUM_OF_MONSTERS; mloop++)
	{
		g_monsters[mloop].Render();
	}
	
	UpdateSideStats();
	WaitForVSync();			//waits for the screen to stop drawing
	CopyOAM();			//Copies sprite array into OAM.

}

// create the game information bar on the right
void CSpriteMan::UpdateSideStats()
{
	// static sprites for side bar
	int Offset = NUM_OF_MONSTERS+NUM_OF_PLAYERS+(MAX_NUM_OF_WEAPONS*NUM_OF_PLAYERS);	
	for (int ploop = 0; ploop<NUM_OF_PLAYERS; ploop++)
	{

		if (g_players[ploop].getIsPlaying())
		{
			// main player stats
			g_players[ploop].UpdateSideStats(ploop * 5);

			// static image of player as a sprite
			sprites[ploop+Offset].attribute0 = COLOR_256 | SQUARE | (40 * ploop)+5;  //setup sprite info, 256 colour, shape and y-coord
			sprites[ploop+Offset].attribute1 = SIZE_16 | 140;            //size 16x16 and x-coord
			sprites[ploop+Offset].attribute2 = 16*ploop;  

			// side arrow to show which player is currently active
			PrintInit(17,2+(5 * ploop),31,32,0);
			if (m_CurrentPlayer == ploop) 
			{
				PrintChar(27,1+(5 * ploop), '<');
			}else{
				PrintChar(27,1+(5 * ploop), ' ');
			}
		}

	}

}

////////////////CopyOAM///////////////////////
void CSpriteMan::CopyOAM(void)
{
	u16 loop;
	u16* temp;
	temp = (u16*)sprites;

	//Copy sprite attributes into OAM
	for(loop = 0; loop < 128*4; loop++)
	{
		OAM[loop] = temp[loop];
	}
}

/////////////////InitializeSprites/////////////
void CSpriteMan::InitializeSprites(void)
{
	int loop;
	for(loop = 0; loop < 128; loop++)
	{
		sprites[loop].attribute0 = 160;  //y > 159, sprite offscreen
		sprites[loop].attribute1 = 240;  //x > 239, sprite offscreen
		sprites[loop].attribute2 = 0;	 //zero out
	}
}

// quick function to remove all sprites from screen
void CSpriteMan::HideSprites(void)
{
	int loop;
	for(loop = 0; loop < 128; loop++)
	{
		sprites[loop].attribute1 &= 0xFE00;	//Clear old X value
		sprites[loop].attribute1 |= 240;		//Set new X value
		
		sprites[loop].attribute0 &= 0xFF00;	//Clear old Y value
		sprites[loop].attribute0 |= 160;		//Set new Y value
	}
	CopyOAM();
}

