// weapon.h: interface for the CWeapon class.
//
//////////////////////////////////////////////////////////////////////
#ifndef WEAPON_H
#define WEAPON_H

#include "actor.h"

class CWeapon : public CActor  
{
public:
	CWeapon();
	virtual ~CWeapon() {};

	void UpdatePosition();
	bool Move(Direction move_direction);
	void Render(void);
	void RotateSprite(void);

};
#endif

