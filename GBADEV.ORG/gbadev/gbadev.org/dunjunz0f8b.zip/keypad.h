/*****************************\
* 	keypad.h
*	Original by Dovoto
*	Modified by staringmonkey
*	Last modified on 10/31/01
\*****************************/

#ifndef KEYPAD_H
#define KEYPAD_H

/////////////////Necessary Includes///////////////

///////////////////Definitions////////////////////

#define FREQUENCY_0		0x0
#define FREQUENCY_64	BIT0
#define FREQUENCY_256	BIT1
#define FREQUENCY_1024	BIT0 | BIT1

#define TIMER_CASCADE	BIT2
#define TIMER_IRQ		BIT6
#define TIMER_ENABLE	BIT7

////////////////Functions Prototypes////////////////
void WaitKey(int whatKey);
void WaitTimeOrKey(int whatKey, int seconds, int milliSeconds);

//////////////////WaitKey///////////////////////////
void WaitKey(int whatKey)
{
	//Enable timers
	REG_TM2CNT = FREQUENCY_256 | TIMER_ENABLE;
	REG_TM3CNT = TIMER_CASCADE | TIMER_ENABLE;

	while(1)
	{
		if(!(*KEYS & whatKey))
		{
			break;
		}
	}

	//Seed random number generator (cant hurt, even if that wasnt why we called it)
//	srand(REG_TM2D);

	//Disable timers
	REG_TM2CNT = 0;
	REG_TM3CNT = 0;

	//Zero-out timer counters
	REG_TM2D = 0;
	REG_TM3D = 0;
}


///////////////////WaitTime////////////////////
void WaitTimeOrKey(int whatKey, int seconds, int milliSeconds)
{
	//Enable timers
	REG_TM2CNT = FREQUENCY_256 | TIMER_ENABLE;
	REG_TM3CNT = TIMER_CASCADE | TIMER_ENABLE;

	//Zero out timer values
	REG_TM2D = 0;
	REG_TM3D = 0;

	//Wait until ? seconds have passed
	while(REG_TM3D < seconds)
	{
		if(!(*KEYS & whatKey))
		{
			break;
		}
	}

	//Zero out base/millisecond timer
	REG_TM2D = 0;

	//1 millisecond = max register value (65536) divided by the # milliseconds in a second (1000)	
	//Wait until ? milliseconds have passed
	while(REG_TM2D / (65536/1000) < milliSeconds)
	{
	}

	//Disable timers
	REG_TM2CNT = 0;
	REG_TM3CNT = 0;
	
	//Zero out timer values
	REG_TM2D = 0;
	REG_TM3D = 0;
}

#endif
