// game.cpp: implementation of the CGame class.
//
//////////////////////////////////////////////////////////////////////
#include "gba.h"
#include "game.h"
#include "map.h"
#include "hero.h"
#include "spritemanager.h"
#include "graphics.h"
#include "print.h"
#include "front.h"
#include "deathscreen.h"
#include "endscreen.h"
#include "keypad.h"
#include "time.h"
#include "blend.h"

///////////////////Globals/////////////////////////
CMap g_LevelMap; 
CSpriteMan g_SpriteMan; 
CHero g_players[NUM_OF_PLAYERS]; // weapons in player
volatile u32* KEYS = (volatile u32*)0x04000130;
u16* BackgroundMem = (u16*)0x6004000;	//Memory for background graphics (OAMData part2)

//run at the start of a new game
// loads all neccesary graphics
// (- this could be altered, so it only needs to be run once.)
void CGame::Initialisation()
{
	m_gametimer = 0;

	SetMode(MODE_1 | BG0_ENABLE | BG1_ENABLE | BG2_ENABLE | OBJ_ENABLE | OBJ_MAP_1D); //set mode 1 and enable sprites and 1d mapping
	
	// ******* Setup up Sprites
	g_SpriteMan.Initialisation();
	
	g_LevelMap.Initialisation();

}


// runs before each level
void CGame::SetupBeforeLevel()
{
	// setup level
	g_LevelMap.SetupBeforeLevel();

	//set up players
	g_SpriteMan.SetupBeforeLevel();
	
	m_Status = RUNNING;

}

// resets back to first level
void CGame::Reset()
{
	//map
	g_LevelMap.setCurrentLevel(0);
	//players
	g_SpriteMan.Reset();

}

// get player input
void CGame::GetInput()
{
	g_SpriteMan.GetInput();

	if(!(*KEYS & KEY_START))
	{
		//Quick Load
		m_Status = PAUSED; // game will freeze and check for unpauses
		Print(11, 5, "PAUSED");
		WaitTime(0, 90);
	}
	if(!(*KEYS & KEY_SELECT))
	{
		//Quick Save
	//	QuickSave(); // TODO
	}
}

// runs whilst game in PAUSE status
void CGame::CheckForUnpause()
{
	if(!(*KEYS & KEY_START))
	{
		// start has been pressed, alter status back
		m_Status = RUNNING;
		Print(11, 5, "      ");
		WaitTime(0, 80);
	}
}

// update map and sprites
void CGame::UpdatePositions()
{
	// Map
	g_LevelMap.UpdateView(g_players[g_SpriteMan.getCurrentPlayer()].getX(), 
		                  g_players[g_SpriteMan.getCurrentPlayer()].getY());
	// sprites
	g_SpriteMan.UpdatePositions();			

}

void CGame::CheckCollisions()
{
	// sprites
	g_SpriteMan.CheckCollisions();			

}

void CGame::RenderGraphics()
{
	//render map
	g_LevelMap.RenderGraphics(m_gametimer);

	//render sprites
	g_SpriteMan.RenderGraphics();

	m_gametimer++; // keep track of time

	WaitTime(0,10); // slow down game a little

}

/******************************************/
// Front screens here ----V

// display Dunjunz first screen
void CGame::DisplayFrontScreen()
{

	int loop;
	int x, y;

    SetMode(MODE_4 | BG2_ENABLE); 

	fadeout(1); //set fade to black

	for(loop = 0; loop < 256; loop++)                 
	{
		BGPaletteMem[loop] = frontPalette[loop]; //load the palette into palette memory
	}

	for(y = 0; y < 160; y++)                  //screen height
	{
		for(x = 0; x < 240; x++)          //screen width
		{
			PlotPixel(x,y, frontData[y*240+x]);	//load image data into
		}						                //memory pixel by pixel
	}

	fadein(FADESPEED); // slowly reveal the picture
	WaitKey(KEY_START); 
	fadeout(FADESPEED); // slowly remove the picture
	FillScreen(BGR(0, 0, 0)); //clear screen
}

//display dunjunz game cover and game info
void CGame::DisplayTitleScreen()
{
	
	int loop;
	int x, y;

    SetMode(MODE_4 | BG2_ENABLE); //set mode 4 and enable background 2
	fadeout(1);
	for(loop = 0; loop < 256; loop++)                
	{
		BGPaletteMem[loop] = titlePalette[loop]; //load the palette into palette memory
	}

	for(y = 0; y < 160; y++)                  //screen height
	{
		for(x = 0; x < 240; x++)          //screen width
		{
			PlotPixel(x,y, titleData[y*240+x]);	//load image data into
		}						                //memory pixel by pixel
	}

	WaitTime(0,60); // prevent double start being pressed
	
	fadein(FADESPEED);
	WaitKey(KEY_START);
	fadeout(FADESPEED);
	FillScreen(BGR(0, 0, 0)); //clear screen
	m_Status = SETUP;

}

// display final message to dead team
void CGame::DisplayDeadScreen()
{
	int loop;
	int x, y;

    SetMode(MODE_4 | BG2_ENABLE);
	fadeout(1);
	for(loop = 0; loop < 256; loop++) 
	{
		BGPaletteMem[loop] = deathPalette[loop]; //load the palette into palette memory
	}

	for(y = 0; y < 160; y++)                  //screen height
	{
		for(x = 0; x < 240; x++)          //screen width
		{
			PlotPixel(x,y, deathData[y*240+x]);	//load image data into
		}						                //memory pixel by pixel
	}

	fadein(FADESPEED);
	WaitKey(KEY_START);
	fadeout(FADESPEED);
	FillScreen(BGR(0, 0, 0)); //clear screen
	m_Status = SETUP;
}



// display final message to dead team
void CGame::DisplayVictoryScreen()
{
	int loop;
	int x, y;

    SetMode(MODE_4 | BG2_ENABLE);
	fadeout(1);
	for(loop = 0; loop < 256; loop++) 
	{
		BGPaletteMem[loop] = frontPalette[loop]; //uses same palette as front screen
	}

	for(y = 0; y < 160; y++)                  //screen height
	{
		for(x = 0; x < 240; x++)          //screen width
		{
			PlotPixel(x,y, endData[y*240+x]);	//load image data into
		}						                //memory pixel by pixel
	}

	fadein(FADESPEED);
	WaitKey(KEY_START);
	fadeout(FADESPEED);
	FillScreen(BGR(0, 0, 0)); //clear screen
	m_Status = SETUP;
}


//player can choose which heros are needed
void CGame::DisplayMenu()
{
	int x;
	fadeout(1);
	PrintInit(0,0,31,32,0);
	PrintSetWindow(0,0,140,140);

	//print the main menu, YES/NO are printed dynamically
	Print(11, 2,  "Dunjunz");
	Print(6, 4,   "HERO            PLAYING");
	Print(1, 6,   "1   RANGER              YES");
	Print(1, 8,   "2   BARBARIAN           YES");
	Print(1, 10,  "3   MAGIC-USER          YES");
	Print(1, 12,  "4   FIGHTER             YES");
	Print(10, 15, "Press Start");

	// TODO - should be removed
	g_SpriteMan.HideSprites();

	WaitTime(0,80); // prevent double start being pressed
	fadein(FADESPEED);
	int iCurrentSelection = 0;

	bool bCanStart = false; // only if one character is selected can you start
	while((*KEYS & KEY_START) || bCanStart == false)
	{

		if(!(*KEYS & KEY_UP))
		{
			iCurrentSelection--;
			if (iCurrentSelection == -1) iCurrentSelection = 3; // wrap around
		} else if(!(*KEYS & KEY_DOWN))
		{
			iCurrentSelection++;
			if (iCurrentSelection == 4) iCurrentSelection = 0; // wrap around
		} else if(!(*KEYS & KEY_A))
		{
			// Key A toggles character on/off
			if (g_players[iCurrentSelection].getIsPlaying())
			{
				g_players[iCurrentSelection].setIsPlaying(false);
			} else {
				g_players[iCurrentSelection].setIsPlaying(true);
			}
		} 

		//output whether playing
		bCanStart = false;
		for (x = 0; x<NUM_OF_PLAYERS; x++)
		{
			// print '*' next to current selection
			if (iCurrentSelection == x)
			{
				Print(3, (x*2)+6, "*");
			}else{
				Print(3, (x*2)+6, " ");
			}

			// output whether character is selected as playing
			if (g_players[x].getIsPlaying())
			{
				Print(25, (x*2)+6, "YES");
				bCanStart = true;
			}else{
				Print(25, (x*2)+6, "NO ");
			}
			
		}

		WaitTime(0,90); // prevent double pressing
	}
	fadeout(FADESPEED);
	ClearText();
	fadein(1);
	m_Status = NEXT_LEVEL;
}



/*

// TODO - add quick load/save menu
void CGame::QuickMenu()
{

}

void CGame::QuickSave()
{
	// serialise required variables
	SaveInt(0, CurrentLevel);
	
}

void CGame::QuickLoad()
{
	// load required variables
	CurrentLevel = LoadInt(0);
	Status = NEXT_LEVEL;
}
*/