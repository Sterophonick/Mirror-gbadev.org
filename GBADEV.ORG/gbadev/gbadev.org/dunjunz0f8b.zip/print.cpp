#include <stdarg.h>


//this is just a conversion table that converts the asci code to 
//the approptiat number in our font set
//needed because i do not have the full asci fon... Some chars are missing
//This is not
//necessary but faster than testing to convert the asci to our font
//plus if we decide to add a new font all we need is another table
//and it does not need to match our old font 

const char ASCI[] = 
{
	0,1,2,3,4,5,6,7,8,9,10,
	11,12,13,14,15,16,17,18,19,20,
	21,22,23,24,25,26,27,28,29,30,
	31,32,33,34,35,36,37,38,39,40,
	41,42,43,44,45,46,47,48,49,50,
	51,52,53,54,55,56,57,63,64,65,
	66,67,68,58,59,60,61,62,63,64,
	65,66,67,68,69,70,71,72,73,74,
	75,76,77,78,79,80,81,82,83,84,
	85,87,88,89,90,91,92,93,94,95
};

//these are also defined in gba.h but I was getting a conflict when i tried to 
//include it so I just stuck these in here for now
#define ScreenBaseBlock(n)		(((n)*0x800)+0x6000000)
typedef unsigned short u16;


//these globals keep track of things for me like cursor position.  Should
//really use a class for this but I am still trying to avoid c++ in the tutors
//even though i use it in my main project
int gPrintX,gPrintY,gTextWidth,gCharOffset;
u16* gbgMap;

//this struct holds the bounds for my window.  Allows for automatic 
//text wrapping
struct gsWindow
{
	int x1,y1,x2,y2;
}gsWindow;


/**************************************************************
/  PrintSetWindow this just enables a smaller window
/  
/  
/
***************************************************************/
void PrintSetWindow(int x1, int y1, int x2, int y2)
{
	gsWindow.x1 = x1;
	gsWindow.y1 = y1;
	gsWindow.x2 = x2;
	gsWindow.y2 = y2;
}
/**************************************************************
/  Print Initializer.  Just call this if you want to print stuff
/  Pass it the starting point of the curser.  The background map
/  and the background width you want to print
/
***************************************************************/
void PrintInit(int x, int y, int BB, int w, int offset)
{
	gPrintX = x;//cursor location
	gPrintY = y;
	gTextWidth = w;//width of the print area
	gbgMap = (u16*)ScreenBaseBlock(BB); //were I am alowed to print to
	gCharOffset = offset;//this is so your font doesnt have to start at the beginning of a char block
	PrintSetWindow(x,y,w,w);
	

}

/**************************************************************
/  PrintSet This just sets the cursor position
/  
/  
/
***************************************************************/
void PrintSet(int x, int y)
{
	gPrintX = x;
	gPrintY = y;
}

/**************************************************************
/  Print a character
/  
/  
/
***************************************************************/
inline void PrintChar(char c)
{

	
	c = ASCI[c-32]; //this is need to convert the asci number to the offset of my font

	gbgMap[gPrintX + gPrintY* gTextWidth] = c+gCharOffset; //this is it to printing the char
	
	//update my text wrapper...very simple text wrapper
	gPrintX++;
	if(gPrintX >= gsWindow.x2)
	{
		gPrintY++;
		gPrintX = gsWindow.x1;
	
	}

}


/**************************************************************
/  print character any place
/  
/  same thing as print char but ignores the window and the cursor
/
***************************************************************/
void PrintChar(int x, int y, char c)
{
	PrintSet(x,y);
	PrintChar(c);
}

/**************************************************************
/  Print a string to curent cursor location
/  
/  
/
***************************************************************/
void Print(char* z)
{
	int loop = 0;

	while(z[loop] != 0)
		PrintChar(z[loop++]);
}

/**************************************************************
/  Print a string to any position
/  
/  
/
***************************************************************/
void Print(int x, int y, char* z)
{
	PrintSet(x,y);
	Print(z);
}



/**************************************************************
/  print an intiger
/  
/  
/
***************************************************************/
void PrintInt(int i)
{
	int loop = 0;
	int temp ;
	char buf[12] = {0,0,0,0,0,0,0,0,0,0,0,0};//set to zero cause I may add formatted output someday

	if(i<0)
	{
		PrintChar('-');
		i = -i;
	}
	while(i > 0)
	{
		temp = i;
		i = i/10; 
		buf[loop++] =  temp - (i*10);
	}
	
	if(!loop)PrintChar(48); //there was nithing there so print 0
	
	else while(--loop >= 0) //after I am done my int is stored backwards in the buffer
	{
		PrintChar(buf[loop]+48); //addint 48 to an int converts it to an asci code
	
	}
}

/**************************************************************
/  print an intiger anywhere
/  
/  
/
***************************************************************/
void PrintInt(int x, int y, int i)
{
	PrintSet(x,y);
	PrintInt(i);
}
/**************************************************************
/  print an intiger in hex
/  
/  almost identical to printInt...exept i divide by 16 instead of ten
/
***************************************************************/
void PrintHex(int i)
{
	int loop = 0;
	
	char buf[12] = {0,0,0,0,0,0,0,0,0,0,0,0}; //set to zero cause I may add formatted output someday
	
	if(i<0)
	{
		PrintChar('-');
		i = -i;
	}
	while(i > 0)
	{
		buf[loop++] =  i & 0xF;
		i = i>>4; 
	}
	
	if(!loop)PrintChar(48);
	
	else while(--loop >= 0)
	{
		if(buf[loop] < 10)PrintChar(buf[loop]+48);
		else PrintChar(buf[loop]+55);
	}
}

/**************************************************************
/  print an intiger anyware in hex
/  
/  
/
***************************************************************/
void PrintHex(int x, int y, int i)
{
	PrintSet(x,y);
	PrintHex(i);
}
/**************************************************************
/  print an formated string...sorta
/  
/  the va stuff is standard c stuff from stdarg.h
/
***************************************************************/
void PrintF(const char* z,...)
{
	va_list argp;  //this is needed to access a variable length argument list
	int loop = 0;

	va_start(argp, z); //get the first argument

	while(z[loop] != 0) //loop through the screen
	{
		switch (z[loop])
		{
		case '%'://special char
			loop++;	
			switch(z[loop])
			{
				case 'd':
				case 'D':
					PrintInt(va_arg(argp, int));
					break;
				case 'x':
				case 'X':
					PrintHex(va_arg(argp, int));
					break;
				case 's':
				case 'S':
					Print(va_arg(argp,char*));
					break;
				default:
					PrintChar('%');
					PrintChar(z[loop]);
					break;
			}
			break;

		case '\n':
			gPrintX = gsWindow.x1;
			gPrintY++;
			break;
		
		default:
			PrintChar(z[loop]);
			break;

		}
		loop++;
	}
}

///////////////////ClearText///////////////////
void ClearText()
{
	//Looping variables
	int x,y;

	for(y=0;y<32;y++)
	{
		for(x=0;x<32;x++)
		{
			PrintChar(x, y, ' ');
		}
	}
}
