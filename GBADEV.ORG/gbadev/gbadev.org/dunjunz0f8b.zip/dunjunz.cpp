/////////////////Necessary Includes////////////
#include "game.h"

// allows multiboot games
//MULTIBOOT 

////////////////////////Main///////////////////////

extern CGame g_theGame;

// main game loop
// uses g_theGame.m_Status to drive game flow
int main(void)
{

	g_theGame.DisplayFrontScreen();
	g_theGame.DisplayTitleScreen();
	while(1)
	{
		switch(g_theGame.m_Status)
		{
			case SETUP:
				g_theGame.Initialisation();
				g_theGame.Reset();
				g_theGame.DisplayMenu();
				break;
			case NEXT_LEVEL:
				g_theGame.SetupBeforeLevel();
				break;
			case RUNNING:
				g_theGame.GetInput();
				g_theGame.UpdatePositions();
				g_theGame.CheckCollisions();
				g_theGame.RenderGraphics();
				break;
			case ALLDEAD:
				g_theGame.DisplayDeadScreen();
				break;
			case COMPLETE:
				g_theGame.DisplayVictoryScreen(); // not yet implemented
				break;
			case PAUSED:
				g_theGame.CheckForUnpause();
				break;
			default:
				break;
		}
	}
}
