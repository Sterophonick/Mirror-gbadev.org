// Map.h: interface for the CMap class.
//
//////////////////////////////////////////////////////////////////////
#ifndef MAP_H
#define MAP_H


class CMap  
{
public:
	CMap() {};
	virtual ~CMap() {}; 

	u8   TileType(int x, int y);
	void Initialisation();
	void SetupBeforeLevel();
	void RenderGraphics(int gametime);
	void RemoveTile(int x, int y);
	void UpdateView(int, int);
	bool WithinCurrentView(int x, int y);

	int  getMetaData(int x, int y);
	void setMetaData(int x, int y, int value);

	int  getCurrentLevel() {return m_CurrentLevel;};
	void setCurrentLevel(int iLevel) {m_CurrentLevel = iLevel;};

	void nextLevel() {m_CurrentLevel++;};
	void DropKey(int x, int y, int keynumber);
	
private:

	int  m_View_Current_x;
	int  m_View_Current_y;
	u8   m_levelcopy[ 64 * 96 ];     // changable copy of the dungeon info
	u8   m_levelMetaData[ 64 * 96 ]; // to keep key/door/kill square data
	u16* m_ptileData;
	u16* m_pmapData;
	int  m_CurrentLevel;
	
	void SetupStatsTiles();
	void SetupStatsFonts();
};

#endif

