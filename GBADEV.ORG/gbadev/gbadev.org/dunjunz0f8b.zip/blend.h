/*****************************\
* 	blend.h
*	By staringmonkey
*	Last modified on 11/04/01
\*****************************/

#ifndef BLEND_H
#define BLEND_H

#define MODE_NONE		0x00
#define MODE_BLEND		BIT00	
#define MODE_FADE_IN	BIT01
#define MODE_FADE_OUT	BIT02

#define TARGET1_BG0		BIT00	
#define TARGET1_BG1		BIT01
#define TARGET1_BG2		BIT02	
#define TARGET1_BG3		BIT03	
#define TARGET1_OBJ		BIT04		
#define TARGET1_BD		BIT05

#define TARGET2_BG0		BIT08	
#define TARGET2_BG1		BIT09	
#define TARGET2_BG2		BIT10	
#define TARGET2_BG3		BIT11	
#define TARGET2_OBJ		BIT12	
#define TARGET2_BD		BIT13
#define TARGET2_ALL		BIT08 | BIT09 | BIT10 | BIT11 | BIT12 | BIT13

#define BlendMode(n)	((n) << 6)	

#define Blend(a, b)		REG_COLY = (a) | ((b) << 8)
#define Fade(y)			REG_COLY = (y)


void SleepQ(int i) 
{ 
   int x, y; 
   int c; 
   for (y = 0; y < i; y++) 
   { 
      for (x = 0; x < 4000; x++) 
         c = c + 2; // do something to slow things down 
   } 
} 


//****************************************************************************** 
void fadeout( u32 aWait ) 
{ 
   s8 Phase; 
   REG_BLDMOD = 0 | 1 | 2 | 4 | 8 | 128 | 64 | 32; 
   for( Phase = 0; Phase < 17; Phase++ ) 
   { 
      REG_COLY = Phase; 
      SleepQ( aWait ); 
   } 
} 

//****************************************************************************** 
void fadein( u32 aWait ) 
{ 
   s8 Phase; 
   REG_BLDMOD = 0 | 1 | 2 | 4 | 8 | 128 | 64 | 32; 
   for( Phase = 0; Phase < 16; Phase++ ) 
   { 
      REG_COLY = 16-Phase; 
      SleepQ ( aWait ); 
   } 
} 


#endif
