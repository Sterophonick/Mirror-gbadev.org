/*****************************\
*	sprite.h
*	Original by Dovoto
*	Modified by staringmonkey
*	Last modified on 10/13/01
\*****************************/

#ifndef SPRITE_H
#define SPRITE_H

////////////////Necessary Includes//////////////////
//#include <math.h>		//Math functions
#include "sincosrad.h"
///////////////////Enumerations/////////////////////
//Attribute0 stuff
#define ROTATION_FLAG 		BIT8
#define SIZE_DOUBLE			BIT9
#define MODE_NORMAL     	0x0
#define MODE_TRANSPERANT	BIT10
#define MODE_WINDOWED		BIT11
#define MOSAIC				BIT12
#define COLOR_16			0x0000
#define COLOR_256			BIT13
#define SQUARE				0x0
#define WIDE				BIT14
#define TALL				BIT15

//Attribute1 stuff
#define ROTDATA(n)			((n) << 9)
#define HORIZONTAL_FLIP		BIT12
#define VERTICAL_FLIP		BIT13
#define SIZE_8				0x0
#define SIZE_16				BIT14
#define SIZE_32				BIT15
#define SIZE_64				BIT14 | BIT15

//Attribute2 stuff
#define PRIORITY(n)			((n) << 10)
#define PALETTE(n)			((n) << 12)


///////////////////////Structs///////////////////
typedef struct tagOAMEntry
{
	u16 attribute0;
	u16 attribute1;
	u16 attribute2;
	u16 attribute3;
}OAMEntry,*pOAMEntry;

typedef struct tagRotData
{
		
	u16 filler1[3];
	u16 pa;

	u16 filler2[3];
	u16 pb;	
		
	u16 filler3[3];
	u16 pc;	

	u16 filler4[3];
	u16 pd;
}RotData,*pRotData;

#endif

