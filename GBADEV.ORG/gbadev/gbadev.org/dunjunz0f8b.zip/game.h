// game.h: interface for the CGame class.
//
//////////////////////////////////////////////////////////////////////
#ifndef GAME_H
#define GAME_H


typedef enum GameStatus { QUIT, ALLDEAD, RUNNING, NEXT_LEVEL, COMPLETE, SETUP, PAUSED};

class CGame  
{
public:
	CGame() {};
	virtual ~CGame() {};

	void RenderGraphics(void);
	void UpdatePositions(void);
	void GetInput(void);
	void CheckCollisions(void);
	void Initialisation(void);
	void SetupBeforeLevel(void);
	void Reset(void);

	void DisplayFrontScreen(void);
	void DisplayTitleScreen(void);
	void DisplayMenu(void);
	void DisplayDeadScreen(void);
	void DisplayVictoryScreen(void);

	void CheckForUnpause(void);

	int getTimer() {return m_gametimer;};
	GameStatus m_Status;

private:


	int m_gametimer;
//	void QuickLoad(void); //todo
//	void QuickSave(void); //todo
	int m_HitCloudSprite;
};

#endif

