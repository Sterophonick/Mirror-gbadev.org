// actor.h: interface for the CActor class.
//
//////////////////////////////////////////////////////////////////////



#ifndef ACTOR_H
#define ACTOR_H

#include "gba.h"
#include "sprite.h"

typedef enum Direction { UP, RIGHT, DOWN, LEFT } Direction;
/*
//would like to use this, but doesn't seem to work
Direction& operator++(Direction& d)
{
	return d = (LEFT==d) ? UP : Direction(d+1);
}
*/


typedef enum ActorType { RANGER, BARBARIAN, MAGE, FIGHTER, MONSTER, WEAPON} ActorType;

class CActor  
{
public:
	CActor();
	virtual ~CActor() {};

	bool Move(Direction move_direction);
		
	void Initialisation(void);
	void SetupBeforeLevel(void);

	void Render(void);
	int  getHealth(void){return m_health;};
	void setHealth(int input_health) {m_health=input_health;};
	void alterHealth(int input_health);
	bool WithinCurrentView();
	
	int  getX() {return m_x;};
	int  getY() {return m_y;};
	int  setPos(int x, int y) {m_x = x; m_y = y;};
	void Hide(void);
	bool getFreeze(void) {return m_freeze;};

	OAMEntry* pOAMSprite;
	pRotData  m_rotData;
	int       m_rotindex;

	Direction m_direction;            //direction sprite is moving
	ActorType m_actortype;  
	int       m_key_number_held;
	bool      m_hidden;
	int		  m_ibaseframe;
	
private:


	int CalcOffsetX(void);
	int CalcOffsetY(void);

protected:

	void AllowMove(Direction move_direction);

	void Turn_Right(void);
	void Turn_Left(void);
	void Turn_Around(void);

	void AnimateSprite(void);
	void MoveSprite(void);
	void RotateSprite(void);

	int getTargetX(Direction move_direction);
	int getTargetY(Direction move_direction);

	int  m_move_point; // used for animation
   	s32  m_x_scale;
	s32  m_y_scale;
	int  m_health;
	int  m_x;			   //x position on screen
	int  m_y;             //y position on screen
	bool m_freeze;
};
#endif

