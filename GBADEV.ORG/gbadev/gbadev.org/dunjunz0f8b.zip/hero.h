// hero.h: interface for the CHero class.
//
//////////////////////////////////////////////////////////////////////
#ifndef HERO_H
#define HERO_H

#include "actor.h"
#include "weapon.h"
typedef enum PlayerStatus {EXITING, EXITED, DYING, DEAD, NORMAL} PlayerStatus;

class CHero : public CActor  
{
public:
	CHero(){};
	virtual ~CHero(){};

	void UseMagic(void);
	void Fire(void);
	void Increase_Score(int amount);
	int  Pick_Up_Key(int keynumber);
	void Pick_Up_Item(void);
	void Initialisation(void);
	void SetupBeforeLevel(void);
	void Reset(void);
	void UpdateSideStats(int Offset);
	void setIsDead(bool IsDead);
	bool getIsDead();
	void CheckTileCollisions();

	void alterHealth(int input_health);
	void UpdatePosition(void);
	int  getFrameRate(void);
	bool IsAvailable(void);

	bool Move(Direction move_direction);
	bool getAttack(void) {return m_attack;};
	bool getDefense(void) {return m_defense;};
	bool getIsPlaying(void) {return m_bIsPlaying;};
	void setIsPlaying(bool bPlaying) {m_bIsPlaying = bPlaying;};

	PlayerStatus m_Status;
	CWeapon m_weapons[MAX_NUM_OF_WEAPONS];
private:


	int  m_attack;
	int  m_defense;
	int  m_number_of_weapons; // 1-3

	bool m_bIsPlaying;
//	bool m_holds_cross;
	bool m_holds_boots;
	int  m_score;

};
#endif

