// weapon.cpp: implementation of the CWeapon class.
//
//////////////////////////////////////////////////////////////////////
#include "gba.h"
#include "weapon.h"
#include "map.h"

extern CMap g_LevelMap; 
//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

CWeapon::CWeapon()
{
	m_hidden = true;
	m_actortype = WEAPON;
}


bool CWeapon::Move(Direction move_direction)
{
	// check target square for door
	int Next_tile = g_LevelMap.TileType(getTargetX(move_direction), 
		                                getTargetY(move_direction));

	if(Next_tile == H_DOOR || Next_tile == V_DOOR) // check for doors
	{
		return false; // weapons can't go through doors
	}
	return CActor::Move(move_direction);
}

void CWeapon::UpdatePosition()
{
	if (m_hidden == true) return;// not active

	// kill square mechanism
	if (g_LevelMap.TileType(m_x, m_y) == KILL_SQUARE) 
	{
		if (g_LevelMap.getMetaData(m_x, m_y) < 0)
		{
			// after 20 hits the square disappears
			g_LevelMap.RemoveTile(m_x, m_y);
		}else{
			// kill block - bounced back
			Turn_Around();
			g_LevelMap.setMetaData(m_x, m_y, (g_LevelMap.getMetaData(m_x, m_y))-10); // reduce 'health' of kill block
		}
	}

	bool bMoveAllowed = Move(m_direction);

	if (bMoveAllowed == false) Hide();//didn't move - hit wall

}

// draw weapon to screen
void CWeapon::Render()
{
	RotateSprite();  
	MoveSprite();
}

///////////////RotateSprite///////////////////////
//check for updated rotation and scaling parameters and update accordingly
void CWeapon::RotateSprite()
{

	// weapons are flipped rather than rotated
	//  otherwise too many sprites are being rotated
	pOAMSprite->attribute1 &= ~HORIZONTAL_FLIP;        //back to original unflipped sprite
	pOAMSprite->attribute1 &= ~VERTICAL_FLIP;          //back to original unflipped 

	switch(m_direction)
	{
		case DOWN:
			pOAMSprite->attribute1 |= VERTICAL_FLIP;         //flip the sprite horizontally
		case UP:
			pOAMSprite->attribute2 = m_ibaseframe;
			break;
		case LEFT:
			pOAMSprite->attribute1 |= HORIZONTAL_FLIP;         //flip the sprite horizontally
		case RIGHT:
			pOAMSprite->attribute2 = m_ibaseframe + 8;
			break;
	}
	return;

}
