// actor.cpp: implementation of the CActor class.
//
//////////////////////////////////////////////////////////////////////

#include "actor.h"
#include "monster.h"
#include "hero.h"
#include "map.h"
#include "sprite.h"

extern CMap g_LevelMap; 

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

CActor::CActor()
{
	m_direction = UP;
	m_x_scale = 1<<8;
	m_y_scale = 1<<8;
	m_freeze = false;
	m_hidden = false;
}

void CActor::Initialisation()
{
	m_x = 0;
	m_y = 0;
}

void CActor::SetupBeforeLevel()
{
	m_move_point = 0;
	pOAMSprite->attribute2 = m_ibaseframe; 
}


// actor requests a move in a particular direction
bool CActor::Move(Direction move_direction)
{
	// is moving/animating so don't allow direction change
	// weapons don't have move points
	if (m_move_point != 0 ) return false;
	// is hidden so can't move
	if (m_hidden == true ) return false;

	// check target square for wall
	// nothing can move into a wall
	int Next_tile = g_LevelMap.TileType(getTargetX(move_direction), 
		                                getTargetY(move_direction));
	if (Next_tile == WALL) return false; 

	// reached here so can move
	AllowMove(move_direction);
	if (m_actortype != WEAPON) // (weapons not animated - jump from square to square)
	{
		m_move_point = NUM_MOVE_PTS; // start animation
	}
	return true;
}

// return target x coordinate
int CActor::getTargetX(Direction move_direction)
{
	switch(move_direction){
		case LEFT:
			return m_x-1;
			break;
		case RIGHT:
			return m_x+1;
			break;
		default:
			return m_x;
	}
}

// return target y coordinate
int CActor::getTargetY(Direction move_direction)
{
	switch(move_direction){
		case DOWN:
			return m_y+1;
			break;
		case UP:
			return m_y-1;
			break;
		default:
			return m_y;
	}
}

// update coordinates in movement direction
void CActor::AllowMove(Direction move_direction)
{
	switch(move_direction)
	{
		case UP:
			m_y--;
			break;
		case DOWN:
			m_y++;
			break;
		case LEFT:
			m_x--;
			break;
		case RIGHT:
			m_x++;
			break;
	}
}

void CActor::alterHealth(int input_health)
{
	m_health+=input_health;
	if (m_health > MAX_HEALTH) m_health = MAX_HEALTH; // maximum
	if (m_health < MIN_HEALTH)  m_health = MIN_HEALTH; // minimum
}

// draw actor to screen
void CActor::Render()
{
	AnimateSprite();
	RotateSprite();  
	MoveSprite();
}

////////////////Animate Sprite///////////////////////
///////////Decide on sprite's frame//////////////////
// currently animation is just swapping between two frames //
void CActor::AnimateSprite()
{
	if(m_move_point != 0) // is within animation cycle
	{
		m_move_point--; // decrement animation frame
		
		// swap frames
		if (pOAMSprite->attribute2 == m_ibaseframe)
		{
			pOAMSprite->attribute2 = m_ibaseframe + 8;
		}else{
			pOAMSprite->attribute2 = m_ibaseframe;
		}
	}
}


////////////////MoveSprite///////////////////////
void CActor::MoveSprite()
{
	int screen_position_x;
	int screen_position_y;

	// actor is in the current view and not hidden
	if (WithinCurrentView() && m_hidden == false) 
	{
		// calculate screen position within the current view
		screen_position_x = (m_x % 8) * VIEW_SIZE_X;
		screen_position_y = (m_y % 8) * VIEW_SIZE_Y;

		// Calculate offset for animation
		screen_position_x += CalcOffsetX();
		screen_position_y += CalcOffsetY();

		//Correct if off the left side
		if(screen_position_x < 0)
			screen_position_x = 512 + screen_position_x;
		//Correct if off the right side
		if(screen_position_y < 0)
			screen_position_y = 256 + screen_position_y;

	}else{
		//actor not in view, take off screen
		screen_position_x = 140;
		screen_position_y = 160;
	}

	//update positions
	pOAMSprite->attribute1 &=  0xFE00;	//Clear old X value
	pOAMSprite->attribute1 |=  screen_position_x;		//Set new X value
	
	pOAMSprite->attribute0 &= 0xFF00;	//Clear old Y value
	pOAMSprite->attribute0 |=  screen_position_y;		//Set new Y value

}		

// animates actor between square, moves them by increments in x direction
int CActor::CalcOffsetX()
{
	switch(m_direction){
		case LEFT:
			return (16/NUM_MOVE_PTS)*m_move_point;
			break;
		case RIGHT:
			return -(16/NUM_MOVE_PTS)*m_move_point;
			break;
		default:
			return 0;
	}	
}

// animates actor between square, moves them by increments in y direction
int CActor::CalcOffsetY()
{
	switch(m_direction){
		case DOWN:
			return (16/NUM_MOVE_PTS)*-m_move_point;
			break;
		case UP:
			return -(16/NUM_MOVE_PTS)*-m_move_point;
			break;
		default:
			return 0;
	}	
}


bool CActor::WithinCurrentView()
{
	// calculate whether coordinate are within current view
	return g_LevelMap.WithinCurrentView(m_x, m_y);
}

///////////////RotateSprite///////////////////////
//check for updated rotation and scaling parameters and update accordingly
void CActor::RotateSprite()
{
	s32 pa,pb,pc,pd;
	s32 angle = m_direction*90; // only 4 possible direction

	pa = ((m_x_scale) * (s32)COS[angle])>>8;    //(do my fixed point multiplies and shift back down)
	pb = ((m_y_scale) * (s32)SIN[angle])>>8;
	pc = ((m_x_scale) * (s32)-SIN[angle])>>8;
	pd = ((m_y_scale) * (s32)COS[angle])>>8;

	m_rotData[m_rotindex].pa = pa;  //put them in my data struct
	m_rotData[m_rotindex].pb = pb;
	m_rotData[m_rotindex].pc = pc;
	m_rotData[m_rotindex].pd = pd;

}

void CActor::Turn_Left()
{
	switch (m_direction)
	{
		case DOWN:
			m_direction =  RIGHT;
			break;
		case UP:
			m_direction =  LEFT;
			break;
		case LEFT:
			m_direction =  DOWN;
			break;
		case RIGHT:
			m_direction =  UP;
			break;
		default:
			break;
	}
}

void CActor::Turn_Right()
{
	switch (m_direction)
	{
		case DOWN:
			m_direction = LEFT;
			break;
		case UP:
			m_direction = RIGHT;
			break;
		case LEFT:
			m_direction = UP;
			break;
		case RIGHT:
			m_direction = DOWN;
			break;
		default:
			break;
	}
}

void CActor::Turn_Around()
{
	switch (m_direction)
	{
		case DOWN:
			m_direction = UP;
			break;
		case UP:
			m_direction = DOWN;
			break;
		case LEFT:
			m_direction = RIGHT;
			break;
		case RIGHT:
			m_direction = LEFT;
			break;
		default:
			break;
	}
}

void CActor::Hide()
{
	// hide and remove actor from dungeon
	m_hidden = true;
	m_x = -1;
	m_y = -1;
}
