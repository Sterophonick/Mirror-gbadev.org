// hero.cpp: implementation of the CHero class.
//
//////////////////////////////////////////////////////////////////////
#include "gba.h"
#include "hero.h"
#include "map.h"
#include "monster.h"
#include "print.h"

extern CMonster g_monsters[NUM_OF_MONSTERS];
extern CMap g_LevelMap; 
extern CHero g_players[NUM_OF_PLAYERS]; // player aware of other players
//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

// before anything
void CHero::Initialisation()
{
	m_bIsPlaying = true;
}

// after death
void CHero::Reset()
{
	switch (m_actortype)
	{
		case RANGER:
			m_attack = 2;
			m_defense = 3;
			m_number_of_weapons = 3;
			break;
		case BARBARIAN:
			m_attack = 9;
			m_defense = 4;
			m_number_of_weapons = 1;
			break;
		case MAGE:
			m_attack = 3;
			m_defense = 1;
			m_number_of_weapons = 2;
			break;
		case FIGHTER:
			m_attack = 5;
			m_defense = 6;
			m_number_of_weapons = 2;
			break;
	}
	m_score = 0;
	m_Status = NORMAL;
	m_health = MAX_HEALTH;
	m_freeze = false;

}


// for level startup
void CHero::SetupBeforeLevel()
{
	// players always arranged in same pattern at level startup
	switch(m_actortype)
	{
		case RANGER:
			setPos(level_Starting_x, level_Starting_y);
			m_direction = UP;
			break;
		case BARBARIAN:
			setPos(level_Starting_x+1, level_Starting_y);
			m_direction = DOWN;
			break;
		case MAGE:
			setPos(level_Starting_x, level_Starting_y+1);
			m_direction = RIGHT;
			break;
		case FIGHTER:
			setPos(level_Starting_x + 1, level_Starting_y + 1);
			m_direction = LEFT;
			break;
	}
	
	if (m_Status == DEAD) setIsDead(false); // bring back dead characters

	m_health = MAX_HEALTH;
	m_Status = NORMAL;
	m_hidden = false;
	m_key_number_held = -1;
	m_holds_boots = false;
	CActor::SetupBeforeLevel();
}


// player position is calculated in GetInput
// this just checks/updates status
void CHero::UpdatePosition()
{
	m_freeze = false;
	m_hidden =  false;	
	if (m_bIsPlaying == false) 
	{
		Hide();
		return;
	}
	switch (m_Status)
	{
		case DYING:
			// player is changing through death sequence
			// change between frames, fully dead
			// then change status to DEAD
			m_freeze = true;
			m_direction = UP;
			if (pOAMSprite->attribute2 < 80 && pOAMSprite->attribute2 != 104 )
			{
				pOAMSprite->attribute2 = 80; //  change to skeleton image
			}else if(pOAMSprite->attribute2 == 120){
				m_Status = DEAD; // player dead 
			}else{
				pOAMSprite->attribute2 +=8; //should be 16 but slows it down a bit
			}
			break;
		case EXITING:
			// creates a primative spinning on exit
			// reduce the scale and then rotate each frame
			m_freeze = true;
			if (m_x_scale == 1<<8)
			{
				m_direction = UP;
				m_x_scale = 1<<9;
				m_y_scale = 1<<9;
			}else{
				if(m_direction == UP) m_direction = RIGHT;
				if(m_direction == RIGHT) m_direction = DOWN;
				if(m_direction == DOWN) m_direction = LEFT;
				if(m_direction == LEFT) 
				{
					m_x_scale = 1<<8;
					m_y_scale = 1<<8;
					m_Status = EXITED;
				}
			}		
			break;
		case DEAD:
			m_freeze = true;
			break;
		case EXITED:
			Hide();
			break;
		default:
			break;
	}
}

bool CHero::IsAvailable()
{
	// hero is available for movement
	if (m_bIsPlaying == false || m_Status == DEAD || m_Status == EXITED)
	{
		return false;
	} else {
		return true;
	}

}

// toggle death
void CHero::setIsDead(bool IsDead)
{
	if (IsDead == true)
	{
		// if not already dead, start the dying process
		if (m_Status != DEAD) m_Status = DYING;
		if (m_key_number_held != -1)
		{
			// drop key upon dying, so other characters can continue
			g_LevelMap.DropKey(m_x, m_y, m_key_number_held);
			m_key_number_held = -1;
		}
	}else{
		Reset();
	}
}

bool CHero::getIsDead()
{
	if(m_Status == DEAD)
	{
		return true;
	}else{
		return false;
	}

}

void CHero::alterHealth(int input_health)
{
	CActor::alterHealth(input_health);
	if (m_health == 0) setIsDead(true);
}

// looks through players weapons for those that are hidden 
// this indicates they are not in use
// set them at the characters current position and show them
void CHero::Fire()
{
	for (int wloop = 0; wloop < m_number_of_weapons; wloop++) 
	{
		if (m_weapons[wloop].m_hidden == true)
		{
			// found an unused weapon
			m_weapons[wloop].setPos(m_x, m_y); 
			m_weapons[wloop].m_direction = m_direction;
			m_weapons[wloop].m_hidden = false;
			return; //break loop
		}
	}

}

// kills monsters in current view and reduces health
// some player types have no magic
void CHero::UseMagic()
{
	switch (m_actortype)
	{
		case BARBARIAN:
			return; // no magic
			break;
		case RANGER:
			alterHealth(-6); //reduce hero's health
			break;
		case MAGE:
			alterHealth(-3); //reduce hero's health
			break;
		case FIGHTER:
			return; // no magic
			break;
	}
	// loop through all monsters, if not hidden and in view
	//   kill them!!
	for (int loop = 0; loop < NUM_OF_MONSTERS; loop++) 
	{
		if (g_monsters[loop].m_hidden == false) // not active
		{
			if (g_monsters[loop].WithinCurrentView())
			{
				g_monsters[loop].alterHealth(-100); // instant kill
			}
		}
	}
}

void CHero::Increase_Score(int amount)
{
	m_score+=amount;
	if (m_score > 9999) m_score = 9999; // set maximum
	if (m_score < 0) m_score = 0; // set minimum
}

// pick up key
// sending -1 removes key
// return value is the swapped key
int CHero::Pick_Up_Key(int keynumber)
{
	if (keynumber == -1)
	{
		//remove key
		m_key_number_held = -1;
		return -1;
	} else if (m_key_number_held == -1) {
		// no key so pick up
		m_key_number_held = keynumber;
		return -1;
	} else {
		// already hold key, this will be placed back on floor
		int temp_number = m_key_number_held;
		m_key_number_held = keynumber;
		return temp_number;
	}
}


// detect pickups
// NB: these fire off when the character is ON the square
// events before when a character is about to move happen in
// the CHero clas Move function
void CHero::CheckTileCollisions()
{
	if(m_Status != NORMAL) return; // in case player is dead

	// tile collisions only checked if the player is not moving
	// otherwise the player will pick up every animation frame 
	// potentially keys could swop round every frame.
	if(m_move_point != 0) return; 

	int iReturnedkey;
	switch (g_LevelMap.TileType(m_x, m_y))
	{
		case SPACE: // speeds things up, most tiles are obviously spaces
			break;
		case KEY: // key
			iReturnedkey = Pick_Up_Key(g_LevelMap.getMetaData(m_x, m_y));
			if (iReturnedkey == -1)
			{
				// first key picked up
				g_LevelMap.RemoveTile(m_x, m_y);
			} else {
				//swap keys, set meta data
				g_LevelMap.setMetaData(m_x, m_y, iReturnedkey);
			}
			break;
		case EXIT: // exit
			if (m_Status != EXITED)	m_Status = EXITING;
			break;
		case WALL:	
			// shouldn't happen
			break;
		case KILL_SQUARE: //kill square
			alterHealth(-5);
			break;
		case GENERATOR:
			// no effect
			break;
		// all these squares are items and envoke the Pick_Up_Item() function
		case TELEPORTER:
		case V_DOOR:// gone into door so remove door 
		case H_DOOR: // gone into door so remove door 
		// normal items
		case TREASURE: 
		case CROSS:
		case SWORD:
		case HELMET:
		case FOOD:
		case WEAPONS:
		case POTION:
		case BOOTS:
			Pick_Up_Item();
			break;
		default:
			break;				
	}
}

// query current space and deal with item there
void CHero::Pick_Up_Item()
{
	m_holds_boots = false; // picking up anything negates boots
	switch (g_LevelMap.TileType(m_x, m_y))
	{
		case TREASURE: // treasure
			Increase_Score(20);
			break;
		case CROSS: // cross
		//	m_holds_cross = true;
			for (int x = 0; x < NUM_OF_PLAYERS; x++)
			{
				if (g_players[x].getIsDead())
				{
					g_players[x].setIsDead(false); // resurrect
					break;
				}
			}
			Increase_Score(10);
			break;
		case SWORD: // sword
			if (m_attack != 9) m_attack++;
			Increase_Score(10);
			break;
		case HELMET: // helmet
			if (m_defense != 7) m_defense++;
			Increase_Score(10);
			break;
		case FOOD: // food
			alterHealth(10);
			Increase_Score(5);
			break;
		case WEAPONS: // weapons
			if (m_number_of_weapons != 3) m_number_of_weapons++;
			Increase_Score(10);
			break;	
		case BOOTS:
			m_holds_boots = true;
			Increase_Score(10);
			break;
		case POTION:
			// last digit doubled - eg 43 -> 33, 26 -> 66 etc
			alterHealth((getHealth() - (getHealth()/10)) 
				     + ((getHealth() - (getHealth()/10))*10)); 
			Increase_Score(10);
			break;
		case H_DOOR: // h_door
			// gone into door so remove door and key
			//   the check for current key is carried out during 
			//   the movement sequence
			Pick_Up_Key(-1); // remove key
			Increase_Score(7);
			break;
		case V_DOOR: // v_door
			// gone into door so remove door and key
			Pick_Up_Key(-1); // remove key
			Increase_Score(7);
	}
	// remove the processed tile
	g_LevelMap.RemoveTile(m_x, m_y);
}

// create the hero stats
// the arbitary looking characters denote 8x8 tiles
// I'm using the print functions to put them on the screen
void CHero::UpdateSideStats(int Offset)
{                               

	// print health and score
	PrintInit(17,2+Offset,31,32,0);
	PrintF("\n%d \n%d   \n", getHealth(), m_score);

	// display attack
	PrintChar(21,3+Offset, ' ' + m_attack);
	
	// display defense
	PrintChar(23,1+Offset, ' ' + m_defense);

	// print main attributes 
	PrintInit(21,1+Offset,28,32,0);
	PrintF("  %& \n  \'(");

	// print key symbol
	if(m_key_number_held != -1)	
	{
		PrintChar(21,1+Offset, '!');
	}else {
		PrintChar(21,1+Offset, ' ');
	}
	
	// print speed lightening symbol
	if(m_holds_boots == true)
	{
		PrintChar(21,2+Offset, '$');
	}else {
		PrintChar(21,2+Offset, ' ');
	}

	// print number of weapons
	PrintInit(23,3+Offset,28,32,0);
	switch (m_number_of_weapons) 
	{
		case 1:
			PrintF("23\n45");
			break;
		case 2:
			PrintF("67\n89");
			break;
		case 3:
			PrintF(":;\n<=");
			break;
	}

}

// return the characters speed
int CHero::getFrameRate()
{
	int iframerate = 2;
	if (m_holds_boots == true) iframerate = 1; // extra speed
	return iframerate;
}

// request to move in a certain direction
// return value is whether this is allowed
// first checks for other players, then doors and exit
// then passes control to the generic move function
bool CHero::Move(Direction move_direction)
{

	int ploop;
	if (m_freeze == true) return false; // can't move
	m_direction = move_direction; // always face direction
	
	// players check for other players
	for (ploop = 0; ploop<NUM_OF_PLAYERS; ploop++) // loop through rest of the monsters
	{
		if (!(g_players[ploop].m_Status == DEAD)) // won't collide into skeleton
		{
			if (g_players[ploop].getX() == getTargetX(move_direction)
				&& g_players[ploop].getY() == getTargetY(move_direction))
			{
				//player/player collision!!
				return false;
			}
		}
	}

	// get information about the target square
	int Next_tile = g_LevelMap.TileType(getTargetX(move_direction), 
		                                getTargetY(move_direction));
	int Next_Metadata = g_LevelMap.getMetaData(getTargetX(move_direction), 
		                                       getTargetY(move_direction));

	if(Next_tile == H_DOOR || Next_tile == V_DOOR) // check for doors
	{
		// door/key check, does the metadata of the square,
		// which holds the key number, match the key
		// held by the character
		if (Next_Metadata != m_key_number_held) return false;// can't move - wrong key

	}else if(Next_tile == EXIT)
	{
		// move into exit square
		// actual exiting code is handled during the move itself
		// but must drop key here so other players can use them
		if (m_key_number_held != -1)
		{
			// drop key before exiting, so other characters can continue
			g_LevelMap.DropKey(m_x, m_y, m_key_number_held);
			m_key_number_held = -1;
		}
	}

	// pass control to generic movement
	return CActor::Move(move_direction);
}
