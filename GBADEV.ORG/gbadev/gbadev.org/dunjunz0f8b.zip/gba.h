// gba.h by eloist 

#ifndef GBA_HEADER
#define GBA_HEADER

//*****************************************************************************
// defines
#define  level_WIDTH         64 // in blocks
#define  level_HEIGHT        96 // in blocks
#define  level_Starting_x    11 //in tiles
#define  level_Starting_y    11 //in tiles
#define  NUMBERLEVELS        3
#define  NUM_OF_MONSTERS     24
#define  NUM_OF_GENERATORS   8
#define  NUM_OF_PLAYERS      4
#define  MAX_NUM_OF_WEAPONS  3
#define  NUM_OF_WEAPON_SPRITES NUM_OF_PLAYERS * MAX_NUM_OF_WEAPONS
#define  VIEW_SIZE_X         16 //in blocks
#define  VIEW_SIZE_Y         16 //in blocks
#define  DISPLAY_X_OFFSET    16
#define  DISPLAY_Y_OFFSET	 16
#define  NUM_MOVE_PTS		 3
#define  FADESPEED			 20
#define  MAX_HEALTH			 99
#define  MIN_HEALTH          0
#define  MAX_KEYS_PER_LEVELS 20

// block defines
#define  H_DOOR      0x06
#define  V_DOOR      0x04
#define  WALL        0x02
#define  SPACE       0x00
#define  GENERATOR   0x18
#define  CROSS       0x34
#define  KEY         0x30
#define  FOOD        0x32
#define  SWORD       0x1E
#define  WEAPONS     0x22
#define  HELMET      0x36
#define  EXIT        0x38
#define  KILL_SQUARE 0x1A
#define  TREASURE    0x08
#define  BOOTS       0x48
#define  TELEPORTER  0x40
#define  POTION      0x4A

/*--------------typedefs-----------------------*/

typedef unsigned char u8;
typedef unsigned short u16;
typedef unsigned long u32;

typedef signed char s8;
typedef signed short s16;
typedef signed long s32;

typedef unsigned char byte;
typedef unsigned short hword;
typedef unsigned long word;

typedef volatile unsigned  char vu8;
typedef volatile unsigned  short vu16;
typedef volatile unsigned  long vu32;

typedef volatile signed char vs8;
typedef volatile signed short vs16;
typedef volatile signed long vs32;

typedef void (*fp)(void);  //a pointer to a void function

#define NULL 0


#define IN_EWRAM __attribute__ ((section (".ewram")))
#define IN_IWRAM __attribute__ ((section (".iwram")))


#define RGB16(r,g,b)  ((r)+(g<<5)+(b<<10))

/////////////////Math Declarations////////////
#define FIXED s32								//Fixed Point variables
#define PI 3.14159								//Pi
#define RADIAN(n) (((float)n)/(float)180*PI)	//Convert radions->degrees

#define OAMMem  		((u32*)0x7000000)
#define VideoBuffer 	((u16*)0x6000000)
#define OAMData			((u16*)0x6010000)
#define BGPaletteMem 	((u16*)0x5000000)
#define OBJPaletteMem 	((u16*)0x5000200)

#define REG_IFCHECKBUFF   *(vu16*)0x3007FF8
#define REG_INTERUPT   (*(u32*)0x3007FFC)
#define REG_DISPCNT    *(vu32*)0x4000000
#define REG_DISPCNT_L  *(vu16*)0x4000000
#define REG_DISPCNT_H  *(vu16*)0x4000002
#define REG_DISPSTAT   *(vu16*)0x4000004
#define REG_VCOUNT     *(vu16*)0x4000006
#define REG_BG0CNT     *(vu16*)0x4000008
#define REG_BG1CNT     *(vu16*)0x400000A
#define REG_BG2CNT     *(vu16*)0x400000C
#define REG_BG3CNT     *(vu16*)0x400000E
#define REG_BG0HOFS    *(vu16*)0x4000010
#define REG_BG0VOFS    *(vu16*)0x4000012
#define REG_BG1HOFS    *(vu16*)0x4000014
#define REG_BG1VOFS    *(vu16*)0x4000016
#define REG_BG2HOFS    *(vu16*)0x4000018
#define REG_BG2VOFS    *(vu16*)0x400001A
#define REG_BG3HOFS    *(vu16*)0x400001C
#define REG_BG3VOFS    *(vu16*)0x400001E
#define REG_BG2PA      *(vu16*)0x4000020
#define REG_BG2PB      *(vu16*)0x4000022
#define REG_BG2PC      *(vu16*)0x4000024
#define REG_BG2PD      *(vu16*)0x4000026
#define REG_BG2X       *(vu32*)0x4000028
#define REG_BG2X_L     *(vu16*)0x4000028
#define REG_BG2X_H     *(vu16*)0x400002A
#define REG_BG2Y       *(vu32*)0x400002C
#define REG_BG2Y_L     *(vu16*)0x400002C
#define REG_BG2Y_H     *(vu16*)0x400002E
#define REG_BG3PA      *(vu16*)0x4000030
#define REG_BG3PB      *(vu16*)0x4000032
#define REG_BG3PC      *(vu16*)0x4000034
#define REG_BG3PD      *(vu16*)0x4000036
#define REG_BG3X       *(vu32*)0x4000038
#define REG_BG3X_L     *(vu16*)0x4000038
#define REG_BG3X_H     *(vu16*)0x400003A
#define REG_BG3Y       *(vu32*)0x400003C
#define REG_BG3Y_L     *(vu16*)0x400003C
#define REG_BG3Y_H     *(vu16*)0x400003E
#define REG_WIN0H      *(vu16*)0x4000040
#define REG_WIN1H      *(vu16*)0x4000042
#define REG_WIN0V      *(vu16*)0x4000044
#define REG_WIN1V      *(vu16*)0x4000046
#define REG_WININ      *(vu16*)0x4000048
#define REG_WINOUT     *(vu16*)0x400004A
#define REG_MOSAIC     *(vu32*)0x400004C
#define REG_MOSAIC_L   *(vu32*)0x400004C
#define REG_MOSAIC_H   *(vu32*)0x400004E
#define REG_BLDMOD     *(vu16*)0x4000050
#define REG_COLV      *(vu16*)0x4000052
#define REG_COLY      *(vu16*)0x4000054
#define REG_SG10       *(vu32*)0x4000060
#define REG_SG10_L     *(vu16*)0x4000060
#define REG_SG10_H     *(vu16*)0x4000062
#define REG_SG11       *(vu16*)0x4000064
#define REG_SG20       *(vu16*)0x4000068
#define REG_SG21       *(vu16*)0x400006C
#define REG_SG30       *(vu32*)0x4000070
#define REG_SG30_L     *(vu16*)0x4000070
#define REG_SG30_H     *(vu16*)0x4000072
#define REG_SG31       *(vu16*)0x4000074
#define REG_SG40       *(vu16*)0x4000078
#define REG_SG41       *(vu16*)0x400007C
#define REG_SGCNT0     *(vu32*)0x4000080
#define REG_SGCNT0_L   *(vu16*)0x4000080
#define REG_SGCNT0_H   *(vu16*)0x4000082
#define REG_SGCNT1     *(vu16*)0x4000084
#define REG_SGBIAS     *(vu16*)0x4000088
#define REG_SGWR0      *(vu32*)0x4000090
#define REG_SGWR0_L    *(vu16*)0x4000090
#define REG_SGWR0_H    *(vu16*)0x4000092
#define REG_SGWR1      *(vu32*)0x4000094
#define REG_SGWR1_L    *(vu16*)0x4000094
#define REG_SGWR1_H    *(vu16*)0x4000096
#define REG_SGWR2      *(vu32*)0x4000098
#define REG_SGWR2_L    *(vu16*)0x4000098
#define REG_SGWR2_H    *(vu16*)0x400009A
#define REG_SGWR3      *(vu32*)0x400009C
#define REG_SGWR3_L    *(vu16*)0x400009C
#define REG_SGWR3_H    *(vu16*)0x400009E
#define REG_SGFIFOA    ((vu32*)0x40000A0)
#define REG_SGFIFOA_L  *(vu16*)0x40000A0
#define REG_SGFIFOA_H  *(vu16*)0x40000A2
#define REG_SGFIFOB    ((vu32*)0x40000A4)
#define REG_SGFIFOB_L  *(vu16*)0x40000A4
#define REG_SGFIFOB_H  *(vu16*)0x40000A6
#define REG_DMA0SAD     *(vu32*)0x40000B0
#define REG_DMA0SAD_L   *(vu16*)0x40000B0
#define REG_DMA0SAD_H   *(vu16*)0x40000B2
#define REG_DMA0DAD     *(vu32*)0x40000B4
#define REG_DMA0DAD_L   *(vu16*)0x40000B4
#define REG_DMA0DAD_H   *(vu16*)0x40000B6
#define REG_DMA0CNT     *(vu32*)0x40000B8
#define REG_DMA0CNT_L   *(vu16*)0x40000B8
#define REG_DMA0CNT_H   *(vu16*)0x40000BA
#define REG_DMA1SAD     *(vu32*)0x40000BC
#define REG_DMA1SAD_L   *(vu16*)0x40000BC
#define REG_DMA1SAD_H   *(vu16*)0x40000BE
#define REG_DMA1DAD     *(vu32*)0x40000C0
#define REG_DMA1DAD_L   *(vu16*)0x40000C0
#define REG_DMA1DAD_H   *(vu16*)0x40000C2
#define REG_DMA1CNT     *(vu32*)0x40000C4
#define REG_DMA1CNT_L   *(vu16*)0x40000C4
#define REG_DMA1CNT_H   *(vu16*)0x40000C6
#define REG_DMA2SAD     *(vu32*)0x40000C8
#define REG_DMA2SAD_L   *(vu16*)0x40000C8
#define REG_DMA2SAD_H   *(vu16*)0x40000CA
#define REG_DMA2DAD     *(vu32*)0x40000CC
#define REG_DMA2DAD_L   *(vu16*)0x40000CC
#define REG_DMA2DAD_H   *(vu16*)0x40000CE
#define REG_DMA2CNT     *(vu32*)0x40000D0
#define REG_DMA2CNT_L   *(vu16*)0x40000D0
#define REG_DMA2CNT_H   *(vu16*)0x40000D2
#define REG_DMA3SAD     *(vu32*)0x40000D4
#define REG_DMA3SAD_L   *(vu16*)0x40000D4
#define REG_DMA3SAD_H   *(vu16*)0x40000D6
#define REG_DMA3DAD     *(vu32*)0x40000D8
#define REG_DMA3DAD_L   *(vu16*)0x40000D8
#define REG_DMA3DAD_H   *(vu16*)0x40000DA
#define REG_DMA3CNT     *(vu32*)0x40000DC
#define REG_DMA3CNT_L   *(vu16*)0x40000DC
#define REG_DMA3CNT_H   *(vu16*)0x40000DE
#define REG_TM0D       *(vu16*)0x4000100
#define REG_TM0CNT     *(vu16*)0x4000102
#define REG_TM1D       *(vu16*)0x4000106
#define REG_TM2D       *(vu16*)0x4000108
#define REG_TM2CNT     *(vu16*)0x400010A
#define REG_TM3D       *(vu16*)0x400010C
#define REG_TM3CNT     *(vu16*)0x400010E
#define REG_SCD0       *(vu16*)0x4000120
#define REG_SCD1       *(vu16*)0x4000122
#define REG_SCD2       *(vu16*)0x4000124
#define REG_SCD3       *(vu16*)0x4000126
#define REG_SCCNT      *(vu32*)0x4000128
#define REG_SCCNT_L    *(vu16*)0x4000128
#define REG_SCCNT_H    *(vu16*)0x400012A
#define REG_P1         *(vu16*)0x4000130
#define REG_P1CNT      *(vu16*)0x4000132
#define REG_R          *(vu16*)0x4000134
#define REG_HS_CTRL    *(vu16*)0x4000140
#define REG_JOYRE      *(vu32*)0x4000150
#define REG_JOYRE_L    *(vu16*)0x4000150
#define REG_JOYRE_H    *(vu16*)0x4000152
#define REG_JOYTR      *(vu32*)0x4000154
#define REG_JOYTR_L    *(vu16*)0x4000154
#define REG_JOYTR_H    *(vu16*)0x4000156
#define REG_JSTAT      *(vu32*)0x4000158
#define REG_JSTAT_L    *(vu16*)0x4000158
#define REG_JSTAT_H    *(vu16*)0x400015A
#define REG_IE         *(vu16*)0x4000200
#define REG_IF         *(vu16*)0x4000202
#define REG_WSCNT      *(vu16*)0x4000204
#define REG_IME        *(vu16*)0x4000208
#define REG_PAUSE      *(vu16*)0x4000300

#define BIT0 1
#define BIT1 (1<<1)
#define BIT2 (1<<2)
#define BIT3 (1<<3)
#define BIT4 (1<<4)
#define BIT5 (1<<5)
#define BIT6 (1<<6)
#define BIT7 (1<<7)
#define BIT8 (1<<8)
#define BIT9 (1<<9)
#define BIT10 (1<<10)
#define BIT11 (1<<11)
#define BIT12 (1<<12)
#define BIT13 (1<<13)
#define BIT14 (1<<14)
#define BIT15 (1<<15)
#define BIT16 (1<<16)
#define BIT17 (1<<17)
#define BIT18 (1<<18)
#define BIT19 (1<<19)
#define BIT20 (1<<20)
#define BIT21 (1<<21)
#define BIT22 (1<<22)
#define BIT23 (1<<23)
#define BIT24 (1<<24)
#define BIT25 (1<<25)
#define BIT26 (1<<26)
#define BIT27 (1<<27)
#define BIT28 (1<<28)
#define BIT29 (1<<29)
#define BIT30 (1<<30)
#define BIT31 (1<<31)

/*---------------------------DMA Defines (Day 5)----------------------*/
#ifndef DMA_H
#define DMA_H

//these defines let you control individual bit in the control register

#define DMA_ENABLE						0x80000000
#define DMA_INTERUPT_ENABLE				0x40000000
#define DMA_TIMEING_IMMEDIATE			0x00000000
#define DMA_TIMEING_VBLANK				0x10000000
#define DMA_TIMEING_HBLANK				0x20000000
#define DMA_TIMEING_SYNC_TO_DISPLAY		0x30000000
#define DMA_TIMEING_DSOUND				0x30000000
#define DMA_16							0x00000000
#define DMA_32							0x04000000
#define DMA_REPEATE						0x02000000
#define DMA_SOURCE_INCREMENT			0x00000000
#define DMA_SOURCE_DECREMENT			0x00800000
#define DMA_SOURCE_FIXED				0x01000000
#define DMA_DEST_INCREMENT				0x00000000
#define DMA_DEST_DECREMENT				0x00200000
#define DMA_DEST_FIXED					0x00400000
#define DMA_DEST_RELOAD					0x00600000

//these defines group common options to save typing. You may notice that I don�t have to include the option to increment the source and address register as that is the default.

#define DMA_32NOW      (DMA_ENABLE | DMA_TIMEING_IMMEDIATE |DMA_32) 
#define DMA_16NOW	   (DMA_ENABLE | DMA_TIMEING_IMMEDIATE |DMA_16) 




#endif //end ifdef DMA_H

/*--------------------------------------------------------------------*/


/*----------------Screen and Background defines (Day 1-2, 4) ---------------*/
#ifndef SCREENMODE_H
#define SCREENMODE_H

///// REG_DISPCNT defines

#define MODE_0			0x0
#define MODE_1			0x1
#define MODE_2			0x2
#define MODE_3			0x3
#define MODE_4			0x4
#define MODE_5			0x5

#define BACKBUFFER		0x10
#define H_BLANK_OAM		0x20 

#define OBJ_MAP_2D		0x0
#define OBJ_MAP_1D		0x40

#define FORCE_BLANK		0x80

#define BG0_ENABLE		0x100
#define BG1_ENABLE		0x200 
#define BG2_ENABLE		0x400
#define BG3_ENABLE		0x800
#define OBJ_ENABLE		0x1000 

#define WIN1_ENABLE		0x2000 
#define WIN2_ENABLE		0x4000
#define WINOBJ_ENABLE	0x8000


///////SetMode Macro
#define SetMode(mode) REG_DISPCNT = (mode) 

///
///BGxCNT defines ///
#define BG_MOSAIC_ENABLE		0x40
#define BG_COLOR256				0x80
#define BG_COLOR16				0x0

#define CharBaseBlock(n)		(((n)*0x4000)+0x6000000)
#define ScreenBaseBlock(n)		(((n)*0x800)+0x6000000)

#define CHAR_SHIFT				2
#define SCREEN_SHIFT			8
#define TEXTBG_SIZE_256x256		0x0
#define TEXTBG_SIZE_256x512		0x8000
#define TEXTBG_SIZE_512x256		0x4000
#define TEXTBG_SIZE_512x512		0xC000

#define ROTBG_SIZE_128x128		0x0
#define ROTBG_SIZE_256x256		0x4000
#define ROTBG_SIZE_512x512		0x8000
#define ROTBG_SIZE_1024x1024	0xC000

#define WRAPAROUND              0x1

#endif


/*----------------Keypad defines ----------------------------*/
#ifndef KEYS_H
#define KEYS_H


//////////////////Enumerations////////////////////
#define KEY_A 			BIT0
#define KEY_B 			BIT1
#define KEY_SELECT		BIT2
#define KEY_START 		BIT3
#define KEY_RIGHT 		BIT4
#define KEY_LEFT 		BIT5
#define KEY_UP 			BIT6
#define KEY_DOWN 		BIT7
#define KEY_R			BIT8
#define KEY_L 			BIT9

///////////////////Globals/////////////////////////
extern volatile u32* KEYS;

////////////////Functions Prototypes////////////////

#endif
/*--------------------------------------------------------------------*/


/*--------------A random Number generator I stole from someone-----------*/
//commented out but feel free to put it in.

// extern "C" void r256init(void);
// extern "C" unsigned short r256(void);
//this is the random number generator Just put it in your code somewere 
//(rand.cpp mabey)
//Just call init to turn it on and mabey call it a few times while waiting for
//a keypress and it should be halfway random by the time you go to use it


/*
unsigned short r256table[256];
unsigned char r256index;

void r256init(void) {
	int i,j,msb;
	j=42424;
	for(i=0;i<256;i++){
		r256table[i]=(unsigned short)(j=j*65539);
	}
	msb=0x8000;
	j=0;
	for(i=0;i<16;i++) {
		j=i*5+3;
		r256table[j]|=msb;
		r256table[j+1]&=~msb;
		msb>>=1;
	}
}

unsigned short r256(void) {
	int r;
	r=r256table[(r256index+103)&255]^r256table[r256index];
	r256table[r256index++]=r;
	return r;
}	

*/
/*---------------------------------------------------------------------*/
#endif //endif GBA_H

