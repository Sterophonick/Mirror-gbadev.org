=============================================
==   Dunjunz for GBA
==
==     by: Daniel Collier - 12th May 2003
==         cheese_block@yahoo.com
==
=============================================

Originally for the BBC Micro, released in 1987 by Julian Avis. One of my all time favourites,
many a happy hour bunched around the keyboard with friends exploring the deeper dungeons!
Rewritten to practise my GBA programming. Haven't been able to find out a lot about 
the original author. Hope he doesn't mind me writing a conversion of his work. 
Love to hear from him if he's out there!

Any comments or constructive critisism would be appreciated, email me as above. 
I've borrowed code from other projects and tutorials.

Version Release
========
1.0 - first version

Known Bugs
========
- Keys on death/exit level - with the original game you could have more than one key
  dropped in a square, ie if two characters died in the same square and dropped keys there
  the first key won't be useable!
- Monsters should bounce off a player not pass through, but still reduce health

TODO List
========
- Add the rest of the levels - currently only goes up to level 3
  Perhaps there is a way of extracting them from the original directly?
- Add the chalice - I never managed to complete dunjunz, so I never saw what the
  chalice looks like. If anyone has a screen shot of it I'd love to put it in
  otherwise I'll make something up later ;-)
- For some reason my BBC emulator (BeebEm 1.4) doesn't let me get past the first level
  So I also don't have the images for the boots of speed, the teleporter or the potion
- Because of the above I haven't been able to work out exactly how the teleporters work
  can't remember from when I used to play
- Sound - currently none at all, going to look for a BBC emulator that will let you save
  out the sound
- Quick Save/Load functionality
- Animated tiles as with the original game
- Teleporters - currently don't work
- Title screen flashes - original has little flashes on the title page
- Improve character animation - add animation when firing weapon

Controls
========
D-Pad                - Move Character
A Button             - Fire
B Button             - Magic
Left/Right Buttons   - Rotate through characters

Start Button         - Pause

Please see the included 'Original Dunjunz rules.txt' for the rules