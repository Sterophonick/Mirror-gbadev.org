// Map.cpp: implementation of the CMap class.
//
//////////////////////////////////////////////////////////////////////
#include "gba.h"
#include "map.h"

#include "levelmaps.h"
#include "palette_tile.h"
#include "sidetiles.h"
#include "font.h"
#include "print.h"

//for fast memory copy
// use for getting graphics into memory
void DMA_Copy(u8 channel, void* source, void* dest, u32 WordCount, u32 mode)
{
	switch (channel)
	{
		case 0: 
			REG_DMA0SAD = (u32)source;
			REG_DMA0DAD = (u32)dest;			
			REG_DMA0CNT = WordCount | mode;
			break;
		case 1:
			REG_DMA1SAD = (u32)source;
			REG_DMA1DAD = (u32)dest;
			REG_DMA1CNT = WordCount | mode;
			break;
		case 2:
			REG_DMA2SAD = (u32)source;
			REG_DMA2DAD = (u32)dest;
			REG_DMA2CNT = WordCount | mode;
			break;

		case 3:
			REG_DMA3SAD = (u32)source;
			REG_DMA3DAD = (u32)dest;
			REG_DMA3CNT = WordCount | mode;
			break;

	}
}

// alter a square to a space
void CMap::RemoveTile(int x, int y)
{
	m_levelcopy[((y*(level_WIDTH))+(x))*2] = 0; 
	m_levelcopy[(((y*(level_WIDTH))+(x))+level_WIDTH/2)*2] = 0;
	m_levelcopy[(((y*(level_WIDTH))+(x))*2)+1] = 0; 
	m_levelcopy[((((y*(level_WIDTH))+(x))+level_WIDTH/2)*2)+1] = 0;
}

// allow player to drop key on exiting and on death
void CMap::DropKey(int x, int y, int keynumber)
{
	m_levelcopy[((y*(level_WIDTH))+(x))*2] = 0x30; 
	m_levelcopy[(((y*(level_WIDTH))+(x))*2)+1] = 0x31; 
	m_levelcopy[(((y*(level_WIDTH))+(x))+level_WIDTH/2)*2] = 0x3C;
	m_levelcopy[((((y*(level_WIDTH))+(x))+level_WIDTH/2)*2)+1] = 0x3D;
	setMetaData(x, y, keynumber); // key held in metadata
}

// draws the current view of the dungeon
// normal view size will be 8 * 8
//level1_WIDTH and level1_HEIGHT are TILE NUMBER!!! (32 * 32)
void CMap::RenderGraphics(int gametime)
{
	// NB - took a while to sort this.
	// need to remember that the rows are devided by 2 
	//  as it's a 16 bit copy, so two blocks are copied a time

	u16 loop = 0;
	u16* temp;      //temporary storage pointer
//	u8 tiletype;
	//load the map image data
	temp = (u16*)m_levelcopy;

	for(int y=m_View_Current_y*VIEW_SIZE_Y; y<(m_View_Current_y*VIEW_SIZE_Y)+VIEW_SIZE_Y; y++)
	{
		for(int x=m_View_Current_x*(VIEW_SIZE_X/2); x<(m_View_Current_x*(VIEW_SIZE_X/2))+(VIEW_SIZE_X/2); x++)
		{

			m_pmapData[loop] = temp[(y*(level_WIDTH/2))+(x)];
			/*
			// idea for animating the tiles
			// not particularly well coded
			tiletype = temp[(y*(level_WIDTH/2))+(x)];
			if (tiletype == TREASURE || tiletype == 0x14)
			{
				if (gametime % 2 == 0)
				{
					m_pmapData[loop] = temp[(y*(level_WIDTH/2))+(x)];
				}else{
					m_pmapData[loop] = temp[(y*(level_WIDTH/2))+(x)] + 2;
				}
			}else if (tiletype == KILL_SQUARE || tiletype == 0x26) 
			{
				if (gametime % 2 == 0)
				{
					m_pmapData[loop] = temp[(y*(level_WIDTH/2))+(x)];
				}else{
					m_pmapData[loop] = temp[(y*(level_WIDTH/2))+(x)] + 2;
				}
			}else{
				m_pmapData[loop] = temp[(y*(level_WIDTH/2))+(x)];
			}

			*/
			loop++;
		}
		loop+=(level_WIDTH-VIEW_SIZE_X)/2;
	}
}

// copies tiles into memory
// runs once at the start of program
void CMap::Initialisation()
{

    //Let us set up the backgroud two structure and enable the background
	REG_BG2CNT = BG_COLOR256 | ROTBG_SIZE_512x512 | (30 << SCREEN_SHIFT) | (0 << CHAR_SHIFT);

	//Point to map data
	m_pmapData = (u16*)ScreenBaseBlock(30);

	//load the background palette into memory
	DMA_Copy(3,(void*)tilesPalette,(void*)BGPaletteMem,256,DMA_16NOW);

	//load tile image data
	DMA_Copy(3,(void*)exptilesData,(void*)CharBaseBlock(0),(tiles_WIDTH * tiles_HEIGHT)/4,DMA_32NOW);

	SetupStatsTiles();
	SetupStatsFonts();

}


//runs once to set up stats tiles
void CMap::SetupStatsTiles()
{

	REG_BG1CNT = BG_COLOR256 | TEXTBG_SIZE_256x256 | (28 << SCREEN_SHIFT) | (1 << CHAR_SHIFT) ;
	
	//copy in the tile data for our font
	DMA_Copy(3,(void*)sidetilesData,(void*)CharBaseBlock(1),(sidetiles_WIDTH*sidetiles_HEIGHT)/4,DMA_32NOW);

	//stat back ground is slightly off centre so the defence is in the middle of the shield icon
	REG_BG1VOFS = 3;
	REG_BG1HOFS = 4;

}

//runs once to set up main font tiles
void CMap::SetupStatsFonts()
{

	REG_BG0CNT = BG_COLOR256 | ROTBG_SIZE_512x512 | (31 << SCREEN_SHIFT) | (2 << CHAR_SHIFT) ;
	
	//copy in the tile data for our font
	DMA_Copy(3,(void*)fontData,(void*)CharBaseBlock(2),font_HEIGHT * font_WIDTH/4,DMA_32NOW);
	
	PrintInit(0,0,31,32,0);
	PrintSetWindow(50,50,140,140);
}


//runs before each level
// loads map dependent on CurrentLevel
void CMap::SetupBeforeLevel()
{
	//load the map image data into changable copy
	int keypos = 0;
	int doornum = 1;
	for(int loop = 0; loop < level_WIDTH * level_HEIGHT; loop++)
	{
		m_levelcopy[loop] = level[m_CurrentLevel][loop];
		
		if (m_levelcopy[loop] == KEY) //key
		{
			// key square, load meta data
			m_levelMetaData[loop] = key_to_door_map_level[m_CurrentLevel][keypos];
			keypos++;
		} else if (m_levelcopy[loop] == V_DOOR || m_levelcopy[loop] == H_DOOR) //doors
		{
			// door, load meta data
			m_levelMetaData[loop] = doornum;
			doornum++;
		}else if (m_levelcopy[loop] == KILL_SQUARE) //kill square
		{
			// kill square square, load 'health' of square
			m_levelMetaData[loop] = 99;
		}
	}

}

// checks that the sent coordinates are within the current game view
//   so you can calculate whether a monster should be displayed
bool CMap::WithinCurrentView(int x, int y)
{
	// calculate current view
	int View_Actor_Current_x = x / (VIEW_SIZE_X/2);
	int View_Actor_Current_y = y / (VIEW_SIZE_Y/2);

	if (View_Actor_Current_x == m_View_Current_x
		&& View_Actor_Current_y == m_View_Current_y)
	{
		return true;
	}else{
		return false;
	}
}

// recalculate current view based on characters position
void CMap::UpdateView(int char_pos_x, int char_pos_y)
{
	m_View_Current_x = char_pos_x / (VIEW_SIZE_X/2);
	m_View_Current_y = char_pos_y / (VIEW_SIZE_Y/2);

}

// return the type of square at given coordinates
// NB: GAME coordinates are for ONE location
//     but a square taken 4 tiles
u8 CMap::TileType(int x, int y)
{
	return m_levelcopy[(y*(level_WIDTH*2))+(x*2)];
}

// metadata holds extra information about a square
// eg a key number, the 'health' left in a kill square
int CMap::getMetaData(int x, int y)
{
	return m_levelMetaData[(y*(level_WIDTH*2))+(x*2)];
}
void CMap::setMetaData(int x, int y, int value)
{
	m_levelMetaData[(y*(level_WIDTH*2))+(x*2)] = value;
}
