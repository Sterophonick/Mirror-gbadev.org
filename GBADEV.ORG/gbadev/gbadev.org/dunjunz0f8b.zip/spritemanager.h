// spritemanager.h: interface for the CSpriteMan class.
//
//////////////////////////////////////////////////////////////////////
#ifndef SPRITE_MANAGER_H
#define SPRITE_MANAGER_H

#include "game.h"
#include "monster.h"
#include "hero.h"
#include "map.h"

class CSpriteMan
{
public:
	CSpriteMan() {};
	virtual ~CSpriteMan() {};

	void Initialisation();
	void SetupBeforeLevel();
	void Reset();
	void CheckCollisions();
	void GetInput();
	void UpdatePositions();
	
	void RenderGraphics();
	void HideSprites();
	int  getCurrentPlayer() {return m_CurrentPlayer;};
private:
	void CheckTileCollisions();
	void CheckActorCollisions();

	void CopyOAM(void);
	int  m_CurrentPlayer;
	void GetAvailableCharacter(int step);
	void UpdateSideStats();
	void InitializeSprites(void);

	bool CheckForCollision(CActor* actor1, CActor* actor2);
	void CheckGameStatus();
	bool AllCharactersExited();
	bool HasTheQuestFailed();
};
#endif

