#ifndef PRINT_H
#define PRINT_H

extern void PrintSetWindow(int x1, int y1, int x2, int y2);
extern void PrintInit(int x, int y, int BB, int w, int offset);
extern void Print(int x, int y, char* z);
extern void PrintSet(int x, int y);
extern void Print(char* z);
extern void PrintChar(char c);
extern void PrintChar(int x, int y, char c);
extern void PrintInt(int i);
extern void PrintInt(int x, int y, int i);
extern void PrintHex(int i);
extern void PrintHex(int x, int y, int i);
extern void PrintF(const char* z,...);
extern void ClearText(void);

#endif
