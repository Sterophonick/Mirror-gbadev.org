MERCURY STORM v1.2
==================

Nicholas Scheltema 2005, 2006

PDROMS.DE coding competition 3 - April 2005
www.pdroms.de


Release Information
-------------------

This is the second release of Mercury Storm, the first being the competition
entry. There are a few additions to this updated version, the more obvious
being the upgradable weapons and the little intro sequence. The less obvious
begin a few AI and collision detection fixes, improved targetting for the
homing missiles and a litte graphic effect fix. See the history section for
more detail.

You can distribute this game as much as you want as long as it remains
unmodified from this realease and comes with this readme.txt


About the Game
--------------

It's a platform-shooter. You control the main character Mercury and try
to reach the end of the 5 levels to defeat the boss.

There are 3 weapons available:

 - Spray shot, fires a wide spray of shots
   Acquired from the [S] pickup

 - Laser shot, fires a straight line of laser shots
   in rapid succession. Acquired from the [L] pickup

 - Homing missiles, slow, but fires little rockets that
   chase after enemies. Acquired from the [H] pickup

The game automatically saves whenever you complete a level.
The "continue" option on the title screen lets you continue
where you left off. Selecting "start new game" will erase
the save.


Controls
--------

                   A - jump
                   B - shoot
directional controls - move player, aim

If you push against a wall while you are airborn, Mercury will cling
on to the wall, enabling you to kick-jump off it. By rapidly kick-
jumping off walls over and over again you can climb up them. It is 
necessary to master this to be able to complete the levels.

Holding down the UP or DOWN button will cause Mercury to aim up or
down. You can do this airborn, and while clinging to walls.

Sound
-----

Mercury Storm uses the non-commercial version of Krawall for all sound
and music playing. To find out more about it, go to:

	http://mind.riot.org/krawall/


Hardware/Emulators
------------------

Mercury Storm ran perfectly on Visual Boy Advance 1.7.1, which was used
during it's development.

Mercury Storm is UNTESTED on the real GBA hardware, since I don't have
it.


Contact
-------

email me at: ndbscheltema !AT! yahoo !DOT! com


History
-------

v1.2 fixes/updates:

Rain layer ordering got mucked up before release. 
	- Fixed. Rain over all BG and OAM.
Collisions with final boss improved. 
	- Bounding box on boss smaller, looks better :)
	- Can now destroy right-moving missiles.
Homing targetting modified.
	- Missile finds a target at firing, not every tick.
Weapons upgradable.
	- Getting the same weapon twice upgrades it.
	- Spread shot has rapid fire.
	- Laser fire includes extra 'photon' spread shots.
	- Homing fires two missiles.
Added a nice little intro
	- Additional graphics & music


Credits
-------

Programming:	
     Design:
      Music:
   Graphics: Nicholas Scheltema

Uses the non-commercial Krawall Sound System. See above for weblink.
