
 __                   __      __               _____            __    __
/\ \       __        /\ \    /\ \__           /\  __`\         /\ \__/\ \
\ \ \     /\_\     __\ \ \___\ \ ,_\   ____   \ \ \/\ \  __  __\ \ ,_\ \ \
 \ \ \  __\/\ \  /'_ `\ \  _ `\ \ \/  /',__\   \ \ \ \ \/\ \/\ \\ \ \/\ \ \
  \ \ \_\ \\ \ \/\ \_\ \ \ \ \ \ \ \_/\__, `\   \ \ \_\ \ \ \_\ \\ \ \_\ \_\
   \ \____/ \ \_\ \____ \ \_\ \_\ \__\/\____/    \ \_____\ \____/ \ \__\\/\_\
    \/___/   \/_/\/____\ \/_/\/_/\/__/\/___/      \/_____/\/___/   \/__/ \/_/
                   /\____/              _
                   \_/__/       __ _ __| |_ ____ _ _ _  __ ___
                               / _` / _` \ V / _` | ' \/ _/ -_)
                               \__,_\__,_|\_/\__,_|_||_\__\___|
								v0.9b

                                   ---====---
                                GAME INFORMATION
                                   ---====---

Created By: Jeff 'Kuja' Katz
                  jeff@katzonline.net

     Title: Lights Out! Advance

Originally: A handheld tiger game, long since discontinued

      Note: I managed to break my flash cart halfway through the development of
                this game, so I am only 90% sure that everything works on
                hardware :(

                                   ---====---
                                  INTRODUCTION
                                   ---====---

You are holding in your hands the most addictive, brain boggling puzzle ever
    created. The object of the puzzle is simple...turn the LIGHTS OUT. It seems
    so easy...at first. The problem is that every toggle of a light has an
    effect on the puzzle. Lights that are on will shut off, and "off" lights
    will turn on. (So, if you toggle a light that is lit, it will shut off.
    Conversely, toggling an unlit light will cause it to light up). Moreover,
    when you toggle a light, it not only changes that light, but it also changes
    the adjacent lights (those that are directly above, below, or next to the
    toggled light). Every puzzle in the game has a solution. Your goal is to
    solve each puzzle in the fewest number of "moves", or steps.

The first puzzles are simple, to help you get a feel for the game, and get the
    basic "logic" of LIGHTS OUT. Later puzzles get progressively more
    challenging, requiring a little more brain power to solve. Once you start to
    solve some of the 50 puzzles in MODE 1, you can try your hand at MODE 2,
    which features over 1000 puzzles...

LIGHTS OUT is so addictive, you may not be able to put it down, but, if you
    should shut it off for any reason, the memory function will keep track of
    your progress, and let you play from the last puzzle solved.

What follows is a basic guide to the game and its functions, and a "walk
    through" of the first puzzle. So get to work...its time to turn the LIGHTS
    OUT!

                                   ---====---
                                    CONTROLS
                                   ---====---

*** Menu Screen ***

Select, D-Pad: Choose menu item
        Start: Execute menu item

*** Puzzle Screen ***

  A/B Buttons: Toggle Light
        D-Pad: Move recticle
     L/R Pads: Select Puzzle
       Select: Reset Level
        Start: Return to main menu

                                   ---====---
                                      MENU
                                   ---====---

At the main menu screen, you can use either the select button, or the D-Pad to
    select which menu item you wish to execute. Press the start button to
    execute your choice. The "sound" option is a quad state, represented by four
    colors, which are as follows:

      Red - Sounds and Music enabled
     Blue - Music, but no Sounds are enabled
   Yellow - Sounds and Music are disabled
    Green - Sounds, but no Music are enabled

                                   ---====---
                                PLAYING THE GAME
                                   ---====---

PRESS THE "START" BUTTON If this is your first time playing LIGHTS OUT, three
    lights in row three will light.... This is Puzzle 1 (Mode 1).

To understand the solution to a puzzle, think of the LIGHTS OUT puzzle display
    in terms of numbers. Each light on the puzzle can be assigned a number from
    1 to 25 (see illustration)

                              1  2  3  4  5   Row 1
                              6  7  8  9  10  Row 2
                              11 12 13 14 15  Row 3
                              16 17 18 19 20  Row 4
                              21 22 23 24 25  Row 5

For Puzzle 1 (Mode 1), you should see light numbers 11, 13, and 15 lit up on
    your display.

Since your goal is to shut off the lights in the fewest moves possible, you will
    need to decide which lights to toggle. Remember, each light toggle effects
    the surrounding lights, so plan your moves carefully. For example, if light
    12 is toggled, lights 11 and 13 will be shut off, but now lights 7, 12, and
    17 will be turned on.

                                   ---====---
                            SOLVING THE FIRST PUZZLE
                                   ---====---

Follow the steps below to solve this puzzle in 6 steps - the minimum number of
    moves!

STEP 1 When you start, lights 11, 13, and 15 will be lit. Toggle light 16.
    toggling light 16 caused light 11 to shut off, and the lights next to and
    below it, 17 and 21, to turn on. lights 13 and 15 stayed the same.

STEP 2 Light 11 is now off, but 13, 15, 16 , 17 and 21 are lit. Toggle light 18.
    lights 18, 19 and 23 are will turn on. lights 13 and 17 will turn off and
    lights 15, 16 and 21 stay the same.

STEP 3 Lights 15, 16, 18, 19, 21 and 23 are lit. Toggle light 20. Now lights 15
    & 19 have shut off. lights 20 and 25 are now lit, and light 16, 18, 21 and
    23 remained the same.

STEP 4 Toggle light 21. Now light 22 is lit. Light 16 and 21 shut off, and light
    18, 20, 23 and 25 remained the same. You notice that there is a general
    "movement" of lights to the right side of the game board. This is a good
    strategy to follow - to "corner" the lights so they are in a better position
    to be shut off.

STEP 5 Toggle light 23. Now lights 20, 24 and 25 are lit. Now you have three
    lights to go.

STEP 6 This is your final move. The only lights on the board are 20, 24 and 25.
    Toggle light 25.

All the lights have gone out and you have turned the Lights Out in the minimum
    number of moves! You should see a "victory" pattern of lights - Now you can
    move on to puzzle 2!

After a puzzle has been solved in MODE 1, you can try to improve your solution
    by accessing that puzzle again in MODE 1 by using the shoulder buttons.
    Simply press the shoulder buttons at any time during a puzzle until the
    puzzle you want comes up.

Note - You cannot select a puzzle number higher than the last puzzle you were
    working on. For example, if the last puzzle you complete is number 12 in
    MODE 1, you cannot select puzzle 14 until you solve 13 first!

Remember, if necessary, you can always shut off the game and it will return you
    to the beginning of the last puzzle you were working on when you�re ready to
    play again!

Now that you have solved Puzzle 1 in Mode 1, it is time to learn how to access
    each of the three different Puzzle Modes in Lights Out.

                                   ---====---
                                  PUZZLE MODE 1
                                   ---====---

After turning Lights Out on, pressing the start button automatically defaults
    you to the last puzzle you tried to solve in Mode 1.

Mode 1 enables you to solve 50 pre-programmed puzzles, each one more difficult
    from the last. Solving a beginning puzzle can be as few as 6 steps, while
    the more advanced puzzles could require up to 15 steps!


PUZZLE            MINIMUM REQ'd STEPS
  Puzzles 1-5       6 steps
  Puzzles 6-10      7 steps
  Puzzles 11-15     8 steps
  Puzzles 16-20     9 steps
  Puzzles 21-25     10 steps
  Puzzles 26-30     11 steps
  Puzzles 31-35     12 steps
  Puzzles 36-40     13 steps
  Puzzles 41-45     14 steps
  Puzzles 46-50     15 steps

*** REMEMBER ***
The challenge of Lights Out is to solve a puzzle in the minimum number of moves
    required. When you solve a puzzle in the minimum number of moves, you will
    be rewarded with a blinking light show. Lights Out will then automatically
    display the next puzzle! If you go over the minimum number of moves, the
    number of moves you exceed by will flash on your display, but you can still
    proceed to the next puzzle as long as you do not exceed 10 moves! For
    example, solving a 6 step puzzle in 8 steps will display two blinking
    lights! If you solve a puzzle in more than 10 steps over the minimum number
    of moves, a lighted �X� will appear on screen and you will have to try again
    before advancing to the next puzzle!

                                   ---====---
                                  PUZZLE MODE 2
                                   ---====---

MODE 2 is similar to MODE 1, except that all the puzzles were randomly generated
    by a computer.

                                   ---====---
                                    STUMPED?
                                   ---====---

If you are so completely stuck on a puzzle, and you just want to get it over
    with, there is an algorithm by which you can solve any puzzle - albiet not
    with the minimum number of moves. To begin, you turn out all the lights on
    the top row, by toggling the lights on the second row that are directly
    underneath any lit lights on the top row. The top row will then have all
    it's lights off.

Repeat this step for the second, third and fourth row. (i.e. chase the lights
    all the way down to the bottom row). This may have solved the puzzle
    already, but is more likely that there will now be some lights left on in
    the bottom row. If so, there are only 7 possible configurations. Depending on
    which configuration you are left with, you need to toggle some lights in the
    top row. You can determine which lights you need to toggle from the
    following table.

                              BOTTOM   |    TOP
                            -----------+-----------
                            X 0 0 0 X  |  X X 0 0 0
                            0 X 0 X 0  |  X 0 0 X 0
                            X X X 0 0  |  0 X 0 0 0
                            0 0 X X X  |  0 0 0 X 0
                            X 0 X X 0  |  0 0 0 0 X
                            0 X X 0 X  |  X 0 0 0 0
                            X X 0 X X  |  0 0 X 0 0

After you have pressed the buttons in the top row, you now apply the Light
    Chasing algorithm again (i.e. turn the lights out row by row). This time the
    puzzle will definitely be solved when you reach the bottom row!