Dear GBADEV.org,

This zip file contains four projects of mine whose source I feel will benefit
    the community. They compile out of the box with the ARM SDT, and with some
    tweaking im sure that gcc can compile them too :). In this zip is a mode
    seven demonstration, some copper bars and wavy lines, some lzw decomp, and a
    full puzzle game. Enjoy!

- Jeff 'Kuja' Katz