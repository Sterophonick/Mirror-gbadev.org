I've been working on this RPG for a while now, and I've pretty much finished the bulk of its raycaster.  This raycaster features variable height texture mapped walls, distance shading, and an average of 15 frames per second on hardware (which I'm sure I can improve, given time).  Right now the raycaster is a part of my RPG, but if there is sufficient interest, I might consider seperating the raycaster engine from my game and releasing its source code.  At any rate, I always appreciate feedback, so let me know what you think.

Erik Rounds
erik_rounds@und.nodak.edu
http://www.cs.und.edu/~rounds/resume.html