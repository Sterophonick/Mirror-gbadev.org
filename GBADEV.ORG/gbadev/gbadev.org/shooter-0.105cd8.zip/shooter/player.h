typedef struct
{
	s32 x, y;
	s16 direction;
	Sprite sprite;
	u32 distance_total, distance_travelled, speed;
	u16 active;
} bullet;

#define BULLET_SPEED FIXED_INT(4)

typedef struct 
{
	s32 x, y;
	u16 direction;
	Sprite sprite;
	u32 xspeed;
	s32 min_x, max_x;
	u32 yspeed;
	s32 min_y, max_y;
	u16 num_bullets;
	bullet* bullets;
	u16 bullet_channel; // sound channel for bullet
	u16 fire_delay;
	u32 score;
} playership;

#define PLAYERSHIP_FIRE_DELAY 10
#define PLAYERSHIP_NUM_BULLETS 8

