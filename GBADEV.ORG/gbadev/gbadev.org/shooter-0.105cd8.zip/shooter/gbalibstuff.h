// Bank stuff.
void gba_initbank(void);
void gba_swapbank(void);
void gba_setdbank(byte n);
void gba_setwbank(byte b);
void gba_vsync(void);

signed long int gba_sin(int ang);		// Check range for 0-359.
signed long int gba_cos(int ang);		// Check range.
signed long int gba_sinq(int ang) CODE_IN_IWRAM;		// No range check.
signed long int gba_cosq(int ang) CODE_IN_IWRAM;		// No range check.
signed long int gba_sqrt(signed long int n);
signed long int gba_atan(signed long int n);

