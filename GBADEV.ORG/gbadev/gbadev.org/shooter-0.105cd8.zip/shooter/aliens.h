typedef struct
{
	s32 x, y;
	u32 distance_travelled, distance_total;
	s32 x_speed, y_speed;
	Sprite sprite;
	u16 active;
} alien_bullet;

typedef struct
{
	s32 x, y;
	u16 active;
	u16 explode; /* explode state: non-zero when exploding, value = frame */
	u16 type;
	void* data; /* data for alien type */
	Sprite sprite;

	alien_bullet* bullets;
	u16 num_bullets;
} alien;	

typedef struct
{
	s32 speed;
} alien_blue;

typedef struct
{
	s32 x_speed, y_speed;
	u16 frame;
} alien_purple;
