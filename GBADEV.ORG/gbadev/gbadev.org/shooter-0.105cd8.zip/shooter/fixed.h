
#define FIXED_INT(x) ((int)((x) * 256))
#define FIXED_TO_INT(x) ((x)  >> 8)
