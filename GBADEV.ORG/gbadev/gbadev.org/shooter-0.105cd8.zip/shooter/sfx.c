#include "gba.h"
#include "sound.h"

#include "laser2.h"
#include "exp2.h"

sfxSystemSound laser_sample = {laser_wav, 3000, 12, -4, 22050, 0, 0, 0};
sfxSystemSound exp_sample = {exp_wav, 16128, 20, 4, 13000, 0, 0, 0};

