#!/usr/bin/env python

# clipping table thingy

for i in range(0, 128):
	print "\t.byte\t-127"

for i in range(-127, 128):
	print "\t.byte\t" + str(i)

for i in range(0, 128):
	print "\t.byte\t128"
	
