#include "main.h"

// debugging output for VBA
void print(char *s)
{
    asm volatile("mov r0, %0;"
                 "swi 0xff;"
                 : // no ouput
                 : "r" (s)
                 : "r0");
		
}

mod_header m;

///main entry point from the boot.asm startup file
int AgbMain()
{
	interrupt_init();
	InitialiseSprites();
	
	mod_parse(&m, foo_mod);

	while(1)
	{
		intro();
		game_run();
	}

	return(0);
}
