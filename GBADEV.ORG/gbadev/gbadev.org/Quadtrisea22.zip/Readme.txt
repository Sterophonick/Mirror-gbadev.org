
======================================================================
======================================================================
   ===============================================================
         ===============================================
              ==================================
                   ========================
                    Quadtris v1.1 for GBA
                   ========================
              ==================================
         ===============================================
   ============= (c) 2005 Coldplastic Software  =================
======================================================================
======================================================================


                      --------------
                       Introduction
                      --------------

    Yes, it's another clone of the classic puzzle game, but there are 
additional twists and turns! New features not found in other clones 
include reverse gravity, multiple backgrounds, unconventional shapes,
varied shape images, and many special effects to make the game more
challenging and/or fun. Also includes two option menus that allows
you to configure the various aspects of the game. 


                      --------------
                         Controls
                      --------------

      Menu Screen:     UP      - moves cursor
                       DOWN    - moves cursor
                       A, B    - select option

      Options Screen:  UP      - moves cursor
                       DOWN    - moves cursor
                       LEFT    - decrement value or toggle option
                       RIGHT   - increment value or toggle option
                       A, B    - quit options screen

      Special Options:   Controls are same as those for 'Options Screen'

      Game Screen:     LEFT    - moves shape left
                       RIGHT   - moves shape right
                       DOWN    - quick fall
                       A       - rotate left
                       B       - rotate right
                       START   - Pause game

                       START, SELECT, then A - Quit the game


                      -----------------
                       Special Options
                      -----------------

           These features allow you to add to the fun or increase the difficulty
           of the game. Most of these options, if turned on, gives you more points
           during the game. If you can play the game comfortably with most of the
           options turned on, you can call yourself the ULTIMATE MASTER!


           Option         Values      Description
          --------       --------    -------------
           
            X-Flip       T/F/Rand     Turns on/off horizontal screen flipping.
                                      Rand means the play field flips
                                      unexpectedly during play.

            Y-Flip       T/F/Rand     Same as above, except that it's done
                                      vertically.

            X-Distort    0-20         Distorts the screen horizontally. Effect
                                      is similar to looking through crumpled
                                      plastic bags.
    
            Y-Distort    0-15         Same effect as above, except that it's done
                                      on the Y axis.

            Shape Morph  T/F          The falling tetrad randomly changes shape.

            Shake        T/F          Playfield shakes in four directions.

            Hole punch   T/F          Random punching of holes in garbage blocks

            Sprite Morph T/F          The cells which make up the blocks change
                                      their appearance randomly
             
            X-Lean       0 - off          Playfield leans like the Tower of Pisa
                         1 - 10 lean left 
                         11 - 20 lean right

            Y-Lean       0 - off          Same effect as above, except on the Y-axis
                         1 - 8 lean up 
                         8 - 15 lean down

            Mirage #1    T/F           Your tetrad is not what it appears to be

            Mirage #2    T/F           Illusion of garbage blocks on playfield

            Tetrad Rain  T/F           It's raining tetrads all over!

            Cell Rain    T/F           It's raining tiny squares all over!

            Explosion    T/F           Clear lines with a blast!

            Jerking      T/F           Tetrad moves up and down in subtle fashion.
       

                      --------------
                         Scoring
                      --------------


                       1 Line  -   2 points
                       2 Lines -   4 points
                       3 Lines -  10 points
                       4 Lines -  40 points


                   
                      --------------
                        Disclaimer
                      --------------

       The author of this program shall not be liable for any incidental,
consequential, or other damages, even if the author is advised of or aware
of the possibility of such damages. This means that the author shall
not be responsible for the lost of profits or revenues, or for damages
or costs incurred as a result of loss of time, data, or use of the 
software, or from any other cause related to the use of this program.
Use of the program means that the user automatically agrees with all
terms and conditions set forth in this disclaimer.


                      --------------
                         Contact
                      --------------
    
               Author: Eugene Yi
               Email : coldplastic@yahoo.com

