PONG-TOR

a simple Game Boy Advance game
by
Tim Cowley

This game was made as a job application. 
Total effort put into this project: 20 hours. There's nothing
fancy here, I'm afraid, no palette animation or tilemaps, no sound or 
dynamic lighting. Not even sprites. Just some simple animation, input,
and state.
Still, it's fun to play. ^_^

Some utility code from outside sources was used, this is almost entirely
limited to the header files and gfx.c. The devkitadv compiler, and pcx2gba
were used to compile and convert graphics. GIMP and Adobe Illustrator 
were used to generate graphics, with some help from Sandra, my fiancee.

Much thanks to www.loirak.com and gbadev.org for maintaining good info and
hosting the demo games and code, and feeding the gba scene. 

Any questions or comments should be directed to Tim Cowley at
guybrush_pirate@hotmail.com

see other demos of mine (mainly PC) at 
http://www.ee.ualberta.ca/~tcowley/demos/

