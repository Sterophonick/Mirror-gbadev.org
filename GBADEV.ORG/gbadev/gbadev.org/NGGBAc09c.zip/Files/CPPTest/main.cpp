// These includes are required for C++ startup ///
#include "stdlib.h"								//
#include "malloc.h"								//
#include "string.h"								//
//////////////////////////////////////////////////

class Apa
{
public:
	void Do();
};

void Apa::Do()
{
	unsigned char r,g,b;
	unsigned short *p;
	int i;

	// 0x04000000 is the display control register
	// Set mode 3 (15-bit mode) | enable background 2 to display video buffer
	*(unsigned int*)0x04000000 = 3 | (1<<10);

	// Create a red pixel (ranges are 0-31 per color component)
	r = 0;
	g = 0;
	b = 31;

	// 0x06000000 is the video buffer - set first pixel in buffer to green
	p = (unsigned short*)0x06000000;
	for(i = 0; i < 240*160; i++)
	{
		*p = (b<<10)|(g<<5)|r;
		p++;
	}
}

int main(void)
{
	Apa a;

	a.Do();

	while(1){}
}

