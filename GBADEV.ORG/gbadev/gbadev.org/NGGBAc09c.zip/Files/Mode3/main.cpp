// These includes are required for C++ startup ///
#include "stdlib.h"								//
#include "malloc.h"								//
#include "string.h"								//
//////////////////////////////////////////////////

int main(void)
{
	*(unsigned int*)0x04000000 = 3 | (1<<10);

	while(1);
}

