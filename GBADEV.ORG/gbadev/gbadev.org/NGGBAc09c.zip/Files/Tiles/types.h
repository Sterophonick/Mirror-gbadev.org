//////////////////////////////////////
//	File: types.h					//
//	Desc: Defines some basic types.	//
//////////////////////////////////////

#ifndef HEADER_TYPES_H
#define HEADER_TYPES_H

typedef     volatile unsigned char           vu8;
typedef     volatile unsigned short int      vu16;
typedef     volatile unsigned int            vu32;
typedef     volatile unsigned long long int  vu64;

typedef     unsigned char           u8;
typedef     unsigned short int      u16;
typedef     unsigned int            u32;
typedef     unsigned long long int  u64;

typedef     signed char             s8;
typedef     signed short int        s16;
typedef     signed int              s32;
typedef     signed long long int    s64;

#endif
