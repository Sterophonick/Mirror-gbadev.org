//////////////////////////////////////////////////////////////
// File: gba.h												//
//															//
// Description: Holds addresses to gba hardware registers	//
//		and the flags to control them.						//
//															//
// Author: Christer Andersson								//
//															//
//////////////////////////////////////////////////////////////

#ifndef HEADER_GBA_H
#define HEADER_GBA_H

#include "types.h"

extern unsigned short *VideoBuffer;

// Video RAM address
#define VRAM		*(u16*)0x06000000

// Mode 4 buffers
#define VRAMBUFFER0	*(u16*)0x06000000
#define VRAMBUFFER1 *(u16*)0x0600A000

// OBJ video RAM start adress
#define OBJVRAM		*(u16*)0x06010000

///////////////////////////////////
// DISPCNT Register & parameters //
///////////////////////////////////

#define DISPCNT		*(u32*)0x04000000	// Address to display controller register
#define DISPCNT_L	*(u16*)0x04000000	// Address to lword of display controller register
#define DISPCNT_H	*(u16*)0x04000002	// Address to hword of display controller register

#define BGMODE0		0		// Tile modes
#define BGMODE1		1
#define BGMODE2		2
#define BGMODE3		3		// Bitmap modes
#define BGMODE4		4
#define BGMODE5		5

#define FRAMEBUFFER0	(0<<4)
#define FRAMEBUFFER1	(1<<4)

#define OBJCHARMEMMAP1D		(1<<6)	// Set OBJ character mapping to 1D

#define BG0ENABLE		(1<<8)		// Enable the different background layers
#define BG1ENABLE		(1<<9)		
#define BG2ENABLE		(1<<10)
#define BG3ENABLE		(1<<11)
#define OBJENABLE		(1<<12)		// Enable the OBJ layer
#define WIN0ENABLE		(1<<13)
#define WIN1ENABLE		(1<<14)
#define OBJWINENABLE	(1<<15)

///////////////////////////
// Vertical line counter //
///////////////////////////

#define VCOUNT *(u16*)0x04000006	// Currently rendered vertical line (0 - 227)

//////////////////////////////////
// BGXCNT Register & parameters //
//////////////////////////////////

#define BG0CNT	*(u16*)0x4000008	// Background 0 control register address
#define BG1CNT	*(u16*)0x400000A	// Background 1 control register address
#define BG2CNT	*(u16*)0x400000C	// Background 2 control register address
#define BG3CNT	*(u16*)0x400000E	// Background 3 control register address

#define BGPRIORITY0		0	// Priority of background layers (1st-4th)
#define BGPRIORITY1		1
#define BGPRIORITY2		2
#define BGPRIORITY3		3

#define BGCHARBASEBLOCK(n)(n<<2)	// In which base block (0-3) character data 
									// (tile map) for background can be found

#define BGMOSAIC			(1<<6)	// Mosaic effect on background

#define BGCOLORMODE16X16	(0<<7)	// 16x16 color palettes
#define BGCOLORMODE1X256	(1<<7)	// 1x256 color palette

#define BGSCREENBASEBLOCK(n)(n<<8)	// In which base block (0-31) screen data 
									// (tile set) for background can be found

#define BGOVERFLOWWRAP	(1<<13)		// Makes the screen wrap at offset overflow

									// Size of text background character data
#define BGTEXTSCREENSIZE256x256	(0<<14)	// 2kb
#define BGTEXTSCREENSIZE512x256	(1<<14)	// 4kb	
#define BGTEXTSCREENSIZE256x512	(2<<14)	// 4kb
#define BGTEXTSCREENSIZE512x512	(3<<14)	// 8kb

										// Size of rotscale background character data
#define BGROTSCALESCREENSIZE128x128		(0<<14)	// 256 bytes
#define BGROTSCALESCREENSIZE256x256		(1<<14)	// 1kb
#define BGROTSCALESCREENSIZE512x512		(2<<14)	// 4kb
#define BGROTSCALESCREENSIZE1024x1024	(3<<14)	// 16kb
						
//////////////////////////////////
// Mosaic register & parameters //
//////////////////////////////////

#define MOSAICCNT	*(u16*)0x400004C	// Address to mosaic control register

#define MOSAICBGHSIZE(n)(n)			// Horizontal size of background mosaic (0-16)
#define MOSAICBGVSIZE(n)(n<<4)		// Vertical size of background mosaic (0-16)
#define MOSAICOBJHSIZE(n)(n<<8)		// Horizontal size of OBJ mosaic (0-16)
#define MOSAICOBJVSIZE(n)(n<<12)	// Vertical size of OBJ mosaic (0-16)

//////////////////////////
// Character properties //
//////////////////////////

#define CHARPROPNAME(n)(n)				// Index into the screen data (tile set) (10-bit for text char, 8-bit for rot/scale char)
#define TEXTCHARPROPFLIPH	(1<<10)		// Character (tile) is drawn flipped horizontally (text mode only)
#define TEXTCHARPROPFLIPV	(1<<11)		// Character (tile) is drawn flipped vertically (text mode only)

/////////////////////////////////
// Background offset registers //
/////////////////////////////////

#define BG0HOFFSET	*(u16*)0x4000010	// Horizontal and vertical offset for background 0	
#define BG0VOFFSET	*(u16*)0x4000012	// each offset value is 9 bits (i.e. 0-1023)
#define BG1HOFFSET	*(u16*)0x4000014	// Horizontal and vertical offset for background 0	
#define BG1VOFFSET	*(u16*)0x4000016	// each offset value is 9 bits (i.e. 0-1023)
#define BG2HOFFSET	*(u16*)0x4000018	// Horizontal and vertical offset for background 0	
#define BG2VOFFSET	*(u16*)0x400001A	// each offset value is 9 bits (i.e. 0-1023)
#define BG3HOFFSET	*(u16*)0x400001C	// Horizontal and vertical offset for background 0	
#define BG3VOFFSET	*(u16*)0x400001E	// each offset value is 9 bits (i.e. 0-1023)


////////////////////
// OBJ parameters //
////////////////////

#define OAM		*(u16*)0x07000000	// Address to OAM RAM where OBJ attributes are stored

#define OBJATTR0(n)	*(u16*)(0x07000000+n*0x8)		// Address to the nth OBJ's attribute 0 (0-128)
#define OBJATTR1(n)	*(u16*)(0x07000000+n*0x8+0x2)	// Address to the nth OBJ's attribute 1 (0-128)
#define OBJATTR2(n)	*(u16*)(0x07000000+n*0x8+0x4)	// Address to the nth OBJ's attribute 2 (0-128)

#define ROTSCALEPARAMPA(n) *(u16*)(0x07000000+n*0x32+0x6)	// Address to the nth rot/scale PA parameter (0-31)
															// dx: x distance moved on the same line
#define ROTSCALEPARAMPB(n) *(u16*)(0x07000000+n*0x32+0x14)	// Address to the nth rot/scale PA parameter (0-31)
															// dmx: x distance moved on the next line
#define ROTSCALEPARAMPC(n) *(u16*)(0x07000000+n*0x32+0x22)	// Address to the nth rot/scale PA parameter (0-31)
															// dy: y distance moved on the same line
#define ROTSCALEPARAMPD(n) *(u16*)(0x07000000+n*0x32+0x30)	// Address to the nth rot/scale PA parameter (0-31)
															// dmy: y distance moved on the next line

// Attribute(s) 0 of OBJ
#define OBJATTR0YCOORD(n)			(n)			// Y coordinate of OBJ (8-bits)
#define OBJATTR0ROTSCALEON			(1<<8)		// Enables rotaion and scaling
#define OBJATTR0ROTSCALEDBLFLAG		(1<<9)		// Rotation and scaling double flag
#define OBJATTR0OBJMODENORMAL		(0<<10)		// Normal OBJ
#define OBJATTR0OBJMODESEMITRANSP	(1<<10)		// Semitransparent OBJ
#define OBJATTR0OBJMODEOBJWINDOW	(2<<10)		// OBJ window
#define OBJATTR0MOSAICON			(1<<12)		// Enables mosaic effect on OBJ
#define OBJATTR0COLORMODE16X16		(0<<13)		// OBJ palette mode 16x16 colors
#define OBJATTR0COLORMODE1X256		(1<<13)		// or 1x256 colors palette
#define OBJATTR0SHAPESQUARE			(0<<14)		// OBJ shape is square
#define OBJATTR0SHAPEHRECT			(1<<14)		// OBJ shape is horizontal rectangle
#define OBJATTR0SHAPEVRECT			(2<<14)		// OBJ shape is vertical rectangle

// Attibute(s) 1 of OBJ
#define OBJATTR1XCOORD(n)			(n)			// X coordinate of OBJ (9-bits)
#define OBJATTR1ROTSCALEPARAM(n)	(n<<9)		// Which rot/scale parameters OBJ uses (0-31 index into transformation table)
#define OBJATTR1HFLIP				(1<<12)		// Flips OBJ horizontally (cannot be used with rot/scale param)
#define OBJATTR1VFLIP				(1<<13)		// Flips OBJ vertically
#define OBJATTR1SIZESQUARE8X8		(0<<14)		// Sizes of square shape OBJ
#define OBJATTR1SIZESQUARE16X16		(1<<14)
#define OBJATTR1SIZESQUARE32X32		(2<<14)
#define OBJATTR1SIZESQUARE64X64		(3<<14)
#define OBJATTR1SIZEHRECT16X8		(0<<14)		// Sizes of horizontal rectangle shape OBJ
#define OBJATTR1SIZEHRECT32X8		(1<<14)
#define OBJATTR1SIZEHRECT32X16		(2<<14)
#define OBJATTR1SIZEHRECT64X32		(3<<14)
#define OBJATTR1SIZEVRECT8X16		(0<<14)		// Sizes of vertical rectangle shape OBJ
#define OBJATTR1SIZEVRECT8X32		(1<<14)		
#define OBJATTR1SIZEVRECT16X32		(2<<14)
#define OBJATTR1SIZEVRECT32X64		(3<<14)

// Attribute(s) 2 of OBJ
#define OBJATTR2CHARNAME(n)			(n)			// Index to starting character (10-bit)
#define OBJATTR2PRIORITY0			(0<<10)		// Draw prority of OBJ (decending 1st-4th)
#define OBJATTR2PRIORITY1			(1<<10)
#define OBJATTR2PRIORITY2			(2<<10)
#define OBJATTR2PRIORITY3			(3<<10)
#define OBJATTR2PALETTEINDEX(n)		(n<<12)		// 16 color palette index (0-15) of OBJ (in 1x256 not used)

/////////////////////
// Palette address //
/////////////////////

#define BGPALETTE	*(u16*)0x05000000			// Address to the background palette
#define OBJPALETTE	*(u16*)0x05000200			// Address to the OBJ palette

///////////////////////////////////
// Window registers & parameters //
///////////////////////////////////

#define WIN0H	*(u16*)0x04000040		// Addresses to window registers
#define WIN0V	*(u16*)0x04000044
#define WIN1H	*(u16*)0x04000042
#define WIN1V	*(u16*)0x04000046

#define WININ	*(u16*)0x04000048		// Address to register controlling display inside window(s) area
#define WINOUT	*(u16*)0x0400004A		// Address to register controlling display outside window(s) area

#define WINUPLEFTX(n)		(n<<8)		// X position of window's corners
#define WINLOWRIGHTX(n)		(n)
#define WINUPLEFTY(n)		(n<<8)		// Y position of window's corners
#define WINLOWRIGHTY(n)		(n)

#define WIN0BG0ENABLE		1			// Enable the different layers for window 0
#define WIN0BG1ENABLE		(1<<1)		// These are valid for both for WININ and WINOUT registers
#define WIN0BG2ENABLE		(1<<2)
#define WIN0BG3ENABLE		(1<<3)
#define WIN0OBJENABLE		(1<<4)
#define WIN0SPECIALFXENABLE	(1<<5)

#define WIN1BG0ENABLE		(1<<8)		// Enable the different layers for window 1
#define WIN1BG1ENABLE		(1<<9)		// These are valid for both for WININ and WINOUT registers
#define WIN1BG2ENABLE		(1<<10)
#define WIN1BG3ENABLE		(1<<11)
#define WIN1OBJENABLE		(1<<12)
#define WIN1SPECIALFXENABLE	(1<<13)

////////////////////////////////////
// Blending register & parameters //
////////////////////////////////////

#define BLDMOD	*(u16*)0x04000050		// Address to the blending register/modifier

#define BLDBG01STTARGET		1			// Background 0 is selected as 1st target pixel
#define BLDBG11STTARGET		(1<<1)		// Background 1 is selected as 1st target pixel
#define BLDBG21STTARGET		(1<<2)		// Background 2 is selected as 1st target pixel
#define BLDBG31STTARGET		(1<<3)		// Background 3 is selected as 1st target pixel
#define BLDOBJ1STTARGET		(1<<4)		// OBJ layer is selected as 1st target pixel
#define BLDBD1STTARGET		(1<<5)		// Backdrop is selected as 1st target pixel

#define BLDBG02NDTARGET		(1<<8)		// Background 0 is selected as 2nd target pixel
#define BLDBG12NDTARGET		(1<<9)		// Background 1 is selected as 2nd target pixel
#define BLDBG22NDTARGET		(1<<10)		// Background 2 is selected as 2nd target pixel
#define BLDBG32NDTARGET		(1<<11)		// Background 3 is selected as 2nd target pixel
#define BLDOBJ2NDTARGET		(1<<12)		// OBJ layer is selected as 2nd target pixel
#define BLDBD2NDTARGET		(1<<13)		// Backdrop is selected as 2nd target pixel

#define BLDSPECIALFXNONE			(0<<6)	// No special effect is performed
#define BLDSPECIALFXABLD			(1<<6)	// Alpha blending
#define BLDSPECIALFXINCBRIGHTNESS	(2<<6)	// Increase in brightness
#define BLDSPECIALFXDECBRIGHTNESS	(3<<6)	// Decrease in brightness

#define COLEV	*(u16*)0x04000052	// Address to the alpha blending coefficents 
#define COLY	*(u16*)0x04000054	// Address to the brightness control coefficents

#define COLEVEVANSIXTEENTH(n)	(n)		// Coefficent set to n/16th	(5-bit)
#define COLEVEVBNSIXTEENTH(n)	(n<<8)  // Coefficent set to n/16th	(5-bit)
#define COLYEVYNSIXTEENTH(n)	(n)     // Coefficent set to n/16th	(5-bit)

//////////////////////////////////
// Timer registers & parameters //
//////////////////////////////////

#define TM0D	*(u16*)0x04000100	// Addresses to the timer counters
#define TM1D	*(u16*)0x04000104
#define TM2D	*(u16*)0x04000108
#define TM3D	*(u16*)0x0400010C

#define TM0CNT	*(u16*)0x04000102	// Addresses to the timer controllers
#define TM1CNT	*(u16*)0x04000106
#define TM2CNT	*(u16*)0x0400010A
#define TM3CNT	*(u16*)0x0400010E

#define TMPRESCALE0		0		// Timer prescale - every clock cycle			(59.595 ns) 
#define TMPRESCALE64	1		// Timer prescale - every 64th clock cycle		(3.814 micro s) 
#define TMPRESCALE256	2		// Timer prescale - every 256th clock cycle		(15.256 micro s) 
#define TMPRESCALE1024	3		// Timer prescale - every 1024th clock cycle	(61.025 micro s) 

#define TMCOUNTUP			(1<<2)	// Count up - on overflow the timer under keeps counting

#define TMINTENABLE			(1<<6)	// Enable interrupt on overflow

#define TMOPERATIONENABLE	(1<<7)	// Enable/start the timer

////////////////////////////////
// DMA registers & parameters //
////////////////////////////////

#define DMA0SRC		*(u32*)0x040000B0	// Source address of transfer (27-bit)
#define DMA0DST		*(u32*)0x040000B4	// Destination address of transfer (27-bit) 
#define DMA0COUNT	*(u16*)0x040000B8	// Count of characters that should be transferred (14-bit)
#define DMA0CNT		*(u16*)0x040000BA	// DMA0 transfer control register

#define DMA1SRC		*(u32*)0x040000BC	// Source address of transfer (27-bit)
#define DMA1DST		*(u32*)0x040000C0	// Destination address of transfer (27-bit) 
#define DMA1COUNT	*(u16*)0x040000C4	// Count of characters that should be transferred (14-bit)
#define DMA1CNT		*(u16*)0x040000C6	// DMA1 transfer control register

#define DMA2SRC		*(u32*)0x040000C8	// Source address of transfer (27-bit)
#define DMA2DST		*(u32*)0x040000CC	// Destination address of transfer (27-bit) 
#define DMA2COUNT	*(u16*)0x040000D0	// Count of characters that should be transferred (14-bit)
#define DMA2CNT		*(u16*)0x040000D2	// DMA2 transfer control register

#define DMA3SRC		*(u32*)0x040000D4	// Source address of transfer (27-bit)
#define DMA3DST		*(u32*)0x040000D8	// Destination address of transfer (27-bit) 
#define DMA3COUNT	*(u16*)0x040000DC	// Count of characters that should be transferred (14-bit)
#define DMA3CNT		*(u16*)0x040000DE	// DMA3 transfer control register

// Control of destination address for transfer
#define DMACNTDSTINC		(0<<5)	// Increment
#define DMACNTDSTDEC		(1<<5)	// Decrement
#define DMACNTDSTFIX		(2<<5)	// Stay fixed
#define DMACNTDSTINCRELOAD	(3<<5)	// Address is incremented but reset after transfer

// Control of source address for transfer
#define DMACNTSRCINC		(0<<7)	// Increment
#define DMACNTSRCDEC		(1<<7)	// Decrement
#define DMACNTSRCFIX		(2<<7)	// Stay fixed

// If time of transfer is the next VB or HB, DMA transfer
// happens every VB/HB
#define DMACNTREPEAT		(1<<9)

// Tranfer mode
#define DMACNTTRANSFER16	(0<<10)		// Transfer in 16-bit units
#define DMACNTTRANSFER32	(1<<10)		// Transfer in 32-bit units

// Time of transfer
#define DMACNTSTARTIM		(0<<12)		// Immediately
#define DMACNTSTARTVB		(1<<12)		// Next vertical blank
#define DMACNTSTARTHB		(2<<12)		// Next horizontal blank

// Enable interrupt request when transfer is done
#define DMACNTINTENABLE		(1<<14)

// Enable DMA transfer
#define DMACNTENABLE		(1<<15)

//////////////////////////////////
// Input registers & parameters //
//////////////////////////////////

#define P1		*(u16*)0x04000130	// Address to current input state
#define P1CNT	*(u16*)0x04000132	// Address to control of

// The following flags are valid in register P1 for checking input state (1 = Pressed)
// and in register P1CNT for setting wheather they should genereate an interrupt
#define P1A			1			// A button
#define P1B			(1<<1)		// B button
#define P1SELECT	(1<<2)		// Select button
#define P1START		(1<<3)		// Start button
#define P1RIGHT		(1<<4)		// Right
#define P1LEFT		(1<<5)		// Left
#define P1UP		(1<<6)		// Up
#define P1DOWN		(1<<7)		// Down
#define P1R			(1<<8)		// R button
#define P1L			(1<<9)		// L button

#define P1CNTINTREQENABLE		(1<<14)		// Enable interrupt requests

#define P1CNTINTCONDITIONOR		(0<<15)		// Generates an interrupt when any of the keys 
											// specified to generate an interrupt is pressed
#define P1CNTINTCONDITIONAND	(1<<15)		// Generates an interrupt when all of the keys 
											// specified to generate an interrupt are pressed

/////////////////////////
// Interrupt registers //
/////////////////////////

// When set to 1 all interrupts are enabled if 0 all disabled
#define INTERRUPTMASTERENABLE	*(u16*)0x04000208

// Register controlling enabling/disabling of individual interrupts
#define INTERRUPTENABLEREG		*(u16*)0x04000200

#define INTERRUPTENABLEH				1			// H rendering blank
#define INTERRUPTENABLEV				(1<<1)		// V rendering blank
#define INTERRUPTENABLEVCOUNTERMATCH	(1<<2)
#define INTERRUPTENABLETIMER0			(1<<3)		// Timers
#define INTERRUPTENABLETIMER1			(1<<4)
#define INTERRUPTENABLETIMER2			(1<<5)
#define INTERRUPTENABLETIMER3			(1<<6)
#define INTERRUPTENABLECOMMUNICATION	(1<<7)		// General communication
#define INTERRUPTENABLEDMA0				(1<<8)		// DMAs
#define INTERRUPTENABLEDMA1				(1<<9)
#define INTERRUPTENABLEDMA2				(1<<10)
#define INTERRUPTENABLEDMA3				(1<<11)
#define INTERRUPTENABLEKEY				(1<<12)
#define INTERRUPTENABLEGAMEPAK			(1<<13)

/////////////////////
// Sound registers //
/////////////////////

// CONTROL REGISTERS //

#define SGCNT0L		*(u16*)0x04000080	// Final sound control register addresses
#define SGCNT0H		*(u16*)0x04000082
#define SGCNT1		*(u16*)0x04000084

#define SGCNT0LROUT(n)		n			// Right speaker output level (0-7)
#define SGCNT0LLOUT(n)		(n<<4)		// Left speaker output level (0-7)

#define SGCNT0LSND1RENABLED	(1<<8)		// Enable left & right speakers for each sound channel
#define SGCNT0LSND1LENABLED	(1<<12)
#define SGCNT0LSND2RENABLED	(1<<9)
#define SGCNT0LSND2LENABLED	(1<<13)
#define SGCNT0LSND3RENABLED	(1<<10)
#define SGCNT0LSND3LENABLED	(1<<14)
#define SGCNT0LSND4RENABLED	(1<<11)
#define SGCNT0LSND4LENABLED	(1<<15)

#define SGCNT0HSNDOUTPUT14		0		// Output ratios (1/4, 1/2 or 1/1)
#define SGCNT0HSNDOUTPUT12		1		// for sound synthesis (sound 1-4)
#define SGCNT0HSNDOUTPUT1		2

#define SGCNT0HDSAOUTPUT12		(0<<2)  // Output ratio for direct sound channel A
#define SGCNT0HDSAOUTPUT1		(1<<2)	// (1/2 or 1/1)
#define SGCNT0HDSBOUTPUT12		(0<<3)  // Output ratio for direct sound channel B
#define SGCNT0HDSBOUTPUT1		(1<<3)	// (1/2 or 1/1)

#define SGCNT0HDSARENABLED		(1<<8)	// Enable left & right speakers for 
#define SGCNT0HDSALENABLED		(1<<9)	// direct sound channel A
#define SGCNT0HDSBRENABLED		(1<<12)	// Enable left & right speakers for 
#define SGCNT0HDSBLENABLED		(1<<13)	// direct sound channel A

#define SGCNT0HDSATIMER0		(0<<10) // Timer selection 0 or 1 for each 
#define SGCNT0HDSATIMER1		(1<<10) // direct sound channel A & B
#define SGCNT0HDSBTIMER0		(0<<14)
#define SGCNT0HDSBTIMER1		(1<<14)

#define SGCNT0HDSFIFOARESET		(1<<11) // Reset FIFO and sequencer for each direct sound A & B
#define SGCNT0HDSFIFOBRESET		(1<<15)

#define SGCNT1SND1OPERATE		1		// Turn sound operation ON
#define SGCNT1SND2OPERATE		(1<<1)
#define SGCNT1SND3OPERATE		(1<<2)
#define SGCNT1SND4OPERATE		(1<<3)
#define SGCNT1ALLSNDOPERATE		(1<<7)


// SOUND 1 //

#define SG10L	*(u16*)0x04000060		// Addresses of sound 1 registers
#define SG10H	*(u16*)0x04000062
#define SG11	*(u16*)0x04000064

#define SG10LSWEEPSHIFTS(n)		n		// Number of sweep shifts (0-7)
#define SG10LSWEEPSHIFTINC		(0<<3)	// Number of sweep shifts (0-7)
#define SG10LSWEEPSHIFTDEC		(1<<3)	// Number of sweep shifts (0-7)
#define SG10LSWEEPTIME(n)		(n<<4)	// Time of sweep (0-7)

#define SG10HSNDLENGTH(n)		n		// Length of sound (0-63)
#define SG10HWAVEDUTYCYCLE(n)	(n<<6)	// Waveform proportions (0-3)
#define SG10HENVELOPESTEPS(n)	(n<<8)	// Envelope steps (0-7)
#define SG10HENVELOPEINC		(1<<11)	// If to increase or decrease envelope
#define SG10HENVELOPEDEC		(0<<11)
#define SG10HENVELOPEINIT(n)	(n<<12) // Initial envelope (0-15)

#define SG11FREQUENCY(n)		n		// Frequency 11-bits
#define SG11PLAYONCE			(1<<14)	// Play sound once
#define SG11PLAYLOOP			(0<<14)	// Loop sound
#define SG11INIT				(1<<15) // Makes the sound restart

// SOUND 2 //

#define SG20	*(u16*)0x04000068
#define SG21	*(u16*)0x0400006C

#define SG20SNDLENGTH(n)		n		// Length of sound (0-63)
#define SG20WAVEDUTYCYCLE(n)	(n<<6)	// Waveform proportions (0-3)
#define SG20ENVELOPESTEPS(n)	(n<<8)	// Envelope steps (0-7)
#define SG20ENVELOPEINC			(1<<11)	// If to increase or decrease envelope
#define SG20ENVELOPEDEC			(0<<11)
#define SG20ENVELOPEINIT(n)		(n<<12)	// Initial envelope (0-15)

#define SG21FREQUENCY(n)		n		// Frequency 11-bits
#define SG21PLAYONCE			(1<<14)	// Play sound once
#define SG21PLAYLOOP			(0<<14)	// Loop sound
#define SG21INIT				(1<<15) // Makes the sound restart

// SOUND 3 //

#define SG30L	*(u16*)0x04000070	// Addresses to sound 3 registers
#define SG30H	*(u16*)0x04000072
#define SG31	*(u16*)0x04000074

#define SGWRAM	*(u16*)0x04000090	// Address of sound 3 wave RAM (16 bytes 4bit/step)

#define SG30LSTEP32		(0<<5)	// Use two banks of 32 steps each
#define SG30LSTEP64		(1<<5)	// Use one bank of 64 steps
#define SG30LSETBANK0	(0<<6)	// Bank to play 0 or 1 (non set bank is written to)
#define SG30LSETBANK1	(1<<6)
#define SG30LPLAY		(1<<7)	// Output sound
#define SG30LSTOP		(0<<7)	// Stop sound output

#define SG30HSNDLENGTH(n)	n		// Length of sound playback (0-255)
#define SG30HOUTPUTMUTE		(0<<13)	// Mute output
#define SG30HOUTPUT1		(1<<13)	// Output unmodified
#define SG30HOUTPUT12		(2<<13)	// Output 1/2 (right shift of 1)
#define SG30HOUTPUT14		(3<<13)	// Output 1/4 (right shift of 2)
#define SG30HOUTPUT34		(1<<15) // Output 3/4

#define SG31FREQUENCY(n)	n		// 11-bit frequency data
#define SG31PLAYONCE		(1<<14)	// Play sound once
#define SG31PLAYLOOP		(0<<14)	// Play sound looped
#define SG31INIT			(1<<15)	// Makes the sound restart

// SOUND 4 //

#define SG40	*(u16*)0x04000078		// Addresses to sound 4 registers
#define SG41	*(u16*)0x0400007C

#define SG40SNDLENGTH(n)		n		// Sound length (0-63)
#define SG40ENVELOPESTEPS(n)	(n<<8)	// Envelope steps (0-7)
#define SG40ENVELOPEINC			(1<<11)	// Increase or decrease envelope
#define SG40ENVELOPEDEC			(0<<11)	
#define SG40ENVELOPEINIT(n)		(n<<12)	// Initial envelope value

#define SG41DIVRATIOFREQSEL(n)	n		// (0-7)
#define SG41STEPS7				(1<<3)
#define SG41STEPS15				(0<<3)
#define SG41SHIFTFREQ(n)		(n<<4)	// (0-15)
#define SG41PLAYONCE			(1<<14)
#define SG41PLAYLOOP			(0<<14)
#define SG41INIT				(1<<15)

////////////////
// PROTOTYPES //
////////////////
/*
void DMA3DataCopy16(u32 Dst, u32 Src, u16 Count);
void DMA3DataZero16(u32 Data, u16 Count);
void WaitForVBlank();
void WaitForVLine(u16 nLine);
void Flip(void);
*/

#endif











