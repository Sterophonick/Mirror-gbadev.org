 Calculator Advance
-=-=-=-=-=-=-=-=-=-=-

About:
------
This is, well, a calculator, somewhat self explainitory. 
This rom image is multibootable with a MBv2 cable or whatever, but I'm gunna stick it in my PogoShell1.0/root folder...

Controls:
---------
arrows = select button
a      = adds to buffer/evaluates buffer/nothing - depends on the button thats
         tinted
b      = backspace
start  = changes the buffer to "3+5", for testing purposes, I guess it 
         could be changed to an equals button
select = clear the buffer
You can also hold the shoulder buttons to do a soft reset


Features:
---------
- Adding, Subtracting
- Multplication, Division
- Order of operations (try something like 2+2*2)
- Still small enough for multiboot ;)

Credits:
--------
Kyle Kienapfel did the crappy programming
Jeremiah Watt (Jbond64) did the graph (yes, singular)


Todo:
-----
* Write a todo

Version History
---------------
First working version did only one operation, second version didn't follow order of operations, this one does.

�23:44� <NuttO> Copy the entire text of another readme file, because, hey, who the fuck reads them?
