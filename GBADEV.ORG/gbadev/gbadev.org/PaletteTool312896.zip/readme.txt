----------------------------------------------------------
PaletteTool version 3.1 - Test Breakdown

Windows tool to help manage 8-bit bitmap palettes.

Features:

- Edit entries with colour picker
- Duplicate range of entries within a bitmap
- Swap range of entries (with remap pixels option)
- Paste range of entries from a different bitmap
- Clear range of entries (with referenced pixels option)
- Friendly entry selection using mouse (Ctrl modify)
- Auto select similar entries (with tolerance)
- Adjust brightness over a range of entries
- Adjust saturation over a range of entries
- Adjust hue over a range of entries
- Generate ramped range of entries
- Create new bitmaps
- Preview pixels display

----------------------------------------------------------

testbreakdown@hotmail.com
