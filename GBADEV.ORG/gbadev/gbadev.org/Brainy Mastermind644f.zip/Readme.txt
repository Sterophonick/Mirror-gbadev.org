This is a simple mastermind game. You have six trials to crack the secret
code. The code consists of four tiles with six possible colors for each
of them.

Press [Left] and [Right] to choose position and [Up] and [Down] to
change color of the current tile. If you choose a tile for all four
positions then press [A] for comparing your code with the secret one...
The right hand side of the current row will show you then:
-a small black tile for every right colored tile on right position
-a small white tile for every right colored tile on wrong position
-no small tile if there is nothing right

Did you understand?
So four small black tiles mean your code is right, otherwise use the next
row for your next try.

Have fun!