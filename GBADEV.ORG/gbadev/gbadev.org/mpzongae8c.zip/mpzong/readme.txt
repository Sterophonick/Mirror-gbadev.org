I originally created this multiplayer pong game as a test where I could isolate
multiplayer code in the simplest possible game. I intended to release the 
source code to get feed back from the community on how to work out the problems.
Seems as though there's not much interest in the subject though and I was able
to work out most of my problems along the way so far. So there you have it, the 
most basic possible 2 player pong game.

This is just a rough demo at the moment, but I thought I'd release it in case 
anyone has interest in the subject or game. Some time in December I'll make a
final release including better menus, sound and source.

Instructions:
Connect 2 gbas via a link cable. Power on the first gba and start multipzong. At
the menu choose to send multiboot image. Turn the 2nd gba on. If a connection is
made, the scrolling background on the 1st gba will pause and the second gba will 
chime. Once both gbas are running the game choose Start multiplayer game. Enjoy!

Special thanks to www.suddenpresence.com for their multiplayer code.
Special thanks to Damian Yerrick for his multiboot replicating code and advice on
the gbadev forum - www.pineight.com
Special thank to Jason Rogers (dovoto) for the spark and everything else 
www.thepernproject.com

Visit www.superfighter.net
Visit www.oldergames.com

Thanks for playing!
johnny_north@hotmail.com
120103
