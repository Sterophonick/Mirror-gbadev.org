Wav2Raw v1.0 for Game Boy Advance by Sylvain Rochette
Mail: corrosif@altern.org
Note: Wav2Raw convert a 8 bits mono wav file to a raw file
    and to C source code file

Use: Wav2Raw <filename> -c
    -c Generate C source file that content the wav data

Extra note: The array generated content the hole wav data
            but the first 4 bytes content the size of the buffer
            for the C and raw mode as well

Example:
	extern "C" const u32 g_wav_intro[ 83601 + 1 ];

	// Wav size
	g_wav_intro[ 0 ]

	// Wav Data
	&g_wav_intro[ 1 ]

Enjoy! :)

