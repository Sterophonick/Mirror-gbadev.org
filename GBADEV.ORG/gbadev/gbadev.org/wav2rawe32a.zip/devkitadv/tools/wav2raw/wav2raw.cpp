//
// Wav2Raw by Sylvain Rochette
// Mail: corrosif@altern.org
// 
// Dont forget to send me a mail for suggestion!
// TODO?: Convert 16 bits to 8 bits wav ?!
//        Support channels?
//

#include <stdio.h>
#include <string.h>

// Type
typedef unsigned char  BYTE;
typedef unsigned short WORD;
typedef unsigned long  DWORD;

// MMIO macros
#define MAKEFOURCC(ch0, ch1, ch2, ch3)                              \
		((DWORD)(BYTE)(ch0) | ((DWORD)(BYTE)(ch1) << 8) |   \
		((DWORD)(BYTE)(ch2) << 16) | ((DWORD)(BYTE)(ch3) << 24 ))
#define mmioFOURCC(ch0, ch1, ch2, ch3)  MAKEFOURCC(ch0, ch1, ch2, ch3)

typedef struct tWAVEFORMATEX
{
    WORD        wFormatTag;         /* format type */
    WORD        nChannels;          /* number of channels (i.e. mono, stereo...) */
    DWORD       nSamplesPerSec;     /* sample rate */
    DWORD       nAvgBytesPerSec;    /* for buffer estimation */
    WORD        nBlockAlign;        /* block size of data */
    WORD        wBitsPerSample;     /* number of bits per sample of mono data */
    WORD        cbSize;             /* the count in bytes of the size of */
} WAVEFORMATEX;

// Parse the wav sound data
bool parse_wav_data( BYTE* pData, BYTE** ppWaveData, DWORD& size, WAVEFORMATEX& wf )
{
	bool   found = false;
	DWORD* ptr;
	DWORD* pEnd;
	DWORD  riff;
	DWORD  type;
	DWORD  length;

	if( ppWaveData )
	{
        *ppWaveData = NULL;
	}

	size   = 0;
    ptr    = (DWORD*)pData;
    riff   = *ptr++;
    length = *ptr++;
    type   = *ptr++;

	if( riff != mmioFOURCC( 'R', 'I', 'F', 'F' ) ||
		type != mmioFOURCC( 'W', 'A', 'V', 'E' ) )
	{
		return false;
	}

    pEnd = (DWORD *)((BYTE *)ptr + length - 4 );

	while( ptr < pEnd )
	{
        type   = *ptr++;
        length = *ptr++;

        switch( type )
        {
			case mmioFOURCC( 'f', 'm', 't', ' ' ):
			{
				if( !found )
				{
					found = true;
					memcpy( &wf, ptr, sizeof( wf ) );

					if( ( !ppWaveData || *ppWaveData ) && size )
					{
						return true;
					}
				}
				break;
			}

			case mmioFOURCC( 'd', 'a', 't', 'a' ):
			{
				if( ( ppWaveData && !*ppWaveData ) || !size )
				{
					*ppWaveData = (BYTE*)ptr;
					size = length;

					if( found )
					{
						return true;
					}
				}
				break;
			}
        }

        ptr = (DWORD *)((BYTE *)ptr + ( ( length + 1 ) &~1 ) );
    }

    return false;
}

// Create C code
bool create_c_code( char* strip_name, DWORD* pWav, DWORD size )
{
	bool  r = true;
	DWORD i;
	FILE* file;
	char  file_name[ 1024 ];

	// Generate the mode text c++ version
	printf( "Creating wav_%s.c file...\n", strip_name );
	sprintf( file_name, "wav_%s.c", strip_name );
	file = fopen( file_name, "wt" );
	if( !file )
	{
		printf( "Can't write c++ source to file\n" );
		r = false;
	}
	else
	{
		// Write header
		fprintf( file, "#include <gba.h>\n\nconst u32 g_wav_%s[ %d + 1 ] =\n{\n", strip_name, size );
		fprintf( file, "\t%d, // wav length\n\n\t// wav data\n", size << 2 );

		// Write data
		for( i = 0 ; i < size; )
		{
			fwrite( "\t", 1, 1, file );

			for( int j = 0 ; j < 64 && i < size; i++, j++ )
			{
				fprintf( file, "0x%08X", pWav[ i ] );

				if( i + 1 < size && j + 1 < 64 )
				{
					fwrite( ", ", 2, 1, file );
				}
			}

			if( i + 1 < size )
			{
				fwrite( ",\n", 2, 1, file );
			}
		}

		// Write footer
		fprintf( file, "\n};\n" );
		fclose( file );

		// Generate the header
		sprintf( file_name, "wav_%s.h", strip_name );
		printf( "Creating wav_%s.h file...\n", strip_name );
		file = fopen( file_name, "wt" );
		if( !file )
		{
			printf( "Can't write c++ header to file\n" );
			r = false;
		}
		else
		{
			char upper[ 256 ];

			strcpy( upper, strip_name );
			strupr( upper );

			// Write header
			fprintf( file, "#ifndef _WAV_%s_H_\n#define _WAV_%s_H_\n\n#include <gba.h>\n\nextern \"C\" const u32 g_wav_%s[ %d + 1 ];\n\n#endif\n", upper, upper, strip_name, size );
		}
	}

	fclose( file );
	return r;
}

// Create raw file
bool create_raw( char* strip_name, DWORD* pWav, DWORD size )
{
	char  file_name[ 1024 ];
	FILE* file;

	sprintf( file_name, "wav_%s.raw", strip_name );
	file = fopen( file_name, "wb" );
	printf( "Creating %s file...\n", file_name );

	if( !file )
	{
		printf( "Cannot create the raw file...\n" );
		return false;
	}

	size <<= 2;

	fwrite( &size, 1, 4, file );
	fwrite( pWav, 1, size, file );
	fclose( file );

	return true;
}

// Open a wav from the pak file
bool open( const char* pFileName, bool c )
{
	// open the file
	FILE* file;

	printf( "Opening %s file...\n", pFileName );

	file = fopen( pFileName, "rb" );

	if( !file )
	{
		printf( "Cannot open the file...\n" );
		return false;
	}

	// read the entire buffer
	fseek( file, 0, SEEK_END );
	DWORD size = ftell( file );

	BYTE* pBuffer = new BYTE[ size + 4 ];
	
	memset( pBuffer, 0, size + 4 );
	fseek( file, 0, SEEK_SET );
	fread( pBuffer, 1, size, file );

	BYTE* pWaveData;
	DWORD bytes;
	WAVEFORMATEX wf;

	if( parse_wav_data( pBuffer, &pWaveData, bytes, wf ) )
	{
		DWORD i = strlen( pFileName );
		char strip_name[ 1024 ];

		strcpy( strip_name, pFileName );

		while( i >= 0  )
		{
			if( pFileName[ i ] == '.' )
			{
				strip_name[ i ] = NULL;
				break;
			}

			i--;
		}

		// Adjust for signed mode (GBA)
		for( i = 0; i < bytes; i++ )
		{
			pWaveData[ i ] -= 128;
		}

		// Must be a multiple of 4
		int rest = bytes % 4;
		DWORD  size_32 = bytes;
		DWORD* pWav = (DWORD*)pWaveData;

		size_32 >>= 2;
		if( rest )
		{
			memset( pWaveData + bytes, 0, 4 );
			size_32++;
			bytes = size_32 << 2;
		}

		if( create_raw( strip_name, pWav, size_32 ) )
		{
			if( c )
			{
				create_c_code( strip_name, pWav, size_32 );
			}
		}
	}
	else
	{
		printf( "Invalid wav format...\n" );
	}

	delete pBuffer;
	fclose( file );

	return true;
}

int main(int argc, char* argv[])
{
	printf( "Wav2Raw v1.0 for Game Boy Advance by Sylvain Rochette\n" );
	printf( "Mail: corrosif@altern.org\n" );
	printf( "Note: Wav2Raw convert a 8 bits mono wav file to a raw file\n" );
	printf( "      and to C source code file\n\n" );

	if( argc < 2 )
	{
		printf( "Use: Wav2Raw <filename> -c\n    -c Generate C source file that content the wav data\n\n" );
		printf( "No filename found! Please make sure the filename parameter exist...\n" );
		return 1;
	}

	bool c = false;

	if( argc == 3 )
	{
		c = !stricmp( argv[ 2 ], "-c" );
	}

	return open( argv[ 1 ], c ) == false;
}



