GBAC Sprite System Demo
=======================

Here is a demo that uses C code and structs as opposed to 
C++, GCC standard libs, and the dynamic memory manager.  As you 
can see by the demo, it is extremely quicker than Wonkie Guy.  
It features 96 fully independent, free moving, frame animated, 
boundary obeying sprites.  It also includes a main-scrolling 
background whose map is larger than 256x256 pixels.

Sean Reid
email@seanreid.ca
http://seanreid.ca
