 ________  ________  ________  ________  ________  ________  ________
/________//________//________//________//________//________//________/

                      ___ ___ ___ __  __  ___ ____ _  _
                     / . / __/ __/, //, \/   /_ __/ |/ /
                    / __/ __/ __/, </  </ ^ /_//_/  / /
                   /_/ /___/___/___/_/\_\/_/____/_/__/
                                               ___
                     _    _ _  _ ___ __  ___  /__ \
                    | |/|/ / // / __/, \/ __/    > >
                    |     / _  / __/  </ __/   /_/
                    |_/|_/_//_/___/_/\_\__/   _
                                             /_/

                      http://www.pbwhere.com
 ________  ________  ________  ________  ________  ________  ________
/________//________//________//________//________//________//________/
    _ _                                                       _ _
   / / /                        GbAME                         \ \ \
  / / /                      v 1.0 4-bit                       \ \ \
 /_/_/                                                          \_\_\
 \ \ \                       by Peebrain                        / / /
  \ \ \                                                        / / /
   \_\_\                    June 28, 2003                     /_/_/
 ________  ________  ________  ________  ________  ________  ________
/________//________//________//________//________//________//________/

Contents of GbAME10.zip
                  _
   GbAME.exe     / /   The executable
  ReadMe.txt    / /   The file you're looking at
 FreeImage.dll /_/   FreeImage Library, see license-fi.txt for details
license-fi.txt \ \    FreeImage License
 sample.gma     \_\    Sample map file
 ________  ________  ________  ________  ________  ________  ________
/________//________//________//________//________//________//________/

Comments

Wrote this tool in about a week.  I think it's pretty cool. Basically,
I had been looking for a good map editor out there, and came across
the cheesy one on PERN Project and it inspired me to write this.  I
like to keep a good outline of my goals, and my goals for this project
was to JUST EDIT 4-BIT MAPS.  I put in a simple tile and palette
editor just because sometimes you need to tweak things - but don't get
me wrong.  This tool is not for editing tilesets.  You should edit
images using an image editing program like PSP or something.  Then
import it into the Map editor.  Palettes are the same way, edit with
something else (like gbapal.exe on my site), then import it.

The app is simple though, and pretty self explanatory I think.  All
tilesets must be 256 x 256, no bigger no smaller.  These are the
exact tiles that will be in the VRAM for your Map.  The map size
can be anything though.  The cool feature of this program I think is
multiple layers.  You can add a layer no problem, just right click
and hit "new layer".  You can also set a layer as transparency so you
can see stuff under it for easier editing.

The source code is on my site.  Feel free to hack, edit, rip apart,
crack, steal, whatever.  If you have questions, suggestions, etc,
feel free to email at the address below.

Oh yeah, let me explain the app just a little bit more.  Each layer
acts the same, except for the Background layer.  That layer is
special: it doesn't have any clear colors, and it defines how big
the map is.  The other layers build off of the background layer.
There is only one background layer per map.

I do plan on making a Meta-Map editor, which I'm told means that
you use it to put maps together to form a bigger map.  That
project has been named gBAMm, so keep your eyes open for it.

- Peebrain

peebrain[SHIFT+2]pbwhere.com

http://www.pbwhere.com
 ________  ________  ________  ________  ________  ________  ________
/________//________//________//________//________//________//________/