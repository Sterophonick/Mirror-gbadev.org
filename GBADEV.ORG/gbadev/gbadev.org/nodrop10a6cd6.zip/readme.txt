-------------------------------------------------------------------------------
Game			: No Drop v1.0a
-------------------------------------------------------------------------------
Author                  : Warder1
Email Address           : warder@nolag.com
Webpage			: www.nolag.com/code/gbdev
-------------------------------------------------------------------------------
Controls
-------------------------------------------------------------------------------
Left + Right	: Moves pieces
Down			: Drops pieces
A			: Rotates piece
-------------------------------------------------------------------------------
Use with:
-------------------------------------------------------------------------------
Mappy v.5  available at : www.agbdev.net/joat
IGBA v8 only displays the title screen then crashes because of
		Bios access
Not sure if it works on real hardware, someone let me know
-------------------------------------------------------------------------------
Info
-------------------------------------------------------------------------------
This is a GBA port of Shen's game No Drop, available at:
http://shen.mansell.tripod.com
It's a tetris/Dr. Mario type game.  Using A to rotate, you move the pieces
and try and line up 4 of the same color.  When you do they disappear, but the
remaining pieces don't drop, hence the name.
Right now this is just a down and dirty port, with a new title screen by me.
It's very simple.  I'm hoping to turn it into a port of Super Puzzle Right II
Turbo, eventually.  Right now, it works, so I'm releasing it.
Cheers
-------------------------------------------------------------------------------
Versions
-------------------------------------------------------------------------------
v1.0a
-------------------------------------------------------------------------------
-Should work on real hardware now, plus input is fixed
-------------------------------------------------------------------------------
v1.0
-------------------------------------------------------------------------------
-Initial release
-------------------------------------------------------------------------------