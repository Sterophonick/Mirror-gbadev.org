
NINJA-BEAR by DKA Productions

www.dkaproductions.com


Keys:

A: jump
B: attack
R: run and dash attack
L: block