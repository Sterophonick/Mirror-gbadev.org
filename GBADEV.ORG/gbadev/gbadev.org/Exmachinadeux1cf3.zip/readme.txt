Ex:Machina Deux Readme

Hey, first of all thank you for downloading for my first GBA game I have made.  Hopefully the 
first of many!  I loved the idea of devil may cry and so though the same premise would be
awesome on the GBA so hence I set to work on this baby.  Hope you enjoy.

Controls

Start: select option/pause game
Select: change which enemy you have targeted
Dpad: move the player
B button: jump
A button: shoot
L button: transform
R button: dodge

Features

Combo shooting:

If you hold the shoot button down, a combo traget will appear.  Then you can select the
enemy you want to open a whole world of pain onto.  Once you have your target press 
the shoot button again to launch into a combo attack which is continued through continious shooting.  
Also if you press the B button when you have your target our hero will hold the enemy down so he 
can be layed into!  This needs to mastered to defeat certain enemys.

Dodging:

Keep a close eye to the screen, when the enemy and yourself flash white, bash the R button to dodge.  
You can do this multiple times during a dodge which adds to your score.  This is signified by either
EX:1, Ex:2, EX:3 in the top right hand corner

Transforming:

Below the health bar is a charge bar, when this is filled our hero can transform into a being of pure energy.  
This makes him faster and more powerful.  Also when transformed if the player presses the L button again, all 
the eneimies on-screen will be desroyed.  However use this wisely as uses all of the charge.

Score combo system:

With this new version Ive implemented a combo scoring system.  This works through the player starting a combo
to which the "Create" icon appears on screen, then do as many combos in a consequtive order as possible to
reach different score multipliers for that coverted highscore.  In addition try adding a well timed dodge to
further your highscore dreams

When attacking the enemies watch the contact flash.  If its red you are doing some damage, but if its blue, 
you need to find a different way to kill.

Modes:

Main game:  The story mode.  Dont really have a story at the moment though.  You fight your way through the hordes 
            of enemies and then are faced with a boss.

Melee:  Endless amounts of enemies, try to rack up your highest score. Bok!

Highscores:  Take a peek at the highscore table.  Are you on?

Like i say this is my first game so i really want some feedback.  Anything, even if its a slate, it can only make 
me better.  Hope you do like it though, alot of work went into it.

My email: lewisrevill@btinternet.com
 

