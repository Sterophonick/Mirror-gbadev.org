#include "gba.h"
#include "sprite.h"
#include "box.h"

void InitializeSprites(void);
void WaitForVsync(void);
void CopyOAM(void);

s16 x = 10;
s16 y = 10;
u16 char_number = 0;

int main(void) {
	int index = 0;
	u16 loop;

	SetMode(MODE_2 | OBJ_ENABLE | OBJ_MAP_1D);

	for(loop = 0; loop < 256; loop++)
		OBJPaletteMem[loop] = boxpal[loop];

	InitializeSprites();

	sprites[0].attribute0 = COLOR_256 |y;
	sprites[0].attribute1 = SIZE_16 |x;
	sprites[0].attribute2 = char_number;

	for(index = 0; index < 64*8; index++) {
		OAMData[index] = boxdata[index];
	}

	while(1)
	{
		WaitForVsync();
		CopyOAM();
	}
}

void InitializeSprites(void)
{
	int loop;
	for(loop = 0; loop < 128; loop++)
	{
		sprites[loop].attribute0 = 160;  //y to > 159
		sprites[loop].attribute1 = 240;  //x to > 239
	}
}

void WaitForVsync(void)
{
	while(REG_VCOUNT<160);
}

void CopyOAM(void)
{
	u16 loop;
	u16* temp;
	temp = (u16*)sprites;
	for(loop = 0; loop < 128*4; loop++)
	{
		OAM[loop] = temp[loop];
	}
}
