#ifndef BASE_HEADER
#define BASE_HEADER

#define BG0_ENABLE 0x100
#define BG1_ENABLE 0x200
#define BG2_ENABLE 0x400
#define BG3_ENABLE 0x800
#define OBJ_ENABLE 0x1000
#define WIN0_ENABLE 0x2000
#define WIN1_ENABLE 0x4000
#define WINOBJ_ENABLE 0x8000

#define BACK_BUFFER 0x10

//Registers
#define REG_DISPCNT    *(ULONG*)0x4000000

//Screen Video Modes
#define MODE0 0x0
#define MODE1 0x1
#define MODE2 0x2
#define MODE3 0x3
#define MODE4 0x4
#define MODE5 0x5
#define SCREENWIDTH 240
#define SCREENHEIGHT 160

//Type Definitions
typedef unsigned char UCHAR;    //8
typedef unsigned short USHORT;  //16
typedef unsigned long ULONG;    //32

typedef signed char CHAR;
typedef signed short SHORT;
typedef signed long LONG;

typedef unsigned char BYTE;
typedef unsigned short SWORD;
typedef unsigned long WORD;

//Macros
#define RGB16(r,g,b)  ((r)+(g<<5)+(b<<10)) //Returns 15bit RGB value. 0>= rgb <=31
#define SetMode(mode) REG_DISPCNT = (mode)

#endif
