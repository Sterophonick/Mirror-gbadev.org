#include "base.h"
#include "image.h"

USHORT* ScreenBuffer = (USHORT*)0x6000000;

int main()
{
   USHORT loop;

   SetMode(MODE3 | BG2_ENABLE);

   for(loop=0;loop<38400;loop++) {
      ScreenBuffer[loop] = sampledata[loop];     
   }

   while(1){}
}
