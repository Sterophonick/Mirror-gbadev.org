#include "base.h"
#include "image.h"

USHORT* ScreenBuffer = (USHORT*)0x6000000;
USHORT* ScreenPal = (USHORT*)0x5000000;

int main()
{
   USHORT loop;
   USHORT x,y;

   SetMode(MODE4 | BG2_ENABLE);

   for(loop=0;loop<256;loop++) {
      ScreenPal[loop] = samplepal[loop];     
   }

   for(loop=0;loop<19200;loop++) {
      ScreenBuffer[loop] = sampledata[loop];
   }

   while(1){}
}
