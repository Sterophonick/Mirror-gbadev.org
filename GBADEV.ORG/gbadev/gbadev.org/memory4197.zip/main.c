/************************************************************************************
*																					*
*		Copyright 2002, Nils Widmer, nils.widmer@maratron.com						*
*		----------------------------------------------------------------------------*
*		www.maratron.com															*
*																					*
*		This is the spurce code for a little Game Boy Advance memory game entitled:	*
*		ECO-MEMORY																	*
*																					*
*		This uses Hamlib from www.engine.de, if u dont have Hamlib u cant			*
*		compile this code.															*
*		This code might be very buggy, btw all done from today 10am					*
*		till now 0.30am (so Im excused:)(Random doesnt provide random for every		*
*		new game obviously, maybe I fix that tomorrow)								*
*																					*
*		You may use this freely as long as you mention my name						*
*		and this message here above stays in tact									*
*																					*
*		Go visit our current GBA project ECOLINC @ www.ecolinc.com					*
*																					*
************************************************************************************/



#include "mygba.h"
//title graphics:
#include "gfx/title.raw.c"
#include "gfx/title.pal.c"
#include "gfx/presents.raw.c"
#include "gfx/presents.pal.c"
#include "gfx/main_title.raw.c"
#include "gfx/main_title.pal.c"
#include "gfx/gameover.raw.c"
#include "gfx/gameover.pal.c"
//the questionmark On/Off:
#include "gfx/questionmark.raw.c"
//the master sprite palette used during gameplay:
#include "gfx/master.pal.c"
//the pictures themselves(4 pics in each file, 1 file=32*128):
#include "gfx/set1.raw.c"
#include "gfx/set2.raw.c"
#include "gfx/set3.raw.c"
//the start button:
#include "gfx/start_btn.raw.c"
#include "gfx/start_btn.pal.c"

MULTIBOOT


#define NUM_PICTURES 24


typedef struct Field
{
	u8 nStatus;//0 = not revealed, 1 = turned on, 2 = revealed
	u8 nMatch;
	u8 nThis;
	u8 sprite;
	u8 IsTaken;	
}*PFIELD, FIELD;


//the sprites:
u8 myquestionmarkOff[NUM_PICTURES];
u8 myquestionmarkOn;
u8 mystartbtn;

//the current selected field:
u16 CurrentField = 0;

//the fields:
FIELD MyField[NUM_PICTURES];
//lookup table for coordinates:
u16 CoordLookup[2][NUM_PICTURES];

#define STATE_LOGO			0
#define STATE_PRESENTS		1
#define STATE_MAIN_SCREEN	2
#define STATE_INITIALIZE	3
#define STATE_GAME			4
#define STATE_OVER			5

u8 nDirection = 0;
#define DIRECTION_UP        0
#define DIRECTION_RIGHT     1
#define DIRECTION_DOWN      2
#define DIRECTION_LEFT      3

u8 GAME_STATE = STATE_LOGO;//first we show logo:)
u8 nSwitch  = 0;//used for tracking start button on and off flash
u32 frames  = 0;//frames we count
u16 ii=0;//general purpose counter
//have we pressed a button?
u8 bPressed = 0;
//mark if its second or first of a pair that has been turned on:
u8 nTurned = 0;
//main check if game is done and whether we should reboot:
u8 bGameDone = 0;

//functions
void InitGameScreen();
void CleanGameScreen();
void RandomizeFields();
void InitFields();
void CreateField(u8 random1, u8 random2, u8 num);
void HandleKeys();
void HideAllPics();
void UncoverField(u8 field);
u8 AllRevealed();//returns 0 if not all are revealed, returns 1 if all are revealed, thus Game finished 
void HideWrongPairs();


void InitGameScreen()
{
	//first init questionmarks:
	u16 startx = 15;
	u16 xlocation = startx; 
	u16 ylocation = 11;
	u16 ii = 0;

	for(ii=0; ii<NUM_PICTURES;ii++)
	{
		CoordLookup[0][ii] = 0;
		CoordLookup[1][ii] = 0;
	}
	 
	myquestionmarkOff[0] = ham_CreateObj(&questionmark_Bitmap[0],0,2,OBJ_MODE_NORMAL,1,0,0,0,0, xlocation, ylocation);	
	//set first lookups
	CoordLookup[0][0] = xlocation;
	CoordLookup[1][0] = ylocation;
	//clone the rest of questionmarks, since all the same
	for( ii=1; ii<NUM_PICTURES; ii++ )
	{
		if( ii%6==0 )
		{
			ylocation += 34;
			xlocation = startx;
		}
		else
		{	
			xlocation += 36;
		}
		myquestionmarkOff[ii] = ham_CloneObj(myquestionmarkOff[0],xlocation,ylocation);
		//fill coordinate lookuptable:
		CoordLookup[0][ii] = xlocation;
		CoordLookup[1][ii] = ylocation;
	}
	//the "on" questionamrk for highlighting:
	myquestionmarkOn = ham_CreateObj(&questionmark_Bitmap[32*32],0,2,OBJ_MODE_NORMAL,1,0,0,0,0, CoordLookup[0][CurrentField], CoordLookup[1][CurrentField]);
	ham_LoadObjPal(&master_Palette,256);
	
	RandomizeFields();
}


void CleanGameScreen()
{
	for(ii=0;ii<NUM_PICTURES;ii++)
	{
		ham_DeleteObj(myquestionmarkOff[ii]);
	}
	for(ii=0;ii<NUM_PICTURES;ii++)
	{
		ham_DeleteObj(MyField[ii].sprite);
	}
	ham_DeleteObj(myquestionmarkOn);
}

void InitFields()
{
	for(ii=0;ii<NUM_PICTURES;ii++)
	{
		MyField[ii].nStatus = 0;
		MyField[ii].IsTaken = 0;
		MyField[ii].nMatch  = 32;
		MyField[ii].nThis   = 32;
	}
}

void RandomizeFields()
{
	u8 random		= 0;
	u8 matchrandom	= 0;
	u8 whilecounter = 0;
	u8 foundmatch   = 0;
	u8 allfound	= 0;

	//reset the fields:
	InitFields();
	
	while( allfound<NUM_PICTURES-1)
	{
		//srand(allfound+1);
		random = abs(rand()%NUM_PICTURES);
		foundmatch = 1;
		for( ii=0;ii<NUM_PICTURES;ii++ )
		{
			if( MyField[ii].nThis == random )
			{
				foundmatch=0;
				break;
			}
		}
		if( foundmatch==0 )//this random is already taken
		{
			continue;
		}
				
		MyField[allfound].IsTaken = 1;
		MyField[allfound].nThis = random;
		
		
		while(1)
		{
			
			matchrandom = abs(rand()%NUM_PICTURES);
			foundmatch = 1;
			for( whilecounter = 0; whilecounter < NUM_PICTURES; whilecounter++ )
			{
				if( MyField[whilecounter].nThis == matchrandom )
				{
					foundmatch=0;
					break;
				}
			}
			if( foundmatch==0 )//this random is already taken
			{
				continue;
			}
			else
			{
				allfound++;
				MyField[allfound].IsTaken  = 1;
				MyField[allfound].nThis    = matchrandom;
				MyField[allfound-1].nMatch = matchrandom; 
				MyField[allfound].nMatch  = MyField[allfound-1].nThis;
				allfound++;
				CreateField( random, matchrandom, allfound );
				break;
			}
		}//end while()
	}//end while()
}

void CreateField(u8 random1, u8 random2, u8 num)
{
	if(num>=2 && num<10)
	{
		MyField[num-2].sprite = ham_CreateObj(&set1_Bitmap[32*32*((num-2)/2)],0,2,OBJ_MODE_NORMAL,1,0,0,0,0, CoordLookup[0][random1], CoordLookup[1][random1]);
	}
	else if(num>=10 && num < 18)
	{
		MyField[num-2].sprite = ham_CreateObj(&set2_Bitmap[32*32*((num-10)/2)],0,2,OBJ_MODE_NORMAL,1,0,0,0,0, CoordLookup[0][random1], CoordLookup[1][random1]);
	}
	else// if(num>=18 && num <26)
	{
		MyField[num-2].sprite = ham_CreateObj(&set3_Bitmap[32*32*((num-18)/2)],0,2,OBJ_MODE_NORMAL,1,0,0,0,0, CoordLookup[0][random1], CoordLookup[1][random1]);
	}
	MyField[num-1].sprite = ham_CloneObj(MyField[num-2].sprite,CoordLookup[0][random2], CoordLookup[1][random2]);	
}



void HandleKeys()
{	
	//check that we dont select already uncovered fields:
	for( ii=0; ii<NUM_PICTURES; ii++ )
	{	
		if( MyField[ii].nThis == CurrentField && MyField[ii].nStatus != 0 )
		{
			
			if(nDirection == DIRECTION_RIGHT)
			{
				if( ++CurrentField >= NUM_PICTURES )
				{	
					CurrentField = 0;
				}
			}
			else
			{
				if( CurrentField == 0 )
					CurrentField = 23;
				else
					CurrentField -= 1;
			}

			ham_SetObjX(myquestionmarkOn,CoordLookup[0][CurrentField]); 
			ham_SetObjY(myquestionmarkOn,CoordLookup[1][CurrentField]);
			ii=0;//check again in new field isnt also taken
		}
	}
	
	//add delay for when u uncover fields:
	if( frames < 90 )
		return;
	else if( frames == 90 )
		     HideWrongPairs();


	if(F_CTRLINPUT_DOWN_PRESSED)
	{
		if(bPressed == 1)
			return;
		else
			bPressed = 1;
		
		nDirection = DIRECTION_DOWN;
		
		//show selection:
		ham_SetObjVisible( myquestionmarkOn, 1 );
		
		if(CurrentField < 18)
		   CurrentField += 6;
		else
		{
			switch(CurrentField)
			{
				case 18:
					CurrentField = 0;
					break;
				case 19:
					CurrentField = 1;
					break;
				case 20:
					CurrentField = 2;
					break;
				case 21:
					CurrentField = 3;
					break;
				case 22:
					CurrentField = 4;
					break;
				case 23:
					CurrentField = 5;
					break;
				default:
					CurrentField = 0;
					break;
			}
		}
		ham_SetObjX(myquestionmarkOn,CoordLookup[0][CurrentField]); 
		ham_SetObjY(myquestionmarkOn,CoordLookup[1][CurrentField]);
	}
	else if(F_CTRLINPUT_UP_PRESSED)
	{
		if(bPressed == 1)
			return;
		else
			bPressed = 1;

		nDirection = DIRECTION_UP;
		
		//show selection:
		ham_SetObjVisible( myquestionmarkOn, 1 );
		
		
		if(CurrentField > 5)
		   CurrentField -= 6;
		else
		{
			switch(CurrentField)
			{
				case 0:
					CurrentField = 18;
					break;
				case 1:
					CurrentField = 19;
					break;
				case 2:
					CurrentField = 20;
					break;
				case 3:
					CurrentField = 21;
					break;
				case 4:
					CurrentField = 22;
					break;
				case 5:
					CurrentField = 23;
					break;
				default:
					CurrentField = 23;
					break;
			}
		}
		ham_SetObjX(myquestionmarkOn,CoordLookup[0][CurrentField]); 
		ham_SetObjY(myquestionmarkOn,CoordLookup[1][CurrentField]);
	}
	else if(F_CTRLINPUT_RIGHT_PRESSED)
	{
		if(bPressed == 1)
			return;
		else
			bPressed = 1;
	
		nDirection = DIRECTION_RIGHT;
		
		//show selection:
		ham_SetObjVisible( myquestionmarkOn, 1 );
		
		if(++CurrentField >= NUM_PICTURES )
			CurrentField = 0;
		ham_SetObjX(myquestionmarkOn,CoordLookup[0][CurrentField]); 
		ham_SetObjY(myquestionmarkOn,CoordLookup[1][CurrentField]);
	}
	else if(F_CTRLINPUT_LEFT_PRESSED)
	{
		if(bPressed == 1)
			return;
		else
			bPressed = 1;

		nDirection = DIRECTION_LEFT;
		//show selection:
		ham_SetObjVisible( myquestionmarkOn, 1 );
		
		if( CurrentField == 0 )
			CurrentField = 23;
		else
			CurrentField -= 1;
		ham_SetObjX(myquestionmarkOn,CoordLookup[0][CurrentField]); 
		ham_SetObjY(myquestionmarkOn,CoordLookup[1][CurrentField]);
	}
	else if(F_CTRLINPUT_A_PRESSED || F_CTRLINPUT_B_PRESSED)
	{
		if(bPressed == 1)
			return;
		else
			bPressed = 1;
		UncoverField(CurrentField);
	}
	else 
		bPressed = 0;
	
}


void HideAllPics()
{
	for(ii=0; ii<NUM_PICTURES; ii++)
		ham_SetObjVisible( MyField[ii].sprite, 0 );
}

void HideWrongPairs()
{
	for( ii=0; ii<NUM_PICTURES; ii++ )
	{
		if(MyField[ii].nStatus != 2)
		{
			MyField[ii].nStatus = 0;
			ham_SetObjVisible( MyField[ii].sprite, 0 );
			
			ham_SetObjVisible( myquestionmarkOff[MyField[ii].nThis], 1 );
		}
	}
}

void UncoverField(u8 field)
{
	u8 ntemp;
	
	for(ii=0; ii<NUM_PICTURES; ii++)
	{
		if(MyField[ii].nThis == field)
		{
			//hide selection:
			ham_SetObjVisible( myquestionmarkOn, 0 );
			//hide the "?"
			ham_SetObjVisible( myquestionmarkOff[field], 0 );
			//show picture
			ham_SetObjVisible( MyField[ii].sprite, 1 );
			//mark if its second or first of a pair that has been turned on:
			if( nTurned == 0 )
			{
				nTurned = 1; //its the first
				MyField[ii].nStatus = 1; //turn it on
				return;
			}
			else
			{
				//set back to turned off:
				nTurned = 0;
				//check what other pic we haveturned on and if they match:
				for( ntemp=0; ntemp < NUM_PICTURES; ntemp++ )
				{
					if(MyField[ntemp].nStatus == 1 )//is it turned on?
					{
						//does it match?
						if( MyField[ntemp].nMatch == MyField[ii].nThis )
						{
							//YES! it matches!!
							//uncover both and go on:
							MyField[ntemp].nStatus = 2;
							MyField[ii].nStatus	  = 2;
							if( AllRevealed()==1 )
							{
								GameOver();
							}
							return;
						}
						else
						{
							//add delay to show these pics for a while(taken care of in HandleKeys()):
							frames=0;
							//hide them internally:
							MyField[ntemp].nStatus = 0;
							MyField[ii].nStatus	  = 0;
							//hide them later at visually in beginning of HandleKeys()
							return;
						}
					}
				}//end for()
			}//end else
		}//end if
	}//end for
}//end UncoverField()


//returns 0 if not all are revealed, returns 1 if all are revealed, thus Game finished 
u8 AllRevealed()
{
	u8 revealed;
	revealed=1;
	for( ii=0; ii<NUM_PICTURES; ii++ )
	{
		if( MyField[ii].nStatus != 2 )
		{
			revealed = 0;
			return revealed;
		}
	}
	return revealed;
}

void GameOver()
{
	CleanGameScreen();
	GAME_STATE = STATE_OVER;
	//dma the presents pic:
	TOOL_DMA1_SET(&gameover_Bitmap,MEM_BG_PTR,SIZEOF_32BIT(gameover_Bitmap),DMA_TRANSFER_32BIT,DMA_STARTAT_NOW)
	// init the Palettes
	ham_LoadBGPal(&gameover_Palette,256);
	frames=0;
}


//vbl interrupt function:
void vblFunc()
{
	// Copy the objs into OAM once per frame
	ham_CopyObjToOAM();
	
    // rotate and zoom the face
	if( frames <91 && GAME_STATE <= STATE_MAIN_SCREEN )
	{
		ham_RotBg(2,0/*180-frames*2*/,120,80,0x100-270+frames*3);
	}
	else
	if( frames==250 && GAME_STATE < STATE_MAIN_SCREEN )
	{
		
		if( GAME_STATE == STATE_LOGO )
		{
			//dma the presents pic:
			TOOL_DMA1_SET(&presents_Bitmap,MEM_BG_PTR,SIZEOF_32BIT(presents_Bitmap),DMA_TRANSFER_32BIT,DMA_STARTAT_NOW)
			// init the Palettes
			ham_LoadBGPal(&presents_Palette,256);
		}
		else
		{
			//dma the main start screen:
			TOOL_DMA1_SET(&main_title_Bitmap,MEM_BG_PTR,SIZEOF_32BIT(main_title_Bitmap),DMA_TRANSFER_32BIT,DMA_STARTAT_NOW)
			// init the Palettes
			ham_LoadBGPal(&main_title_Palette,256);
			
		}
		frames=0;
		GAME_STATE++;
	}
	else if( GAME_STATE== STATE_MAIN_SCREEN && frames == 91 )
	{
		//load start button sprite here:
		mystartbtn = ham_CreateObj(&start_btn_Bitmap[0],1,3,OBJ_MODE_NORMAL,1,0,0,0,0, 87, 96);
		ham_LoadObjPal(&start_btn_Palette,256);
		
	}
	else if( GAME_STATE == STATE_MAIN_SCREEN )
	{
		//randomly blink start button
		if( F_CTRLINPUT_START_PRESSED )
		{
			//delete start button:
			ham_DeleteObj(mystartbtn);
			//change the state:
			GAME_STATE = STATE_INITIALIZE;
			//initialize the game:
			InitGameScreen();
			//dma the background pic
			TOOL_DMA1_SET(&title_Bitmap,MEM_BG_PTR,SIZEOF_32BIT(title_Bitmap),DMA_TRANSFER_32BIT,DMA_STARTAT_NOW)
			// init the Palettes
			ham_LoadBGPal(&title_Palette,256);
			//set frames back since we will wait couple of seconds:
			frames = 0;
			ii = 0; //this we need to drop away the pics below in STATE_INITIALIZE
		}
		if(frames%90==0)
		{
			//flash start button on and off:
			ham_SetObjVisible(mystartbtn, nSwitch);
			if( nSwitch == 0)
				nSwitch = 1;
			else 
				nSwitch = 0;	
		}
	}
	else if( GAME_STATE == STATE_INITIALIZE && frames > 90 )
	{
		if( F_CTRLINPUT_B_PRESSED || F_CTRLINPUT_A_PRESSED ||
			F_CTRLINPUT_START_PRESSED )
		{
			GAME_STATE++;//user skips waiting to proceed to game
			HideAllPics();
			return;
		}
		if(frames>200)
		{
			if(frames%20==0)
			{
				ham_SetObjVisible( MyField[ii].sprite, 0 );
				ii++;
				if(ii==NUM_PICTURES)
				{
					GAME_STATE++;
					return;
				}   
			}
		}
	}
	else if( GAME_STATE == STATE_GAME )
	{
//M_INTMST_DISABLE 
		HandleKeys();
//M_INTMST_ENABLE 
	}
	else if( GAME_STATE == STATE_OVER && frames > 120)
	{
		
		if( F_CTRLINPUT_B_PRESSED || F_CTRLINPUT_A_PRESSED ||
			F_CTRLINPUT_START_PRESSED )
		{
			if( bPressed == 1 )
				return;
			else
			bPressed = 1;

			GAME_STATE = STATE_PRESENTS;
			frames = 250;
			return;
		}
		else
			bPressed = 0;
	}
	
	
	frames++;
}

/*
----------------------------------
 Program entry point
----------------------------------
*/

void AgbMain(void)
{	
	// initialize HAMlib
	ham_Init();
	// set the new BGMode
    ham_SetBgMode(4);
    
	//dma the background pic
	TOOL_DMA1_SET(&title_Bitmap,MEM_BG_PTR,SIZEOF_32BIT(title_Bitmap),DMA_TRANSFER_32BIT,DMA_STARTAT_NOW)
	// init the Palettes
	ham_LoadBGPal(&title_Palette,256);

	// start hblFunc every frame
    ham_StartIntHandler(INT_TYPE_VBL,&vblFunc);
 
	while(bGameDone==0)
    {
    }    
	return;  
}


