Author: Matthew Gummo
e-mail: tomonkeyistoeror@aol.com

Controls:
	left,right,up,down - move cursor in that dir, change decks
	Start		   - conforms selections, ends displaying scores,
				deals out deck
	A		   - selects card, conforms finished tricks,
				shows next credit screen
	B		   - deslects cards, exits buying decks menu
		     
Flow of the game:
	Now that you know the keys, I'll explain the flow of the game
	so you know what is going on. Because the game will not output
	any text about illegal card selections and the such, although
	it will not allow you to select them, it would be wise to pay 
	attention to the game and know the rules of Hearts. This will 
	make some people go crazy because they won't know what is wrong,
	but it won't slow down people that just want to play the game.
	This version follows just the rules listed in part 2 
	of the heats_compo.txt file.

	-After you select "Play Hearts" in the main menu you will see
	 a deck in the middle. This is where you use the left and right
	 keys to rotate through all the decks you own. Press start when
	 you found the one you want to play with.
	-The deck will deal out and organize your hand. After that you 
	 select the three cards you want to pass to the left (this game
	 will always pass to the left) using the A key, B to deselect,
	 and press start when the three are selected.
	-All the cards will be passed and the cards you recieve will be 
	 shown to you untill you press start.
	-Now you select a card to play for the trick. Press A to select
	 a card, B to deselect the card, and Start to play the card.
	-After each trick the cards will stay untill you press the A key
	-After all cards have been played the round is done and scores will
	 be counted and displayed. Press Start to continue on.
	-Its a new round and a new deal of the cards. The deck won't be 
	 dealt out untill you press Start again.

	And the process begins anew untill a player has a score of 100 or more
	with the player with the lowest score the winner. Yes I know it looks
	complicated, but after a round or two you will get the hang of it.

Buying new decks:
	To buy new decks you use money you win after a game of Hearts.
	Select "Buy Decks" at the main menu to go to the buy decks menu.
	Use the left, right, up, and down keys to move the arrow around.
	Press A to buy a deck. B to return to the main menu.
	The most amount of money you can have is $255. After a game of Hearts
	you will recieve $ (100 - <your score>) / 2. So the lower your score,
	the more money you win. Don't forget to show off your Hearts Skillz
	by buying the Elite Gold Deck that costs $255!

Future Plans:
	If my version of Hearts is worthy enough (if people like it enough),
	I will add an in-game deck editor that will allow you to draw your 
	own decks and play them. If alot of people really want it added then
	I might be motivated to work on it.

  		     