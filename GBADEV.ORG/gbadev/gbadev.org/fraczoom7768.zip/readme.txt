Fractal Zoomer v1
Colin Brown
08 March 2002

This is my first GBA demo - its been an interesting experience, as i've used it to learn GBA, gcc, c++ and a little ARM assembly.

I used devkitAdvance by Jason Wilkins with Jeff Frohweins latest Crt0 and linkscript, Benjamin D. Hales 'GBA Project Appwizard' and visualC++6. For testing and debugging I used Mappy, VisualBoyAdvance and BoycottAdvance.


Controls a pretty rudimentary, there are no 'options' and you only get the mandelbrott set and one palette(old skool Fractint default ;))

features:
	* cool fractint palette
	* you can zoom in lots (not sure how far though)
	* high max Iterations for detail at high magnification
	* swirly colour cycling effect
	* fast guessing algorithm
	* interrupts for input testing and colour cycling - so you don't have to wait :)

keys:
	START*		-	reset the fractal and the palette
	SELECT		-	toggle colour cycling for cool swirly effects
	B button*	-	toggle the zoom target
	L flipper	-	zoom the target out
	R flipper	-	zoom the target in
	A button	-	generate a new fractal based on the target
	up
	down
	left
	right		-	move the target around
	

I havn't tested this on hardware - don't have the gear yet, but it works on the latest versions of VisualBoyAdvance and BoycottAdvance - not properly on mappy though! 

I decided not to include source code, purely because it contains loads of stuff not really needed for this demo so beginners may be confused while experienced programmers would probably learn little.

If anyone really wants the source, or has any questions or a job offer :)
please mail me at:

colin_brown@hotmail.com

Thanks (in no particular order) to:
http://www.gbadev.org/
http://www.devrs.com/gba/
Jeff Frohwein
Jason Wilkins 
Benjamin D. Hale
everyone at the gbadev yagoo group
big N
the Stone Soup Group
Forgotten
Gollum
BottledLight
all the emu coders - without whom....


cheers,

col.
