#ifndef __debug_h
#define __debug_h

#if DEBUGGING

// Multiboot debugging:
//#define DEBUG(x...) { char _t[256]; sprintf(_t, x); printf(_t); }

// VisualBoy Advance debugging:
#define DEBUG(x...) { char _t[256]; sprintf(_t, x); print(_t); }

// VisualBoy Advance debug code.
void print(char *s) {
  asm volatile(
    "mov r0, %0;"
    "swi 0xff0000;"
    : // no ouput
    : "r" (s) // inputs
    : "r0" // crushed and smushed.
  );
}

#else // i.e. DEBUGGING is false

#define DEBUG(x...)

#endif // DEBUGGING

#endif // __debug_h
