/* (c) Peter Horsman, 2001
 * Converts an xpm file to a 256col raw file. Intended for > 16 colour xpms.
 * It also expects the xpm to be multiples of 8 wide and high.
 * Pete ( dooby@bits.bris.ac.uk / http://bits.bris.ac.uk/dooby/ )
 */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#define OUT_EXT	".spr.raw"
#define TRUE (0==0)
#define FALSE (0==1)

FILE *in = NULL;
FILE *out = NULL;

void usage(char *name) {
  printf("Usage: %s [--block] <infile.xpm>\n", name);
  exit(1);
}

void quit(int e) {
  if(in != NULL) fclose(in);
  if(out != NULL) fclose(out);

  exit(e);
}

char *getLine(FILE *file) {
  char *line = NULL;
  int line_len = 0;
  int line_pos = 0;
  int c;

  /* Initialise line reader. */
  line_len = 1;
  line = realloc(line, line_len);
  if(line == NULL) {
    fprintf(stderr, "Error: Out of memory\n");
    quit(1);
  }

  c = fgetc(file);
  while(c == '\n') c = fgetc(file);
  while(c != '\n' && c != EOF) {
    line[line_pos] = c;
    line_pos ++;

    /* Allocate additional memory as necessary. */
    if(line_pos > line_len - 1) {
      line_len *= 2;
      line = realloc(line, line_len);
      if(line == NULL) {
        fprintf(stderr, "Error: Out of memory\n");
        quit(1);
      }
    }
    c = fgetc(file);
  }
  line[line_pos] = '\0';

  return(line);
}

int main(int argc, char **argv) {
  char *line = NULL;
  char *out_name;
  int x = 0, y = 0, cols = 0;
  int i;
  unsigned char palette[256];
  char c;
  unsigned char *raw = NULL;
  unsigned char unit[8*8];
  int row = 0;
  int bx, by, bw, bh, width, height;
  unsigned char byte;
  int arg = 1;
  signed char block = FALSE;

  /* Check arguments. */
  if(argc != 2 && argc != 3) usage(argv[0]);

  if(strcmp(argv[arg], "--block") == 0) {
    arg++;
    block = TRUE;
  }

  /* Open the input file. */
  in = fopen(argv[arg], "r");
  if(in == NULL) {
    fprintf(stderr, "Error: Cannot open file '%s' for input\n", argv[1]);
    quit(1);
  }

  /* Form output filename and open file. */
  out_name = calloc(strlen(argv[1]) + strlen(OUT_EXT) + 1, sizeof(char));
  strcpy(out_name, argv[1]);
  strcpy(out_name + strlen(argv[1]), OUT_EXT);
  out = fopen(out_name, "wb");
  if(out == NULL) {
    fprintf(stderr, "Error: Cannot open file '%s' for output\n", out_name);
    quit(1);
  }

  /* Check the input file looks like an XPM. */
  line = getLine(in);
  if(strstr(line, "XPM") == NULL) {
    fprintf(stderr, "Error: '%s' doesn't appear to be an XPM file\n", argv[1]);
    quit(1);
  }
  free(line);

  /* Consume useless 'static char *' line. */
  line = getLine(in);
  free(line);

  /* Get image and palette sizes. */
  line = getLine(in);
  sscanf(line, "\"%i %i %i", &width, &height, &cols);
  free(line);
  printf("Image is %i by %i pixels, %i colours.\n", width, height, cols);

  if(cols > 256) {
    fprintf(stderr, "Error: Cannot process images with > 256 colours\n");
    quit(1);
  }

  /* Grab palette. */
  for(i = 0; i < 256; i ++) palette[i] = -1;
  for(i = 0; i < cols; i ++) {
    line = getLine(in);
    sscanf(line, "\"%c c ", &c);
    printf("Palette char %i is '%c'\n", i, c);
    palette[(int)c] = i;
    free(line);
  }

  /* Initialise raw image holder. */
  raw = calloc(width * height, sizeof(unsigned char));
  while(!feof(in)) {
    line = getLine(in);
    //printf("'%s'\n", line);
    if(strlen(line) > width) {
      for(i = 0; i < width; i ++) {
	//printf("'%c'\n", line[i]);
	raw[row * width + i] = palette[(int)line[i + 1]];
      }
    }
    row += 1;
    free(line);
  }
  
  fclose(in);

  if(block) {
  /* Scan image by 8x8 blocks. */
  bw = width / 8;
  bh = height / 8;
  for(by = 0; by < bh; by ++) {
    for(bx = 0; bx < bw; bx ++) {
      printf("block %i, %i\n", bx, by);
      for(y = 0; y < 8; y ++) {
	for(x = 0; x < 8; x ++) {
	  unit[y * 8 + x] = raw[(by  * 8 + y) * width + bx * 8 + x];
	}
      }
      /* Dump block. */
      for(y = 0; y < 8; y ++) {
	for(x = 0; x < 8; x ++) {
	  byte = unit[y * 8 + x];
	  fputc(byte, out);
	}
      }
    }
  }
  } else {
    for(i = 0; i < width * height; i ++) {
      byte = raw[i];
      fputc(byte, out);
    }
  }

  quit(0);

  for(row = 0; row < y; row ++) {
    for(i = 0; i < x; i ++) {
      printf("%c", raw[row * x + i]);
    }
    printf("\n");
  }
  // Scan raw in 8x8 blocks, generating nibble-merged data into bytes to write.

  fclose(out);

  return(0);
}
