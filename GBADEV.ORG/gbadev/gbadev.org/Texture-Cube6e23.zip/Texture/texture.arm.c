/* (c) Peter Horsman, 2003
 * Pete ( dooby@bits.bris.ac.uk / http://bits.bris.ac.uk/dooby/ )
 * vi:set ts=2 sts=2 expandtab:
 */

#include "gba.h"
#include "regs.h"
#include "interrupt.h"
#include "symbols.h"
#include "mbv2lib.h"
#include "stdlib.h"
#include "3d.h"

// Set to 0 or 1 as you wish. See debug.h to tailor for multiboot, VBA, etc.
#define DEBUGGING 1
#include "debug.h"

// Set for delay loops to activate.
#define wait() { int vsync; if(slow) for(vsync = 0; vsync < 1; vsync ++) gba_vsync(); }
//#define wait()

s32 new_gba_div(s32 a, s32 b);
signed long int slow_gba_div(signed long int numerator, signed long int denominator) CODE_IN_IWRAM;
// Comment this out to use the (less accurate) LUT div version.
// Use EWRAM/ROM version:
//#define new_gba_div(a, b) gba_div(a, b);
// Use IWRAM version:
//#define new_gba_div(a, b) slow_gba_div(a, b);

// Useful offsets and constants.
#define X_OFF (240 / 2)
#define Y_OFF (160 / 2)
#define FIXED 16
#define ROUND ((s32)(0.5 * (float)(1<<FIXED)))
#define INFINITY 0x7fffffff
#define TEXTURE_SIZE  64
#define SCALE 1.3

unsigned char tex1[TEXTURE_SIZE * TEXTURE_SIZE] IN_IWRAM;
unsigned char tex2[TEXTURE_SIZE * TEXTURE_SIZE] IN_IWRAM;

unsigned char* tex[] = { (u8 *)_binary_gfx_texture_spr_raw_start,
  tex1,
  tex2,
  (u8 *)_binary_gfx_texture_spr_raw_start,
  tex1,
  tex2 };
u8 *texture_global = NULL;

signed int slow = FALSE;
signed int usage = FALSE;

__inline void swap(u32 *a, u32 *b) {
  *a ^= *b;
  *b ^= *a;
  *a ^= *b;
}

// starfield
#define STARS  30
#define URAND_MAX  0xffffffff
int star_ang[STARS];
int star_dist[STARS];
int star_col[STARS];
void starfield(u8 *base) {
  static int first = 1;
  int i, x, y;

  if(first) {
    first = 0; // Not first time round any more...
    // Set palette.
    for(i = 0; i < 16; i ++) {
      gba_setpalette(16 + i, i * 2, i * 2, i * 2);
    }
    // Init stars.
    for(i = 0; i < STARS; i ++) {
      star_ang[i] = (int) (360.0*gba_rand()/(URAND_MAX+1.0));
      star_dist[i] = (int) ((float)(TEXTURE_SIZE>>1)*gba_rand()/(URAND_MAX+1.0));
      star_dist[i] <<= 8; // Go FIXED point.
      star_col[i] = (int) (16.0*gba_rand()/(URAND_MAX+1.0));
    }
  }
  // Clear texture.
  for(i = 0; i < (TEXTURE_SIZE * TEXTURE_SIZE)-1; i ++) {
    base[i] = 16;
  }
  // Border.
  for(i = 0; i < TEXTURE_SIZE-1; i ++) {
    base[i*TEXTURE_SIZE] = 31;
    base[i*TEXTURE_SIZE+TEXTURE_SIZE-1] = 31;
    base[i] = 31;
    base[TEXTURE_SIZE * (TEXTURE_SIZE-1) + i] = 31;
  }

  // Every time:
  for(i = 0; i < STARS; i ++) {
    x = gba_cos(star_ang[i]) * (star_dist[i] >> 8);
    y = gba_sin(star_ang[i]) * (star_dist[i] >> 8);
    //DEBUG("x, y: %i, %i (FIXED)\n", x, y);
    //x = (x >> 7) + (TEXTURE_SIZE>>1);
    //y = (y >> 7) + (TEXTURE_SIZE>>1);
    x = (x >> 7) + (TEXTURE_SIZE>>1);
    y = (y >> 7) + (TEXTURE_SIZE>>1);
    //DEBUG("x, y: %i, %i (real)\n\n", x, y);
    base[x + TEXTURE_SIZE * y] = star_col[i] + 16;
    //star_dist[i] += star_col[i] >> 2;
    star_dist[i] += star_col[i] * 4;
    if(star_dist[i] >= (TEXTURE_SIZE>>1)<<8) star_dist[i] -= (TEXTURE_SIZE>>1)<<8;
    //if(star_dist[i] >= (TEXTURE_SIZE>>1)) star_dist[i] -= (TEXTURE_SIZE>>1);
  }
}

// Radar
#define RADAR_RADIUS  (int)((float)(TEXTURE_SIZE>>1) * 0.75)
void radar(u8 *base) {
  static int first = 1;
  int i, x, y, cos, sin, ang, col;
  static int col_offset = 0;

  if(first) {
    first = 0; // Not first time round any more...
    // Set palette.
    for(i = 0; i < 16; i ++) {
      gba_setpalette(32 + i, 0, i * 2, i * 2);
    }
    // Clear texture.
    for(i = 0; i < (TEXTURE_SIZE * TEXTURE_SIZE)-1; i ++) {
      base[i] = 32;
    }
    // Border.
    for(i = 0; i < TEXTURE_SIZE-1; i ++) {
      base[i*TEXTURE_SIZE] = 47;
      base[i*TEXTURE_SIZE+TEXTURE_SIZE-1] = 47;
      base[i] = 47;
      base[TEXTURE_SIZE * (TEXTURE_SIZE-1) + i] = 47;
    }
    // Draw lines.
    col = 0;
    for(ang = 0; ang < 360; ang += 9) {
      cos = gba_cos(ang);
      sin = gba_sin(ang);
      for(i = 0; i < RADAR_RADIUS; i ++) {
        x = ((cos * i) >> 7) + (TEXTURE_SIZE>>1);
        y = ((sin * i) >> 7) + (TEXTURE_SIZE>>1);
        base[x + TEXTURE_SIZE * y] = col + 32;
      }
      col ++;
      if(col > 14) col = 1;
    }
  }
  
  // Every time:
  for(i = 1; i < 15; i ++) {
    gba_setpalette(33 + (i+col_offset)%14, 0, i * 2, i * 2);
  }
  col_offset += 1;
  //if(col_offset > 15) col_offset = 0;
}

// Used to 'grow' square coords in their correct direction.
s32 sign(s32 i) {
  if(i < 0) return -1;
  if(i > 0) return 1;
  return 0;
}

// New attempt at faster texline func.
__inline void texline(u32 x1, u32 x2, u32 y, u32 u, u32 v, s32 du, s32 dv) {
  u8 *addr = (u8 *)((u32 *)&gba_bank)[((u32 *)(&gba_bank))[0]];
  u16 writeme;
  int len;
  //u8 *texture = (u8 *)_binary_gfx_texture_spr_raw_start;
  u8 *texture = texture_global;

  addr = (u8 *)((u32)addr + x1 + y * 240); // Calc first screen pixel.

  len = x2 - x1 + 1;
  if(((u32)addr & 1) != 0) {
    // Patch up leading pixel.
    u8 colour = texture[(v >> FIXED) * TEXTURE_SIZE + (u >> FIXED)];
    writeme = *(u16 *)((u32)addr & ~1);
    writeme &= 0xff;
    writeme |= colour << 8;
    *(u16 *)((u32)addr & ~1) = writeme;
    len --;
    v += dv;
    u += du;
    addr += 1;
  }
  // While we've got multiples of 2 pixels left, concatenate and blit.
  // NB Could produce an interesting effect here by reversing halfword order?
  while(len >= 2) {
    writeme = texture[(v >> FIXED) * TEXTURE_SIZE + (u >> FIXED)];
    v += dv;
    u += du;
    writeme |= (texture[(v >> FIXED) * TEXTURE_SIZE + (u >> FIXED)]) << 8;
    v += dv;
    u += du;
    *(u16 *)addr = writeme;
    addr += 2;
    len -= 2;
    wait();
  }
  if(len != 0) {
    // Patch up trailing pixel.
    u8 colour = texture[(v >> FIXED) * TEXTURE_SIZE + (u >> FIXED)];
    writeme = *(u16 *)addr;
    writeme &= 0xff00;
    writeme |= colour;
    *(u16 *)addr = writeme;
  }
}

void texture(s32 x1, s32 y1, s32 u1, s32 v1, s32 x2, s32 y2, s32 u2, s32 v2, s32 x3, s32 y3, s32 u3, s32 v3) {
  s32 grad1, grad2, grad3, xl, xr, xm;
  u32 y;
  // Texture stuff.
  s32 ul, ur, vl, vr, ugrad1, vgrad1, ugrad2, vgrad2, ugrad3, vgrad3, du, dv;
  s32 sorted = FALSE;

  //DEBUG("WOOOOOOOOOOOOOOOOOOOOOOOOOOOOOO\n");
  //DEBUG("Entered texture()\n");

  //DEBUG("Got (x, y):\n  %i, %i\n%i, %i\n%i, %i\n", x1, y1, x2, y2, x3, y3);
  //DEBUG("Got (u, v):\n  %i, %i\n%i, %i\n%i, %i\n", u1, v1, u2, v2, u3, v3);

  // Sort into y-ascending (going down screen).
  if(y3 < y2) { swap(&x3, &x2); swap(&y3, &y2); swap(&u3, &u2); swap(&v3, &v2); }
  if(y2 < y1) { swap(&x2, &x1); swap(&y2, &y1); swap(&u2, &u1); swap(&v2, &v1); }
  if(y3 < y2) { swap(&x3, &x2); swap(&y3, &y2); swap(&u3, &u2); swap(&v3, &v2); }

  //DEBUG("Sorted (x, y):\n  %i, %i\n%i, %i\n%i, %i\n", x1, y1, x2, y2, x3, y3);
  //DEBUG("Sorted (u, v):\n  %i, %i\n%i, %i\n%i, %i\n", u1, v1, u2, v2, u3, v3);

  /*
   *     __ (x1, y1)
   *   |\ 
   *   | \ 2
   * 1 |  \ __ (x2, y2)
   *   |  /
   *   | / 3
   *   |/ __ (x3, y3)
   *
   */

  // Calculate dx/dy for each line.
  if(y3 != y1) grad1 = new_gba_div((x3 - x1) << FIXED, y3 - y1);
  if(y2 != y1) grad2 = new_gba_div((x2 - x1) << FIXED, y2 - y1);
  if(y3 != y2) grad3 = new_gba_div((x3 - x2) << FIXED, y3 - y2);

  //DEBUG("grad1: %i\n", grad1);
  //DEBUG("grad2: %i\n", grad2);
  //DEBUG("grad3: %i\n", grad3);

  // Start texture left and right positions.
  ul = (u1 << FIXED);// + ROUND;
  ur = ul;
  vl = (v1 << FIXED);// + ROUND;
  vr = vl;
  // Calculate the gradients they will follow.
  ugrad1 = new_gba_div((u3 - u1) << FIXED, y3 - y1);
  vgrad1 = new_gba_div((v3 - v1) << FIXED, y3 - y1);
  ugrad2 = new_gba_div((u2 - u1) << FIXED, y2 - y1);
  vgrad2 = new_gba_div((v2 - v1) << FIXED, y2 - y1);
  ugrad3 = new_gba_div((u3 - u2) << FIXED, y3 - y2);
  vgrad3 = new_gba_div((v3 - v2) << FIXED, y3 - y2);
  //DEBUG("ugrad1: %i\tvgrad1: %i\n", ugrad1, vgrad1);
  //DEBUG("ugrad2: %i\tvgrad2: %i\n", ugrad2, vgrad2);
  //DEBUG("ugrad3: %i\tvgrad3: %i\n", ugrad3, vgrad3);

  // Set start left and right x positions (both start at x1).
  xl = (x1 << FIXED) + ROUND;
  xr = xl;
  //DEBUG("xl, xr: %i, %i\n", xl >> FIXED, xr >> FIXED);

  // Calculate the x position mid way along longest line (1).
  xm = (x1<<FIXED) + (y2 - y1)*grad1;
  //DEBUG("xm = %i\n", xm);

  // And here's the ONE place we calc these for the whole triangle.
  if((x2 << FIXED) < xm) {
    // swapped coords - account for this (left triangle).
  du = new_gba_div((u1<<FIXED)+ugrad1*(y2-y1) - (u2<<FIXED), abs( (((x1<<FIXED)+grad1*(y2-y1)) >> FIXED) - x2 ) );
  dv = new_gba_div((v1<<FIXED)+vgrad1*(y2-y1) - (v2<<FIXED), abs( (((x1<<FIXED)+grad1*(y2-y1)) >> FIXED) - x2 ) );
  } else {
    // normal coords (right triangle).
  du = new_gba_div((u2<<FIXED) - ((u1<<FIXED)+ugrad1*(y2-y1)), x2 - (((x1<<FIXED)+grad1*(y2-y1)) >> FIXED) );
  dv = new_gba_div((v2<<FIXED) - ((v1<<FIXED)+vgrad1*(y2-y1)), x2 - (((x1<<FIXED)+grad1*(y2-y1)) >> FIXED) );
  }
  //DEBUG("Calculated du, dv as (%i, %i)\n", du, dv);

  // Here we have a problem. If we're tracing xl and it's to the right of xr,
  // correct.
  if((x2 << FIXED) < xm) {
    swap(&grad1, &grad2);
    swap(&ugrad1, &ugrad2);
    swap(&vgrad1, &vgrad2);
    //DEBUG("  sorted for top triangle\n");
    sorted = TRUE;
  }

  //DEBUG("xl, xr: %i, %i\n", xl >> FIXED, xr >> FIXED);

  // If a top triangle exists, start it.
  if(y1 != y2) {
    for(y = y1; y < y2; y ++) {
      //DEBUG("y: %i (top), l: (%i, %i)\tr=(%i, %i)\n", y, ul >> FIXED, vl >> FIXED, ur >> FIXED, vr >> FIXED);
      //DEBUG("                du, dv: (%i, %i)\n", du, dv);
      texline(xl >> FIXED, xr >> FIXED, y, ul, vl, du, dv);
      xl += grad1;
      xr += grad2;
      ul += ugrad1;
      ur += ugrad2;
      vl += vgrad1;
      vr += vgrad2;
    }
  } else //DEBUG("y1 == y2 - didn't draw\n");

  // We may not have drawn an actual top triangle, in which case fudge left and
  // right positions for bottom triangle.
  if(y1 == y2) {
    //DEBUG("y1 == y2 - fudging ready for bottom triangle\n");
    // No top triangle, so 
    if(!sorted) {
      xl = (x1 << FIXED) + ROUND;
      ul = (u1 << FIXED);// + ROUND;
      vl = (v1 << FIXED);// + ROUND;
      xr = (x2 << FIXED) + ROUND;
      ur = (u2 << FIXED);// + ROUND;
      vr = (v2 << FIXED);// + ROUND;
    } else {
      // Need other way round.
      xl = (x2 << FIXED) + ROUND;
      ul = (u2 << FIXED);// + ROUND;
      vl = (v2 << FIXED);// + ROUND;
      xr = (x1 << FIXED) + ROUND;
      ur = (u1 << FIXED);// + ROUND;
      vr = (v1 << FIXED);// + ROUND;
    }
  }

  // We just drew the top triangle (if any). Swap back if we fudged left/right.
  if(sorted) {
    swap(&grad1, &grad2);
    swap(&ugrad1, &ugrad2);
    swap(&vgrad1, &vgrad2);
    //DEBUG("  UN-sorted after top triangle\n");
  }

  // In theory, the swaps we did for the top triangle switched left/right should
  // be very similar for the bottom.
  // Should be (x2 < x3) ?
  if((x2 << FIXED) < xm) {
    swap(&grad1, &grad3);
    swap(&ugrad1, &ugrad3);
    swap(&vgrad1, &vgrad3);
    //DEBUG("  RE-sorted for bottom triangle\n");
  }

  //DEBUG("(xl, xr): %i, %i\n", xl >> FIXED, xr >> FIXED);
  //DEBUG("(ul, vl): %i, %i\n", ul >> FIXED, vl >> FIXED);
  //DEBUG("(ur, vr): %i, %i\n", ur >> FIXED, vr >> FIXED);
  if(y2 != y3) {
    /* Triangle is NOT like this:
     *  /|
     * /_| as it has a bottom half.
     *
     */
    //DEBUG("ugrad1: %i\tvgrad1: %i\n", ugrad1, vgrad1);
    //DEBUG("ugrad2: %i\tvgrad2: %i\n", ugrad2, vgrad2);
    //DEBUG("ugrad3: %i\tvgrad3: %i\n", ugrad3, vgrad3);
    for(y = y2; y <= y3; y ++) {
      //DEBUG("y: %i (bottom), l: (%i, %i)\tr=(%i, %i)\n", y, ul >> FIXED, vl >> FIXED, ur >> FIXED, vr >> FIXED);
      //DEBUG("                du, dv: (%i, %i)\n", du, dv);
      texline(xl >> FIXED, xr >> FIXED, y, ul, vl, du, dv);
      ul += ugrad1;
      vl += vgrad1;
      ur += ugrad3;
      vr += vgrad3;
      xl += grad1;
      xr += grad3;
    }
  } else {
    /* Triangle is like this:
     *  /|
     * /_| as it has no bottom half.
     *     Still need to draw one line as we've not drawn y2 yet.
     */
    y = y2;
    //DEBUG("y: %i (single)\n", y);
      texline(xl >> FIXED, xr >> FIXED, y, ul, vl, du, dv);
  }
}

/*void text_face(Face *f) {
  s32 x1, y1, x2, y2, x3, y3;

  //DEBUG("I AM NEVER CALLED\n");

  // Initialise coords from 1st triangle of face.
  x1 = f->v[0].x + X_OFF; y1 = f->v[0].y + Y_OFF;
  x2 = f->v[1].x + X_OFF; y2 = f->v[1].y + Y_OFF;
  x3 = f->v[2].x + X_OFF; y3 = f->v[2].y + Y_OFF;

  texture(x1, y1, 0, 0, x2, y2, 0, TEXTURE_SIZE, x3, y3, TEXTURE_SIZE, TEXTURE_SIZE);

  x2 = f->v[3].x + X_OFF; y2 = f->v[3].y + Y_OFF;
  texture(x1, y1, 0, 0, x2, y2, TEXTURE_SIZE, 0, x3, y3, TEXTURE_SIZE, TEXTURE_SIZE);
}*/

//void init_square(Face *square) {
void init_square(Object *o, Face f[]) {
  int i, j;

  // Initialise square front.
  f[0].v[0].x =  -25; f[0].v[0].y =   25; f[0].v[0].z =   25;
  f[0].v[1].x =  -25; f[0].v[1].y =  -25; f[0].v[1].z =   25;
  f[0].v[2].x =   25; f[0].v[2].y =  -25; f[0].v[2].z =   25;
  f[0].v[3].x =   25; f[0].v[3].y =   25; f[0].v[3].z =   25;
  f[0].col = (u32)_binary_gfx_texture_spr_raw_start;
  
  // Initialise square top.
  f[1].v[0].x =  -25; f[1].v[0].y =   25; f[1].v[0].z =  -25;
  f[1].v[1].x =  -25; f[1].v[1].y =   25; f[1].v[1].z =   25;
  f[1].v[2].x =   25; f[1].v[2].y =   25; f[1].v[2].z =   25;
  f[1].v[3].x =   25; f[1].v[3].y =   25; f[1].v[3].z =  -25;
  f[1].col = (u32)tex2;
  
  // Initialise square back.
  f[2].v[0].x =   25; f[2].v[0].y =   25; f[2].v[0].z =  -25;
  f[2].v[1].x =   25; f[2].v[1].y =  -25; f[2].v[1].z =  -25;
  f[2].v[2].x =  -25; f[2].v[2].y =  -25; f[2].v[2].z =  -25;
  f[2].v[3].x =  -25; f[2].v[3].y =   25; f[2].v[3].z =  -25;
  f[2].col = (u32)_binary_gfx_texture_spr_raw_start;
  
  // Initialise square left.
  f[3].v[0].x =  -25; f[3].v[0].y =   25; f[3].v[0].z =  -25;
  f[3].v[1].x =  -25; f[3].v[1].y =  -25; f[3].v[1].z =  -25;
  f[3].v[2].x =  -25; f[3].v[2].y =  -25; f[3].v[2].z =   25;
  f[3].v[3].x =  -25; f[3].v[3].y =   25; f[3].v[3].z =   25;
  f[3].col = (u32)tex1;
  
  // Initialise square right.
  f[4].v[0].x =   25; f[4].v[0].y =   25; f[4].v[0].z =   25;
  f[4].v[1].x =   25; f[4].v[1].y =  -25; f[4].v[1].z =   25;
  f[4].v[2].x =   25; f[4].v[2].y =  -25; f[4].v[2].z =  -25;
  f[4].v[3].x =   25; f[4].v[3].y =   25; f[4].v[3].z =  -25;
  f[4].col = (u32)tex1;
  
  // Initialise square bottom.
  f[5].v[0].x =   25; f[5].v[0].y =  -25; f[5].v[0].z =  -25;
  f[5].v[1].x =   25; f[5].v[1].y =  -25; f[5].v[1].z =   25;
  f[5].v[2].x =  -25; f[5].v[2].y =  -25; f[5].v[2].z =   25;
  f[5].v[3].x =  -25; f[5].v[3].y =  -25; f[5].v[3].z =  -25;
  f[5].col = (u32)tex2;
  
  // Temporary fix-up.
  //for(i = 0; i < 4; i ++) f[0].v[i].y *= -1;

  // Alter size.
  for(j = 0; j < 6; j ++) {
    for(i = 0; i < 4; i ++) {
      f[j].v[i].x = (int)(f[j].v[i].x * SCALE);
      f[j].v[i].y = (int)(f[j].v[i].y * SCALE);
      f[j].v[i].z = (int)(f[j].v[i].z * SCALE);
    }
  }

  o->face = &f[0];
  // FIXME f[0].n = NULL;
  f[0].n = &f[1];
  f[1].n = &f[2];
  f[2].n = &f[3];
  f[3].n = &f[4];
  f[4].n = &f[5];
  f[5].n = NULL;

  o->angX =    0;
  o->angY =    0;
  o->angZ =    0;
  o->incX =    0;
  o->incY =    0;
  o->incZ =    1;
  o->offX = 0;//45;
  o->offY = 0;
  o->offZ = 0;
}

int go(void) {
  int i;//, x, y;
  Object *world, bob;
  Face square[6];
  s32 ang_x = 0, ang_y = 0, ang_z = 0;
  u16 keys;

  init_square(&bob, square);
  world = &bob;
  world->n = NULL;

  // Set GBA mode 4 with sprites enabled.
  DISPCNT = 0x0404;	// NB don't enable window flag unless it's set up :)

  // Initialise interrupts to allow A+B+Start+Select to hard reset.
  interrupt_init();
  KEYCNT = KEY_AND | KEY_IRQ | PAD_A | PAD_B | PAD_START | PAD_SELECT;
  IE |= INT_KEY;
  IME = 1;

  gba_setpalette(0, 31, 0, 0);

  // Load palette of texture.
  for(i = 0; i < (u32)(&_binary_gfx_texture_pal_raw_size) / 2; i ++) {
    ((u16 *)0x05000000)[i] = ((u16 *)_binary_gfx_texture_pal_raw_start)[i];
  }

  gba_clsUnroll2(0);

#if 0
  // Test printing text in first N colours.
  for(i = 0; i < 160/8-1; i ++) {
    gba_setcolour(i);
    gba_print(0, i, "Hello");
  }
#endif

#if 0
  // Test dumping the texture to VRAM.
  i = 0;
  for(y = 0; y < TEXTURE_SIZE; y ++) {
    for(x = 0; x < TEXTURE_SIZE/2; x ++) {
      *(u16 *)(0x06000000 + y * 240 + x * 2) = ((u16*)_binary_gfx_texture_spr_raw_start)[i++];
    }
  }
#endif

  gba_initbank();

  // Test rotating a square around.

  // Clear, set up and start timers.
  TM3CNT_L = 0;
#define TMCNT_ENABLE  0x80
#define TMCNT_COUNT_UP  0x4
#define TMCNT_PRESCALE_1024  0x3
  TM3CNT_H = TMCNT_ENABLE | TMCNT_COUNT_UP;
  TM2CNT_H = TMCNT_ENABLE | TMCNT_PRESCALE_1024;
    // Draw 3D stuff.
    //while(ang_x < 360) {
    while(TRUE) {
      Object *curr_obj;
      Face *curr, temp;
      s32 sin[3], cos[3];
      // Fill textures:
      //starfield();#
      starfield(tex1);
      radar(tex2);

      // 3D Rendering stuff.
      curr_obj = world;
      while(curr_obj != NULL) {
        // Get rotation angles.
        sin[0] = gba_sin(ang_x); cos[0] = gba_cos(ang_x);
        sin[1] = gba_sin(ang_y); cos[1] = gba_cos(ang_y);
        sin[2] = gba_sin(ang_z); cos[2] = gba_cos(ang_z);
        curr = curr_obj->face;
        //first = TRUE;
        while(curr != 0) {
          // Rotate face into temp.
          copy(&temp, curr);
          rotX(&temp, sin[0], cos[0]);
          rotY(&temp, sin[1], cos[1]);
          rotZ(&temp, sin[2], cos[2]);
          trs(&temp, curr_obj->offX, curr_obj->offY, curr_obj->offZ);
          psp(&temp);

          
          if((temp.v[1].x - temp.v[0].x) * (temp.v[2].y - temp.v[1].y) -
              (temp.v[1].y - temp.v[0].y) * (temp.v[2].x - temp.v[1].x) > 0) {
            s32 x1, y1, x2, y2, x3, y3;

            // Initialise coords from 1st triangle of face.
            x1 = temp.v[0].x + X_OFF; y1 = -temp.v[0].y + Y_OFF;
            x2 = temp.v[1].x + X_OFF; y2 = -temp.v[1].y + Y_OFF;
            x3 = temp.v[2].x + X_OFF; y3 = -temp.v[2].y + Y_OFF;

            texture_global = (u8 *)curr->col;
          
            texture(x1, y1, 0, 0, x2, y2, 0, TEXTURE_SIZE, x3, y3, TEXTURE_SIZE, TEXTURE_SIZE);
          
            x2 = temp.v[3].x + X_OFF; y2 = -temp.v[3].y + Y_OFF;
            texture(x1, y1, 0, 0, x2, y2, TEXTURE_SIZE, 0, x3, y3, TEXTURE_SIZE, TEXTURE_SIZE);
          }
          /*gba_setcolour(temp.col);
          gba_triangle(temp.v[0].x+XOFF, -temp.v[0].y+YOFF,
                       temp.v[1].x+XOFF, -temp.v[1].y+YOFF,
                       temp.v[2].x+XOFF, -temp.v[2].y+YOFF);
          if((temp.v[2].x != temp.v[3].x) || (temp.v[2].y != temp.v[3].y)) {
            gba_triangle(temp.v[0].x+XOFF, -temp.v[0].y+YOFF,
                         temp.v[2].x+XOFF, -temp.v[2].y+YOFF,
                         temp.v[3].x+XOFF, -temp.v[3].y+YOFF);
          }*/
          // Get next face.
          curr = curr->n;
        }
        curr_obj = curr_obj->n;
      }

      //DEBUG("%i, %i, %i (ang_x, ang_y, ang_z)\n", ang_x, ang_y, ang_z);

      keys = KEYINPUT;

      if(!(keys & PAD_L)) ang_z --;
      if(!(keys & PAD_R)) ang_z ++;
      if(!(keys & PAD_LEFT)) ang_x --;
      if(!(keys & PAD_RIGHT)) ang_x ++;
      if(!(keys & PAD_DOWN)) ang_y --;
      if(!(keys & PAD_UP)) ang_y ++;

      //if(!(keys & PAD_START)) while(KEYINPUT & PAD_START);

      //if(!(keys & PAD_SELECT)) slow = TRUE;
      //else slow = FALSE;

      if(!(keys & PAD_A)) usage = TRUE;
      else {
        usage = FALSE;
        gba_setpalette(0, 0, 0, 0);
      }

      ang_z ++;
      ang_x += 2;
      ang_y --;
      if(usage) gba_setpalette(0, 0, 0, 0);
      gba_vsync();
      //while(VCOUNT != 0);
      gba_swapbank();
      if(usage) gba_setpalette(0, 0, 15, 0);
      gba_clsUnroll2(0);
    }
    TM2CNT_H = 0;
    TM3CNT_H = 0;
    //DEBUG("TM2 = %i\n", TM2CNT_L);
    //DEBUG("TM3 = %i\n", TM3CNT_L);
    DEBUG("Time: %.2f\n", (TM3CNT_L * (1 << 16) + TM2CNT_L) * 61.025E-6);

  while(TRUE);

  if(FALSE) {
    square->v[0].x = -75;
    square->v[0].y = -75;
    square->v[2].x = 75;
    square->v[2].y = 75;
    // FIXME No function called this anymore.
    // text_face(&square[0]);
  } else {
    int i, j;
    while(TRUE) {
    for(i = 0; i < 49; i ++) {
      gba_clsUnroll2(-1);
      // FIXME No function called this anymore.
      // text_face(&square[0]);
      for(j = 0; j < 4; j ++) {
        square->v[j].x -= sign(square->v[j].x);
        square->v[j].y -= sign(square->v[j].y);
        square->v[j].z -= sign(square->v[j].z);
      }
      gba_vsync();
    }
    for(i = 0; i < 79; i ++) {
      gba_clsUnroll2(-1);
      // FIXME No function called this anymore.
      // text_face(&square[0]);
      for(j = 0; j < 4; j ++) {
        square->v[j].x += sign(square->v[j].x);
        square->v[j].y += sign(square->v[j].y);
        square->v[j].z += sign(square->v[j].z);
      }
      gba_vsync();
    }
    for(i = 0; i < 29; i ++) {
      gba_clsUnroll2(-1);
      // FIXME No function called this anymore.
      // text_face(&square[0]);
      for(j = 0; j < 4; j ++) {
        square->v[j].x -= sign(square->v[j].x);
        square->v[j].y -= sign(square->v[j].y);
        square->v[j].z -= sign(square->v[j].z);
      }
      gba_vsync();
    }
    }
  }

  while(0==0);

  return(0);
}
