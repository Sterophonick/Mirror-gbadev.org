/* (c) Peter Horsman, 2002
 * Pete (dooby@bits.bris.ac.uk / http://bits.bris.ac.uk/dooby/)
 */

#include "gba.h"
#include "regs.h"
#include "interrupt.h"

MULTIBOOT

void go(void);

int AgbMain(void) {
  go();

  return(0);
}
