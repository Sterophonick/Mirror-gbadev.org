Texture mapper
~~~~~~~~~~~~~~

This is just an update of some stuff I'm working on. Most of the source is in
C and hasn't been optimised yet, so maybe you can spot the bugs easier ;-)

L, R and D-pad modify angular rotation speeds. A shows usage - if the green
touches the bottom it means I've dropped below 60FPS which I don't *think* it
does ATM.

You can modify it to switch between 64x64 pixel textures or 32x32 pixel
textures by changing the TEXTURE_SIZE #define and the gfx link to whichever
you want. It makes no difference to the speed but the 64x64 looks higher
resolution if a little 'grainy'.

You can also see the effect of a division Look Up Table (LUT) versus
calculated (either in EWRAM or IWRAM) by modifying the new_gba_div #defines.

Finally, the size of the cube can be easily altered using the SCALE #define.

Hopefully someone brave will implement a flame effect or plasma generated
texture and send me the results ;-)

Feel free to have a play, and mail me those bugs you find!

Pete ( dooby@bits.bris.ac.uk / http://bits.bris.ac.uk/dooby/ )
