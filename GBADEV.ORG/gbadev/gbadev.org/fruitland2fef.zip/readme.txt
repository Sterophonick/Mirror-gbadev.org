
Fruit Land v1.10	(c) 2001 Arjan Bakker
------------------------------------------------

Introduction
---------------
Fruit Land is my first program for the GBA, or AGB, whatever you want. It's a simple puzzle game I
ported over from the PC-version I did one year ago (which was a port of the MSX-version I did in 1998
or so). Actually it's more a rewrite than a port, but that doesn't matter. Anyways, I did this game in
only 4 days, in which I also had to write some tools and discover that some documents aren't always
correct...

New in version 1.10
----------------------
Not much new really. Most important: it works on hardware! Also, I increased the time-limit, made the
menu's/dialog boxes better and crunched the gfx (game now is <32kb!).

What do you need to run it?
------------------------------
The game runs on hardware and on almost all emulators I tested, only DreamGBA doesn't runs the game
correctly.

What do you need to compile it?
----------------------------------
The makefile was made for gcc+gfxlib, so if you're using that, change the makefile to make sure all
directories are correct. If you aren't using this, include your own startup-code and it'll work.

How do you play this game?
-----------------------------
The game's goal is completing all levels by eating all cherries in all levels. To achieve this you
probably need to use some items scattered in all levels, like screen-turners, enemy-stoppers, time-
stoppers, rocks, blocks and teleporters. There are also diamonds and little dots, but they only give
you extra points. The teleporters are a bit tricky, so I'll tell you how they work. If you enter a
teleporter, the game scans the level from the top-left corner to top down-right corner (first from
the left to the right and then one line down) to find another teleporter. To make things a bit harder
you need to do this within the timelimit. After completing a level, you'll get some bonuspoints. After
every 5th level, you'll get a password so you don't have to start from the beginning next time you
play the game.

How to control?
------------------
In the intro-screen, use up and down to move to another option and press button A to select.
In the password-screen, use left and right to move left and right, up and down to change a letter and
button A to confirm.
In the game, use the directional buttons to move around, button B to pause the game and select to kill
yourself.

Other things
---------------
If you find bugs or want to criticize my code or whatever, just mail me. And of course you can also
mail me to tell me you like (or don't like) the game :) My mail-address is: abeker@hetnet.nl

Disclaimer
-------------
No-one has been hurt during the process of making this game. The author cannot be held responsible for
any damage caused by having, distributing or playing this game. In other words: use it on your own risk!

