
//includes
#include "main.h"

//include all gfx (very inefficient :) )
#include "sprites.h"
#include "tiles.h"
#include "intro.h"

//include the level-data
#include "levels.inc"

#define _VRAM (u8 *)TILES_BG0
#define OAM		((Sprite*)0x07000000)
#define BG_PALET  0x5000000
#define SPR_PALET 0x5000200
#define TILES_BG0  0x6000000
#define TILES_BG1  0x6000800
#define TILES_BG2  0x6001000
#define TILES_BG3  0x6001800
#define TILEDATA_BG0	0x6004000
#define TILEDATA_BG2	0x6008000
#define SPRITEDATA	0x6010000
#define BG1_X	0x4000014
#define BG1_Y   0x4000016
#define BG0CNT  0x4000008
#define BG1CNT  0x400000A
#define BG2CNT  0x400000C
#define BG3CNT  0x400000E
#define UP		1
#define RIGHT	3
#define DOWN	5
#define LEFT	7

//define a sprite as a structure
typedef struct _Sprite { u16 Attrib0, Attrib1, Attrib2, RotateScale; } Sprite;

//this is our nice sprite-info block
typedef struct OBJECT
{
  u8 dx;    // x-coordinaat in level_data
  u8 dy;    // y-coordinaat in level_data
  u8 x;     // x-coordinaat on screen
  u8 y;     // y-coordinaat on screen
  u8 dir;   // direction
  u8 step;  // number of steps OBJECT has moved
  u8 l;     // l==1 -> valid data in OBJECT
  u8 spr;	// spritenumber to display
  u8 move;	// set to 1 if rock is busy falling (so rocks only :) )	
} OBJECT;

//I'll waste some RAM here :)
u8 *leveldata = (u8 *) 0x2000000;	//temporary leveldata, size 15*11 bytes
//object 0 = player
//object 1-4 = enemy
//object 5-14 = rocks
//object 15 = block
OBJECT *objects = (OBJECT *)0x2000300; //16*8 bytes

u16 time, freeze_enemy;
u8 lives, level, fruitleft, sx, sy, dead;
u32 score;


void WaitForLine(u8 line)
{
  asm
   ("  @Thumb! 
1:
	mov	r1,#0x04
	lsl	r1,r1,#24
	add	r1,r1,#6

    wait:
	ldrh	r2, [r1]	@read linenumber from LCY
	cmp	r2, r0			@compare with line to wait for
	bne	wait			@wait if not equal
2:
    " :
      :
      "r" (line) :			//input registers
      "r0", "r1", "r2" );	// Specify which registers we destroy
}

#define VSYNC WaitForLine(160)	//Shortcut


//Returns the keys being pressed
u16 joypad()
{
u16 k = KEYS^0x3ff;


	return k;
}


//Wait for a key being released
void wait_joypad(u16 mask)
{
	do
	{
		VSYNC;
		WaitForLine(161);
	}
	while( (joypad() & mask) );
}


//decrunches tome tiles
void DecrunchTiles(u8 *source, u32 dest, u16 nt)
{
u32 i;
u8 l,c,ch,mask,flc = 0;
u16 comb;
u16 lc = 0;
u32 tile_ind = 0, tile_adr = 0;
u16 pos = 0;

	tile_adr = 0; tile_ind = 0;
	for (i = 0; i < nt; i++)	//155 tiles
	{
		for (l = 0; l < 8; l++)	//8 lines per tile
		{
			mask = 128;pos = 0x0f0;
			ch = source[tile_ind++];
			if (ch & 128)
			{
				flc = source[tile_ind] & pos;
				flc>>=4;
			}
			lc = flc;
			for (c = 0; c < 2; c++)	//2 packets of 4 pixels
			{
				if (ch & mask)
				{
					lc = source[tile_ind] & pos;
					if (pos>>=4)
						lc>>=4;
					else
					{
						pos = 0x0f0;
						tile_ind++;
					}
				}
				comb=lc;
				mask>>=1;

				if (ch & mask)
				{
					lc = source[tile_ind] & pos;
					if (pos>>=4)
						lc>>=4;
					else
					{
						pos = 0x0f0;
						tile_ind++;
					}
				}
				comb+=(lc<<4);
				mask>>=1;

				if (ch & mask)
				{
					lc = source[tile_ind] & pos;
					if (pos>>=4)
						lc>>=4;
					else
					{
						pos = 0x0f0;
						tile_ind++;
					}
				}
				comb+=(lc<<8);
				mask>>=1;

				if (ch & mask)
				{
					lc = source[tile_ind] & pos;
					if (pos>>=4)
						lc>>=4;
					else
					{
						pos = 0x0f0;
						tile_ind++;
					}
				}
				comb+=(lc<<12);
				mask>>=1;

				*(u16 *)(dest + tile_adr) = comb;
				tile_adr+=2;
			}
			if (pos == 0x00f)
				tile_ind++;
		}
	}
}


//Screen will be correctly setup
void init_program()
{
u32 i;

	*(u16 *)REG_DISPCNT = DISP_LCDC_OFF; // LCDC OFF

	//BG0 - this will be used to display text
	*(u8 *)(BG0CNT) = 4;	//tileaddress TILEDATA_BG0 = 0x6004000
	*(u8 *)(BG0CNT + 1) = 0;	//tiledata starts at 0x6000000, size = 32*32
	//BG1 - this will be used to display the level
	*(u8 *)(BG1CNT) = 4 | 64 | 1 | 2;	//tileaddress TILEDATA_BG0 = 0x6004000, enable MOSAIC
	*(u8 *)(BG1CNT + 1) = 1;	//tiledata starts at 0x6000800, size = 32*32
	//BG2 - this will be used to display the intro-screen minus textmenu
	*(u8 *)(BG2CNT) = 8;		//tileaddress TILEDATA_BG2 = 0x6008000
	*(u8 *)(BG2CNT + 1) = 2;	//tiledata starts at 0x6001000, size = 32*32

	for (i = 0; i < 7; i++)
		*(u32 *)(BG_PALET + i * 4) = *(u32 *)(tiles_palette + i * 4);	//transfer palette
	DecrunchTiles(tiles_tiles,TILEDATA_BG0,160);

	for (i = 0; i < 15; i++)
		*(u16 *)(SPR_PALET + i * 2) = sprites_palette[i];	//transfer palette

	DecrunchTiles(sprites_tiles,SPRITEDATA,204);

	DecrunchTiles(intro_tiles,TILEDATA_BG2,640);

	
	for (i = 0; i < 512; i+=2)
		*(u32 *)(TILES_BG2 + (i/2) * 4) = (i + 1) * 65536 + i;			//initialise intro-screen

	for (i = 0; i < 128; i++)
		OAM[i].Attrib0 = 168;	//make sure all sprites are displayed outside visible range

	// Setup mode 0 graphics
	*(u16 *)REG_DISPCNT = 0 | DISP_BG0_ON | DISP_BG1_ON | DISP_OBJ_ON | 64;
	*(u16 *)REG_STAT = 0;
	MOSAIC = 0;	//reset mosaic
}


//print a string on BG0
void print_string(u8 *string,u16 address)
{ 
u8 c = 0;
  
	while (string[c] != 0)
	{
		if (string[c] == 32)
			*(u16 *)(TILES_BG0 + address + 2 * c) = 107;
		else
			*(u16 *)(TILES_BG0 + address + 2 * c) = string[c] + 48;
		c++;
	}
}


//print a string on BG1
void print_string1(u8 *string,u16 address)
{
u8 c = 0;
  
	while (string[c] != 0)
	{
		if (string[c] == 32)
			*(u16 *)(TILES_BG1 + address + 2 * c) = 107;
		else
			*(u16 *)(TILES_BG1 + address + 2 * c) = string[c] + 48;
		c++;
	}
}


//print a string on BG2
void print_string2(u8 *string,u16 address, u8 inv)
{
u8 c = 0;
  
	inv*=64;

	while (string[c] != 0)
	{
		if (string[c] == 32)
			*(u16 *)(TILES_BG2 + address + 2 * c) = 528 + inv;
		else
			*(u16 *)(TILES_BG2 + address + 2 * c) = string[c] + 464 + inv;
		c++;
	}
}


//draw a box with a string in it
void draw_box(u8 x, u8 y, u8 *string)
{
u32 adr = 64 * (y - 2) + 2 * x - 4;
u8 strlen = 0;
u8 c;

	while(string[strlen] != 0)
		strlen++;

	*(u16 *)(TILES_BG1 + adr) = 67;								//topleft corner
	*(u16 *)(TILES_BG1 + adr + strlen * 2 + 6) = 70;			//topright corner
	*(u16 *)(TILES_BG1 + adr + 4 * 64) = 68;					//downleft corner
	*(u16 *)(TILES_BG1 + adr + 4 * 64 + strlen * 2 + 6) = 71;	//downright corner	

	*(u16 *)(TILES_BG1 + adr + 64) = 64;
	*(u16 *)(TILES_BG1 + adr + 128) = 64;
	*(u16 *)(TILES_BG1 + adr + 192) = 64;						//left wall

	*(u16 *)(TILES_BG1 + adr + 64 + strlen * 2 + 6) = 65;
	*(u16 *)(TILES_BG1 + adr + 128 + strlen * 2 + 6) = 65;
	*(u16 *)(TILES_BG1 + adr + 192 + strlen * 2 + 6) = 65;		//right wall

	for (c = 0; c < (strlen + 2); c++)
	{
		*(u16 *)(TILES_BG1 + adr + c * 2 + 2) = 66;				//upper wall
		*(u16 *)(TILES_BG1 + adr + c * 2 + 2 + 1 * 64) = 0;		//clear BG
		*(u16 *)(TILES_BG1 + adr + c * 2 + 2 + 2 * 64) = 0;
		*(u16 *)(TILES_BG1 + adr + c * 2 + 2 + 3 * 64) = 0;	
		*(u16 *)(TILES_BG1 + adr + c * 2 + 2 + 4 * 64) = 69;	//downside wall
	}

	print_string1(string, 64 * y + 2 * x);
}


//draw score, time etc. on screen
void draw_info()
{
u8 c;
u32 ts = score;

	u8 strtime[]  = "TIME : 0000";
	u8 strlevel[] = "LEVEL: 00";
	u8 strlives[] = "LIVES: 00";
	u8 strscore[] = "SCORE: 00000000";

	strtime[7] = (time / 1000) + 48;
	strtime[8] = ((time / 100) % 10) + 48;
	strtime[9] = ((time / 10) % 10) + 48;
	strtime[10] = (time % 10) + 48;
	print_string(strtime, 64 * 19);

	strlevel[7] = (level / 10) + 48;
	strlevel[8] = (level % 10) + 48;
	print_string(strlevel, 64 * 18 + 42);

	strlives[7] = (lives / 10) + 48;
	strlives[8] = (lives % 10) + 48;
	print_string(strlives, 64 * 19 + 42);

	for (c = 0; c < 8; c++)
	{
		strscore[7 + 7 - c] = (ts % 10) + 48;
		ts = ts / 10;
	}	   
	print_string(strscore, 64 * 18);
}


//draw all sprites at the correct place
void draw_sprites()
{
u8 i;
s16 offx = 0;
s16 offy = 0;

	if (objects[0].x < 104)
		offx = 8;
	else
		if (objects[0].x > 120)
			offx = -8;
		else
			offx = (112 - objects[0].x);

	if (objects[0].y < 64)
		offy = 8;
	else
		if (objects[0].y > 96)
			offy = -24;
		else
			offy = (72 - objects[0].y);
	
	for (i = 0; i < 16; i++)
	{
		if (objects[i].l == 1)
		{
			OAM[i].Attrib0 = objects[i].y + offy;			//sprite y
			OAM[i].Attrib1 = objects[i].x + offx + 0x4000;	//sprite x
			OAM[i].Attrib2 = objects[i].spr + 1024;			//sprite number
		}
	}
}


//draw the entire level on screen
void draw_level()
{
u32 c;
u8 x, y, p;

	*(u16 *)(TILES_BG1) = 67;				//topleft corner
	*(u16 *)(TILES_BG1 + 62) = 70; 			//topright corner
	*(u16 *)(TILES_BG1 + 64 * 23) = 68; 		//downleft corner
	*(u16 *)(TILES_BG1 + 64 * 23 + 62) = 71; 	//downright corner

	for (y = 1; y < 23; y++)
	{
		*(u16 *)(TILES_BG1 + 64 * y) = 64;	//left wall
		*(u16 *)(TILES_BG1 + 64 * y + 62) = 65; //right wall
	}

	for (x = 1; x < 31;x++)
	{
		*(u16 *)(TILES_BG1 + x * 2) = 66; //upper wall
		*(u16 *)(TILES_BG1 + x * 2 + 64 * 23) = 69; //down wall
	}

	c=0;
	for (y = 0; y < 11; y++)
	{
		for (x = 0; x < 15; x++)
		{
			p = leveldata[c]*2;
			
			if (p > 31)
				p = 0;

			*(u16 *)(TILES_BG1 + 66 + 4 * x + 128 * y) = p;
			*(u16 *)(TILES_BG1 + 66 + 4 * x + 128 * y + 2) = p + 1;
			*(u16 *)(TILES_BG1 + 66 + 4 * x + 128 * y + 64) = p + 32;
			*(u16 *)(TILES_BG1 + 66 + 4 * x + 128 * y + 66) = p + 33;

			c++;
		}
	}
}


//disable all options in menu
void disable_option()
{
	print_string2("    START    ", 64 * 17 + 18, 0);
	print_string2("  PASSWORD   ", 64 * 18 + 18, 0);
}


//enable one option in menu
void enable_option(u32 choice)
{
	if (choice == 0)
		print_string2("    START    ", 64 * 17 + 18, 1);
	else
		print_string2("  PASSWORD   ", 64 * 18 + 18, 1);
}


//this is the menu-routine
u32 menu()
{
u32 mchoice = 0;
u32 i;
u8 strstart[] = "    START    ";
u8 strpass[]  = "  PASSWORD   ";
u16 j;

	VSYNC;	//wait for vblank
	*(u16 *)REG_DISPCNT = DISP_LCDC_OFF; // LCDC OFF
	for (i = 0; i < 15; i++)
		*(u16 *)(BG_PALET + 2 * i) = intro_palette[i];	//transfer intro-palette

	for (i = 0; i < 640;i++)
		*(u16 *)(TILES_BG0 + 2 * i) = 0; //clear text-page

	print_string2(strstart, 64 * 17 + 18, 1);		//first option always enabled at start menu
	print_string2(strpass, 64 * 18 + 18, 0);

	VSYNC;	//wait for vblank again
	*(u16 *)REG_DISPCNT = 0 | DISP_BG2_ON;	//enable menu+intro

	j = joypad();
	VSYNC;
	WaitForLine(161);
	while (!(j & J_A) )	//leave this loop if J_A is pressed
	{
		VSYNC;
		WaitForLine(161);
		j = joypad();
		if (j & J_UP)	//if up is pressed
		{	
			VSYNC;					//wait a little bit
			WaitForLine(161);
			disable_option();	//disable current option
			mchoice = 1 - mchoice;
			enable_option(mchoice);	//enable new option
			wait_joypad(J_UP);
		}

		if (j & J_DOWN )
		{
			VSYNC;					//wait a little bit
			WaitForLine(161);
			disable_option();	//disable current option
			mchoice = 1 - mchoice;
			enable_option(mchoice);	//enable new option
			wait_joypad(J_DOWN);
		}
	}

	return mchoice;
}


//let the player input a password
u8 input_password()
{
u8 i;
u8 passlist[4][7] = {"QINFGF", "RGWODA", "TQVEAZ", "OFCPMD"};
u8 password[] = "AAAAAA";
u8 wt = 0;
u8 p = 0;
u16 j;

	VSYNC;
	*(u16 *)REG_DISPCNT = DISP_LCDC_OFF; // LCDC OFF
	for (i = 0; i < 15; i++)
		*(u16 *)(BG_PALET + 2 * i) = tiles_palette[i];	//transfer palette

	print_string("INPUT PASSWORD", 64 * 4 + 18);
	print_string("AAAAAA", 64 * 10 + 26);

	VSYNC;
	WaitForLine(161);
	*(u16 *)REG_DISPCNT = 0 | DISP_BG0_ON;	//enable screen
	wait_joypad(J_A);

	j = joypad();
	while (!(j & J_A))	//wait until player presses a-button
	{
		VSYNC;
		WaitForLine(161);
		j = joypad();

		wt++;
		if (wt == 15)
			*(u16 *)(TILES_BG0 + 64 * 10 + 26 + 2 * p) = 58;
		if (wt == 30)
		{
			*(u16 *)(TILES_BG0 + 64 * 10 + 26 + 2 * p) = password[p] + 48;
			wt=0;
		}

		if (j & J_LEFT)
		{
			*(u16 *)(TILES_BG0 + 64 * 10 + 26 + 2 * p) = password[p] + 48;
			if (!p)
				p = 5;
			else
				p--;

			wait_joypad(J_LEFT);
		}

		if (j & J_RIGHT)
		{
			*(u16 *)(TILES_BG0 + 64 * 10 + 26 + 2 * p) = password[p] + 48;
			if (p == 5)
				p = 0;
			else
				p++;

			wait_joypad(J_RIGHT);
		}

		if (j & J_UP)
		{
			if (password[p] < 'Z')
				password[p]++;
			else
				password[p] = 'A';
			*(u16 *)(TILES_BG0 + 64 * 10 + 26 + 2 * p) = password[p] + 48;
			wait_joypad(J_UP);
		}

		if (j & J_DOWN)
		{
			if (password[p]>'A')
				password[p]--;
			else
				password[p] = 'Z';
			*(u16 *)(TILES_BG0 + 64 * 10 + 26 + 2 * p) = password[p] + 48;
			wait_joypad(J_DOWN);
		}
	}

	*(u16 *)(TILES_BG0 + 64 * 10 + 26 + 2 * p) = password[p] + 48;
	j=wt=0;
	for (i = 0; i < 4; i++)
	{
		for (p=0; p<6; p++)
		{
			if (password[p] != passlist[i][p])
				j=1;
		}

		if (!j)
			wt = i * 5 + 6;
	}

	if (!wt)
	{
		print_string("ERROR", 64 * 16 + 26);
		wait_joypad(J_A);
	}

	wait_joypad(J_A);

	return wt;
}


//reset all objects
void init_objects()
{
u8 c;

	for(c = 0; c < 16; c++)
	{
		objects[c].dir = 0;
		objects[c].dx = 0;
		objects[c].dy = 0;
		objects[c].l = 0;
		objects[c].move = 0;
		objects[c].spr = 0;
		objects[c].step = 0;
		objects[c].x = 0;
		objects[c].y = 0;
	}
}


//initialise player
void init_player()
{
	objects[0].dx = sx;
	objects[0].dy = sy;
	objects[0].x = sx * 16;
	objects[0].y = sy * 16;
	objects[0].l = 1;
}


//initialise all rocks
void init_rocks()
{
u8 c;
u8 cur_rock = 5;

	cur_rock = 5;

	for (c = 0; c != 15 * 11; c++)
	{
		if (leveldata[c] == 3) /* initialise rock */
		{
		    objects[cur_rock].dx = c % 15;
		    objects[cur_rock].dy = c / 15;
		    objects[cur_rock].x = (c % 15) * 16;
		    objects[cur_rock].y = (c / 15) * 16;
		    objects[cur_rock].l = 1;
			objects[cur_rock].spr = 192;
		    cur_rock++;
			leveldata[c] = 17;
		}
	}
}


//initialise all enemies
void init_enemy()
{
u8 c;
u8 cur_enemy = 1;

	for (c = 0; c != 15 * 11; c++)
	{
		if (leveldata[c] == 14 || leveldata[c] == 13)		//is there an enemy?
		{
			objects[cur_enemy].dx = c % 15;
			objects[cur_enemy].dy = c / 15;
			objects[cur_enemy].x = (c % 15) * 16;
			objects[cur_enemy].y = (c / 15) * 16;
			objects[cur_enemy].l = 1;
			objects[cur_enemy].step = 16;
			
			if (leveldata[c] == 14)	//this one's moving horizontally
			{
				objects[cur_enemy].spr = 128;
				if (objects[cur_enemy].dx > 0 && leveldata[c - 1] == 0)
					objects[cur_enemy].dir = 7;
				else
					objects[cur_enemy].dir = 3;
			}
			else
			{	//this one's moving vertically
				objects[cur_enemy].spr = 128 + 32;
				if (objects[cur_enemy].dy > 0 && leveldata[c - 15] == 0)
					objects[cur_enemy].dir = 1;
				else
					objects[cur_enemy].dir = 5;

			}
			cur_enemy++;
			leveldata[c] = 16;
		}
	}
}


//initialise one level
void init_level(u8 l)
{
u32 i = (15 * 11 + 4) * l;
u32 c;

	for (c = 0; c < 128; c++)
		OAM[c].Attrib0 = 168;	//make sure all sprites are displayed outside visible range

	time = (levels[i] / 16) * 1000;
	time += (levels[i] & 15) * 100;
	time += (levels[i + 1] / 16) * 10;
	time += (levels[i + 1] & 15);	//time was in BCD-format

	time = time *2;	//more time needed to make it a bit easier

	sy = levels[i + 2];
	sx = levels[i + 3];

	dead = 0;

	fruitleft = 0;
	for (c = 0; c < 15 * 11; c++)
	{
		leveldata[c] = levels[i + c + 4];	//copy leveldata	-could be done with DMA but I have to count fruit anyway
		if (leveldata[c] == 4)				//is this fruit??
			fruitleft++;					//more fruit to eat
	}

	leveldata[15 * sy + sx] = 0;	//delete spot player

	init_objects();
	init_player();
	init_rocks();
	init_enemy();

	draw_level();	//draw level
	draw_info();

	VSYNC;
	*(u16 *)REG_DISPCNT = 0 | DISP_BG0_ON | DISP_BG1_ON;
}


//search a rock in the object-table
u8 search_rock(u8 xr, u8 yr)
{
u8 c;

    for (c = 5; c < 15; c++)
        if (objects[c].l && objects[c].dx == xr && objects[c].dy == yr && objects[c].step == 0)
			return c;

    return 0;
}


//initialse the block
void init_block(u8 dx, u8 dy, u8 d)
{
u32 adr;

	objects[15].dir = d;		//direction
	objects[15].l = 1;			//valid object
	objects[15].dx = dx;		//x-address in leveldata
	objects[15].dy = dy;		//y-address in leveldata
	objects[15].x = 16 * dx;	//x-position on screen
	objects[15].y = 16 * dy;	//y-position on screen
	objects[15].step = 16;		//number of steps to do
	objects[15].spr = 196;		//sprite to use

	adr = dx * 4 + 2 + 64 + 128 * dy;	//calculate address object on screen
	*(u16 *)(TILES_BG1 + adr) = 0;
	*(u16 *)(TILES_BG1 + adr + 2) = 0;
	*(u16 *)(TILES_BG1 + adr + 64) = 0;
	*(u16 *)(TILES_BG1 + adr + 66) = 0;	//print object on screen

	adr = dy * 15 + dx;	//calculate next address of block
	switch (d)
	{
	case UP:
		adr = adr - 15;
		break;
	case RIGHT:
		adr++;
		break;
	case DOWN:
		adr = adr + 15;
		break;
	case LEFT:
		adr--;
		break;
	}
	leveldata[adr] = 17;	//this prevents enemies & rocks from moving through this block
}


//check if player can move up
void check_up()
{
u8 p;

	if (objects[0].dy == 0)
		return;

	p = leveldata[(objects[0].dy - 1) * 15 + objects[0].dx];
	
	if (p == 2 || p == 3)
		return;

	if (p == 11)
	{
		if (objects[0].dy == 1)
			return;
		if (leveldata[objects[0].dy * 15 + objects[0].dx - 30] != 0)
			return;
		init_block(objects[0].dx, objects[0].dy - 1, 1);
	}

	if (p == 17)
		return;

	objects[0].step = 16;
	objects[0].dir = UP;

}


//check if player can move right
void check_right()
{
u8 r, p;

	if (objects[0].dx == 14)
		return;

	p = leveldata[objects[0].dy * 15 + objects[0].dx + 1];

	if (p == 2 || p == 3 || p == 16)
		return;

	if (p == 17)
	{
		if (objects[0].dx == 13)
			return;
		if (leveldata[objects[0].dy * 15 + objects[0].dx + 2] != 0)
			return;

		r = search_rock(objects[0].dx + 1, objects[0].dy);
		if (r != 0)
		{
			objects[r].dir = RIGHT;
			objects[r].step = 16;
			leveldata[objects[0].dy * 15 + objects[0].dx + 2] = 17;
			leveldata[objects[0].dy * 15 + objects[0].dx + 1] = 17;
		}
		else
			return;
	}

	if (p == 11)
	{
		if (objects[0].dx == 13)
			return;
		if (leveldata[objects[0].dy * 15 + objects[0].dx + 2] != 0)
			return;
		init_block(objects[0].dx + 1, objects[0].dy, 3);
	}

	objects[0].step = 16;
	objects[0].dir = RIGHT;
}


//check if player can move down
void check_down()
{
u8 p;

	if (objects[0].dy == 10)
		return;

	p = leveldata[(objects[0].dy + 1) * 15 + objects[0].dx];

	if (p == 2 || p == 3)
		return;

	if (p == 11)
	{
		if (objects[0].dy == 9)
			return;
		if (leveldata[objects[0].dy * 15 + objects[0].dx + 30] != 0)
			return;
		init_block(objects[0].dx, objects[0].dy + 1, 5);
	}

	if (p == 17)
		return;

	objects[0].step = 16;
	objects[0].dir = DOWN;
}


//check if player can move left
void check_left()
{
u8 r, p;

	if (objects[0].dx == 0)
		return;

	p = leveldata[objects[0].dy * 15 + objects[0].dx - 1];

	if (p == 2 || p == 3 || p == 16)
		return;

	if (p == 17)
	{
		if (objects[0].dx == 1)
			return;
		if (leveldata[objects[0].dy * 15 + objects[0].dx - 2] != 0)
			return;

		r = search_rock(objects[0].dx - 1, objects[0].dy);
		if (r != 0)
		{
			objects[r].dir = LEFT;
			objects[r].step = 16;
			leveldata[objects[0].dy * 15 + objects[0].dx - 2] = 17;
			leveldata[objects[0].dy * 15 + objects[0].dx - 1] = 17;
		}
		else
			return;
	}

	if (p == 11)
	{
		if (objects[0].dx == 1)
			return;
		if (leveldata[objects[0].dy * 15 + objects[0].dx - 2] != 0)
			return;
		init_block(objects[0].dx - 1, objects[0].dy, 7);
	}

	objects[0].step = 16;
	objects[0].dir = LEFT;
}


//do some simple MOSAIC-stuff
void mosaic_on()
{
u8 c;

	*(u16 *)REG_DISPCNT = 0 | DISP_BG0_ON | DISP_BG1_ON;	//it'll look a bit strange with sprite so disable sprites
	for (c = 0; c < 16; c+=2)
	{
		VSYNC;
		WaitForLine(161);
		MOSAIC = (c) + (c << 4) + (c << 8) + (c << 12);
	}
}


//do some more simple MOSAIC-stuff
void mosaic_off()
{
s8 c;

	for (c = 15; c > 0; c-=2)
	{
		VSYNC;
		WaitForLine(161);
		MOSAIC = (c) + (c << 4) + (c << 8) + (c << 12);
	}

	*(u16 *)REG_DISPCNT = 0 | DISP_BG0_ON | DISP_BG1_ON | DISP_OBJ_ON | 64;
	
	MOSAIC = 0;
}


//turn the screen upside down
void turn_screen()
{
u8 t, c, y;

	leveldata[objects[0].dx + 15 * objects[0].dy] = 0;

	mosaic_on();

	for (y = 0; y != 5; y++)	//turn the screendata upside down
	{
		for (c=0; c!= 15; c++)
		{
			t=leveldata[y * 15 + c];
			leveldata[y * 15 + c]=leveldata[(10 - y) * 15 + c];
			leveldata[(10 - y) * 15 + c]=t;
		}
	}

	for (c = 0; c < 16; c++)	//re-init all objects
	{
		if (objects[c].l)
		{
			objects[c].dy = 10 - objects[c].dy;
			objects[c].y = 160 - objects[c].y;

			if (c < 5 && objects[c].step && (objects[c].dir==1 || objects[c].dir==5))
				objects[c].dir = 6 - objects[c].dir;
		}
	}

	for (c = 5; c != 15; c++)
	{ 
		if (objects[c].l && objects[c].dir == 5)
		{
			objects[c].dy--;
			objects[c].step = 16 - objects[c].step;
		}
	}

	draw_level();	//draw new level

	mosaic_off();
}


//teleport to the first teleporter we can find on screen
void teleport()
{
u8 c = 0;
u32 adr;

	mosaic_on();

	while (leveldata[c] != 6)	//search teleporter
		c++;

	objects[0].dx = c % 15;			//init new place player
	objects[0].dy = c / 15;
	objects[0].x = (c % 15) * 16;
	objects[0].y = (c / 15) * 16;

	leveldata[c]=0;				//clear leveldata
	adr = objects[0].dx * 4 + 2 + 64 + 128 * objects[0].dy;
	*(u16 *)(TILES_BG1 + adr) = 0;		//erase object on screen
	*(u16 *)(TILES_BG1 + adr + 2) = 0;
	*(u16 *)(TILES_BG1 + adr + 64) = 0;
	*(u16 *)(TILES_BG1 + adr + 66) = 0;

	mosaic_off();
}


//let the player get an item
void get_item()
{
u8 n;
u32 adr = objects[0].dx * 4 + 2 + 64 + 128 * objects[0].dy;

	n=leveldata[objects[0].dx + objects[0].dy * 15];
	leveldata[objects[0].dx + objects[0].dy * 15] = 0;
	*(u16 *)(TILES_BG1 + adr) = 0;
	*(u16 *)(TILES_BG1 + adr + 2) = 0;
	*(u16 *)(TILES_BG1 + adr + 64) = 0;
	*(u16 *)(TILES_BG1 + adr + 66) = 0;

	switch (n)
	{
	case 1:
		score++;
		break;
	case 4:
		fruitleft--;
		score = score + 500;
		break;
	case 5:
		score = score + 100;
		break;
	case 6:
		teleport();
		break;
	case 7:
		time = time + 500;
		break;
	case 8:
		turn_screen();
		break;
	case 9:
		lives++;
		break;
	case 10:
		freeze_enemy = 500;
		break;
	case 12:
		dead = 1;
		break;
	default:
		break;
	}
}


//let the player move around
void move_player()
{
	if (objects[0].step > 0)	//if player is already moving, let it move automatically
	{
		objects[0].step--;
		
		switch (objects[0].dir)
		{
		case UP:
			objects[0].spr = 64 + (objects[0].step / 2) * 4;
			objects[0].y--;
			break;
		case RIGHT:
			objects[0].spr = 32 + (objects[0].step / 2) * 4;
			objects[0].x++;
			break;
		case DOWN:
			objects[0].spr = 96 + (objects[0].step / 2) * 4;
			objects[0].y++;
			break;
		case LEFT:
			objects[0].spr = 0 + (objects[0].step / 2) * 4;
			objects[0].x--;
			break;
		}

		if (objects[0].step == 0)
		{
			switch (objects[0].dir)
			{
			case UP:
				objects[0].dy--;
				break;
			case RIGHT:
				objects[0].dx++;
				break;
			case DOWN:
				objects[0].dy++;
				break;
			case LEFT:
				objects[0].dx--;
				break;
			}

			get_item();	//let the player get an item
		}
	}
}

//pause the game
void pause()
{
u8 strpause[] = "PAUSE";
u8 strunpause[] = "     ";
u16 adr = 64 * 8 + 24;
u8 t = 0;

	mosaic_on();	//start with stupid mosaic

	*(u16 *)REG_DISPCNT = 0 | DISP_BG0_ON;	//player isn't allowed to see level, so disable it

	print_string(strpause, adr);

	wait_joypad(J_B);

	while(!(joypad() & J_B) )	//wait for b-button being released
	{
		VSYNC;
		WaitForLine(161);
		t++;
		if (t == 17)
			print_string(strunpause, adr);	//alternating text
		if (t == 34)
		{
			print_string(strpause, adr);
			t = 0;
		}
	}

	print_string(strunpause, adr);

	*(u16 *)REG_DISPCNT = 0 | DISP_BG0_ON | DISP_BG1_ON;

	mosaic_off();	//end with stupid mosaic
}

//check for player movement
void check_player()
{
u16 j = joypad();

	if (j & J_SELECT)	//enable suicide
		dead = 1;

	if (j & J_B)
		pause();

	if (objects[0].step == 0)
	{
		if (j & J_UP)
			check_up();
		if (j & J_RIGHT && objects[0].step != 16)	//this prevents the player from taking a different 
			check_right();								//direction when it's pressing multiple keys
		if (j & J_DOWN && objects[0].step != 16)
			check_down();
		if (j & J_LEFT && objects[0].step != 16)
			check_left();
	}
}


//move all rocks
void move_rocks()
{
u8 c, p;

	for (c = 5; c < 15; c++)	//loop through all rocks
	{
		if (objects[c].l == 1)	//if rock is valid
		{
			if (objects[c].step > 0)
			{
				objects[c].step--;
				
				switch (objects[c].dir)
				{
				case RIGHT:
					objects[c].x++;
					break;
				case DOWN:
					objects[c].y++;
					break;
				case LEFT:
					objects[c].x--;
					break;
				}	//end switch
				if (objects[c].step == 0)
				{
					leveldata[objects[c].dy * 15 + objects[c].dx] = 0;
					switch (objects[c].dir)
					{
					case RIGHT:
						objects[c].dx++;
						break;
					case DOWN:
						objects[c].dy++;
						break;
					case LEFT:
						objects[c].dx--;
						break;
					}	//end switch
					objects[c].dir = 0;
				}	//end if
			}	//end if

			if (objects[c].step == 0)	//now we can check if rock can move
			{
				p = leveldata[15 * objects[c].dy + objects[c].dx + 15];
				
				if ( (p == 0 || p == 16 || p == 15) && objects[c].dy < 10)
				{
					if (objects[c].dx == objects[0].dx && (objects[c].dy + 1) == objects[0].dy)
					{
						if (objects[c].move == 1)
						{
							objects[c].step = 16;
							objects[c].dir = DOWN;
							leveldata[15 * objects[c].dy + objects[c].dx] = 17;
							leveldata[15 * objects[c].dy + objects[c].dx + 15] = 17;
						}
					}
					else
					{
						objects[c].step = 16;
						objects[c].dir = DOWN;
						leveldata[15 * objects[c].dy + objects[c].dx] = 17;
						leveldata[15 * objects[c].dy + objects[c].dx + 15] = 17;
						objects[c].move = 1;
					}
				}
				else
					objects[c].move = 0;
			}
		}	//end if
	}	//end for
}


//move a block
void move_block()
{
u32 adr;

	if (objects[15].l == 1)	//is there a valid block?
	{
		objects[15].step--;

		switch(objects[15].dir)	//move the block
		{
		case UP:
			objects[15].y--;
			break;
		case RIGHT:
			objects[15].x++;
			break;
		case DOWN:
			objects[15].y++;
			break;
		case LEFT:
			objects[15].x--;
			break;
		}

		if (objects[15].step == 0)
		{
			leveldata[objects[15].dy * 15 + objects[15].dx] = 0;	//block isn't here now
			switch(objects[15].dir)	//bring block to new position in leveldata
			{
			case UP:
				objects[15].dy--;
				break;
			case RIGHT:
				objects[15].dx++;
				break;
			case DOWN:
				objects[15].dy++;
				break;
			case LEFT:
				objects[15].dx--;
				break;
			}

			objects[15].l = 0;	//block stopped moving
			leveldata[objects[15].dy * 15 + objects[15].dx] = 11;	//block is here now
			adr = objects[15].dx * 4 + 2 + 64 + 128 * objects[15].dy;

			OAM[15].Attrib0 = 168;	//place sprite outside screen
			*(u16 *)(TILES_BG1 + adr) = 22;
			*(u16 *)(TILES_BG1 + adr + 2) = 23;
			*(u16 *)(TILES_BG1 + adr + 64) = 54;
			*(u16 *)(TILES_BG1 + adr + 66) = 55;	//print object on screen
		}
	}
}


//move the enemy up
void move_enemy_up(u8 c)
{
u8 p;

	objects[c].step--;	//one step less
	objects[c].y--;		//go 1 pixel up
	objects[c].spr = 128 + 32 + (objects[c].step / 2) * 4;

	if (objects[c].step == 0)
	{
		leveldata[objects[c].dy * 15 + objects[c].dx] = 0;
		objects[c].dy--;	//to previous position on screen
		leveldata[objects[c].dy * 15 + objects[c].dx] = 15;

		p = leveldata[objects[c].dy * 15 + objects[c].dx - 15];

		objects[c].step = 16;
	
		if (p > 15 || (p > 0 && p < 15) || objects[c].dy == 0)	//can the enemy move on?
		{
			leveldata[objects[c].dy * 15 + objects[c].dx + 15] = 15;
			objects[c].dir = DOWN;	//no -> switch direction
		}
		else
			leveldata[objects[c].dy * 15 + objects[c].dx - 15] = 15;
	}
}


//move the enemy down
void move_enemy_down(u8 c)
{
u8 p;

	objects[c].step--;	//one step less
	objects[c].y++;		//go 1 pixel down
	objects[c].spr = 128 + 32 + (objects[c].step / 2) * 4;

	if (objects[c].step == 0)
	{
		leveldata[objects[c].dy * 15 + objects[c].dx] = 0;
		objects[c].dy++;	//to previous position on screen
		leveldata[objects[c].dy * 15 + objects[c].dx] = 15;

		p = leveldata[objects[c].dy * 15 + objects[c].dx + 15];

		objects[c].step = 16;
	
		if (p > 15 || (p > 0 && p < 15) || objects[c].dy == 10)	//can the enemy move on?
		{
			leveldata[objects[c].dy * 15 + objects[c].dx - 15] = 15;
			objects[c].dir = UP;	//no -> switch direction
		}
		else
			leveldata[objects[c].dy * 15 + objects[c].dx + 15] = 15;
	}
}


//move the enemy to the right
void move_enemy_right(u8 c)
{
u8 p;

	objects[c].step--;	//one step less
	objects[c].x++;		//go 1 pixel the right
	objects[c].spr = 128 + (objects[c].step / 2) * 4;

	if (objects[c].step == 0)
	{
		leveldata[objects[c].dy * 15 + objects[c].dx] = 0;
		objects[c].dx++;	//to previous position on screen
		leveldata[objects[c].dy * 15 + objects[c].dx] = 15;

		p = leveldata[objects[c].dy * 15 + objects[c].dx + 1];

		objects[c].step = 16;
	
		if (p > 15 || (p > 0 && p < 15) || objects[c].dx == 14)	//can the enemy move on?
		{
			objects[c].dir = LEFT;	//no -> switch direction
			leveldata[objects[c].dy * 15 + objects[c].dx - 1] = 15;
		}
		else
			leveldata[objects[c].dy * 15 + objects[c].dx + 1] = 15;
	}
}


//move the enemy to the left
void move_enemy_left(u8 c)
{
u8 p;

	objects[c].step--;	//one step less
	objects[c].x--;		//go 1 pixel to the left
	objects[c].spr = 128 + (objects[c].step / 2) * 4;

	if (objects[c].step == 0)
	{
		leveldata[objects[c].dy * 15 + objects[c].dx] = 0;
		objects[c].dx--;	//to previous position on screen
		leveldata[objects[c].dy * 15 + objects[c].dx] = 15;

		p = leveldata[objects[c].dy * 15 + objects[c].dx - 1];

		objects[c].step = 16;
	
		if (p > 15 || (p > 0 && p < 15) || objects[c].dx == 0)	//can the enemy move on?
		{
			objects[c].dir = RIGHT;	//no -> switch direction
			leveldata[objects[c].dy * 15 + objects[c].dx + 1] = 15;
		}
		else
			leveldata[objects[c].dy * 15 + objects[c].dx - 1] = 15;
	}
}


//handle the movement of enemies
void move_enemy()
{
u8 c;

	if (freeze_enemy > 0)
	{
		freeze_enemy--;
		return;
	}

	for(c=1; c<5; c++)
	{
		switch(objects[c].dir)
		{
		case UP:
			move_enemy_up(c);
			break;
		case RIGHT:
			move_enemy_right(c);
			break;
		case DOWN:
			move_enemy_down(c);
			break;
		case LEFT:
			move_enemy_left(c);
			break;
		}
	}
}


//set BG1 at the right place
void set_scroll()
{
u16 scx = 0;
u16 scy = 0;

	if (objects[0].x < 104)
		scx = 0;
	else
		if (objects[0].x > 120)
			scx = 16;
		else
			scx = 16 - (120 - objects[0].x);

	if (objects[0].y < 64)
		scy = 0;
	else
		if (objects[0].y > 96)
			scy = 32;
		else
			scy = 32 - (96 - objects[0].y);

	*(u16 *)BG1_X = scx;
	*(u16 *)BG1_Y = scy;
}


//check if object 'i' overlaps another object
//the GBA probably has built-in colission-detection but I haven't seen
//documents 'bout it yet so I'll just use this :)
void check_overlap(int i)
{
u8 c, c1;

	if (i)
		c1 = 5;	//enemies only have to be compared with rocks (for enemy killing)
	else
		c1 = 1; //player has to be compared with 

	for (c = c1; c != 15; c++)	//loop through all objects
	{
		if (objects[c].l)	//if it's an valid object, we have to check it
		{
			if ( abs(objects[c].x - objects[i].x) < 13 && abs(objects[c].y - objects[i].y) < 13) //overlap?
			{
				if (!i)	//if it's an player
					dead=1;	//player is dead
				else
				{
					score = score + 500;	//it was an enemy, so score!
					objects[i].l = 0;		//kill of enemy
					OAM[i].Attrib0 = 168;	//enemy out of sight
				}
			}
		}
	}
}


//check for colission of objects
void check_colission()
{
u8 e;

	for (e = 0; e != 5; e++)	//loop through all player+enemies
		if (objects[e].l)		//if enemy is valid
			check_overlap(e);	//check for overlap other objects
}


//wait for t interrupts, unless a-button is pressed
void wait_time(u16 t)
{
u8 c = 0;

	while(c < t)
	{
		VSYNC;
		WaitForLine(161);
		if (joypad() & J_A)
			c = t;
		c++;
	}
}


//give the player some bonus score and maybe a password
void bonus()
{
u16 i;
u8 string[] = "PASSWORD: AAAAAA";
u8 passlist[4][7] = {"QINFGF", "RGWODA", "TQVEAZ", "OFCPMD"};

	mosaic_on();

	*(u16 *)BG1_X = 0;
	*(u16 *)BG1_Y = 0;
	for (i = 0; i < 32 * 20; i++)
		*(u16 *)(TILES_BG1 + 2 * i) = 0;

	*(u16 *)REG_DISPCNT = 0 | DISP_BG0_ON | DISP_BG1_ON;

	MOSAIC = 0;

	draw_box(10,8,"WELL DONE");

	while(time > 0)
	{
		VSYNC;
		WaitForLine(161);
		time = time - 2;

		if (time == 1)
			time = 0;
		score = score + level * 10;
		draw_info();
	}

	if (level % 5 == 0)
	{
		for (i = 0; i < 6; i++)
			string[10 + i] = passlist[level / 5 - 1][i];

		draw_box(8,8,string);
		wait_time(180);
	}
}


//play a game starting from level l
void play_game(u8 l)
{
u32 i;

	for (i = 0; i < 15;i++)
		*(u16 *)(BG_PALET + 2*i) = tiles_palette[i];	//transfer palette
	for (i = 0; i < 32 * 20;i++)
		*(u16 *)(TILES_BG0 + 2 * i) = 0;	//clear BG0

	score = 0;
	lives = 3;
	level = l;

	while ( level < 26 && lives > 0)	//loop until game over or completed game
	{
		*(u16 *)BG1_X = 0;
		*(u16 *)BG1_Y = 0;
		init_level(level - 1);
		mosaic_off();
		draw_box(13, 8, "READY");
		wait_time(120);
		draw_level();
		*(u16 *)REG_DISPCNT = 0 | DISP_BG0_ON | DISP_BG1_ON | DISP_OBJ_ON | 64;

		while (dead == 0 && time > 0 && fruitleft > 0)	//main game loop
		{

			VSYNC;
			move_player();
			move_rocks();
			check_player();
			move_enemy();
			move_block();
			set_scroll();
			check_colission();
			time--;
			draw_info();
			draw_sprites();
		}

		if (time == 0 || dead == 1)	//player is dead
		{
			objects[0].spr = 200;
			for(i = 0; i < 60; i++)
			{
				VSYNC;
				move_rocks();
				move_enemy();
				draw_sprites();
			}
			lives--;
		}

		if (fruitleft == 0)		//player cleared level
		{
			bonus();
			level++;
		}
	}

	if (lives == 0)		//GAME OVER!
	{
		*(u16 *)BG1_X = 0;
		*(u16 *)BG1_Y = 0;

		for (i = 0; i < 32 * 20; i++)
			*(u16 *)(TILES_BG1 + 2 * i) = 0;

		*(u16 *)REG_DISPCNT = 0 | DISP_BG1_ON;

		draw_box(10, 8, "GAME OVER");

		wait_time(160);
		while(joypad() & J_A) {}
	}

	if (level == 26)	//player has finished the game
	{
		*(u16 *)BG1_X = 0;
		*(u16 *)BG1_Y = 0;

		for (i = 0; i < 32 * 20; i++)
			*(u16 *)(TILES_BG1 + 2 * i) = 0;

		*(u16 *)REG_DISPCNT = 0 | DISP_BG1_ON;

		draw_box(8, 8, "CONGRATULATIONS");

		wait_time(160);
		while(joypad() & J_A) {}
	}
}


//the program starts here
void AgbMain(void)
{
u8 l;

	init_program();

	while (1)	//always stay in loop
	{
		l = 0;

		if (menu() == 0)
			play_game(1);
		else
		{
			l = input_password();
			if (l > 0)
				play_game(l);
		}
	}
}

