Sopwith for GBA
---------------

GBA Port by David Rorex.
See README.sdl for original credits.

Controls:
Left  - Tip plane up
Right - Tip plane down
Down  - Flip plane over
B     - Drop Bomb
A     - Fire Gun
L     - Decellerate
R     - Accelerate
Start - Auto-pilot return to base for refueling & reloading ammo

Tips:
-To get going, tap R quickly a few times, then tap left to lift off, then tap 
right to level out.  Your goal is to destroy the buildings that are purple 
(cyan is your side).

-Don't drop bombs while upside down.

-If you run out of bombs/ammo, press Start to return to base

-If you fly too high, you will go into a stall, what I do is tap R a lot, while holding either Left or Right, this should pull out of the stall most of the time.

-Watch out for birds.

-If you get hit, return to base for repairs.
