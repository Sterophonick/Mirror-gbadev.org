                              ------------------
                              | Tank Commander |
                              ------------------

                         Version 1.3 (February 2006)

                             For GameBoy Advance

                         Programmed by Donnie Russell
                              Copyright (C) 2006



License
=======

The contents of this archive are freeware; they are not in the public domain.
This archive may only be redistributed in an unmodified state. The software
contained in this archive is provided to the end-user "as is", and comes with
no warranty of any kind. In no event shall the copyright owner be liable for
any damage that may result from the use of this software.

This software may not be sold in any form for any reason whatsoever.
Distribution of this software on cartridge media is strictly prohibited.



About This Game
===============

Tank Commander was clearly inspired by Atari's arcade game Battlezone, but
most of my experience with that game was not in the arcades, but with Atari's
port to the Atari 2600, and Activision's take on the concept, Robot Tank.

This is not an accurate simulation of tank warfare as, it could be argued,
Battlezone was (a modified version of that game was used in U.S. Army
training). Real tanks do not operate even remotely as they do in this game.



Technical Notes
===============

This game does not utilize any special graphics features of the GBA. Pixels
are simply written and cleared from the display (bitmap mode 3) in real-time,
fast enough to create the illusion of movement, and hopefully with little or
no flicker.

No actual GBA's were harmed in the making of this game; in other words, it
wasn't developed or tested on hardware.



Status Information
==================

The top-left corner of the display shows your current score and the amount
of damage to your tank. The bar grows shorter and changes color as your
tank takes hits from enemy weapons.

Color   Damage Level
-----   ------------
Green   None
Yellow  Moderate
Red     Severe

The top-center area of the display is occupied by your radar console. Enemy
tanks appear as white dots. Your tank is represented by the center of the
circle. The farther away from the center the dot is the more distant the
object. Dots in the top half of the circle represent objects in front of you.



Controls and Gameplay
=====================

Press START to begin the game.

This game is played from a first-person perspective. Rotate your tank
counterclockwise by pressing the left button of the control pad. Rotate it
clockwise by pressing the right button. Move forward or backward by pressing
the top or bottom buttons. Press the A button to fire your tank's weapon at
the enemy tanks that randomly appear around you. Holding down the button
causes your weapon to fire repeatedly.

When an incoming enemy tank is detected by your radar, it appears as a white
dot on your radar console. Rotate your tank to bring the enemy tank into view.
When an enemy tank is within range of your weapon, the grey range finder will
turn white. When tanks come into range, they begin firing upon you repeatedly.
Your tank's armor can withstand five impacts of the enemy's weapon, after
which your tank will be immobilized, ending the game.

There are two types of enemy tanks. Greenish-blue tanks are the more numerous
type and can be destroyed with a single hit, while orange tanks are fewer but
much more dangerous. The latter have stronger armor, requiring two hits to
destroy, and move faster than ordinary tanks. Regardless of type, destroyed
tanks are worth 250 points each.

Occasionally a destroyed enemy tank will leave behind a rotating purple
square. Drive your tank over these symbols to repair one unit of damage to
your tank.

When the game is over, if your final score is higher than any of the ten best
scores, you will be prompted to enter your name. Use the control pad to select
a letter, then press the A button to enter that letter and advance the
blinking cursor. Press the B button to move the cursor back. Press the START
button when finished. Please note that the letter under the cursor counts as
part of your entry.



Frequently Asked Questions
==========================

Question: Why does it take so long to fire my weapon?

Answer: The loading time of weapons is an important part of the strategy of
this game. A shorter loading time would make this a completely different kind
of game than I intended.


Question: Why does a tank that was behind me a moment ago suddenly appear in
front of me?

Answer: The world "loops" east-west and north-south, something like moving
across the surface of a tiny sphere.


Question: What is that in the background with dots flying out of it?

Answer: A volcano; there was one in Battlezone. The idea of making it erupt
was suggested to Battlezone's principal programmer, Ed Rotberg, but he was
busy with other aspects of the game and it wasn't added until the code was
submitted by the programmer who suggested it.


Question: How do I evade enemy fire?

Answer: One way is to wait for the enemy tank to fire, then return fire and
press the control pad left-down or right-down to dodge the shot. Use caution,
however, since another tank may be firing from another direction. Rocks can
be used to block enemy fire. Enemy tanks can also destroy each other, but no
points are awarded for it.
