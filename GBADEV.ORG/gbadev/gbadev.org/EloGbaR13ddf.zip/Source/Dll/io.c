void standard_io_write_handle (void)
{

}

void reg_dispcnt_write (void)
{

}

void reg_dm3cnt_write (void)
{
	if ((DM3CNT_H&0x8000) && !(DM3CNT_H&0x3000))
		exec_dma3();
}

