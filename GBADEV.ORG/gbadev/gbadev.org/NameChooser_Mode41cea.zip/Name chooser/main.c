/******************************************************************
*  ____________NAME CHOOSER EXAMPLE                               * 
*  BY:         MANULON                                            *
*  DATE:       25.06.03                                           *
*  THANKS TO:  DOVOTOS & GBAJUNKIE TUTORIALS                      *
*  E-MAIL:     CABRONELQUELOLEA@HOTMAIL.COM                       *
******************************************************************/
/************* COMMENTS ARE IN SPANISH ***************************/

// Includes
#include "gba.h"
#include "sprite.h"
#include "screenmode.h"
#include "keypad.h"

#include "paleta.h"	// Paleta de los sprites y del fondo
#include "fondo.h"	// Fondo
#include "cursor.h"	// Sprite del cursor
#include "letras.h"	// Sprite con todas las letras

// Constantes
#define N_LETRAS_ABECEDARIO 	 26		// N� de letras del abecedario
#define ABECEDARIO		 "ABCDEFGHIJKLMNOPQRSTUVWXYZ"   // Abecedario
#define POS_SAVE		 26 		// Posicion del SAVE
#define POS_LOAD		 27		// Posicion del LOAD
#define MAX_LETRAS		 18		// N� Maximo de letras para el nombre
#define POS_X_TEXTO_INI		 8		// Posicion X de la primera letra del nombre
#define POS_Y_TEXTO_INI		 8		// Posicion Y de la primera letra del nombre
#define SRAM_OFFSET		 0x0E000000	// Direccion para guardar el nombre en la SRAM      

// Estructura para guardar coordenadas
typedef struct tagPosicion
{
	u16 x;
	u16 y;
} Posicion;

// Variables globales
Posicion PosCursor[28];			// Para las distintas posiciones del cursor		
Posicion PosLetra;			// Para la posicion de la siguiente letra del nombre
OAMEntry Sprites[128];			// Array con los 128 sprites
u16      PosActualCursor = 0;		// Posicion inicial del cursor = 0 (letra "A")
u16	 Letras[N_LETRAS_ABECEDARIO];   // Para la direccion de cada letra
u16      N_Letra = 0;                   // Para saber las letras que llevamos escritas
char     TextoActual[MAX_LETRAS];	// Para guardar el texto actual

// Funcion Sleep de darkclud
void Sleep(int i)
{ 
   int x, y; 
   int c; 
   
   for (y = 0; y < i; y++) 
   { 
      for (x = 0; x < 4000; x++) 
         c = c + 2; // do something to slow things down 
   } 
} 

// Guarda el texto
void GuardaTexto(char *texto)
{
	u16 bucle;
	
	// Recorre todo el texto y guarda cada letra
	// en laposicion SRAM_OFFSET + bucle
	// por ejemplo la 3 letra se guardaria en: 0x0E000000 + 2 = 0x0E000002 
	for (bucle = 0; bucle < MAX_LETRAS; bucle++)
		*(u8 *)(SRAM_OFFSET + bucle) = texto[bucle];
}

// Carga el texto
void CargaTexto(char *texto)
{
	u16 bucle;
	
	// Lee el texto de la memoria y lo mete en el
	// texto que se le pasa como parametro
	for (bucle = 0; bucle < MAX_LETRAS; bucle++)
	{
		if (*(u8 *)(SRAM_OFFSET + bucle) == 0) break;
		texto[bucle] = *(u8 *)(SRAM_OFFSET + bucle);
	}
} 

// Saca todos los sprites fuera de la pantalla
void InicializaSprites()
{
	u16 bucle;
	
	// Recorrer todos los sprites y sacarlos fuera
	// de la pantalla
	for (bucle = 0; bucle < 128; bucle++)
	{
		Sprites[bucle].attribute0 = 160;	// y = 160
		Sprites[bucle].attribute1 = 240;	// x = 240
	}			 
}

// Inicializa las distintas posiciones del cursor
void InicializaPosCursor()
{
	u8 bucle;
	u8 linea, pos_letra_linea;
	
	linea = 0;
	pos_letra_linea = 0;  
	
	// pos_letra_linea  ->  0 1 2 3 4 5 6 7 8 9
	                        
	// Posiciones 		A B C D E F G H I J  linea 0
	// Posiciones 		K L M N O P Q R S T  linea 1
	// Posiciones     	    U V W X Y Z	     linea 2
	// Posiciones     	    SAVE   LOAD      -> PosCursor[26] y PosCursor[27]
	for (bucle = 0; bucle < 26; bucle++)
	{
		if (bucle == 10) 		// Cuando va por la "J" baja a la linea 2 y la posicion
		{ 				// de la 1� letra ("K") en la 2� linea es 0  
			linea = 1;
			pos_letra_linea = 0;
		}		
		else if (bucle == 20)		// Cuando va por la "T" baja a la linea 3 y la posicion
						// de la 1� letra ("U") en la 3� linea es 2 
		{
			linea = 2;
			pos_letra_linea = 2;
		}	
		PosCursor[bucle].x = 22 + pos_letra_linea * 20;
		PosCursor[bucle].y = 40 + linea * 20;
		pos_letra_linea++;
	}
	
	// Posicion del SAVE
	PosCursor[26].x = 78;
	PosCursor[26].y = 102;
	// Posicion del LOAD
	PosCursor[27].x = 148;
	PosCursor[27].y = 102;
}	

// Inicializa las letras
void InicializaLetras()
{
	u16 bucle;
	
	// Inicializar las distintas posiciones de las letras
	// en la memoria de la gba
	// +---+---+
	// |8x8|8x8|
	// +---+---+
	// |8x8|8x8|  Un sprite de 16x16 son 4 de 8x8 (por eso se multiplica por 4)
	// +---+---+  luego se multiplica 4 por 2 porque estamos en 256 colores 
	// En el modo 4 la memoria de los sprites empieza en 512,
	// pero en el esa posicion ya se encuentra el cursor que tambien es
	// de 16x16, y ocupa 8 posicion, por lo tanta las letras empiezan
	// en 512+8 = 520
	// Asi tenemos un array con todas las posiciones que resulta mas
	// sencillo de manejar (Letras[0] = primera letra, Letras[1] = segunda letra..)
	for (bucle = 0; bucle < N_LETRAS_ABECEDARIO; bucle++)
		Letras[bucle] = 520 + bucle * 8;
	
	PosLetra.x = POS_X_TEXTO_INI;	
	PosLetra.y = POS_Y_TEXTO_INI;
}

// Actualiza la posicion del cursor
void ActualizaPosCursor()
{
	// Borramos la X y la Y 
	Sprites[0].attribute0 = Sprites[0].attribute0 & 0xFF00;
	Sprites[0].attribute1 = Sprites[0].attribute1 & 0xFE00;
	
	// Ponemos la nueva X y la nueva Y
	Sprites[0].attribute0 = Sprites[0].attribute0 | PosCursor[PosActualCursor].y;
	Sprites[0].attribute1 = Sprites[0].attribute1 | PosCursor[PosActualCursor].x;	
}

// Comprueba si se pulsa alguna tecla
void CompruebaTeclas()
{		
	u16 bucle, bucle2;
	
	// Si se pulsa hacia la izquierda
	if ((!(*KEYS & KEY_LEFT)) && (PosActualCursor >= 0))
	{
		if (PosActualCursor > 0) PosActualCursor--; // Si no estamos en la "A"
							    // retrocedemos una posicion
        	else if (PosActualCursor == 0) PosActualCursor = 27; // Si estamos en la "A"
								     // ponemos en cursor en "LOAD"       	
		ActualizaPosCursor();	// Actualiza la posicion del cursor
		Sleep(9);		// Espera un poco
	}
	
	// Si se pulsa hacia la derecha	
	if ((!(*KEYS & KEY_RIGHT)) && (PosActualCursor <= 27))
        {
        	if (PosActualCursor < 27) PosActualCursor++; // Si no estamos en "LOAD"
        						     // avanzamos una posicion
        	else if (PosActualCursor == 27) PosActualCursor = 0; // Si estamos en "LOAD"
        							     // ponemos el cursor en "A"
        	
        	ActualizaPosCursor();
        	Sleep(9);
        }
        
        // Si se pulsa el boton A
        if (!(*KEYS & KEY_A))
        {
        	// Si el cursor esta encima de alguna letra
        	if ((PosActualCursor >= 0) && (PosActualCursor <= 25) && (N_Letra < MAX_LETRAS))
        	{
        		TextoActual[N_Letra] = ABECEDARIO[PosActualCursor]; // A�adir la letra al texto
        		N_Letra++;		// Incrementar en contador de letras
        		// Colocar un sprite con la letra correspondiente
        		// en la X y en la Y correspondientes
        		Sprites[N_Letra].attribute0 = COLOR_256 | SQUARE | PosLetra.y;
        		Sprites[N_Letra].attribute1 = SIZE_16 | PosLetra.x;
        		Sprites[N_Letra].attribute2 = Letras[PosActualCursor];
        		PosLetra.x += 12;	// Incrementar en 12 pixels la x para la siguiente letra
        		Sleep(10);		// Esperamos un poco
        	}
        	// Si el cursor esta en la posicion del SAVE
        	else if (PosActualCursor == POS_SAVE)
        	{
        		GuardaTexto(TextoActual);	// Guardamos el texto en la SRAM
        	}
        	// Si el cursor esta en la posicion del LOAD
        	else if (PosActualCursor == POS_LOAD)
        	{
        		for (bucle = 1; bucle <= N_Letra; bucle++)
        		{
        			// Sacamos los sprites fuera de la pantalla
        			// (desde 1 porque el 0 es el cursor)
        			Sprites[bucle].attribute0 = 160;	// y = 160
        			Sprites[bucle].attribute1 = 240; 	// x = 240
        		}
        		N_Letra = 0;			// Reseteamos el contador de letras
        		PosLetra.x = POS_X_TEXTO_INI;	// Posicion para la primera letra
        		
        		CargaTexto(TextoActual);	// Cargamos el texto
        		bucle = 0;
        		
        	        // Recorremos todo el texto y comparamos cada letra con todas las del
        	        // abecedario y si coincide la letra actual del texto con la del
        	        // abecedario creamos un sprite con esa letra, asi formamos el texto
        		while (TextoActual[bucle] != 0) {
        			for (bucle2 = 0; bucle2 < N_LETRAS_ABECEDARIO; bucle2++)
        				if (TextoActual[bucle] == ABECEDARIO[bucle2])
        				{
        					N_Letra++;
        					Sprites[N_Letra].attribute0 = COLOR_256 | SQUARE | PosLetra.y;
        					Sprites[N_Letra].attribute1 = SIZE_16 | PosLetra.x;
        					Sprites[N_Letra].attribute2 = Letras[bucle2];
        					PosLetra.x += 12;
        				}
        			bucle++;
        		}        		
        	}
        }
        
        // Si se pulsa el boton B y hay letras que borrar
        if (!(*KEYS & KEY_B) && N_Letra > 0)
        {
        	// Sacamos el sprite con la ultima letra fuera de pantalla
        	Sprites[N_Letra].attribute0 = 240; 
        	Sprites[N_Letra].attribute1 = 160;
        	N_Letra--;		// Quitamos una letra del contador
        	PosLetra.x -= 12;	// Actualizamos la posicion para la siguiente letra
        	Sleep(9);		// Esperamos un poco
        }
	
}
	

// Espera a que acabe de pintar la pantalla
void WaitForVSync()
{
	while ((volatile u16)REG_VCOUNT != 160) {}
}

// Copia los datos de los sprites a la oam de la gba
void CopiaOAM()
{
	u16 bucle;
	u16 *temp;
	
	temp = (u16 *)Sprites;
	
	// 128 es el maximo de sprites, se multiplica por 4 porque  son 4 atributos u16
	for (bucle = 0; bucle < 128 * 4; bucle++)
		OAMmem[bucle] = temp[bucle];
}	

// Funcion principal
int main()
{
 	u16 x, y, bucle;
	
	// Establecer el modo (Modo 4, fondo 2, sprites activados, 1d)
 	SetMode(MODE_4 | BG2_ENABLE | OBJ_ENABLE | OBJ_MAP_1D);
 
 	// Cargar la paleta del fondo (256 colores)
 	for (bucle = 0; bucle < 256; bucle++)
		theScreenPalette[bucle] = Paleta[bucle];
 
	 // Cargar el fondo
	 for (x = 0; x < 120; x++)
		for (y = 0; y < 160; y++)
			PlotPixel(x, y, 120, FONDOData[y * 120 + x]);
 	
 	InicializaSprites();		// Sacar los sprites fuera de la pantalla
 	InicializaPosCursor();		// Inicializar las posiciones del cursor
 	InicializaLetras();		// Inicializar el array con las direcciones de las letras
 	
 	// Cargar la paleta de los sprites (256 colores)
 	for (bucle = 0; bucle < 256; bucle++)
 		OBJPaletteMem[bucle] = Paleta[bucle];

 	// Datos del cursor 
 	Sprites[0].attribute0 = COLOR_256 | SQUARE | PosCursor[PosActualCursor].y;
 	Sprites[0].attribute1 = SIZE_16 | PosCursor[PosActualCursor].x;
 	Sprites[0].attribute2 = 512;
 	
 	// Cargar el cursor 16x16 = 256 -> 256/2 = 128
 	// Se divide por 2 porque la gba escribe 2 pixels a la vez
 	// En modo 4 se empieza a escribir en la posicion 0x2000 de la OAMdata
 	for (bucle = 0; bucle < 128; bucle++)
 		OAMdata[bucle + 0x2000] = CURSORData[bucle];
 	
 	// Cargar el sprite con todas las letras
 	// Desde 128 porque los primeros 128 bytes estan ocupados por el cursor
 	for (bucle = 128; bucle < 3328 + 128; bucle++)
 		OAMdata[bucle + 0x2000] = LETRASData[bucle - 128];
 
 	
 	
 	// Bucle principal
 	while (1)
 	{
		CompruebaTeclas();	// Comprueba si se pulsa una tecla
		WaitForVSync();		// Espera a que acabe de pintar la pantalla
		CopiaOAM();		// Copia los datos a la oam
 	}
}


