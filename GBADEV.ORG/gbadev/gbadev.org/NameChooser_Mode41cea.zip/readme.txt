NAME CHOOSER EXAMPLE BY MANULON

Well, it's only an example of a name chooser in the gba like the rpg ones.
Name can be saved and loaded.

It's written in C and compiled with devkitadvance.

cabronelquelolea@hotmail.com