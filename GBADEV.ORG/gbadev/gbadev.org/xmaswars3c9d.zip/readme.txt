xmas wars v0.1
==============

(c)Jon Huggins, December 2002

happy chrimbo to all the GBA dev dudes

heres a little toy i came up with while working
on some collision detection code for my current
project!

controls:
up / down - move your dude
A - throw a snowball!

don't forget...
www   : http://zap.to/gbaproject
email : gbaproject@hud.ac.uk
