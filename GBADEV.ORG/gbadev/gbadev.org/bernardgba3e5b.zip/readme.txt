-------
Bernard
-------

File:		bernard.mb
Date:		26 - 12 -2003
Program:	platformer (demo)
Author:		Johan Jansen (Jenswa)
Contact:	awsnej@hotmail.com
Site:		http://www.gouwevrouwe.nl/gba
		

-----------------------------
About this bin-file:

It's one of my first attempts to create a platformer on the GBA.
I used the graphics from the pc version of Bernard & Hank.
You play with the character Bernard, he can shoot, jump and walk a little on the map.
It was the start of a GBA version from our platformer.
But I couldn't get the character picking up coins without error.

I didn't include the source code.
Because I don't want the graphics ending up somewhere on the net.
However, source code is available upon request.


---------------
Features:

Three scrolling maps.
Some coins to pick up (doesn't work).
A main character called Bernard.
Nice graphics done by Hayo van Reek.
There is a counter to keep track of the number of scrolled pixels.
Black&White mode by palette swap.


---------------
Controlls:

KEY LEFT - walk left
KEY RIGHT - walk right
KEY A - Shoot a bullet
KEY B - Jump
KEY L - Black&White mode


------------------
Debugging:

This file is tested with VisualBoyAdvance and runs fine.
The multiboot image has been sent to my gba and works correct.


----------------
Thanks to:

Forgotten (VisualBoyAdvance)
Jason Wilkins (Dev-Kit Advance)
Eloist (gba.h)
gbajunkie (his great tutorials really helped me)
Dovoto (pcx2sprite, pcx2gba, dma)
Nokturn (keypad.h)
Warder1 (map editor)
Lord Graga (his platform tutorial helped me a lot)
GBADEV.org (their forum is great)


---------
Links:

http://www.gbadev.org
http://www.devrs.com/gba
http://www.gbaemu.com/
http://www.gbajunkie.co.uk
http://www.thepernproject.com
http://www.gamedev.net
http://www.cs.rit.edu/~tjh8300/CowBite/CowBiteSpec.htm (CowBite Virtual Harware Spec)
http://www.work.de/nocash/gbatek.htm - gbatek html version (GBATEK)
http://www.vboy.emuhq.com/ (VisualBoyAdvance)

----------------
Jenswa


-----------------
Disclaimer:
This game is freeware. This software is provided 'as is' with no warranty or guarantees of
any kind, you use this software at your own risk. You accept all responsibility for any 
damage caused as a result of using this software. The author is not liable for any costs 
incurred as a result of using this software.

