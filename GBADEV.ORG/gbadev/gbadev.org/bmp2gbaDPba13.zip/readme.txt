Game Boy Advance Developer's tools

BMP2GBA
By Daniel Papenburg, December 2001

Bmp2gba is a program that will extract a palette and tileset
from a 256 color windows bitmap file and dump the arrays into
a c/c++ header file. Header files, in some cases, are much easier
to include in the project and easier to deal with than 
binaries. The input bitmap must be in 256 color format, and the 
dimensions must be 128x128. This is a result of the gba's tiles 
being 8x8 pixels, thus 256 gba tiles would amount to a square of 
128x128 pixels. You can use any program to edit and save the file,
as long as it is in this format. You should play around with the 
program to become familiar with how it spits out data. If the 
program can not process the data correctly due to wrong formatting,
it will alert you. The tiles are to be arranged like this:

 0   1   2   3   4   5   6   7   8   9 .....................
16  17  18  19  20  21  22  23  24  25......................
............................................................
................................................... 254  255

(That's a rough sketch. I hope you get the idea.)
The program will output a linear array of tiles, arranged in block 
format for easy reading, along with a palette. You can rename the arrays
and include files as you feel necessary. You can also use different 
palettes with different pictures. How you use the data is up to you. 
This will just extract it for you. The default names are Palette[] 
and Bitmap[].


NOTE: The output header file, if it already exists, will always be 
      overwritten, not appended. 


====================================================================
Specs:
-------------------------
Name: Bmp2gba
Author: Daniel Papenburg
Language: 32-bit Assembly
OS: Windows 9x and above
Date: Dec. 2001
Performance: 
             The program can do a dump in about 0.3 seconds
             on my 500MHz celeron. No advanced optimization
             has been done, and this is most likely the final
             version.
