Puzzle by Daniel Fowler (daniel@fowlers.net / http://daniel.fowlers.net)

This is a classic 15-Puzzle where fifteen blocks are pushed around 
till they are in order or an image is made.  This program is 
capable of randomly jumbling and solving the puzzle.  There are 
also two modes; one in witch the blocks are numbered one through 
fifteen, and another where the blocks make up the image of a 
mantis.  The program can also tell when you have completed the 
game and will notify you.

If you show this to people, please make mention me and my site.
Also feel free to offer any feedback.

Controls:
D-pad    - Controls the sliding of the blocks.
A button - Menu selection.
B button - Menu cancellation.
Start    - Menu.
R	 - Switch to image.
L	 - Switch to numbered blocks.

Simple but fun, enjoy yourself.
