Naturette Advance

(c)2004 by Robin Gravel

GBAGI by Brian Provinciano


The original game was made with AGI studio. This game was modified and
compiled with GBAGI to play with Gameboy Advance or with an emulator.


THE STORY:

Naturette needs to find eigh diamonds to get back to her world.


START A GAME:

Once the game is loaded you see the menu. Select Naturette (English)
and press on A Button to play. Select Naturette (Francais) if you wish
to play Naturette in French.

Press A to remove texts. Press A again to leave the title screen.


THE MAIN GAME:

Use control pad to move Naturette.
Press A to bring the command control.
Press B to bring the menu.


THE COMMAND CONTROL:

By default, you'll see any commands used in one room only.

Use the control pad up and down to choose a command and press A to
select. Press B to erase a preview command.

Press R to change a new set of command. Press L to go back to the
preview set of command.

Choose 'MORE' if you wish to see any commands used in the game.
Choose 'LESS' if you wish to see any command used in one room.
Choose 'OK' to valid the command you have made.
Choose 'CANCEL' to go back in the game without using any commands.


To make Naturette to take a book, Select TAKE and press A. You might
need to use another column of words by pressing R. Select BOOK word.

Press R until you select OK and press A button or just press START to
valid any commands faster. Naturette should take the book.


THE MENU:

To access to the menu, press B button in the game.

Choose 'SAVE' if you wish to save your game.
Choose 'RESTORE' if you wish to play a saved game.
Choose 'RESTART' if you wish to play from scratch.
Choose 'INVENTORY' if you wish to see any objects you have found.


You may also adjust speed game if the game is too fast or too slow.

Don't worry about french texts you'll see in the game. They are
written in the backgrounds and don't need them to complete the game.


HOW DO I PUT NATURETTE ADVANCE INTO GAMEBOY ADVANCE?

Consult some links bellow to know how to play Naturette on Gameboy.

GBAGI home:
http://www.bripro.com/gbagi/index.php

Gameboy Advance development:
http://www.gbadev.org/

Virtualboy Advance:
http://vba.ngemu.com/

DID NATURETTE HAVE TESTED ON THE REAL GAMEBOY ADVANCE BEFORE RELEASING
ON THE PUBLIC?

No. I don't have any equipments to load Naturette into the gameboy
cartrige. The game was tested with success on the emulator Virtualboy.


I AM STUCK IN THE GAME?

Please post your question in my messageboard. I'll help you.


Robin Gravel

Le Spaceweb:
http://www.chez.com/robingravel/

Jeux de r�les/Jeux d'aventures:
http://membres.lycos.fr/agisite/agisite.htm

Messageboard:
http://pub10.ezboard.com/brobingravel


February 7th 2004

- First release

