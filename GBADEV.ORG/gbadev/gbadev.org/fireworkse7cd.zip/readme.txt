fw.gba  Fireworks demo by AndyW. January 14 2002
Tested in Igba and Mappy08b
My first demo. Just shoots some fireworks which explode one after another and slowly (on my ancient PC) extinguish.