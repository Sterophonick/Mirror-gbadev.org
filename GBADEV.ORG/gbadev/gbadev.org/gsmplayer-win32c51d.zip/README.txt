_____________________________________________________________________

=== About ===

GSM RPE-LTP (Global Services Mobile Regular Pulse Excitation Long
Term Predictor) is an audio codec initially designed for digital
telephony.  Because it's less complex to decode than, say, MP3,
a low-power microprocessor can decode it in real time.

GSM Player is an application (some would say "abuse") of the
GSM RPE-LTP codec to music. The codec was originally intended
to transmit a monophonic human voice in 8000 Hz, but because
it was designed to be robust in the face of background noise,
it performs well on polyphonic popular music at 18157 Hz,
a "nice" playback rate for the Game Boy Advance hardware.

If you already have a GBA and a rewritable flash cartridge, you
won't need to carry a solid-state MP3 player with you when you go
jogging.  A 256 Mbit flash cart holds up to 150 minutes of music.


=== How to build a ROM ===

To build a GBA ROM containing several recordings, just drop some .wav
files in the "wavs" folder and then run Go.bat.  (Windows 95, 98, and
ME users should run Go-win9x.bat instead.)  This should produce a ROM
called gsm.gba, which you can write to a GBA flash cartridge.

You can get .wav files by extracting digital audio from your music
CDs or by running the Revolux ripper on a Dance Dance Revolution disc
for the PlayStation game console.  If you just have a bunch of MP3
files that you copyright-infringed off a file sharing network, you
can use Winamp's "Disk Writer" output plug-in to convert them to
.wav files.


=== How to work the player ===

Left: previous track
Right: next track
L: seek left
R: seek right
Select: lock/unlock controls
Start: pause/resume playback
A+B+Select+Start: reset GBA, such as to exit to your loader menu
  (works only on Visoly and F2A carts)


=== Legal information ===

Copyright 2004 Damian Yerrick and his licensors.  These programs are
provided with ABSOLUTELY NO WARRANTY.

Copyright license statements covering parts of this distribution can
be found in the following files:

  * TOAST-COPYRIGHT.txt  # Permissive license of GSM RPE-LTP decoder
  * COPYING              # GNU General Public License
  * COPYING.LIB          # GNU Lesser General Public License
  * COPYING.DJ           # DJGPP license, based on GNU LGPL

If the person who sent you this file did not include the licenses,
that person is BREAKING THE LAW, and you should turn the dirty pirate
in to the FBI.

This distribution includes one or more programs distributed under a
copyright license that requires distribution of source code alongside
binaries (collectively "Copylefted Tools").  If you distribute the
Copylefted Tools in binary form, you must also distribute the source
code for all Copylefted Tools according to their respective licenses.
The source code for all Copylefted Tools in this distribution can be
found in the source code distributions for the following packages:

  * Pin Eight GSM Player (http://www.pineight.com/gba/gsm/)
  * SoX (http://sox.sourceforge.net/)

If the person who sent you this file did not either send you source
code for the Copylefted Tools nor make an offer to send you such
source code, that person is BREAKING THE LAW, and you should turn
the dirty pirate in to the FBI.

