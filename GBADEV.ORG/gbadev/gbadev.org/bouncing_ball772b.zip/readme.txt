-------------------------
Bouncing Ball
-------------------------

File:		ball.bin
Program:		Moving a coloured ghost sprite
DemoNr:		02
Author:		Johan Jansen (Jenswa)
Contact:		awsnej@hotmail.com
Site:		http://www.geocities.com/flashsite_jrj/hooghaar (not about gba)

-----------------------------
About this bin-file:

This is my second working bin file (yeah!)

It is created with a gcc compiler, DevKitAdvance, nice compiler guys.
Coded with c or c++ (I don't know, since that's new to me).

Source files included.

Tested on VisualBoyAdvance, works fine, now I need to get a flash card and
flash it to my gba to see if it works on the real hardware.
-------------------------------------
Features in this bin-file:

Display a 8x8 sprite and moving a sprite
without pressing buttons.
----------------
Thanks to:

Forgotten (VisualBoyAdvance)
Jason Wilkins (Dev-Kit Advance)
Eloist (gba.h)
GBAjunkie (tutorial, dovoto, dispcnt.h, sprite_info.h)
Dovoto (pcx2sprite, dispcnt.h, sprite_info.h) 
Noktrun (keypad.h)
GBADEV.org

------------
Jenswa