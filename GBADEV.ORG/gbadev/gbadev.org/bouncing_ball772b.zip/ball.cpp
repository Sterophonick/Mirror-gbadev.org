///////////////////////////////////
//ball.cpp
//Bouncing ball demo
//by Jenswa
// First of August 2002
///////////////////////////////////

#include "gba.h" //GBA register definitions
#include "dispcnt.h" //REG_DISPCNT register #defines
#include "sprite_info.h" //gbajunkies generic sprite header file
#include "palette.h"	 //sprite palette
#include "ball.h" //ball sprite

//create an OAM variable and make it point to the address of OAM
u16* OAM = (u16*)0x7000000;

//create the array of sprites (128 is the maximum)
OAMEntry sprites[128];

//declare variables

s16 BallX = 120;	//ball position x
s16 BallY = 80;	//and y

s8  BallSX = 2;	//variable containing value '2'
s8  BallSY = 2;	//variable containing value '2'

//Copy sprite array to OAM
void CopyOAM()
{
	u16 loop;
	u16* temp;
	temp = (u16*)sprites;
	for(loop=0; loop < 128*4; loop++)
	{
		OAM[loop] = temp[loop];
	}
}

//sprite move function (from gbajunkie)
void MoveSprite(OAMEntry* sp, int x, int y)
{
	if(x < 0)			//if it is off the left correct
		x = 512 + x;
	if(y < 0)			//if off the top correct
		y = 256 + y;

	sp->attribute1 = sp->attribute1 & 0xFE00;  //clear the old x value
	sp->attribute1 = sp->attribute1 | x;

	sp->attribute0 = sp->attribute0 & 0xFF00;  //clear the old y value
	sp->attribute0 = sp->attribute0 | y;
}

//move the ball (modified from Nokturn's pong tutorial)
void MoveBall()
{
	 BallX+= BallSX;
	 BallY+= BallSY;

	 if( BallY >= 152 ) BallSY = -2;
	 if( BallY <= 0 )   BallSY = 2;

	 if( BallX >= 232 ) BallSX = -2;
	 if( BallX <= 0 )   BallSX = 2;
}

// Set sprites off screen
void InitializeSprites()
{
	u16 loop;
	for (loop = 0; loop < 128; loop++)
	{
		sprites[loop].attribute0 = 160;	//y > 159
		sprites[loop].attribute1 = 240;	//x > 239
	}
}

//wait for the screen to stop drawing
void WaitForVsync()
{
	while((volatile u16)REG_VCOUNT != 160){}
}

int main()
{
	u16 loop;	//generic loop variable


	SetMode(MODE_1 | OBJ_ENABLE | OBJ_MAP_1D);	//Set mode 1, enable objects and use 1d mode

	for(loop = 0; loop < 256; loop++)		//load palette into memory
	OBJPaletteMem[loop] = palette[loop];


	InitializeSprites();

	sprites[0].attribute0 = COLOR_256 | SQUARE | BallY;
	sprites[0].attribute1 = SIZE_8 | BallX;
	sprites[0].attribute2 = 0;			//pointer to tile where sprite starts

for(loop = 0; loop < 32; loop++)		//load ball sprite
{
	OAMData[loop] = ballData[loop];
}


	while(1)		//main loop
	{
		MoveSprite(&sprites[0], BallX, BallY);		//move the ball
		MoveBall();		//also for moving the ball
		WaitForVsync();		//waits for the screen to stop drawing
		CopyOAM();		//copies sprite array into memory
	}
}
