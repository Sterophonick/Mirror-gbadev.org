AirWingAssault.bin

This is Edmund Wong's second demo!
It's an overhead shooter.
Use the arrow keys to move around.
Other buttons are for shooting,bombing, rolling, and shield charging.
Hope you guys like it!
This demo is not for profit or commercial use.
It is just to demonstrate my programming skills.
Graphics and sounds are taken from various sources.

E-Mail me feedback at: ginsingtome@hotmail.com

Thanks!
Edmund Wong