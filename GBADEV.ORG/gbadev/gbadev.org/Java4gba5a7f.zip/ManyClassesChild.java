public class ManyClassesChild extends ManyClassesParent {

	public void method() {
		System.out.println("Child Method");
	}

}
