public class Exceptions {

	public static void stupidCrash() {
		int [] a = new int[2];
		System.out.println(a[3]);
	}

	public static void lessStupidCrash() throws Exception {
		try {
			stupidCrash();
		} catch(Exception ex) {
			ex.printStackTrace();
			throw new Exception("lessStupid");
		}
	}
	
	public static void main(String [] args) {
		System.out.println("Exceptions example");

		try {
			System.out.println("\nCalling stupidCrash");
			Exceptions.stupidCrash();
			System.out.println("I will never been reached");
		} catch (Exception ex) {
			ex.printStackTrace();
		}

		try {
			System.out.println("\nCalling lessStupidCrash");
			Exceptions.lessStupidCrash();
			System.out.println("I will never been reached");
		} catch (Exception ex) {
			ex.printStackTrace();
		}
		
	}
	
}
