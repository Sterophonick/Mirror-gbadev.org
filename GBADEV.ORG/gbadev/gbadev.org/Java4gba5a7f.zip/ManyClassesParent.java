public class ManyClassesParent {

	public void method() {
		System.out.println("Parent Method");
	}

}
