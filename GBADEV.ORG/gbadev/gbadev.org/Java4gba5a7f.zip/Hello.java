public class Hello {

	public static void main(String [] args) {
		System.out.println("Java Virtual Machine for GBA");
		System.out.println("");
		System.out.println("Hello Java World");
	}
	
}
