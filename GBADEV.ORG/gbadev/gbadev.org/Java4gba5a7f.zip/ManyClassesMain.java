public class ManyClassesMain {

	public static void main(String [] args) {

		System.out.println("Many Classes example");
		
		ManyClassesParent parent = new ManyClassesParent();
		ManyClassesParent child = new ManyClassesChild();

		parent.method();
		child.method();

		parent = child;

		parent.method();
	}	
}
