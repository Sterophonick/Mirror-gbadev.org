///////////////////////
// swi.h              /
// andrew p. bilyk    /
// july 21, 2003      /
///////////////////////

extern void SWI_SoftReset();
extern void SWI_RegisterRamReset(u32 reset_flags);
extern void SWI_Halt();
extern void SWI_Stop();
extern void SWI_IntrWait(u32 initflagclear, u32 interrrupt);
extern void SWI_VBlankInterWait();
extern u32  SWI_Div(u32 numerator, u32 denominator);
extern u32  SWI_AbsDiv(u32 numerator, u32 denominator); // SWI_Div + mov r0, r3
extern u32  SWI_Mod(u32 numerator, u32 denominator);    // SWI_Div + mov r0, r1
extern u32  SWI_DivArm(u32 denominator, u32 numerator);
extern u32  SWI_AbsDivArm(u32 denominator, u32 numerator); // SWI_DivArm + mov r0, r3
extern u32  SWI_ModArm(u32 denominator, u32 numerator);    // SWI_DivArm + mov r0, r1
extern u32  SWI_Sqrt(u32 number);
extern s16  SWI_ArcTan(s16 tangent);
extern u16  SWI_ArcTan2(s16 x, s16 y);
extern void SWI_CPUSet(void *source, void *destination, u32 length_mode);
extern void SWI_CPUFastSet(void *source, void *destination, u32 length_mode);
extern u32  SWI_GetBiosChecksum();
extern void SWI_BgAffineSet(void *source, void *destination, u32 number);
extern void SWI_ObjAffineSet(void *source, void *destination, u32 number, u32 offset);
extern void SWI_BitUnPack(void *source, void *destination, void *parameters);
extern void SWI_LZ77UnCompWRAM(void *source, void *destination);
extern void SWI_LZ77UnCompVRAM(void *source, void *destination);
extern void SWI_HuffUnComp(void *source, void *destination);
extern void SWI_RLUnCompWRAM(void *source, void *destination);
extern void SWI_RLUnCompVRAM(void *source, void *destination);
extern void SWI_Diff8bitUnFilterWRAM(void *source, void *destination);
extern void SWI_Diff8bitUnFilterVRAM(void *source, void *destination);
extern void SWI_Diff16bitUnFilter(void *source, void *destination);
