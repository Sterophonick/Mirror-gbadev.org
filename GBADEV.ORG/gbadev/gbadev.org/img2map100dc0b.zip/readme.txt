img2map

author: f(Dark Angel)
last update: 21 feb 2004
version: 1.0.0

------------------------------------------------------------

img2map is a simple tool for generating tileset & mapdata
from an image file. this tool uses DevIL image library
for image i/o. for details on supported image formats, see
DevIL docs.

windows systems require devil.dll, which is available in DevIL
project downloads.

img2map is intended to be a tool for remake projects.


usage:
 img2map <imagefile> <tilewidth> <tileheight> [outputimagefile] [outputmapfile] [fX]
 
 first 3 args are required, followings are optional
 last 2 parameters are flip types, and you can to replace X with
 h (horizontal flip)
 v (vertical flip)
 hv or vh (both)


notes:
-there's no multilayer map support
-no image exporting to .C or .H
-no makefile/workspace included
-source files should be in the archive. you need DevIL SDK
to compile your own version
-DevIl project url: http://sf.net/pojects/openil
you can get win32 dlls at http://openil.sourceforge.net/download.php
(referred as "End User Package")
-output files will overwrite the existing files if there is
-default output file names are mapdata.c and tileset.png
-for some image formats (like .png), you'll have to flip the
input image. you can do this with an external editor, or
you can use fh fv parameters for horizontal-vertical
flips
-be careful when choosing different type (extension) for
output image (if you specify). ie, if input.png is a 24-bit
png image, using
 img2map input.png 16 16 output.gif
won't work (issue an error) since gifs are 8-bit-only images.



------------------------------------------------------------
death scream...