+--------------+
|Thrust Advance|
+--------------+

Version History
---------------
V1.04 (02/12/2002)
	Running out of fuel and dying ends the game.
	The reactor flashes when it goes into meltdown.
	Added a pause mode using the "Select" key.
	Added an "enter" character to the highscore entry.
	During highscore entry the "Up" and "Down" keys repeat after a short delay.
	Added a prompt to enter your name on the highscore screen.
V1.03 (18/11/2002)
	Removed BIOS calls.
V1.02 (15/11/2002)
	Fixed a minor door bug.
	Fixed bug with losing lives at when the reactor blows.
	Lowered the fireing rate increase when the reactor is destroyed.
	Fixed a rogue limpet gun on map 6.
	Centered the lives, text and number, on the OSD.
	Removed DMA (except sound).
V1.01 (5/11/2002)
	Changed the title screen
V1.00 (5/11/2002)
	Inital release

Author
------
Matthew R. Partridge (MatthewRPartridge@hotmail.com)

Controls
--------
 Left           - Rotate anti-clockwise
 Right          - Rotate clockwise
 A              - Fire
 B              - Thrust
 Right shoulder - Shield / Tractor beam

Notes
-----
This is an unofficial conversion that is not endorsed.

This version now works on hardware as well as emulators as below.
    VisualBoyAdvance - Works fine.
    BoycottAdvance   - Has dodgy sound.
    Mappy            - Looks OK but goes totally bonkers.

After entering a high score it's saved by writing to CartRAM at 0x0E000000 this
might possibly cause problems on hardware but does work on VisualBoyAdvance.

Differences to Thrust (C64)
---------------------------
The door opens the wrong way on level 5.
The teleport effect is missing.
There should be 2 types of fuel pod, there is only one.
There are no collisions between the ship or orb and static objects.
The particles for players bullets, limpet bullets and debris are all the same colour.
The sprites are 2/3 the size that they should be, in comparison to the landscape.
The orb stand remains after the orb has been picked up.

Thanks
------
Thanks to Jeremy C. Smith for the original Thrust.
Thanks to the entire GBA Dev community for info and tools.
www.gbadev.org and www.devrs.com/gba/
Thanks to the Yahoo! group gbadev.
Thanks to everyone who has e-mailed me with helpful comments.
Extra special thanks go to Chris Naylor for helping me to get it working on a real GBA.

Tools/Docs Used
---------------
Devkit advance
VisualBoyAdvance
Gfx2GBA
b2x
Mappy for Win32, V1.3.14 (tile editor)
Cowbite spec
Jeff Frohwein's crt0.s and lnkscript.
Jaap Suter's on screen assert routine.

Disclaimer
----------
This game is freeware. This software is provided 'as is' with no warranty or guarantees of
any kind, you use this software at your own risk. You accept all responsibility for any 
damage or injury caused as a result of using this software. The author is not liable for 
any costs incurred as a result of using this software.
