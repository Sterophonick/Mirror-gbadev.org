Puzzle Dungeon Advance README
-----------------------------

For up-to-date information, or if you run into problems and need help, 
visit www.puzzledungeon.com.

-----------------------------

Game Controls:

D-Pad - move, push blocks
A - use item
B - undo last move
Start - pause

------------------------------

How to play:

The goal of each level is to cover the goal spaces with blocks of the
same color.  Blocks will be different shapes in each area (example, they
are acorns in the forest).

As levels are beaten, new adjacent levels will be unlocked on the world map. 

------------------------------

Special Note For Running on Real Hardware:

Puzzle Dungeon has game saving functionality.  If you want to support game saving
you must have a flashcartridge with SRAM availible.  We have used the EZ Flash Advance,
and set the SRAM size to 256kbits.  256kbits is the recommeded size if your cart gives
you an option.