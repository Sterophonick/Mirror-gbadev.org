  __                           _
 / _| _ _  ___   ___  _ _ __  (_) _ _  _ _   ___   _ _
| |_ | '_|/ _ \ / _ \| ' `  \ | || '_|| '_| / _ \ | '_|
|  _|| | |  __/|  __/| || || || || |  | |  | (_) || |
|_|  |_|  \___| \___||_||_||_||_||_|  |_|   \___/ |_|

freemirror release 20020119
by Damian Yerrick <d_yerrick@hotmail.com>

freemirror displays an image of up to 256 colors on a Game Boy
Advance system.  You can use this to test mock-ups of your screen
layout to make sure that they work well with the size and gamma
properties of the GBA display hardware.  Then it turns the display
black so that you can use its scratch shield as a makeshift mirror.


Feature comparison              freemirror      Mirror v1.0
                                                By Jylam
Runs on GBA as cartridge        yes             yes
Runs on GBA as multiboot        yes             no
Unzipped size of final binary   24 KB           86 KB
Free software                   yes             no
User can replace intro screen   yes             not easily


Programming techniques demonstrated

 * Reading from joypad
 * PackBits run-length encoding and decoding
   (see http://developer.apple.com/technotes/tn/tn1023.html)
 * Spinning on LCD_Y to wait for vertical blank


Build instructions

You will need DevKit Advance and one of DJGPP or MinGW.
To compile the included bitmap-to-raw-data converter, you must
also install the Allegro library into your DJGPP or MinGW tree.

DJGPP:          http://www.delorie.com/djgpp/
MinGW:          http://www.mingw.org/
Allegro:        http://alleg.sourceforge.net/
DevKit Advance: http://www.io.com/~fenix/devkitadv/

1. Set your PATH to include DJGPP or MinGW.
2. cd tools
3. make
4. cd ..
5. Add DevKit Advance to the front of your PATH.
6. make

The process should also work with Linux, but Linux will need
slight changes to the makefiles.


Using the software

You can load this software into Game Boy Advance as a cartridge
or as a multiboot image.  If loaded as a cartridge, it will copy
itself to EWRAM (where multiboot programs live).  (Because
freemirror is much too small to fill a cartridge, you'll probably
want to find or write a shell app that can display a menu of
multiboot images and copy the correct one into RAM.)  The included
binary does not include the Nintendo logo diagnostic data; your
header tool or transfer utility should handle that for you.


  ______
 /  ___ \
|  / __) |
| | (__  |
|  \___) |
 \______/

Copyright 2002 Damian Yerrick

Permission is hereby granted, free of charge, to any person obtaining
a copy of this software and associated documentation files (the
"Software"), to deal in the Software without restriction, including
without limitation the rights to use, copy, modify, merge, publish,
distribute, sublicense, and/or sell copies of the Software, and to
permit persons to whom the Software is furnished to do so, subject to
the following conditions:

The above copyright notice and this permission notice shall be
included in all copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND,
EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES
OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND
NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS
BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN
AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF
OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS
IN THE SOFTWARE.

Nintendo and Game Boy Advance are trademarks of Nintendo.
