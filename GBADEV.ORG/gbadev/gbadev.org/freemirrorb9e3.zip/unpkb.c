/*

unpkb.c
bitmap unpacking code for Game Boy Advance
by Damian Yerrick

Copyright 2002 Damian Yerrick

Permission is hereby granted, free of charge, to any person obtaining
a copy of this software and associated documentation files (the
"Software"), to deal in the Software without restriction, including
without limitation the rights to use, copy, modify, merge, publish,
distribute, sublicense, and/or sell copies of the Software, and to
permit persons to whom the Software is furnished to do so, subject to
the following conditions:

The above copyright notice and this permission notice shall be
included in all copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND,
EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES
OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND
NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS
BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN
AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF
OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS
IN THE SOFTWARE.

 */


#define MULTIBOOT volatile const int __gba_multiboot;
MULTIBOOT

#include "pin8gba.h"
#include <stdlib.h>

const u32 dummy;  /* force aligned data */

#include "chr.h"



/* cpu_memcpy() ************************
   Copy a region of memory to VRAM or any other area of memory.
*/
void cpu_memcpy(void *in_dest, const void *in_source, size_t len)
{
  unsigned short *dst = in_dest;
  const unsigned short *src = in_source;

  len >>= 1;  /* bytes to shorts */
  if(len == 0)
    return;

  /* handle less than eight words */
  {
    size_t short_overage = len & 0x07;
    if(short_overage)
      do {
	*dst++ = *src++;
      } while(--short_overage);
  }

  len >>= 3;  /* shorts to 16-bytes */
  if(len == 0)
    return;

  /* unroll loop */
  do {
    *dst++ = *src++;
    *dst++ = *src++;
    *dst++ = *src++;
    *dst++ = *src++;
    *dst++ = *src++;
    *dst++ = *src++;
    *dst++ = *src++;
    *dst++ = *src++;
  } while(--len);
}


void paldump4(int idx)
{
  int x, y, xp, yp;

  for(y = 0; y < 16; y++)
    {
      int ycontr = (y << 12) | (y << 4);

      for(yp = 0; yp < 10; yp++)
	{
	  for(x = 0; x < 16; x++)
	    {
	      int by = (x << 8) | x | ycontr;

	      for(xp = 0; xp < 5; xp++)
		VRAM[idx++] = by;
	    }
	  idx += 40;
	}
    }
}



/* unpack a packbits buffer to memory */
void vrunpack(unsigned short *dst, const unsigned char *src)
{
  unsigned int len;

  /* for 16-bit output */
  unsigned int lowbyte = 0;     /* low byte of a word */
  unsigned int inhighbyte = 0;  /* toggle a 16-bit byte */

  len = (unsigned int)(*src++) << 8;
  len |= *src++;

  while(len)
  {
    unsigned int runlen = *src++;

    if(runlen == 0x80)        /* 128: do nothing */
    {
      /* do nothing */
    }
    else if(runlen < 0x80)    /* 0-127: literal of n+1 */
    {
      runlen = 1 + runlen;
      while(len > 0 && runlen > 0)
      {
        if(inhighbyte)
        {
          *dst++ = lowbyte | (unsigned int)(*src++) << 8;
          inhighbyte = 0;
        }
        else
        {
          lowbyte = *src++;
          inhighbyte = 1;
        }
        len--;
        runlen--;
      }
    }
    else                      /* 129-255: run of 257-n */
    {
      unsigned int runbyte = *src++;
      unsigned int runbytehi = runbyte << 8;

      runlen = 257 - runlen;

      while(len > 0 && runlen > 0)
      {
        if(inhighbyte)
        {
          *dst++ = lowbyte | runbytehi;
          inhighbyte = 0;
        }
        else
        {
          lowbyte = runbyte;
          inhighbyte = 1;
        }
        len--;
        runlen--;
      }
    }
  }
}


int main(void)
{
  int i;

  LCDMODE = 4 | LCDMODE_BLANK;

  cpu_memcpy(PALRAM, gbarle_pal, gbarle_pal_len);

  vrunpack(VRAM, gbarle_pkb);

  LCDMODE = 4 | LCDMODE_BG2;

  while(JOY & JOY_START);  /* wait for start release */
  while(!(JOY & JOY_START));  /* wait for start press */
  while(LCD_Y != 160);  /* wait for vblank */

  /* blacken screen */
  for(i = 0; i < 256; i++)
  {
    PALRAM[i] = 0;
  }

  while(1);
}
