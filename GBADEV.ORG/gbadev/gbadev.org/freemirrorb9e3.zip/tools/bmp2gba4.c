#include <stdio.h>
#define USE_CONSOLE
#include <allegro.h>
#ifndef ALLEGRO_CONSOLE_OK
#error This platform does not support compiling Allegro console applications.
#endif

int main(int argc, char **argv)
{
  PALETTE pal = {{0}};
  BITMAP *bmp;
  FILE *fp;
  unsigned int x, y;

  install_allegro(SYSTEM_NONE, &errno, atexit);
  set_color_depth(8);

  bmp = load_bitmap(argv[1], pal);
  if(!bmp)
  {
    fputs("Could not load ", stderr);
    perror("gbarle.bmp");
    return 1;
  }

  fp = fopen("gbarle.out", "wb");

  if(!fp)
  {
    destroy_bitmap(bmp);
    fputs("Could not open ", stderr);
    perror("gbarle.out");
    return 1;
  }

  for(y = 0; y < bmp->h; y++)
    for(x = 0; x < bmp->w; x++)
      fputc(getpixel(bmp, x, y), fp);

  fclose(fp);
  destroy_bitmap(bmp);

  fp = fopen("gbarle.pal", "wb");
  if(!fp)
  {
    destroy_bitmap(bmp);
    fputs("Could not open ", stderr);
    perror("gbarle.pal");
    return 1;
  }

  for(y = 0; y < 256; y++)
  {
    unsigned int i = 0;
    i |= (pal[y].r >> 1) & 0x1f;
    i |= ((pal[y].g >> 1) & 0x1f) << 5;
    i |= ((pal[y].b >> 1) & 0x1f) << 10;
    fputc(i & 0xff, fp);
    fputc((i >> 8) & 0xff, fp);
  }
  fclose(fp);

  return 0;
} END_OF_MAIN();
