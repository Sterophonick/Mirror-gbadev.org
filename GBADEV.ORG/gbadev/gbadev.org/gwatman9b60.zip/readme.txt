
Classic Spectrum game remaked
Original game by Jon Ritman & Bernie Drummond
Remake version by Kak, The GGG & Russell Hoy

Controls: redefinible. see the game.
Contact: see the readme.


