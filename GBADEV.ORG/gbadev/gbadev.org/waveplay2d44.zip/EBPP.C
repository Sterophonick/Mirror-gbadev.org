// Evil Bob's Pocket Painter 0.4
// By: The Black Frog (TheBlackFrog.8m.com)
// see 'readme.txt' for more info

#define START_OF_DELAY 20
#define TIME_TO_WAIT 120

#include "gba.h"        // eloist's GBA header with many defines
#include "keypad.h"     // dovoto's keypad defines
#include "screenmode.h" // dovoto's screen mode defines
#include "sprite.h"     // dovoto's sprite defines

#define RGB(r,g,b) ((r)+((g)<<5)+((b)<<10))  // macro to convert 3 values [R, G, B] into a single 16 bit int that is used in mode 3, Each Red, Green and Blue is from 0-31 which gives up 32*32*32 or 32, 768 possible colors

#include <math.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>

#include "BFtext.h" // my text routines

#include "M4GFX.h" // Mode 4 Graphics

#include "time.h"

#include "coloredit.h" // EditColor(); screen made with bimbo
#include "filemenu.h"
#include "objects.h"   // Sprites include file created with dovoto's pcx2sprite and my fixh program. 

u8 tenslider[41], oneslider[41], pen=0, linelength=0; // tenslider stores whats in the tens postition of the numbers 0-41, oneslider stores the ones. its used so i know what digit to dislay in the box next to the Red, Green and Blue sliders.

u16 picpal[256], RGBcolorA, RGBcolorB, RGBcolorBG, RGBcolor;
u8  colorA=1, colorB=2, colorBG=0, color=0, oldcolor;
u8  picdata[240*160];

u16* BMPOBJData =(u16*)0x6014000; // a pointer to halfway point in charecter memory [cause bitmap modes take up the first half so you only have half the amount of character memory in bitmap modes

u8* SRAM =(u8*)0x0E000000;

u16  getkey(void);
void waitkeyup(void);
void ebppMENU(void); // the menu at boot
void FillBG(u16 c2); // Fills the Screen with color c2
void CopyOAM(void); // Copys the info in sprites[] to OAM. in this way you first set all your attributes in sprites[X].attributeY and then copy them, DONT FORGET TO COPY THEM AFTER
void ClearOAM(void); // Clears OAM [object attribute memory] use only at start or all object attributes will be lost
void EditColor(void); // brings up the color editing screen. 
void FileMenu(void);
void WriteSRAM(u16 offset, u8 data);
u8   ReadSRAM8(u16 offset);
u16  ReadSRAM16(u16 offset);
u32  ReadSRAM32(u16 offset);
s16  rint(s16 tempval);

void C_Entry(void) // main entry point defined in boot.asm
{
        u8 ones, tens, delay=START_OF_DELAY, linelength; // xloop is looping variable, x is the current x position of your "pen", y is y position of "pen", yy and xx are temp variables for if you move the pen to the screen edge
	u8 tempo, otempy2, otempx2, otempy, otempx; // i really have to optimze theese goddam variables someday :P
        u16 temp, temp2;
	s16 y=80, x=120, xtemp, xtemp2, ytemp, ytemp2;
//	SetMode(MODE_0 | BG0_ENABLE);
//	REG_BG0CNT = 132;
//	BFinit();
//	ebppMENU();
	SetMode(MODE_4 | BG2_ENABLE | OBJ_ENABLE | OBJ_MAP_1D); // Sets the screen to mode 3 [a 240*160 array of 15-bit colors [5 bits per R,G,B = 0-31 each]], turns on background 2 [the only one accessible in bitmap mode], turns on sprites, sets sprites access mode to 1d 
	
	for(temp=0;temp<256;temp++) // loop for 256 times [0-255]
		OBJPaletteMem[temp] = objectsPalette[temp]; //copys sprite palette into the correct memory location
	for(temp=0;temp<(objects_WIDTH*objects_HEIGHT);temp++) // loop for [8*272] which, if you look at objects.pcx, is the size of all my sprites
		BMPOBJData[temp] = objectsData[temp]; // copy sprites into charecter [sprite] memory
	for(tens=0;tens<4;tens++) // loops thru the tens
		for(ones=0;ones<10;ones++) // loops thru the ones
		{
			tenslider[(tens*10)+ones] = tens; //sets the correct values to use later on in the color editor so that i know what to set the digits next to the sliders to
			oneslider[(tens*10)+ones] = ones; // ^
		}
        WaitForVSync();
        M4PutPalette(RGB(31,0,0), 1);
        M4PutPalette(RGB(31,31,31), 0);
	colorA = 1;
	M4PutPalette(RGB(0,31,0), 2);
	colorB = 2;
	ClearOAM(); // clear OAM

	sprites[0].attribute0 = COLOR_256 | SQUARE | 79; // sets up the pen
	sprites[0].attribute1 = SIZE_8 | 119; 
	sprites[0].attribute2 = 512; // makes it the pencil

	sprites[1].attribute0 = COLOR_256 | TALL | 9; // red slider 
	sprites[1].attribute1 = SIZE_8 | 240; // sets it to 140 [offscreen] because we dont start in color editor
	sprites[1].attribute2 = 514; // makes it the black slider
	
	sprites[2].attribute0 = COLOR_256 | TALL | 24; // green Slider 
	sprites[2].attribute1 = SIZE_8 | 240; // sets it to 140 [offscreen] because we dont start in color editor
	sprites[2].attribute2 = 514; // makes it the black slider

	sprites[3].attribute0 = COLOR_256 | TALL | 39; // Blue Slider
	sprites[3].attribute1 = SIZE_8 | 240; // sets it to 140 [offscreen] because we dont start in color editor
	sprites[3].attribute2 = 514; // makes it the black slider

	sprites[4].attribute0 = COLOR_256 | TALL | 10; // Red 1st digit
	sprites[4].attribute1 = SIZE_8 | 240; // sets it to 140 [offscreen] because we dont start in color editor
	sprites[4].attribute2 = 522; // 0
	sprites[5].attribute0 = COLOR_256 | TALL | 10; // Red 2nd digit
	sprites[5].attribute1 = SIZE_8 | 240; // sets it to 140 [offscreen] because we dont start in color editor
	sprites[5].attribute2 = 522; // 0

	sprites[6].attribute0 = COLOR_256 | TALL | 25; // Green 1st digit
	sprites[6].attribute1 = SIZE_8 | 240; // sets it to 140 [offscreen] because we dont start in color editor
	sprites[6].attribute2 = 522; // 0
	sprites[7].attribute0 = COLOR_256 | TALL | 25; // Green 2nd digit
	sprites[7].attribute1 = SIZE_8 | 240; // sets it to 140 [offscreen] because we dont start in color editor
	sprites[7].attribute2 = 522; // 0

	sprites[8].attribute0 = COLOR_256 | TALL | 40; // Blue 1st digit
	sprites[8].attribute1 = SIZE_8 | 240; // sets it to 140 [offscreen] because we dont start in color editor
	sprites[8].attribute2 = 522; // 0
	sprites[9].attribute0 = COLOR_256 | TALL | 40; // Blue 2nd digit
	sprites[9].attribute1 = SIZE_8 | 240; // sets it to 140 [offscreen] because we dont start in color editor
	sprites[9].attribute2 = 522; // 0

	// the arrows in the file menu
	sprites[10].attribute0 = COLOR_256 | SQUARE | 160;
	sprites[10].attribute1 = SIZE_16 | HORIZONTAL_FLIP | 0;
	sprites[10].attribute2 = 562;
	sprites[11].attribute0 = COLOR_256 | SQUARE | 160;
	sprites[11].attribute1 = SIZE_16 | 111;
	sprites[11].attribute2 = 562;

	// the temporary + targets for use in lines, etc. 
	sprites[12].attribute0 = COLOR_256 | SQUARE | 160;
	sprites[12].attribute1 = SIZE_8 | 240;
	sprites[12].attribute2 = 562;
	sprites[13].attribute0 = COLOR_256 | SQUARE | 160;
	sprites[13].attribute1 = SIZE_8 | 240;
	sprites[13].attribute2 = 562;
	
	// 214,43
	// these show the current palette number
	sprites[14].attribute0 = COLOR_256 | SQUARE | 160;
	sprites[14].attribute1 = SIZE_8 | 214;
	sprites[14].attribute2 = 522;
	sprites[15].attribute0 = COLOR_256 | SQUARE | 160;
	sprites[15].attribute1 = SIZE_8 | 214+8;
	sprites[15].attribute2 = 522;
	sprites[16].attribute0 = COLOR_256 | SQUARE | 160;
	sprites[16].attribute1 = SIZE_8 | 214+8+8;
	sprites[16].attribute2 = 522;

        WaitForVSync();
	CopyOAM(); // Copy all the attributes i just set into OAM
	M4FillScreen(colorBG);
	ones=0;
	delay=START_OF_DELAY;
	while(!0) // loops forever
	{
		if(!((*KEYS) & KEY_UP)) // if the up key on the d pad is pressed
			if(y>0)         // makes sure you wont draw off the screen
			{
				y--;
				WaitBlanks(delay); // waits delay/60ths of a second. delay is adjusted by the L and R butttons.
			}
		if(!((*KEYS) & KEY_DOWN)) // if the down key is pressed
			if(y<159) //makes sure you wont draw off the screen
			{
				y++; // increments the y value of the screen
				WaitBlanks(delay); // waits delay/60ths of a second. delay is adjusted by the L and R butttons.
			}
		if(!((*KEYS) & KEY_LEFT)) // if left is pressed
			if(x>0) // makes sure you wont draw off the scrren
			{
				x--; // decrements the x value of the "pen"
				WaitBlanks(delay); // waits delay/60ths of a second. delay is adjusted by the L and R butttons.
			}
		if(!((*KEYS) & KEY_RIGHT)) // ir right is pressed
			if(x<239) // make sure you wont draw off the screen
			{
				x++; // increments x
				WaitBlanks(delay); // waits delay/60ths of a second. delay is adjusted by the L and R butttons.
			}
		if(!((*KEYS) & KEY_L))
		{
			if(delay>20)
				delay-=10;
			WaitBlanks(30);
		}
		if(!((*KEYS) & KEY_R))
		{
			if(delay<240)
				delay+=10;
			WaitBlanks(30);
		}		
		if(!((*KEYS) & KEY_A)) // if your press A,
			color=1;  // make the color to be plotted be color A
		else if(!((*KEYS) & KEY_B)) // if you press B,
			color=2;       // make the color being blitted be color B
		else color=0; // otherwiese make it the BG color
		if(!((*KEYS) & KEY_SELECT)) // if you press select
		{
			for(temp=0;temp<256;temp++)       
				picpal[temp] = M4GetPalette(temp);
			for(temp=0;temp<240;temp++)
				for(temp2=0;temp2<160;temp2++)
					picdata[temp2*240+temp] = M4GetPixel(temp, temp2);
				
			EditColor(); // load the editcolor foxion
                        WaitForVSync();
                        
			for(temp=0;temp<256;temp++)       
				M4PutPalette(picpal[temp], temp);
			for(temp=0;temp<240;temp++)
				for(temp2=0;temp2<160;temp2++)
					M4PlotPixel(temp, temp2, picdata[temp2*240+temp]);
					
			sprites[1].attribute1 = SIZE_8 | 240; // sets it to 140 [offscreen] because we dont start in color editor
			sprites[2].attribute1 = SIZE_8 | 240; // sets it to 140 [offscreen] because we dont start in color editor
			sprites[3].attribute1 = SIZE_8 | 240; // sets it to 140 [offscreen] because we dont start in color editor
			sprites[4].attribute1 = SIZE_8 | 240; // sets it to 140 [offscreen] because we dont start in color editor
			sprites[5].attribute1 = SIZE_8 | 240; // sets it to 140 [offscreen] because we dont start in color editor
			sprites[6].attribute1 = SIZE_8 | 240; // sets it to 140 [offscreen] because we dont start in color editor
			sprites[7].attribute1 = SIZE_8 | 240; // sets it to 140 [offscreen] because we dont start in color editor
			sprites[8].attribute1 = SIZE_8 | 240; // sets it to 140 [offscreen] because we dont start in color editor
			sprites[9].attribute1 = SIZE_8 | 240; // sets it to 140 [offscreen] because we dont start in color editor
			sprites[12].attribute1 = SIZE_8 | 240; // sets it to 140 [offscreen] because we dont start in color editor
			sprites[13].attribute1 = SIZE_8 | 240; // sets it to 140 [offscreen] because we dont start in color editor
			ones=0;
		}
		if(!((*KEYS) & KEY_START)) // if you press start
		{
			for(temp=0;temp<256;temp++)       
				picpal[temp] = M4GetPalette(temp);
			for(temp=0;temp<240;temp++)
				for(temp2=0;temp2<160;temp2++)
					picdata[temp2*240+temp] = M4GetPixel(temp, temp2);
			FileMenu();
                        WaitForVSync();
			for(temp=0;temp<256;temp++)       
				M4PutPalette(picpal[temp], temp);
			for(temp=0;temp<240;temp++)
				for(temp2=0;temp2<160;temp2++)
					M4PlotPixel(temp, temp2, picdata[temp2*240+temp]);
					
			sprites[10].attribute0 = COLOR_256 | SQUARE | 160;
			sprites[11].attribute0 = COLOR_256 | SQUARE | 160;
			if(pen==0)
				sprites[0].attribute2 = 512;
			if(pen==1)
				sprites[0].attribute2 = 570;
			if(pen==2)
				sprites[0].attribute2 = 572;
			if(pen==3)
				sprites[0].attribute2 = 574;
			if(pen==4)
				sprites[0].attribute2 = 574;
			if(pen==5)
				sprites[0].attribute2 = 574;
			if(pen==6)
				sprites[0].attribute2 = 578;
			ones=0;
		}
                if(pen==0)
                {
                	sprites[0].attribute0 = COLOR_256 | SQUARE | y;
                	sprites[0].attribute1 = SIZE_8 | x;
			if(color != colorBG) // plots the pixel only if you are pressing A or B, otherwise just moves the "pen"
			{
				WaitForVSync();
				M4PlotPixel(x,y,color); //plots the pixel!
			}
		}
		if(pen==1)
		{
                	sprites[0].attribute0 = COLOR_256 | SQUARE | y;
                	sprites[0].attribute1 = SIZE_8 | x;
			if(color != colorBG)
			{
	                        WaitForVSync();
				M4PlotPixel(x+1,y,color);
				M4PlotPixel(x,y,color);
				M4PlotPixel(x,y+1,color);
				M4PlotPixel(x+1,y+1,color);
			}
		}
		if(pen==2)
		{
		       	sprites[0].attribute0 = COLOR_256 | SQUARE | y;
                	sprites[0].attribute1 = SIZE_8 | x;
			if(color != colorBG)
			{
                		WaitForVSync();
				M4PlotPixel(x+1,y,colorBG);
				M4PlotPixel(x,y,colorBG);
				M4PlotPixel(x,y+1,colorBG);
				M4PlotPixel(x+1,y+1,colorBG);
			}
		}
		if(pen==3)
		{
               		sprites[0].attribute0 = COLOR_256 | SQUARE | y-2;
               		sprites[0].attribute1 = SIZE_8 | x-2;
			if(color==colorA)
			{
				if(ones==0)
				{
					sprites[12].attribute0 = COLOR_256 | SQUARE | y-2;
					sprites[12].attribute1 = SIZE_8 | x-2;
					sprites[12].attribute2 = 576;
					xtemp=x;
					ytemp=y;
					ones=1;
				}
				else if(ones==1)
				{
					sprites[13].attribute0 = COLOR_256 | SQUARE | y-2;
					sprites[13].attribute1 = SIZE_8 | x-2;
					sprites[13].attribute2 = 576;
					xtemp2=x;
					ytemp2=y;
					ones=0;
				}
                        WaitForVSync();
			CopyOAM();
			while(!((*KEYS) & KEY_A));
			}
			if(color==colorB)
			{
				sprites[12].attribute1 = SIZE_8 | 240;
				sprites[13].attribute1 = SIZE_8 | 240;
                                WaitForVSync();
				CopyOAM();
				M4Line(xtemp,ytemp,xtemp2,ytemp2,colorA);
			}
		}

		if(pen==4)
		{
               		sprites[0].attribute0 = COLOR_256 | SQUARE | y-2;
               		sprites[0].attribute1 = SIZE_8 | x-2;
			if(color==colorA)
			{
				if(ones==0)
				{
					sprites[12].attribute0 = COLOR_256 | SQUARE | y-2;
					sprites[12].attribute1 = SIZE_8 | x-2;
					sprites[12].attribute2 = 576;
					xtemp=x;
					ytemp=y;
					ones=1;
				}
				else if(ones==1)
				{
					sprites[13].attribute0 = COLOR_256 | SQUARE | y-2;
					sprites[13].attribute1 = SIZE_8 | x-2;
					sprites[13].attribute2 = 576;
					xtemp2=x;
					ytemp2=y;
					ones=0;
				}
                        WaitForVSync();
			CopyOAM();
			while(!((*KEYS) & KEY_A));
			}
			if(color==colorB)
			{
				sprites[12].attribute1 = SIZE_8 | 240;
				sprites[13].attribute1 = SIZE_8 | 240;
                                WaitForVSync();
				CopyOAM();
				if(xtemp>xtemp2)
				{
					tempo=xtemp2;
					xtemp2=xtemp;
					xtemp=tempo;
				}
				if(ytemp>ytemp2)
				{
					tempo=ytemp2;
					ytemp2=ytemp;
					ytemp=tempo;
				}	
				M4FillBox(xtemp,ytemp,xtemp2,ytemp2,colorA);
			}
		}


		if(pen==5)
		{
               		sprites[0].attribute0 = COLOR_256 | SQUARE | y-2;
               		sprites[0].attribute1 = SIZE_8 | x-2;
			if(color==colorA)
			{
				if(ones==0)
				{
					sprites[12].attribute0 = COLOR_256 | SQUARE | y-2;
					sprites[12].attribute1 = SIZE_8 | x-2;
					sprites[12].attribute2 = 576;
					xtemp=x;
					ytemp=y;
					ones=1;
				}
				else if(ones==1)
				{
					sprites[13].attribute0 = COLOR_256 | SQUARE | y-2;
					sprites[13].attribute1 = SIZE_8 | x-2;
					sprites[13].attribute2 = 576;
					xtemp2=x;
					ytemp2=y;
					ones=0;
				}
                        WaitForVSync();
			CopyOAM();
			while(!((*KEYS) & KEY_A)) {};
			}
			if(color==colorB)
			{
				sprites[12].attribute1 = SIZE_8 | 240;
				sprites[13].attribute1 = SIZE_8 | 240;
				ones=0;
				if(xtemp>xtemp2)
				{
					otempx  = xtemp;
					otempx2 = xtemp2;
					xtemp   = xtemp2;
					xtemp2  = otempx;
				}
				else otempx = xtemp;
				if(ytemp>ytemp2)
				{
					otempy  = ytemp;
					otempy2 = ytemp2;
					ytemp   = ytemp2;
					ytemp2  = otempy;
				}
				else otempy = ytemp;
                                WaitForVSync();
				linelength = abs((xtemp2-xtemp)^2 + (ytemp2-ytemp)^2);
				M4Circle(otempx,otempy,linelength,colorA);
			}
		}
		
		if(pen==6) // flood
                {
                	if(y<7)
                	{
                		otempy = 255-(6-y);
                	}
                	else otempy = y-7;
                	sprites[0].attribute0 = COLOR_256 | SQUARE | otempy;
                	sprites[0].attribute1 = SIZE_8 | x;
			if(color != colorBG) // plots the pixel only if you are pressing A or B, otherwise just moves the "pen"
			{
				M4FloodFill(x,y, color);
			}
		}
                WaitForVSync();
		CopyOAM(); // copys sprites
	}	

}


void EditColor() // editcolor funxion
{
	u8 xloop, yloop, tempvar1, rgb, ab=0, ecpalnum=colorA; // variables
	u16 temp, temp2, R, G, B;                    // variables
        WaitForVSync();
	for(temp=0;temp<127;temp++)       
		BGPaletteMem[temp] = coloreditPalette[temp];
	for(temp=0;temp<19200;temp++)
	{
		VideoBuffer[temp]=coloreditBitmap[temp];
	}
	if(ab==0)
	{
		temp=31;              // theese extract the Red, green and blue data from the 15 bit values used in mode 3 into 3 5 bit values from 0-31
		R=M4GetPalette(colorA) & temp;
		temp=992;
		G=(M4GetPalette(colorA) & temp)>>5;
		temp=31744;
		B=(M4GetPalette(colorA) & temp)>>10;
	}
	if(ab==1)
	{
		temp=31;           // theese extract the Red, green and blue data from the 15 bit values used in mode 3 into 3 5 bit values from 0-31
		R=M4GetPalette(colorB) & temp;
		temp=992;
		G=(M4GetPalette(colorB) & temp)>>5;
		temp=31744;
		B=(M4GetPalette(colorB) & temp)>>10;
	}

	sprites[0].attribute1 = SIZE_8 | 240; // sets the pen to offscreen, cause in editing colors now, not drawing
	sprites[1].attribute1 = SIZE_8 | 43;  // puts the red slider to the 0 position.
	sprites[2].attribute1 = SIZE_8 | 43;  //puts Green to 0
	sprites[3].attribute1 = SIZE_8 | 43;  //puts the Blue Slider to the 0 position
	
	sprites[4].attribute2 = ((tenslider[R]*4)+522); // makes the digit sprites point to the right character in memory
	sprites[5].attribute2 = ((oneslider[R]*4)+522); // ^

	sprites[4].attribute1 = SIZE_8 | 178; // makes the digit sprites come back on screen
	sprites[5].attribute1 = SIZE_8 | 185; // ^

	sprites[6].attribute2 = ((tenslider[G]*4)+522); 
	sprites[7].attribute2 = ((oneslider[G]*4)+522);

	sprites[6].attribute1 = SIZE_8 | 178;
	sprites[7].attribute1 = SIZE_8 | 185;

	sprites[8].attribute2 = ((tenslider[B]*4)+522);
	sprites[9].attribute2 = ((oneslider[B]*4)+522);

	sprites[8].attribute1 = SIZE_8 | 178;
	sprites[9].attribute1 = SIZE_8 | 185;
	
	sprites[14].attribute0 = COLOR_256 | SQUARE | 43;
	sprites[14].attribute1 = SIZE_16 | 214;
	sprites[14].attribute2 = 522;
	sprites[15].attribute0 = COLOR_256 | SQUARE | 43;
	sprites[15].attribute1 = SIZE_16 | 214+8;
	sprites[15].attribute2 = 522;
	sprites[16].attribute0 = COLOR_256 | SQUARE | 43;
	sprites[16].attribute1 = SIZE_16 | 214+8+8;
	sprites[16].attribute2 = 522;

 
        WaitForVSync(); // waits for the scren to finish drawing
	CopyOAM(); // copys Object Attribute Memory
	tempvar1=0; 
	rgb=0; // sets the current selected color to 0
	
	while(tempvar1==0)
	{
		if(!((*KEYS) & KEY_A))
			if(ab==1)
			{
				ab=0;
				temp=31;
				R=colorA & temp;
				temp=992;
				G=(colorA & temp)>>5;
				temp=31744;
				B=(colorA & temp)>>10;
			}
		if(!((*KEYS) & KEY_B))
			if(ab==0)
			{
				ab=1;
				temp=31;
				R=colorB & temp;
				temp=992;
				G=(colorB & temp)>>5;
				temp=31744;
				B=(colorB & temp)>>10;
			}
		if(!((*KEYS) & KEY_UP))
		{
			if(rgb==0) // Red
			{
				rgb=2;
			}
			else if(rgb==1) // Green
			{
				rgb=0;
			}
			else if(rgb==2) // Blue
			{
				rgb=1;
			}
			WaitBlanks(TIME_TO_WAIT);
		}
		if(!((*KEYS) & KEY_DOWN))
		{
			if(rgb==0) // Red
			{
				rgb=1;
			}
			else if(rgb==1) // Green
			{
				rgb=2;
			}
			else if(rgb==2) // Blue
			{
				rgb=0;
			}
			WaitBlanks(TIME_TO_WAIT); // this line sends 1000 emails to those goddam idiots who made the "internet threasure chest" infomercial!
		}
		if(!((*KEYS) & KEY_LEFT))
		{
			if(rgb==0) // Red
				if(R>0)
					R-=1;
			if(rgb==1) // Green
				if(G>0)
					G-=1;
			if(rgb==2) // Blue
				if(B>0)
					B-=1;
			WaitBlanks(TIME_TO_WAIT);
		}
		if(!((*KEYS) & KEY_RIGHT)) // if(right+right!wrong) right=wrong;
		{
			if(rgb==0) // Red
				if(R<31)
					R+=1;
			if(rgb==1) // Green
				if(G<31)
					G+=1;
			if(rgb==2) // Blue
				if(B<31)
					B+=1;
			WaitBlanks(TIME_TO_WAIT);
		}
		if(!((*KEYS) & KEY_SELECT))
			tempvar1=1;


	sprites[1].attribute1 = SIZE_8 | ((R*4)+43);
	sprites[2].attribute1 = SIZE_8 | ((G*4)+43);
	sprites[3].attribute1 = SIZE_8 | ((B*4)+43);

	sprites[1].attribute2 = 514;
	sprites[2].attribute2 = 514;
	sprites[3].attribute2 = 514;

	sprites[rgb+1].attribute2 = 518;
	
	sprites[4].attribute2 = ((tenslider[R]*4)+522);
	sprites[5].attribute2 = ((oneslider[R]*4)+522);

	sprites[6].attribute2 = ((tenslider[G]*4)+522);
	sprites[7].attribute2 = ((oneslider[G]*4)+522);

	sprites[8].attribute2 = ((tenslider[B]*4)+522);
	sprites[9].attribute2 = ((oneslider[B]*4)+522);

	sprites[14].attribute0 = COLOR_256 | SQUARE | 160;
	sprites[14].attribute1 = SIZE_8 | 214;
	sprites[14].attribute2 = 522+( rint((ecpalnum/100)) );
	sprites[15].attribute0 = COLOR_256 | SQUARE | 160;
	sprites[15].attribute1 = SIZE_8 | 214+8;
	sprites[15].attribute2 = 522+( rint(ecpalnum/10) - (rint(ecpalnum/100) *100) );
	sprites[16].attribute0 = COLOR_256 | SQUARE | 160;
	sprites[16].attribute1 = SIZE_8 | 214+8+8;
	sprites[16].attribute2 = 522+( ecpalnum - (rint(ecpalnum/100)*100) - (rint(ecpalnum/10)/10) );

	if(ab==0)
	{
		M4PutPalette((B<<10) | (G<<5) | R, colorA);

		for(xloop=200;xloop<(200+15);xloop++)
			for(yloop=20;yloop<(20+15);yloop++)
				M4PlotPixel(xloop, yloop, colorA);

		for(xloop=221;xloop<(221+15);xloop++)
			for(yloop=20;yloop<(20+15);yloop++)
				M4PlotPixel(xloop, yloop, colorBG);
	}
	if(ab==1)
	{
		M4PutPalette((B<<10) | (G<<5) | R, colorB);

		for(xloop=221;xloop<(221+15);xloop++)
			for(yloop=20;yloop<(20+15);yloop++)
				M4PlotPixel(xloop, yloop, colorB);

		for(xloop=200;xloop<(200+15);xloop++)
			for(yloop=20;yloop<(20+15);yloop++)
				M4PlotPixel(xloop, yloop, colorBG);
	}

	CopyOAM();
	}
}

void FileMenu(void)
{
	u8 xloop, yloop, a, b, side=0;
	u16 temp, temp2;
	for(temp=0;temp<256;temp++)       
		BGPaletteMem[temp] = filemenuPalette[temp];
	for(temp=0;temp<19200;temp++)
	{
		VideoBuffer[temp]=filemenuBitmap[temp];
	}
	waitkeyup();
	sprites[0].attribute1 = SIZE_8 | 240;
	sprites[12].attribute1 = SIZE_8 | 240;
	sprites[13].attribute1 = SIZE_8 | 240;

	CopyOAM();
	temp=0;
	while(temp==0)
	{
		if(!((*KEYS) & KEY_UP))
		{
			if(side==0)
			{
				if(pen>0)
				{
					pen--;
				}
				else pen=6;
				WaitBlanks(TIME_TO_WAIT);
			}
			else
			{
				if(pen>0)
				{
					pen--;
				}
				else pen=2;
				WaitBlanks(TIME_TO_WAIT);
			}
		}
		if(!((*KEYS) & KEY_DOWN)) // visit dcvision.com right now!
		{
			if(side==0)
			{
				if(pen<6)
				{
					pen++;
				}
				else pen=0;
				WaitBlanks(TIME_TO_WAIT);
			}
			else
			{
				if(pen<2)
				{
					pen++;
				}
				else pen=0;
				WaitBlanks(TIME_TO_WAIT);
			}
		}
		if(!((*KEYS) & KEY_START))
		{
			if(side==0)
				temp=1;
			else
			{
				if(pen==0)
				{
					for(temp=0;temp<255;temp++)
						WriteSRAM(temp, picpal[temp]);
					for(temp=0;temp<(240*160);temp++)
						WriteSRAM(temp+255, picdata[temp]);
				}
				if(pen==1)
				{
					for(temp=0;temp<255;temp++)
						picpal[temp] = ReadSRAM8(temp);
					for(temp=0;temp<(240*160);temp++)
						picdata[temp] = ReadSRAM8(temp+255);
				}
				if(pen==2)
				{
					M4PutPalette(RGB(31,31,31),255);
					for(temp=0;temp<240*160;temp++)
						picdata[temp]= 255;
				}
			}
		}
		if(!((*KEYS) & KEY_L))
		{
			side=0;
			sprites[10].attribute1 = SIZE_16 | HORIZONTAL_FLIP | 2;
		}
		if(!((*KEYS) & KEY_R))
		{
			side=1;
			if(pen>2)
				pen=2;
			sprites[10].attribute1 = SIZE_16 | HORIZONTAL_FLIP | 126;
		}
		if(pen==0)
		{
			sprites[10].attribute0 = COLOR_256 | SQUARE | 29;
		}
		if(pen==1)
		{
			sprites[10].attribute0 = COLOR_256 | SQUARE | 47;
		}
		if(pen==2)
		{
			sprites[10].attribute0 = COLOR_256 | SQUARE | 65;
		}
		if(pen==3)
		{
			sprites[10].attribute0 = COLOR_256 | SQUARE | 83;
		}
		if(pen==4)
		{
			sprites[10].attribute0 = COLOR_256 | SQUARE | 101;
		}
		if(pen==5)
		{
			sprites[10].attribute0 = COLOR_256 | SQUARE | 119;
		}
		if(pen==6)
		{
			sprites[10].attribute0 = COLOR_256 | SQUARE | 137;
		}
		WaitForVSync();
		CopyOAM();
	}
}

void ClearOAM(void)
{
	u8 loop;
	for(loop=0;loop<128;loop++)
	{
		sprites[loop].attribute0 = 160;
		sprites[loop].attribute1 = 240;
	}
}

void CopyOAM(void) 
{
	u16 loop;
	u16* temp;
	temp = (u16*)sprites;
	for(loop = 0; loop < 128*4; loop++)
		OAM[loop] = temp[loop];
}

void WriteSRAM(u16 offset, u8 data)
{
	SRAM[offset] = data;
}

u8 ReadSRAM8(u16 offset)
{
	u8 sramdata;
	sramdata = SRAM[offset];
	return sramdata;
}

u16 ReadSRAM16(u16 offset)
{
	u8  sramdata;
	u8  sramdata2;
	u16 rval;
	sramdata  = SRAM[offset];
	sramdata2 = SRAM[offset+1];
	rval = sramdata+(sramdata2<<8);
	return rval;
}

u32 ReadSRAM32(u16 offset)
{
	u8  sramdata;
	u8  sramdata2;
	u16 sramdata3;
	u32 rval;
	sramdata  = SRAM[offset];
	sramdata2 = SRAM[offset+1];
	sramdata3 = sramdata+(sramdata2<<8);
	sramdata  = SRAM[offset+2];
	sramdata2 = SRAM[offset+3];
	rval = sramdata3+(sramdata<<16)+(sramdata2<<24);
	return rval;
}
	
void ebppMENU(void)
{
	u8 menunum=1, update=1;
	u16 tempkey=0;
	BFsetcolors(RGB(31,31,31),RGB(0,0,0));
	while(menunum !=0)
	{
		if(!((*KEYS) & KEY_UP))
		{
			if(menunum>1)
				menunum--;
			else menunum=5;
			update=1;
		}
		if(!((*KEYS) & KEY_DOWN))
		{
			if(menunum<5)
				menunum++;
			else menunum=1;
			update=1;
		}
		if(!((*KEYS) & KEY_START))
		{
			switch (menunum)
			{
				case 1:
					menunum=0;
					break;
				case 2:
					BFclear();
					BFprint(0,0,"____Instructions____");
					BFprint(0,1,"Move around your tool with the");
					BFprint(0,2,"D-pad. L and R will increase /");
					BFprint(0,3,"decrease the speed of the tool");

					BFprint(0,5,"Press SELECT for  the color   ");
					BFprint(0,6,"selection screen. Press A to  ");
					BFprint(0,7,"modify ColorA and B to modify ");
					BFprint(0,8,"ColorB. You can set the R,G,B ");
					BFprint(0,9,"of each from 0-31, giving you ");
					BFprint(0,10,"36 768 total possible colors! ");

					BFprint(0,12,"Press START to go to the tool ");
					BFprint(0,13,"selection screen. Change tools");
					BFprint(0,14,"with the D-Pad. Pres L to save");
					BFprint(0,15,"the pic to SRAM, R to load.   ");

					BFprint(0,17,"Now press A for specific tool ");
					BFprint(0,18,"usage info or any other button");
					BFprint(0,19,"for Main Menu.                ");
					waitkeyup();
					tempkey = getkey();
					if(tempkey==KEY_A)
					{
						WaitForVSync();
						BFclear();

						BFprint(0,0,"Brush: Hold A to blit 2*2 dots");
						BFprint(0,1,"of ColorA, B for ColorB.      ");
						BFprint(0,3,"Eraser: Same as brush except  ");
						BFprint(0,4,"it blits in white.            ");
						BFprint(0,6,"Line: Press A to set p1, press");
						BFprint(0,7,"A again to set p2, then press ");
						BFprint(0,8,"B to blit a straight line from");
						BFprint(0,9,"p1 to p2 of ColorA.           ");
						BFprint(0,11,"Rectangle: Same as line except");
						BFprint(0,12,"it blits a filled rectangle.  ");
						BFprint(0,14,"Circle: Press A to set center,");
						BFprint(0,15,"A again for radius. The radius");
						BFprint(0,16,"MUST be either the same X or Y");
						BFprint(0,17,"as center or it wont work.    ");
						BFprint(0,19,"Press any button for Main Menu");
						waitkeyup();
						tempkey = getkey();
						tempkey=KEY_A;
					}					
					break;
				case 4:
					BFclear();
					BFprint(0,0,"____Credits____");
					BFprint(0,2,"  Coder: The Black Frog       ");
					BFprint(0,3,"Website: TheBlackFrog.8m.com  ");
					BFprint(0,5,"I used Staring Monkey's mode 3");
					BFprint(0,6,"drawing and timer librarys.   ");
					BFprint(0,7,"Get his libs from gbadev.org. ");
					BFprint(0,9,"crt0 made the ebpp2bmp tool   ");
					BFprint(0,10,"that converts ebpp SRAM to a  ");
					BFprint(0,11,"windows bitmap file. His URL  ");
					BFprint(0,12,"is dcvision.com/crt0/.        ");
					BFprint(0,19,"Press any key for Main Menu.  ");
					waitkeyup();
					tempkey=getkey();
					break;
				case 5:
					BFclear();
					BFprint(0,0,"____Greets____");
					BFprint(0,2,"Greetings to the following:   ");
					BFprint(0,4,"StarMonk, SlasherX, Dovoto,   ");
					BFprint(0,5,"Joat, JayC, JSensebe, Fett,   ");
					BFprint(0,6,"crt0, Ryuudo and eveyone else ");
					BFprint(0,7,"on #GBADev on EFNET.          ");
					BFprint(0,19,"Press any key for Main Menu.  ");
					waitkeyup();
					tempkey = getkey();
					break;
				case 3:
					BFclear();
					BFprint(0,0,"____Resources____");
					BFprint(0,2,"/----- The Pern Project -----\\");
					BFprint(0,3,"\\==== ThePernProject.com ====/");
					BFprint(0,4,"A very good tutorial on GBA   ");
					BFprint(0,5,"Dev by dovoto.                ");
					BFprint(0,7,"/------- Mappy v0.7b --------\\");
					BFprint(0,8,"\\===== BottledLight.com =====/");
					BFprint(0,9,"A very good GBA emu that has  ");
					BFprint(0,10,"many usefull debug features.  ");
					BFprint(0,12,"/-------- Bimbo v1.3 --------\\");
					BFprint(0,13,"\\====== cncd.fi/aeeben ======/");
					BFprint(0,14,"A bitmap (mode 3-5) graphics  ");
					BFprint(0,15,"converter for GBA.            ");
					BFprint(0,17,"Press A to see a list of GBA  ");
					BFprint(0,18,"Dev related URLS or any other ");
					BFprint(0,19,"button for Main Menu.         ");
					waitkeyup();
					tempkey= getkey();
					if(tempkey==KEY_A)
					{
						BFclear();
						BFprint(0,0,"A > means the URL continues to");
						BFprint(0,1,"the next line. damn long urls!");
						BFprint(0,3,"www.ThePernProject.com        ");
						BFprint(0,4,"www.GBADev.org                ");
						BFprint(0,5,"www.GBAEmu.com                ");
						BFprint(0,6,"www.BottledLight.com          ");
						BFprint(0,7,"www.occultforces.mine.nu/ >   ");
						BFprint(0,8,"~DarkFader/gba                ");
						BFprint(0,9,"www.devrs.com/gba             ");
						BFprint(0,10,"www.GameBoyLand.com          ");
						BFprint(0,11,"www.ConsoleVision.com        ");
						BFprint(0,12,"www.FiveMouse.com            ");
						BFprint(0,13,"www.gbax.com                 ");
						BFprint(0,19,"Press any key for Main Menu. ");
						waitkeyup();
						tempkey=getkey();
					}
					break;
			}
			update=1;
		}
		if(update==1)
		{
			WaitForVSync();
			BFsetcolors(RGB(31,31,31),RGB(5,5,5));
			BFclear();
			BFprint(0,0,"   Evil Bob's Pocket Painter  ");
			BFprint(0,1,"      By: The Black Frog      ");
			BFprint(0,4,"Main Menu:                    ");
  	     		BFprint(0,6,"    Start Painting   ");
			BFprint(0,7,"     Instructions   ");
		        BFprint(0,8,"      Resources   ");
			BFprint(0,9,"       Credits   ");
			BFprint(0,10,"        Greets   ");

			BFsetcolors(RGB(31,31,31), RGB(0,0,0));
			switch (menunum)
			{
				case 1:
					BFprint(0,6," -> Start Painting <-");
					break;
				case 2:
					BFprint(0,7,"  -> Instructions <-"); 
					break;
				case 3:
					BFprint(0,8,"   -> Resources <-");
					break;
				case 4:
					BFprint(0,9,"    -> Credits <-");
					break;
				case 5:
					BFprint(0,10,"     -> Greets <-");
					break;
			}
			update=0;
		}
	}
}

u16 getkey()
{
	u16 temp=0;
	while(temp==0)
	{
		if(!((*KEYS) & KEY_A))
			temp=KEY_A;
		if(!((*KEYS) & KEY_B))
			temp=KEY_B;
		if(!((*KEYS) & KEY_L))
			temp=KEY_L;
		if(!((*KEYS) & KEY_R))
			temp=KEY_R;
		if(!((*KEYS) & KEY_START))
			temp=KEY_START;
		if(!((*KEYS) & KEY_SELECT))
			temp=KEY_SELECT;
		if(!((*KEYS) & KEY_UP))
			temp=KEY_UP;
		if(!((*KEYS) & KEY_DOWN))
			temp=KEY_DOWN;
		if(!((*KEYS) & KEY_LEFT))
			temp=KEY_LEFT;
		if(!((*KEYS) & KEY_RIGHT))
			temp=KEY_RIGHT;
	}
	return temp;
}

void waitkeyup(void)
{
//	while((*KEYS) != 0xFFFF);
}

s16 rint(s16 tempval)
{
	return tempval;
}