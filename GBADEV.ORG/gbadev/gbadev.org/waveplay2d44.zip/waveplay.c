#define RGB(r,g,b) ((r)+((g)<<5)+((b)<<10)) // rgb macro

#include <string.h> // for BFtext
#include <ctype.h> // alkso for BFtext
#include "gba.h"
#include "screenmode.h"
#include "time.h"

#include "dma.h" // starmonk's dma lib
#include "sound.h" // starmonk's directsound lib

#include "onering.c" // from moviesounds.com
#include "BFtext.h" // my BFtext lib

void C_Entry(void)
{
	PlaySound(ONERING_DATA, ONERING_SAMPRATE); // this plays the sound
	
	
	SetMode(MODE_0 | BG0_ENABLE);
	REG_BG0CNT = 132;
	BFinit();
	BFsetcolors(RGB(31,31,31),RGB(0,0,0));
	BFclear();
	BFprint(0,2," wav2gbac r3 demo");
	BFprint(0,3," by: The Black Frog");
	BFprint(0,5,"http://www.TheBlackFrog.8m.com");
	BFprint(0,6,"^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^");
	BFprint(0,8,"Greetz: SlasherX,");
	BFprint(0,9,"Staring Monkey,");
	BFprint(0,10,"Stephen Stairs,");
	BFprint(0,11,"John Sensebe.");
	BFprint(0,13,".wav from LoTR movie");
	BFprint(0,14,"from moviesounds.com");
		
	while(!0);
}