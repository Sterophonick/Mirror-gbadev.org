#ifndef __OBJPROPERTIESLUT__
#define __OBJPROPERTIESLUT__

#define CONTENTS_BIT 4
#define CONTENTS_MASK 0x0F

extern const int objPropertiesLUT[35];

#endif
