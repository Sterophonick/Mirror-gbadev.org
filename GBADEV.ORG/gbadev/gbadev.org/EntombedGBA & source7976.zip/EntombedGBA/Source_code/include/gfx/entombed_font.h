
//{{BLOCK(entombed_font)

//======================================================================
//
//	entombed_font, 128x56@4, 
//	+ palette 16 entries, not compressed
//	+ 112 tiles not compressed
//	Total size: 32 + 3584 = 3616
//
//	Time-stamp: 2015-12-12, 10:40:23
//	Exported by Cearn's GBA Image Transmogrifier, v0.8.12
//	( http://www.coranac.com/projects/#grit )
//
//======================================================================

#ifndef GRIT_ENTOMBED_FONT_H
#define GRIT_ENTOMBED_FONT_H

#define entombed_fontTilesLen 3584
extern const unsigned short entombed_fontTiles[1792];

#define entombed_fontPalLen 32
extern const unsigned short entombed_fontPal[16];

#endif // GRIT_ENTOMBED_FONT_H

//}}BLOCK(entombed_font)
