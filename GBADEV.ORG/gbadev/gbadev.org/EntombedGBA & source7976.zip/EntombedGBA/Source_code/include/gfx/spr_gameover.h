
//{{BLOCK(spr_gameover)

//======================================================================
//
//	spr_gameover, 96x16@4, 
//	+ 24 tiles Metatiled by 4x2 not compressed
//	Total size: 768 = 768
//
//	Time-stamp: 2015-12-12, 10:40:23
//	Exported by Cearn's GBA Image Transmogrifier, v0.8.12
//	( http://www.coranac.com/projects/#grit )
//
//======================================================================

#ifndef GRIT_SPR_GAMEOVER_H
#define GRIT_SPR_GAMEOVER_H

#define spr_gameoverTilesLen 768
extern const unsigned short spr_gameoverTiles[384];

#endif // GRIT_SPR_GAMEOVER_H

//}}BLOCK(spr_gameover)
