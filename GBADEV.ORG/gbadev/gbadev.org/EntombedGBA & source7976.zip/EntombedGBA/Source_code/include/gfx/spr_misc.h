
//{{BLOCK(spr_misc)

//======================================================================
//
//	spr_misc, 128x32@4, 
//	+ 64 tiles Metatiled by 4x2 not compressed
//	Total size: 2048 = 2048
//
//	Time-stamp: 2015-06-23, 08:35:05
//	Exported by Cearn's GBA Image Transmogrifier, v0.8.12
//	( http://www.coranac.com/projects/#grit )
//
//======================================================================

#ifndef GRIT_SPR_MISC_H
#define GRIT_SPR_MISC_H

#define spr_miscTilesLen 2048
extern const unsigned short spr_miscTiles[1024];

#endif // GRIT_SPR_MISC_H

//}}BLOCK(spr_misc)
