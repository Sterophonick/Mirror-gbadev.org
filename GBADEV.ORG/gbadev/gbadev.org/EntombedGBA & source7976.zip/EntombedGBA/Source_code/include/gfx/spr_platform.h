
//{{BLOCK(spr_platform)

//======================================================================
//
//	spr_platform, 32x16@4, 
//	+ 8 tiles Metatiled by 4x2 not compressed
//	Total size: 256 = 256
//
//	Time-stamp: 2015-12-12, 10:40:23
//	Exported by Cearn's GBA Image Transmogrifier, v0.8.12
//	( http://www.coranac.com/projects/#grit )
//
//======================================================================

#ifndef GRIT_SPR_PLATFORM_H
#define GRIT_SPR_PLATFORM_H

#define spr_platformTilesLen 256
extern const unsigned short spr_platformTiles[128];

#endif // GRIT_SPR_PLATFORM_H

//}}BLOCK(spr_platform)
