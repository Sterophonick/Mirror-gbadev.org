#include "sfx.h"

//Setup sound effects
	mm_sound_effect title_bounce = {
			{ SFX_TITLE } ,			// id
			(int)(1.0f * (1<<10)),	// rate
			0,		// handle
			255,	// volume
			0,		// panning
		};



