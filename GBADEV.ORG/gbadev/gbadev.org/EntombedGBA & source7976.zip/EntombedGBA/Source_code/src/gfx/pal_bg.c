
//{{BLOCK(pal_bg)

//======================================================================
//
//	pal_bg, 256x16@8, 
//	Transparent palette entry: 0.
//	+ palette 32 entries, not compressed
//	Total size: 64 = 64
//
//	Time-stamp: 2015-06-25, 10:21:59
//	Exported by Cearn's GBA Image Transmogrifier, v0.8.12
//	( http://www.coranac.com/projects/#grit )
//
//======================================================================

const unsigned short pal_bgPal[32] __attribute__((aligned(4))) __attribute__((visibility("hidden")))=
{
	0x0000,0x2235,0x3220,0x77BD,0x010C,0x4635,0x210C,0x0084,
	0x32B9,0x218C,0x1191,0x318C,0x56B5,0x46B5,0x23BD,0x023D,
	0x0000,0x0D70,0x1D60,0x6318,0x0067,0x2D70,0x0C67,0x0000,
	0x1E14,0x0CE7,0x00EB,0x1CE7,0x4210,0x2E10,0x0F18,0x0178,
};

//}}BLOCK(pal_bg)
