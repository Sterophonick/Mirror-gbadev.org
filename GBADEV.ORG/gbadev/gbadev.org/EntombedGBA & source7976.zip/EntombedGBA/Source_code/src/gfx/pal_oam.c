
//{{BLOCK(pal_oam)

//======================================================================
//
//	pal_oam, 256x128@4, 
//	+ palette 16 entries, not compressed
//	Total size: 32 = 32
//
//	Time-stamp: 2015-12-12, 10:40:23
//	Exported by Cearn's GBA Image Transmogrifier, v0.8.12
//	( http://www.coranac.com/projects/#grit )
//
//======================================================================

const unsigned short pal_oamPal[16] __attribute__((aligned(4))) __attribute__((visibility("hidden")))=
{
	0x0000,0x2235,0x3220,0x77BD,0x010C,0x4635,0x210C,0x0084,
	0x32B9,0x218C,0x1191,0x318C,0x56B5,0x46B5,0x23BD,0x023D,
};

//}}BLOCK(pal_oam)
