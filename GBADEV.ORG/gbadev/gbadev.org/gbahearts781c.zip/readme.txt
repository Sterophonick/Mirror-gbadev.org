GBAHearts by Stephen Stair (sgstair)
an entry in the GBADEV hearts compo

Hello everyone, I'm back into gba development!
This is the result of 3-4 days effort with a significant amount of
planning.  I hope you like it, source will be released after the
competition results are finalized on my website and on gbadev.org

This entry is by no means complete, I'm sitting here writing this less than 2 hours before the deadline, trying to crank out some decent computer AI.  The entry is the result of most of a weekend's work and an incredible lack of sleep :) and of course In a sense I'm a stupid eye-candy freak, so yes I wrote the menus first and then went on the the gameplay (the guys in #gbadev won't leave me alone about this :)
so, I hope you like it, I've had fun writing it and I DO intend to complete it after the compo in my spare time, by adding multiplayer, Improving cpu AI, and all those other cool things.
There are still some bugs, but I'll get them fixed soon

Thanks to:
Joat [#gbadev on EFnet](for mappy)
Forgotton [vboy.emuhq.com] (for VBA)
Costis [#gbadev on EFnet] (for helping with VBA and 
		bothering me a LOT while I was writing this entry!)
deeno_ [#gameart on EFnet] (for sending me the free-to-use cards!)
Boofly [#gbadev on EFnet] (for helping out with ideas to speed up
				graphics)

Greets to:
OneManBand, DuoDreamer, Goury, BigRedPimp, meepmouse, frog_e_style
all others on #gbadev and #gameart on EFnet
Others i've probably forgotten too

Anyhow, that's all for now, I'll retreat to my nice dark little corner
of #gbadev on EFnet :)

-Stephen Stair (sgstair)
www.interspecialty.com/sgstair