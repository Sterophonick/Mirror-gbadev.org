--- Mario Demo v1.0 by dagamer34 ---

After spending lots of time on the forums increasing my post count you would think that I would have released something to the public by now, right? Anyway, your prayers (and mine) have finally been answered. dagamer34 has released his very first demo! And he thinks it's a pretty good one too. :)



Controls:
D-pad: Move Mario around
A button: Jump (jump higher by pressing B button and moving in a direction at      same time)
B button: Run
L/R: Not used

Scoring: 100 points for every coin, 10000 points for getting 100 coins. The coin counter resets to 0 after getting 100 coins.

Goal: Jump around and have some fun, hopefully! :) 



If you feel like something should be changed or added, e-mail me at dagamer34@yahoo.com. I will listen to anyone, no matter how much experience you have!

...Oh, and for those people who are complaining about the size of the ROM being 2.62 MB, I am clearly aware that the ROM is WAY over the limit for the compo. It's just that I converted a .mod to a .s3m and it bloated the file to 2.5 MB! Crazy.