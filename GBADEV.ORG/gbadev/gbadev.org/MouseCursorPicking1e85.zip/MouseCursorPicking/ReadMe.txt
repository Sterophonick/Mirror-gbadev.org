
I made a way to select objects on screen like a mouse by using pixel color.
Here is a video I made to explain how it works.
https://www.youtube.com/watch?v=Jw3G2XvTE00

A or B buttons    = mouse click.
Direction buttons = move mouse.

I'm providing the C source code and my batch file. 
Check out my youtube channel if you want to see more random fun stuff. 
www.youtube.com/3dsage
Thank you and have fun programming on the GBA!

