Final Fantasy GBA v0.2

Code - Ethos
Graphics - Squaresoft

v0.2 - Whole Castle Baron 
     - Chest opening, with flag marking 
     - Switches will work (tile fliping + collision changing) 
     - Animated Tiles 
     - Animated NPCs (fixed or random movement) 
     - Paralax backgrounds (2 Layered Backgrounds, one moving) 
     - Door opening 
     - 50/50 alpha blends (water)
     - 0/100 alpha blend (bed-top)
     - Windowing used for map transitions with Mosaic

v0.1 - First Demo, can walk around in screen with a map transition 
       if you go through the upper exit.  Also there is an intro with
       a mode 4 text tool.