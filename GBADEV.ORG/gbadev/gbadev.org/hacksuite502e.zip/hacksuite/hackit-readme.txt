*** Hackit v0.1 Read-Me ***

Synopsis:
 A nice little command line utility (you can drag and drop an image
 on to it too, works great) that will seperate the palette and image
 data from a source file and save them to seperate files.

 Usage:
  hackit srcfile.ext

 Where:
  srcfile is the source image, one of:
    o 256 color PCX Image
    o 256 color BMP Image

 The resulting pixel data from the source image is saved as 
 srcfile.raw and the palette is saved as srcfile.pal

 If enough peeps want it to support more formats or 16 color images
 or something, I'll make a new version. I like feedback.

 My e-mail is michael@auia.net, if I'm in #gbadev, my nick is Joat.