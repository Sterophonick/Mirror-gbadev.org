------------------------------------------
TBM Tool pre-release (September 16th 2002)
------------------------------------------

Overview

TBM Tool is a front-end and viewer for encoding
TBM-format files. TBM files consist of a palette,
a tile-map and the tiles. The file format is
detailed further down in this document.
    Originally, the format was designed for the
Gameboy Advance and is still being developed in
regards to it, however I have added output
formats that might be more desirable for other
platforms as well. One particular advantage of
the encoder is that it can output files of a
specific number of tiles - this helps work with
the Gameboy Advance's memory limitations while
still providing a high-quality image.
    The point of TBM is that it provides
reasonable compression, with reasonable image
quality, but at almost zero impact to
decompress. The image can be lossless or lossy
and at times (for certain platforms) can
actually be less impact to transfer to RAM than
the same image stored in its raw format.

Features

-Batch encoding
-3 output modes (one specially tailored for
 Gameboy Advance)
-Viewing of TBM, BMP and PCX files
-Zooming in/out
-Overlay grid (8x8 to show tiles)
-Customisable quality of compression
-Customisable tile-amounts for encoded files

Usage

Usage should be self-explanatory. Any problems
can be communicated to myself. Contact details
are given below.

Known Bugs

-Encoder progress bar is inaccurate
-Zooming out makes the image look wrong

Future features

-Encoding of .bmp and .tbm formats
-4/15/16/24/32-bit images
-More accurate progress bar
-Simple image editing tools
-Better zooming out
-Support for more formats
-Support for H/V-flipped tiles
-Better and more efficient encoding
-Image pre-processing (viewer)
-Source for viewing on various platforms
-Complete integration of the encoder and 
 viewer (?)
-Source for encoder (?)

File format

Byte	|Description		 |Size
----------------------------------------
0	|Mode			 |1
1	|Width in tiles 	 |1
2	|Height in tiles	 |1
3	|Blank for Mode P,	 |768/1
	|otherwise start of	 |
	|palette data		 |
4	|Palette data for Mode P |512
-	|Tile-map		 |-
-	|Tile data (raw format)	 |-

For Mode P (the GBA optimised mode), the
palette is stored in 15-bit BGR format.
Otherwise it is in 24-bit RGB format.
For Mode 1, the palette, tile-map and tile
data is LZ77 compressed. I would not recommend
using this mode as the compressor is not
optimised in the slightest and compression
gained is usually minimal.

This should be enough information to use this
format in Gameboy Advance applications,
however, in the next release I will add some
simple source code showing how to do it. The
header format may also change in later versions.

Contact

e-mail:  cwiiis@hotmail.com
website: http://ChrisLord.cjb.net/

Disclaimer

As always, any damage caused to anything through
the usage of this application is in no way my
responsibility. You may not modify the executables
included with this application or distribute them
without my prior written permission. You may not
use this product in, or to aid, any commercial
application without my prior written permission.
By using this tool, you agree with the previous
statements.

Foot note

I enjoy e-mail, so if you use this tool and find it
useful, or perhaps even completely useless, I'd love
to know about it. I reply to all e-mail and all
comments will be taken on board for any future work
I happen to do. I also hope you find this tool useful,
after all - I did write it because there wasn't
anything similar about for free. Enjoy, and thanks for
downloading!