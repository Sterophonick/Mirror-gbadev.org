/**************************************************************
*	
* GBASprites.h : Fichier en-tete comprenant les elements
*                permettant la gestion des Sprites sur la GBA
*
* Cree le : 10.12.2001
* Par : Edorul (edorul@caramail.com)
*         http://www.ifrance.com/edorul/
*
* Ver. : 0.2.2
* Modifi� le 13.02.2002
*
***************************************************************/

#ifndef GBASPRITES_H
#define GBASPRITES_H

#include "GBATypes.h"
#include "GBATime.h"
#include "GBATrigo.h"

// DEFINITIONS 
//-------------

//Reglage tempo entre Tile Studio et GBATime
#define TEMPO		600

// Limites des cartes (provenant de Tile Studio)
#define B_UP		0x1	//Upper bound
#define B_LEFT		0x2	//Left bound
#define B_DOWN		0x4	//Lower bound
#define B_RIGHT		0x8	//Right bound
#define B_VERT		0x1	//Limite verticale bloque le sprite
#define B_HORIZ		0x2	//Limite horizontale bloque le sprite
#define B_NONE		0x0	//sprite non bloque
#define B_BLOCKED	0x100 //le sprite est bloqu� (fonction MapCollision_Quick)
#define B_NOTMOVED  0x200 //le sprite n'a pas boug�

// Lien du sprite par rapport au scrolling du background
#define S_FREE		0x0	//independant par rapport au background
#define S_SCROLL	0x1	//scrolle en meme temps que le background

//Boucle de l'animation du Sprite
#define LOOP_FWD		32767		//boucle infinie sens normal (FORWARD)
#define LOOP_RWD		-32768		//boucle infinie sens inverse (REWIND)

// Attribute 0 
// (pour utilisation en dehors de SetSprite_Properties: <<8 sauf Y_POS)
#define Y_POS(num)			(num)
#define ROT_FLAG			0x1
#define ROT_DS				0x2
#define MODE_NORMAL			0x0
#define MODE_TRANSPARENT	0x4
#define MODE_WINDOWED		0x8
#define SPR_MOSAIC_E		0x10
#define SPR_COLOR16			0x0
#define SPR_COLOR256		0x20
#define SHAPE_SQUARE		0x0
#define SHAPE_TALL			0x40
#define SHAPE_WIDE			0x80

// Attribute 1
// (pour utilisation en dehors de SetSprite_Properties: rien changer)
#define X_POS(num)			(num)
#define ROT_NUM(num)		((num)<<9)
#define SPR_HFLIP			0x1000
#define SPR_VFLIP			0x2000
#define SHAPE_SIZE0			0x0
#define SHAPE_SIZE1			0x4000
#define SHAPE_SIZE2			0x8000
#define SHAPE_SIZE3			0xC000

// Attribute 2
// (pour utilisation en dehors de SetSprite_Properties: >>16)
#define SPR_NUM(num)		((num)<<16)
#define SPR_PRIORITY(num)	((num)<<26)
#define SPR_PALETTE(num)	((num)<<28)

// VARIABLES 
//-----------
//Debut de la palette pour les sprites
u16		*PaletteSPR = (u16*)0x5000200;

//Debut de l'emplacement des graphismes pour les sprites
u16		*SpritesData_VRAM = (u16*)0x6010000;

//Debut OAM
u16		*SpritesOAM_RAM = (u16*)0x7000000;

spriteOAM_struct SpritesOAM[128];
spriteRot_struct *RotData = (spriteRot_struct*)SpritesOAM;

//Pour calculer la taille des sprites (en pixels en) fonction de leurs proprietes
u16		SpriteWidth[12] = {8, 16, 32, 64, 16, 32, 32, 64, 8, 8, 16, 32 };
u16		SpriteHeight[12] = {8, 16, 32, 64, 8, 8, 16, 32, 16, 32, 32, 64 };

//taleau indiquant si l'index est deja utilise (=1) ou non (=0)
u16 UsedSprIndex[128];	

// MACROS
//--------
#define D(var)			((var)>>16)  //reduction nb bits de 32 a 16 (DOWN)
#define U(var)			((var)<<16)	 //augmentation nb bits d e16 a 32 (UP)

// FONCTIONS 
//-----------

//Envoie d'une couleur dans la palette sprite
void SetPaletteSPR_Entry(u16 index, u16 color) {
	PaletteSPR[index]=color; }

//Envoie de toutes les couleurs dans la palette sprite
void SetPaletteSPR_All(u16 *emplct_colors) {
	u16 i;
	for(i=0;i<256;i++)
		PaletteSPR[i]=emplct_colors[i]; }

//Initialisation d'un sprite.
// on n'a pas a se soucier � quels attributs appartiennent les proprietes 
// ni du numero du sprite dans l'OAM :)))
// (Retourne TRUE si initialisation OK, et FALSE si plus d'index de libre dans l'OAM)
BOOL SetSprite_Properties(sprite_struct *sprite, u32 properties){
	u16 index=0;

	//recherche du premier indexOAM libre pour y placer le sprite
	while (UsedSprIndex[index])
	{
		index++;
		if (index==128)
			return 0;
	}
	UsedSprIndex[index] = 1; //donc index utilise
	sprite->NumSprite = index;
	sprite->SpriteOAM = &SpritesOAM[index];

	//Initialisation du sprite
	sprite->SpriteRot = NULL;
	sprite->NumRot = 0;
	sprite->CurrentFrame = 0;
	sprite->TimeFrame =0;
	sprite->X_Pos = 0;
	sprite->Y_Pos = 0;
	sprite->SpriteOAM->Attribute0 = properties<<8;
	sprite->SpriteOAM->Attribute1 = (u16)(properties&0x0000FF00);
	sprite->SpriteOAM->Attribute2 = properties>>16;
	sprite->Width = SpriteWidth [((sprite->SpriteOAM->Attribute0&0xC000)>>12) + ((sprite->SpriteOAM->Attribute1&0xC000)>>14)];
	sprite->Height = SpriteHeight [((sprite->SpriteOAM->Attribute0&0xC000)>>12) + ((sprite->SpriteOAM->Attribute1&0xC000)>>14)];
	sprite->Bkg = NULL;
	sprite->Loop = 0;
	sprite->Next = NULL;
	sprite->Prev = NULL;

	return TRUE;
}

//Modifie les proprites d'un sprite deja existant
void ChangeSprite_Properties(sprite_struct *sprite, u32 properties){
	sprite->SpriteOAM->Attribute0 = properties<<8;
	sprite->SpriteOAM->Attribute1 = (u16)(properties&0x0000FF00);
	sprite->SpriteOAM->Attribute2 = properties>>16;
	sprite->Width = SpriteWidth [((sprite->SpriteOAM->Attribute0&0xC000)>>12) + ((sprite->SpriteOAM->Attribute1&0xC000)>>14)];
	sprite->Height = SpriteHeight [((sprite->SpriteOAM->Attribute0&0xC000)>>12) + ((sprite->SpriteOAM->Attribute1&0xC000)>>14)];
}

//impose le numero d'index dans l'OAM sauf si l'index est deja pris
BOOL SetSprite_indexOAM(sprite_struct *sprite, u16 indexOAM){
	if (UsedSprIndex[indexOAM])
		return FALSE;

	UsedSprIndex[sprite->NumSprite] = 0; //liberation ancien index
	UsedSprIndex[indexOAM] = 1; //reservation de ce numero
	sprite->NumSprite = indexOAM;

	//Transfert du contenu des attributs
	SpritesOAM[indexOAM].Attribute0 = sprite->SpriteOAM->Attribute0;
	SpritesOAM[indexOAM].Attribute1 = sprite->SpriteOAM->Attribute1;
	SpritesOAM[indexOAM].Attribute2 = sprite->SpriteOAM->Attribute2;

	//cache la copie du sprite dans l'ancien index
	sprite->SpriteOAM->Attribute0=ROT_DS<<8;

	//Transfert effectif
	sprite->SpriteOAM = &SpritesOAM[indexOAM];

	return TRUE;
}

//Indique le numero de la rotation a utiliser pour le sprite
void SetSprite_indexRot(sprite_struct *sprite, u16 indexRot){
	sprite->NumRot = indexRot;
	sprite->SpriteRot = &RotData[indexRot];
}

//definie les valeurs de la rotation d'un des 32 index
void SetRotation_Spr(u16 indexRot, u16 AVal, u16 BVal, u16 CVal, u16 DVal){
	RotData->PA = AVal;
	RotData->PB = BVal;
	RotData->PC = CVal;
	RotData->PD = DVal;
}

// place le sprite aux coordonn�es indiqu�es et modifie X_Pos et Y_Pos
void SetSprite_Pos(sprite_struct *sprite, s32 X, s32 Y){
	s16 x, y;

	sprite->X_Pos = X;
	sprite->Y_Pos = Y;
	sprite->X_Pred = sprite->X_Pos;
	sprite->Y_Pred = sprite->Y_Pos;
	sprite->X_Dest = sprite->X_Pos;
	sprite->Y_Dest = sprite->Y_Pos;
	if (sprite->Bkg == NULL)
	{
		sprite->SpriteOAM->Attribute0 &= 0xFF00;
		sprite->SpriteOAM->Attribute0 |= (256+(Y>>16))&0xFF;
		sprite->SpriteOAM->Attribute1 &= 0xFE00;
		sprite->SpriteOAM->Attribute1 |= (512+(X>>16))&0x1FF;
	}
	else
	{
		y=256+(sprite->Y_Pred>>16)-sprite->Bkg->Scroll_Y;
		x=512+(sprite->X_Pred>>16)-sprite->Bkg->Scroll_X;
		if ((y>191)&&(y<512)) //partie visible de l'ecran((y>191)&&(y<512))
		{
			sprite->SpriteOAM->Attribute0 &= 0xFF00;
			sprite->SpriteOAM->Attribute0 |= y&0xFF;
		}
		else //sprite place en dehors de la zone d'affichage
		{
			sprite->SpriteOAM->Attribute0 &= 0xFF00;
			sprite->SpriteOAM->Attribute0 |= 160&0xFF;
		}
		if ((x>447)&&(x<1024)) //partie visible de l'ecran((x>447)&&(x<1024))
		{
			sprite->SpriteOAM->Attribute1 &= 0xFE00;
			sprite->SpriteOAM->Attribute1 |= x&0x1FF;
		}
		else //sprite place en dehors de la zone d'affichage
		{
			sprite->SpriteOAM->Attribute1 &= 0xFE00;
			sprite->SpriteOAM->Attribute1 |= 240&0x1FF;
		}
	}
}

//Lie le sprite � un Background (i.e. pour le scrolling)
void SetSprite_Bkg(sprite_struct *sprite, bkg_struct *Bkg)
{
	sprite->Bkg = Bkg;
}

// deplace le sprite a l'emplacement prevu (Pos = Pred)
void MoveSprite (sprite_struct *sprite){
	s16 x, y;

	sprite->X_Pos = sprite->X_Pred;
	sprite->Y_Pos = sprite->Y_Pred;
	if (sprite->Bkg == NULL)
	{
		sprite->SpriteOAM->Attribute0 &= 0xFF00;
		sprite->SpriteOAM->Attribute0 |= (256+(sprite->Y_Pred>>16))&0xFF;
		sprite->SpriteOAM->Attribute1 &= 0xFE00;
		sprite->SpriteOAM->Attribute1 |= (512+(sprite->X_Pred>>16))&0x1FF;
	}
	else
	{
		y=256+(sprite->Y_Pred>>16)-sprite->Bkg->Scroll_Y;
		x=512+(sprite->X_Pred>>16)-sprite->Bkg->Scroll_X;
		if ((y>191)&&(y<512)) //partie visible de l'ecran((y>191)&&(y<512))
		{
			sprite->SpriteOAM->Attribute0 &= 0xFF00;
			sprite->SpriteOAM->Attribute0 |= y&0xFF;
		}
		if ((x>447)&&(x<1024)) //partie visible de l'ecran((x>447)&&(x<1024))
		{
			sprite->SpriteOAM->Attribute1 &= 0xFE00;
			sprite->SpriteOAM->Attribute1 |= x&0x1FF;
		}
	}
}

// initialise l'animation a utiliser pour le sprite 
//  (Loop = nb de boucles, 0xFFFF reserve a LOOP = infinie)
void SetSprite_Anim(sprite_struct *sprite, sequence_struct Anim, u16 Loop){
	sprite->Animation = Anim;
	sprite->CurrentFrame = 0;
	sprite->TimeFrame = GetTicks();
	sprite->Loop = Loop;
}

// change l'animation du sprite (conserve CurrentFrame et TimeFrame)
//     Si le numero de la frame en cours d'affichage est superieure 
//     au nombre de frames de la nouvelle animation alors remise a zero
void Change_Anim(sprite_struct *sprite, sequence_struct Anim, u16 Loop){
	u16 temp = sprite->SpriteOAM->Attribute2 & 0xFE00; //conserve propriete & palette

	sprite->Animation = Anim;
	if (sprite->CurrentFrame >= Anim.SequenceLength)
		sprite->CurrentFrame = 0;

	sprite->Loop = Loop;

	sprite->SpriteOAM->Attribute2 = temp + (SPR_NUM(sprite->Animation.TileNum[sprite->CurrentFrame]*4*2)>>16);
}


//Mise � jour de l'animation d'un sprite
void AnimSprite(sprite_struct *sprite){
	u16 temp = sprite->SpriteOAM->Attribute2 & 0xFE00; //conserve propriete & palette

	if(sprite->Loop > 0) //animation sens normal (FORWARD)
	{
		if ((GetTicks()-sprite->TimeFrame)>sprite->Animation.Duration[sprite->CurrentFrame]*TEMPO)
		{
			sprite->CurrentFrame = (sprite->CurrentFrame+1)%sprite->Animation.SequenceLength;
			sprite->SpriteOAM->Attribute2 = temp + (SPR_NUM(sprite->Animation.TileNum[sprite->CurrentFrame]*4*2)>>16);
			sprite->TimeFrame = GetTicks();
			if(sprite->Loop != LOOP_FWD) //animation nombre finie de boucles
				if(sprite->CurrentFrame==(sprite->Animation.SequenceLength-1))	//animation terminee (arrive derniere Frame)
				sprite->Loop--;		//donc decrementer nombre d'anim restantes
		}
	}
	if(sprite->Loop < 0) //animation sens inverse (REWIND)
	{
		if ((GetTicks()-sprite->TimeFrame)>sprite->Animation.Duration[sprite->CurrentFrame]*TEMPO)
		{
			if(sprite->CurrentFrame==0) //
				sprite->CurrentFrame = sprite->Animation.SequenceLength;
			sprite->CurrentFrame = (sprite->CurrentFrame-1)%sprite->Animation.SequenceLength;
			sprite->SpriteOAM->Attribute2 = temp + (SPR_NUM(sprite->Animation.TileNum[sprite->CurrentFrame]*4*2)>>16);
			sprite->TimeFrame = GetTicks();
			if(sprite->Loop != LOOP_RWD) //animation nombre finie de boucles
				if(sprite->CurrentFrame==0)	//animation terminee (arrive premiere Frame)
				sprite->Loop++;		//donc incrementer (car nb negatif) nombre d'anim restantes
		}
	}
	// si Loop = 0 donc pas d'animation et bye-bye...
}

// Mise en place des Sprites en Memoire video
void Transfert_Sprites(tile_struct *Tiles){
	u16 i;

	// VidMemLocation pointe maintenant vers l'emplacement en memoire des tiles
	Tiles->VidMemLocation = SpritesData_VRAM;

	// Mise en place de donnees des Tiles 2 bytes � la fois
	//    car Mem video 16 bits et donnees Tiles valeurs sur 8 bits 
	for(i = 0; i < Tiles->TileWidth * Tiles->TileHeight * Tiles->TilesNb /2 ; i++)
		SpritesData_VRAM[i] = (Tiles->TilesData[2*i+1]<<8)+Tiles->TilesData[2*i];
}

// copie les proprietes d'un sprite dans l'OAM
void RefreshSprite(sprite_struct *sprite){
	u16 i;
	u16* temp;
	//copie les proprietes du sprite dans l'OAM
	temp = (u16*)SpritesOAM;
	for(i = 0; i < 4; i++)
	{
		SpritesOAM_RAM[sprite->NumSprite*4+i] = temp[sprite->NumSprite*4+i];
	}
}

// copie les proprietes de tous les sprites dans l'OAM
void RefreshSprite_All(void){
	u16 i;
	u16* temp;
	//copie les proprietes de tous les sprites dans l'OAM
	temp = (u16*)SpritesOAM;
	for(i = 0; i < 128*4; i++)
	{
		SpritesOAM_RAM[i] = temp[i];
	}
}

// Cache un seul sprite
void HideSprite(sprite_struct *sprite){
	sprite->SpriteOAM->Attribute0=ROT_DS<<8;
}

// Cache tous les sprites
void HideSprite_All(){
	u16 i;

	//mettre les sprites en Rotation Double Size Mode
	for(i=0; i<128; i++)
		SpritesOAM[i].Attribute0=ROT_DS<<8;

	//attente de la synchro verticale
	while((*(volatile u16*)0x4000006)<160){}

	//mise � jour des attributs des sprites dans la RAM de la GBA
	RefreshSprite_All();
}

// detecte si le sprite entre en collision avec des limites de la map
// renvoie les directions de blocage (verticale ou horizontale) du sprite ou 0 si non bloqu�
u16 MapCollision(sprite_struct sprite, bkg_struct bkg){
	u16 Tile_A, Tile_B, Tile_C, Tile_D;
	u16 Sprite_Width, Sprite_Height;
	s16 X_Pred, Y_Pred, X_Pos, Y_Pos;
	s16 H_Dir, V_Dir;
	u16 Result=B_NONE;

	Sprite_Width = sprite.Width;
	Sprite_Height = sprite.Height;

	if(sprite.Bkg==NULL)
	{
		X_Pos = (sprite.X_Pos>>16)+bkg.Scroll_X;
		Y_Pos = (sprite.Y_Pos>>16)+bkg.Scroll_Y;
		X_Pred = (sprite.X_Pred>>16)+bkg.Scroll_X+bkg.Deplct_X;
		Y_Pred = (sprite.Y_Pred>>16)+bkg.Scroll_Y+bkg.Deplct_Y;
	}
	else
	{
		X_Pos = sprite.X_Pos>>16;
		Y_Pos = sprite.Y_Pos>>16;
		X_Pred = sprite.X_Pred>>16;
		Y_Pred = sprite.Y_Pred>>16;
	}

	Tile_A = X_Pred/bkg.Map->Tiles->TileWidth + Y_Pred/bkg.Map->Tiles->TileHeight*bkg.Map->MapWidth;
	Tile_B = (X_Pred+Sprite_Width-1)/bkg.Map->Tiles->TileWidth 
				+ Y_Pred/bkg.Map->Tiles->TileHeight*bkg.Map->MapWidth;						// A     B
	Tile_C = (X_Pred+Sprite_Width-1)/bkg.Map->Tiles->TileWidth								//  *---*
				+ (Y_Pred+Sprite_Height-1)/bkg.Map->Tiles->TileHeight*bkg.Map->MapWidth;	//  |   |
	Tile_D = X_Pred/bkg.Map->Tiles->TileWidth												//  *---*
				+ (Y_Pred+Sprite_Height-1)/bkg.Map->Tiles->TileHeight*bkg.Map->MapWidth;	// D     C

	H_Dir = X_Pred - X_Pos;
	V_Dir = Y_Pred - Y_Pos;

	if (H_Dir>0)
	{
		if (V_Dir==0)
			if ((bkg.Map->Bounds[Tile_B]&B_LEFT)||(bkg.Map->Bounds[Tile_C]&B_LEFT))
				Result = B_HORIZ;
		if (V_Dir>0)
			if ((bkg.Map->Bounds[Tile_D]&B_UP)||(bkg.Map->Bounds[Tile_C]&B_UP)
					||(bkg.Map->Bounds[Tile_C]&B_LEFT)||(bkg.Map->Bounds[Tile_B]&B_LEFT))
				Result = B_VERT|B_HORIZ;
		if (V_Dir<0)
			if ((bkg.Map->Bounds[Tile_A]&B_DOWN)||(bkg.Map->Bounds[Tile_B]&B_DOWN)
					||(bkg.Map->Bounds[Tile_B]&B_LEFT)||(bkg.Map->Bounds[Tile_C]&B_LEFT))
				Result = B_VERT|B_HORIZ;
	}

	if (H_Dir==0)
	{
		if (V_Dir==0)
			Result = B_NOTMOVED;
		if (V_Dir>0)
			if ((bkg.Map->Bounds[Tile_C]&B_UP)||(bkg.Map->Bounds[Tile_D]&B_UP))
				Result = B_VERT;
		if (V_Dir<0)
			if ((bkg.Map->Bounds[Tile_A]&B_DOWN)||(bkg.Map->Bounds[Tile_B]&B_DOWN))
				Result = B_VERT;
	}

	if (H_Dir<0)
	{
		if (V_Dir==0)
			if ((bkg.Map->Bounds[Tile_A]&B_RIGHT)||(bkg.Map->Bounds[Tile_D]&B_RIGHT))
				Result = B_HORIZ;
		if (V_Dir>0)
			if ((bkg.Map->Bounds[Tile_A]&B_RIGHT)||(bkg.Map->Bounds[Tile_D]&B_RIGHT)
					||(bkg.Map->Bounds[Tile_D]&B_UP)||(bkg.Map->Bounds[Tile_C]&B_UP))
				Result = B_VERT|B_HORIZ;
		if (V_Dir<0)
			if ((bkg.Map->Bounds[Tile_B]&B_DOWN)||(bkg.Map->Bounds[Tile_A]&B_DOWN)
					||(bkg.Map->Bounds[Tile_A]&B_RIGHT)||(bkg.Map->Bounds[Tile_D]&B_RIGHT))
				Result = B_VERT|B_HORIZ;
	}
	return Result;
}

// detecte si le sprite entre en collision avec des limites de la map
// fonction rapide renvoie B_BLOCKED si sprite est sur une tile avec Bound != 0
// et renvoie B_NONE si Bound = 0
u16 MapCollision_Quick(sprite_struct sprite, bkg_struct bkg){
	u16 Tile_A, Tile_B, Tile_C, Tile_D;
	u16 Sprite_Width, Sprite_Height;
	s16 X_Pred, Y_Pred, X_Pos, Y_Pos;
	u16 Result=B_NONE;

	Sprite_Width = sprite.Width;
	Sprite_Height = sprite.Height;

	if(sprite.Bkg==NULL)
	{
		X_Pos = (sprite.X_Pos>>16)+bkg.Scroll_X;
		Y_Pos = (sprite.Y_Pos>>16)+bkg.Scroll_Y;
		X_Pred = (sprite.X_Pred>>16)+bkg.Scroll_X+bkg.Deplct_X;
		Y_Pred = (sprite.Y_Pred>>16)+bkg.Scroll_Y+bkg.Deplct_Y;
	}
	else
	{
		X_Pos = sprite.X_Pos>>16;
		Y_Pos = sprite.Y_Pos>>16;
		X_Pred = sprite.X_Pred>>16;
		Y_Pred = sprite.Y_Pred>>16;
	}

	Tile_A = X_Pred/bkg.Map->Tiles->TileWidth + Y_Pred/bkg.Map->Tiles->TileHeight*bkg.Map->MapWidth;
	Tile_B = (X_Pred+Sprite_Width-1)/bkg.Map->Tiles->TileWidth 
				+ Y_Pred/bkg.Map->Tiles->TileHeight*bkg.Map->MapWidth;						// A     B
	Tile_C = (X_Pred+Sprite_Width-1)/bkg.Map->Tiles->TileWidth								//  *---*
				+ (Y_Pred+Sprite_Height-1)/bkg.Map->Tiles->TileHeight*bkg.Map->MapWidth;	//  |   |
	Tile_D = X_Pred/bkg.Map->Tiles->TileWidth												//  *---*
				+ (Y_Pred+Sprite_Height-1)/bkg.Map->Tiles->TileHeight*bkg.Map->MapWidth;	// D     C

	if (bkg.Map->Bounds[Tile_A])
		Result = B_BLOCKED;
	if (bkg.Map->Bounds[Tile_B])
		Result = B_BLOCKED;
	if (bkg.Map->Bounds[Tile_C])
		Result = B_BLOCKED;
	if (bkg.Map->Bounds[Tile_D])
		Result = B_BLOCKED;

	return Result;
}

// obtention du Bound sur l'emplacement du centre d'un sprite
u16 GetMap_Bound(sprite_struct sprite, bkg_struct bkg){
	u16 Tile_A;
	s16 X_Pos, Y_Pos;
	u16 Result=B_NONE;

	if(sprite.Bkg==NULL)
	{
		X_Pos = (sprite.X_Pos>>16)+bkg.Scroll_X+sprite.Width/2;
		Y_Pos = (sprite.Y_Pos>>16)+bkg.Scroll_Y+sprite.Width/2;
	}
	else
	{
		X_Pos = (sprite.X_Pos>>16)+sprite.Width/2;
		Y_Pos = (sprite.Y_Pos>>16)+sprite.Height/2;
	}

	Tile_A = X_Pos/bkg.Map->Tiles->TileWidth + Y_Pos/bkg.Map->Tiles->TileHeight*bkg.Map->MapWidth;

	Result = bkg.Map->Bounds[Tile_A];

	return Result;
}

// obtention du Code sur l'emplacement du centre d'un sprite
u16 GetMap_Code(sprite_struct sprite, bkg_struct bkg){
	u16 Tile_A;
	s16 X_Pos, Y_Pos;
	u16 Result=B_NONE;

	if(sprite.Bkg==NULL)
	{
		X_Pos = (sprite.X_Pos>>16)+bkg.Scroll_X+sprite.Width/2;
		Y_Pos = (sprite.Y_Pos>>16)+bkg.Scroll_Y+sprite.Width/2;
	}
	else
	{
		X_Pos = (sprite.X_Pos>>16)+sprite.Width/2;
		Y_Pos = (sprite.Y_Pos>>16)+sprite.Height/2;
	}

	Tile_A = X_Pos/bkg.Map->Tiles->TileWidth + Y_Pos/bkg.Map->Tiles->TileHeight*bkg.Map->MapWidth;

	Result = bkg.Map->MapCode[Tile_A];

	return Result;
}

#endif

