/**************************************************************
*	
* GBAInput.h : Fichier en-tete comprenant les elements
*              permettant l'utilisation du JoyPad de la GBA
*
* Cree le : 18.11.2001
* Par : Edorul (edorul@caramail.com)
*         http://www.ifrance.com/edorul/
*
* Ver. : 0.2.0
* Modifi� le 30.11.2001
*
***************************************************************/

#ifndef GBAINPUT_H
#define GBAINPUT_H

#include "GBATypes.h"

// DEFINITIONS 
//-------------

// definition du registre KEYS_REG
#define KEYS_REG		*(volatile u16*)0x4000130
#define K_A				0x1
#define K_B				0x2
#define K_SELECT		0x4
#define K_START			0x8
#define K_RIGHT			0x10
#define K_LEFT			0x20
#define K_UP			0x40
#define K_DOWN			0x80
#define K_R				0x100
#define K_L				0x200
#define K_NONE			0x0
#define K_ALL			0x3FF

// MACROS 
//--------

//verification si une des touches est pressee
//   si = 0 touches non pressees
//   si = 1 touche pressee
#define KEY_DOWN(keys)		~(KEYS_REG | 0xFC00) & (keys) 

//verification si une des touches est relachee
//   si = 0 touches non relachees
//   si = 1 touche relachee
#define KEY_UP(keys)		!(~(KEYS_REG | 0xFC00) & (keys)) 

//attente que au moins l'une des touches 
// passee en argument soit pressee
void Wait_KeyDown(u16 keys){
	while (KEY_UP(keys));
}
 
//attente que des touches soient relachees ###fonctionne pas super...mais OK pour K_ALL et K_NONE :)
void Wait_KeyUp(u16 keys){
	while (KEY_DOWN(keys));
}

// renvoi dans une variable les touches pressees
u16 GetKeys(void){
	return (u32)~(KEYS_REG | 0xFC00);
}

#endif

