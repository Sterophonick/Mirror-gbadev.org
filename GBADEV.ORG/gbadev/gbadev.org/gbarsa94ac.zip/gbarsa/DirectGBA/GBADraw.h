/**************************************************************
*	
* GBADraw.h : Fichier en-tete comprenant les elements
*             communs a GBADrawBitmap et GBADrawTiles
*
* Cree le : 16.08.2001
* Par : Edorul (edorul@caramail.com)
*         http://www.ifrance.com/edorul/
*
* Ver. : 0.4.2
* Modifi� le 28.02.2002
*
***************************************************************/

#ifndef GBADRAW_H
#define GBADRAW_H

#include "GBATypes.h"
#include "GBATrigo.h"

/////////////////////////////////////////////////
/////////////////////////////////////////////////
// Elements communs aux modes Bitmaps et Tiles //
/////////////////////////////////////////////////
/////////////////////////////////////////////////

// DEFINITIONS 
//-------------

// definition du registre DISP_CR
#define DISP_CR			*(u16*)0x4000000
#define TESTMODE		0x7	//pour tester le Mode
#define MODE(num)		(num)
#define MODE0			0x0
#define MODE1			0x1
#define MODE2			0x2
#define MODE3			0x3
#define MODE4			0x4
#define MODE5			0x5
#define GBC				0x8
#define BACKBUFFER		0x10
#define HB_OAM			0x20
#define SPR_2D			0x0
#define SPR_1D			0x40
#define FB				0x80
#define BG(num)			(1<<(8+(num)))
#define BG0				0x100
#define BG1				0x200
#define BG2				0x400
#define BG3				0x800
#define SPR				0x1000
#define WIN0			0x2000
#define WIN1			0x4000
#define SWE				0x8000

// definition du registre DISP_SR
#define DISP_SR			*(volatile u16*)0x4000004
#define IN_VBLANK		0x1
#define IN_HBLANK		0x2
#define Y_TRIG			0x4
#define E_VBLANK		0x8
#define E_HBLANK		0x10
#define E_Y_TRIG		0x20
#define Y_TRIG_VAL		0xff00

// definition du registre DISP_Y
#define DISP_Y			*(volatile u16*)0x4000006
#define CUR_SCANLINE	0xff

// MACROS 
//--------

//RGB -> hexa (16bits)
#define RGB(r,g,b)		((r)+((g)<<5)+((b)<<10)) 
//BGR -> hexa (16bits)
#define BGR(b,g,r)		((r)+((g)<<5)+((b)<<10)) 

///////// DISP_CR ///////////
//ecriture DISP_CR buffer
#define SetVideoMode(mode) DISP_CR=(mode)
#define SetDISP_CR(mode) DISP_CR=(mode)

//ajouter les options passees en argument a DISP_CR
#define EnableVideoMode(mode) DISP_CR|=(mode)
#define EnableDISP_CR(mode) DISP_CR|=(mode)

//supprime les options de DISP_CR passees en argument
#define DisableVideoMode(mode) DISP_CR&=~(mode)
#define DisableDISP_CR(mode) DISP_CR&=~(mode)

///////// DISP_SR ///////////
//ecriture DISP_SR buffer
#define SetDISP_SR(mode) DISP_SR=(mode)

//ajouter les options passees en argument a DISP_SR
#define EnableDISP_SR(mode) DISP_SR|=(mode)

//supprime les options de DISP_SR passees en argument
#define DisableDISP_SR(mode) DISP_SR&=~(mode)

// FONCTIONS 
//-----------

//-----------------------
// Lecture des Registres
//-----------------------
//lecture DISP_CR buffer
u16 GetVideoMode() { return DISP_CR; } 
u16 GetDISP_CR() { return DISP_CR; } 

//lecture DISP_SR buffer
u16 GetDISP_SR() { return DISP_SR; }

//lecture DISP_Y buffer
u16 GetDISP_Y() { return DISP_Y; }


//-------------------------------
// definition des memoires video
//-------------------------------
u16		*VideoBuffer = (u16*)0x6000000;
u16		*VideoFrontBuffer = (u16*)0x6000000;
u16		*VideoBackBuffer = (u16*)0x600a000;

//--------------------------
// Utilisation des Palettes
//--------------------------
u16		*PaletteBKG	= (u16*)0x5000000;

//Envoie d'une couleur dans la palette background
void SetPaletteBKG_Entry(u16 index, u16 color) {
	PaletteBKG[index]=color; }

//Envoie de toutes les couleurs dans la palette background
void SetPaletteBKG_All(const u16 *emplct_colors) {
	u16 i;
	for(i=0;i<256;i++)
		PaletteBKG[i]=emplct_colors[i]; }

//Envoie de n couleurs dans la palette background
void SetPaletteBKG_N(const u16 *emplct_colors,u16 nb_col) {
	u16 i;
	for(i=0;i<nb_col;i++)
		PaletteBKG[i]=emplct_colors[i]; }

//Attente de la synchro verticale
void WaitVBLANK(void){
	while(DISP_Y<160){}
}

////////////////////////////////////////
////////////////////////////////////////
// Elements propres aux modes Bitmaps //
////////////////////////////////////////
////////////////////////////////////////

// FONCTIONS 
//-----------

//-------------------------------------------------------------
// Fonctions pour l'affichage de Pixels
//
// les numeros a la fin des fonctions indiquent pour quel mode 
// elles doivent etre utilisees
//-------------------------------------------------------------

//Affichage d'un pixel aux coordonnees (x,y) dans le mode 3
// de la couleur desiree
void PlotPixel3 (u16 x, u16 y, u16 color) { 
	VideoBuffer[x + 240 * y]=color; }

//Obtention de la couleur du pixel de coordonnees (x,y) dans le mode 3
u16 GetPixel3 (u16 x, u16 y) { 
	return VideoBuffer[x+240*y]; }

//Affichage � l'�cran d'un image de 240x160 pixels contenue
// dans la variable *img
void DrawImg3 (const u16 *img) {
	u16 i, j;

	for (j=0; j<160; j++)
		for (i=0; i<240; i++)
			VideoBuffer[i+240*j]=img[i+j*240];
}

//Affichage � l'�cran d'une image de w*h pixels contenue
// dans la variable *img aux coordonn�es x,y
void DrawSubImg3 (u16 x, u16 y, const u16 *img, u16 w, u16 h) {
	u16 i, j;

	for (j=y; j<y+h; j++)
		for (i=x; i<x+w; i++)
			VideoBuffer[i+240*j]=img[(i-x)+(j-y)*w];
}

//Affichage d'un pixel aux coordonnees (x,y) dans le mode 4
// de la couleur desiree (provenant de la palette) 
void PlotPixel4 (u16 x, u16 y, u16 index) { 
	u16 half, peek, send;
	
	half = x>>1;
	peek = VideoBuffer[half+y*120];

	if (x!=(half<<1))
		send = (0x00ff&peek) + (index<<8);
	else
		send = (0xff00&peek) + index;

	VideoBuffer[half+y*120] = send; }

//Obtention du numero dans la palette de la couleur du pixel 
// de coordonnees (x,y) dans le mode 4
u8 GetPixel4 (u16 x, u16 y) { 
	u16 half, peek, send;

	half = x>>1;
	peek = VideoBuffer[half+y*120];

	if (x!=(half<<1))
		send = (0xff00&peek) >> 8;
	else
		send = 0x00ff&peek;

	return (u8)send; }

//Affichage des pixels aux coordonnees (i*2,j) et (i*2+1,j) dans le mode 4
// des couleurs desirees (provenant de la palette)
void SendPixels4 (u16 i, u16 j, u16 indexes) { 
	VideoBuffer[i + 120 * j]=indexes; } 

//Obtention des numeros dans la palette des couleurs des pixels 
// de coordonnees (i*2,j) et (i*2+1,j) dans le mode 4
u16 ReceivePixels4 (u16 i, u16 j) { 
	return VideoBuffer[i+120*j]; } 

//Affichage � l'�cran d'un image de 240x160 pixels contenue
// dans la variable *img
void DrawImg4 (u16 *img) {
	u16 i, j;

	for (j=0; j<160; j++)
		for (i=0; i<120; i++)
			VideoBuffer[i+120*j]=img[i+j*120];
}

//Affichage d'un pixel aux coordonnees (x,y) dans le mode 5
// de la couleur desiree
void PlotPixel5 (u16 x, u16 y, u16 color) { 
	VideoBuffer[x + 160 * y]=color; }

//Obtention de la couleur du pixel de coordonnees (x,y) dans le mode 5
u16 GetPixel5 (u16 x, u16 y) { 
	return VideoBuffer[x+160*y]; }

//Affichage � l'�cran d'un image de 160x128 pixels contenue
// dans la variable *img
void DrawImg5 (u16 *img) {
	u16 i, j;

	for (j=0; j<128; j++)
		for (i=0; i<160; i++)
			VideoBuffer[i+160*j]=img[i+j*160];
}

//Affichage d'un pixel aux coordonnees (x,y) de la couleur desiree  
void PlotPixel (u16 x, u16 y, u16 color) { 
	switch (DISP_CR & TESTMODE)
	{
	case 3:
		PlotPixel3 (x, y, color);
		break;
	case 4:
		PlotPixel4 (x, y, color);
		break;
	case 5:
		PlotPixel5 (x, y, color);
		break;
	}
}

//Obtention de la couleur du pixel de coordonnees (x,y)
u16 GetPixel (u16 x, u16 y) { 
	switch (DISP_CR & TESTMODE)
	{
	case 3:
		return GetPixel3 (x, y);
		break;
	case 4:
		return GetPixel4 (x, y);
		break;
	case 5:
		return GetPixel5 (x, y);
		break;
	}
	return 0;
}

//Affichage � l'�cran d'un image contenue dans la variable *img
void DrawImg (u16 *img) {
	switch (DISP_CR & TESTMODE)
	{
	case 3:
		DrawImg3 (img);
		break;
	case 4:
		DrawImg4 (img);
		break;
	case 5:
		DrawImg5 (img);
		break;
	}
}

//------------------------------------
// Fonctions pour le Double-Buffering
//------------------------------------

//Basculement FrontBuffer / BackBuffer
void Flip(){
	WaitVBLANK();
	if (DISP_CR & BACKBUFFER){
		DISP_CR &= ~BACKBUFFER;
		VideoBuffer = VideoBackBuffer;
	}
	else {
		DISP_CR |= BACKBUFFER;
		VideoBuffer = VideoFrontBuffer;
	}
}

//////////////////////////////////////
//////////////////////////////////////
// Elements propres aux modes Tiles //
//////////////////////////////////////
//////////////////////////////////////

// DEFINITIONS 
//-------------

// definition des registres BGx_CR
#define PRIORITY(num)	(num)
#define PRIORITY0		0x00	// Priority 0
#define PRIORITY1		0x01	// Priority 1
#define PRIORITY2		0x02	// Priority 2
#define PRIORITY3		0x03	// Priority 3
#define TILEBLOCK(num)	((num)<<2)
#define TILEBLOCK0		0x00	// Tile Base Block 0
#define TILEBLOCK1		0x04	// Tile Base Block 1
#define TILEBLOCK2		0x08	// Tile Base Block 2
#define TILEBLOCK3		0x0c	// Tile Base Block 3
#define BKG_MOSAIC_E	0x40	// Mosaic Enable
#define COLOR16			0x00	// 16 colors mode
#define COLOR256		0x80	// 256 collors mode
#define MAPBLOCK(num)	((num)<<8)
#define MAPBLOCK0		0x00	// Screen Base Block 0 (Map Block)
#define MAPBLOCK1		0x0100	// Screen Base Block 1 (Map Block)
#define MAPBLOCK2		0x0200	// Screen Base Block 2 (Map Block)
#define MAPBLOCK3		0x0300	// Screen Base Block 3 (Map Block)
#define MAPBLOCK4		0x0400	// Screen Base Block 4 (Map Block)
#define MAPBLOCK5		0x0500	// Screen Base Block 5 (Map Block)
#define MAPBLOCK6		0x0600	// Screen Base Block 6 (Map Block)
#define MAPBLOCK7		0x0700	// Screen Base Block 7 (Map Block)
#define MAPBLOCK8		0x0800	// Screen Base Block 8 (Map Block)
#define MAPBLOCK9		0x0900	// Screen Base Block 9 (Map Block)
#define MAPBLOCK10		0x0a00	// Screen Base Block 10 (Map Block)
#define MAPBLOCK11		0x0b00	// Screen Base Block 11 (Map Block)
#define MAPBLOCK12		0x0c00	// Screen Base Block 12 (Map Block)
#define MAPBLOCK13		0x0d00	// Screen Base Block 13 (Map Block)
#define MAPBLOCK14		0x0e00	// Screen Base Block 14 (Map Block)
#define MAPBLOCK15		0x0f00	// Screen Base Block 15 (Map Block)
#define MAPBLOCK16		0x1000	// Screen Base Block 16 (Map Block)
#define MAPBLOCK17		0x1100	// Screen Base Block 17 (Map Block)
#define MAPBLOCK18		0x1200	// Screen Base Block 18 (Map Block)
#define MAPBLOCK19		0x1300	// Screen Base Block 19 (Map Block)
#define MAPBLOCK20		0x1400	// Screen Base Block 20 (Map Block)
#define MAPBLOCK21		0x1500	// Screen Base Block 21 (Map Block)
#define MAPBLOCK22		0x1600	// Screen Base Block 22 (Map Block)
#define MAPBLOCK23		0x1700	// Screen Base Block 23 (Map Block)
#define MAPBLOCK24		0x1800	// Screen Base Block 24 (Map Block)
#define MAPBLOCK25		0x1900	// Screen Base Block 25 (Map Block)
#define MAPBLOCK26		0x1a00	// Screen Base Block 26 (Map Block)
#define MAPBLOCK27		0x1b00	// Screen Base Block 27 (Map Block)
#define MAPBLOCK28		0x1c00	// Screen Base Block 28 (Map Block)
#define MAPBLOCK29		0x1d00	// Screen Base Block 29 (Map Block)
#define MAPBLOCK30		0x1e00	// Screen Base Block 30 (Map Block)
#define MAPBLOCK31		0x1f00	// Screen Base Block 31 (Map Block)
#define WRAP			0x2000	//Wrap around Enable
#define SIZE(num)		((num)<<14)
#define SIZE0			0x00	// Taille de carte 0
#define SIZE1			0x4000	// Taille de carte 1
#define SIZE2			0x8000	// Taille de carte 2
#define SIZE3			0xc000	// Taille de carte 3

//adresse registre pour utiliser la mosaique
// meme adresse que pour les sprites mais nom different pour eviter conflits
#define BKG_MOSAIC		*(u16*)0x400004C

//definitions pour utiliser le Fading et l'Alpha-Blending
#define BLEND_CR		*(u16*)0x4000050
#define BLEND_AB		*(u16*)0x4000052
#define BLEND_Y			*(u16*)0x4000054
#define FADE_IN			0x80
#define FADE_OUT		0xC0
#define ALPHA			0x40
#define BD				0x2000	//5eme Background

//declaration pour le type de Zoom a employer
#define AXE_SCREEN		0
#define AXE_BKG			1

// MACROS 
//--------

//calcul de l'adresse en mem vid�o du TileBlock utilis�
#define TileBlockAddress(num)	(0x6000000+0x4000*(num))

//calcul de l'adresse en mem vid�o du MapBlock utilis�
#define MapBlockAddress(num)	(0x6000000+0x800*(num))

//calcul de l'adresse du registre BGx_CR utilis�
#define BGx_CRAddress(num)		(0x4000008+0x02*(num))

// FONCTIONS 
//-----------
void Transfert_Map(bkg_struct *, map_struct *);

///-----------------------------------
// Lecture et �criture des Registres
//    des Backgrounds
//-----------------------------------

//Adresses de registres pour les Scrollings des Bkgs de type Rotation
const u32 BGx_XRot[] = {0, 0, 0x4000028, 0x4000038};
const u32 BGx_YRot[] = {0, 0, 0x400002C, 0x400003C};

//Adresses de registres pour les Scrollings des Bkgs de type Text
const u32 BGx_XTxt[] = {0x4000010, 0x4000014, 0x4000018, 0x400001C};
const u32 BGx_YTxt[] = {0x4000012, 0x4000016, 0x400001A, 0x400001E};

//Adresses de registres pour les Rotations des Bkgs de type Rotation
const u32 BGx_HDX[] = {0, 0, 0x4000020, 0x4000030};		// coef A
const u32 BGx_VDX[] = {0, 0, 0x4000022, 0x4000032};		// coef B
const u32 BGx_HDY[] = {0, 0, 0x4000024, 0x4000034};		// coef C
const u32 BGx_VDY[] = {0, 0, 0x4000026, 0x4000036};		// coef D

// ecriture BGx_CR buffer et d�finition de la bkg_struct associ�e
void SetBGx_CR(bkg_struct *Background, u16 num, u16 mode){
	Background->Register = (u16*)BGx_CRAddress(num);
	*Background->Register = mode;
	Background->Scroll_X = 0;
	Background->Scroll_Y = 0;
	Background->Center_X = 0;
	Background->Center_Y = 0;
	Background->Zoom_X = 1<<8;
	Background->Zoom_Y = 1<<8;
	Background->ZoomType = AXE_SCREEN;
	Background->Num = num;
//	Background->TileBlock = (mode & 0x000c) >> 2;
//	Background->MapBlock = (mode & 0x1f00) >> 8;
	Background->TileData = (u16*)TileBlockAddress((mode & 0x000c) >> 2);
	Background->MapData = (u16*)MapBlockAddress((mode & 0x1f00) >> 8);
//	Background->Priority = mode & 0x03;
//	Background->Mosaic = (mode & 0x40) >> 6;
//	Background->NbColors = 16 + ((mode & 0x80) >> 7) * 240;
	Background->ScreenSize = (mode & 0xc000) >> 14;
	Background->Bound = 0;
}

//ajouter les options passees en argument a BGx_CR et modif de BKGx
void EnableBGx_CR(bkg_struct *Background, u16 mode){
	*Background->Register |= mode;
//	Background->TileBlock = (mode & 0x000c) >> 2;
//	Background->MapBlock = (mode & 0x1f00) >> 8;
	Background->TileData = (u16*)TileBlockAddress((mode & 0x000c) >> 2);
	Background->MapData = (u16*)MapBlockAddress((mode & 0x1f00) >> 8);
//	Background->Priority = mode & 0x03;
//	Background->Mosaic = (mode & 0x40) >> 6;
//	Background->NbColors = 16 + ((mode & 0x80) >> 7) * 240;
	Background->ScreenSize = (mode & 0xc000) >> 14;
}

//supprime les options de BGx_CR passees en argument et modif de BKGx
void DisableBGx_CR(bkg_struct *Background, u16 mode){
	*Background->Register &= ~mode;
//	Background->TileBlock = (mode & 0x000c) >> 2;
//	Background->MapBlock = (mode & 0x1f00) >> 8;
	Background->TileData = (u16*)TileBlockAddress((mode & 0x000c) >> 2);
	Background->MapData = (u16*)MapBlockAddress((mode & 0x1f00) >> 8);
//	Background->Priority = mode & 0x03;
//	Background->Mosaic = (mode & 0x40) >> 6;
//	Background->NbColors = 16 + ((mode & 0x80) >> 7) * 240;
	Background->ScreenSize = (mode & 0xc000) >> 14;
}

// Changement d'affichage du decors dans un autre Background
//   (toutes les proprietes de l'ancien Background sont transferees
//     dans le nouveau et sont supprimees dans l'ancien)
// il est maintenant iniutile de recharger la Map pour les Sizes 2 en Bkg type text
void ChangeBGx_CR(bkg_struct *Background, u16 num){
	u16 mode;

	//SIZE2 et Bkg type text rechargement de la Map
	if (((DISP_CR & TESTMODE)==2)&&((num==2)||(Background->Num==2)))
		Transfert_Map(Background, Background->Map);

	mode = *Background->Register;
	*Background->Register = 0;
	Background->Register = (u16*)BGx_CRAddress(num);
	*Background->Register = mode;
	Background->Num = num;
}

//-----------------------------------
// Fonctions pour les transferts des 
//   donnees des Tiles et des Maps
//   vers la memoire video
//-----------------------------------

// Mise en place des Tiles en Memoire video (Backgrounds Text & Rotation)
void Transfert_Tiles(u16 Num_Blck, tile_struct *Tiles){
	u16 i;
	u16 *TileData;

	TileData = (u16*)TileBlockAddress(Num_Blck);

	// VidMemLocation pointe maintenant vers l'emplacement en memoire des tiles
	Tiles->VidMemLocation = (u16*)TileBlockAddress(Num_Blck);

	// Mise en place de donnees des Tiles 2 bytes � la fois
	//    car Mem video 16 bits et donnees Tiles valeurs sur 8 bits 
	for(i = 0; i < Tiles->TileWidth * Tiles->TileHeight * Tiles->TilesNb /2 ; i++)
		TileData[i] = (Tiles->TilesData[2*i+1]<<8)+Tiles->TilesData[2*i];
}

// Mise en place de la Map en Memoire video (Backgrounds Text & Rotation)
void Transfert_Map(bkg_struct *Background, map_struct *Map){
	u16 i, j, mapheight, mapwidth;

	Background->Map = Map;
	Background->MapWidth = Map->MapWidth * Map->Tiles->TileWidth;
	Background->MapHeight = Map->MapHeight * Map->Tiles->TileHeight;

	mapwidth = Background->MapWidth>>3;
	mapheight = Background->MapHeight>>3;

	if (((DISP_CR & TESTMODE)==2)||(((DISP_CR & TESTMODE) == 1) && (Background->Num == 2))) //Bkg type Rotation
		for(j=0; j<mapheight; j++)
			for(i=0; i<mapwidth/2; i++)
				Background->MapData[i+j*(16<<Background->ScreenSize)/2] = (Map->MapData[2*i+1+j*mapwidth]<<8)+Map->MapData[2*i+j*mapwidth];
	else //Bkg type Text
	{
		if(Background->ScreenSize == 2) 
			for(j = 0; j < mapheight; j++)
				for(i = 0; i < 32; i++)
					Background->MapData[i+j*32] = Map->MapData[i+j*mapwidth];
		else
			for(j = 0; j < mapheight; j++)
				for(i = 0; i < mapwidth; i++)
					if(j<32)
						if(i<32)
							Background->MapData[i+j*32] = Map->MapData[i+j*mapwidth];
						else
							Background->MapData[i-32+j*32+32*32] = Map->MapData[i+j*mapwidth];
					else
						if(i<32)
							Background->MapData[i+(j-32)*32+2*32*32] = Map->MapData[i+j*mapwidth];
						else
							Background->MapData[i-32+(j-32)*32+3*32*32] = Map->MapData[i+j*mapwidth];
	}
}

//Mise en place en memoire d'une tile de 8x8 avec respect specificites memoire mode Text
void PutTile_Small(bkg_struct *Bkg, u16 x_pos, u16 y_pos, u16 TileNum){
	u16 half, peek, send;
	
	if (((DISP_CR & TESTMODE)==2)||(((DISP_CR & TESTMODE) == 1) && (Bkg->Num == 2))) //Bkg type Rotation
	{
		half = x_pos>>1;
		peek = Bkg->MapData[half+((y_pos*(16<<Bkg->ScreenSize))>>1)];
		if (x_pos!=(half<<1))
			send = (0x00ff&peek) + (TileNum<<8);
		else
			send = (0xff00&peek) + TileNum;
		Bkg->MapData[half+((y_pos*(16<<Bkg->ScreenSize))>>1)] = send; //!!! marche pas MapData 8 bits et pas 16 !!!
	}
	else	//Bkg type Text
	{
		if(Bkg->ScreenSize == 2) 
			Bkg->MapData[x_pos+y_pos*32] = TileNum;
		else
			if(y_pos<32)
				if(x_pos<32)
					Bkg->MapData[x_pos+y_pos*32] = TileNum;
				else
					Bkg->MapData[x_pos-32+y_pos*32+32*32] = TileNum;
			else
				if(x_pos<32)
					Bkg->MapData[x_pos+(y_pos-32)*32+2*32*32] = TileNum;
				else
					Bkg->MapData[x_pos-32+(y_pos-32)*32+3*32*32] = TileNum;
	}
}

//Mise en place en memoire d'une tile de dimension > a 8x8 avec respect specificites memoire mode Text
// - Bkg: Background ou ecrire
// - T_Pos: Tableau contenant les positions des tiny tiles pour recreer les grands caracteres
// - NbTWidth: Largeur Tile en tiles de 8x8
// - NbTHeight: Hauteur Tile en tiles de 8x8
// - x_pos: emplct affichage texte suivant x (en tiles de 8x8) | permet espaces plus petits...
// - y_pos: emplct affichage texte suivant y (en tiles de 8x8) |
// - LargeTNum: Numero de la grande Tile
void PutTile_Large(bkg_struct *Bkg, u16 *T_Pos, u16 NbTHeight, u16 NbTWidth, u16 x_pos, u16 y_pos, u16 LargeTNum){
	u16 i, j, NumTile;

	NumTile = LargeTNum * NbTHeight * NbTWidth;

	for(j=0; j<NbTHeight; j++)
		for(i=0; i<NbTWidth; i++)
			PutTile_Small(Bkg, x_pos+i, y_pos+j, T_Pos[NumTile + i + j*NbTWidth]);
}

//-----------------------------------
// Fonctions pour les Scrollings 
//-----------------------------------

// Scrolling relatif d'un Background de type Text
void Scroll_TextBkg (bkg_struct *Background, s32 x, s32 y)
{
	s16 tempx, tempy;

	Background->Scroll_X += x;
	Background->Scroll_Y += y;

	if (Background->Bound)	
	{
		//Si map plus petite que l'ecran
		if((tempx = Background->MapWidth - 240)<0)
			tempx=0;
		if ((tempy = Background->MapHeight - 160)<0)
			tempy=0;

		//Si map plus grande que la SIZE selectionnee 
		if (tempx > (((1 + Background->ScreenSize%2)<<8) - 240))
			tempx = ((1 + (Background->ScreenSize%2))<<8) - 240;
		if (tempy > (((1 + Background->ScreenSize/2)<<8) - 160))
			tempy = ((1 + Background->ScreenSize/2)<<8) - 160;

		//Limitation du scrolling aux bords de la Map
		if ((Background->Scroll_X < 0))
			Background->Scroll_X = 0;
		if ((Background->Scroll_Y < 0))
			Background->Scroll_Y = 0;
		if (Background->Scroll_X > tempx)
			Background->Scroll_X = tempx;
		if (Background->Scroll_Y > tempy)
			Background->Scroll_Y = tempy;
	}

	*(s16*)BGx_XTxt[Background->Num] = Background->Scroll_X;
	*(s16*)BGx_YTxt[Background->Num] = Background->Scroll_Y;
}

// Scrolling relatif d'un Background de type Rotation
void Scroll_RotationBkg (bkg_struct *Background, FIXED20_8 x, FIXED20_8 y){
	s16 tempx, tempy;

	Background->Scroll_X += x;
	Background->Scroll_Y += y;

	if (Background->Bound)	
	{
		//Si map plus petite que l'ecran
		if((tempx = Background->MapWidth - 240)<0)
			tempx=0;
		if ((tempy = Background->MapHeight - 160)<0)
			tempy=0;

		//Si map plus grande que la SIZE selectionnee 
		if (tempx > ((128<<Background->ScreenSize) - 240))
			tempx = (128<<Background->ScreenSize) - 240;
		if (tempy > ((128<<Background->ScreenSize) - 160))
			tempy = (128<<Background->ScreenSize) - 160;

		//Limitation du scrolling aux bords de la Map
		if ((Background->Scroll_X < 0))
			Background->Scroll_X = 0;
		if ((Background->Scroll_Y < 0))
			Background->Scroll_Y = 0;
		if (Background->Scroll_X > (tempx<<8))
			Background->Scroll_X = (tempx<<8);
		if (Background->Scroll_Y > (tempy<<8))
			Background->Scroll_Y = (tempy<<8);
	}

	*(FIXED20_8*)BGx_XRot[Background->Num] = Background->Scroll_X + Background->Trans_X;
	*(FIXED20_8*)BGx_YRot[Background->Num] = Background->Scroll_Y + Background->Trans_Y;
}

// Scrolling relatif d'un Background tous types
void Scroll_Bkg (bkg_struct *Background, s32 x, s32 y){
	if (((DISP_CR & TESTMODE)==2)||(((DISP_CR & TESTMODE) == 1) && (Background->Num == 2))) //Bkg type Rotation
		Scroll_RotationBkg (Background, x, y);
	else	//Bkg type Text
		Scroll_TextBkg (Background, x, y);
}

// Scrolling absolu d'un Background de type Text
void SetScroll_TextBkg (bkg_struct *Background, s32 x, s32 y){
	s16 tempx, tempy;

	Background->Scroll_X = x;
	Background->Scroll_Y = y;

	if (Background->Bound)	
	{
		//Si map plus petite que l'ecran
		if((tempx = Background->MapWidth - 240)<0)
			tempx=0;
		if ((tempy = Background->MapHeight - 160)<0)
			tempy=0;

		//Si map plus grande que la SIZE selectionnee 
		if (tempx > (((1 + Background->ScreenSize%2)<<8) - 240))
			tempx = ((1 + (Background->ScreenSize%2))<<8) - 240;
		if (tempy > (((1 + Background->ScreenSize/2)<<8) - 160))
			tempy = ((1 + Background->ScreenSize/2)<<8) - 160;

		//Limitation du scrolling aux bords de la Map
		if ((Background->Scroll_X < 0))
			Background->Scroll_X = 0;
		if ((Background->Scroll_Y < 0))
			Background->Scroll_Y = 0;
		if (Background->Scroll_X > tempx)
			Background->Scroll_X = tempx;
		if (Background->Scroll_Y > tempy)
			Background->Scroll_Y = tempy;
	}

	*(s16*)BGx_XTxt[Background->Num] = Background->Scroll_X;
	*(s16*)BGx_YTxt[Background->Num] = Background->Scroll_Y;
}

// Scrolling absolu d'un Background de type Rotation
void SetScroll_RotationBkg (bkg_struct *Background, FIXED20_8 x, FIXED20_8 y){
	s16 tempx, tempy;

	Background->Scroll_X = x;
	Background->Scroll_Y = y;

	if (Background->Bound)	
	{
		//Si map plus petite que l'ecran
		if((tempx = Background->MapWidth - 240)<0)
			tempx=0;
		if ((tempy = Background->MapHeight - 160)<0)
			tempy=0;

		//Si map plus grande que la SIZE selectionnee 
		if (tempx > ((128<<Background->ScreenSize) - 240))
			tempx = (128<<Background->ScreenSize) - 240;
		if (tempy > ((128<<Background->ScreenSize) - 160))
			tempy = (128<<Background->ScreenSize) - 160;

		//Limitation du scrolling aux bords de la Map
		if ((Background->Scroll_X < 0))
			Background->Scroll_X = 0;
		if ((Background->Scroll_Y < 0))
			Background->Scroll_Y = 0;
		if (Background->Scroll_X > (tempx<<8))
			Background->Scroll_X = (tempx<<8);
		if (Background->Scroll_Y > (tempy<<8))
			Background->Scroll_Y = (tempy<<8);
	}

	*(FIXED20_8*)BGx_XRot[Background->Num] = Background->Scroll_X + Background->Trans_X;
	*(FIXED20_8*)BGx_YRot[Background->Num] = Background->Scroll_Y + Background->Trans_Y;
}

// Scrolling absolu d'un Background tous types
void SetScroll_Bkg (bkg_struct *Background, s32 x, s32 y){
	if (((DISP_CR & TESTMODE)==2)||(((DISP_CR & TESTMODE) == 1) && (Background->Num == 2))) //Bkg type Rotation
		SetScroll_RotationBkg (Background, x, y);
	else	//Bkg type Text
		SetScroll_TextBkg (Background, x, y);
}

//-----------------------------------
// Fonction pour l'effet Mosaic 
//-----------------------------------

// Utilisation de la Mosaique pour les Backgrounds
// (XLevel et YLevel compris entre 0 et 15)
void Mosaic_Bkg(u16 XLevel, u16 YLevel){
	u16 temp;

	temp = BKG_MOSAIC & 0xFF00; //pour ne pas modifier la mosaique des sprites
	BKG_MOSAIC = temp + (YLevel<<4) + XLevel;
}

//-----------------------------------
// Fonctions pour le Fading 
//-----------------------------------

// Initialisation du Fading pour les Backgrounds et les Sprites (Fade IN et Fade OUT)
// (FLevel compris entre 0 et 16 (oui 16, ce n'est pas une erreur))
// (Mode = FADE_IN ou FADE_OUT)
void Set_Fade(u16 Targets, u16 Mode, u16 FLevel){
	BLEND_CR = Mode + (Targets>>8); //Targets>>8 car utilisation des defines du reg DISP_CR: BG0, ... SPR
	BLEND_Y  = FLevel;
}

//Modification de la valeur du Fading
void Change_FadeValue(u16 FLevel){
	BLEND_Y  = FLevel;
}

//Modification du Mode du Fading
void Change_FadeMode(u16 Mode){
	u16 temp;

	temp = BLEND_CR & 0xFF3F; //pour ne pas modifier les cibles
	BLEND_CR = temp + Mode;
}

//Modification des cibles (anciennes cibles remplacees par nouvelles
void Change_FadeTarget(u16 Targets){
	u16 temp;

	temp = BLEND_CR & 0xC0; //pour ne pas modifier le Mode
	BLEND_CR = temp + (Targets>>8);
}

//Ajout de cibles
void Enable_FadeTarget(u16 Targets){
	BLEND_CR |= (Targets>>8);
}

//Suppression de cibles
void Disable_FadeTarget(u16 Targets){
	BLEND_CR &= ~(Targets>>8);
}

//-----------------------------------
// Fonctions pour l'Alpha-Blending 
//-----------------------------------

// Initialisation de l'Alpha-Blending pour les Backgrounds et les Sprites
// (LevelA et LevelB compris entre 0 et 16 (oui 16, ce n'est pas une erreur))
void Set_Alpha(u16 FTargets, u16 STargets, u16 LevelA, u16 LevelB){
	BLEND_CR = STargets + ALPHA + (FTargets>>8);
	BLEND_AB = (LevelB<<8) + LevelA;
}

//Modification des valeurs de l'Alpha-Blending
void Change_AlphaValues(u16 LevelA, u16 LevelB){
	BLEND_AB  = (LevelB<<8) + LevelA;
}

//Modification des cibles (anciennes cibles remplacees par nouvelles
void Change_AlphaTarget(u16 FTargets, u16 STargets){
	BLEND_CR = ALPHA + STargets + (FTargets>>8);
}

//Ajout de cibles
void Enable_AlphaTarget(u16 FTargets, u16 STargets){
	BLEND_CR |= (STargets + (FTargets>>8));
}

//Suppression de cibles
void Disable_AlphaTarget(u16 FTargets, u16 STargets){
	BLEND_CR &= ~(STargets + (FTargets>>8));
}

//-----------------------------------
// Fonctions pour les Zooms/Rotations 
//-----------------------------------

// determination du centre de la rotation
void SetCenter(bkg_struct *Bkg, s16 x, s16 y){
	Bkg->Center_X = x;
	Bkg->Center_Y = y;
}

// ajout des valeurs passees e, argument aux coordonnees
//   du centre de la rotation
void AddToCenter(bkg_struct *Bkg, s16 x, s16 y){
	Bkg->Center_X += x;
	Bkg->Center_Y += y;
}

// determination des coef des zooms
void SetZoom(bkg_struct *Bkg, FIXED8_8 x, FIXED8_8 y){
	Bkg->Zoom_X = x;
	Bkg->Zoom_Y = y;
}

// ajout des valeurs passees en argument aux coordonnees
//   du centre de la rotation
void AddToZoom(bkg_struct *Bkg, FIXED8_8 x, FIXED8_8 y){
	Bkg->Zoom_X += x;
	Bkg->Zoom_Y += y;
}

// effectue la rotation de l'angle d�sir�
void Rotation(bkg_struct *Bkg, u16 teta){
	if(!Bkg->ZoomType) //axe du Zoom suivant axe de l'ecran 
	{
		*(FIXED8_8*)BGx_HDX[Bkg->Num] = (COS[teta]<<8)/Bkg->Zoom_X;
		*(FIXED8_8*)BGx_VDX[Bkg->Num] = (SIN[teta]<<8)/Bkg->Zoom_Y;
		*(FIXED8_8*)BGx_HDY[Bkg->Num] = (-1*SIN[teta]<<8)/Bkg->Zoom_X;
		*(FIXED8_8*)BGx_VDY[Bkg->Num] = (COS[teta]<<8)/Bkg->Zoom_Y;

		Bkg->Trans_X = (Bkg->Center_X<<8)-(((Bkg->Center_X*COS[teta])<<8)/Bkg->Zoom_X+((Bkg->Center_Y*SIN[teta])<<8)/Bkg->Zoom_Y);
		Bkg->Trans_Y = (Bkg->Center_Y<<8)-(((Bkg->Center_Y*COS[teta])<<8)/Bkg->Zoom_Y-((Bkg->Center_X*SIN[teta])<<8)/Bkg->Zoom_X);
	}
	else	//axe du Zoom suivant axe du Background
	{
		*(FIXED8_8*)BGx_HDX[Bkg->Num] = (COS[teta]<<8)/Bkg->Zoom_X;
		*(FIXED8_8*)BGx_VDX[Bkg->Num] = (SIN[teta]<<8)/Bkg->Zoom_X;
		*(FIXED8_8*)BGx_HDY[Bkg->Num] = (-1*SIN[teta]<<8)/Bkg->Zoom_Y;
		*(FIXED8_8*)BGx_VDY[Bkg->Num] = (COS[teta]<<8)/Bkg->Zoom_Y;

		Bkg->Trans_X = (Bkg->Center_X<<8)-(((Bkg->Center_X*COS[teta])<<8)/Bkg->Zoom_X+((Bkg->Center_Y*SIN[teta])<<8)/Bkg->Zoom_X);
		Bkg->Trans_Y = (Bkg->Center_Y<<8)-(((Bkg->Center_Y*COS[teta])<<8)/Bkg->Zoom_Y-((Bkg->Center_X*SIN[teta])<<8)/Bkg->Zoom_Y);
	}

	*(FIXED20_8*)BGx_XRot[Bkg->Num] = Bkg->Scroll_X + Bkg->Trans_X;
	*(FIXED20_8*)BGx_YRot[Bkg->Num] = Bkg->Scroll_Y + Bkg->Trans_Y;

}

#endif

