/**************************************************************
*	
* DirectGBA.h : Fichier en-tete commun a toute la lirairie DirectGBA
*
* Cree le : 30.11.2001
* Par : Edorul (edorul@caramail.com)
*         http://www.ifrance.com/edorul/
*
* Ver. : 0.1.0
* Modifi� le 
*
***************************************************************/

#ifndef DIRECTGBA_H
#define DIRECTGBA_H

//Inclusion des autres fichiers en-tete de la librairie DirectGBA
#include "GBADraw.h"
#include "GBAInput.h"
#include "GBASprites.h"
#include "GBASpritesList.h"
#include "GBAText.h"
#include "GBATime.h"

#endif
