/**************************************************************
*	
* GBAText.h : Fichier en-tete contenant des fonctions pour g�rer
*               l'affichage de texte (max 255 caracteres!) 
*               � l'aide de tiles.
*             Plusieurs fontes sont utilisables en meme temps
*               il suffit de creer une variable text_struct
*               pour chacune.
*             NOTE1: les tiles doivent etre dans l'ordre des
*                    caracteres ASCII. 
*             NOTE2: si vous utilisez TileStudio la premiere
*                    map avec le Set de tiles des caracteres
*                    doit afficher tous les caracteres dans 
*                    l'ordre des caracteres ASCII (encore ;)
*
* Cree le : 03.02.2002
* Par : Edorul (edorul@caramail.com)
*         http://www.ifrance.com/edorul/
*
* Ver. : 0.1.0
* Modifi� le 
*
***************************************************************/

#ifndef GBATEXT_H
#define GBATEXT_H

#include "GBADraw.h"

// VARIABLES 
//-----------
typedef struct text_struct
{
	bkg_struct *Bkg;	//Background ou sera affiche le texte
	u16 *TilePos;		//Positions des Tiny Tiles pour recreer les grands caracteres
	u16 TileWidth;		//Largeur des tiles a utiliser en pixels
	u16 TileHeight;		//Hauteur des tiles a utiliser en pixels
//	u16	*TileData;		//Emplct en mem des tiles a utiliser pour les caracteres
//	u16 *MapData;		//Emplct en mem des donnees de la map ou placer le message
//	u16 BkgWidth;		//Largeur en Tiles du Bkg
//	u16 BkgHeight;		//Hauteur en Tiles du Bkg
	u8	FirstChar;		//Premier caractere des tiles
	u16 CharNb;			//Nombre de caracteres
} text_struct;


// FONCTIONS 
//-----------

//Initialisation de pour l'affichage des caracteres de 8x8 pixels:
//   - Nom de la variable de type text_struct du jeu de caracteres
//   - Background ou seront affiches les messages
//   - debut des caracteres (ex: 'A')
//   - nombre de caracteres
void InitText_Small(text_struct *Fonts, bkg_struct *Bkg, u8 FChar){//, u16 CNb){
	Fonts->Bkg = Bkg;
//	Fonts->TileData = Bkg->TileData;
//	Fonts->MapData = Bkg->MapData;
	Fonts->TileWidth = 8;
	Fonts->TileHeight = 8;
	Fonts->TilePos = NULL;
	Fonts->FirstChar = FChar;
//	Fonts->CharNb = CNb;
/*
	SizeNb=(*Bkg->Register & 0xC000)>>14;

	if (((DISP_CR & TESTMODE)==2)||(((DISP_CR & TESTMODE) == 1) && (Bkg->Num == 2))) //Bkg type Rotation
	{
		Fonts->BkgWidth = 16<<Fonts->Bkg->ScreenSize;
		Fonts->BkgHeight = 16<<Fonts->Bkg->ScreenSize;
	}
	else	//Bkg type Text
	{
		switch(Fonts->Bkg->ScreenSize){
		case 0:
			Fonts->BkgWidth = 32;
			Fonts->BkgHeight = 32;
			break;
		case 1:
			Fonts->BkgWidth = 64;
			Fonts->BkgHeight = 32;
			break;
		case 2:
			Fonts->BkgWidth = 32;
			Fonts->BkgHeight = 64;
			break;
		case 3:
			Fonts->BkgWidth = 64;
			Fonts->BkgHeight = 64;
			break;
		}
	}*/
}

//Initialisation de pour l'affichage de caracteres superieurs a 8x8 pixels:
//   - Nom de la variable de type text_struct du jeu de caracteres
//   - Background ou seront affiches les messages
//   - Largeur tiles en pixels
//   - Hauteur Tiles en pixels
//   - Tableau contenant les positions des tiny tiles pour recreer les grands caracteres
//   - debut des caracteres (ex: 'A')
//   - nombre de caracteres
void InitText_Large(text_struct *Fonts, bkg_struct *Bkg, u16 T_Width, u16 T_Height, u16 *T_Pos, u8 FChar){//, u16 CNb){
	Fonts->Bkg = Bkg;
//	Fonts->TileData = Bkg->TileData;
//	Fonts->MapData = Bkg->MapData;
	Fonts->TileWidth = T_Width;
	Fonts->TileHeight = T_Height;
	Fonts->TilePos = T_Pos;
	Fonts->FirstChar = FChar;
//	Fonts->CharNb = CNb;
/*
	SizeNb=(*Bkg->Register & 0xC000)>>14;

	if (((DISP_CR & TESTMODE)==2)||(((DISP_CR & TESTMODE) == 1) && (Bkg->Num == 2))) //Bkg type Rotation
	{
		Fonts->BkgWidth = 16<<SizeNb;
		Fonts->BkgHeight = 16<<SizeNb;
	}
	else	//Bkg type Text
	{
		switch(SizeNb){
		case 0:
			Fonts->BkgWidth = 32;
			Fonts->BkgHeight = 32;
			break;
		case 1:
			Fonts->BkgWidth = 64;
			Fonts->BkgHeight = 32;
			break;
		case 2:
			Fonts->BkgWidth = 32;
			Fonts->BkgHeight = 64;
			break;
		case 3:
			Fonts->BkgWidth = 64;
			Fonts->BkgHeight = 64;
			break;
		}
	}*/
}

//Affichage d'une chaine de caractere de 8x8 dans le Background desire
//   - Fonte a employer
//   - emplct affichage texte suivant x (en tiles)
//   - emplct affichage texte suivant y (en tiles)
//   - tableau contenant la chaine de caracteres (termine par le caractere '\0')
void PrintText_Small(text_struct Fonts, u16 x_pos, u16 y_pos, u8 *Text){
	u16 i=0;

	while(Text[i]!=0){
		PutTile_Small(Fonts.Bkg, x_pos+i, y_pos, Text[i]-Fonts.FirstChar);
		i++;
	}
}

void PrintTextCR_Small(text_struct Fonts, u16 x_pos, u16 y_pos, u8 *Text){
	u16 i=0;

	while(Text[i]!=0){
		if(x_pos>=30){
			x_pos=0;
			y_pos++;
		}
		PutTile_Small(Fonts.Bkg, x_pos, y_pos, Text[i]-Fonts.FirstChar);
		i++;x_pos++;
	}
}

//Affichage d'une chaine de caractere superieurs a 8x8 dans le Background desire
//   - Fonte a employer
//   - emplct affichage texte suivant x (en tiles de 8x8) | permet espaces plus petits... 
//   - emplct affichage texte suivant y (en tiles de 8x8) |   
//   - tableau contenant la chaine de caracteres (termine par le caractere '\0')
void PrintText_Large(text_struct Fonts, u16 x_pos, u16 y_pos, u8 *Text){
	u16 i=0, NbTWidth, NbTHeight;

	NbTWidth = (Fonts.TileWidth>>3);
	NbTHeight = (Fonts.TileHeight>>3);

	while(Text[i]!=0){
		PutTile_Large(Fonts.Bkg, Fonts.TilePos, NbTWidth, NbTHeight, x_pos+i*NbTWidth, y_pos, Text[i]-Fonts.FirstChar);
		i++;
	}
}

//Affichage d'une chaine de caractere de tailles quelconques dans le Background desire
//   - Fonte a employer
//   - emplct affichage texte suivant x (en tiny tiles)
//   - emplct affichage texte suivant y (en tiny tiles)
//   - tableau contenant la chaine de caracteres (termine par le caractere '\0')
void PrintText(text_struct Fonts, u16 x_pos, u16 y_pos, u8 *Text){
	if (Fonts.TilePos == NULL)
		PrintText_Small(Fonts, x_pos, y_pos, Text);
	else
		PrintText_Large(Fonts, x_pos, y_pos, Text);
}

void PrintTextCR(text_struct Fonts, u16 x_pos, u16 y_pos, u8 *Text){
	if (Fonts.TilePos == NULL)
		PrintTextCR_Small(Fonts, x_pos, y_pos, Text);
	else
		PrintText_Large(Fonts, x_pos, y_pos, Text);
}

#endif

