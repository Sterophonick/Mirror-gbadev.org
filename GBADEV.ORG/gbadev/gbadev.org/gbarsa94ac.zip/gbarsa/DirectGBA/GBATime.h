/**************************************************************
*	
* GBATime.h : Fichier en-tete comprenant les elements
*             permettant la gestion du temps sur la GBA
*
*      NOTE : GBATime utilise en interne les Timers 0 et 1, 
*             ils ne devront pas etre utilis�s par le codeur. 
*             Les Timers 2 et 3 sont, eux, librement accessibles. 
*
* Cree le : 21.11.2001
* Par : Edorul (edorul@caramail.com)
*         http://www.ifrance.com/edorul/
*
* Ver. : 0.2.1
* Modifi� le 23.01.2002
*
***************************************************************/

#ifndef GBATIME_H
#define GBATIME_H

#include "GBATypes.h"

// DEFINITIONS 
//-------------

// definition des registres TIMERx_DATA
#define TIMER0_DATA		*(volatile u16*)0x4000100
#define TIMER1_DATA		*(volatile u16*)0x4000104
#define TIMER2_DATA		*(volatile u16*)0x4000108
#define TIMER3_DATA		*(volatile u16*)0x400010C

// definition des registres TIMERx_CR
#define TIMER0_CR		*(volatile u16*)0x4000102
#define TIMER1_CR		*(volatile u16*)0x4000106
#define TIMER2_CR		*(volatile u16*)0x400010A
#define TIMER3_CR		*(volatile u16*)0x400010E
#define RATIO_1			0x0
#define RATIO_64		0x1
#define RATIO_256		0x2
#define RATIO_1024		0x3
#define CASCADE			0x4
#define IRQ				0x40
#define ENABLE			0x80

// MACROS 
//--------

//calcul de l'adresse du registre TIMERx_CR (o� x = num)
#define TIMERx_CRAddress(num)	*(volatile u16*)(0x4000102+0x04*(num))

//calcul de l'adresse du registre TIMERx_DATA (o� x = num)
#define TIMERx_DATAAddress(num)	*(volatile u16*)(0x4000100+0x04*(num))

//ecriture TIMERx_CR buffer
#define SetTIMER0_CR(mode) TIMER0_CR=(mode)
#define SetTIMER1_CR(mode) TIMER1_CR=(mode)
#define SetTIMER2_CR(mode) TIMER2_CR=(mode)
#define SetTIMER3_CR(mode) TIMER3_CR=(mode)
#define SetTIMERx_CR(num, mode) TIMERx_CRAddress(num)=(mode)

//ajouter les options passees en argument a TIMERx_CR
#define EnableTIMER0_CR(mode) TIMER0_CR|=(mode)
#define EnableTIMER1_CR(mode) TIMER1_CR|=(mode)
#define EnableTIMER2_CR(mode) TIMER2_CR|=(mode)
#define EnableTIMER3_CR(mode) TIMER3_CR|=(mode)
#define EnableTIMERx_CR(num, mode) TIMERx_CRAddress(num)|=(mode)

//supprime les options de TIMERx_CR passees en argument
#define DisableTIMER0_CR(mode) TIMER0_CR&=~(mode)
#define DisableTIMER1_CR(mode) TIMER1_CR&=~(mode)
#define DisableTIMER2_CR(mode) TIMER2_CR&=~(mode)
#define DisableTIMER3_CR(mode) TIMER3_CR&=~(mode)
#define DisableTIMERx_CR(num, mode) TIMERx_CRAddress(num)&=~(mode)

// FONCTIONS 
//-----------

// Initialisation des Timers 0 et 1 de facon a ce que:
// - le ration de la frequence soit 256 (1bit = 15�s / 16bits = 1s / 32bits = 18h)
// - les deux Timers soient en cascade
// - les deux Timers soient valides
void InitTime(){
	TIMER0_DATA = 0;
	TIMER1_DATA = 0;

	SetTIMER0_CR(RATIO_256 | ENABLE);
	SetTIMER1_CR(ENABLE | CASCADE);
}

//Nb de cycles depuis le lancement du programme
// (Transformation des valeurs de TIMER0_DATA et TIMER1_DATA
//  en une valeur de 32bits)
u32 GetTicks(){
	return ((TIMER1_DATA<<16) + TIMER0_DATA);
}

// Attente d'un certain nombre de cycles (1 cycle = 15�s)
void Wait(u32 nb){
	u32 start;

	start = GetTicks();

	while((GetTicks()-start) < nb);
}

//calcul du temps ecoule entre 2 frames
u32 Calc_DeltaTime(void){
	u32 CurrentTime;
	u32 DeltaTime;
	static u32 LastTime = 0;

	CurrentTime = GetTicks();
	DeltaTime = CurrentTime - LastTime;
	LastTime = CurrentTime;

	return DeltaTime;
}


#endif

