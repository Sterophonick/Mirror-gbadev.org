/**************************************************************
*	
* GBATypes.h : Fichier en-tete contenant la definition des 
*              types des variables
*
* Cree le : 16.08.2001
* Par : Edorul (edorul@caramail.com)
*         http://www.ifrance.com/edorul/
*
* Ver. : 0.3.4
* Modifi� le 28.02.2002
*
***************************************************************/

#ifndef GBATYPES_H
#define GBATYPES_H

// Types generaux
//----------------

// definitions des types courants de variables
typedef unsigned char u8;
typedef unsigned short u16;
typedef unsigned long u32;

typedef signed char s8;
typedef signed short s16;
typedef signed long s32;

// definitions de types pour les fichiers ".H" 
//   contenant des donn�es binaires
typedef const unsigned char const_u8;
typedef const unsigned short const_u16;

//variables booleennes
typedef unsigned short BOOL;
#define TRUE	1
#define FALSE	0	

//Pour les pointeurs nuls
#define NULL	0

//Definitions pour les registres utilises par 
// les Backgrounds de type Rotation
typedef signed short FIXED8_8;
typedef signed long FIXED20_8;

// STRUCTURES pour GBADraw
//-------------------------

// Structure pour l'utilisation des Tiles
#ifndef TILE_STRUCT
#define TILE_STRUCT

typedef struct tile_struct
{
	unsigned short PaletteSize;
	unsigned short *PaletteData;
	unsigned short TilesNb;
	unsigned short TileWidth;
	unsigned short TileHeight;
	unsigned short Overlap;
	unsigned short *TilesData;
	unsigned short *VidMemLocation;
} tile_struct;

#endif

// Structure pour l'utilisation des maps
#ifndef MAP_STRUCT
#define MAP_STRUCT

typedef struct map_struct
{
	tile_struct *Tiles;			// Pointeur vers la structure des Tiles utilisees
	unsigned short MapWidth;	// Largeur de la Map en Tiles
	unsigned short MapHeight;	// Hauteur de la Map en Tiles
	unsigned short *MapData;	// Pointeur vers le tableau contenant les donnees de la Map
	unsigned char *Bounds;		// Pointeur vers le tableau contenant les limites de la Map
	unsigned char *MapCode;		// Pointeur vers le tableau contenant les emplacements spreciaux
} map_struct;

#endif

// Structure pour l'utilisation des Sequences
#ifndef SEQUENCE_STRUCT
#define SEQUENCE_STRUCT

typedef struct sequence_struct
{
	tile_struct *Tiles;
	unsigned short SequenceLength;
	unsigned short *TileNum;
	unsigned char *Duration;
} sequence_struct;

#endif

// Structure pour les Backgrounds
typedef struct bkg_struct
{
	map_struct *Map;	// Pointeur vers la structure contenant la Map plac�e dans ce Background
	u16 Num;			// numero du Background
	u16 *Register;      // pointe vers le registre BGx_CR du Background
//	u16 TileBlock;		// Tile Base Block Number
	u16 *TileData;		// pointe vers la en m�m vid�o contenant les Tiles
//	u16 MapBlock;		// Screen Base Block Number (Map Block)
	u16 *MapData;		// pointe vers la m�m vid�o contenant la Map
	u16 MapWidth;		// Largeur de la Map en Pixels
	u16 MapHeight;		// Hauteur de la Map en Pixels

//	u16 Priority;		// Priorit� du Background (0 affich� dessus, 3 affich� dessous)
//	u16 Mosaic;			// si =1 Mosaic enable
//	u16 NbColors;		// 16 ou 256
	u16 ScreenSize;		// Taille de la carte de 0 � 3 (utilise en interne par DirectGBA)

	s32 Scroll_X;		// valeur absolue du scrolling suivant X
	s32 Scroll_Y;		// valeur absolue du scrolling suivant Y
	s32 Deplct_X;		// valeur relative du deplacement du scrolling suivant X
	s32 Deplct_Y;		// valeur relative du deplacement du scrolling suivant Y
	u16 Bound;			// si =1 empeche Map de sortir de l'ecran

	u16 Angle;			// angle en degres de la rotation du Bkg
	s16 Center_X;		// coordonnee suivant X du centre de la rotation
	s16 Center_Y;		// coordonnee suivant Y du centre de la rotation
	u16 Zoom_X;			// facteur d'agrandissement du Bkg suivant X (>1 agrandit)
	u16 Zoom_Y;			// facteur d'agrandissement du Bkg suivant Y (>1 agrandit)
	u16 ZoomType;		// axe du zoom (AXE_SCREEN -> selon axe ecran, AXE_BKG -> selon axe Background)

	s32 Trans_X;		// Translation suivant X (pour chgt de repere du centre rotation juste pour augmenter rapidite, utilise en interne par DirectGBA)
	s32 Trans_Y;		// Translation suivant Y (pour chgt de repere du centre rotation juste pour augmenter rapidite, utilise en interne par DirectGBA)
} bkg_struct;

// Definitions pour les SPRITES
//------------------------------
typedef struct spriteOAM_struct
{
	u16 Attribute0;
	u16 Attribute1;
	u16 Attribute2;
	u16 Unused;
} spriteOAM_struct;

typedef struct spriteRot_struct
{
	u16 Unused0[3];
	u16 PA;
	u16 Unused1[3];
	u16 PB;
	u16 Unused2[3];
	u16 PC;
	u16 Unused3[3];
	u16 PD;
} spriteRot_struct;

// structure pour les sprites
typedef struct sprite_struct
{
	u16 NumSprite;					//numero du sprite dans SpritesOAM[128]
	spriteOAM_struct *SpriteOAM;	//pointe vers zone memoire contenant les attributs du sprite
	u16 NumRot;						//numero de la rotation a utiliser pour le sprite
	spriteRot_struct *SpriteRot;	//pointe vers la rotation utilisee par le sprite
	bkg_struct *Bkg;				//different de NULL si li� � un Bkg (i.e. pour le scrolling)
	u16 Width;						//largeur en pixels
	u16 Height;						//hauteur en pixels
	s32 X_Pos;						//X actuel % ecran
	s32 Y_Pos;						//Y actuel % ecran
	s32 X_Pred;						//prochain X prevu
	s32 Y_Pred;						//prochain Y prevu
	s32 X_Dest;						//X de la destination % ecran
	s32 Y_Dest;						//Y de la destination % ecran
	u16 Action;						//type de l'action (ex: 01 = marcher vers droite, 18 = sauter...)
	u16 Type;						//type du sprite (ex:01 = joueur, 03 = ennemi n�1...)
	u32 LastAction;					//temps de la derniere action executee
	u32 NextAction;					//temps ou sera executee la prochaine action
	sequence_struct Animation;		//pointe vers l'animation a utiliser
	u32 TimeFrame;					//temps du commencement de cette frame 
	u16 CurrentFrame;				//frame en cour d'affichage
	s16	Loop;						//Si = LOOP_FWD (ou LOOP_RWD) animation boucle a l'infini, sinon nb de boucles a faire (si <0 animation sens inverse)
	struct sprite_struct *Next;		//sprite suivant dans liste chainee
	struct sprite_struct *Prev;		//sprite precedent dans liste chainee
	void (*Fonction)(struct sprite_struct *self);	//fonction a executer avec ce sprite (peut etre utilise avec NextAction)
} sprite_struct;

//Structure pour les Listes chainees de sprites
//------------------------------------------------
typedef struct spritelist_struct
{
	u16 NbSpr;				//nombre de sprites dans la liste
	sprite_struct *First;	//Premier sprite de la liste
} spritelist_struct;

#endif
