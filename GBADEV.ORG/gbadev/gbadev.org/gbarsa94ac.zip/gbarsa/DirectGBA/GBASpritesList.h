/**************************************************************
*	
* GBASpritesList.h : Fichier en-tete contenant les fonctions
*                    pour utiliser des listes chainees de sprites
*
* Cree le : 05.02.2002
* Par : Edorul (edorul@caramail.com)
*         http://www.ifrance.com/edorul/
*
* Ver. : 0.1.2
* Modifi� le 08.02.2002
*
***************************************************************/

#ifndef GBASPRLIST_H
#define GBASPRLIST_H

#include <malloc.h>
#include "GBASprites.h"

// FONCTIONS 
//-----------
// Ajout d'un sprite en debut de liste chainee + initialisation proprietes du sprite
sprite_struct *AddSprite(spritelist_struct *List, u32 properties){//, s32 X, s32 Y){
	sprite_struct *New;

	New = (sprite_struct *) malloc (sizeof(sprite_struct));

	if (New==NULL)
		return NULL;

	//Initialisation du sprite
	SetSprite_Properties(New, properties); 

	List->First->Prev = New;
	New->Prev = NULL;
	New->Next = List->First;
	List->First = New;
	List->NbSpr++;
	
	return New;
}

// Suppression d'un sprite a la liste chainee
void RemoveSprite(spritelist_struct *List, sprite_struct *sprite){
	if(sprite->Prev == NULL) //sprite de debut de liste
		List->First = sprite->Next;

	sprite->Prev->Next = sprite->Next;
	sprite->Next->Prev = sprite->Prev;

	List->NbSpr--;
	UsedSprIndex[sprite->NumSprite] = 0; //index libere

	//efface le sprite de l'ecran
	sprite->SpriteOAM->Attribute0=ROT_DS<<8;

	free(sprite);
}

// Suppression de tous les sprites de la chaine
void RemoveAllSprites(spritelist_struct *List){
	sprite_struct *Curr, *Next;

	Curr = List->First;
	
	while(Curr != NULL){
		Next = Curr->Next;
		UsedSprIndex[Curr->NumSprite] = 0; //index libere
		Curr->SpriteOAM->Attribute0=ROT_DS<<8; //efface le sprite de l'ecran
		free(Curr);
		Curr = Next;
	}

	List->First = NULL;
	List->NbSpr = 0;
}

#endif

