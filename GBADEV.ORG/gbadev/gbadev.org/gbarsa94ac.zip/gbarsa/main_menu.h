void init_main_menu(u8 crtItem){
	SetVideoMode(MODE0 | BG1 | BG2 | BG3);
	SetPaletteBKG_All(rsa_logo_main_palette_Pal);
	SetBGx_CR(&Screen, 0, TILEBLOCK2 | MAPBLOCK28 | COLOR256 | SIZE0 | PRIORITY0);
	Transfert_Tiles(2, &rsa_logo_Tiles[2]);
	Transfert_Map(&Screen, &rsa_logo_T2Map[crtItem]);
	SetVideoMode(MODE0 | BG0 | BG1 | BG2 | BG3);
}

void main_menu(void)
{
	u8 crtItem=0,lastItem=-1;
	u8 keyUp=0;

	init_main_menu(crtItem);

	while(1){
		keyUp|=KEY_UP(K_ALL);
		if (KEY_DOWN(K_UP)&&keyUp)crtItem=0;
		else if (KEY_DOWN(K_DOWN)&&keyUp)crtItem=1;
		else if (KEY_DOWN(K_A)&&keyUp){
			switch(crtItem){
			case 0:
				process_menu();
				break;
			case 1:
				setup_menu();
				break;
			}
			init_main_menu(crtItem);
		}
		if (KEY_DOWN(K_ALL))keyUp=0;

		if(crtItem!=lastItem){
			Transfert_Map(&Screen, &rsa_logo_T2Map[crtItem]);
			lastItem=crtItem;
		}

		/*char buf[32];
		sprintf(buf,"%x",rand());
		PrintTextCR(Font8x8, 8, 8, buf);*/

		//Wait_KeyDown(K_UP);

		scroll_digit_background();
	}

}
