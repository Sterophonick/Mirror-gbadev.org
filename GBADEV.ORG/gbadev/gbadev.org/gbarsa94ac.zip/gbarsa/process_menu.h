void display_process_values(map_struct* map){
	map->Tiles=rsa_logo_T4Map[3].Tiles;
	map->MapWidth=rsa_logo_T4Map[3].MapWidth;
	map->MapHeight=rsa_logo_T4Map[3].MapHeight;
	map->Bounds=rsa_logo_T4Map[3].Bounds;
	map->MapCode=rsa_logo_T4Map[3].MapCode;
	memcpy(map->MapData,rsa_logo_T4Map[3].MapData,((rsa_logo_T4Map[3].MapWidth*rsa_logo_T4Map[3].MapHeight*
		rsa_logo_T4Map[3].Tiles->TileWidth*rsa_logo_T4Map[3].Tiles->TileHeight)>>6)*sizeof(unsigned short));

	int i,j,k;
	for(i=0;i<NB_RSA;i++){
		char buf[32];
		sprintf(buf,"%4d",rsa_tab[i].nb);
		for(j=0;j<2;j++){
			map->MapData[30*(4+i*2+j)]=rsa_logo_T4Map[0].MapData[j*19];
			for(k=0;k<4;k++)
				map->MapData[30*(4+i*2+j)+k+1]=rsa_logo_T4Map[0].MapData[j*19+1+(buf[k]==' '?0:1+buf[k]-'0')];
			map->MapData[30*(4+i*2+j)+5]=rsa_logo_T4Map[0].MapData[j*19+18];
			for(k=0;k<10;k++)
				map->MapData[30*(4+i*2+j)+k+6]=rsa_logo_T4Map[1].MapData[10*(2-2*compareBigIntegerInt(&rsa_tab[i].factor,0)+j)+k];
			map->MapData[30*(4+i*2+j)+16]=rsa_logo_T4Map[0].MapData[j*19];
			for(k=0;k<5;k++)
				map->MapData[30*(4+i*2+j)+17+k]=rsa_logo_T4Map[0].MapData[j*19+2+((rsa_tab[i].attempt>>(16-(k*4)))&0xF)];
			map->MapData[30*(4+i*2+j)+22]=rsa_logo_T4Map[0].MapData[j*19+18];
			for(k=0;k<7;k++)
				map->MapData[30*(4+i*2+j)+k+23]=rsa_logo_T4Map[2].MapData[7*(4*compareBigIntegerInt(&rsa_tab[i].factor,0)+(rsa_index==i?0:2)+j)+k];
		}
	}


	Transfert_Map(&Screen, map);
}

void init_process_menu(map_struct* map){
	SetVideoMode(MODE0 | BG1 | BG2 | BG3);
	SetPaletteBKG_All(rsa_logo_process_palette_Pal);
	SetBGx_CR(&Screen, 0, TILEBLOCK2 | MAPBLOCK28 | COLOR256 | SIZE0 | PRIORITY0);
	Transfert_Tiles(2, &rsa_logo_Tiles[4]);
	display_process_values(map);
	SetVideoMode(MODE0 | BG0 | BG1 | BG2 | BG3);
}

void process_menu(void){
	u8 keyUp=0;
	map_struct process_map;
	if((process_map.MapData=(unsigned short*)malloc(((rsa_logo_T4Map[3].MapWidth*rsa_logo_T4Map[3].MapHeight*
		rsa_logo_T4Map[3].Tiles->TileWidth*rsa_logo_T4Map[3].Tiles->TileHeight)>>6)*sizeof(unsigned short)))==NULL)return;

	init_process_menu(&process_map);

	while(1){
		keyUp|=KEY_UP(K_ALL);
		if (KEY_DOWN(K_UP)&&keyUp&&rsa_index>0)rsa_index--;
		else if (KEY_DOWN(K_DOWN)&&keyUp&&rsa_index<NB_RSA-1)rsa_index++;
		else if (KEY_DOWN(K_A)&&keyUp){
			if(compareBigIntegerInt(&rsa_tab[rsa_index].factor,0)==0){
				process_key();
			}else{
				view_key();
			}
			init_process_menu(&process_map);
		}
		else if (KEY_DOWN(K_B)&&keyUp){
			free(process_map.MapData);
			return;
		}
		if (KEY_DOWN(K_ALL)){
			keyUp=0;
			display_process_values(&process_map);
		}

		scroll_digit_background();
	}
}
