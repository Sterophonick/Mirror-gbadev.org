#include <stdio.h>
#include <unistd.h>
#include <string.h>
#include <stdlib.h>
#include <time.h>

#define min(a,b) ((a)<=(b)?(a):(b))
#define max(a,b) ((a)>=(b)?(a):(b))

struct BigInteger{
	unsigned int* value;
	int size;
};

void initBigIntegerCopy(struct BigInteger* bi1,const struct BigInteger* bi2){
	bi1->value=(unsigned int*)malloc(bi2->size*sizeof(unsigned int));
	memcpy(bi1->value,bi2->value,bi2->size*sizeof(unsigned int));
	bi1->size=bi2->size;
}

void initBigIntegerSetInt(struct BigInteger* bi,unsigned int l){
	bi->value=(unsigned int*)malloc(sizeof(unsigned int));
	bi->value[0]=l;
	bi->size=1;
}

void initBigInteger(struct BigInteger* bi){
	initBigIntegerSetInt(bi,0);
}

void clearBigInteger(struct BigInteger* bi){
	free(bi->value);
}

void reallocBigInteger(struct BigInteger* bi,int new_size){
	if(bi->size!=new_size){
		bi->value=(unsigned int*)realloc(bi->value,new_size*sizeof(unsigned int));
		bi->size=new_size;
	}
}

int compareBigInteger(const struct BigInteger* bi1,const struct BigInteger* bi2){
	if(bi1->size!=bi2->size)return bi1->size<bi2->size?-1:1;
	int i=bi1->size;
	while(i-->0)
		if(bi1->value[i]!=bi2->value[i])
			return bi1->value[i]<bi2->value[i]?-1:1;
	return 0;
}

int compareBigIntegerInt(const struct BigInteger* bi,unsigned int ui){
	if(bi->size>1)return 1;
	if(bi->value[0]==ui)return 0;
	return bi->value[0]<ui?-1:1;
}

void getBigIntegerStr(const struct BigInteger* bi,char* str){
	int i=bi->size;
	str[0]='\0';
	while(i-->0)
		sprintf(str+strlen(str),"%0*x",(int)(i==bi->size-1?0:2*sizeof(unsigned int)),bi->value[i]);
}

void dispBigInteger(const struct BigInteger* bi){
	char buf[32768];
	getBigIntegerStr(bi,buf);
	printf("%s\n",buf);
}

void setBigIntegerStr(struct BigInteger* bi,const char* str){
	int s=strlen(str);
	int new_size=(s%(2*sizeof(unsigned int))==0?0:1);
	new_size+=(s-new_size)/(2*sizeof(unsigned int));
	reallocBigInteger(bi,new_size);
	char* buf=(char*)malloc((2*sizeof(unsigned int))+1);
	for(s=0;s<bi->size;s++){
		memset(buf,'\0',(2*sizeof(unsigned int))+1);
		strncpy(buf,max(str,str+strlen(str)-(s+1)*(2*sizeof(unsigned int))),
						2*sizeof(unsigned int)+min(0,(int)(strlen(str)-(s+1)*(2*sizeof(unsigned int)))));
		sscanf(buf,"%x",&bi->value[s]);
	}
	free(buf);
}

void initBigIntegerSetStr(struct BigInteger* bi,const char* str){
	initBigInteger(bi);
	setBigIntegerStr(bi,str);
}

void setBigIntegerCopy(struct BigInteger* bi1,const struct BigInteger* bi2){
	reallocBigInteger(bi1,bi2->size);
	memcpy(bi1->value,bi2->value,bi2->size*sizeof(unsigned int));
}

void setBigIntegerInt(struct BigInteger* bi,unsigned int l){
	reallocBigInteger(bi,1);
	bi->value[0]=l;
}

void addIntIndex(struct BigInteger* bi,unsigned int ui,int index){
	if(index>=bi->size){
		int sz=bi->size;
		reallocBigInteger(bi,index+1);
		while(sz<bi->size)
			bi->value[sz++]=0;
	}
	unsigned int val=ui;
	do{
		bi->value[index]+=val;
		if(bi->value[index]>=val)return;
		val=1;
		if(++index==bi->size){
			reallocBigInteger(bi,index+1);
			bi->value[index]=val;
			return;
		}
	}while(1);
}

void addInt(struct BigInteger* bi,unsigned int ui){
	addIntIndex(bi,ui,0);
}

void addBigInteger(struct BigInteger* bi1,const struct BigInteger* bi2){
	register int i;
	for(i=0;i<bi2->size;i++)
		addIntIndex(bi1,bi2->value[i],i);
}

void subIntIndex(struct BigInteger* bi,unsigned int ui,int index){
	unsigned int val=ui;
	do{
		if(index>=bi->size)abort();
		if(bi->value[index]>=val){
			bi->value[index]-=val;
			while(bi->size>1&&bi->value[bi->size-1]==0)
				reallocBigInteger(bi,bi->size-1);
			return;
		}
		bi->value[index]-=val;
		val=1;
		index++;
	}while(1);
}

void subInt(struct BigInteger* bi,unsigned int ui){
	subIntIndex(bi,ui,0);
}

void subBigInteger(struct BigInteger* bi1,const struct BigInteger* bi2){
	register int i;
	for(i=0;i<bi2->size;i++)
		subIntIndex(bi1,bi2->value[i],i);
}

void shiftLeft(struct BigInteger* bi,int nb_digits){
	if(compareBigIntegerInt(bi,0)==0)return;
	int nb_subDigits=nb_digits%(2*sizeof(unsigned int));
	nb_digits-=nb_subDigits;
	if(nb_subDigits>0){
		register unsigned int lastRet=0;
		register int i;
		for(i=0;i<bi->size;i++){
			register unsigned int crtRet=bi->value[i]>>(4*(2*sizeof(unsigned int)-nb_subDigits));
			bi->value[i]<<=4*nb_subDigits;
			bi->value[i]|=lastRet;
			lastRet=crtRet;
		}
		if(lastRet)addIntIndex(bi,lastRet,bi->size);
	}
	nb_digits/=2*sizeof(unsigned int);
	if(nb_digits>0){
		reallocBigInteger(bi,bi->size+nb_digits);
		memmove(&bi->value[nb_digits],bi->value,(bi->size-nb_digits)*sizeof(unsigned int));
		while(nb_digits-->0)
			bi->value[nb_digits]=0;
	}
}

void initSetTabFactor(struct BigInteger (*tab)[0x10],const struct BigInteger* bi){
	initBigIntegerSetInt(&(*tab)[0],0);
	register int i;
	for(i=1;i<0x10;i++){
		initBigIntegerCopy(&(*tab)[i],&(*tab)[i-1]);
		addBigInteger(&(*tab)[i],bi);
	}
}

void clearTabFactor(struct BigInteger (*tab)[0x10]){
	register int i;
	for(i=0;i<0x10;i++)
		clearBigInteger(&(*tab)[i]);
}

void multBigInteger(struct BigInteger* bi1,const struct BigInteger* bi2){
	register int i=compareBigInteger(bi1,bi2);
	const struct BigInteger* f1=(i<0?bi1:bi2);
	const struct BigInteger* f2=(i<0?bi2:bi1);
	struct BigInteger tabF[0x10];
	initSetTabFactor(&tabF,f2);
	int tabD[0x10];
	for(i=1;i<0x10;i++)tabD[i]=0;
	for(i=0;i<f1->size;i++){
		register int j;
		for(j=0;j<2*sizeof(unsigned int);j++){
			register int k=(f1->value[i]&(0xf<<(j*4)))>>(j*4);
			if(k){
				shiftLeft(&tabF[k],((i*2*sizeof(unsigned int))+j)-tabD[k]);
				tabD[k]=(i*2*sizeof(unsigned int))+j;
				addBigInteger(&tabF[0],&tabF[k]);
			}
		}
	}
	setBigIntegerCopy(bi1,&tabF[0]);
	clearTabFactor(&tabF);
}

void divBigInteger(struct BigInteger* quot,struct BigInteger* remainder,const struct BigInteger* bi1,const struct BigInteger* bi2){
	setBigIntegerInt(quot,0);
	if(compareBigInteger(bi1,bi2)<0){
		setBigIntegerCopy(remainder,bi1);
		return;
	}
	register int i=0,j=0;
	struct BigInteger tabF[0x10];
	initBigIntegerSetInt(&tabF[0],0);
	initBigIntegerCopy(&tabF[1],bi2);
	for(i=2;i<0x10;i++)
		initBigIntegerSetInt(&tabF[i],0);
	setBigIntegerInt(remainder,0);
	register int index=bi1->size;
	register int subIndex=0;
	do{
		i=0;j=0;
		do{
			do{
				if(--subIndex<=0){
					if(j){
						shiftLeft(remainder,j);
						int gap=((2*sizeof(unsigned int))-j)*4;
						remainder->value[0]|=(bi1->value[index]<<gap)>>gap;
					}
					if(--index<0){
						shiftLeft(quot,i);
						for(i=0;i<0x10;i++)
							clearBigInteger(&tabF[i]);
						return;
					}
					subIndex=2*sizeof(unsigned int);j=0;
				}
				if(remainder->size<bi2->size-1){
					j+=subIndex;
					subIndex=0;
				}else j++;i++;
			}while(remainder->size<bi2->size-1);
			shiftLeft(remainder,j);
			int gap=(2*sizeof(unsigned int))-(subIndex+j)+1;j=0;
			remainder->value[0]|=(bi1->value[index]<<(gap*4))>>(((subIndex-1)+gap)*4);
		}while(compareBigInteger(remainder,bi2)<0);
		shiftLeft(quot,i);
		for(i=2;i<0x10;i++){
			if(!compareBigIntegerInt(&tabF[i],0)){
				setBigIntegerCopy(&tabF[i],&tabF[i-1]);
				addBigInteger(&tabF[i],bi2);
			}
			if(compareBigInteger(remainder,&tabF[i])<0)break;
		}
		quot->value[0]|=i-1;
		subBigInteger(remainder,&tabF[i-1]);
	}while(1);
}

void modBigInteger(struct BigInteger* modulus,const struct BigInteger* bi1,const struct BigInteger* bi2){
	if(compareBigInteger(bi1,bi2)<0){
		setBigIntegerCopy(modulus,bi1);
		return;
	}
	register int i=0;
	struct BigInteger tabF[0x10];
	initBigIntegerSetInt(&tabF[0],0);
	initBigIntegerCopy(&tabF[1],bi2);
	for(i=2;i<0x10;i++)
		initBigIntegerSetInt(&tabF[i],0);
	setBigIntegerInt(modulus,0);
	register int index=bi1->size;
	register int subIndex=0;
	do{
		i=0;
		do{
			do{
				if(--subIndex<=0){
					if(i){
						shiftLeft(modulus,i);
						int gap=((2*sizeof(unsigned int))-i)*4;
						modulus->value[0]|=(bi1->value[index]<<gap)>>gap;
					}
					if(--index<0){
						for(i=0;i<0x10;i++)
							clearBigInteger(&tabF[i]);
						return;
					}
					subIndex=2*sizeof(unsigned int);i=0;
				}
				if(modulus->size<bi2->size-1){
					i+=subIndex;
					subIndex=0;
				}else i++;
			}while(modulus->size<bi2->size-1);
			shiftLeft(modulus,i);
			int gap=(2*sizeof(unsigned int))-(subIndex+i)+1;i=0;
			modulus->value[0]|=(bi1->value[index]<<(gap*4))>>(((subIndex-1)+gap)*4);
		}while(compareBigInteger(modulus,bi2)<0);
		for(i=2;i<0x10;i++){
			if(!compareBigIntegerInt(&tabF[i],0)){
				setBigIntegerCopy(&tabF[i],&tabF[i-1]);
				addBigInteger(&tabF[i],bi2);
			}
			if(compareBigInteger(modulus,&tabF[i])<0)break;
		}
		subBigInteger(modulus,&tabF[i-1]);
	}while(1);
}

void gcdBigInteger(struct BigInteger* gcd,const struct BigInteger* bi1,const struct BigInteger* bi2){
	struct BigInteger remain,x;
	initBigInteger(&remain);
	int cmp=compareBigInteger(bi1,bi2);
	initBigIntegerCopy(&x,cmp<0?bi2:bi1);
	setBigIntegerCopy(gcd,cmp<0?bi1:bi2);
	do{
		modBigInteger(&remain,&x,gcd);
		if(!compareBigIntegerInt(&remain,0))break;
		setBigIntegerCopy(&x,gcd);
		setBigIntegerCopy(gcd,&remain);
	}while(1);
	clearBigInteger(&remain);
	clearBigInteger(&x);
}

void setBigIntegerRand(struct BigInteger* bi){
	int i=bi->size-1;
	reallocBigInteger(bi,max(1,i));
	for(i=0;i<bi->size;i++)
		bi->value[i]=(unsigned int)rand();
}

void setRsaRand(struct BigInteger* bi,int size){
	reallocBigInteger(bi,size);
	int i;
	for(i=0;i<bi->size;i++)
		bi->value[i]=(unsigned int)rand();
	bi->value[0]|=0x1;
	bi->value[bi->size-1]|=(0x1<<((8*sizeof(unsigned int))-1));
}
