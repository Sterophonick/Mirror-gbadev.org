GBARSA 1.0 2004/01/24

**********
Content
**********
This is a 'game' which purpose is to break RSA challenge keys
(http://www.rsasecurity.com/rsalabs/challenges/factoring/numbers.html).
using the (little) power of the ARM processor of the GBA.
I was very bothered by my GBA doing nothing, while its ressources
can be used to gain money.
This is also a Mode0/Alpha blending/Saving demo.

Due to hardware limitation of the GBA (memory and processing power),
standard factoring methods can't be used. So the method I use is based
on chance : randomize for probably prime number. I know it's not the best
way but it keeped me busy a while, preventing me from putting old ladies back up.

**********
Thanks
**********
I would like to thank Edorul for his tutorial (http://www.ifrance.com/edorul/index.html)
and its library DirectGBA (which I used and modified a little bit), and also
staringmonkey (staringmonkey@hotmail.com) for his saving demo (which I also modified).

**********
Contact
**********
You can contact me at maxime_kaiser@yahoo.com
I will be happy to help you if I'm not in a hurry.

**********
TODO
**********
- clean the code, as many things are very ugly
- improve graphics
- use GMP instead of my slow lib
