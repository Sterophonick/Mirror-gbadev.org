void display_view_values(map_struct* map){
	map->Tiles=rsa_logo_T6Map[1].Tiles;
	map->MapWidth=rsa_logo_T6Map[1].MapWidth;
	map->MapHeight=rsa_logo_T6Map[1].MapHeight;
	map->Bounds=rsa_logo_T6Map[1].Bounds;
	map->MapCode=rsa_logo_T6Map[1].MapCode;
	memcpy(map->MapData,rsa_logo_T6Map[1].MapData,((rsa_logo_T6Map[1].MapWidth*rsa_logo_T6Map[1].MapHeight*
		rsa_logo_T6Map[1].Tiles->TileWidth*rsa_logo_T6Map[0].Tiles->TileHeight)>>6)*sizeof(unsigned short));

	int i,j,x,y;
	char buf[BLOCK_SIZE];
	sprintf(buf,"%d",rsa_tab[rsa_index].nb);
	for(i=0;i<2;i++){
		for(j=0;j<strlen(buf);j++)
			map->MapData[30*i+15+j]=rsa_logo_T6Map[0].MapData[19*i+buf[j]-'0'+2];
		map->MapData[30*i+15+strlen(buf)]=rsa_logo_T6Map[0].MapData[19*i+18];
	}
	getBigIntegerStr(&rsa_tab[rsa_index].factor,buf);
	for(i=0;i<2;i++){
		x=1,y=1;
		for(j=0;j<strlen(buf);j++){
			map->MapData[30*(i+2*y)+x]=rsa_logo_T6Map[0].MapData[19*i+buf[j]-(buf[j]<='9'?'0':'a'-10)+2];
			if(++x>=rsa_logo_T6Map[1].MapWidth)x=0,y++;
		}
		map->MapData[30*(i+2*y)+x]=rsa_logo_T6Map[0].MapData[19*i+18];
	}
	
	Transfert_Map(&Screen, map);
}

void init_view_menu(map_struct* map){
	SetVideoMode(MODE0 | BG1 | BG2 | BG3);
	SetPaletteBKG_All(rsa_logo_processing_palette_Pal);
	SetBGx_CR(&Screen, 0, TILEBLOCK2 | MAPBLOCK28 | COLOR256 | SIZE0 | PRIORITY0);
	Transfert_Tiles(2, &rsa_logo_Tiles[6]);
	display_view_values(map);
	SetVideoMode(MODE0 | BG0 | BG1 | BG2 | BG3);
}

void view_key(){
	u8 keyUp=0;
	map_struct view_map;
	if((view_map.MapData=(unsigned short*)malloc(((rsa_logo_T6Map[1].MapWidth*rsa_logo_T6Map[1].MapHeight*
		rsa_logo_T6Map[1].Tiles->TileWidth*rsa_logo_T6Map[1].Tiles->TileHeight)>>6)*sizeof(unsigned short)))==NULL)return;

	init_view_menu(&view_map);
	
	while(1){
		keyUp|=KEY_UP(K_ALL);
		if (KEY_DOWN(K_B)&&keyUp){
			free(view_map.MapData);
			return;
		}
		if (KEY_DOWN(K_ALL))
			keyUp=0;

		scroll_digit_background();
	}
}
