void display_processing_values(map_struct* map){
	map->Tiles=rsa_logo_T5Map[1].Tiles;
	map->MapWidth=rsa_logo_T5Map[1].MapWidth;
	map->MapHeight=rsa_logo_T5Map[1].MapHeight;
	map->Bounds=rsa_logo_T5Map[1].Bounds;
	map->MapCode=rsa_logo_T5Map[1].MapCode;
	memcpy(map->MapData,rsa_logo_T5Map[1].MapData,((rsa_logo_T5Map[1].MapWidth*rsa_logo_T5Map[1].MapHeight*
		rsa_logo_T5Map[1].Tiles->TileWidth*rsa_logo_T5Map[0].Tiles->TileHeight)>>6)*sizeof(unsigned short));

	int i,j;
	char buf[32];
	sprintf(buf,"%d",rsa_tab[rsa_index].nb);
	for(i=0;i<2;i++){
		for(j=0;j<strlen(buf);j++)
			map->MapData[30*(6+i)+19+j]=rsa_logo_T5Map[0].MapData[19*i+buf[j]-'0'+2];
		map->MapData[30*(6+i)+19+strlen(buf)]=rsa_logo_T5Map[0].MapData[19*i+18];
		for(j=0;j<strlen(buf)-2;j++)
			map->MapData[30*(9+i)+13+j]=rsa_logo_T5Map[0].MapData[19*i+1];
		for(j=0;j<8;j++)
			map->MapData[30*(9+i)+18+strlen(buf)-j]=rsa_logo_T5Map[0].MapData[19*i+(((rsa_tab[rsa_index].attempt>>(j*4))&0xF))+2];
		map->MapData[30*(9+i)+19+strlen(buf)]=rsa_logo_T5Map[0].MapData[19*i+18];
	}
	
	Transfert_Map(&Screen, map);
}

void init_processing_menu(map_struct* map){
	SetVideoMode(MODE0 | BG1 | BG2 | BG3);
	SetPaletteBKG_All(rsa_logo_processing_palette_Pal);
	SetBGx_CR(&Screen, 0, TILEBLOCK2 | MAPBLOCK28 | COLOR256 | SIZE0 | PRIORITY0);
	Transfert_Tiles(2, &rsa_logo_Tiles[5]);
	display_processing_values(map);
	SetVideoMode(MODE0 | BG0 | BG1 | BG2 | BG3);
}

u8 process_key(){
	struct BigInteger fct,tmp;
	initBigInteger(&fct);
	initBigInteger(&tmp);
	u8 runFlg=1,keyUp=0;
	map_struct processing_map;
	if((processing_map.MapData=(unsigned short*)malloc(((rsa_logo_T5Map[1].MapWidth*rsa_logo_T5Map[1].MapHeight*
		rsa_logo_T5Map[1].Tiles->TileWidth*rsa_logo_T5Map[1].Tiles->TileHeight)>>6)*sizeof(unsigned short)))==NULL)return 0;

	init_processing_menu(&processing_map);
	
	while(runFlg){
		setRsaRand(&fct,rsa_tab[gcd_index].root.size);
		do{
			addInt(&fct,2);
			gcdBigInteger(&tmp,&fct,&gcd_tab[gcd_index].gcd_nb);
			scroll_digit_background();
		}while(compareBigIntegerInt(&tmp,1)!=0);
		modBigInteger(&tmp,&rsa_tab[rsa_index].rsa_nb,&fct);
		if(compareBigInteger(&tmp,0)==0){
			setBigIntegerCopy(&rsa_tab[rsa_index].factor,&fct);
			save_factor();
			runFlg=0;
		}

		keyUp|=KEY_UP(K_ALL);
		if (KEY_DOWN(K_B)&&keyUp)
			runFlg=0;
		if (KEY_DOWN(K_ALL))
			keyUp=0;

		rsa_tab[rsa_index].attempt++;
		display_processing_values(&processing_map);
		scroll_digit_background();
	}

	save_attempt();

	clearBigInteger(&fct);
	clearBigInteger(&tmp);
	free(processing_map.MapData);

	return runFlg;
}
