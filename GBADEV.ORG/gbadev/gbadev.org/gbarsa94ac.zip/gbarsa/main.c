#include "DirectGBA.h"
#include "saving.h"
#include "mygmp.h"

#include "images/rsa_logo.h"

#define NB_GCD 3
#define NB_RSA 8

#define BLOCK_SIZE 1024
#define ID_STR "GBA_RSA 1.0"

struct rsa_bigInteger
{
	unsigned int nb,attempt;
	struct BigInteger rsa_nb,factor,root;
};

struct gcd_bigInteger
{
	unsigned int nb;
	struct BigInteger gcd_nb;
};

bkg_struct Logo,Digits,Shading,Screen;
text_struct Font8x8;

static struct gcd_bigInteger gcd_tab[NB_GCD];
static struct rsa_bigInteger rsa_tab[NB_RSA];
static u8 gcd_index=0,rsa_index=0;
static u32 rand_seed=0x0;

void scroll_digit_background(void){
	static u32 LastTime = 0;
	u32 CurrentTime = GetTicks();
	if((CurrentTime - LastTime)>0x1FFF){
		Scroll_TextBkg(&Digits, 0,-1);
		Scroll_TextBkg(&Digits, -1,0);
		LastTime=CurrentTime;
	}
}

void setTextMode(void)
{
	SetBGx_CR(&Screen, 0, TILEBLOCK1 | MAPBLOCK28 | COLOR256 | SIZE0 | PRIORITY0);
	Transfert_Map(&Screen, &rsa_logo_T1Map[3]);
}

void save_attempt(){
	SaveInt(strlen(ID_STR)+1+2*sizeof(unsigned int)+rsa_index*BLOCK_SIZE,rsa_tab[rsa_index].attempt);
}

void save_factor(){
	char buff[BLOCK_SIZE];
	getBigIntegerStr(&rsa_tab[rsa_index].factor,buff);
	SaveString(strlen(ID_STR)+1+2*sizeof(unsigned int)+rsa_index*BLOCK_SIZE+sizeof(unsigned int),buff);
}

void load_attempt(){
	rsa_tab[rsa_index].attempt=(unsigned int)LoadInt(strlen(ID_STR)+1+2*sizeof(unsigned int)+rsa_index*BLOCK_SIZE);
}

void load_factor(){
	char buff[BLOCK_SIZE];
	LoadString(strlen(ID_STR)+1+2*sizeof(unsigned int)+rsa_index*BLOCK_SIZE+sizeof(unsigned int),BLOCK_SIZE-sizeof(unsigned int),buff);
	setBigIntegerStr(&rsa_tab[rsa_index].factor,buff);
}

void load_rand_seed(){
	rand_seed=(unsigned long)LoadInt(strlen(ID_STR)+1+sizeof(unsigned int));
}

void save_rand_seed(){
	SaveInt(strlen(ID_STR)+1+sizeof(unsigned int),rand_seed);
}

void load_gcd_index(){
	gcd_index=(unsigned long)LoadInt(strlen(ID_STR)+1);
}

void save_gcd_index(){
	SaveInt(strlen(ID_STR)+1,gcd_index);
}

#include "view_key.h"
#include "process_key.h"
#include "setup_menu.h"
#include "process_menu.h"
#include "main_menu.h"

void init(void)
{
	gcd_tab[0].nb=16;
	initBigIntegerSetStr(&gcd_tab[0].gcd_nb,"341dd47f9f45c500af");
	gcd_tab[1].nb=32;
	initBigIntegerSetStr(&gcd_tab[1].gcd_nb,"60488f03402cd4e539501ff7d84b78e2f2a4b1adc2c3");
	gcd_tab[2].nb=64;
	initBigIntegerSetStr(&gcd_tab[2].gcd_nb,"b4747d2963d813a6ee4d3db5d8a7d921bdc8b1c65928b0de80277a1ab2da918fd7c4709d5c42d7073e107e4b5d1df0aa1b781e8b01");

	rsa_tab[0].nb=576;
	initBigIntegerSetStr(&rsa_tab[0].rsa_nb,"c2cbb24fdbf923b61268e3f11a3896de4574b3ba58730cbd652938864e2223eeeb704a17cfd08d16b46891a61474759939c6e49aafe7f2595548c74c1d7fb8d24cd15cb23b4cd0a3");
	initBigIntegerSetStr(&rsa_tab[0].root,"df4f8e1d2e88a0f7b88e87a82d49252ff0bdf111579ccfd7eb11c097176b5dc1e5e22022");
	rsa_tab[1].nb=640;
	initBigIntegerSetStr(&rsa_tab[1].rsa_nb,"ae5bb4f266003259cf9a6f521c3c03410176cf16df53953476eae3b21ede6c3c7b03bdca20b31c0067ffa797e4e910597873eef113a60feccd95deb5b2bf10066be2224ace29d532dc0b5a74d2d006f1");
	initBigIntegerSetStr(&rsa_tab[1].root,"d3458a58e3ae698dae1e9ff2cd9d0f709410f45bb30b1a8e099e69ada735b430b099759d236be4ce");
	rsa_tab[2].nb=704;
	initBigIntegerSetStr(&rsa_tab[2].rsa_nb,"e1341893fe6e6816cec8a970a39c00fa547c7da2cdedab0a62b91c4651a83f96380bcfaee26f7e866107906389421b1e68d0a17aadc9870b9858e956286e3999e98cec9881534ac772ae78f5e8aba1e2f8d3039577029d87");
	initBigIntegerSetStr(&rsa_tab[2].root,"f01bc73bed3125d4ec1253b219363a192d33c6ba24cdba2e5b8723a65b7e40467879b20c0e48c8c9aff4cbd8");
	rsa_tab[3].nb=768;
	initBigIntegerSetStr(&rsa_tab[3].rsa_nb,"cad984557c97e039431a226ad727f0c6d43ef3d418469f1b375049b229843ee9f83b1f97738ac274f5f61f401f21f1913e4b64bb31b55a38d398c0dfed00b1392f0889711c44b359e7976c617fcc734f06e3e95c26476091b52f462e79413db5");
	initBigIntegerSetStr(&rsa_tab[3].root,"e3e167adb765a3952b235c501b454b02a8cf5c888cb671cde02c88cc938a3aa8e37c37a4fbaf18da733069e16487a5ad");
	rsa_tab[4].nb=896;
	initBigIntegerSetStr(&rsa_tab[4].rsa_nb,"c7a85633bb0a423869d4af11300db9b80940821efd000cfcd5c568af1ef3f68fccf0433981e22a755c8a55b6aee9e10d5739e85741e2b30008b776540e958d213dea358147994c8df5e3b34b90d626c0e0e356569f97d948b5c19be32517d1dc1ab89866e0b275655e0e0fa64021278f");
	initBigIntegerSetStr(&rsa_tab[4].root,"e21493912f2ca5cb30f065132d01fecd61902492ea762fa4c893c531f9c1ba6712534dc3ace1250eff7326525a9cc2116325779c4e2590c3");
	rsa_tab[5].nb=1024;
	initBigIntegerSetStr(&rsa_tab[5].rsa_nb,"c05748bbfb5acd7e5a77dc03d9ec7d8bb957c1b95d9b206090d83fd1b67433ce83ead7376ccfd612c72901f4ce0a2e07e322d438ea4f34647555d62d04140e1084e999bb4cd5f947a76674009e2318549fd102c5f7596edc332a0ddee3a355186b9a046f0f96a279c1448a9151549dc663da8a6e89cf8f511baed6450da2c1cb");
	initBigIntegerSetStr(&rsa_tab[5].root,"dde63646e59ed2981246c1da57b93096f0160adae89bacd9e8beff3647dd637c06c8446e2b35cc3f8055d1a5a085129daafae5e3a991317529a80c474a6e417b");
	rsa_tab[6].nb=1536;
	initBigIntegerSetStr(&rsa_tab[6].rsa_nb,"c43ea6f7ac84155e40f7028dbf6324fc90ee8498f07b176497884f51e244a7a40e749a8e6929143510a8cfb2f82abb1a730b299032d91623984c49cc1af19303182d7541994dd46f2dc28e7c69ec9682577bcd6b5a6be7f55e67764f8e63c3c4335c1b84ccfd766f29ff042d4102ac23cf0b9aa2b2d395cadca95c4aecc970beec6292a2fe95ef68593a2894c1393d6919fb1e1cfc7d4912ffb9f758e11cf4e5062b973cea95df1f6175f51167cfad93be8d24ab16719778ed128f67f9659725");
	initBigIntegerSetStr(&rsa_tab[6].root,"e023ca43da5f8e13c1bea189ab2b8231730dbc4b034384d1b687837c2ea9865285b06ec455b7a4b181f1a5c7dfef074f9f932dd8b91839a996b6bc734721aaf43c6ecfe8c9ee1b79dbde3b10104a4d75ed03d28eeb6f21ba91cd26dbcf85069a");
	rsa_tab[7].nb=2048;
	initBigIntegerSetStr(&rsa_tab[7].rsa_nb,"c7970ceedcc3b0754490201a7aa613cd73911081c790f5f1a8726f463550bb5b7ff0db8e1ea1189ec72f93d1650011bd721aeeacc2acde32a04107f0648c2813a31f5b0b7765ff8b44b4b6ffc93384b646eb09c7cf5e8592d40ea33c80039f35b4f14a04b51f7bfd781be4d1673164ba8eb991c2c4d730bbbe35f592bdef524af7e8daefd26c66fc02c479af89d64d373f442709439de66ceb955f3ea37d5159f6135809f85334b5cb1813addc80cd05609f10ac6a95ad65872c909525bdad32bc729592642920f24c61dc5b3c3b7923e56b16a4d9d373d8721f24a3fc0f1b3131f55615172866bccc30f95054c824e733a5eb6817f7bc16399d48c6361cc7e5");
	initBigIntegerSetStr(&rsa_tab[7].root,"e20ac9e6361d8925e264d5bc33db342f03130762ddee46b2dbfcf70b6aba296b67eaacf4e94db8265a15e5d852c851f7ea030f319e1acab41142eaea07871a3bab5ee2c9e9017b248f39fb038c43b1ce290596077a219a939671c116b5e4d3f0661c40463aa2b4802f78a14b7cbeac431a52d10796818400cc467413d57d1224");

	char buff[32];
	LoadString(0,strlen(ID_STR)+1,buff);
	if(strncmp(ID_STR,buff,strlen(ID_STR)+1)==0){
		for(rsa_index=0;rsa_index<NB_RSA;rsa_index++){
			load_attempt();
			load_factor();
		}
		load_gcd_index();
		load_rand_seed();
		rand_seed++;
	}else{
		SaveString(0,ID_STR);
		for(rsa_index=0;rsa_index<NB_RSA;rsa_index++){
			rsa_tab[rsa_index].attempt=0;
			initBigIntegerSetInt(&rsa_tab[rsa_index].factor,0);
			save_attempt();
			save_factor();
		}
		save_gcd_index();
	}
	rsa_index=0;
	save_rand_seed();
	srand(rand_seed);

	setBigIntegerStr(&rsa_tab[0].factor,"cce95457f127c49546e57841029ac6af70604c64e8281018acbb538233bb57f37a6e6895");
	rsa_tab[0].attempt=0;
}

void AgbMain(void)
{
	init();

	// initialisation des timers
	InitTime();

	// initialisation des elements visuels
	rsa_logo_Init();
	InitText_Small(&Font8x8, &Screen, ' ');

	// initialisation de la palette
	SetPaletteBKG_All(rsa_logo_bck_palette_Pal);

	// Mise en place des Tiles en Memoire video
	Transfert_Tiles(0, &rsa_logo_Tiles[0]); //RSA logo
	Transfert_Tiles(1, &rsa_logo_Tiles[1]); //Font 8*8

	// Mise en place du logo
	SetBGx_CR(&Logo, 2, TILEBLOCK0 | MAPBLOCK31 | COLOR256 | SIZE0 | PRIORITY2);
	Transfert_Map(&Logo, &rsa_logo_T0Map[0]);

	// Mise en place des digits
	SetBGx_CR(&Digits, 3, TILEBLOCK1 | MAPBLOCK30 | COLOR256 | SIZE0 | PRIORITY3);
	Transfert_Map(&Digits, &rsa_logo_T1Map[2]);

	// Mise en place du white shading
	SetBGx_CR(&Shading, 1, TILEBLOCK1 | MAPBLOCK29 | COLOR256 | SIZE0 | PRIORITY1);
	Transfert_Map(&Shading, &rsa_logo_T1Map[1]);

	// Mise en place de l'alpha blending
	Set_Alpha(BG(Shading.Num), BG(Logo.Num)|BG(Digits.Num), 12, 4);

	// Activation du mode 0
	SetVideoMode(MODE0 | BG1 | BG2 | BG3);

	main_menu();

/*
		int i;
		for(i=0;i<3000;i++)
			WaitVBLANK();*/

/*	InitText_Small(&Font8x8, &Screen, ' ');

	int x=10,y=10;
	while(1){
		
		//Wait_KeyDown(K_ALL);

		if (KEY_DOWN(K_DOWN)){
			//Scroll_TextBkg(&Digits, 0,1);
			PrintTextCR(Font8x8, x, y, "             ");
			y++;
		}
		if (KEY_DOWN(K_UP)){
			//Scroll_TextBkg(&Digits, 0,-1);
			PrintTextCR(Font8x8, x, y, "             ");
			y--;
		}
		if (KEY_DOWN(K_RIGHT)){
			//Scroll_TextBkg(&Digits, 1,0);
			PrintTextCR(Font8x8, x, y, "             ");
			x++;
		}
		if (KEY_DOWN(K_LEFT)){
			//Scroll_TextBkg(&Digits, -1,0);
			PrintTextCR(Font8x8, x, y, "             ");
			x--;
		}

		//char buf[30*20];
		//getBigIntegerStr(&gcd64,buf);
		//PrintTextCR(Font8x8, 0, 0, buf);
		PrintTextCR(Font8x8, x, y, "Hello world !");
		//Wait(0x0fff*1);
		int i;
		for(i=0;i<3000;i++)
			WaitVBLANK();

		Scroll_TextBkg(&Digits, 0,-1);
		Scroll_TextBkg(&Digits, -1,0);

		//Wait_KeyUp(K_ALL);
	}*/

	for(gcd_index=0;gcd_index<NB_GCD;gcd_index++)
		clearBigInteger(&gcd_tab[gcd_index].gcd_nb);
	for(rsa_index=0;rsa_index>NB_RSA;rsa_index++){
		clearBigInteger(&rsa_tab[rsa_index].rsa_nb);
		clearBigInteger(&rsa_tab[rsa_index].factor);
		clearBigInteger(&rsa_tab[rsa_index].root);
	}
}
