void display_setting_values(u8 crtItem,map_struct* map){
	map->Tiles=rsa_logo_T3Map[crtItem].Tiles;
	map->MapWidth=rsa_logo_T3Map[crtItem].MapWidth;
	map->MapHeight=rsa_logo_T3Map[crtItem].MapHeight;
	map->Bounds=rsa_logo_T3Map[crtItem].Bounds;
	map->MapCode=rsa_logo_T3Map[crtItem].MapCode;
	memcpy(map->MapData,rsa_logo_T3Map[crtItem].MapData,((rsa_logo_T3Map[0].MapWidth*rsa_logo_T3Map[0].MapHeight*
		rsa_logo_T3Map[0].Tiles->TileWidth*rsa_logo_T3Map[0].Tiles->TileHeight)>>6)*sizeof(unsigned short));

	int i,j,k;
	for(i=0;i<NB_GCD;i++){
		char buf[32];
		sprintf(buf,"%0*d",2,gcd_tab[i].nb);
		for(j=0;j<3;j++){
			map->MapData[30*(2*3+j)+17+(i*4)]=rsa_logo_T3Map[2].MapData[(j*18)+(gcd_index==i?0:18*3)];
			for(k=0;k<2;k++)
				map->MapData[30*(2*3+j)+17+(i*4)+k+1]=rsa_logo_T3Map[2].MapData[(j*18)+(gcd_index==i?0:18*3)+buf[k]-'0'+1];
			map->MapData[30*(2*3+j)+17+(i*4)+3]=rsa_logo_T3Map[2].MapData[(j*18)+(gcd_index==i?0:18*3)+17];
		}
	}
	for(i=0;i<8;i++)
		for(j=0;j<3;j++)
			map->MapData[30*(4*3+j)+i+20]=rsa_logo_T3Map[2].MapData[(j*18+1+((rand_seed>>(28-(i*4)))&0xF))+(18*3*(1-crtItem))];

	Transfert_Map(&Screen, map);
}

void init_setup_menu(u8 crtItem,map_struct* map){
	SetVideoMode(MODE0 | BG1 | BG2 | BG3);
	SetPaletteBKG_All(rsa_logo_setup_palette_Pal);
	SetBGx_CR(&Screen, 0, TILEBLOCK2 | MAPBLOCK28 | COLOR256 | SIZE0 | PRIORITY0);
	Transfert_Tiles(2, &rsa_logo_Tiles[3]);
	display_setting_values(crtItem,map);
	SetVideoMode(MODE0 | BG0 | BG1 | BG2 | BG3);
}

void setup_menu(void)
{
	u8 crtItem=0,keyUp=0;
	u32 old_rand_seed=rand_seed;
	map_struct setup_map;
	if((setup_map.MapData=(unsigned short*)malloc(((rsa_logo_T3Map[0].MapWidth*rsa_logo_T3Map[0].MapHeight*
		rsa_logo_T3Map[0].Tiles->TileWidth*rsa_logo_T3Map[0].Tiles->TileHeight)>>6)*sizeof(unsigned short)))==NULL)return;

	init_setup_menu(crtItem,&setup_map);

	while(1){
		keyUp|=KEY_UP(K_ALL);
		if (KEY_DOWN(K_UP)&&keyUp)crtItem=0;
		else if (KEY_DOWN(K_DOWN)&&keyUp)crtItem=1;
		else if (KEY_DOWN(K_RIGHT)){
			switch(crtItem){
			case 0:
				if (keyUp&&gcd_index<NB_GCD)
					gcd_index++;
				break;
			case 1:
				rand_seed++;
				break;
			}
		}
		else if (KEY_DOWN(K_LEFT)){
			switch(crtItem){
			case 0:
				if (keyUp&&gcd_index>0)
					gcd_index--;
				break;
			case 1:
				rand_seed--;
				break;
			}
		}
		else if (KEY_DOWN(K_A)&&keyUp){
			switch(crtItem){
			case 0:
				// GCD size
				break;
			case 1:
				rand_seed=rand();
				break;
			}
		}
		else if (KEY_DOWN(K_B)&&keyUp){
			free(setup_map.MapData);
			save_gcd_index();
			if(rand_seed!=old_rand_seed){
				save_rand_seed();
				srand(rand_seed);
			}
			return;
		}
		if (KEY_DOWN(K_ALL)){
			keyUp=0;
			display_setting_values(crtItem,&setup_map);
		}

		scroll_digit_background();
	}
}
