 ----------------------------------------------------------------------------
   || CHRISTMAS ADVANCE || by ZoneGN ||
 ----------------------------------------------------------------------------
  - For Visoly's X-Mas Demo Compo 2001 -
 ----------------------------------------------------------------------------

 Programmer / Music composer / Graphic Designer : ZoneGN (www.zonegn.com)
 Music engine by Sergej Kravcenko ( sergej@codewaves.com - www.codewaves.com)

 ----------------------------------------------------------------------------
 The game:
 ----------------------------------------------------------------------------
 "Christmas Advance" is a freeware!

 "Christmas Advance" is a remake of the famous snake game.

 You are Santa Clause and you must pick all xmas gifts up. 

 Special note: The game has been programmed in 1 week 1/2. ( ^^; )

 Enjoy!

 ----------------------------------------------------------------------------
 Credits & Greetings:
 ----------------------------------------------------------------------------
 To all my Friends & familly ^^

 ----------------------------------------------------------------------------
 Contact:
 ----------------------------------------------------------------------------

 ZoneGN email : contact@zonegn.com | Website : http://www.zonegn.com

 Visoly INC. : http://www.visoly.com
