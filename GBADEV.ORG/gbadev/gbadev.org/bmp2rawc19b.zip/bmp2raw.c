#include <allegro.h>


#include <stdio.h>
 unsigned long int bitmap_offset[1024];
 FILE *f;
 int i,j,loop1,loop2;
 int bitmap_count;
  BITMAP *input;
 PALLETE temppal;
void print_instructions(void)
{
 printf("Amy's 16 colour sprite making program v0.2\n");
 printf("Usage:\n bmp2raw <num> file.tmp sprite1.bmp sprite2.bmp ...  \n");
 printf("where <num>=0 means generate bitmap info\n");
 printf("and   <num>=1 means generate pallete info\n");
}

void print_bitmap(void)
{
 unsigned short int temp;
 for(j=0;j<=(*input).h-1;j=j+8)
    {
      for(i=0;i<=(*input).w-1;i=i+8)
	{

	  for(loop1=0;loop1<=7;loop1++)
	    {
	      for(loop2=0;loop2<=7;loop2=loop2+4)
		{
		  printf(".");
		  temp=getpixel(input,i+loop2,j+loop1)+
		    16*getpixel(input,i+loop2+1,j+loop1)+
		    256*getpixel(input,i+loop2+2,j+loop1)+
	            4096*getpixel(input,i+loop2+3,j+loop1);		  fwrite(&temp,sizeof(short),1,f);
//fprintf(f,"%d",getpixel(input,i+loop2,j+loop1)+getpixel(input,i+loop2+1,j+loop1)*16);
		}
	    }
	printf("!!\n");
        }
      //printf("\n");
    }
 bitmap_offset[bitmap_count]=bitmap_offset[bitmap_count-1]+((*input).h-1)*((*input).w-1);
 fprintf(stderr,"%d,%d,%d\n",(*input).h,(*input).w,bitmap_offset[bitmap_count]);
 bitmap_count++;
}


void print_pal(void)
{
 int r,g,b;
 unsigned short temp;
for(i=0;i<=15;i++)
 {
  r=temppal[i].r;
  g=temppal[i].g;
  b=temppal[i].b;
  r=r/2;
  g=g/2;
  b=b/2;
  temp=b*32*32+g*32+r;

fwrite(&temp,sizeof(short),1,f) ; 
//writef(f,,g*32*32+r*32+b);
//   if(i!=15) printf(",");
//  if(i==7) printf("\n");

 }
// printf("\n");
}

main(int argc, char *argv[])
{
 int loop;
 int option;
 allegro_init();
 install_keyboard();
 if(argc<4) print_instructions(); else
 {
  bitmap_offset[0]=0;
  bitmap_count=1;
  f=fopen(argv[2],"w");
  for(loop=3;loop<=argc-1;loop++)
  {

   printf("\n // Start of %s \n",argv[loop]);
   input=load_bitmap(argv[loop],temppal);
   if(!input) fprintf(stderr,"Couldn't load file: %s\nDoes it exist? Is it a valid file?\n",argv[loop]);
   else
   {
    option=atoi(argv[1]);
    if(option==0)  print_bitmap();
    else print_pal();
   }
   if(loop<argc-1) printf(",");
  }
 
 printf("\n static const unsigned int %s_offset [",argv[2]);

 for(i=0;i <= bitmap_count-2; i++)
 {
  printf("%d", bitmap_offset[i]);
  if(i!=bitmap_count-2) printf(",");
 }
 printf("];\n");
 }
for(i = 0; i <= argc; i++)
      fprintf(stderr,"arg %d: %s\n", i, argv[i]);
return 0;
}


