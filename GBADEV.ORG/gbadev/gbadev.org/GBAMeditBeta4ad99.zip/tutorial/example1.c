//------------------------------------------//
//   BG tutorial for MapEdit by Warder1     //
//------------------------------------------//
//This example loads a 32x32 map into vram  //
//and displays it.							//
//Step 1:									//
//Draw your map in GBAMapEditor 			//
//Step 2:									//
//Export your map to c						//
//Step 3:									//
//Convert your tile .bmp using spritestripper//
//and hackit								//
//Step 4									//
//Compile using ARM and it will run on a 	//
//real GBA									//
//------------------------------------------//
#define DISPCNT		*(u32*)0x04000000			//Sets DISPCNT to be the register for it.  Easier than using the hex every time
#define BG0CNT		*(u16*)0x04000008			//Sets BG0CNT to be the register for it.  Easier than using the hex every time

typedef unsigned char u8;						//some type definitions
typedef unsigned short u16;
typedef unsigned long u32;

#include "map1.c"

extern u16 BKGtiles;							//adds the tiles and palette from data.asm
extern u16 tilePalette;

u16 *pal=(u16*)0x5000000;						//tells the compiler to load all the pallette info into that address
u16 *tmp_pal;

u16 *tiles=(u16*)0x6004000;						//tells the compiler to load all the tile info into that address	
u16 *bg_data;

u16  *m0=(u16*)0x6000000;						//tells the compiler when our bkg map is going to be located

void MakeBKG()
{
	u16 x,y,i;									//define some temp variables
	   	bg_data = (u16*)(&BKGtiles);			//have bg_data point to our .raw defined in data.asm
	   	tmp_pal = (u16*)(&tilePalette);			//have tmp_pal point to our .pal defined in data.asm

	   	for (i=0;i<256;i++) pal[i]=tmp_pal[i];	//load the pallette info into the desired address

	   	for(i=0;i<64*600;i++) tiles[i]=bg_data[i];//load the bg tiles into the desired address

   		for (y=0;y<32;y++) 						//loop to load in the map data
		   for (x=0;x<32;x++) {
			    m0[y*32+x]=map[y*32+x];
		   }
		
}

void Init()
{
	BG0CNT = 0x0084;							//turn on BG0CNT.  Also tells where the map and tile locations are for this bkg
	DISPCNT = 0x0140;							//sets the display mode to display BKG0 
}

void C_Entry()
{
	Init();										//call init to set up our screen display
	
	MakeBKG();									//display the background

	while (1)									//loop
	{}
  
 }