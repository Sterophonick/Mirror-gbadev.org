>>Example Readme<<
The following 3 files are examples only. Tiles are (c) squaresoft (they're ripped from ff4).

>To view the exapmles<
Extract the bmp and the map files to the desired location. Run the map editor and load
the map files.


