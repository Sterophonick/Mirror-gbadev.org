------------------------------------------------------------------
				GBA Map Editor Beta 4
------------------------------------------------------------------
Controls
------------------------------------------------------------------
Left Mouse Button	-	Places a tile, or selects the tile

Shortcuts:
Ctrl + N		-	New Map
Ctrl + S		-	Save
Ctrl + L		- 	Load
Ctrl + E		-	Export to .c
Ctrl + P		-	Properties
Ctrl + R		-	Clear screen
------------------------------------------------------------------
Usage
------------------------------------------------------------------
Before you start you need to load a tile set.  Under tools select
tiles -> load tiles and select a .bmp.  Now you can select 
different tiles and draw with it.  When you are ready to use the 
map in gba you can use export to .c
Block select is very easy to use.  When you need to select more
than an 8x8 square of tiles, just click block select on and then
select multiple tile by dragging a rectangle in tools.  To go back
to regular paint, just turn block select off
Zoom works, but be careful about going over 2x
Included is a tutorial written by Subice on how to make a map
and use it in your gba game.
------------------------------------------------------------------
Updates
------------------------------------------------------------------
Beta 4:
-Long awaited release (by who I don't know)
-Subice primary coder
-Major bug fixes
-Choice between 16x16 or 8x8 tiles
-Paint bucket removed

Beta 3:
-Block selected added
-Resizing bug fixed
-Basics of a tile editor added
-Icons used for pencil and fill tools
-Many little bugfixes

Beta 2:
-Zoom
-Paint bucket added
-Small bug fixes

Beta 1:
-First Release
-Save/load/export all work
------------------------------------------------------------------
Bugs
------------------------------------------------------------------
-Be careful of zooming over 2x
------------------------------------------------------------------
Thanks to:
Subice, Yozzi and sgstair on efnet
------------------------------------------------------------------
Visit #gbadev on efnet
and
my website at:
www.nolag.com/code/gbdev

Warder1
warder@nolag.com