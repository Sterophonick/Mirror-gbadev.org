Breakout
========

Remake of the classic game 'Breakout'.  Bounce the ball off of your paddle to
hit the blocks.  When the ball hits a block, that block will either change
colour or disappear.  The colour of a block indicates how many more times it
needs to be hit to disappear.

If the ball hits the bottom of the screen, you lose a life.  You start out
with 9 of these, and there is (currently) no way to get them back.

Remove all of the blocks to complete the level!

If the paddle is moving in the same direction as the ball when the ball hits
the balls directory will change to move it faster in that direction.
Conversely, moving in the opposite direction will cause the balls direction to
be more straight up and down.

Controls
========

left/right	- Moves the paddle left or right
'A'		- Launches the ball when it is sitting on the paddle
'Start'		- Starts the game from the title/game over screens

Source
======

The files in 'source.zip' are basically a dump of everything in my own
working directory.

I'm afraid to say it's a mess :)  If you are still interested, e-mail me back
in about a month and maybe I'll have tidied it up a little :)

mailto:mscales@blueyonder.co.uk

-----------------------------------------------------------------------------

This program is free to use and ditribute for non-commercial use.

Programming and design by Matthew 'ProbBob' Scales, Copyright (c) 2003

With thanks to :
	dovoto for his excellent tutorials.

	Rob Andrews, for his invaluable technical information ;)

	The denizens of #gbadev, for help, entertainment and for keeping the
		community alive.