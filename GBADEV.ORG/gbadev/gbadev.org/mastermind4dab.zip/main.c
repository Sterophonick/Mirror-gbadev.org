// This is the game Super Master Mind for the gameboy advance written by Keith Epstein
// The original board game was made by Invicta Plastics
// Lots of code in here is based on the visual HAM demos/samples by Peter Schraut
// This code makes excessive use of HAMlib by Emanuel Schleussinger
// Thank you to everyone who posts at gbadev.org


#include <mygba.h>
#include <math.h>

extern const unsigned short background_Map[1024];
extern const unsigned char background_Tiles[38208];
extern const unsigned short master_Palette[256]; // palette for running on emulator
extern const unsigned short master_Palette_hard[256]; // palette for running on hardware
unsigned short Palette_BG[256];

extern const unsigned short instructions_Map[1024];
extern const unsigned char instructions_Tiles[25984];

extern const unsigned char red_Bitmap[256];
extern const unsigned char orange_Bitmap[256];
extern const unsigned char yellow_Bitmap[256];
extern const unsigned char green_Bitmap[256];
extern const unsigned char blue_Bitmap[256];
extern const unsigned char purple_Bitmap[256];
extern const unsigned char black_Bitmap[256];
extern const unsigned char white_Bitmap[256];
extern const unsigned char black_small_Bitmap[256];
extern const unsigned char white_small_Bitmap[256];
extern const unsigned char selector_Bitmap[256];
extern const unsigned char question_Bitmap[256];
extern const unsigned short sprite_Palette[256]; // palette for running on emulator
extern const unsigned short sprite_Palette_hard[256]; // palette for running on hardware
unsigned short Palette_sprite[256];

#define WHITE 0
#define ORANGE 1
#define YELLOW 2
#define GREEN 3
#define BLUE 4
#define PURPLE 5
#define BLACK 6
#define RED 7
#define BLACK_SMALL 8
#define WHITE_SMALL 9
#define SELECTOR 10
#define QUESTION 11

/**************
 * PROTOTYPES
 **************/
void vblFunc();
void LoadSprite(u8 index, u8 color, u8 xloc, u8 yloc);
void kre_fadepal(void);
void kre_unfadepal(unsigned short palette[]);
void showinstructions(void);
void hideinstructions(void);
extern u8 IsRealGBA(void);
void Adjust_palettes(void);


// global variables

void *sprites[12]; // array of pointers to sprites
u8  g_sprite[128];   // Global Sprite (index)
u8 numsprites = 0;
u8 created = 0; // 1 if sprite at column has been created, 0 if not
u8 guess[5] = {0}; // this is the colors that the player guesses, from left to right
u8 spritenum[5] = {0}; // this is the sprite number at the selected column
u8 qsprite[5] = {0}; // these are the sprite numbers of the question marks
u8 code[5] = {0};  // this is the code that must be broken
u8 column = 0; // current guess column
u8 guesses = 0; // number of gueses
u8 xStart = 79; // this is where the board starts, x coordinate
u8 yStart = 148; // this is where the board starts, y coordinate
u8 xPitch = 13; // pitch from space to space
u8 yPitch = 12; // pitch from space to space
u8 xStartKey = 40; // this is where the keys start, x coordinate
u8 yStartKey = 151; // this is where the keys start, y coordinate
u8 xPitchKey = 7; // pitch from key to key
u8 won = 0; // this goes to 1 when the game is won
u8 codedrawn = 0; // has the code been revealed
unsigned long seed; // for determining the code
u8 newframe = 0; // updated every vblank
u8 instructions = 0;// 0 during normal play, 1 when instructions are shown.  When == 1, buttons don't control game, they exit instruction mode



int main(void)
{

   Adjust_palettes();

    sprites[0] = &white_Bitmap;
    sprites[1] = &orange_Bitmap;
    sprites[2] = &yellow_Bitmap;
    sprites[3] = &green_Bitmap;
    sprites[4] = &blue_Bitmap;
    sprites[5] = &purple_Bitmap;
    sprites[6] = &black_Bitmap;
    sprites[7] = &red_Bitmap;
    sprites[8] = &black_small_Bitmap;
    sprites[9] = &white_small_Bitmap;
    sprites[10] = &selector_Bitmap;
    sprites[11] = &question_Bitmap;
    
    ham_Init();
    ham_SetBgMode(0);
    ham_InitText(0);
    ham_SetTextCol(0x10,0x00);
    ham_SetBgVisible(0,1);
    
    // Inits the Palette for the Sprite
    ham_LoadObjPal((void *)&Palette_sprite,        // a pointer to the palette data that is to be loaded
                  SIZEOF_16BIT(Palette_sprite));  // the number of the 16 color OBJ (sprite) palette you
                                                  // want to load with the 16 color values at address src.
    // Load Background Palette
    ham_LoadBGPal((void *)&Palette_BG,         // a pointer to the palette data that is to be loaded
                  SIZEOF_16BIT(Palette_BG));   // the size of the data in u16 chunks (usually 256)
                  
    ham_bg[3].ti = ham_InitTileEmptySet(1024,1,1);
    ham_bg[3].mi = ham_InitMapEmptySet(0,0);
    ham_SetBgVisible(3,1);
    showinstructions();
    ham_InitBg(3,   // The BGs number that you want to Initialize (0-3)
               1,   // 1 = show this BG, 0 = hide this BG
               1,   // Priority of this BG to other BGs (0 = highest prio, 3 = lowest)
               1);  // Enable / Disable Mosaic for this BG (0=off 1=on)
               
    ham_StartIntHandler(INT_TYPE_VBL,         // The Interrupts ID you want to start.
                       (void *)&vblFunc);    // The adress of a function that should be called when the interrupt is fired

    ham_InitPad();
    
    while(Pad.Pressed.A == 0 && Pad.Pressed.B == 0 && Pad.Pressed.Start == 0 && Pad.Pressed.Select == 0)
    { ham_UpdatePad(); }
    Pad.Pressed.A = 0;
    // after one of these buttons are pushed, fade the master palette to black
    kre_fadepal();

    // hide the instructions (show the main game board)
    hideinstructions();
    
    // fade the palette back to normal
    kre_unfadepal(Palette_BG);

    
    ham_DrawText(19,5,"Press A");
    ham_DrawText(19,6,"TO START");
    // this is here to make some vblanks to change the seed
    while(Pad.Pressed.A == 0)
    {
     ham_UpdatePad();
     srand(seed);
    }
    ham_DrawText(19,5,"       ");
    ham_DrawText(19,6,"        ");
        
    while(TRUE)
    {
    ham_UpdatePad();
    if(won == 0) // if didn't pick the right combo yet
    {
        if(guesses == 12) // if reached the limit on the number of guesses
        {
            if(codedrawn == 0) // if the code has not been revealed
            {
                int i;
                // reveal the code, and tell the player that they LOST
                for(i = 0;i<5;i++)
                {
                    ham_UpdateObjGfx(g_sprite[qsprite[i]],sprites[code[i]]);
                }
                ham_DrawText(19,5,"YOU LOST!");
                ham_DrawText(20,6,"PRESS B");
                ham_DrawText(19,7,"TO RESTART");
            }
            codedrawn = 1;
            // restart the game when B is pressed at the appropriate time
            if(Pad.Pressed.B && (instructions == 0))
            {
                ham_DrawText(19,5,"         ");
                ham_DrawText(20,6,"       ");
                ham_DrawText(19,7,"          ");
                ham_ResetObj();

                won = 0;
                guesses = 0;
                numsprites = 0;
                codedrawn = 0;
                int i;
                for(i=0;i<5;i++)
                {
                  created = 0;
                    guess[i] = 0;
                }
            } // end B pressed
        } // end if guesses == 12
        if((guesses == 0) && (created == 0)) // this is the beginning
        {
            // pick a code
            int i = 0;
            for(i=0;i<5;i++)
            {
                code[i] = seed % 8;
                seed += rand();
            }

            // load selector, first color, and question marks
            LoadSprite(0,SELECTOR,xStart-1,yStart-1); numsprites++;
            for(i=0;i<5;i++)
            {
                LoadSprite(++numsprites,WHITE,xStart+i*xPitch,yStart-guesses*yPitch);
                created = 1;
                spritenum[i] = numsprites;
                LoadSprite(++numsprites,QUESTION,xStart+i*xPitch,yStart-12*yPitch-2);
                qsprite[i] = numsprites;
            }
        }
        if(guesses>0 && guesses < 12) // if in the middle of game
        {

            // draw color if needed
            int i;
            if(created!=1){
            for(i=0;i<5;i++)
            {
                // move selector
                ham_SetObjXY(g_sprite[0],xStart+column*xPitch-1,yStart-guesses*yPitch-1);
                LoadSprite(++numsprites,WHITE,xStart+i*xPitch,yStart-guesses*yPitch);
                created = 1;
                spritenum[i] = numsprites;
            }
            }
        }
            
        
        // UP PRESSED
        if(Pad.Pressed.Up && instructions == 0 && guesses < 12)
        {
            
            if(guess[column] < 7)
            {
                guess[column]++;
            }
            else
            {
                guess[column] = 0;
            }

            ham_UpdateObjGfx(g_sprite[spritenum[column]],sprites[guess[column]]);
        }
        // DOWN PRESSED
        if(Pad.Pressed.Down && instructions == 0 && guesses < 12)
        {
            if(guess[column] > 0)
            {
                guess[column]--;
            }
            else
            {
                guess[column] = 7;
            }

            ham_UpdateObjGfx(g_sprite[spritenum[column]],sprites[guess[column]]);
        }
        // RIGHT PRESSED
        if(Pad.Pressed.Right && instructions == 0 && guesses < 12)
        {
            if(column<4)
            {
                column++;
            }
            ham_SetObjX(g_sprite[0],xStart+column*xPitch-1);
        }
        // LEFT PRESSED
        if(Pad.Pressed.Left && instructions == 0 && guesses < 12)
        {
            if(column>0)
            {
                column--;
            }
            ham_SetObjX(g_sprite[0],xStart+column*xPitch-1);
        }
        // COMPARE TO CODE WHEN A IS PRESSED
        if(Pad.Pressed.A && instructions == 0 && guesses < 12)
        {
            int i = 0;
            int num_blacks = 0;
            int num_whites = 0;

            // check for blacks and whites
            for(i=0;i<5;i++)
            {
                if(code[i] == guess[i])
                {
                    num_blacks++;
                }
                else if((code[i] == guess[0]) || (code[i] == guess[1]) || (code[i] == guess[2]) || (code[i] == guess[3]) || (code[i] == guess[4]))
                {
                    num_whites++;
                }
            }
            
            if(num_blacks == 5)
            {
                won = 1;
            }
            
            // place blacks and whites
            for(i=0;i<num_blacks;i++)
            {
                LoadSprite(++numsprites,BLACK_SMALL,xStartKey+i*xPitchKey,yStartKey-guesses*yPitch);
            }
            for(i=0;i<num_whites;i++)
            {
                LoadSprite(++numsprites,WHITE_SMALL,xStartKey+(i+num_blacks)*xPitchKey,yStartKey-guesses*yPitch);
            }
            
            guesses++;
            column = 0;
            for(i=0;i<5;i++)
            {
                created = 0;
                guess[i] = 0;
            }
                
            
        }  // end A pressed
        
        // instructions = 2 when it is first shown, need to change it to 1 so they can be hidden when needed
        if(instructions == 2)
        { instructions = 1; }
         // show instructions only if start is pressed while instructions are not shown
        if(Pad.Pressed.Start && instructions == 0)
        {
            showinstructions();
        }
        
         // hide instructions if a button is pressed while instructions are shown
        if((Pad.Pressed.Start || Pad.Pressed.Select || Pad.Pressed.A || Pad.Pressed.B) && instructions == 1)
        {
            hideinstructions();
        }
        

        

    } // end if won == 0 (still playing)
    
    // do the following if the game has been won
    if(won == 1)
    {
        ham_DrawText(19,5,"YOU WON!!");
        ham_DrawText(20,6,"PRESS B");
        ham_DrawText(19,7,"TO RESTART");
        // draw the code
        int i;
        if(codedrawn == 0){
        for(i = 0;i<5;i++)
        {
            ham_UpdateObjGfx(g_sprite[qsprite[i]],sprites[code[i]]);
        }
        }
        codedrawn = 1;
        if(Pad.Pressed.B)
        {
            ham_DrawText(19,5,"         ");
            ham_DrawText(20,6,"       ");
            ham_DrawText(19,7,"          ");
            ham_ResetObj();

            won = 0;
            guesses = 0;
            numsprites = 0;
            codedrawn = 0;
            int i;
            for(i=0;i<5;i++)
            {
                created = 0;
                guess[i] = 0;
            }
        }
            
    }

    } // end while
    return 0;

}

void vblFunc()
{
    ham_CopyObjToOAM();
    seed += rand();
    newframe = 1;
}

// does the sprite loading
void LoadSprite(u8 index, u8 color, u8 xloc, u8 yloc)
{
    // Returns the ham_obj entry which is now associated with the sprite created.
    // Memory for the graphics are automatically allocated and the sprite data is
    //copied. Remember that this does not mean the sprite is comitted to Hardware yet,
    // you need to run ham_CopyObjToOAM for that
    g_sprite[index] = ham_CreateObj(sprites[color],  // A pointer to the tile data for this object
                             0,                       // obj_shape
                             1,                       // obj_size
                             OBJ_MODE_NORMAL,         // obj_mode
                             1,                       // col_mode
                             0,                       // pal_no
                             1,                       // mosaic <-- 1 = use mosaic mode!
                             0,                       // hflip
                             0,                       // vflip
                             0,                       // dbl_size
                             0,                       // prio
                             xloc,                   // x position of sprite on screen
                             yloc);                  // y position of sprite on screen

    ham_SetObjVisible(g_sprite[index],1); // display selected sprite
    
}

void kre_fadepal(void)
{
    int fadepal;
    int color;
    for(color = 0;color<=31;color++)
    {
        for(fadepal = 0;fadepal<=510;fadepal+=2)
        {
            int r = RGB_GET_R_VALUE(*(unsigned short*)(MEM_PAL_BG+fadepal));
            int g = RGB_GET_G_VALUE(*(unsigned short*)(MEM_PAL_BG+fadepal));
            int b = RGB_GET_B_VALUE(*(unsigned short*)(MEM_PAL_BG+fadepal));
            if(r > 0)
            {
                r -= 1;
            }
            if(g > 0)
            {
                g -= 1;
            }
            if(b > 0)
            {
                b -= 1;
            }
            int i;
            for(i=0;i<80;i++) // DELAY to slow it down
            {i = i;} 
            *(unsigned short*)(MEM_PAL_BG+fadepal) = RGB(r,g,b);
        }
    }
}

// this function shows bg0, hides bg1 and sprites to make only instructions visible
void showinstructions(void)
{
    ham_ReloadTileGfx(ham_bg[3].ti,(void*)&instructions_Tiles,0,600);
    ham_DeInitMapSet(ham_bg[3].mi);
    ham_bg[1].mi = ham_InitMapSet((void*)&instructions_Map,SIZEOF_16BIT(instructions_Map),0,0);
    ham_CreateWin(0,0,0,240,160,WIN_BG3,WIN_OBJ,0);
    instructions = 2; // make it 2 so that it doesn't get hidden right away at next if statement
}

// this function shows the normal board again
void hideinstructions(void)
{
    ham_ReloadTileGfx(ham_bg[3].ti,(void*)&background_Tiles,0,600);
    ham_DeInitMapSet(ham_bg[3].mi);
    ham_bg[3].mi = ham_InitMapSet((void*)&background_Map,SIZEOF_16BIT(background_Map),0,0);
    ham_DeleteWin(0);
    instructions = 0;
}

void Adjust_palettes(void)
{
int i = 0;
   switch(IsRealGBA())
   {
      /* 0 = Emulator */
      case 0:
         // use emulator palette
         for(i=0;i<256;i++) {
         Palette_BG[i] = master_Palette[i];
         Palette_sprite[i] = sprite_Palette[i];
         }
         break;

      /* 1 = Real hardware */
      case 1:
         // adjust palettes to compensate - used gamma = 1.5 to make this palette
         for(i=0;i<256;i++) {
         Palette_BG[i] = master_Palette_hard[i];
         Palette_sprite[i] = sprite_Palette_hard[i];
         }
         break;
      default:
         for(i=0;i<256;i++) {
         Palette_BG[i] = master_Palette[i];
         Palette_sprite[i] = sprite_Palette[i];
         }
         break;
   }
}

void kre_unfadepal(unsigned short palette[])
{
    int fadepal;
    int color;
    // get red, green, and blue of palette to return to
    int red[256];
    int green[256];
    int blue[256];
    for(fadepal=0;fadepal<=255;fadepal++)
    {
      red[fadepal] = RGB_GET_R_VALUE(palette[fadepal]);
      green[fadepal] = RGB_GET_G_VALUE(palette[fadepal]);
      blue[fadepal] = RGB_GET_B_VALUE(palette[fadepal]);
    }

    for(color = 255;color>=0;color--)
    {
        for(fadepal = 0;fadepal<=255;fadepal++)
        {
            int r = red[fadepal] - color;
            int g = green[fadepal] - color;
            int b = blue[fadepal] - color;
            if(r > red[fadepal])
            {
                r = red[fadepal] ;
            }
            if(r<0) r = 0;
            if(g > green[fadepal])
            {
                g = green[fadepal];
            }
            if(g<0) g = 0;
            if(b > blue[fadepal])
            {
                b = blue[fadepal];
            }
            if(b<0) b = 0;
            *(unsigned short*)(MEM_PAL_BG+fadepal*2) = RGB(r,g,b);
        }
    }
}

/* END OF FILE */
