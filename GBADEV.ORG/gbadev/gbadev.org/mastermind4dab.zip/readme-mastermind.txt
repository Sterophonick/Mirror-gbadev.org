This is a GBA version of the board game Super Master Mind by Invicta Plastics.
The goal is to determine the hidden color code through educated guessing.
After each guess, you will be given information about your guess that you can use to determine your next guess.
Source code is included.