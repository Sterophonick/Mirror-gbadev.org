------------------------
| AGB_Trek Version 1.0 |
------------------------

2008 Gameboy Advance port of
Super Star Trek by Donnie Russell

1996 C port by Chris Nystrom

1978 BASIC version published in the book
BASIC Computer Games edited by David Ahl

1972 BASIC version by Mike Mayfield



AGB_Trek is not affiliated with Paramount Pictures or CBS Studios.
STAR TREK is a registered trademark of Paramount Pictures.
STAR TREK and related marks are trademarks of CBS Studios, Inc.

Sound effects are from the Star Trek - Strategic Operations Simulator
arcade game released by Sega in 1982.



License
=======

The software contained in this archive is freeware, and may not be sold in any
form for any reason whatsoever. This software is provided to the end-user
"as is", and comes with no warranty of any kind. In no event shall the
copyright owner be liable for any damage that may result from the use of this
software.

This software may be redistributed provided that the original archive is
whole, intact, and unmodified. Only copies identical to the original
distribution archive available from my web site are authorized for
redistribution. Proper credit must be given to all people involved in the
creation of this software near the point of redistribution. Redistribution of
this software on cartridge media is strictly prohibited.



Controls
========

Menu prompt
-----------
Direction pad         Select option
A or Start button     Enter option

Number prompt
-------------
Direction pad         Select digit
A button              Type digit
B button              Backspace
L button              Type '-'
R button              Type '.'
Start button          Enter number (digit under cursor not included)

MORE prompt
-----------
Press any button except Select to continue.

All prompts
-----------
While holding down the Select button, use the direction pad to scroll back
through the text.
