// starfield test using my old GBC starfield code
//using the ARM SDK
//
//15 April 2001
// Richard "Ries" van der Brugge / rvdbrugge@yahoo.com
//

//replace this with the number of particles you want onscreen
#define MAXPART 800

//change this to 1 to get a fountain effect/all particles get drawn towards the floor
#define GRAVITY 0

//include standard routines
#include <stdlib.h>//for the rand function
#include "rieslib.h"



u16 part_x[MAXPART];
u16 part_y[MAXPART];
u16 part_xv[MAXPART];
u16 part_yv[MAXPART];
u16 part_color[MAXPART];

u16 gravity;



void InitParticle(long particle){
//set it somewhere in the middle
part_x[particle] = (rand()%4)+118;
part_y[particle] = (rand()%4)+78;
//vector values
part_xv[particle] = (rand()%20)-10;
part_yv[particle] = (rand()%28)-14;
//cycle color from 31 to 0 per particle
part_color[particle]=0;
}


//********************************************************************************
//entry from startup asm code, probably the only original bit in this source all others use c_entry :)))
//this is the replacement for the main() stuff you find in other C programs
//********************************************************************************
void StartHere()
{
long i;

SetDisplayMode4On();
CreatePalette();



//init all particles
for (i=0;i<MAXPART;i++){
InitParticle(i);
}

while(1){
	VSync();
	DMAClearScreen();
	for (i=0;i<MAXPART;i++){


			//the y vector is affected by gravity
			part_yv[i] = part_yv[i] + GRAVITY;

			//calculate new particle x/y posityion
			part_x[i] = part_x[i] + part_xv[i];
			part_y[i] = part_y[i] + part_yv[i];
			//set color, the longer the darker
			part_color[i]++;
			//check offscreen or color limits
			if ((part_x[i] < 1) || (part_x[i] > 240) || (part_y[i] < 1) || ( part_y[i] > 160)||(part_color[i] > 32)){
				InitParticle(i);
			}//fi
			DrawPixel(part_x[i],part_y[i],part_color[i]);
	}//next


	}//wend
}//end starthere
