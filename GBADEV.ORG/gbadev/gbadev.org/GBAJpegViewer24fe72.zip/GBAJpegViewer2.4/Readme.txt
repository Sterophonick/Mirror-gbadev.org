Readme file for GBA Jpeg viewer Version 2.3 by Tony Savon

GBAJpeg lets you display pictures in a slide-show fashion on a Gameboy Advance(tm). To create a jpeg GBA rom use the GBAJpegPacker included in the zip file: Open or drop the pictures in the listbox and press the "Create GBA rom..." button. The GBA rom can be loaded by a GBA emulator such as Visual Boy Advance ( http://vboy.emuhq.com ) or uploaded to a real Gameboy Advance using a flash2advance ( http://www.flash2advance.com ) or a similar backup tool.

Usage:
To browse the pictures of your slideshow use "L" and "R" keys on your Gameboy.
Hold "A" while pressing "L" or "R" to skip 10 pictures
Hold "B" while pressing "L" or "R" to skip 100 pictures
Press "A"+"B" to jump to a random picture
Hold Start and press Select to reset or to exit to Pogoshell
Press Select to bring up a simple help screen
Hold Start and press "R" to start slideshow mode
Hold Start and press "L" to switch to thumbnails mode
  In thumbnails mode use pad to move cursor, "L" & "R" to skip a page and "A" 
  to select a picture.  
Hold "A" and Press Pad Up and Down to adjust brightness
Hold "A" and Press Pad Right to zoom zoomable pictures, then use pad to scroll

Feel free to contact me for suggestions: tonysavon@hotmail.com
Download latest version from http://www.caimans.net/gba

GBA Jpeg Viewer is free, but if you are really happy with my software and you think it worths, please visit www.christopherreeve.org and make your donation to Christopher Reeve Paralysis Foundation. 

History

VERSION 2.4
-Better Jpeg packing (smaller files at the same quality)
-Faster Jpeg decoding
-Added a "Back to Pogoshell" function for Pogoshell users (like me). Thanks to Reesy for help.

VERSION 2.3
-Added a color dithering system: greatly enhanches display quality
-In thumbnail mode more infos on the pictures are shown
-Added pause option in slideshow mode
-New Graphics for menus
-In Jpeg Packer added settings for brightness and contrast
-Slighlty faster jpeg packing

VERSION 2.2
-Added Project Load/Save
-Added a thumbnail system

VERSION 2.1
-Support for bigger pictures with zoom/scrolling
-New graphic interface in Viewer
-Some minor changes in Packer

VERSION 2.0:

New Features:

-Brand new Jpeg decoding engine: up to 3 times faster!!!
-Added a password system
-Added a basic area selection option to encode only a part of a picture (useful when encoding comics)
-Added a Sharpen/text enhancement option (again:useful for comics). Use carefully because it slightly slows down decompression and increases jpeg size.

Bugfixes:
Some minor bugs in png decoding in Jpeg Packer fixed.
Tab order in packer fixed for proud keybord users :-)

VERSION 1.2:

New Features:

-Added a Rom size preview feature in Jpeg packer
-Better quality in Jpeg encoding
-Added a rom options button to specify rom internal name (required by some flash program)
-Added a slideshow mode in Jpeg viewer
-Added a nice "about box" in Jpeg packer (based on an idea by Tangor Fopper)
-Added dynamic brightness adjustment in Jpeg viewer
-Small pictures are now centered in GBA display
-Jpeg decoding is now 10-15% faster

Bugfixes:
-Some nasty buttons sequence freezed Jpeg Packer.

VERSION 1.1:

New Features:

-Added "Gamma correction"
-Added "Insert pictures" feature, to import pictures at a specific point in the list, first requested by Aghnar Le Bisaieul
-Added "Jump to Random picture", skip +-10 and +-100 pictures
-Added an image counter, first requested by Dermot Mac Flannchaidh
-Added "Reset", first requested by Jim Parask
-Added up and down buttons in GBA Jpeg packer and the ability to remove pictures pressing the "DEL" key, first requested by Phil Holden
-Added a simple help screen.

Bugfixes:

-Loading many pictures at a time with the add... button instead of drag and drop didn't work well. First reported by Zhao DingAn, Thanks Zhao!

VERSION 1.0: First release.
