ARM ASM Plasma Example
----------------------

Program... Old Skool Plasma Effect
Version... 1.01
Author.... Andrew Burch (Jesder)
Contact... diprod@dodo.com.au
Site...... http://members.dodo.com.au/~aburch


About this Example
------------------
I have decided to port a number of my old graphics effects which I wrote
in Turbo pascal a number of years ago. This is mainly to give me a more
comfortable feel with the ARM assembly instructions, and mode 4 on the GBA.

I've noticed a lack of ARM assembly source around - so I may turn some of
these into tutorials at some point :) 

The pregenerated tables i calc'ed in C++ and just outputed the results, and 
the images were converted from PCX files using my PCX2GBA tool which you
can find on the downloads page of my site (http://members.dodo.com.au/~aburch)

I have not included a whole heap of comments in the source code, 
but I've kept things straight forward and so you wouldn't have too 
much trouble understanding whats going on. You will need the goldroad 
assembler to compile the ARM asm sources and the gcc compiler to
compile the c examples. You can grab the goldroad assembler at 
http://www.goldroad.co.uk

If you have any feedback, I'd love to hear from you? Find anything useful
here? Love to hear from you also :)


Thanks
------
I would like to take this short opportunity to thank a few people:

SimonB @ gbadev.org  - The site has been a very useful resource for me!
Dovoto @ PernProject - For getting the basics across to me
Rob    @ goldroad    - Your ARM assembler is a dream to work with!