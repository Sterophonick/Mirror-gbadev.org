GBA Sound Demo
Brendan Sechter <sgeos@granicus.if.org>
May 16, 2003

A fairly simple example of getting the GBA to spit out sound.
It uses channel 1 and is not interactive.

See agb_notes.c for my notes and a frequency table.  (Notes is
a pun in this case, although that was not intentional.)
