#ifndef AGB_NOTES_C
#define AGB_NOTES_C

/*** About agb_notes.c
 *
 *  Brendan Sechter <sgeos@granicus.if.org>
 *  May 16, 2003
 *
 *  Disclaimer:  These are my notes.  They may
 *    be wrong.  If you find an error, please
 *    inform me.  ("The whole thing!")
 *
 *  The first 3 notes are bogus.
 *  They are set to the lowest value, and are
 *  more or less just place holders.
 *  Everything from A9 up is a little silly,
 *  and probably shouldn't be used, A11 and up
 *  especially so.  They've been included for
 *  complete-ness.
 *
 *  Treble Clef:  E4 to F5 (note[31] to note[44])
 *  Alto Clef:    F3 to G4 (note[20] to note[34])
 *  Bass Clef:    G2 to A3 (note[10] to note[24])
 *
 *  C2 = note[ 3]
 *  C3 = note[15]
 *  C4 = note[27]
 *  C5 = note[39]
 *  C6 = note[51]
 *  C7 = note[63]
 *  C8 = note[75]
 *
 *  The midi number for C2 is 36.
 *
 *  AGB Play Frequency in Hz (V from 0x000 to 0x7FF):
 *    0x20000 / (0x800 - V)
 *
 *  Solved for V (Hz from 0x40 to 0x20000):
 *    0x800 - 0x20000 / Hz
 *
 *  Any note in the next octave has twice the Hz.
 *  There are 12 semitones.  Therefore, the
 *  frequency of the next semitone equals the
 *  frequency of the current semitone times the
 *  12th root of two, in Hz.  (The 12th root of
 *  two, to the power of twelve equals two.)
 *  A above middle C, A4, is defined as 440 Hz.
 *
 *  Here are the twelve semitones:
 *  A A# B C C# D D# E F F# G G#
 *
 *  References:
 *    http://www.dolmetsch.com/introduction.htm
 *      http://www.dolmetsch.com/musictheory1.htm
 *    http://belogic.com/gba/
 *      http://belogic.com/gba/channel1.shtml
 *      http://belogic.com/gba/registers.shtml
 *    http://www.work.de/nocash/gbatek.htm
 *      http://www.work.de/nocash/gbatek.htm#soundcontroller
 */

const unsigned short note[144] =
{

/*  XX     XX     XX     C2     C2#    D2   */
  0x000, 0x000, 0x000, 0x02C, 0x09C, 0x106,
  0x16A, 0x1C9, 0x222, 0x276, 0x2C6, 0x311,
/*  D2#    E2     F2     F2#    G2     G2#  */


/*  A2     A2#    B2     C3     C3#    D3   */
  0x358, 0x39B, 0x3DA, 0x416, 0x44E, 0x483,
  0x4B5, 0x4E4, 0x511, 0x53B, 0x563, 0x588,
/*  D3#    E3     F3     F3#    G3     G3#  */


/*  A3     A3#    B3     C4     C4#    D4   */
  0x5AC, 0x5CD, 0x5ED, 0x60B, 0x627, 0x641,
  0x65A, 0x672, 0x688, 0x69D, 0x6B1, 0x6C4,
/*  D4#    E4     F4     F4#    G4     G4#  */


/*  A4     A4#    B4     C5     C5#    D5   */
  0x6D6, 0x6E6, 0x6F6, 0x705, 0x713, 0x720,
  0x72D, 0x739, 0x744, 0x74E, 0x758, 0x762,
/*  D5#    E5     F5     F5#    G5     G5#  */


/*  A5     A5#    B5     C6     C6#    D6   */
  0x76B, 0x773, 0x77B, 0x782, 0x789, 0x790,
  0x796, 0x79C, 0x7A2, 0x7A7, 0x7AC, 0x7B1,
/*  D6#    E6     F6     F6#    G6     G6#  */


/*  A6     A6#    B6     C7     C7#    D7   */
  0x7B5, 0x7B9, 0x7BD, 0x7C1, 0x7C4, 0x7C8,
  0x7CB, 0x7CE, 0x7D1, 0x7D3, 0x7D6, 0x7D8,
/*  D7#    E7     F7     F7#    G7     G7#  */


/*  A7     A7#    B7     C8     C8#    D8   */
  0x7DA, 0x7DC, 0x7DE, 0x7E0, 0x7E2, 0x7E4,
  0x7E5, 0x7E7, 0x7E8, 0x7E9, 0x7EB, 0x7EC,
/*  D8#    E8     F8     F8#    G8     G8#  */


/*  A8     A8#    B8     C9     C9#    D9   */
  0x7ED, 0x7EE, 0x7EF, 0x7F0, 0x7F1, 0x7F2,
  0x7F2, 0x7F3, 0x7F4, 0x7F4, 0x7F5, 0x7F6,
/*  D9#    E9     F9     F9#    G9     G9#  */


  0x7F6, 0x7F7, 0x7F7, 0x7F8, 0x7F8, 0x7F9,  /* A9 */
  0x7F9, 0x7F9, 0x7FA, 0x7FA, 0x7FA, 0x7FB,
  0x7FB, 0x7FB, 0x7FB, 0x7FC, 0x7FC, 0x7FC,  /* A10 */
  0x7FC, 0x7FC, 0x7FD, 0x7FD, 0x7FD, 0x7FD,
  0x7FD, 0x7FD, 0x7FD, 0x7FE, 0x7FE, 0x7FE,  /* A11 */
  0x7FE, 0x7FE, 0x7FE, 0x7FE, 0x7FE, 0x7FE,
  0x7FE, 0x7FE, 0x7FE, 0x7FF, 0x7FF, 0x7FF,  /* A12 */
  0x7FF, 0x7FF, 0x7FF, 0x7FF, 0x7FF, 0x7FF,
};

#endif  /* AGB_NOTES_C */
