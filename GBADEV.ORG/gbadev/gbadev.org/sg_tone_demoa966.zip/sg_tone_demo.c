/*** Compile Options

gcc -Wall -o sg_tone_demo.elf sg_tone_demo.c
objcopy -v -O binary sg_tone_demo.elf sg_tone_demo.bin
gbarm sg_tone_demo.bin -t'SG TONE DEMO' -cSGTD -mSG -p -v -i

 */


/*** Included files
 */
#include "agb_notes.c"


/*** Function Prototypes
 */
void *music(void);


/*** Global Variables
 */
int mus_len;
int mus_time;
int mus_tone;


/*** stall()
 *
 *  Stall until next vblank.
 */
void *stall(void)
{
  while (*(volatile unsigned short *)0x04000006 == 160);
  while (*(volatile unsigned short *)0x04000006 != 160);
  return music;
}


/*** glow()
 *
 *  Something visual.  If there is a sound problem
 *  we can tell that the code is running.
 */
void *glow(void)
{
  *(unsigned short *)0x05000000 =
    mus_tone % 0x20 | (0x1F - mus_tone % 0x20) << 10;
  return stall;
}


void *music(void)
{
  int prim_note[7] = {0,2,3,5,7,8,10};
  int tone[] =
  {
    7,5,3,1,4,
    6,5,4,5,4,
    3,4,5,6,5,
    4,3,4,5,6,
    5,4,5,6,7,
    7,1,6,2,5,
    3,4,7,1,6,
    2,5,3,4,5,
    3,4,4,3,4,4,
    2,3,3,2,3,3,
    2,3,4,2,
    2,3,4,2,
    3,4,4,3,4,4,
    2,3,3,2,3,3,
    3,4,4,2,3,3,
    3,4,4,2,3,3,
    4,6,6,5,4,4,
    5,4,3,2,1,
    3,5,
  };
  int len[] =
  {
    2,2,2,2,2,
    1,1,2,1,1,
    2,1,2,1,1,
    2,1,1,2,1,
    1,1,1,1,1,
    1,1,1,1,1,
    1,1,1,1,1,
    1,1,1,1,1,
    1,1,2,1,1,2,
    1,1,2,1,1,2,
    1,1,2,1,
    1,1,2,1,
    1,1,2,1,1,2,
    1,1,2,1,1,2,
    1,1,2,1,1,2,
    1,1,2,1,1,2,
    1,1,2,1,1,2,
    1,1,1,1,2,
    2,2,
  };

  mus_time++;
  if (mus_time > mus_len * len[mus_tone])
  {
    mus_tone++;
    if (mus_tone >= sizeof(tone) / sizeof(int))
      mus_tone = 0;
    mus_time = 0;
    *(unsigned short *)0x04000064 =
//      0x8000 | 64 * (tone[mus_tone] + 16);
      0x8000 | note[36 + prim_note[tone[mus_tone] - 1]];
  }
  return glow;
}


void *music_init(void)
{
  mus_len  =  20;  /* Bigger = Slower */
  mus_tone =  -1;
  mus_time = 255;
  *(unsigned short *)0x04000084 = 0x0080;
  *(unsigned short *)0x04000082 = 0x0002;
  *(unsigned short *)0x04000080 = 0x1177;
  *(unsigned short *)0x04000060 = 0x0008;
  *(unsigned short *)0x04000062 = 0xF600; // 0x8600;  // 0xF0C0;
  *(unsigned short *)0x04000064 = 0xC000;
  return music;
}


/*** main_init()
 *
 *  Main program initialization function.
 */
void *main_init(void)
{
  *(unsigned short *)0x04000000 = 0x0000;
  return music_init;
}


/*** main()
 *
 *  fptr is a function pointer.
 *  Call the function pointed to by fptr,
 *  and set fptr to the return value.
 *  Repeat.
 *  The functions called by main return the
 *  address of the next funtion to be called.
 *  If the addres of an init function is returned,
 *  then something is reinitialized.
 *  This is usually some version of a software reset.
 */
int main(void)
{
  void *(*fptr)(void) = main_init;
  while ((fptr = fptr()));
  return (0);
}
