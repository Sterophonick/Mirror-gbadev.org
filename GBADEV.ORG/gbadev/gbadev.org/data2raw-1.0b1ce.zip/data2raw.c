/*
    Data2Raw. A small tool for creating tiles in Game Boy Advance format.
    Copyright (C) 2001 Davide Inglima 

    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program; if not, write to the Free Software
    Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA

    Author Contact: hadesnebula@libero.it
                    Davide Inglima, 
                    Via Bruna 53
                    10070 San Francesco al Campo (To)
                    Italy
*/

#include <stdio.h>
#include <strings.h>
#include <ctype.h>

#define OUTSIDE    0x00
#define TAG        0x01
#define INSIDE     0x02
#define LOWMASK    0x0F
#define NOLOW      0xF0

#define COMMENT    0x00
#define STRING     0x10 
#define REVERSE_16 0x30
#define COLOR_16   0x40
#define REVERSE_FF 0x50
#define COLOR_FF   0x60
#define HIGHMASK   0xF0
#define NOHIGH     0x0F

#define ODD        0x00
#define EVEN       0x01

#define getchar()	getc(fileinput)
#define putchar(cache)  putc((cache),fileoutput)

char status; 
char charnumber;
char cache, c, tagnumber;  
long tag;
FILE *fileinput, *fileoutput;

void process_inside(char input);
void process_tag(char input);
void process_outside(char input);

void tag_reset()
{
  tag=0;
}

int main(int argc, char *argv[])
{
  int i;
  status     = OUTSIDE; 
  charnumber = ODD;
  fileoutput = stdout;
  fileinput  = stdin;
  tag_reset();

  // Command Line manipulation: input and output file.

  if (--argc > 0)
  {
    if (!(strcmp(argv[1],"-") == 0))
    {
      if ((fileoutput = fopen(argv[1], "w+")) == NULL)
      {
        fprintf( stderr, "I can't open output file %s\n", argv[1]);
        exit(1);
      }
    }
  }

  if (--argc > 0)
  {
    if (!(strcmp(argv[2],"-") == 0))
    {
      if ((fileinput = fopen(argv[2], "r")) == NULL)
      {
        fprintf( stderr, "I can't open input file %s\n", argv[2]);
        exit(2); 
      }
    }
  }

  // main loop 

  while ((c = getchar()) != EOF)
  {
    switch (status & LOWMASK) 
    {
      case INSIDE  : process_inside(tolower(c));
                     break;
      case TAG     : process_tag(tolower(c));
                     break;
      default      : process_outside(tolower(c));
                     break;
    }
  }
  return 0;
} 

void process_r0f(char input);
void process_c0f(char input);
// void process_cff(char input);
// void process_string(char input);
void process_comment(char input);

void process_outside(char input)
{
  //we are outside any string and we are parsing the whitespace 
  //looking for the start of meaningful tags. 

  switch (input)
  {
    case ';':
    case '#':
      status = INSIDE | COMMENT;
      break;
    case '0':
    case 'f':
      status = TAG;
      tag = (long)input;      
      tagnumber = 1;
      break;
  }

}

void process_tag(char input)
{
  tag <<= 4;
  tag |= input;
  tagnumber++;

  if (tag == ('0' << 8 | 'f' << 4 | 'r')) 
  {
    status = INSIDE | REVERSE_16;
    tag_reset();
  }
  else if (tag == ('0' << 8 | 'f' << 4 | 'a'))
  {
    status = INSIDE | COLOR_16;
    tag_reset();
  }
/*  else if  (tag == ('f' << 8 | 'f' << 4 | 'r'))
  {
    status = OUTSIDE;
    fprintf(stderr, "You choose tag ffr");
    tag_reset();
  }
*/
  else if (tag == ('f' << 8 | 'f' << 4 | 'a'))
  {
    status = INSIDE | COLOR_FF;
    tag_reset();
  }  
  else
  {
    if (tagnumber == 5)
    {  
      fprintf(stderr, "Error, no valid tag given.");
      fprintf(stderr, "%d",tag);
      fprintf(stderr, "\n");
      tag_reset();
      status = OUTSIDE;
    }
  } 
}

void process_inside(char input)
{
   switch(status & HIGHMASK)
   { 
     case COMMENT:    process_comment(input);
                      break;
     case REVERSE_16: process_r0f(input);
                      break;

     case COLOR_16:
     case COLOR_FF:   process_c0f(input);
                      break;
   }
}

void process_r0f(char input)
{
  // Whitespace: we finished to process r0f 

  if (input == ' ' || input == '\n' || input == '\t')
  {
    status = OUTSIDE;
  }

  // Valid digit: we process it. 
  else if (isdigit(input) || (input >= 'a' && input <= 'f'))
  {
  
    if (isdigit(input))
    {
      input -= '0';   
    }
    else if (input >= 'a' && input <= 'f')
    {
      input -= 'a';
    }

    if (charnumber == ODD)
    {
      cache = (input);
    }
    else
    {
      cache = cache | ((input)<<4);
      putchar(cache);
    }
    charnumber ^= EVEN; 
  }

  //Non valid character
  else
  {
    fprintf(stderr, "unrecognized character %c \n", input);
  }

}

void process_c0f(char input)
{
  //Again... whitespace. 

  if (input == ' ' || input == '\n' || input == '\t')
  {
    status = OUTSIDE;
  }

  //Valid digit
  else if (isdigit(input) || (input >= 'a' && input <= 'f'))
  {
  
    if (isdigit(input))
    {
      input -= '0';   
    }
    else if (input >= 'a' && input <= 'f')
    {
      input -= 'a';
    }

    if (charnumber == ODD)
    {
      cache = (input);
    }
    else
    {
      cache = ((cache)<<4) | input;
      putchar(cache);
    }
    charnumber ^= EVEN; 
  }

  // Unrecognized character... :p
  else
  {
    fprintf(stderr, "unrecognized character %c \n", input);
  }
}

void process_comment(char input)
{
  // It's a comment. If it is a newline, it is no more a comment. 
  if (input == '\n')
  {
        status = OUTSIDE;
  }
}

