Boing! May 07, 2001

Running well with VGBA 0.6 and Igba. thanks Marat and Iki!

Does it works under real GBA ?... 

Boing! is the GBA conversion of the Amiga Boing! demo.
More informations on this great demo of 1985 can be found at
http://www.jimbrooks.org/web/opengl/boing/boing.html

Nowadays, you could smile when looking at this demo, but in 1985
it was really stunning! I think that a lot of guys bought Amiga
computers after seeing this...

I had a very good time on Amiga, like a lot of you perhaps ?.. :)
And so, Boing! is a kind of tribute to the Amiga... and a way 
to test some simple GBA programming..

Thanks a lot to GXB for support, and ass kicking some times... ;)
but warning, I know how to kick too!.. ;)))

Thanks a lot to all GBA fans, GBA web sites webmasters, and every one 
who help us to find how to code on GBA..

Best regards!

devpsx@hotmail.com

( GFX and SFX makers WELCOME ! )
