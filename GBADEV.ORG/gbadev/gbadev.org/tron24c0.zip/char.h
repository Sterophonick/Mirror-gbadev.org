void DisplayChar(int digit, int x, int y);
void DisplayNumber(int number, int x, int y);
void DisplayText(char *string, int length, int x, int y);

u32 chr[96] = {
		0x00000000, // ' '
		0x06666060, // '!' 
		0x05500000, // '"' 
		0x05f55f50, // '#'
		0x027e3e20, // '$'
		0x00924900, // '%'
		0x04aa7a60, // '&'
		0x06240000, // '''
		0x02444420, // '(' 
		0x04222240, // ')' 
		0x06f69000, // '*'
		0x00272000, // '+'
		0x00000624, // ',' 
		0x000f0000, // '-'
		0x00000660, // '.'
		0x11224488, // '/'
		0x06999960, // '0'
		0x02622220, // '1'
		0x069124f0, // '2'
		0x0f121960, // '3'
		0x0359f110, // '4'
		0x0f8e1960, // '5'
		0x078e9960, // '6'
		0x0f112440, // '7'
		0x06969960, // '8'
		0x06997160, // '9'
		0x00000000, // ':' [Still blank]
		0x00000000, // ';' [Still blank]
		0x00000000, // '<' [Still blank]
		0x00000000, // '=' [Still blank]
		0x00000000, // '>' [Still blank]
		0x00000000, // '?' [Still blank]
		0x00000000, // '@' [Still blank]
		0x0699f990, // 'A'
		0x0e9e99e0, // 'B'
		0x06988960, // 'C'
		0x0e9999e0, // 'D'
		0x0f8e88f0, // 'E'
		0x0f8e8880, // 'F'
		0x0788b970, // 'G'
		0x099f9990, // 'H'
		0x0f6666f0, // 'I'
		0x0f222a40, // 'J'
		0x09aca990, // 'K'
		0x088888f0, // 'L' 
		0x09fd9990, // 'M' 
		0x09ddbb90, // 'N'
		0x06999960, // 'O'
		0x0e99e880,	// 'P'
		0x06999a50, // 'Q' 
		0x0e99e990, // 'R' 
		0x078421e0, // 'S' 
		0x0f666660, // 'T'
		0x09999960, // 'U' 
		0x0999ac80, // 'V'	
		0x0999bf90, // 'W' 
		0x09966990, // 'X' 
		0x09972220, // 'Y' 
		0x0f1248f0, // 'Z'
		0x00000000, // '[' [Still blank]
		0x00000000, // '\' [Still blank]
		0x00000000, // ']' [Still blank]
		0x00000000, // '^' [Still blank]
		0x00000000, // '_' [Still blank]
		0x02460000, // '`'
		0x00079970, // 'a'
		0x088e99e0, // 'b'
		0x00078870, // 'c'
		0x01179970, // 'd'
		0x0006f870, // 'e'
		0x00034f44, // 'f'
		0x0007971e, // 'g'
		0x088e9990, // 'h'
		0x02062270, // 'i'
		0x02062224, // 'j'
		0x088aca90, // 'k'
		0x04444420, // 'l'
		0x000ed990, // 'm'
		0x000e9990, // 'n'
		0x00069960, // 'o'
		0x000e9e88, // 'p'
		0x00079711, // 'q'
		0x000bc880, // 'r'
		0x0007c3e0, // 's'
		0x044f4430, // 't'
		0x00099960, // 'u'
		0x00099ac0, // 'v'
		0x00099b70, // 'w'
		0x00096690, // 'x'
		0x0009971e, // 'y'
		0x000f24f0, // 'z'
		0x244c4420, // '{'
		0x00000000, // '|' [Still blank]
		0x42232240, // '}'
		0x00000000, // '~' [Still blank]
		0x00000000, // '[DEL]' [Non - Printing]
};

void DisplayChar(int digit, int x, int y)
{
	digit = digit - 32;

	int i, j;
	for(i = 0; i < 4; i++)
	{
		for(j = 0; j < 8; j++)
		{
			PlotPixel(x + (3 - i), y + (7 - j), 0x7FFF * ((chr[digit] & 1 << (i + (j * 4))) >> (i + (j * 4))));
		}
	}
}

void DisplayNumber(int number, int x, int y)
{
	//Currently hacked to deal only with numbers that are six figures or less!
	int temp[6] = {0,0,0,0,0,0};
	int i, z;

	x = x - 30;	// Another hack!  The 'x' in the function call should be set to the *RIGHT* hand edge of the number

	for(i = 0; i < 6; i++)
	{
		temp[i] = number % 10;
		number -= temp[i];
		number = number / 10;
	}

	z = 0;

	for(i = 5; i >= 0; i--)						
	{
		if((i == 0) || (temp[i] != 0) || (z == 1))  // This 'if' stops us from printing leading zeroes
		{
			DisplayChar(temp[i] + 48, x, y);
			z = 1;
		}

		x = x + 5;
	}
}

void DisplayText(char *string, int length, int x, int y)
{ 

	int i;
	for(i = 0; i < length; i++)
	{
		if(y < 153)
		{
			if(string[i] > 31)
			{
				DisplayChar(string[i], x, y);
			}
			else
			{
				if(string[i] == '\n')
				{
					x = - 5;
					y = y + 8;
				}
			}

			x = x + 5;
	
			if(x > 235)
			{
				x = 0;
				y = y + 8;
			}
		}
	}		
}

