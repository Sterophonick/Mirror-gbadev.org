Tron 'Light Cycles' game
========================

A quick game I've knocked up over a few days.

Includes a High Score table that saves to catridge RAM.

Instructions on how to play are given on the intro screen.

(Although I forgot to mention that the start button is used to jump between
screens, and is also 'Pause', in-game)

Source
======

I have also included the full source.

* tron.c : The main game code
* char.h : A utility file for drawing text in mode 3
* help.h : Contains the string used for the intro screen

mailto:mscales@blueyonder.co.uk with comments, requests, etc..

-----------------------------------------------------------------------------

This program is free to use and ditribute for non-commercial use.

Programming and design by Matthew 'ProbBob' Scales, Copyright (c) 2003

With thanks to :
	dovoto for his excellent tutorials.

	Rob Andrews, for his invaluable technical information ;)

	The denizens of #gbadev, for help, entertainment and for keeping the
		community alive.