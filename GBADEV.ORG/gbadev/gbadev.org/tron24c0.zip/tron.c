// Typdefs
typedef unsigned char u8;
typedef unsigned short u16;
typedef unsigned long u32;

typedef signed char s8;
typedef signed short s16;
typedef signed long s32;

// Defines
#define REG_DISPCNT		*(volatile u16*)0x4000000
#define REG_BG2CNT		*(volatile u16*)0x400000C
#define VCOUNT			*(volatile u16*)0x4000006
#define REG_BG2X		*(volatile u32*)0x4000028
#define REG_BG2Y		*(volatile u32*)0x400002C

#define COLOUR(r, g, b)	((b << 10) | (g << 5) | r)
#define KEY_A 			1
#define KEY_B 			2
#define KEY_SELECT		4
#define KEY_START 		8
#define KEY_RIGHT 		16
#define KEY_LEFT 		32
#define KEY_UP 			64
#define KEY_DOWN 		128
#define KEY_R			256
#define KEY_L 			512

#define RAND_MAX 32767

//#define MAX_SCORE 40764

// Global Variables
volatile u32* KEYS = (volatile u32*)0x04000130;
u16* VRAM = (u16*)0x6000000;
u8* SAVERAM = (u8*)0xE000000;
volatile s32 RAND_RandomData;
int score;	// The players score
u16 ScreenSave[300];	// A big array to store screen data in for the area of the screen overwritten by the score.
char mstring[10] = "GAME OVER";	// Guess :)
char nstring[12] = "High Scores";
int i, j;	// General looping variables
int x, y;	// Cycle co-ordinates
int sx, sy;	// Text co-ordinates for score/'game over'/etc...
char savestring[35] = "TRONMATMATMATMATMATMATMATMATMATMAT";
int hiscore[11];
char hiname[11][3];
char pname[3] = "Mat";
char nameprompt[17] = "Enter your name!";


// Function Prototypes
void SeedRandom(void);
s32 RAND(s32 Value);
void InitScreen(void);
void ClearScreen(void);
void BuildHiscores(void);
void GetHiscores(void);
void SortScores(void);
void SaveScores(void);
void ShowScores(void);
void DrawBox(void);
void WaitKey(u16 key);
void PlotPixel(int x, int y, u16 c);
void GetName(void);

#include "char.h"
#include "help.h"

// Function Bodies
void AgbMain(void)
{

	//InitScreen();
	REG_DISPCNT = 0x1403;
	REG_BG2CNT = 0x0000;

	u8 col[3];	// Current colour (r, g, b)
	int StillGoing;	// Are we still alive?
	int d;		// Current direction

	if(!(SAVERAM[0] == 'T'))
	{
		BuildHiscores();
	}

	GetHiscores();
	SortScores();

	DisplayText(helpstring, 569, 0, 0);

	while(1)
	{
		WaitKey(KEY_START);

		if(score > hiscore[9])
		{
			GetName();
			hiscore[10] = score;

			for(i = 0; i < 3; i++)
			{
				hiname[10][i] = pname[i];
			}

			SortScores();
			SaveScores();
		}

		SeedRandom();
		
		ClearScreen();

		ShowScores();

		WaitKey(KEY_START);

		ClearScreen();
		DrawBox();

		x = 120;
		y = 80;

		d = KEY_RIGHT;

		StillGoing = 1;
		score = 0;

		sx = x;
		sy = y;

		while(StillGoing == 1)
		{

			if(!(*KEYS & KEY_START))
			{
				*KEYS = *KEYS ^ KEY_START;
				WaitKey(KEY_START);
			}

			if((d == KEY_RIGHT) || (d == KEY_LEFT))
			{

				if (!(*KEYS & KEY_UP))
				{
					d = KEY_UP;
				}
				else
				{
					if (!(*KEYS & KEY_DOWN))
					{
						d = KEY_DOWN;
					}
				}
			}

			if((d == KEY_UP) || (d == KEY_DOWN))
			{
				if (!(*KEYS & KEY_RIGHT))
				{
					d = KEY_RIGHT;
				}
				else
				{
					if(!(*KEYS & KEY_LEFT))
					{
						d = KEY_LEFT;
					}
				}
			}

			if(d == KEY_LEFT) { x--; }
			if(d == KEY_RIGHT) { x++; }
			if(d == KEY_UP) { y--; }
			if(d == KEY_DOWN) { y++; }

			if(VRAM[x + (y *240)] > 0)
			{
				StillGoing = 0;
			}
			else
			{
				score++;
			}

			if(x < 0) { x = 0; }
			if(x > 239) { x = 239; }
			if(y < 0) { y = 0; }
			if(y > 159) { y = 159; }

			for(i = 0; i < 3; i++)
			{
				col[i] = col[i] + (RAND(4) * (RAND(3) - 1));
				if(col[i] < 15) {col[i] = 15;}
				if(col[i] > 31) {col[i] = 31;}
			}

			while(VCOUNT != 160);

			for(i = 0; i < 30; i++)
			{
				for(j =0; j < 10; j++)
				{
					PlotPixel((sx - 25) + i, (sy - 1) + j, ScreenSave[i + (j * 30)]);
				}
			}

			PlotPixel(x, y, COLOUR(col[0], col[1], col[2]));
			
			REG_BG2X = (x - 120) << 8;
			REG_BG2Y = (y - 80) << 8;
			
			if(x < 35)
			{
				sx = x + 40;
			}
			else
			{
				sx = x - 10;
			}

			if(y < 15)
			{
				sy = y + 10;
			}
			else
			{
				sy = y - 10;
			}

			for(i = 0; i < 30; i++)
			{
				for(j =0; j < 10; j++)
				{
					ScreenSave[i + (j * 30)] = VRAM[(sx - 25) + i + (((sy - 1) + j) * 240)];
				}
			}

			DisplayNumber(score, sx, sy);

		}

		for(i = 0; i < 30; i++)
		{
			for(j =0; j < 10; j++)
			{
				ScreenSave[i + (j * 30)] = 0x0000;
			}
		}

		if(x < 60)
		{
			sx = 25;
		}
		else
		{
			sx = -60;
		}

		if(y < 25)
		{
			sy = 25;
		}
		else
		{
			sy = -25;
		}

		DisplayText(mstring, 10, x + sx, y + sy);

	}
}

void SeedRandom(void)
{
   RAND_RandomData = VCOUNT;
}


s32 RAND(s32 Value)
{
   RAND_RandomData *= 20077;
   RAND_RandomData += 12345;

   return ((((RAND_RandomData >> 16) & RAND_MAX) * Value) >> 15);
}

void WaitKey(u16 key)
{
	while(*KEYS & key);
	*KEYS = *KEYS ^ key;
}

void ShowScores(void)
{
	DisplayText(nstring, 12, 90, 16);

	for(i = 0; i < 10; i++)
	{
		DisplayText(hiname[i], 3, 70, 8 * (i + 4));
		DisplayNumber(hiscore[i], 165, 8 * (i + 4));
	}
}


void SaveScores(void)
{
	for(i = 0; i < 10; i++)
	{
		for(j = 0; j < 4; j++)
		{
			SAVERAM[34 + (i * 4) + j] = (hiscore[i] & (0xFF << ((3 - j) << 3))) >> ((3 - j) << 3);
		}

		for(j = 0; j < 3; j++)
		{
			SAVERAM[4 + (i * 3) + j] = hiname[i][j];
		}
	}
}

void SortScores(void)
{
	int stemp;
	char ntemp[3];
	int done = 0;

	while(done ==0)
	{
		done = 1;

		for(i = 0; i < 10; i++)
		{
			if(hiscore[i] < hiscore[i + 1])
			{
				stemp = hiscore[i];
				for(j = 0; j < 3; j++)
				{
					ntemp[j] = hiname[i][j];
				}

				hiscore[i] = hiscore[i+1];

				for(j = 0; j < 3; j++)
				{
					hiname[i][j] = hiname[i + 1][j];
				}

				hiscore[i + 1] = stemp;;

				for(j = 0; j < 3; j++)
				{
					hiname[i + 1][j] = ntemp[j];
				}
				done = 0;
			}
			else
			{
				done = done & 1;
			}
		}
	}
}

void BuildHiscores(void)
{
	for(i = 0; i < 34; i++)
	{
		SAVERAM[i] = savestring[i];
	}

	for(i = 0; i < 10; i++)
	{
		int tscore;
		tscore = ((i + 1) * 100);

		for(j = 0; j < 4; j++)
		{
			SAVERAM[34 + (i * 4) + j] = (tscore & (0x000000FF << ((3 - j) * 8))) >> ((3 - j) * 8);
		}
	}
}

void GetHiscores(void)
{
	for(i = 0; i < 10; i++)
	{
		for(j = 0; j < 3; j++)
		{
			hiname[i][j] = SAVERAM[4 + ((i * 3) + j)];
		}

		hiscore[i] = 0;

		for(j = 0; j < 4; j++)
		{
			hiscore[i] |= SAVERAM[34 + (i * 4) + j] << ((3 - j) * 8);
		}
	}
}


void ClearScreen(void)
{
	REG_BG2X = 0;
	REG_BG2Y = 0;

	for(y = 0; y < 160; y++)
	{
		for(x = 0; x < 240; x++)
		{
			PlotPixel(x, y, 0x0000);
		}
	}
}

void DrawBox(void)
{
	for(y = 0; y < 160; y++)
	{
		PlotPixel(0, y, 0x7FFF);
		PlotPixel(239, y, 0x7FFF);
	}

	for(x = 0; x < 240; x++)
	{
		PlotPixel(x, 0, 0x7FFF);
		PlotPixel(x, 159, 0x7FFF);
	}
}

void PlotPixel(int x, int y, u16 c)
{
	VRAM[x + (y * 240)] = c;
}

void GetName(void)
{
	int dig = 0; //The char we are currently changing

	ClearScreen();
	DisplayText(nameprompt, 16, 80, 8);

	while(*KEYS & KEY_START)
	{
		if(!(*KEYS & KEY_LEFT))
		{
			dig--;
			*KEYS ^= KEY_LEFT;
		}

		if(!(*KEYS & KEY_RIGHT))
		{
			dig++;
			*KEYS ^= KEY_RIGHT;
		}

		if(dig < 0) { dig = 2; }
		if(dig > 2) { dig = 0; }

		if(!(*KEYS & KEY_UP))
		{
			pname[dig]++;
			*KEYS ^= KEY_UP;
		}

		if(!(*KEYS & KEY_DOWN))
		{
			pname[dig]--;
			*KEYS ^= KEY_DOWN;
		}

		if(pname[dig] == 'A' - 1) { pname[dig] = 'z'; }  // Loop the letters round and round! :)  Allows us upper case
		if(pname[dig] == 'a' - 1) { pname[dig] = 'Z'; }  // and lower case without having symbols in the middle
		if(pname[dig] == 'Z' + 1) { pname[dig] = 'a'; }
		if(pname[dig] == 'z' + 1) { pname[dig] = 'A'; }

		for(i = 0; i < 4; i++)
		{
			while(VCOUNT != 160);
			while(VCOUNT == 160);
		}

		for(i = 0; i < 15; i++)
		{
			PlotPixel(i + 102, 90, 0x0000);
		}

		for(i = 0; i < 5; i++)
		{
			PlotPixel(i + (dig * 5) + 102, 90, COLOUR(0,0,31));
		}

		DisplayText(pname, 3, 102, 80);
	}

}

