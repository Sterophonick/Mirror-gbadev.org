char helpstring[425] =
{"Welcome to my Tron demo!\n"
 "\n"
 "The game is essentially the light cycles game\n"
 "from the film Tron. You can change direction\n"
 "with up, down, left and right, but you cannot\n"
 "stop.  Currently, I have only implemented\n"
 "survival mode.  You must navigate your way\n"
 "around the screen, avoiding your own trail and\n"
 "the walls.  The longer you survive, the higher\n"
 "your score (shown next to your `cycle'.)\n"
 "\n"
 "Good luck!\n"
 "\n"
 "Matthew Scales A.K.A. ProbBob"};

