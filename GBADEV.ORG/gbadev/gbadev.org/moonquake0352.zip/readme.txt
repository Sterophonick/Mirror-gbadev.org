Moonquake Advance
=================

Following a devastating moonquake, you have been called in on a well paid contract to clear the 10 levels of the
lunarbase of rubble using your explosives. Your task is made more complicated by the malfunctioning security robots
that are roaming the base and the delicate nuclear reactors that are keeping them running.

A bomberman-like game with a difference  - a conversion from an old Acorn RISC OS game, made with the permission of
the original author.

Credits
=======
Graphics and sound samples extracted from the original software by Paul Taylor.
The sound routines to play samples are taken from Richard Heasman's Defender Advance.

David Sharp
30th March 2004
www.davidsharp.com/gba