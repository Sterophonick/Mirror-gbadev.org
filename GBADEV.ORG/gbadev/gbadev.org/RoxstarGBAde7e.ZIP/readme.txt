Roxstar
Prototype Version/TechDemo 1.0
� 2003 FreeLancer Games
http://www.freelancer-games.com
Contact: info@freelancer-games.com

General Game Info

Genre
Puzzle / JnR

Comparable with
Bombuzal from Image Works 
Boulder Dash from First Star Software 
Chips Challenge from Epyx 
Emerald Mines from Kingsoft 
Sokoban from Thinking Rabbit

Gameplay
The game is a side view Puzzle / JnR game. The game consists of various levels, which have to 
be completed one by one. The objective within a level is to collect a certain amount of objects in 
a timelimit. 
The enemies (5 different types) have special move patterns so the player can work out a way to 
solve the level without luck but tactic. 
Compared to the above stated games the gameplay has many enhancements. There are about 
40 special items to collect or manipulate and a the possibility to rotate the whole level.

Game modes
Tutorial: About 10 levels to explain all features to the player 
Story mode: 50 levels within 5 worlds, connected by video sequences 
1 player mode: All beaten levels from the story mode 
2 player mode: 25 special levels where 2 players have to cooperate

Presentation
The whole look of the game is very colorful and in a cartoon style. 
There are 5 different worlds with individual looks in both environment and enemies (30). There 
are 6 video sequences: The intro (2:30 min), world connection videos (4 x about 0:10 min) and a 
end sequence (0:30 min). 
Maybe the video sequences will be reduced to stills, depending on the memory available (32Mb 
or 64Mb).

Status of Development
PC Prototype engine: 95% 
PC Prototype features: 85% 
PC Editor: 95% 
GBA Version: 80% 
Leveldesign: 10%


How to Play

Startscreen
-	push Start to continue

Optionscreen
-	Steering Cross to move through choice
-	A-Button: Choice selection
-	B-Button: Back to Startscreen
-	Only "1-Player-Mode" and Language "Deutsch" or "English" are active yet

Levelselection
-	Alphaversion Screen
-	Test Level 1 to Test Level 7 are active

How to play
-	Steering cross moves Roxx
-	A-Button and Steering Cross: Pushing and "Sucking" items
-	B-Button and Steering Cross: Use item
-	Shoulder-Buttons scroll through the Inventory (up to 3 items)

Debug-Functions in the game
-	Select and Left Shoulder Button: Cycle through different background picture
-	Select and Right Shoulder Button: Cycle through different graphics sets

Test Level 1
To beat the level you have to rotate it (sphere down left). To get to the door the blocking enemy 
has to be destroyed by the wight. The other enemies should be no problem, you can 
outmanoeuvere them or eleminate them with the bomb, stone or zapper.
Features: Teleporter, zapper, keys and doors, firefly, butterfly, rotation sphere, whight 1

Test Level 2
To beat the level you have to master some tricky passages, avoid the gearwheel and clear the 
exit by rotating the level.
Features: Firefly, butterfly, small gearwheel, large geerwheel, rotation shpere

Test Level 3
To beat the level, first you have to hit the parcel with a rock to get the note. Then use the 
teleporter, collect the keys and rotate the level to move to the exit.
Features: Firefly, butterfly, parcel, rotation shpere, wight 1, keys and doors

Test Level 4 to 7
Testlevel for new features. There are several new items to test?




