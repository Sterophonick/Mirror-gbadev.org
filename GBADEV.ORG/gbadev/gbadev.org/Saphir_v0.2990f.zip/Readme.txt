Saphir v0.2
-----------

Saphir is a conversion of the T08 hit from 1986 by Infogrames
Converted by xFlasH, from the original work by Eric Szymkowiak