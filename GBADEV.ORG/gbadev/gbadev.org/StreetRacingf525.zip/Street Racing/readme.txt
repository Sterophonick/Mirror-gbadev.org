Street Racing by Krzysk  - a GBA game        
-------------------------------------
ver. 13 Oct 2002

This is my first GBA project. I use GCC compiler, smslibrary and BoyScout music library.
Game idea and some gfx are from Game Maker example game (http://www.cs.uu.nl/people/markov/gmaker/). 
Background music is from BoyScout example song. I tested game on VisualBoyAdvance and GBA hardware.

I use as many functions as possible:

- mixing text and graphics background
- background scrolling
- sprite animation
- effects sounds and background music
- saving high score in SRAM

This is not very big project but gameplay is ok. My best score is about 8000 (If you made 10000 points, you get extra car).
Write to my your best scores or any sugestions.

Included source is free.

Contact: krzysk@wp.pl
---------------------