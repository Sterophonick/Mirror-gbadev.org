#include "audio\COLLISION.c"
#include "audio\GAS_SOUND.c"
#include "audio\HORN.c"
#include "audio\SIRENS.c"

#define COLLISION_LEN	25
#define GAS_SOUND_LEN	6
#define HORN_LEN	10
#define SIRENS_LEN	10
