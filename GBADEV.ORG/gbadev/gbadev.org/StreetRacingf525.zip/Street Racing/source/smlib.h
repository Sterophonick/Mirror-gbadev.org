/*****************************\
* 	smlib.h
*	By staringmonkey
*	Last modified on 12/14/01
\*****************************/

#ifndef SMLIB_H
#define SMLIB_H

#include <stdlib.h>
#include <stdio.h> /* [-V989] for sprintf() */
#include <math.h>

//Include all library header files
#include "lib_gba.h"
#include "lib_background.h"
#include "lib_blend.h"
#include "lib_mode3.h"
#include "lib_mode4.h"
#include "lib_keypad.h"
#include "lib_screenmode.h"
#include "lib_sprite.h"
#include "lib_text.h"
#include "lib_windows.h"
#include "lib_time.h"
#include "lib_palette.h"
#include "lib_saving.h"
#include "lib_irq.h"
#include "lib_mosaic.h"
#include "lib_dma.h"
#include "lib_sound.h"

#endif
