////////////////////////////////////////Events///////////////////////

////////////////////////////////////room0///////////////////////////////////
void	room0_step()
{
	//COMMENT: Create Cars
	if( (rand()%50) == 1)			//if a dice with 50 sides does land on one
		car_create('D');			//      create object car_down at position (0,0)
	if( (rand()%100) == 1)			//if a dice with 100 sides does land on one
		car_create('U');			//      create object car_up at position (0,0)
}

void	room0_keyboard()
{
	if(!(*KEYS & KEY_START))		//Keyboard Event for <any key>:
	{
		if(pause_enable)
		{
			clear_screen();
			room = 1;				//go to next room with transition effect 0
			room_created = false;			
			pause_enable = false;
		}
	}
	if(*KEYS & KEY_START)	//Release <Start> Key:
		pause_enable = true;

}

void	room0_game_start()
{
	int	i;
				//play sound background_music looping
	score = 0;		//set the score to 0
	lives = mlives;	//set the number of lives to 3
	clear_objects();
	clear_screen();

	room_created = true;
}

void	room0_draw()
{
			//set a font for drawing text
			//at position (118,40) draw text: Street Racing
	WriteText(9, 30, 5, 11, "Street Racing", 10, 0, 0); 
			//set a font for drawing text
			//at position (150,100) draw text: press any key to start
			//at position (154,130) draw text: press escape to quit
	WriteText(10, 30, 10, 11, "Press Start", 10, 0, 0); 

}

/////////////////////////////////////////room1///////////////////////////////////
void	room1_create()
{
	global_petrol = 1000;	//set variable global.petrol to value 1000
	alarm0 = 300;		//set alarm0 to 300
	clear_objects();
	clear_screen();
	if(lives)
		racing_create();

	room_created = true;
}

void	room1_keyboard()
{
	if(!(*KEYS & KEY_A))					//Keyboard Event for <A>:
	{
		if(soundAPlaying == 0)				//	if sound horn is not playing
			PlayDirectSoundA(HORN_DATA, HORN_SAMPRATE, HORN_LEN); 	//	play sound horn once
	}
	if(!(*KEYS & KEY_START))				//Keyboard Event for <Start>:
	{
		if(pause_enable)
			Pause();
	}
	if(*KEYS & KEY_START)	//Release <Start> Key:
		pause_enable = true;
}


void	room1_alarm0()
{

	gas_create();			//create object gas at position (40+random(320),-40)
	gas.x = 18 + (rand()% 120);
	gas.y = - 16;
	alarm0 = 300 + score/100;	//set alarm0 to 300 + score/100
}


void	room1_step()
{
	alarm0--;
	if(alarm0 <= 0)
		room1_alarm0();

	score++;							//set the score relative to 1
	if(score % bonus == 0)
	{
		lives++;						//increment lives every 10 000
		PlayDirectSoundA(HORN_DATA, HORN_SAMPRATE, HORN_LEN);
	}

	//COMMENT: Create Cars

	if( (rand()%(70 - score/200)) == 1)			//if a dice with 70 - score/200 sides does land on one
		car_create('D');					//      create object car_down at position (0,0)
	if( (rand()%(200 - score/200)) == 1)		//if a dice with 200 - score/200 sides does land on one
		car_create('U');					//      create object car_up at position (0,0)
	if( score > 3000 && police.status == 0 )		//if expression score > 3000 is true
		if( (rand()%(800 - score/30)) == 1)		//      if a dice with 800-score/30 sides does land on one
									//      if number of objects police is equal to 0
			police_create();				//      create object police at position (0,0)
}

void	room1_NoMoreLives()
{
	room = 2;							//show the highscore table
	room_created = false;			
}

void	room1_draw()
{
										//set a font for drawing text
	WriteText(21, 30, 1 , 10, "Score:", 10, 0, 0); 		//at position (420,20) draw text: 'Score: ' + string(score)
	WriteNum(21, 30, 2 , 10, score, 10, 0, 0); 		
	WriteText(21, 30, 3 , 10, "Cars:", 10, 0, 0);		//at position (420,50) draw text: 'Cars left: ' + string(lives)
	WriteNum(21, 30, 4 , 10, lives, 10, 0, 0); 		
	WriteText(21, 30, 5 , 10, "Petrol:", 10, 0, 0);		//at position (420,100) draw text: 'Petrol'
	WriteText(21, 30, 6 , 10, "   %_", 10, 0, 0);	
	WriteNum(21, 30, 6 , 10, global_petrol / 10, 10, 0, 0); 		

	//COMMENT: Draw the petrol left box
	//set the fill color to 0
	//draw rectangle with vertices (480,100) and (480+100,120)
	//set the fill color to 255
//	if(global_petrol > 300)					//if expression global.petrol >300 is true
//		FillBox(168, 40, 158, 166, 40);		//      set the fill color to 65535
//	if(global_petrol > 700)					//if expression global.petrol >700 is true
//		FillBox(168, 40, 158, 166, 50);		//      set the fill color to 65280
	//draw rectangle with vertices (480,100) and (480+max(0,min(100,global.petrol/10)),120)

	WriteText(21, 30, 8 , 12, "Bestscore", 10, 0, 0);	//at position (420,100) draw text: 'Petrol'
	WriteNum(21, 30, 9 , 12, bestscore, 10, 0, 0); 		
}

/////////////////////////////////////////room2///////////////////////////////////
void	room2_create()
{
	//SAVE THE NEW BEST SCORE INTO SRAM
	if(score > bestscore)
	{
		SaveInt(0, score);
		bestscore = score;
	}

	clear_objects();

	room_created = true;
}

void	room2_keyboard()
{
	if(!(*KEYS & KEY_START) || !(*KEYS & KEY_A))		//Keyboard Event for <any key>:
	{
		if(pause_enable)
		{
			clear_screen();
			room = 0;			//go to next room with transition effect 0
			room_created = false;			
			pause_enable = false;
		}
	}
}

void	room2_draw()
{
	WriteText(21, 30, 18 , 19, "Game Over", 10, 0, 0); 
}


/////////////////////////////////////////car///////////////////////////////////
void	car_create(char ch)
{
	int	i;

	for(i = 0; i < mcars; i++)
	{
		if(car[i].status == false)		// znajd� wolny numer
			break;
	}
	if(car[i].status == true)			// wszystkie zaj�te!
		return;
	car[i].status = true;
	car[i].dead = false;				//set variable dead to value false
	car[i].lp1 = 0;

	if(ch == 'D')	//down
	{				
		car[i].image = rand() % 4;		//set variable image_single to value random(image_number)
		car[i].x = 18 + 48;			//move to position (44+120,-80)
		car[i].y = -32;
		car[i].speed = 2;				//set the vertical speed to 6
		car[i].sp1 = 0;
		if(rand() % 2 == 1)			//if a dice with 2 sides does land on one
		{
			car[i].x = 18 + 24;		//      move to position (44+60,-80)
			car[i].speed = 1;			//      set the vertical speed to 5
			car[i].sp1 = 2;
			if(rand() % 3 == 1)		//      if a dice with 3 sides does land on one
			{
				car[i].x = 18;		//            move to position (44,-80)
				car[i].speed = 1;		//            set the vertical speed to 4
				car[i].sp1 = 3;
			}
		}
								//if at relative position (0,0) there is object car_down
								//      destroy yourself
	}
	else
	{
		car[i].image = 4 + (rand() % 4);	//set variable image_single to value random(image_number)
		car[i].x = 18 + 120;			//move to position (44+300,-80)
		car[i].y = -32;
		car[i].speed = 0;				//set the vertical speed to 2
		car[i].sp1 = 2;
		if(rand() % 2 == 1)			//if a dice with 2 sides does land on one
		{
			car[i].x = 18 + 96;		//      move to position (44+240,-80)
			car[i].speed = 0;			//      set the vertical speed to 1
			car[i].sp1 = 3;
				if(rand() % 3 == 1)	//      if a dice with 3 sides does land on one
			{
				car[i].x = 18 + 72;	//           move to position (44+180,-80)
				car[i].speed = 0;		//            set the vertical speed to 0.5
	 			car[i].sp1 = 6;
			}
		}
	}
	if( collision(car[i].x, car[i].y, 1))	//if at relative position (0,0) there is object car_racing
		car[i].status = false;			//      destroy yourself
	if( collision(car[i].x, car[i].y, 3))	//if at relative position (0,0) there is object car_down or car up
		car[i].status = false;			//      destroy yourself
}

void	car_destroy(int i)
{
	car[i].status = false;
	if(car[i].dead == true)			//if expression dead is true
		return;				//      exit this event
	PlayDirectSoundA(COLLISION_DATA, COLLISION_SAMPRATE, COLLISION_LEN); //play sound collision once
	car[i].speed = background_speed;	//set the vertical speed to 3
	car[i].sp1 = 0;
	car[i].dead = true;			//set variable dead to value true
}

void	car_collision(int i)
{

	//Collision Event with car_racing, police:
	if ( collision(car[i].x, car[i].y, 1) || collision(car[i].x, car[i].y, 2) || collision(car[i].x, car[i].y, 3) )
	{
		if(car[i].dead == true)			//if expression dead is true
			return;				//      exit this event
		PlayDirectSoundA(COLLISION_DATA, COLLISION_SAMPRATE, COLLISION_LEN); //play sound collision once
		car[i].speed = background_speed;	//set the vertical speed to 3
		car[i].sp1 = 0;
		car[i].dead = true;			//set variable dead to value true
	}
}

void	car_outside(int i)
{
	if( car[i].y > room_height)		//if expression y > room_height is true
		car[i].status = false;		//     destroy yourself
}

/////////////////////////////////////////police///////////////////////////////////
void	police_create()
{
	police.status = true;

	PlayDirectSoundA(SIRENS_DATA, SIRENS_SAMPRATE, SIRENS_LEN); 		//play sound sirens looping
	sirens_play = true;
	police.dead = false;			//set variable dead to value false
	police.speed = - 1;			//set the vertical speed to -1.5
	police.sp1 = 2;
	police.lp1 = 0;
	police.x = racer.x;			//move to position (car_racing.x,room_height)
	police.y = room_height;

	//COMMENT: Destroy yourself if you hit something
	if( collision(police.x, police.y, 1))		//if at relative position (0,0) there is object car_racing
		police_destroy();					//      destroy yourself
	if( collision(police.x, police.y, 3))		//if at relative position (0,0) there is object car_down or car up
		police_destroy();					//      destroy yourself
}

void	police_destroy()
{
	police.status = false;
	stop_sound_sirens();	//stop sound sirens
}


void	police_step()
{
	police.image++;
	if(police.image == 6)
		police.image = 0;

	if(police.dead == true)				//if expression dead is true
		return;					//      exit this event
	if(racer.x < police.x)				//if expression car_racing.x<x && place_empty(x-8,y) is true
		if( collision(police.x - 1, police.y, 3) == false)	//if at relative position (0,0) there is object car_down or car up
			police.x--;				//      move relative to position (-2,0)
	if(racer.x > police.x)				//if expression car_racing.x>x && place_empty(x+8,y) is true
		if( collision(police.x + 1, police.y, 3) == false)	//if at relative position (0,0) there is object car_down or car up
			police.x++;				//      move relative to position (2,0)
}

void	police_collision()
{
	if(police.dead == true)				//if expression dead is true
		return;					//      exit this event

	//Collision Event with car_down or car_up:
	if ( collision(police.x, police.y, 3) )
	{
		stop_sound_sirens();			//stop sound sirens
		PlayDirectSoundA(COLLISION_DATA, COLLISION_SAMPRATE, COLLISION_LEN); //play sound collision once
		police.speed = background_speed; 	//set the vertical speed to 3
		police.sp1 = 0;
		police.dead = true;			//set variable dead to value true
	}

	//Collision Event with car_racing:
	if ( collision(police.x, police.y, 1) )
	{
		stop_sound_sirens();			//stop sound sirens
		police.speed = background_speed; 	//set the vertical speed to 3
		police.sp1 = 0;
		police.dead = true;			//set variable dead to value true
	}

}

void	police_outside()
{
	if(police.y < -32 || police.y > room_height)		//if expression y<0 || y > room_height+20 is true
		police.status = false;					//      destroy yourself		
}

/////////////////////////////////////////gas///////////////////////////////////
void	gas_create()
{
	gas.status = true;
	gas.speed = background_speed;			//set the vertical speed to background_vspeed[0]
}

void	gas_destroy()
{
	gas.status = false;
}

void	gas_outside()
{
	if( gas.y > room_height)				//if expression y > room_height is true
		gas.status = false;				//      destroy yourself

}

/////////////////////////////////////////racing///////////////////////////////////
void	racing_create()
{
	racer.status = true;

	racer.dead = false;		//set variable dead to value false
	racer.speed = 0;			//set the vertical speed to 0
	racer.x = 78;			// centre of the road
	racer.y = 64;
}

void	racing_destroy()
{
	racer.status = false;
}

void	racing_step()
{
	if(racer.dead == true)				//if expression dead is true
		return;					//      exit this event

	if(global_petrol <= 0)				//if expression global.petrol <= 0 is true
		racer.speed = background_speed;	//      set the vertical speed to 3
	else
		global_petrol--;				//set variable global.petrol relative to value -1
}

void	racing_collisions()
{
	if(racer.dead == true)				//if expression dead is true
		return;					//      exit this event

	//Collision Event with gas:
	if ( collision(racer.x, racer.y, 4))
	{
		PlayDirectSoundA(GAS_SOUND_DATA, GAS_SOUND_SAMPRATE, GAS_SOUND_LEN);	//play sound gas_sound once
		global_petrol += 400;				//set variable global.petrol to value min(1000,global.petrol+400)
		if (global_petrol > 1000)
			global_petrol = 1000;
		gas_destroy();					//for other object: destroy yourself
	}





	//Collision Event with police, car_up or down:
	if ( collision(racer.x, racer.y, 2) || collision(racer.x, racer.y, 3) )
	{
		PlayDirectSoundA(COLLISION_DATA, COLLISION_SAMPRATE, COLLISION_LEN); //play sound collision once
		racer.speed = background_speed;		//set the vertical speed to 3
		racer.dead = true;				//set variable dead to value true
	}
}

void	racing_keyboard()

{
	if(global_petrol > 0 && racer.dead == false)	//if expression global.petrol > 0 && x >32 && not dead is true
	{
		if(!(*KEYS & KEY_LEFT))				//Keyboard Event for <Left>:
			if(racer.x > 14)
				racer.x--;				//      move relative to position (-2,0)
		if(!(*KEYS & KEY_UP))				//Keyboard Event for <Up>:
			racer.y--;					//	  move relative to position (0,-3)
		if(!(*KEYS & KEY_RIGHT))			//Keyboard Event for <Right>:
			if(racer.x < 141)
				racer.x++;				//      move relative to position (2,0)
		if(!(*KEYS & KEY_DOWN))				//Keyboard Event for <Down>:
			racer.y++;	     				//	  move relative to position (0,3)
	}
}


void	racing_outside()
{
	if(racer.y < -32 || racer.y > room_height)	//if expression y<0 || y > room_height+20 is true
	{
		stop_sound_sirens();	//stop sound sirens
		WaitTime(1,0);		//sleep 1000 milliseconds redrawing the screen
		room1_create();		//restart the current room with transition effect 0

		lives--;			//set the number of lives relative to -1
	}
}

/////////////////////////////////////////stop_sound_sirens//////////////////////////////
void	stop_sound_sirens()
{
	sirens_play = false;
	soundALength = 0;
	UpdateDirectSoundA();
}



/////////////////////////////////////////stop_sound_sirens//////////////////////////////
void	clear_objects()
{
	int i;

	racer.status = false;
	police.status = false;
	gas.status = false;
	for(i = 0; i < mcars; i++)
		car[i].status = false;
}


/////////////////////////////////////////clear_screen///////////////////////////////////
void	clear_screen()
{
	int i, j;

	for(i = 0; i < 20; i++)
		WriteText(0, 30,i, i, "                              _",10,0,0);

}


/////////////////////////////////////////collision///////////////////////////////////
int	collision(s16 x1, s16 y1, s8 z1)
{
	int i1;

	switch(z1)
	{
		case 1:			// racer	
		{
			if(racer.status == true)
			{
				if(abs(x1 - racer.x) >= 14)
					return false;
				if(abs(y1 - racer.y) >= 29)
					return false;
				return true;
			}
			else
				return false;
		}
		case 2:			// police
		{
			if(police.status == true)
			{
				if(abs(x1 - police.x) >= 14)
					return false;
				if(abs(y1 - police.y) >= 29)

					return false;
				return true;
			}
			else
				return false;
		}
		case 3:			// cars	
		{
			for(i1 = 0; i1 < mcars; i1++)
			{
				if(car[i1].status == true)
				{
					if(abs(x1 - car[i1].x) >= 14)
						continue;
					if(abs(y1 - car[i1].y) >= 29)
						continue;
					if(x1 == car[i1].x && y1 == car[i1].y)	// this same
						continue;
					return true;
				}
			}
			return false;
		}
		case 4:			// gas
		{
			if(gas.status == true)
			{
				if(abs(x1 - gas.x) >= 15)
					return false;
				if(abs(y1 - gas.y) >= 15 && abs(y1 - gas.y + 16) >= 15 )
					return false;
				return true;
			}
			else
				return false;
		}
	}
}
