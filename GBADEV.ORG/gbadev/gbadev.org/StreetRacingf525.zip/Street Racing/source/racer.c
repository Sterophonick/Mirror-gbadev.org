//////////////////////////////////////////////////////////////////////////
// File: 	racer.cpp                                            		//
// Description: A program that displays multiple sprites			//
// Author:	Krzysztof Kaniewski 	  						//
// Date: 	11.10.2002                                      		//
//////////////////////////////////////////////////////////////////////////

#include <math.h> 		//sign and cos stuff
#include "smlib.h"		//GBA register definitions
#include "all_sprites.h"     	//pion sprite image data
#include "background.h"		//holds the image information in an array
#include "road.h"		//holds map
#include "letters256.h"		//letters
#include "sample.h"		//audio waves
#include "music.h"		//background music
#include "boyscout.h"		//music player (c) boyscout
#include "intro.h"		//game intro 
#include "events.h"

///////////////Function Prototypes////////////////
void Setup();
void UpdateGame();
void Pause();

///////////////Sta�e Gry////////////////
//Game
s8	room = 0;	// 0 - start, 1 - jazda, 2 - game over
s8	room_created = 0; 
s8	sirens_play = 0;
s8	pause_enable, lives;
s16	score, bestscore, global_petrol;

#define false			0
#define true			1
#define mlives			3		// lives limit
#define mcars			10		// cars limit
#define bonus			10000		// extra liva
#define background_speed  	1
#define room_height		160

s16 	bg_scroll = 0;		//start position of background
s16	alarm0 = 0;

//////Objects//////////////
typedef struct tagobject
{
	s8  	status;				// 0 - niewidoczny, 1 - widoczny
	s8	dead;					// czy uszkodzony /nr sprite/
	s16 	x, y, speed;
	s8	sp1, lp1;				// speed modyfication
	s8	image;				// police, cars
}typeobject;
typeobject	racer, police, gas, car[mcars];

#include "events.c"

/////////////////////////////////////////Setup///////////////////////////////////
void Setup(void)
{
	//set mode 1 and enable sprites and 1d mapping
     	SET_MODE(MODE_1 | BG0_ENABLE | BG2_ENABLE | OBJ_ENABLE | OBJ_MAP_1D); 


	//Point to correct tile and map data, update the Background and Display registers accordingly
	REG_BG0CNT = BG_COLOR_256 | TEXTBG_SIZE_256x256 | CHAR_MEM(2) | BG_PRIORITY(0) | SCREEN_MEM(10);
	REG_BG2CNT = BG_COLOR_256 | ROTBG_SIZE_256x256 | CHAR_MEM(0) | SCREEN_MEM(28) | BG_PRIORITY(2) | WRAPAROUND;

	//clear text screen BG(0)
	clear_screen();

	//Load the background graphics and palette
	LoadBackgroundPalette256(backgroundPalette);
	LoadBackgroundTiles(backgroundData, 0, background_WIDTH * background_HEIGHT / 2);

	LoadBackgroundTiles(lettersData, 2, letters_WIDTH * letters_HEIGHT / 2);

	//READ THE VALUES STORED IN SRAM
	//Read best score
	bestscore = LoadInt(0);
	if(bestscore < 0 || bestscore > 1000000)		//saving error
		bestscore = 0;

	//load the map image data
	LoadBackgroundMap(map, 28 , 32, 32);

	//Hide unused sprites
	InitializeSprites();
	LoadSpritePalette256(spritesPalette);
	CopyOAM();

	BitmapMode_LoadSpriteTiles(spritesData, 0, sprites_WIDTH * sprites_HEIGHT /2);

	unsigned int nBSSongSize; 

	// Initialize BoyScout
	BoyScoutInitialize();

	// Get needed song memory
	nBSSongSize = BoyScoutGetNeededSongMemory((unsigned char *)module);

	// Allocate and set BoyScout memory area
	BoyScoutSetMemoryArea((unsigned int)malloc(nBSSongSize));

	// Open song
	BoyScoutOpenSong((unsigned char *)module);

	// Play song and loop
	BoyScoutPlaySong(1);
}

/////////////////////////////////////////UpdateGame///////////////////////////////////
void UpdateGame()
{
	int	i1;

	//Scrool Background
	bg_scroll -= background_speed;
	if(bg_scroll <0)
	{
		bg_scroll += background_HEIGHT;
	}
	
	// Racing car
	if(racer.status == true)
	{
		sprites[0].attribute0 = COLOR_256 | TALL; 
		sprites[0].attribute1 = SIZE_32 | PRIORITY(2);
		if(racer.dead == true)      	
			sprites[0].attribute2 = c_dead_racer;            			
		else
			sprites[0].attribute2 = c_racer;    
        		
		MoveSprite(&sprites[0], racer.x, racer.y);
	}
	else
       	MoveSprite(&sprites[0], 240, 160);


	// Police car
	if(police.status == true)
	{
		sprites[1].attribute0 = COLOR_256 | TALL;
		sprites[1].attribute1 = SIZE_32 | PRIORITY(2);
       	MoveSprite(&sprites[1], police.x, police.y);
		if(police.dead == true)     	
		      sprites[1].attribute2 = c_dead_police;            	
		else
		{
			switch(police.image)
			{
				case 0:	
				{
					sprites[1].attribute2 = c_police1;            		
					break;
				}
				case 1:	
				{
					sprites[1].attribute2 = c_police2;            		
					break;
				}
				case 2:	
				{
					sprites[1].attribute2 = c_police3;            		
					break;
				}
				case 3:	
				{
					sprites[1].attribute2 = c_police4;            		
					break;
				}
				case 4:	
				{
					sprites[1].attribute2 = c_police5;            		
					break;
				}
				case 5:	
				{
					sprites[1].attribute2 = c_police6;            		
					break;
				}
			}
		}
	}
	else
       	MoveSprite(&sprites[1], 240, 160);

	// other cars
	for(i1 = 0; i1 < mcars; i1++)
	{
		if(car[i1].status == true)
		{
			sprites[i1 + 2].attribute0 = COLOR_256 | TALL;
			sprites[i1 + 2].attribute1 = SIZE_32 | PRIORITY(2);
		     	MoveSprite(&sprites[i1 + 2], car[i1].x, car[i1].y);
			if(car[i1].dead == true)
			{
				switch(car[i1].image)
				{
					case 0:	
					{
						sprites[i1 + 2].attribute2 = c_dn_dead_yellow;            		
						break;
					}
					case 1:	
					{
						sprites[i1 + 2].attribute2 = c_dn_dead_green;            		
						break;
					}
					case 2:	
					{
						sprites[i1 + 2].attribute2 = c_dn_dead_red;            		
						break;
					}
					case 3:	
					{
						sprites[i1 + 2].attribute2 = c_dn_dead_black;            		
						break;
					}
					case 4:	
					{
						sprites[i1 + 2].attribute2 = c_up_dead_yellow;            		
						break;
					}
					case 5:	
					{
						sprites[i1 + 2].attribute2 = c_up_dead_green;            		
						break;
					}
					case 6:	
					{
						sprites[i1 + 2].attribute2 = c_up_dead_red;            		
						break;
					}
					case 7:	
					{
						sprites[i1 + 2].attribute2 = c_up_dead_black;            		
						break;
					}
				}
			}
			else
			{
				switch(car[i1].image)
				{
					case 0:	
					{
						sprites[i1 + 2].attribute2 = c_dn_yellow;            		
						break;
					}
					case 1:	
					{
						sprites[i1 + 2].attribute2 = c_dn_green;            		

						break;
					}

					case 2:	
					{
						sprites[i1 + 2].attribute2 = c_dn_red;            		
						break;
					}
					case 3:	
					{
						sprites[i1 + 2].attribute2 = c_dn_black;            		
						break;
					}
					case 4:	
					{
						sprites[i1 + 2].attribute2 = c_up_yellow;            		
						break;
					}
					case 5:	
					{
						sprites[i1 + 2].attribute2 = c_up_green;            		
						break;
					}
					case 6:	
					{
						sprites[i1 + 2].attribute2 = c_up_red;            		
						break;
					}
					case 7:	
					{
						sprites[i1 + 2].attribute2 = c_up_black;            		
						break;
					}
				}
			}
		}
		else
		     	MoveSprite(&sprites[i1 + 2], 240, 160);
	}

	// gas station
	if(gas.status == true)
	{
	      sprites[mcars + 3].attribute0 = COLOR_256 | SQUARE;
		sprites[mcars + 3].attribute1 = SIZE_16 | PRIORITY(3);
		sprites[mcars + 3].attribute2 = c_gaz;    
		MoveSprite(&sprites[mcars + 3], gas.x, gas.y);        	
	}
	else
       	MoveSprite(&sprites[mcars + 3], 240, 160);
}

/////////////////////////////////////////GameOver///////////////////////////////////
void	Pause()
{
	WriteText(21, 30, 18 , 19, "Pause", 10, 0, 0); 
	while(1)
	{
		if(*KEYS & KEY_START)			//Release <Start> Key:
			break;
	}
		while(1)
	{
		WaitTime(0,10);
		if(!(*KEYS & KEY_START))			//Keyboard Event for <Start>:
			break;
	}
	WriteText(21, 30, 18 , 19, "      _", 10, 0, 0); 
	while(1)
	{
		if(*KEYS & KEY_START)			//Release <Start> Key:
			break;
	}
	WriteText(21, 30, 18 , 19, "      _", 10, 0, 0); 
}



/////////////////////////////////////////Main///////////////////////////////////
int main()
{
	Intro();

	//Setup mode and such
	Setup();

	//Main loop
	while(1)
	{
		switch(room)
		{
			case 0:
			{
				if(room_created == false)
					room0_game_start();	// initiation room0
				room0_step();
				room0_keyboard();
				room0_draw();
				break;
			}
			case 1:
			{
				if(room_created == false)
					room1_create();
				room1_step();
				room1_keyboard();
				room1_draw();
				if(lives == 0)
					room1_NoMoreLives();
				break;
			}
			case 2:
			{
				if(room_created == false)
					room2_create();
				room0_step();
				room2_keyboard();
				room2_draw();
				break;
			}
		}

		if(police.status == true)
		{
			if(police.sp1)
			{
				police.lp1++;
				if(police.lp1 == police.sp1)
				{
					police.lp1 = 0;
					police.y += police.speed;
				}
			}
			else
				police.y += police.speed;
			police_step();		
			police_outside();
		}

		if(gas.status == true)
		{
			gas.y += gas.speed;
			gas_outside();
		}

		int i1;
		for(i1 = 0; i1 < mcars; i1++)
		{
			if(car[i1].status == true)
			{
				if(car[i1].sp1)
				{
					car[i1].lp1++;
					if(car[i1].lp1 == car[i1].sp1)
					{
						car[i1].lp1 = 0;
						car[i1].y++;
					}
				}
				car[i1].y += car[i1].speed;
				car_outside(i1);
			}
		}
		if(racer.status == true)
		{
			racer.y += racer.speed;
			racing_step();


			racing_keyboard();
			racing_outside();
			racing_collisions();
		}
		if(police.status == true)
		{
			police_collision();
		}
		for(i1 = 0; i1 < mcars; i1++)
		{
			if(car[i1].status == true)
			{
				car_collision(i1);
			}
		}
	
		UpdateGame();

//		WaitTime(0,5);

		WaitForVSync();			//waits for the screen to stop drawing
		REG_BG2Y = bg_scroll<<8;  	//scroll background
		CopyOAM();				//Copies sprite array into OAM.

		// Update song
		BoyScoutUpdateSong();
		
		UpdateDirectSoundA();

		if(soundAPlaying == 0 && sirens_play == true)
			PlayDirectSoundA(SIRENS_DATA, SIRENS_SAMPRATE, SIRENS_LEN); 		//play sound sirens looping
	}
}
