/*****************************\
* 	intro.h
*	by staringmonkey
*	Last modified on 8/28/01
\*****************************/

#ifndef INTRO_H
#define INTRO_H

//////////////////Necessary Includes/////////////////
#include "smlib.h"
#include "intro_sprite.h"

/////////////////Memory Divisions////////////
u16* CharMem = (u16*)0x6010000;			//Memory for character graphics (OAMData part1)
u16* BackgroundMem = (u16*)0x6004000;	//Memory for background graphics (OAMData part2)

/////////////////////Globals///////////////////////
u16 *lTiles = &intro1Data;
u16 *rTiles = &intro2Data;
u16 *sTiles = &intro3Data;
u16 *artPal = &introPalette;

FIXED angle = 0;
FIXED zoom = 1<<8;

////////////////Function Prototypes/////////////////
void Intro(void);

///////////////////Intro///////////////////////
void Intro(void)
{
	//Looping variables
	int palette_loop,data_loop = 0;

	//Mode 1, Sprites, 1D Mapping
	SET_MODE(MODE_1 | OBJ_ENABLE | OBJ_MAP_1D);

	//Setup Fading (Fade to Black)
	REG_BLDMOD = TARGET1_OBJ | BlendMode(MODE_FADE_IN) | TARGET2_ALL;

	//Store palette from "sprite1.h" into OBJPalette memory
	for(palette_loop = 0; palette_loop < 256; palette_loop++)
		OBJPaletteMem[palette_loop] = artPal[palette_loop];

	//Set all 128 sprites to offscreen
	InitializeSprites();

	//Calculate Sin and Cos tables
	CalcAngles();

	//Create left half of logo
	sprites[0].attribute0 = COLOR_256 | WIDE | 64;		//256 Color, Wide, Y location (64)
	sprites[0].attribute1 = SIZE_64 | 56;				//64x32, X Location (56)
	sprites[0].attribute2 = 0 | PRIORITY(1);			//First tile (0), Priority (1)

	//Create right half of logo
	sprites[1].attribute0 = COLOR_256 | WIDE | 64;		//256 Color, Wide, Y location (64)
	sprites[1].attribute1 = SIZE_64 | 120;				//64x32, X Location (120)
	sprites[1].attribute2 = 64 | PRIORITY(1);			//First tile (64), Priority (1)

	//Loop through and put the bitmaps into OAM character memory
	for(data_loop = 0; data_loop < 16*8*8; data_loop++)
	{
		CharMem[data_loop] = lTiles[data_loop];
		CharMem[16*8*8 + data_loop] = rTiles[data_loop];
		CharMem[32*8*8 + data_loop] = sTiles[data_loop];
	}

	//Copy shadow OAM into true OAM
	CopyOAM();

	//Enable timers
	REG_TM2CNT = BIT01 | BIT07;	//Enable base timer, at 16.78
	REG_TM3CNT = BIT02 | BIT07;	//Enable cascade timer, at 16.78/256

	//Fade in

	for(data_loop = 0; data_loop < 16*8*8; data_loop++)
	while(REG_TM3D < 8)
	{
		Fade(16 - (2 * REG_TM3D));	//Fade based on the second (8 Seconds)
	}

	//Reset for second fade
	REG_TM2CNT = 0;			//Disable timer
	REG_TM3CNT = 0;			//Disable timer
	REG_TM2D = 0;				//Zero out base value
	REG_TM3D = 0;				//Zero out cascade value

	//Create stamp
	sprites[2].attribute0 = COLOR_256 | WIDE | ROTATION_FLAG | SIZE_DOUBLE | 44;	//256 Color, Wide, Y location (160)
	sprites[2].attribute1 = SIZE_64 | ROTDATA(0) | 64;								//64x32, X Location (240)
	sprites[2].attribute2 = 128 | PRIORITY(0);										//First tile (64), Priority (1)

	//Copy shadow OAM into true OAM
	CopyOAM();

	//Zoom the stamp in
	for(zoom = 0; zoom < 38; zoom++)
	{
		RotateSprite(0,335,zoom*6,zoom*6);
		WaitForVSync();
		CopyOAM();
	}
	WaitTime(2,0);
/*
	//Enable timers
	REG_TM2CNT = BIT01 | BIT07;	//Enable base timer, at 16.78
	REG_TM3CNT = BIT02 | BIT07;	//Enable cascade timer, at 16.78/256

	//Fade out
	while(REG_TM3D < 8)
	{
		Fade(REG_TM3D * 2);	//Fade based on the second (8 Seconds)
	}
*/
	//Disable timers
	REG_TM2CNT = 0;				//Disable timer
	REG_TM3CNT = 0;				//Disable timer
	REG_TM2D = 0;				//Zero out base value
	REG_TM3D = 0;				//Zero out cascade value

	//Set all 128 sprites to offscreen
	InitializeSprites();

	//Reset everything
	SET_MODE(0);
	REG_BLDMOD = 0;
}

#endif
