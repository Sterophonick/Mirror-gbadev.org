GBADemo2 by Sean Reid
=====================

Date: March 3, 2002


About the Demo
==============

This is my first real GBA project which is a simple side-scrolling 
platform game.  It is built on top of an engine that I am currently 
producing.  Basically, as I program this game, I am programming 
the engine.


For the Future
==============

I plan to have more levels, obviously.  The coding and refining of 
the engine is what takes the most time.  My tile editor program, 
TileMax, can be used to create levels very easily.  Perhaps I will 
sit down and design a few tile sets and corresponding levels.

I also want to add a "map screen" that is shown before entering 
a new level.  If you remember the map screen in Super Mario 3, then 
you will know what I am talking about.

Audio is also an issue, but it is minor.  I plan to use this game 
for demonstration purposes to employers.  Not only that, but I get 
a lot of experience coding this unique project.  Since I am interested 
in the development of the game structure, the audio is not a huge 
factor for me.


Emulators and GBA Hardware
==========================

I haven't tested this demo on real hardware.  If someone can test it, 
please email me.  I tested this mostly on VisualBoy Advance.  Also, 
it works fairly well on Boycott Advance.  However, as of now, it does 
not run on Boycott Advance Online--the Java port of Boycott Advance. 
Let's hope that the issue is remedied soon.


Contact and Links
=================

For updates on this project, please visit:

    http://www.seanreid.ca/project/GBADemo2/

TileMax is extremely useful for this demo:

    http://www.seanreid.ca/project/TileMax/

If you want to email me, my address is:

    email@seanreid.ca

My resume is located online at:

    http://www.seanreid.ca/resource/sean_reid_resume.html
