Mode4 Blured 3dPlot effect for the GBA. (08/2001)
Just a bit different from previous 3d ploter.

Written in C.
by Bruno Vedder  (bruno.vedder@REMOVE_NO_SPAM_wanadoo.fr No big attachement please!)

It was build with a cross gcc under Linux 2.2.16.
Gfx were made with the gimp :-)  (nice c-source output !)
The intro was tested with VGBA, all seems to work fine
excepted the frame rate maybe (Linux VGBA don t display it !).

    I release the source cause, it might be usefull for someone, like me,
starting with gba coding, but remember it s not an example of good
C writting...
    A lot of things could be better, but speed was not my goal.
If you have any comment or question, feel free to email me.
I d like to know, frame rate, on emulator even a true hardware, if 
it works .

NOTE TO GBA CODERS:
  I often download nice intros from gbadev, but a lot of them are
without their source code  :(

  -If you keep them for yourself because you find them dirty, don't worry
   it's like everywhere :) so send them...
  -If you keep them for yourself because you  you think you are god-like coder
   open your eyes and ask yourself how do you manage to write your GBA code 
   without help or doc from others.


Greets to:
Stephen Stair   (for testing on windows emulator, and his sources,answers etc..)
Joat		(cool docs)
Nokturn		(tutorials)
Dovoto		 (  " " )
Richard "Ries" van der Brugge (compiler advice,sources)
All guys at gbadev.org
The Forgotten   :)
And all sources contributors and consoles coders.
