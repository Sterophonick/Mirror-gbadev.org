/*
	Some parts of this code come from xmatrix for gba from "Adam"
	already taken from the screensaver xmatrix by Jamie Zawinski (true)
	etc ... already taken from .... and from ...
	and finaly from my fisrt cpc 6128 Asm routines  (false these old
	routines will be used in future OS W6000in a few century)
	:-D 
*/

#include "cossin.h"	// Precalculated Cos / Sin tables.
#include "txt.c"	// Picture for GBA text (rotating)

typedef unsigned short int uint16;
typedef unsigned int uint;
typedef unsigned char bool;

#define TRUE (0 == 0)
#define FALSE (0 == 1)
#define VRAM        0x06000000
#define BCK_M5_VRAM 0x0600A000
#define PAL	    0x05000000
#define REG_BG0CNT  0x04000008
#define REG_BG1CNT  0x0400000a
#define REG_BLDCNT  0x04000050
#define REG_BLDY    0x04000054
#define REG_JP      0x04000130
#define REG_DISPCNT *(uint16*)0x04000000
#define SetMode(Mode) REG_DISPCNT=(Mode)
#define MODE_3	    0x03	//   240*160 15bits
#define MODE_4	    0x04	//   240*160 8bits indexed palette
#define MODE_5	    0x05	//   160*128 15bits :-O	
#define BACKBUFFER  0x010	
#define BG2_ENABLE  0x0400
#define RGB(r,g,b) ((r)+((g)<<5)+((b)<<10))

void waitretrace(void);
void WaitVBlank (void);
uint16 jp_getstate(void);
void Copy32 (int *src,int *dst,unsigned int nb);
void Clear32 (int *src,unsigned int nb);
void M4_PutPixel (int x,int y, unsigned char color);
void SwapScreen (void);
int abs (int value);
void SendPal (short *pal);

void RotateXYZ (short *vtx_org,short *vtx_dst,int nb_vtx,int angX,int angY,int angZ);
void DrawStars (short *vtx,int nb_vtx,int x,int y);
void DrawLittleScreen (short *ls);
void Blur (int *src,int *dst);
void Noise (int x,int y,int *dst);


uint16 *ActualVideoBuffer;
unsigned int _rsa = 0x76237;
unsigned int _rsb = 0x1;
unsigned int random(void);

#define NB_PIX	1500
short pix_org [NB_PIX*3];
short pix_rot [NB_PIX*3];

short Pal [256];

int main()
{
int alpha,i,o,nb_pix;
int dx,aX,aY,aZ,daX,daY,daZ,pass;

SetMode (MODE_4 | BG2_ENABLE);
ActualVideoBuffer = (uint16*)0x600A000;// BCK_M5_VRAM;

nb_pix=0;
alpha =0;
dx=0;
pass=0;
for (i=0;i<256;i++)
  Pal [i] = ((i>>3)<<10) | ((i>>3)<<0);
SendPal (Pal);

//
// I do an horrible thing here:
// pix org should be a bit plane (char at least) store in my code
// but i was lazy and i store it in bg as a 16bit picture :-O
// now, i extract data in pix_org from a picture...

for (i=-10;i<10;i++)
  {
  for (o=-30;o<30;o++)  
    {
    if (gba [dx] !=0)
      {
      pix_org [alpha] = o*2;
      pix_org [alpha+1] = i*2;
      pix_org [alpha+2] =0;
      alpha+=3; 	
      nb_pix++;
      }
    dx++;
    }
  }

dx =-160;
daX=4;
daY=4;
daZ=2;
aX=0;
aY=0;
aZ=0;
while (1) 
  {
  RotateXYZ (pix_org,pix_rot,nb_pix,aX,aY,aZ);
  Blur((int *)ActualVideoBuffer,(int*)ActualVideoBuffer); 
  DrawStars (pix_rot,nb_pix,dx>>1,0);
  WaitVBlank();
  SwapScreen ();
  
  aZ +=daZ;
  if (aZ>359) aZ =0;  
  aX +=daX;
  if (aX>359) aX =0;  
  aY +=daY;
  if (aY>359) aY =0;  
  dx++;
  if (dx>320) 
    dx = -200;
  }
return(0);
}

/* returns joypad state */
uint16 jp_getstate(void)
{
  return(~*((uint16 *)REG_JP));
}

void waitretrace(void)
{
  while(!((*((volatile uint16 *)0x04000004) & (1<<0))));
  return;
}

/*   
    With this we can plot in (240*160) resolution.
*/
void M4_PutPixel (int x,int y, unsigned char color)
{
short col;
unsigned int dst;

dst = (y*120)+(x>>1);
col = ActualVideoBuffer [dst];
if (x & 1)	// impair value
  {
  col &=0xff;
  col |= (color<<8);  
  }
else
  {
  col &=0xff00;
  col |= color;
  }
ActualVideoBuffer[dst] = col;
}


void Copy32 (int *src,int *dst,unsigned int nb)
{
unsigned int i=0;

for (i=0;i<nb;i++)
  {
  *dst= *src;
  dst++;
  src++;
  }
}

void Clear32 (int *src,unsigned int nb)
{
unsigned int i=0;

for (i=0;i<nb;i++)
  {
  *src=0;
  src++;
  }
}

int abs (int value)
{
if (value <0) return (value* -1);
else return (value);
}

void SwapScreen ()
{
if (REG_DISPCNT & BACKBUFFER)
  {
  
  REG_DISPCNT &= ~BACKBUFFER;
  ActualVideoBuffer = (uint16*) BCK_M5_VRAM;
  }
else
  {
  
  REG_DISPCNT |= BACKBUFFER;
  ActualVideoBuffer = (uint16*) VRAM;
  }
}

void WaitVBlank (void)
{
while (*(volatile uint16*)0x4000006<160) {};
}

// for code lisibility.
#define Xdst vtx_dst [ind]
#define Ydst vtx_dst [ind+1]
#define Zdst vtx_dst [ind+2]
#define Xsrc vtx_src [ind]
#define Ysrc vtx_src [ind+1]
#define Zsrc vtx_src [ind+2]

void RotateXYZ (short *vtx_src,short *vtx_dst,int nb_vtx,int angX,int angY,int angZ)
{
int i,ind=0;
short x1,y1,z1,x2,y2,z2;

for (i=0;i<nb_vtx;i++)
  {
  x1 = Xsrc;
  y1 = (Ysrc * Cos [angX] - Zsrc * Sin [angX])>>7;
  z1 = (Ysrc * Sin [angX] + Zsrc * Cos [angX])>>7;
  x2 = (x1 * Cos [angY] + z1 * Sin [angY])>>7;
  y2 = y1;
  z2 = ((-1 * x1 * Sin [angY]) + z1 * Cos [angY])>>7;
  Xdst = (x2 * Cos [angZ] - y2 *Sin [angZ])>>7;
  Ydst = (x2 * Sin [angZ] + y2 * Cos [angZ])>>7;
  Zdst = z2;
  ind+=3;
  }
}

void DrawStars (short *vtx,int nb_vtx,int ox,int oy)
{
int i,x,y,z;
for (i=0;i<nb_vtx;i++)
  {
  x = vtx [(i*3)];
  y = vtx[(i*3)+1];
  z = vtx [i*3+2];
  x += (x*z)>>6;
  y += (y*z)>>6;
  x += 120+ox;
  y += 80+oy;
  if ((x>0) && (x<240) && (y>0) && (y<160))
    M4_PutPixel (x,y,0xff);  
  }
}

void SendPal (short *pal)
{
int i;
short  *PalPtr=(short *)PAL;

for (i=0;i<256;i++)
  PalPtr [i] = pal [i];  
}

void Blur (int *src,int *dst)
{
unsigned int ptr;
int i;
unsigned int c1,c2,c3,c4;
ptr =0;
for (i = 0;i<9600;i++)
  {
  c3 = src [ptr];
  c1 = c3 & 0x00ff;
  c2 = (c3 & 0xff00)>>8; 
  c4 = ((c1+c2)*48)>>7;
  c4 |= (c4<<8);
  c1 = (c3 & 0x00ff0000)>>16;
  c2 = (c3 & 0xff000000)>>24;
  c3 = ((c1+c2)*48)>>7;
  c3 |= (c3<<8);
  c4 |= (c3<<16);
  dst [ptr] = c4;
  ptr++;
  }
}


#ifdef __GNUC__
static void __gccmain() { }
#endif
