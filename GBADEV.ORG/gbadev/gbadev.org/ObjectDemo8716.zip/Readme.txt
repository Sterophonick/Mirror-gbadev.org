-
-  Demo:     ObjectDemo.bin
-  Author:   Peebrain
-  Email:    peebrain1@hotmail.com
-  Site:     http://gameboyadv.cjb.net
-

This is my first demo.  I used DevKitAdv with Visual C++ 6.0.
I didn't include the source, and it isn't at my web site, but
I should have it uploaded soon.  Keep checking or e-mail me if
it's really urgent.

Other than that, it's pretty simple.  Follow the on-screen
instructions and just play around with the sprite.  And yes,
that IS a picture of me :-).

Oh, one thing.  Some people thought that DoubleSize is supposed
to double the size of the image.  It's not.  It's a feature of
the GBA so that it will double the size of the clipping region.
If you don't know what that means, don't worry.  Stretch the
image length until part gets cut out.  Then toggle the Double-
Size and the more of the image will be displayed.  Same with
rotating - rotate the image normally and the corners will get
cut off.  Rotate it with DoubleSize and the corners are fine.
Run the demo and see for yourself.

Happy coding!  And keep looking for more demos by me!

- Peebrain (http://gameboyadv.cjb.net)
