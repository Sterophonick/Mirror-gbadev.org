#define INTERUPT_C

#include "gba.h"
#include "dma.h"
#include "ARMCode.h"
#include "interupts.h"

void VBlank(void);
void HBlank(void);
void VCount(void);
void Timer0(void);
void Timer1(void);
void Timer2(void);
void Timer3(void);
void SerialCom(void);
void Dma0(void);
void Dma1(void);
void Dma2(void);
void Dma3(void);
void Keyboard(void);
void Cart(void);


/*-------enable/disable interupt rutien---------------*/
void EnableInterupts(u16 interupts)
{
	REG_IME = 0;  //probably not necessary but not a good idea to change interupt registers when an interupt is ocuring

	if(interupts && INT_VBLANK)
		REG_DISPSTAT |= 0x8;

	if(interupts && INT_HBLANK)
		REG_DISPSTAT |= 0x10;

	REG_IE |= interupts;
	REG_IME = 1;

}

void DisableInterupts(u16 interupts)
{
	REG_IE &= ~interupts;

	if(interupts | INT_VBLANK)
		REG_DISPSTAT &= ~0x8;

	if(interupts | INT_HBLANK)
		REG_DISPSTAT &= ~0x10;

	if(interupts = INT_ALL) //this is were that ALL comes in
		REG_IME = 0;  //disable all interupts;
}

fp IntrTable[]  = 
{
	VBlank,
	HBlank,
	VCount,
	Timer0,
	Timer1,
	Timer2,
	Timer3,
	SerialCom,
	Dma0,
	Dma1,
	Dma2,
	Dma3,
	Keyboard,
	Cart
};


void VBlank(void) {
	REG_IF = INT_VBLANK;
}


void HBlank(void) {
	REG_IF = INT_HBLANK;
}


void VCount(void) {
	REG_IF = INT_VCOUNT;
}


void Timer0(void) {
	REG_IF = INT_TIMER0;
}


void Timer1(void) {
	REG_IF = INT_TIMER1;
}


void Timer2(void) {
	REG_IF = INT_TIMER2;
}


void Timer3(void) {
	REG_IF |= INT_TIMER3;
}


void SerialCom(void) {
	REG_IF = INT_COMMUNICATION;
}


void Dma0(void) {
	REG_IF = INT_DMA0;
}


void Dma1(void) {
	REG_IF = INT_DMA1;
}


void Dma2(void) {
	REG_IF = INT_DMA2;
}


void Dma3(void) {
	REG_IF = INT_DMA3;
}


void Keyboard(void) {
	REG_IF = INT_KEYBOARD;
}


void Cart(void) {
	REG_IF = INT_CART;
}
