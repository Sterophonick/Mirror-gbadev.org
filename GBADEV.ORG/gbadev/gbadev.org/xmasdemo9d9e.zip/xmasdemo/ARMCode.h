void dma32clear(u32 dest, u32 count) CODE_IN_IWRAM;
void dma32xfer(u32 source, u32 dest, u32 count) CODE_IN_IWRAM;
void LZ77UnCompVRAM(u32 source, u32 dest);
void RLUnCompVRAM(u32 source, u32 dest);
void HuffUnComp(u32 source, u32 dest);
void VBlankIntrWait(void);
void IntrWait(u32 flagclear, u32 interupt);
extern u32 clearVal;
