#include "gba.h"

u32 clearVal IN_IWRAM;					// dma32clear uses this, put in fast IWRAM for fast dma's

void dma32clear(u32 dest, u32 count) {
	asm("ldr r1, =0x040000D4\n"			//dma3 base reg
		"ldr r2, =clearVal\n"			//source word for clear
		"mov r3, %0\n"					//dest address
		"mov r5, %1\n"
		"ldr r4, =0x85000000\n"			//dma control, fixed source, 32 bit
		"orr r4, r5\n"
		"stmia r1!, {r2-r4}\n"			//load dma regs, start transfer
		:
		:"r" (dest), "r" (count)		//input args
		:"r1","r2","r3","r4", "r5");	//clobbered registers
}

void dma32xfer(u32 source, u32 dest, u32 count) {
	asm("ldr r1, =0x040000D4\n"			//dma3 base reg
		"mov r2, %0\n"					//source word for clear
		"mov r3, %1\n"					//dest address
		"mov r5, %2\n"
		"ldr r4, =0x84000000\n"			//dma control, 32 bit, source inc, dest inc
		"orr r4, r5\n"
		"stmia r1!, {r2-r4}\n"			//load dma regs, start transfer
		:
		:"r" (source), "r" (dest), "r" (count)		//input args
		:"r1","r2","r3","r4", "r5");	//clobbered registers
}


//uncompress lz77 data to vram
void LZ77UnCompVRAM(u32 source, u32 dest) {
	asm("mov r0, %0\n"
		"mov r1, %1\n"
		"swi 0x12\n"
		:
		:"r" (source), "r" (dest)
		:"r0", "r1" );
}

//uncompress lz77 data to vram
void HuffUnComp(u32 source, u32 dest) {
	asm("mov r0, %0\n"
		"mov r1, %1\n"
		"swi 0x13\n"
		:
		:"r" (source), "r" (dest)
		:"r0", "r1" );
}

//uncompress rle data to vram
void RLUnCompVRAM(u32 source, u32 dest) {
	asm("mov r0, %0\n"
		"mov r1, %1\n"
		"swi 0x15\n"
		:
		:"r" (source), "r" (dest)
		:"r0", "r1" );
}

void VBlankIntrWait(void) {
	asm("swi 0x05");
}


void IntrWait(u32 flagclear, u32 interupt) {
	asm("mov r0, %0\n"
		"mov r1, %1\n"
		"swi 0x04"
		:
		:"r" (flagclear), "r" (interupt)
		:"r0", "r1" );
}
