#include "gba.h"			// gba register defines, typedefs
#include "keypad.h"			// keypad definitions 
#include "screenmode.h"		// screenmode defines
#include "interupts.h"		// interupt handling
#include "timer.h"			// timer defines
#include "dma.h"
#include "ARMCode.h"		// some utility routines
#include "trigLUT.h"		// sin/cos lookup table
#include "krawall.h"
#include "mtypes.h"
#include "modules.h"
#include "samples.h"

typedef void (*cb)(int, int);

// if compiling for multiboot roms, enable it here
#define MULTIBOOT int __gba_multiboot;
MULTIBOOT

// handy macros for color processing
#define getRGB(R,G,B,PAL) (B) = ((PAL) >> 10) & 31; \
	                      (G) = ((PAL) >> 5)  & 31; \
                          (R) = (PAL) & 31;

#define setRGB(R,G,B) (B) << 10 | (G) << 5 | (R)


// useful for checking key presses 
#define keyDown(KEY) (!(KEYS & (KEY)))


// use last 512 bytes of vram as work area for fading palettes
#define fadePal ((u16*)0x600FE00)		


// trig magros
#define SIN(X) trigLUT[(X) & 511]
#define COS(X) trigLUT[((X) & 511) + 128]


// defined in ARMcode.c, used for dma clear routine
extern u32 clearVal;	


// externs from resource.a
extern const u16 icelogo3Data[];
extern const u16 icelogo3Palette[];
extern const u8  rotozoomData[];
extern const u16 rotozoomPalette[];
extern const u8  scrollfontData[];
extern const u16 scrollfontPalette[];
extern const u16 xmasdemoData[];
extern const u16 xmasdemoPalette[];

u32 rot, rot2, rot3, rot4;

typedef struct {
	s16 reg_pa, reg_pb, reg_pc, reg_pd;
} RotBGEntry;

RotBGEntry RotArray[160] IN_IWRAM;

u8 scrolltext[] = 
	 "   SEASONS GREETINGS!    HAPPY HAUNAKAH    MERRY CHRISTMAS"
	 "   FELIZ NAVIDAD AND ALL THAT GOOD STUFF.   LOTS OF GREETS COMING UP     FIRST THE"
	 " #GBADEV CREW:   COSTIS   KUJA   BIGREDPIMP   NEIMOD   ANLI   JOAT   SUBBIE   JAYC   BOOFLY"
	 " (HOW ARE YOU GENTLEMEN!)   ILPARATZO   THE-REV   YANNIS   JSENSEBE   DOVOTO   J-ROD  "
	 " JARVIK7   OUTRIDER    AND MANY OTHERS I KNOW IM FORGETTING BUT THANKS FOR YOUR PATIENCE"
	 " AND TIME SHOWING ME THE WAYS OF GBA DEVVING!       NEXT UP IS THE #ICE CREW: SLOTHY  "
	 " DARKMAGE   GECKZILLA   INNER VISION   GREATER EVIL   SYNTAX ERROR   ROOT88   MYNX   DJ MONKEYBOY  "
	 " THE KNAVE   FARMY   LORDSCARLET   RAINMAKER    CORPCOW   QUANTUM X   PRISM   BV   ETO   EPOCH  "
	 " IRONGHOST   SPRITE   TETANUS   TRIP    TONCHYZ   MONGI   ENZO   AND MANY MORE TALENTED"
	 " AND GIFTED ARTISTS, PROGRAMMERS AND ALL AROUND GOOD GUYS. AND SOME SHOUTS TO #EMUHOLIC WHO"
	 " ALWAYS GAVE ME A PLACE TO HIDE FROM ALL THE NOISE IN #GBADEV =)   PEACE EVERYONE    "
	 " MR MISTER (ICE) 2002                        THE END             ";

u16 fontwidths[59] = 
{ 13, 10, 10, 27, 17, 21, 19, 6, 11, 11, 12, 13, 7, 11, 6, 17, 15, 9, 15, 13, 15, 14, 15, 14, 
  14, 15, 6, 7, 14, 13, 14, 14, 20, 21, 16, 18, 19, 12, 13, 18, 17, 8, 10, 17, 14, 25, 21, 21, 
  14, 21, 15, 17, 17, 18, 19, 25, 19, 18, 17 };

u16 fontpos[59] = 
{ 0, 13, 23, 33, 60, 77, 98, 117, 123, 134, 145, 157, 170, 177, 188, 194, 211, 226, 235, 250,
  263, 278, 292, 307, 321, 335, 350, 356, 363, 377, 390, 404, 418, 438, 459, 475, 493, 512, 524,
  537, 555, 572, 580, 590, 607, 621, 646, 667, 688, 702, 723, 738, 755, 772, 790, 809, 834, 853, 871 };

u8  scroller[3076];
u16 scrolltextpos, scrollcharpixel;
s16 scrollcharwidth;
u16 gamelogicRunning, kramWorkerCallNeeded, songDone;

// do splash screen
void doSplash(void) 
{
	u16 fadeR, fadeG, fadeB;
	u16 palR, palG, palB;
	u16 fadeRinc, fadeGinc, fadeBinc;
	u16 loop, fadeloop;
	
	REG_DISPCNT = MODE_4 | BG2_ENABLE; // switch to mode4

	clearVal = 0;
	
	dma32clear((u32)fadePal, 128);
	dma32clear((u32)BGPaletteMem, 128);

	LZ77UnCompVRAM((u32)icelogo3Data, 0x6000000);

	// fade in the palette for the splash screen
	for (fadeloop = 0; fadeloop < 32; fadeloop++) 
	{
		VBlankIntrWait();

		for (loop = 0; loop < 256; loop++) 
		{
			getRGB(fadeR, fadeG, fadeB, fadePal[loop]);
			getRGB(palR, palG, palB, icelogo3Palette[loop]);
			if (fadeR < palR) fadeR++;
			if (fadeG < palG) fadeG++;
			if (fadeB < palB) fadeB++;
			fadePal[loop] = setRGB(fadeR, fadeG, fadeB);
		}

		dma32xfer((u32)fadePal, (u32)BGPaletteMem, 128);
	}

	for (loop=0; loop<60; loop++) 
	{ 
		VBlankIntrWait();
	}

	// fade out the splash screen
	for (fadeloop = 0; fadeloop < 32; fadeloop++) 
	{
		VBlankIntrWait();
		
		for (loop = 0; loop < 256; loop++) 
		{
			getRGB(fadeR, fadeG, fadeB, fadePal[loop]);
			if (fadeR > 0) fadeR--;
			if (fadeG > 0) fadeG--;
			if (fadeB > 0) fadeB--;
			fadePal[loop] = setRGB(fadeR, fadeG, fadeB);
		}

		dma32xfer((u32)fadePal, (u32)BGPaletteMem, 128);
	}
}



void VBlank_Rotozoom(void)
{
	u16 loop;
	s16 w_deltaX, w_deltaY, h_deltaX, h_deltaY;
	s16 tempS, tempC;
	s32 zoom, centerX, centerY;


	zoom = (SIN((rot2+rot4-rot3) >> 8) + 1024) >> 1;
	centerX = ((120 << 8) * zoom) >> 8;
	centerY = ((80 << 8) * zoom) >> 8;

	tempS = SIN(rot >> 8);
	tempC = COS(rot >> 8);

	REG_BG3X = (s32)((centerY * tempS) - (centerX * tempC)) >> 8;
	REG_BG3Y = (s32)((centerY * tempC) + (centerX * tempS)) >> 8;

	w_deltaX = (tempC * zoom) >> 8;
	w_deltaY = (tempS * zoom) >> 8;
	h_deltaX = (-tempS * zoom) >> 8;
	h_deltaY = (tempC * zoom) >> 8;

	for (loop=0; loop<120; loop++) 
	{
		RotArray[loop].reg_pa = w_deltaX;
		RotArray[loop].reg_pb = w_deltaY;
		RotArray[loop].reg_pc = h_deltaX;
		RotArray[loop].reg_pd = h_deltaY;

		w_deltaX += SIN(loop+(rot3 >> 8)) >> 6;
		h_deltaY += COS(loop-(rot3 >> 8)) >> 6;
		w_deltaY += COS(loop-(rot4 >> 8)) >> 6;
		h_deltaX += SIN(loop+(rot2 >> 8)) >> 6;
	}

	rot += SIN(rot2 >> 8);
	rot2 += 188;
	rot3 += 278;
	rot4 += 412;

	if (!gamelogicRunning) {
		kramWorkerCallNeeded = false;
		kramWorker();
	} else {
		kramWorkerCallNeeded = true;
	}	
}


void VCount_Rotozoom(void) {
	u16 scan = REG_VCOUNT;

	// switch to mode2 morph/rotozoomer effect
	if (scan == 15) {	
		REG_DMA0SAD = (u32)RotArray;
		REG_DMA0DAD = (u32)0x4000030; // BG3PA
		REG_DMA0CNT = DMA16HBLANK | 4;

		REG_DISPCNT = MODE_2 | BG3_ENABLE;
		REG_BG3CNT = 0x378C;	// 128x128, tile wrap, char map 23, 256 color, char set 3

		REG_DISPSTAT &= 0xFF;
		REG_DISPSTAT |= 0x8700;	// set next vcount irq at scan 135
	}

	//switch to mode2 scroller
	if (scan == 135) {	
		REG_DMA0CNT_H = 0;		//disable dma0
		
		REG_DISPCNT = MODE_2 | BG2_ENABLE;
		REG_BG2CNT = 0xf288;	//1024x1024, tile wrap, char map 18, 256 color, char set 2
		REG_BG2PA = 0x440;
		REG_BG2PB = 0;
		REG_BG2PC = 0;
		REG_BG2PD = 0x800;
		REG_BG2Y = 0;

		REG_DISPSTAT &= 0xFF;
		REG_DISPSTAT |= 0xE000;	//set next vcount irq at scan 224
	}

	// switch to mode 4, xmas demo logo
	if (scan == 224) {	
		REG_BG2PA = 256;
		REG_BG2PB = 0;
		REG_BG2PC = 0;
		REG_BG2PD = 256;
		REG_BG2Y = 0;
		REG_DISPCNT = MODE_4 | BG2_ENABLE;
		
		REG_DISPSTAT &= 0xFF;
		REG_DISPSTAT |= 0x0F00;	//set next vcount irq at scan 14
	}
	REG_IF = INT_VCOUNT;
}


void doScroll(void) {
	u16 loop;
	u32 sptr, fptr;
	
	for (loop=0; loop<3072; loop++)
	{
		scroller[loop] = scroller[loop+1];
	}

	for (loop=0, sptr=127, fptr=scrollcharpixel; 
		 loop<24; 
		 loop++, sptr+=128, fptr+=888)
	{
		if (scrollfontData[fptr] != 187) 
		{
			scroller[sptr] = scrollfontData[fptr];
		} else {
			scroller[sptr] = 0;
		}
		
	}

	dma32xfer((u32)scroller, 0x6009000, 768);
		
	scrollcharwidth--;
	scrollcharpixel++;
	if (scrollcharwidth < 0) {
		scrolltextpos++;
		if (scrolltext[scrolltextpos] == 0) {
			scrolltextpos = 0;
		} else {
			scrollcharwidth = fontwidths[scrolltext[scrolltextpos] - ' '] - 1;
			scrollcharpixel = fontpos[scrolltext[scrolltextpos] - ' '];
		}
	}
}


void musicCallback(int event, int param)
{
	if (event == KRAP_CB_DONE)
	{
		songDone = true;
	}
}


int AgbMain(void)
{
	u16 loop, width;
	u8 map[256];
	u32 vptr, fptr, color;
	

	// enable vblank interupts for VBlankIntrWait to work
	EnableInterupts(INT_VBLANK);
	
	doSplash();

	dma32clear((u32)0x6000000, 16384);
	LZ77UnCompVRAM((u32)rotozoomData, 0x600C000);
	LZ77UnCompVRAM((u32)xmasdemoData, 0x6000000);
	REG_DISPCNT = MODE_2 | BG3_ENABLE;
	REG_BG3CNT = 0x378C;	// 128x128, tile repeat, char map 23, 256 color, char set 3
	for (loop=0; loop<256; loop++) {
		map[loop] = loop;
	}
	dma32xfer((u32)map,(u32)0x600B800, 64);

	// set up 64 tiles with the font color indeces, 
	// I use these as "pixels" to draw the font scroller
	vptr = (u32)0x6008000;
	clearVal = 128 | (128 << 8) | (128 << 16) | (128 << 24); 
	for (loop=0; loop<64; loop++) {
		dma32clear(vptr, 16);
		vptr+=64;
		clearVal += 0x01010101;
	}
	clearVal = 0;
	dma32clear(0x6009000, 1536);

	for (loop=0, vptr=(u32)0x6009000, fptr=(u32)scrollfontData; loop<24; loop++, vptr+=128, fptr+=888) {
		dma32xfer(fptr, vptr, 32);
	}
		
	rot = 0; 
	rot2 = 0;
	scrolltextpos = 0;
	scrollcharwidth = fontwidths[scrolltext[scrolltextpos] - ' '];
	scrollcharpixel = fontpos[scrolltext[scrolltextpos] - ' '];
	dma32clear((u32)scroller, 769);

	//remind me to combine the palettes to one 256 color palette
	dma32xfer((u32)rotozoomPalette, (u32)0x5000000, 64);
	dma32xfer((u32)scrollfontPalette, (u32)0x5000100, 32);
	dma32xfer((u32)xmasdemoPalette,(u32)0x5000180, 32);

	
	REG_DISPSTAT |= 0xE020; // turn on vcount irq, trigger on scan 224
	IntrTable[0] = (fp)VBlank_Rotozoom;
	IntrTable[2] = (fp)VCount_Rotozoom;	
	IntrTable[4] = (fp)kradInterrupt;
	EnableInterupts(INT_VCOUNT);

	kragInit( KRAG_INIT_MONO );
	krapCallback((cb)&musicCallback);
	
	krapPlay(&mod_xmas, KRAP_MODE_SONG, 0);
	songDone = false;
	
	// be gentle to the batteries...calling VBlankIntrWait is a nice way of saving batteries in 
	// a while loop
	while (1) 
	{
		gamelogicRunning = true;
		VBlankIntrWait();
		doScroll();
		
		if (songDone) {
			krapPlay(&mod_xmas, KRAP_MODE_SONG, 0);
			songDone = false;
		}

		gamelogicRunning = false;
		if (kramWorkerCallNeeded) {
			kramWorker();
		}
	}
	
	return 0;
}

