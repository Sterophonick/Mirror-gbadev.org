Xmas Demo
Written by Mr Mister
pureedlizard@homtail.com
MrMr[iCE] on EFNet #gbadev, #emuholic, #ice

Released to the public as open source


Well, here's a quick 2 day project I threw together for the holiday season.
source included, some assembly required =)

To build you need the following:
	DevKit Advance		http://www.io.com/~fenix/devkitadv/download.html
	GBA ROM Manipulator	http://gbadev.org, in tools section, under header utilities
	Krawall			http://mind.riot.org/krawall/, grab the free sdk
	GBACrusher		EFNet #gbadev, look for Jsensebe, the author of this fine compression tool
	gfx2gba	v0.13		http://gbadev.org, in tools section, under gfx utilities		
	bin2o v1.1		http://gbadev.org, in tools section, under misc utilities

To build resources, run resource.bat, which will produce resource.a

run krawalls converter util: converter xmas.s3m. this will produce moduldes.h, xmas.s, samples.h, samples.s

Then run the makefile, and you should have a shiny new rom. Its multiboot and cart friendly.
		
This demo uses some pretty cool techniques. The screen is split into 3 different modes:
	Top (xmas demo logo) is mode 4, 256 color bitmap
	Middle (merry xmas rotozoomer) is mode 2, rotation background layer 2
	Bottom (font scroller) is mode 2, rotation background layer 3

Look at VCount_rotozoom(), that handles the mode splits
The morphing rotozoom effect is done with hardware, similar to how "mode 7" games like Fzero do scaling/rotation
to do the perspective plane. I change the affine angles/scaling per scan, getting the twisted effect you see.
The scroller is a zoomed out rotation background where each "pixel" in the font is actually a tile in the map

Credits to 
	Shadow of Illusion for his awesome track - xmas.s3m 
	Krawall for their kick ass music library
	Jsensebe for his awesome compression tool, GBA Crusher
	Anli for his linker-friendly version of bin2o
	all the people in #gbadev, for which I owe many thanks for helping me with gba devving

	
		