#ifndef __MODULES_H__
#define __MODULES_H__

#include "mtypes.h"

extern const Module mod_xmas;

#endif
