/* (c) Peter Horsman, 2002
 * Pete (dooby@bits.bris.ac.uk / http://bits.bris.ac.uk/dooby/)
 *
 * Little demo to test new things I've implemented. Namely, mode 4 bitmap and
 * sprite mixing, and direct sounds A and B. This has resulted in an embryonic
 * memory manager (well only loader so far really) for OAM, VRAM and palettes.
 * Also, new gbalib functions for initialising, playing and looping sounds.
 */

#include <stdlib.h>

#include "gba.h"
#include "sound.h"
#include "regs.h"
#include "3d.h"
#include "oam.h"

#include "symbols.h"        // Grab imported symbol list.

MULTIBOOT

//void gba_triangleTest(s32 x1, s32 y1, s32 x2, s32 y2, s32 x3, s32 y3) CODE_IN_IWRAM;



void bounce_dooby(Sprite *dooby) {
  int i;
  s16 cy, ia;
  static s16 dooby_angle = 0;

  // Bounce dooby sprites.
  for(i = 0; i < 5; i ++) {
    ia = dooby_angle - i * 20;
    while(ia > 360) ia -= 360;
    while(ia < 0) ia += 360;
    if(ia > 180) {
      cy = 104;
    } else {
      cy = 104 + 16 - (abs(gba_cosq(ia)) >> 3);
    }
    set_obj_y(dooby[i], cy);
  }
  if(dooby_angle > 180) dooby_angle += 2;
  else dooby_angle += 5;
  if(dooby_angle >= 360) dooby_angle -= 360;
}
  
void init_acid(Sprite *acid) {
  s16 x, y;
  u32 time = 0;
  // Initialise acid smiley position.
  x = 0;
  y = 160 - 32 - (abs(gba_cos(time)) >> 0);
  // Try and bring acid sprite up...
  acid->oam = allocate_oam();
  acid->oam[0] = OBJ_SQR | OBJ_16 | OBJ_ROTSCL | (y & 0xff);
  acid->oam[1] = OBJ_SZ3 | OBJ_ROT00 | (x & 0x1ff);
  acid->oam[2] = acid->pal << 12 | OBJ_PRI1 | acid->name;
}



void bounce_acid(Sprite *acid) {
  static u32 time = 0;
  static s16 x = 0;
  static s16 y = 160 - 32 - 128;
  static s16 old_y = 160 - 32 - 128;
  static s16 older_y = 160 - 32 - 128;
  static s16 angle = 0;
  static s8 x_dir = 2;
  static s8 ang_dir = -1;

  // Bounce acid sprite.
  x = x + x_dir;
  if((x + x_dir) > (240 - 32) || (x + x_dir) < 0) {
    x_dir = -x_dir;
    play_sound((u8 *)_binary_sound_boing_raw_start,
               (u8 *)_binary_sound_boing_raw_end);
  }

  older_y = old_y;
  old_y = y;
  y = 160 - 32 - (abs(gba_cos(time)) >> 0);

  // Detect floor bounce and do summat perty.
  if((older_y < old_y) && (y < old_y)) {
    //ang_dir = -ang_dir;
    ang_dir += -x_dir;
      play_sound((u8 *)_binary_sound_boing_raw_start,
                 (u8 *)_binary_sound_boing_raw_end);
  
    // Flip layer priority.
    acid->oam[2] = acid->oam[2] ^ 0x0400;
  }
  
  time += 2;
    
  set_obj_x(*acid, x);
  set_obj_y(*acid, y);
  
  angle += ang_dir;
  if(angle >= 360) angle -= 360;
  if(angle < 0) angle += 360;

  // Set rotation parameter 0 to 0 degrees, 1x scale in x & y.
  PA00 = gba_cosq(angle) << 1;
  PB00 = -gba_sinq(angle) << 1;
  PC00 = gba_sinq(angle) << 1;
  PD00 = gba_cosq(angle) << 1;
}


 
// Set a palette based on BBC B colours :)
// Though I often seem to misremember green and yellow order...
void set_beeb_palette(void) {
  gba_setpalette(0, 0, 0, 0);	// Black
  gba_setpalette(1, 31, 0, 0);	// Red
  gba_setpalette(2, 0, 31, 0);	// Green
  gba_setpalette(3, 31, 31, 0);	// Yellow
  gba_setpalette(4, 0, 0, 31);	// Blue
  gba_setpalette(5, 31, 0, 31);	// Magenta
  gba_setpalette(6, 0, 31, 31);	// Cyan
  gba_setpalette(7, 31, 31, 31);// White
}



// Render the 3D polygon objects.
void render_3D(Object *world) {
  Object *curr_obj;
  Face *curr, temp;
  s32 sin[3], cos[3];
  s32 nx, nz, fudge;	// Surface normal x and z components and a fudge var.

  // 3D rendering stuff.
  curr_obj = world;
  while(curr_obj != NULL) {

  // Get the rotation angle sin and cos values.
  sin[0] = gba_sinq(curr_obj->angX); cos[0] = gba_cosq(curr_obj->angX);
  sin[1] = gba_sinq(curr_obj->angY); cos[1] = gba_cosq(curr_obj->angY);
  sin[2] = gba_sinq(curr_obj->angZ); cos[2] = gba_cosq(curr_obj->angZ);

  curr = curr_obj->face;

  while(curr != 0) {

    // Rotate face into temp.
    copy(&temp, curr);
    rotX(&temp, sin[0], cos[0]);
    rotY(&temp, sin[1], cos[1]);
    rotZ(&temp, sin[2], cos[2]);
    trs(&temp, curr_obj->offX, curr_obj->offY, curr_obj->offZ);
    psp(&temp);

    // Calculate face visibility by calculating surface normal z component.
    nz  = (temp.v[1].x - temp.v[0].x) * (temp.v[2].y - temp.v[1].y);
    nz -= (temp.v[1].y - temp.v[0].y) * (temp.v[2].x - temp.v[1].x);

    if(nz < 0) {
      // Cheat light shade - just calculate surface normal x component.
      nx  = (temp.v[1].y - temp.v[0].y) * (temp.v[2].z - temp.v[1].z);
      nx -= (temp.v[1].z - temp.v[0].z) * (temp.v[2].y - temp.v[1].y);

      if(nz == 0) {
        fudge = 31;
      } else {
        fudge = gba_div(nx << 8, nz);
      }
      if(fudge < 0) fudge = -fudge;
      fudge = fudge >> 4;
      if(fudge > 31) fudge = 31;

      // Draw temporary face.
      gba_setcolour(temp.col * 32 + 31 - fudge); 
      gba_triangle(temp.v[0].x+XOFF, temp.v[0].y+YOFF,
                   temp.v[1].x+XOFF, temp.v[1].y+YOFF,
                   temp.v[2].x+XOFF, temp.v[2].y+YOFF);
      if((temp.v[2].x != temp.v[3].x) || (temp.v[2].y != temp.v[3].y)) {
      gba_triangle(temp.v[0].x+XOFF, temp.v[0].y+YOFF,
                   temp.v[2].x+XOFF, temp.v[2].y+YOFF,
                   temp.v[3].x+XOFF, temp.v[3].y+YOFF); }

    }

    // Get next face.
    curr = curr->n;
  }

  // Increment angles.
  curr_obj->angX = (curr_obj->angX + curr_obj->incX) % 360;
  curr_obj->angY = (curr_obj->angY + curr_obj->incY) % 360;
  curr_obj->angZ = (curr_obj->angZ + curr_obj->incZ) % 360;

  curr_obj = curr_obj->n;
  }
}



void init_mamba(Object *o, Face f[]) {
  // Bottom face.
  f[0].v[0].x = -17; f[0].v[0].y =   0; f[0].v[0].z =  19;
  f[0].v[1].x =  17; f[0].v[1].y =   0; f[0].v[1].z =   0;
  f[0].v[2].x = -17; f[0].v[2].y =   0; f[0].v[2].z = -19;
  f[0].v[3].x = -17; f[0].v[3].y =   0; f[0].v[3].z = -19;
  f[0].col = 1;

  // Left wing.
  f[1].v[0].x = -17; f[1].v[0].y =   5; f[1].v[0].z =  10;
  f[1].v[1].x =  17; f[1].v[1].y =   0; f[1].v[1].z =   0;
  f[1].v[2].x = -17; f[1].v[2].y =   0; f[1].v[2].z =  19;
  f[1].v[3].x = -17; f[1].v[3].y =   0; f[1].v[3].z =  19;
  f[1].col = 2;

  // Right wing.
  f[2].v[0].x = -17; f[2].v[0].y =   0; f[2].v[0].z = -19;
  f[2].v[1].x =  17; f[2].v[1].y =   0; f[2].v[1].z =   0;
  f[2].v[2].x = -17; f[2].v[2].y =   5; f[2].v[2].z = -10;
  f[2].v[3].x = -17; f[2].v[3].y =   5; f[2].v[3].z = -10;
  f[2].col = 3;

  // Roof.
  f[3].v[0].x = -17; f[3].v[0].y =   5; f[3].v[0].z = -10;
  f[3].v[1].x =  17; f[3].v[1].y =   0; f[3].v[1].z =   0;
  f[3].v[2].x = -17; f[3].v[2].y =   5; f[3].v[2].z =  10;
  f[3].v[3].x = -17; f[3].v[3].y =   5; f[3].v[3].z =  10;
  f[3].col = 4;

  // Back.
  f[4].v[0].x = -17; f[4].v[0].y =   0; f[4].v[0].z =  19;
  f[4].v[1].x = -17; f[4].v[1].y =   0; f[4].v[1].z = -19;
  f[4].v[2].x = -17; f[4].v[2].y =   5; f[4].v[2].z = -10;
  f[4].v[3].x = -17; f[4].v[3].y =   5; f[4].v[3].z =  10;
  f[4].col = 5;

  // Initialise object face list.
  o->face = &f[0];
  f[0].n = &f[1];
  f[1].n = &f[2];
  f[2].n = &f[3];
  f[3].n = &f[4];
  f[4].n = 0;

  // Initialise object offset & rotation attributes.
  o->angX =    0;
  o->angY =    0;
  o->angZ =    0;
  o->incX =    3;
  o->incY =    2;
  o->incZ =    1;
  o->offX =    0; // -60
  o->offY =    0; // -40
  o->offZ =    0;
}

int AgbMain(void) {
  int i;
  // Allocate sprite objects.
  Sprite acid;
  Sprite dooby[5];

  u16 keys_now, keys_old = 0x3ff;

  //u16 vcount;
  u16 mosaic = 0;

  // 3D variables we need to declare.
  Object *world, mamba;
  Face mamba_faces[5];

  // 3D stuff we need to initialise.
  init_mamba(&mamba, mamba_faces);
  world = &mamba;
  world->n = NULL;
  
  // Set GBA mode 4 with sprites enabled.
  DISPCNT = 0x1444;	// NB don't enable window flag unless it's set up :)

  gba_initbank();	// Initialise double buffering.

  gba_setpalette(255, 31, 31, 31);	// White is always nice to have.

  // Initialise interrupts to allow DMA1 to count sample length.
  KEYCNT = KEY_AND | KEY_IRQ | PAD_A | PAD_B | PAD_START | PAD_SELECT;
  IE |= INT_DMA1;
  IE |= INT_DMA2;
  IE |= INT_KEY;
  IME = 1;

  // Initialise master sound and set timer 1 going at 11025Hz.
  init_sound();

  // Test palette loading function.
  acid.pal = load_palette((u16 *)_binary_acid_acid_xpm_pal_raw_start,
                          (u16 *)_binary_acid_acid_xpm_pal_raw_end);
  dooby[0].pal = load_palette((u16 *)_binary_dooby_d_xpm_pal_raw_start,
                              (u16 *)_binary_dooby_d_xpm_pal_raw_end);
  dooby[1].pal = load_palette((u16 *)_binary_dooby_o1_xpm_pal_raw_start,
                              (u16 *)_binary_dooby_o1_xpm_pal_raw_end);
  dooby[2].pal = load_palette((u16 *)_binary_dooby_o2_xpm_pal_raw_start,
                              (u16 *)_binary_dooby_o2_xpm_pal_raw_end);
  dooby[3].pal = load_palette((u16 *)_binary_dooby_b_xpm_pal_raw_start,
                              (u16 *)_binary_dooby_b_xpm_pal_raw_end);
  dooby[4].pal = load_palette((u16 *)_binary_dooby_y_xpm_pal_raw_start,
                              (u16 *)_binary_dooby_y_xpm_pal_raw_end);

  // Test sprite loading function.
  acid.name = load_sprite((u16 *)_binary_acid_acid_xpm_spr_raw_start,
                          (u16 *)_binary_acid_acid_xpm_spr_raw_end);
  dooby[0].name = load_sprite((u16 *)_binary_dooby_d_xpm_spr_raw_start,
                              (u16 *)_binary_dooby_d_xpm_spr_raw_end);
  dooby[1].name = load_sprite((u16 *)_binary_dooby_o1_xpm_spr_raw_start,
                              (u16 *)_binary_dooby_o1_xpm_spr_raw_end);
  dooby[2].name = load_sprite((u16 *)_binary_dooby_o2_xpm_spr_raw_start,
                              (u16 *)_binary_dooby_o2_xpm_spr_raw_end);
  dooby[3].name = load_sprite((u16 *)_binary_dooby_b_xpm_spr_raw_start,
                              (u16 *)_binary_dooby_b_xpm_spr_raw_end);
  dooby[4].name = load_sprite((u16 *)_binary_dooby_y_xpm_spr_raw_start,
                              (u16 *)_binary_dooby_y_xpm_spr_raw_end);

  // Set mosaic for bg to 0x1 (HxW).
  mosaic = 0x0001;
  MOSAIC = mosaic;

  init_acid(&acid);		// Initialise acid smiley position.

  // Bring 'dooby' sprites up.
  for(i = 0; i < 5; i ++) {
    dooby[i].oam = allocate_oam();
    dooby[i].oam[0] = OBJ_VER | OBJ_16 | 104;
    dooby[i].oam[1] = OBJ_SZ3 | (80 + i * 16);
    dooby[i].oam[2] = dooby[i].pal << 12 | OBJ_PRI1 | dooby[i].name;
  }

  set_beeb_palette();	// Add some oldskool colours to the palette.

  // Set lighter face palettes for ligth shaded polys.
  for(i = 0; i < 32; i ++) gba_setpalette( 32+i,(i>>1)+16,0,0);
  for(i = 0; i < 32; i ++) gba_setpalette( 64+i,0,(i>>1)+16,0);
  for(i = 0; i < 32; i ++) gba_setpalette( 96+i,(i>>1)+16,(i>>1)+16,0);
  for(i = 0; i < 32; i ++) gba_setpalette(128+i,0,0,(i>>1)+16);
  for(i = 0; i < 32; i ++) gba_setpalette(160+i,(i>>1)+16,0,(i>>1)+16);
  for(i = 0; i < 32; i ++) gba_setpalette(192+i,0,(i>>1)+16,(i>>1)+16);
  for(i = 0; i < 32; i ++) gba_setpalette(224+i,(i>>1)+16,(i>>1)+16,(i>>1)+16);

  // Set OBJ rotation parameter 0 to 0 degrees, 1x scale in x & y.
  PA00 = 0x0100;
  PB00 = 0x0000;
  PC00 = 0x0000;
  PD00 = 0x0100;

  // Start music.
  loop_sound((u8 *)_binary_sound_loop_raw_start,
             (u8 *)_binary_sound_loop_raw_end);

  // Main loop.
  while(0==0) {
    gba_clsUnroll2();

    render_3D(world);		// Render all poly and/or bezier content.
  
    bounce_dooby(dooby);	// Bounce dooby sprites about.

    bounce_acid(&acid);		// Bounce acid smiley about.

    keys_now = KEYINPUT;

    if(!(keys_now & PAD_LEFT)) {
    }

    if(!(keys_now & PAD_RIGHT)) {
    }

    if(!(keys_now & PAD_UP)) {
    }

    if(!(keys_now & PAD_DOWN)) {
    }

    /*if(!(keys_now & PAD_A) && (keys_old & PAD_A)) {
    }*/
    if(!(keys_now & PAD_A)) {
      while(!(KEYINPUT & PAD_A));
    }

    if(!(keys_now & PAD_B) && (keys_old & PAD_B)) {
    }

    if(!(keys_now & PAD_L)) { // && (keys_old & PAD_L)) {
    }

    if(!(keys_now & PAD_R)) { // && (keys_old & PAD_R)) {
    }

    if(!(keys_now & PAD_START) && (keys_old & PAD_START)) {
      // Flip background mosaic enable.
      BG2CNT = BG2CNT ^ 0x40;
    }
    
    if(!(keys_now & PAD_SELECT) && (keys_old & PAD_SELECT)) {
    }

    keys_old = keys_now;

    // Raster line CPU usage.
    /* vcount = *(u16 *)0x04000006;
    if(vcount < 160) {
      gba_setcolour(2);
      gba_drawline(0, 159-vcount, 239, 159-vcount);
    } else {
      gba_setcolour(1);
      gba_drawline(0, 159-(vcount - 160), 239, 159-(vcount - 160));
    } */

    // Ready for next frame.
    gba_vsync();
    gba_swapbank();
  }

  return(0);
}
