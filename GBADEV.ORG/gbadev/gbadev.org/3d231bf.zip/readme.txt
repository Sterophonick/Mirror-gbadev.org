Hi GBAdev Developers!
Well, I decided to contribute a litle to the community and release this 3D demo.
This demo was done as part of my 3D programming learning for the past year,
and for some reason I fell in love with GBA development, so I decided to do it
as GBA project.
This engine could be 3 times faster, not due to faster algorithms,
but due to better compiler and configurations. This is a debug Version, which is not
very suited to compiler Optimizations.

Anyway, the file contains a simple 3D demo (not the best of my work), but well enough for demonstration purposes. In addition to that, there are about 10 screenshots of rendering
in my engine.

I decided to make a new engine for Windows CE, and the Architecture will be the same as Tomb-Raider 2, and it will be great fun, and alot of work.

This engine will be called : The Quake GBA homage, as it was based upon other people knowledge, so this is my contribution.
The level featuring in the demo was made using a Quake editor.
this engine can run all Quake 1 levels

I'll probabely release it open-source, but that depends on demand.

Would like to thank you all for knowledge pouring in thr forums, and to Yeti3D, which was
a real motivation for me to code 3D software.

You can use all of the GBA keys for the camera.

these are the following features of my engine:

- 3D Clipping (camera - space)
- 2D clipping (screen space)
- 6 DOF (tilt, yaw, pitch)
- Affine mapping, DDA
- Multi-Texturing
- texture animation
- sub Pixel/Texel accuarcy
- Key frame Animation (.MD2 Models)
- Painter's algorithm
- Z -buffering
- BSP + PVS , as part of support to QUAKE1 .bsp files
- Dynamic lighting / Shading (Ambient + Diffuse) -  Lambert + Linear Falloff
- Lens flare
- Particle systems : Explosions
- Back Face culling (World space + Camera Space)
- 1st Person Camera
- 3rd Person Camera (Polar System)
- Wire Frame Rendering
- Solid Color rendering (Flat)
- Support for Mode 3/4/5
- Fixed point math
- Currently the engine pulls up to 13,000 texture-mapped poly per second, and a FillRate      
  of 1MB/sec


Cheer, Tomer!
tomer.shalev@gmail.com
tomer_sh@msn.com