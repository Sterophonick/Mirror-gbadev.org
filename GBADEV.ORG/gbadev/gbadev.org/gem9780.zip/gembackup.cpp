////////////////////////////////////////////////////////////////////////////
//File:		gem.cpp
//Date:		01 - 03 - 2002
//Program:	Collect all fours gems
//Author:		Jenswa
//Thanks to:	gbajunkie, nokturn, dovoto,
////////////////////////////////////////////////////////////////////////////

//general declarations
#include "gba.h"		//GBA register definitions
#include "dispcnt.h"		//REG_DISPCNT register defines
#include "keypad.h"	//keypad defines
#include "background.h"	//background defines
#include "sprites.h"		//sprite defines
#include "fade.h"		//fade functions

//dma stuff
#include "dma.h"		//dma defines
#include "dma.c"		//dma copy function

//gfx
#include "title.h"		//8-bit title screen
#include "title2.h"		//8-bit 2nd screen
#include "numbers.h"	//numbers 0 - 9
#include "tiles.h"		//tiles gfx and palette
#include "objpalette.h"	//normal mspaint 256 colour palette
#include "ghost.h"		//the blue ghost sprite
#include "ghostmap.c"	//collisionmap for the ghost sprite
#include "cristal.h"		//cristal sprite
#include "cristalmap.c"	//collisionmap for the cristal sprite
#include "key.h"		//key sprite
#include "gate.h"		//gate sprite
#include "border.c"		//tilemap for the border
#include "water1.c"		//tilemap for level 1
#include "water2.c"		//tilemap for level 2
#include "water3.c"		//tilemap for level 3
#include "water4.c"		//tilemap for level 4
#include "water5.c"		//tilemap for level 5
#include "water6.c"		//tilemap for level 6


//create a background
BG bg3;
BG bg2;

//create an OAM variable and make it point to the address of OAM
u16* OAM = (u16*)0x7000000;

//create the array of sprites
OAMEntry sprites[128];

int xpos ;
int ypos;
int counterx;
int countery;
int lastx[5];
int lasty[5];

//x and y of cristals
int cristalx[4];
int cristaly[4];
int cristals;

//were not walking while we start playing the 'game'
int walk = 0;
//starting score
int score = 0;
//starting level
int level = 0;
//maximum number of levels (six in this case)
int max = 6;

//x and y of the key
int key = 0;
int keyx;
int keyy;
int mirrorkeyx;
int mirrorkeyy;

//x and y of the gate
int gatex;
int gatey;
int playing = 0;

//for map collisions
u8* BorderMap;
u8 WaterMap[32*32];

//clear VideoBuffer with some unused VRAM
void ClearBuffer()
{
	REG_DM3SAD = 0x06010000;				//Source Address - Some unused VRAM
	REG_DM3DAD = 0x06000000;				//Destination Address - Front buffer
	REG_DM3CNT = DMA_ENABLE | DMA_SOURCE_FIXED | 96*160;
}

//wait for the screen to stop drawing
void WaitForVsync()
{
	while((volatile u16)REG_VCOUNT != 160){}
}

void CopyOAM()
{
	u16 loop;
	u16* temp;
	temp = (u16*)sprites;
	for(loop=0; loop < 128*4; loop++)
	{
		OAM[loop] = temp[loop];
	}
}

// Set sprites off screen
void InitializeSprites()
{
	int x;
	for (x = 0; x < 128; x++)
	{
		sprites[x].attribute0 = 160;	//y > 159
		sprites[x].attribute1 = 240;	//x > 239
	}
}

//move the sprite
void MoveSprite(OAMEntry* sp, int x, int y)
{
	if(x < 0)			//if it is off the left correct
		x = 512 + x;
	if(y < 0)			//if off the top correct
		y = 256 + y;

	sp->attribute1 = sp->attribute1 & 0xFE00;  //clear the old x value
	sp->attribute1 = sp->attribute1 | x;

	sp->attribute0 = sp->attribute0 & 0xFF00;  //clear the old y value
	sp->attribute0 = sp->attribute0 | y;
}

//sprite strucure, for animation of the sprite
typedef struct
{
	u16 xpos;		//x position
	u16 ypos;		//y position
	u16 spriteFrame[9];	//total frames
	int activeFrame;	//which frame is active
}Sprite;

//Declare some sprites
Sprite counter1;		//create an instance
Sprite counter2;		//create an instance
Sprite counter3;		//create an instance

//set counters
void SetCounters(int score)
{
	int hundreds = (score/100)%10;
	int tens =(score/10)%10;
	int units =(score/1)%10;

	sprites[1].attribute2 = counter1.spriteFrame[hundreds];
	sprites[2].attribute2 = counter2.spriteFrame[tens];
	sprites[3].attribute2 = counter3.spriteFrame[units];
}

//loads the tiles for the background maps
void LoadTiles()
{
	int x;
	for(x = 0; x < tiles_WIDTH*tiles_HEIGHT/2; x++)
	{
		BGTileMem[x] = tilesData[x];
	}
}

//loads a map (only for screenmem 0 and 1, number = 0 or 1)
void LoadMap(int number, u8* map)
{
	int x;
	switch(number)
	{
		case 0:
			for(x=0; x < 32*32; x++){
				ScreenMem0[x] = map[x];
			}
			break;
		case 1:
			for(x=0; x < 32*32; x++){
				ScreenMem1[x] = map[x];
			}
			break;
		default:
			break;
	}
}

u8* CreateCollisionMap(u8* map)
{
	u8* outputMap;
	int x;
	for(x=0; x < (32*32); x++){
		if( map[x] == 0x01 || map[x] == 0x02 || map[x] == 0x03)
		{
			outputMap[x] = 1;
		}
		else
		{
			outputMap[x] = 0;
		}
	}
	return outputMap;
}

//move all sprites and backgrounds
void MoveStuff()
{
	//move the ghost sprite
	MoveSprite(&sprites[0], xpos, ypos);

	//move the cristal sprites
	for(int z=0; z < 4; z++){
		MoveSprite(&sprites[z+4], (cristalx[z] - bg3.x), (cristaly[z] - bg3.y) );
	}

	//update the background registers
	UpdateBG(&bg3);
	UpdateBG(&bg2);

	//move the key sprite
	MoveSprite(&sprites[8], keyx - bg3.x, keyy - bg3.y);

	//moves the gate sprite
	MoveSprite(&sprites[9], gatex - bg3.x, gatey - bg3.y);
}

//checks if the is a collision with a collisionmap
int CheckCollisionWithMap(u8* map, int bgx, int bgy)
{
	int cxt;
	int cyt;
	int ct;
	cxt = (xpos + bgx) / 8;
	cyt =  (ypos + bgy) / 8;
	ct = cyt * 32 + cxt;
	if(map[ct] == 1)
	{
		return 1;
	}
	cxt = (xpos +15 + bgx) / 8;
	cyt = (ypos + bgy) / 8;
	ct = cyt * 32 + cxt;
	if(map[ct] == 1)
	{
		return 1;
	}
	cxt = (xpos + bgx) / 8;
	cyt = (ypos + 15 + bgy) / 8;
	ct = cyt * 32 + cxt;
	if(map[ct] == 1)
	{
		return 1;
	}
	cxt = (xpos +15 + bgx) / 8;
	cyt = (ypos + 15 + bgy) / 8;
	ct = cyt * 32 + cxt;
	if(map[ct] == 1)
	{
		return 1;
	}
	return 0;
}

void MapCollision()
{
	int collision = ( CheckCollisionWithMap(BorderMap,bg3.x,bg3.y) ) + ( CheckCollisionWithMap(WaterMap, bg2.x, bg2.y) );

	if (collision == 0){
		lastx[1] = xpos;
		lasty[1] = ypos;
		lastx[2] = bg3.x;
		lasty[2] = bg3.y;
		lastx[3] = bg2.x;
		lasty[3] = bg2.y;
		lastx[4] = counterx;
		lasty[4] = countery;
	}
	else if (collision == 1){
		xpos = lastx[1];
		ypos = lasty[1];
		bg3.x = lastx[2];
		bg3.y = lasty[2];
		bg2.x = lastx[3];
		bg2.y = lasty[3];
		counterx = lastx[4];
		countery = lasty[4];
		walk = 0;
	}

}

void CheckCollisionWithGems()
{
	int collision = 0;

	for(int z=0; z < 4; z++){
		for(int y=0; y < 16; y++){
			for(int x=0; x < 16; x++){
				if( (counterx+x) > cristalx[z] && (counterx+x) < (cristalx[z] + 16) && (countery+y) > cristaly[z] && (countery+y) < (cristaly[z] + 16) ){
					collision = ghostmap[ x*(y+1)] + cristalmap[ (16-x)*(15-y) ];
				}
				if(collision != 0){
					cristalx[z] = 256;
					cristaly[z] = 0;
					cristals++;
					score++;
					collision = 0;
				}
			}
		}
	}
}

//simple (square) collision
void CheckCollisionWithKey()
{
	if(counterx <= keyx && (counterx + 16) > keyx && countery <= keyy && (countery + 16) > keyy){
		//collision
		key = 1;
		cristals = 0;
	}
}

//should the key be revealed?
void ShowKey()
{
	if(key == 1 || cristals != 4){
		keyx = 256;
		keyy = 0;
	}
	else{
		keyx = mirrorkeyx;
		keyy = mirrorkeyy;
	}
}

//simple (square) collision
void CheckCollisionWithGate()
{
	if(counterx <= gatex && (counterx + 16) > gatex && countery <= gatey && (countery + 16) > gatey && key == 1){
		//collision
		level++;
		playing = 0;
	}
}

void CheckCollisions()
{
	CheckCollisionWithGems();
	CheckCollisionWithKey();
	CheckCollisionWithGate();
	MapCollision();
}

//read the gba keypad
void GetInput()
{
	//walk function
	if(walk == 0){
		if(KEY_DOWN(KEYLEFT))
		{
			walk = 1;
		}
		if(KEY_DOWN(KEYRIGHT))
		{
			walk = 2;
		}
		if(KEY_DOWN(KEYUP))
		{
			walk = 3;
		}
		if(KEY_DOWN(KEYDOWN))
		{
			walk = 4;
		}
	}

}

//Wait until the start key is pressed
void WaitForStart()
{

	int t=0;		//used for detecting a single press

	while (1)
		if( KEY_DOWN(KEYSTART) )
		{
		t++;
			if(t<2){
				return;
			}
		}
		else{
			t = 0;
		}
}

//this function, moves the ghost and scrolls the bg
void Walk()
{
	if(walk == 1){
		counterx--;
		if(bg3.x > 0 && xpos == 120){
			bg3.x--;
			bg2.x--;
		}
		else{
			xpos--;
		}
	}
	if(walk == 2){
		counterx++;
		if(bg3.x < 16 && xpos == 120){
			bg3.x++;
			bg2.x++;
		}
		else{
			xpos++;
		}
	}
	if(walk == 3){
		countery--;
		if(bg3.y > 0 && ypos == 80){
			bg3.y--;
			bg2.y--;
		}
		else{		
			ypos--;
		}
	}
	if(walk == 4){
		countery++;
		if(bg3.y < 96 && ypos == 80){
			bg3.y++;
			bg2.y++;
		}
		else{
			ypos++;
		}
	}
	if( (counterx%16 + countery%16) == 0){
		walk = 0;
	}

}

//loads the watermap and sets the cristals for the current level
void SetLevel(int number)
{
	int x;

	//sets the BG x and y coor, n is in which backgroudlayer the map is
	bg3.x = 0;
	bg3.y = 0;
	bg3.n = 3;

	//sets the BG x and y coor, n is in which backgroudlayer the map is
	bg2.x = 0;
	bg2.y = 0;
	bg2.n = 2;

	//number of cristals is reset and you haven't got a key
	cristals = 0;
	key=0;

	//position of the ghost
	xpos = 16;
	ypos = 16;
	counterx = xpos;
	countery = ypos;

	//load the border map for display
	LoadMap(0,(u8*)border);
	//create the collisionMap
	BorderMap = CreateCollisionMap((u8*)border);


	switch(number)		//add cases for more levels, mapdat, cristal positions, gate position, key position
	{
		case 0:
			//load the map for display
			LoadMap(1,(u8*)water1);
			//the function CreateCollsionMap does not work (right) for the WaterMap
			//make the collisionMap
			for(x=0; x<32*32; x++)
			{
				if( water1[x] != 0x03 )
				{
					WaterMap[x] = 0;
				}
				else
				{
				WaterMap[x] = 1;
				}
			}
			//cirstal position
			cristalx[0] = 36;
			cristaly[0] = 32;
			cristalx[1] = 36;
			cristaly[1] = 208;
			cristalx[2] = 212;
			cristaly[2] = 32;
			cristalx[3] = 212;
			cristaly[3] = 208;
			//position of the gate
			gatex = 112;
			gatey = 128;
			//position of the key
			mirrorkeyx = 128;
			mirrorkeyy = 128;
			break;
		case 1:
			//load the map for display
			LoadMap(1,(u8*)water2);
			//make the collisionMap
			for(x=0; x<32*32; x++)
			{
				if( water2[x] != 0x03 )
				{
					WaterMap[x] = 0;
				}
				else
				{
				WaterMap[x] = 1;
				}
			}
			//cristals position
			cristalx[0] = 68;
			cristaly[0] = 224;
			cristalx[1] = 180;
			cristaly[1] = 16;
			cristalx[2] = 132;
			cristaly[2] = 144;
			cristalx[3] = 116;
			cristaly[3] = 96;
			//position of the gate/door
			gatex = 16;
			gatey = 224;
			//position of the key
			mirrorkeyx = 224;
			mirrorkeyy = 16;
			break;
		case 2:
			//load the map for display
			LoadMap(1,(u8*)water3);
			//make the collisionMap
			for(x=0; x<32*32; x++)
			{
				if( water3[x] != 0x03 )
				{
					WaterMap[x] = 0;
				}
				else
				{
				WaterMap[x] = 1;
				}
			}
			//cristals position
			cristalx[0] = 20;
			cristaly[0] = 224;
			cristalx[1] = 100;
			cristaly[1] = 48;
			cristalx[2] = 132;
			cristaly[2] = 144;
			cristalx[3] = 196;
			cristaly[3] = 208;
			//position of the gate/door
			gatex = 192;
			gatey = 48;
			//position of the key
			mirrorkeyx = 48;
			mirrorkeyy = 224;
			break;
		case 3:
			//load the map for display
			LoadMap(1,(u8*)water4);
			//make the collisionMap
			for(x=0; x<32*32; x++)
			{
				if( water4[x] != 0x03 )
				{
					WaterMap[x] = 0;
				}
				else
				{
				WaterMap[x] = 1;
				}
			}
			//cristals position
			cristalx[0] = 52;
			cristaly[0] = 48;
			cristalx[1] = 54;
			cristaly[1] = 192;
			cristalx[2] = 196;
			cristaly[2] = 48;
			cristalx[3] = 196;
			cristaly[3] = 192;
			//position of the gate/door
			gatex = 144;
			gatey = 96;
			//position of the key
			mirrorkeyx = 96;
			mirrorkeyy = 144;
			break;
		case 4:
			//load the map for display
			LoadMap(1,(u8*)water5);
			//make the collisionMap
			for(x=0; x<32*32; x++)
			{
				if( water5[x] != 0x03 )
				{
					WaterMap[x] = 0;
				}
				else
				{
				WaterMap[x] = 1;
				}
			}
			//cristals position
			cristalx[0] = 68;
			cristaly[0] = 16;
			cristalx[1] = 20;
			cristaly[1] = 176;
			cristalx[2] = 180;
			cristaly[2] = 224;
			cristalx[3] = 228;
			cristaly[3] = 64;
			//position of the gate/door
			gatex = 96;
			gatey = 96;
			//position of the key
			mirrorkeyx = 144;
			mirrorkeyy = 144;
			break;
		case 5:
			//load the map for display
			LoadMap(1,(u8*)water6);
			//make the collisionMap
			for(x=0; x<32*32; x++)
			{
				if( water6[x] != 0x03 )
				{
					WaterMap[x] = 0;
				}
				else
				{
				WaterMap[x] = 1;
				}
			}
			//cristals position
			cristalx[0] = 52;
			cristaly[0] = 48;
			cristalx[1] = 84;
			cristaly[1] = 48;
			cristalx[2] = 196;
			cristaly[2] = 192;
			cristalx[3] = 228;
			cristaly[3] = 224;
			//position of the gate/door
			gatex = 128;
			gatey = 128;
			//position of the key
			mirrorkeyx = 160;
			mirrorkeyy = 160;
			break;
		default:
			break;
	}
}

int main()
{

	//Enable background 2 and set mode to mode 4
	SetMode(MODE_4 | OBJ_MAP_1D | BG2_ENABLE);

	//loads the background palette
	DMACopy(3, (void*)OBJPalette, (void*)BGPaletteMem, 128, DMA_32NOW);

	//draw some pictures in mode 4 and do some fades
	FadeOut(0);
	//draw title screen, actually, just copy the data into the right memeroy position with a dma transfer
	DMACopy(3, (void *)titleData, (void *)VideoBuffer, 96*160, DMA_32NOW);
	FadeIn(2);
	SleepQ(32);
	FadeOut(2);
	DMACopy(3, (void*)title2Palette, (void*)BGPaletteMem, 128, DMA_32NOW);
	DMACopy(3, (void *)title2Data, (void *)VideoBuffer, 96*160, DMA_32NOW);
	FadeIn(2);
	WaitForStart();
	FadeOut(2);

	DMACopy(3, (void*)OBJPalette, (void*)BGPaletteMem, 128, DMA_32NOW);

	//clear buffer
	ClearBuffer();

	//loads the sprite palette
	DMACopy(3, (void*)OBJPalette, (void*)OBJPaletteMem, 128, DMA_32NOW);

	InitializeSprites();

	int x;
	//counter positions
	int cx[2];
	for(x=0; x < 3; x++)
	{
		cx[x] = (x)*8;
	}

	REG_BG3CNT = CHAR_BASE(1) | SCREEN_BASE(0) | BG_COLOR_256;

	REG_BG2CNT = CHAR_BASE(1) | SCREEN_BASE(1) | BG_COLOR_256;

	//this loads the tiles
	LoadTiles();

	//setup sprite stuff
	sprites[0].attribute0 = COLOR_256 | SQUARE | ypos;
	sprites[0].attribute1 = SIZE_16 | xpos;
	sprites[0].attribute2 = 0;

	//loads the sprite image
	DMACopy(3, (void *)ghostData, (void *)OAMData, 64, DMA_32NOW);

	//set up counters
	sprites[1].attribute0 = COLOR_256 | SQUARE | 0;
	sprites[1].attribute1 = SIZE_8 | cx[0];
	sprites[1].attribute2 = 520;			//pointer to tile where sprite starts

	counter1.spriteFrame[0] = 520;
	counter1.spriteFrame[1] = 522;
	counter1.spriteFrame[2] = 524;
	counter1.spriteFrame[3] = 526;
	counter1.spriteFrame[4] = 528;
	counter1.spriteFrame[5] = 530;
	counter1.spriteFrame[6] = 532;
	counter1.spriteFrame[7] = 534;
	counter1.spriteFrame[8] = 536;
	counter1.spriteFrame[9] = 538;
	counter1.activeFrame = 520;

	//set up counter2
	sprites[2].attribute0 = COLOR_256 | SQUARE | 0;
	sprites[2].attribute1 = SIZE_8 | cx[1];
	sprites[2].attribute2 = 520;			//pointer to tile where sprite starts

	counter2.spriteFrame[0] = 520;
	counter2.spriteFrame[1] = 522;
	counter2.spriteFrame[2] = 524;
	counter2.spriteFrame[3] = 526;
	counter2.spriteFrame[4] = 528;
	counter2.spriteFrame[5] = 530;
	counter2.spriteFrame[6] = 532;
	counter2.spriteFrame[7] = 534;
	counter2.spriteFrame[8] = 536;
	counter2.spriteFrame[9] = 538;
	counter2.activeFrame = 520;

	//set up counters
	sprites[3].attribute0 = COLOR_256 | SQUARE | 0;
	sprites[3].attribute1 = SIZE_8 | cx[2];
	sprites[3].attribute2 = 520;			//pointer to tile where sprite starts

	counter3.spriteFrame[0] = 520;
	counter3.spriteFrame[1] = 522;
	counter3.spriteFrame[2] = 524;
	counter3.spriteFrame[3] = 526;
	counter3.spriteFrame[4] = 528;
	counter3.spriteFrame[5] = 530;
	counter3.spriteFrame[6] = 532;
	counter3.spriteFrame[7] = 534;
	counter3.spriteFrame[8] = 536;
	counter3.spriteFrame[9] = 538;
	counter3.activeFrame = 520;

	for(x = 8320; x < 8640; x++)
	{
		OAMData[x] = numbersData[x-8320];
	}

	//create cristal sprites
	sprites[4].attribute0 = COLOR_256 | WIDE;
	sprites[4].attribute1 = SIZE_8;
	sprites[4].attribute2 = 8;

	sprites[5].attribute0 = COLOR_256 | WIDE;
	sprites[5].attribute1 = SIZE_8;
	sprites[5].attribute2 = 8;

	sprites[6].attribute0 = COLOR_256 | WIDE;
	sprites[6].attribute1 = SIZE_8;
	sprites[6].attribute2 = 8;

	sprites[7].attribute0 = COLOR_256 | WIDE;
	sprites[7].attribute1 = SIZE_8;
	sprites[7].attribute2 = 8;

	//loads the cristal image
	DMACopy(3, (void *)cristalData, (void *)(OAMData+128), 32, DMA_32NOW);

	//create key sprite
	sprites[8].attribute0 = COLOR_256 | SQUARE;
	sprites[8].attribute1 = SIZE_16;
	sprites[8].attribute2 = 16;

	//loads the key image
	DMACopy(3, (void *)keyData, (void *)(OAMData+256), 64, DMA_32NOW);

	//create gate sprite
	sprites[9].attribute0 = COLOR_256 | SQUARE;
	sprites[9].attribute1 = SIZE_16;
	sprites[9].attribute2 = 24;

	//loads the key image
	DMACopy(3, (void *)gateData, (void *)(OAMData+384), 64, DMA_32NOW);

	while (1)	//main loop
	{
		if(playing == 0)
		{
			SetMode(MODE_0 | BG2_ENABLE | BG3_ENABLE | OBJ_MAP_1D);		//set objects off
			FadeOut(2);			//fade to black screen
			walk=0;
			SetLevel(level);			//load next level
			MoveStuff();			//move all sprites
			FadeIn(2);				//fade from black
			SetMode(MODE_0 | BG2_ENABLE | BG3_ENABLE | OBJ_ENABLE | OBJ_MAP_1D);	//objects on
			playing = 1;
		}
		else if(playing == 1)
		{
			GetInput();			//read the gba keypad
			Walk();				//walks the ghost
			CopyOAM();			//copies sprite data
			WaitForVsync();			//wait for the screen to stop drawing
			MoveStuff();			//move all sprites
			CheckCollisions();			//all collisions which should be checked
			ShowKey();			//show key or hide key?
			SetCounters(score);			//updates the score
		}
	}
}
