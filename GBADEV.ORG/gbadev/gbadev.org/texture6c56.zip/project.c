//lame texture generator code
//using the ARM SDK
//
//
//15 April 2001
// Richard "Ries" van der Brugge / rvdbrugge@yahoo.com
//


//include standard routines

#include "rieslib.h"
#include <stdlib.h>//for the rand function



//fill the screen with pixels within the 0-32 palette range (grayscale)
void InitRNDScreen(){
long i;
unsigned char *p;
int rndcounter;
rndcounter=0;
p = SCREEN;							// p points to start of screen
	for(i=0; i<38400; i++) {
		*(p+i)=rand()%32;
	}
}


//blur the current screen by average-ing each pixel with it's neighbors
void AverageScreen(){
int x,y;
int pixelright, pixelleft, pixelbelow,pixelabove;
unsigned char *p;
p = SCREEN;							// p points to start of screen

//do screen from top to bottom
for(y=0;y<160;y++){
//inner loop is per vertical line
for(x=0;x<240;x++){
	//store value from 4 surrounding pixels
	pixelright=*(p+((y*240)+(x+1)));
	pixelleft=*(p+((y*240)+(x-1)));
	pixelbelow=*(p+(((y+1)*240)+x));
	pixelabove=*(p+(((y-1)*240)+x));
	//pixel at x,y is all four divided by 4
	*(p+((y*240)+x))=(pixelright+pixelleft+pixelbelow+pixelabove)>>2; //average from 4 neighboring pixels
	}//next x
}//next y

}

//********************************************************************************
//entry from startup asm code, probably the only original bit in this source all others use c_entry :)))
//this is the replacement for the main() stuff you find in other C programs
//********************************************************************************
void StartHere()
{
int i;


SetDisplayMode4On();
ClearScreen();
//create a grayscale palette from 0 to 32
CreatePalette();
//fill the screen with crap
InitRNDScreen();

//create a blurred screen
AverageScreen();
AverageScreen();
AverageScreen();

//loop forever
while(1){
	VSync();
	}//wend
}//end starthere
