GBASlideShow v0.2
By Darrell Blake


Information About This Release
------------------------------

Quite a huge updated from version 0.1. Instead of you having to know how to convert images
to header files and then compile the program I've written a program called GBASlideShow
Generator. All you need to do now is load up GBASlideShow Generator and select the images
you want in your rom. Then click Make GBA Rom and the program creates the C code and 
compiles and links it for you so you don't have to know any code. The only real problem is 
that you have to have devkitadvance installed but for the next release I will make sure 
that it runs stand-alone.


Instructions
------------

You need to have devkitadvance installed. To get it go to http://devkitadv.sourceforge.net

Use the GBASlideShow Generator to create your slideshow and then load it up in your GBA or 
emulator and then use the A button to go to the next picture and B to go to the previous 
picture.

If anyone wants to help with this program feel free. I would like to make this a really 
cool program with lots of functionality.


Thanks
------

I would like to thank Darren for allowing me to use his GFX2GBA program in this program. 
For more information on this program go to http://www.gbacode.net
