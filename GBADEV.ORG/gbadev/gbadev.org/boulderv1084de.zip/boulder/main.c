//------------------------------------------------------------------------------------

// main
// Rich Heasman April 2002

//------------------------------------------------------------------------------------

#include 	"mygba.h"
#include 	"main.h"

#include 	"game.h"
#include 	"vblank.h"
#include 	"button.h"
#include 	"interrupt.h"
#include 	"gfx.h"
#include 	"gfxdata1.h"
#include 	"menu.h"
#include 	"profile.h"
#include 	"rnd.h"
#include 	"debug.h"
#include	"background.h"

MULTIBOOT

//------------------------------------------------------------------------------------

// Program entry point

void AgbMain(void)
{
 	Gfx_Init();
	Interrupt_Init();
	VBlank_Init();
	Button_Init();
	Profile_Init();
	Rnd_Init();
	Debug_Init();

	Menu_Init();
    Game_Init();

	Interrupt_Enable();

	while (TRUE)
	{
		Button_Update();

		Menu_Update();
		Game_Update();

		Background_ScreenClear(BACKGROUND_TEXT);
		Profile_Point("Text Clear");

		Game_Render();
		Menu_Render();

		Debug_Render();
		Profile_Render();

		Gfx_Update();
	}		
}

//------------------------------------------------------------------------------------

