//------------------------------------------------------------------------

// debug
// Rich Heasman May 2002

//------------------------------------------------------------------------

#include	"agbtypes.h"

#define	Debug_Display(x)	Debug_DisplayValueInt(#x, x);

void	Debug_Init(void);
void	Debug_Render(void);
void	Debug_DisplayValueInt(char *szName, int nValue);

//-----------------------------------------------------------------------

