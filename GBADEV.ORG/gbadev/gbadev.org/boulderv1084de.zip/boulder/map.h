//----------------------------------------------------------------------------

// map
// Rich Heasman April 2002

//----------------------------------------------------------------------------

#include	"mygba.h"

#define	MAP_MAX_X				40
#define	MAP_MAX_Y				22

// map data available externally
extern u16   	uMap[MAP_MAX_X][MAP_MAX_Y];

// map types
enum
{
	MAP_BLANK,
	MAP_EARTH,
	MAP_BOULDER,
	MAP_DIAMOND,
	MAP_EDGE,
	MAP_WALL,
	MAP_DWALL,
	MAP_GWALL,
	MAP_SQUARE,
	MAP_BUTTERFLY,
	MAP_GREEN,
	MAP_HOME,
	MAP_START,
	MAP_MAN,
	MAP_BOULDER_FALLING,
	MAP_DIAMOND_FALLING,

	MAP_BASE_MAX,					// end of base types
	
	MAP_SQUARE_NOT_MOVED,
	MAP_BUTTERFLY_NOT_MOVED,
	MAP_START_1,
	MAP_START_2,
	MAP_DIAMOND_1,
	MAP_DIAMOND_2,
	MAP_DIAMOND_3,
	MAP_DIAMOND_4,
	MAP_DIAMOND_5,
	MAP_DIAMOND_6,
	MAP_DIAMOND_7,
	MAP_DIAMOND_8,
	MAP_DEATH_1,
	MAP_DEATH_2,
	MAP_DEATH_3,
	MAP_DEATH_4,
	MAP_DEATH_5,
	MAP_BFLY_DEATH_1,
	MAP_BFLY_DEATH_2,
	MAP_BFLY_DEATH_3,
	MAP_BFLY_DEATH_4,
	MAP_BFLY_DEATH_5,
	MAP_BUTTERFLY_1,
	MAP_BUTTERFLY_2,
	MAP_BUTTERFLY_3,
	MAP_BUTTERFLY_4,
	MAP_BUTTERFLY_5,
	MAP_BUTTERFLY_6,
	MAP_BUTTERFLY_7,
	MAP_BUTTERFLY_8,
	MAP_SQUARE_1,
	MAP_SQUARE_2,
	MAP_SQUARE_3,
	MAP_SQUARE_4,
	MAP_GREEN_1,
	MAP_GREEN_2,
	MAP_GREEN_3,
	MAP_GREEN_4,
	MAP_DWALL_1,
	MAP_DWALL_2,
	MAP_DWALL_3,
	MAP_DWALL_4,
	MAP_WHITE,
	MAP_DWALL_BOULDER,
	MAP_DWALL_DIAMOND,

	MAP_TYPES_MAX
};

#define	MAP_TILE_MASK		(0xFF)

//----------------------------------------------------------------------------

void	Map_Init(void);
void	Map_Begin(uint uLevel);
void	Map_UpdateTimerClear(void);

void	Map_Update(void);
void	Map_Process1(u32 *pFuncAddr) CODE_IN_IWRAM;
void	Map_Process2(u32 *pFuncAddr) CODE_IN_IWRAM;
void	Map_ProcessDrop(int nCol, int nLine, int nTarget) CODE_IN_IWRAM;
void	Map_ProcessMove(int nCol, int nLine, int nTarget) CODE_IN_IWRAM;
void	Map_ProcessDWall(int nCol, int nLine) CODE_IN_IWRAM;
void	Map_ProcessGreen(int nCol, int nLine) CODE_IN_IWRAM;
void	Map_TileExplode(int nX, int nY, int nTile);
void	Map_TileExplode_IWRAM(int nX, int nY, int nTile) CODE_IN_IWRAM;

void	Map_Render(void);
void	Map_DrawPrepare(void);
void	Map_Draw(u32 *pFuncAddr, int nX, int nY) CODE_IN_IWRAM;

void	Map_SetupFE(void);
void	Map_FlashWhite(void);
BOOL	Map_FlashingWhite(void);
void	Map_TransitionBegin(int nStep);


//----------------------------------------------------------------------------
