//------------------------------------------------------------------------

// string
// Rich Heasman May 2002

//------------------------------------------------------------------------

#include	"agbtypes.h"
#include	"string.h"

//------------------------------------------------------------------------

void	String_Copy(char *szDest, char *szSrc)
{
	while (*szSrc != STRING_TERMINATOR)
	{
		*szDest++ = *szSrc++;
	}
	*szDest = STRING_TERMINATOR;
}	

//------------------------------------------------------------------------

void	String_Cat(char *szDest, char *szSrc)
{
	while (*szDest != STRING_TERMINATOR)
	{
		szDest++;
	}
	while (*szSrc != STRING_TERMINATOR)
	{
		*szDest++ = *szSrc++;
	}
	*szDest = STRING_TERMINATOR;
}	

//------------------------------------------------------------------------

#define	STRING_INT_DIGITS_MAX			10

static const int	nStringIntFactors[STRING_INT_DIGITS_MAX]	=  
{ 1000000000, 100000000, 10000000, 1000000, 100000, 10000, 1000, 100, 10, 1};

void	String_FromInt(char *szDest, int nSrc)
{
	int		nFactorIndex;
	int		nFactor;
	int		nCount;
	int		nNumber;
	BOOL	boFirst;

	nNumber = nSrc;
	if (nNumber < 0)
	{
		nNumber = -nSrc;
		*szDest++ = '-';
	}
	nFactorIndex = 0;
	boFirst = TRUE;
	nFactorIndex = STRING_INT_DIGITS_MAX - 1;
	while (nStringIntFactors[nFactorIndex] < nNumber && nFactorIndex > 0)
	{
		nFactorIndex--;
	}

	while (nFactorIndex < STRING_INT_DIGITS_MAX)
	{
		nFactor = nStringIntFactors[nFactorIndex];
		nCount = 0;
		while (nNumber >= nFactor)
		{
			nNumber -= nFactor;
			nCount++;
		}
		if (!boFirst || nCount > 0 || nFactor == 1)
		{
			*szDest++ = nCount + '0';
			boFirst = FALSE;
		}  
		nFactorIndex++;
	}
	*szDest = STRING_TERMINATOR;
}	

//------------------------------------------------------------------------

void	String_FromChar(char *szDest, char cSrc)
{
	*szDest++ = cSrc;
	*szDest = STRING_TERMINATOR;
}	

//------------------------------------------------------------------------
