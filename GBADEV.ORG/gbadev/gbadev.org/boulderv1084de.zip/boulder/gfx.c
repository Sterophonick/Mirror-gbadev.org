//------------------------------------------------------------------------------------

// graphics 
// Rich Heasman April 2002

//------------------------------------------------------------------------------------

#include "mygba.h"
#include "gfx.h"

#include "vblank.h"
#include "profile.h"
#include "background.h"
#include "blend.h"

// VRAM Memory map : blocks x800 (slots 0 to 29)
// 0 - 9 		 : gfxdata1 tiles
// 10,11 		 : front and back for bg 0 (text)
// 12,13		 : front and back for bg 1 (display)
// 14,15		 : front and back for bg 2 (map)
// 16 - 17		 : gfxdata2 tiles
// 18,19		 : front and back for bg 3 (under text)

//------------------------------------------------------------------------------------

void	Gfx_Init(void)
{
	M_DISCNT_FRCBLK_ENA				// blank all

    M_DISCNT_BG0_OFF				// turn everything off
    M_DISCNT_BG1_OFF
    M_DISCNT_BG2_OFF
    M_DISCNT_BG3_OFF
    M_MOSAIC_SET(0,0,0,0)

	Background_Init();
	Blend_Init();

}

//------------------------------------------------------------------------------------

void	Gfx_Update(void)
{
	Blend_Update();
	VBlank_Wait();
	Profile_Point("Post VBlank");

	M_DISCNT_FRCBLK_DIS									// enable display

	Blend_Render();

 	Background_FlipBufferView(BACKGROUND_TEXT);			
	Background_Update(BACKGROUND_TEXT);
	Background_FlipBufferWrite(BACKGROUND_TEXT);

	Background_Update(BACKGROUND_MAP);

	Background_Update(BACKGROUND_DISPLAY);
}

//------------------------------------------------------------------------------------
