//------------------------------------------------------------------------

// palette
// Rich Heasman May 2002

//------------------------------------------------------------------------

#include	"mygba.h"
#include	"palette.h"

#include	"mapdata.h"
#include	"debug.h"


//-----------------------------------------------------------------------

typedef struct
{
	int	nHead;
	int	nLegs;
	int	nFeet;
} PALETTE_TYPE;


const PALETTE_TYPE	Palette[MAP_LEVELS] =
{
	//head		 	 legs		    feet
	{ COLOUR_DGREY, COLOUR_BROWN, 	COLOUR_WHITE},		// A
	{ COLOUR_PURPLE,COLOUR_PINK, 	COLOUR_WHITE},		// B
	{ COLOUR_BROWN, COLOUR_DBROWN, 	COLOUR_WHITE}, 		// C
	{ COLOUR_BROWN, COLOUR_PURPLE, 	COLOUR_WHITE}, 		// D
	{ COLOUR_PINK, 	COLOUR_DBROWN, 	COLOUR_WHITE}, 		// E
	{ COLOUR_PINK, 	COLOUR_LBLUE, 	COLOUR_WHITE}, 		// F
	{ COLOUR_PINK, 	COLOUR_DBROWN, 	COLOUR_LGREEN}, 	// G
	{ COLOUR_LBLUE, COLOUR_DRED, 	COLOUR_WHITE}, 		// H
	{ COLOUR_PURPLE,COLOUR_BROWN, 	COLOUR_WHITE}, 		// I
	{ COLOUR_BROWN, COLOUR_BLUE, 	COLOUR_WHITE}, 		// J
	{ COLOUR_BROWN, COLOUR_DGREY, 	COLOUR_WHITE}, 		// K
	{ COLOUR_PINK, 	COLOUR_GREY, 	COLOUR_WHITE}, 		// L
	{ COLOUR_BROWN, COLOUR_BLUE, 	COLOUR_LGREEN}, 	// M
	{ COLOUR_BROWN, COLOUR_GREY, 	COLOUR_WHITE}, 		// N
	{ COLOUR_LBLUE, COLOUR_BROWN, 	COLOUR_WHITE}, 		// O
	{ COLOUR_PINK, 	COLOUR_DBROWN, 	COLOUR_WHITE}, 		// P
};

//-----------------------------------------------------------------------

void	Palette_Copy(int nDest, int nSrc)
{
	u16	*pDest;
	u16	*pSrc;

	pSrc  = (u16 *) MEM_PAL_BG + nSrc;
	pDest = (u16 *) MEM_PAL_BG + nDest;
	*pDest = *pSrc;
}	

//-----------------------------------------------------------------------

void	Palette_Begin(int nLevel)
{
	Palette_Copy(COLOUR_HEAD, Palette[nLevel].nHead);
	Palette_Copy(COLOUR_LEGS, Palette[nLevel].nLegs);
	Palette_Copy(COLOUR_FEET, Palette[nLevel].nFeet);
}

//-----------------------------------------------------------------------

