//------------------------------------------------------------------------------------

// background
// Rich Heasman May 2002

//------------------------------------------------------------------------------------

#include	"mygba.h"

enum
{
	BACKGROUND_TEXT,				// text
	BACKGROUND_DISPLAY,				// logo
	BACKGROUND_MAP,					// game tiles

	BACKGROUND_MAX
};

//------------------------------------------------------------------------------------

typedef struct
{
    uint  	uActive;				// active
    uint  	uPriority;    			// (0=highest,3=lowest)
    uint  	uCbb;        			// character base block
    uint  	uBufferWrite;			// current buffer view 0/1
    uint  	uBufferView;			// current buffer write 0/1
    uint  	uSbbBase;      			// screen base block
    uint  	uSbb;   	   			// current screen base to write to
    uint  	uColmode;    			// 0=16 pals 1=1 pal
    uint  	uMapsize;    			// size of map data (0: 256x256 to 3:512x512)
	uint	uMapLength;				// map length in words
	int		nScrollX;				// scroll position
	int		nScrollY;				// scroll position
	BOOL	boFlipView;				// screen flip required this frame
} BACKGROUND_TYPE;


//------------------------------------------------------------------------------------

void 		Background_Init(void);

void 		Background_Setup(uint uBackground);
u16			*Background_SbbPtr(uint uBackground);
void		Background_SetScreen(uint uBackground, u16 nTileIndex);
void		Background_ScreenClear(uint uBackground);

void		Background_SetAll(uint uBackground, u16 nTileIndex);
void		Background_ScrollSet(uint uBackground, int nX, int nY);

void		Background_Update(uint uBackground);
void		Background_FlipBufferWrite(uint uBackground);
void		Background_FlipBufferView(uint uBackground);
void		Background_LoadVram(void);

u16			Background_TileFromGraphic(u16 uGraphic);
void		Background_Font1Print(int nXCo, int nYCo, char *szMessage);
void		Background_Font2Print(int nXCo, int nYCo, char *szMessage);

void		Background_SetupFE(void);

//------------------------------------------------------------------------------------
