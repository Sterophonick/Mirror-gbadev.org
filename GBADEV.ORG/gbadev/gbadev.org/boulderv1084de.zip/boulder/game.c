//------------------------------------------------------------------------------------

// Game
// Rich Heasman April 2002

//------------------------------------------------------------------------------------

#include 	"mygba.h"
#include 	"game.h"

#include 	"map.h"
#include 	"mapdata.h"
#include 	"menu.h"
#include 	"gfx.h"
#include 	"button.h"
#include 	"vblank.h"
#include 	"scroll.h"
#include 	"man.h"
#include 	"stats.h"
#include	"background.h"
#include	"palette.h"
#include	"profile.h"
#include	"string.h"
#include	"blend.h"

//------------------------------------------------------------------------------------

static uint			uGameState;
static uint			uGameTimer;
static uint			uGameNextTimer;
static uint			uGameStartTimer;
static uint			uGameStatsTimer;
static const uint	uGameStartWaitLen = 120;
static const uint	uGameStatsWaitLen = 180;
static const uint	uGameDoneWaitLen = 200;
static const uint	uGameWipeWaitLen = 40;
static const uint	uGameNextWaitLen = 60;
static BOOL 		boGameStartDisplay;
static uint			uGameStateAfterWipe;
static BOOL			boGameStartFadeIn;
static BOOL			boGameStartedFadeOut;
static BOOL			boGameStatsFadeIn;
static BOOL			boGameFromFE;


//------------------------------------------------------------------------------------

void	Game_Init(void)
{
	Map_Init();
	Man_Init();
	Scroll_Init();

	boGameStartDisplay = FALSE;
	boGameStartedFadeOut = FALSE;
	boGameStartFadeIn = FALSE;
	boGameStatsFadeIn = TRUE;
	boGameFromFE = FALSE;
	uGameState = GAME_DORMANT;
}

//------------------------------------------------------------------------------------

void	Game_Update(void)
{
    switch(uGameState)
    {
        case GAME_PAUSE:
        case GAME_DORMANT:
		{
            break;
		}
        case GAME_INGAME_INIT:
		{
			Map_Begin(Menu_LevelGet());
			Palette_Begin(Menu_LevelGet() % MAP_LEVELS); 
			Man_Begin();
			Stats_Begin();
			Scroll_Begin();

			boGameStartedFadeOut = FALSE;
			boGameStatsFadeIn = FALSE;
			boGameStartDisplay = TRUE;

			if (boGameFromFE)
			{
				boGameFromFE = FALSE;
			}
			else	// not from FE
			{
				boGameStartFadeIn = FALSE;
			}

        	VBlank_TimerSet(&uGameStartTimer, uGameStartWaitLen);
        	VBlank_TimerSet(&uGameStatsTimer, uGameStatsWaitLen);
			uGameState=GAME_INGAME;
            break;
		}
        case GAME_INGAME:
		{
			Man_Update1();
			Map_Update();
			Man_Update2();
			Scroll_Update();
			Stats_Update();

			if (Man_Home())
			{
				uGameState = GAME_DONE_INIT;
			}
			if (!Man_Alive())
			{
			   	VBlank_TimerSet(&uGameNextTimer, uGameNextWaitLen);
				uGameState = GAME_DEAD_WAIT;
			}
			if (Stats_TimerMature())
			{
			   	VBlank_TimerSet(&uGameNextTimer, uGameNextWaitLen);
				uGameState = GAME_EXPIRED_WAIT;
			}
            break;
		}
		case GAME_DONE_INIT:
		{
		   	VBlank_TimerSet(&uGameTimer, uGameDoneWaitLen);
		   	VBlank_TimerSet(&uGameNextTimer, uGameNextWaitLen);
			uGameState=GAME_DONE_WAIT;
            break;
		}
		case GAME_DONE_WAIT:
		{
			if (VBlank_TimerMature(&uGameNextTimer))
			{
				if (Button_PressedDebounced(BUTTON_A)
				 || Button_PressedDebounced(BUTTON_START)
				 || VBlank_TimerMature(&uGameTimer))
				{
					Menu_LevelIncrement();
					uGameState = GAME_WIPE_INIT;
					uGameStateAfterWipe = GAME_INGAME_INIT;
				}			   
			}
            break;
		}
		case GAME_EXPIRED_WAIT:
		{
			if (VBlank_TimerMature(&uGameNextTimer))
			{
				if (Button_PressedDebounced(BUTTON_A)
				 || Button_PressedDebounced(BUTTON_START))
				{
					uGameState = GAME_WIPE_INIT;
					uGameStateAfterWipe = GAME_INGAME_INIT;
				}
			}
            break;
		}
		case GAME_DEAD_WAIT:
		{
			Map_Update();

			if (VBlank_TimerMature(&uGameNextTimer))
			{
				if (Button_PressedDebounced(BUTTON_A)
				 || Button_PressedDebounced(BUTTON_START))
				{
					uGameState = GAME_WIPE_INIT;
					uGameStateAfterWipe = GAME_INGAME_INIT;
				}
			}
            break;
		}
		case GAME_WIPE_INIT:
		{
			Man_Remove();
			Map_TransitionBegin(-4);
			Blend_TextOut();
        	VBlank_TimerSet(&uGameTimer, uGameWipeWaitLen);
			uGameState=GAME_WIPE_WAIT;
			break;
		}
		case GAME_WIPE_WAIT:
		{
			if (VBlank_TimerMature(&uGameTimer))
			{
				uGameState = uGameStateAfterWipe;
			}
			break;
		}
    }
}

//------------------------------------------------------------------------------------

void	Game_Render(void)
{
	Background_FlipBufferWrite(BACKGROUND_MAP);
	Map_Render();
	Profile_Point("Map Render");
	Man_Render();
	Profile_Point("Stats Render");
	Background_FlipBufferView(BACKGROUND_MAP);

	Scroll_Render();

	if (VBlank_TimerMature(&uGameStatsTimer))
	{
		if (!boGameStatsFadeIn)
		{
			Blend_TextIn();
			boGameStatsFadeIn = TRUE;
		}

		if (uGameState != GAME_DORMANT)
		{
			Stats_Render();
		}
	}

	if (boGameStartDisplay)
	{
		if (!boGameStartFadeIn)
		{
			Blend_TextIn();
			boGameStartFadeIn = TRUE;
		}

		if (VBlank_TimerMature(&uGameStartTimer))
		{
			if (!boGameStartedFadeOut)
			{
				Blend_TextOut();
				boGameStartedFadeOut = TRUE;
			}
			else
			{
				if (Blend_Done())
				{
					boGameStartDisplay = FALSE;
				}
			}
		}
		Menu_RenderLevel();
	}

	if (uGameState == GAME_EXPIRED_WAIT)
	{
	    Background_Font2Print( 8,10, "TIME UP");
    }
}

//------------------------------------------------------------------------------------

void	Game_StateSet(uint uState)
{
	uGameState = uState;
}

//------------------------------------------------------------------------------------

uint	Game_StateGet(void)
{
	return(uGameState);
}

//------------------------------------------------------------------------------------

void	Game_StateSetAfterWipe(uint uState)
{
	uGameStateAfterWipe = uState;
}	

//------------------------------------------------------------------------------------

void	Game_FromFE(void)
{
	boGameFromFE = TRUE;
}	

//------------------------------------------------------------------------------------
