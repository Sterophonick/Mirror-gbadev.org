//------------------------------------------------------------------------------------

// interrupt
// Rich Heasman April 2002

//------------------------------------------------------------------------------------

#define INT_TYPE_VBL    0
#define INT_TYPE_HBL    1
#define INT_TYPE_VCNT   2
#define INT_TYPE_TIM0   3
#define INT_TYPE_TIM1   4
#define INT_TYPE_TIM2   5
#define INT_TYPE_TIM3   6
#define INT_TYPE_SIO    7
#define INT_TYPE_DMA0   8
#define INT_TYPE_DMA1   9
#define INT_TYPE_DMA2   10
#define INT_TYPE_DMA3   11
#define INT_TYPE_KEY    12
#define INT_TYPE_CART   13

//------------------------------------------------------------------------------------

void	Interrupt_Init(void);
void 	Interrupt_HandlerSet(u8 intno, void* function);
void 	Interrupt_Enable(void);
void 	Interrupt_HWReset(void);

//------------------------------------------------------------------------------------
