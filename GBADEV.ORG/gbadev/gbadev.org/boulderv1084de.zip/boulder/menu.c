//------------------------------------------------------------------------------------

// Menu
// Rich Heasman April 2002

//------------------------------------------------------------------------------------

#include 	"mygba.h"
#include 	"menu.h"

#include 	"vblank.h"
#include 	"map.h"
#include 	"mapdata.h"
#include 	"button.h"
#include 	"game.h"
#include 	"gfx.h"
#include 	"interrupt.h"
#include 	"scroll.h"
#include 	"man.h"
#include	"background.h"
#include	"palette.h"
#include	"string.h"
#include	"main.h"
#include	"blend.h"

enum
{
	MENU_INIT,
	MENU_INFO_WAIT_1,
	MENU_INFO_WAIT_2,
	MENU_PRE_GAME_INIT,
	MENU_PRE_GAME,
	MENU_DORMANT_INIT,
	MENU_DORMANT,
	MENU_INGAME,
	MENU_GAME_QUITTING,
	MENU_GAME_COMPLETE
};

enum
{
	MENU_IG_RESTART,
	MENU_IG_QUIT,

	MENU_IG_MAX
};

enum
{
	MENU_DEV_OFF,
	MENU_DEV_ON
};

enum
{
	MENU_DEV_RESET,					// to save the on/off switch�
	MENU_DEV_LEVEL_LOCK,

	MENU_DEV_MAX
};

static uint			uMenuState;
static uint			uMenuDevState;
static uint			uMenuLevelMax;
static uint			uMenuLevel;
static uint			uMenuLevelGot;
static uint			uMenuIGOption;
static uint			uMenuDevOption;
static BOOL			boMenuLevelsLocked;

static uint			uMenuButtonTimer;
static uint			uMenuButtonTimerLen;
static const uint	uMenuButtonTimerDefault	= 40;

static uint			uMenuInfoTimer;
static const uint	uMenuInfoTimerLen 	= 180;
static const uint	uMenuInfoGapLen 	= 60;

static BOOL			boMenuClearLogo;
static BOOL			boMenuFlipDisplay;		// hack to avoid fade glitch ( alpha seems to be a frame behind)
static BOOL			boMenuFadeIn;

#define	MENU_VERSION_STRING	"v1.0 15 May 2002"

//------------------------------------------------------------------------------------

void	Menu_Init(void)
{
	uMenuLevel = 0;
	uMenuLevelMax = MAP_NUM_OF - 1;
	uMenuLevelGot = uMenuLevel;

	uMenuIGOption = MENU_IG_RESTART;
	uMenuDevOption = MENU_DEV_RESET;
	uMenuState = MENU_INIT;
	uMenuDevState = MENU_DEV_OFF;
	boMenuLevelsLocked = TRUE;

	boMenuFlipDisplay = FALSE;
	boMenuClearLogo = FALSE;
	boMenuFadeIn = FALSE;

   	VBlank_TimerSet(&uMenuInfoTimer, uMenuInfoTimerLen);

	uMenuButtonTimerLen = 0;
   	VBlank_TimerSet(&uMenuButtonTimer, 0);
}

//------------------------------------------------------------------------------------

void	Menu_Update(void)
{
	uint	uLevelTop;
	BOOL	boButtonRequest;
	BOOL	boButtonDone;

    switch(uMenuState)
	{
		case MENU_INIT :
		{
			uMenuState = MENU_INFO_WAIT_1;
			break;
		}
		case MENU_INFO_WAIT_1 :
		{
			if (VBlank_TimerMature(&uMenuInfoTimer))
			{
			   	VBlank_TimerSet(&uMenuInfoTimer, uMenuInfoGapLen);
				Blend_TextOut();
				uMenuState = MENU_INFO_WAIT_2;
			}
			break;
		}
		case MENU_INFO_WAIT_2 :
		{
			if (VBlank_TimerMature(&uMenuInfoTimer))
			{
				uMenuState = MENU_PRE_GAME_INIT;
			}
			break;
		}
		case MENU_PRE_GAME_INIT:
		{
			uMenuState = MENU_PRE_GAME;
			break;
		}
		case MENU_PRE_GAME :
		{
			Scroll_UpdateFE();

			if (uMenuDevState == MENU_DEV_OFF && Blend_Done())
			{
				if ((Button_PressedDebounced(BUTTON_A))
				||  (Button_PressedDebounced(BUTTON_START) && !Button_Pressed(BUTTON_SELECT)))
				{
					Scroll_Init();
					Game_FromFE();
					Game_StateSet(GAME_INGAME_INIT);
					uMenuState = MENU_DORMANT_INIT;
				}

				boButtonRequest = FALSE;
				boButtonDone = FALSE;
				if (Button_Pressed(BUTTON_UP))
				{
					boButtonRequest = TRUE;

					if (VBlank_TimerMature(&uMenuButtonTimer))
					{
						uLevelTop = uMenuLevelMax;
						if (boMenuLevelsLocked)
						{
							uLevelTop = uMenuLevelGot;
						}

						if (uMenuLevel < uLevelTop)
						{
							uMenuLevel++;
						}
						boButtonDone = TRUE;
					}
				}

				if (Button_Pressed(BUTTON_DOWN))
				{
					boButtonRequest = TRUE;

					if (VBlank_TimerMature(&uMenuButtonTimer))
					{
						if (uMenuLevel > 0)
						{
							uMenuLevel--;
						}
						boButtonDone = TRUE;
					}
				} 

				if (!boButtonRequest)
				{
				   	VBlank_TimerSet(&uMenuButtonTimer, 0);
					uMenuButtonTimerLen = uMenuButtonTimerDefault;
				}

				if (boButtonDone)
				{
					if (uMenuButtonTimerLen > 4)
					{
						uMenuButtonTimerLen -= 12;
					}
				   	VBlank_TimerSet(&uMenuButtonTimer, uMenuButtonTimerLen);
				}
			}
			break;
		}
		case MENU_DORMANT_INIT :
		{
			uMenuState = MENU_DORMANT;
			break;
		}
		case MENU_DORMANT :
		{
			if ((Game_StateGet() == GAME_INGAME)
			 && (Man_Born()))
			{
				if (Button_PressedDebounced(BUTTON_START))
				{
					Game_StateSet(GAME_PAUSE);
					uMenuState = MENU_INGAME;
				}
			}
			break;
		}
		case MENU_INGAME :
		{
			if (Button_PressedDebounced(BUTTON_START))
			{
				Game_StateSet(GAME_INGAME);
				uMenuState = MENU_DORMANT;
			}

			if (Button_PressedDebounced(BUTTON_DOWN))
			{
				if (uMenuIGOption < MENU_IG_MAX-1)
				{
					uMenuIGOption++;
				}
			} 
			if (Button_PressedDebounced(BUTTON_UP))
			{
				if (uMenuIGOption > 0)
				{
					uMenuIGOption--;
				}
			} 

			if (Button_Pressed(BUTTON_A))
			{
				switch (uMenuIGOption)
				{
					case MENU_IG_RESTART:
					{
						Game_StateSet(GAME_WIPE_INIT);
						Game_StateSetAfterWipe(GAME_INGAME_INIT);
			            uMenuState=MENU_DORMANT;
						break;
					}
					case MENU_IG_QUIT:
					{
						Game_StateSet(GAME_WIPE_INIT);
						Game_StateSetAfterWipe(GAME_DORMANT);
						uMenuState = MENU_GAME_QUITTING;
						break;
					}
				}
			}
			break;
		}
		case MENU_GAME_QUITTING:
		{
			if (Game_StateGet() == GAME_DORMANT)
			{
				uMenuState = MENU_PRE_GAME_INIT;
			}
			break;
		}
		case MENU_GAME_COMPLETE :
		{
			Game_StateSet(GAME_DORMANT);
			// classic game completion lockup
			break;
		}
	}

    switch(uMenuDevState)
    {
    	case MENU_DEV_OFF:
    	{
			if ((Button_Pressed(BUTTON_SELECT))
			 && (Button_PressedDebounced(BUTTON_START)))
			{
				uMenuDevState = MENU_DEV_ON;
			}
    		break;
    	}
    	case MENU_DEV_ON:
    	{
			if (Button_PressedDebounced(BUTTON_SELECT))
			{
				uMenuDevState = MENU_DEV_OFF;
			}
			if (Button_PressedDebounced(BUTTON_DOWN))
			{
				if (uMenuDevOption < MENU_DEV_MAX-1)
				{
					uMenuDevOption++;
				}
			} 
			if (Button_PressedDebounced(BUTTON_UP))
			{
				if (uMenuDevOption > 0)
				{
					uMenuDevOption--;
				}
			} 
			if (Button_PressedDebounced(BUTTON_A))
			{
				switch (uMenuDevOption)
				{
					case MENU_DEV_RESET:
					{
						Interrupt_HWReset();
						break;
					}
					case MENU_DEV_LEVEL_LOCK:
					{
						boMenuLevelsLocked = !boMenuLevelsLocked;
						if (boMenuLevelsLocked)
						{
							if (uMenuLevel > uMenuLevelGot)
							{
								uMenuLevel = uMenuLevelGot;
							}
						}
					}
				}
			}
			break;
    	}
    }
}


//------------------------------------------------------------------------------------

void	Menu_Render(void)
{
    switch(uMenuState)
	{
		case MENU_INIT :
		{
			break;
		}
		case MENU_INFO_WAIT_1 :
		case MENU_INFO_WAIT_2 :
		{
//			if (!boMenuFadeIn)
//			{
//				boMenuFadeIn = TRUE;
//				Blend_TextIn();
//			}
		    Background_Font1Print( 1,2, "Boulder Dash Advance");
		    Background_Font1Print( 1,4, MENU_VERSION_STRING);
		    Background_Font1Print( 1,6, "By Rich Heasman");
		    Background_Font1Print( 1,17, "This game is freeware and");
		    Background_Font1Print( 1,18, "is an unoffical conversion");
			break;	
		}
		case MENU_DORMANT_INIT :
		{
			Blend_FEOut();
			boMenuClearLogo = TRUE;
			break;
		}
		case MENU_DORMANT :
		{
			if (boMenuClearLogo)
			{
				if (Blend_Done())
				{
					Background_FlipBufferWrite(BACKGROUND_DISPLAY);
					Background_ScreenClear(BACKGROUND_DISPLAY);
					Background_FlipBufferView(BACKGROUND_DISPLAY);
					boMenuClearLogo = FALSE;
				}
			}
			break;
		}
		case MENU_PRE_GAME_INIT:
		{
			Background_FlipBufferWrite(BACKGROUND_DISPLAY);
			Background_SetupFE();
			Map_SetupFE();
			Blend_FEIn();
			boMenuFlipDisplay = TRUE;
			break;
		}
		case MENU_PRE_GAME :
		{
			if (boMenuFlipDisplay)
			{
				boMenuFlipDisplay = FALSE;
				Background_FlipBufferView(BACKGROUND_DISPLAY);
			}

//			Palette_Begin(0);	I kind of like leaving the palette as it was on the previous sheet
			Scroll_Render();
			Menu_RenderLevel();
			break;
		}
		case MENU_INGAME :
		{
		    Background_Font2Print( 9,7, 	"PAUSED");
		    Background_Font2Print( 9,8, 	"------");
		    Background_Font2Print( 9,10, 	"RESTART");
		    Background_Font2Print( 9,11, 	"QUIT");

		    Background_Font2Print( 6, 10 + uMenuIGOption, ">");

			break;
		}
		case MENU_GAME_QUITTING :
		{
			break;
		}
		case MENU_GAME_COMPLETE :
		{
		    Background_Font2Print( 2,7, "   NICE ONE  ");
		    Background_Font2Print( 2,9, "GAME COMPLETE");
			break;
		}
	}

    switch(uMenuDevState)
    {
    	case MENU_DEV_OFF:
    	{
    		break;
    	}
    	case MENU_DEV_ON:
    	{
		    Background_Font1Print( 9,7, 	"Development");
		    Background_Font1Print( 9,8, 	"-----------");
		    Background_Font1Print( 9,10, 	"HW Reset");
			if (boMenuLevelsLocked)
			{
				Background_Font1Print( 9,11, "Unlock levels");
			}
			else
			{
				Background_Font1Print( 9,11, "Lock levels");
			}

		    Background_Font1Print( 7, 10 + uMenuDevOption, ">");
    		break;
    	}
	}
}

//------------------------------------------------------------------------------------

void	Menu_RenderLevel(void)
{
	char		szMessage[STRING_LEN_MAX];
	char		szLevel[STRING_LEN_MAX];

	String_Copy(szMessage, "LEVEL ");
	String_FromChar(szLevel, (uMenuLevel % MAP_LEVELS) + 'A');
	String_Cat(szMessage, szLevel);
	String_FromChar(szLevel, (uMenuLevel / MAP_LEVELS) + '1');
	String_Cat(szMessage, szLevel);
    Background_Font2Print( 7,16, szMessage);
}

//------------------------------------------------------------------------------------

uint	Menu_LevelGet(void)
{
	return(uMenuLevel);
}

//------------------------------------------------------------------------------------

void	Menu_LevelIncrement(void)
{
	if (uMenuLevel < uMenuLevelMax)
	{
		uMenuLevel++;
		if (uMenuLevel > uMenuLevelGot)
		{
			uMenuLevelGot = uMenuLevel;
		}
	}
	else
	{
		uMenuState = MENU_GAME_COMPLETE;
	}
}

//------------------------------------------------------------------------------------
