//------------------------------------------------------------------------

// blend
// Rich Heasman May 2002

//------------------------------------------------------------------------

enum
{
	BLEND_OFF,
	BLEND_ALPHA,
	BLEND_FADE_IN,
	BLEND_FADE_OUT
};

typedef struct
{
	uint	uPixelABG0:1;
	uint	uPixelABG1:1;
	uint	uPixelABG2:1;
	uint	uPixelABG3:1;
	uint	uPixelASprite:1;
	uint	uPixelABackdrop:1;
	uint	uBlendMode:2;
	uint	uPixelBBG0:1;
	uint	uPixelBBG1:1;
	uint	uPixelBBG2:1;
	uint	uPixelBBG3:1;
	uint	uPixelBSprite:1;
	uint	uPixelBBackdrop:1;
	uint	uUnused1:2;

	uint	uCoeffA:5;
	uint	uUnused2:3;
	uint	uCoeffB:5;
	uint	uUnused3:3;

	uint	uFadeStep:5;
	uint	uUnused4:11;

	int		nCount;
	int		nRate;
	int		nDeltaA;
	int		nEndA;
	int		nDeltaB;
	int		nEndB;

} BLEND_TYPE;

//------------------------------------------------------------------------

void		Blend_Init(void);
void		Blend_Update(void);
void		Blend_Render(void);
void		Blend_Clear(void);
BLEND_TYPE	*Blend_GetPtr(void);
BOOL		Blend_Done(void);

void		Blend_FEIn(void);
void		Blend_FEOut(void);
void		Blend_TextIn(void);
void		Blend_TextOut(void);

//------------------------------------------------------------------------
