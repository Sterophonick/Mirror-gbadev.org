//------------------------------------------------------------------------------------

// interrupt
// Rich Heasman April 2002

//------------------------------------------------------------------------------------

#include "mygba.h"
#include "interrupt.h"

//------------------------------------------------------------------------------------

u32 IntrTable[14];

static void Interrupt_DefaultHandler(void);

//------------------------------------------------------------------------------------

void	Interrupt_Init(void)
{
    IntrTable[0]    =(u32)&Interrupt_DefaultHandler;  //VBL int 
	IntrTable[1]    =(u32)&Interrupt_DefaultHandler;  //HBL int
	IntrTable[2]    =(u32)&Interrupt_DefaultHandler;  //V Counter match int
	IntrTable[3]    =(u32)&Interrupt_DefaultHandler;  //Timer 0 fire
	IntrTable[4]    =(u32)&Interrupt_DefaultHandler;  //Timer 1 fire
	IntrTable[5]    =(u32)&Interrupt_DefaultHandler;  //Timer 2 fire
	IntrTable[6]    =(u32)&Interrupt_DefaultHandler;  //Timer 3 fire
	IntrTable[7]    =(u32)&Interrupt_DefaultHandler;  //SIO int (do not use when using MBV2)
	IntrTable[8]    =(u32)&Interrupt_DefaultHandler;  //DMA0 int
	IntrTable[9]    =(u32)&Interrupt_DefaultHandler;  //DMA1 int
	IntrTable[10]   =(u32)&Interrupt_DefaultHandler;  //DMA2 int
	IntrTable[11]   =(u32)&Interrupt_DefaultHandler;  //DMA3 int
	IntrTable[12]   =(u32)&Interrupt_DefaultHandler;  //key int
	IntrTable[13]   =(u32)&Interrupt_DefaultHandler;  //cart remove/insert int
}

//------------------------------------------------------------------------------------

void Interrupt_HandlerSet(u8 intno,void* function)
{
    IntrTable[intno]=(u32) function;
}

//------------------------------------------------------------------------------------

void 	Interrupt_Enable(void)
{
    M_INTMST_ENABLE
}

//------------------------------------------------------------------------------------

void 	Interrupt_HWReset(void)
{
	// should be in an interrupt (supervisor mode) apparently, seems to work, it's only dev
	asm ("
		mov r0,#0x8c 
		bx r0 
	");

}

//------------------------------------------------------------------------------------

static void Interrupt_DefaultHandler(void)
{
}

//------------------------------------------------------------------------------------
