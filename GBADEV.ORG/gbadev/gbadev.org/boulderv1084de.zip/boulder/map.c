//----------------------------------------------------------------------------

// map
// Rich Heasman April 2002

//----------------------------------------------------------------------------

#include 	"mygba.h"
#include	"map.h"

#include	"main.h"
#include	"mapdata.h"
#include	"gfx.h"
#include 	"gfxdata1.h"
#include 	"rnd.h"
#include 	"scroll.h"
#include 	"stats.h"
#include 	"vblank.h"
#include 	"man.h"
#include	"background.h"
#include	"palette.h"
#include	"debug.h"
#include	"profile.h"

//----------------------------------------------------------------------------

u16  	uMap[MAP_MAX_X][MAP_MAX_Y];

const u16	Map_Graphic[MAP_TYPES_MAX] = 
{
	GFX_BLANK,			// MAP_BLANK,
	GFX_EARTH,			// MAP_EARTH,
	GFX_BOULDER,		// MAP_BOULDER,
	GFX_DIAMOND_1,		// MAP_DIAMOND,
	GFX_EDGE,			// MAP_EDGE,
	GFX_WALL,			// MAP_WALL,
	GFX_WALL,			// MAP_DWALL,
	GFX_WALL,			// MAP_GWALL,
	GFX_SQUARE_1,		// MAP_SQUARE,
	GFX_BUTTERFLY_1,	// MAP_BUTTERFLY,
	GFX_GREEN_1,		// MAP_GREEN,
	GFX_EDGE,			// MAP_HOME,
	GFX_EDGE,			// MAP_START,
	GFX_MAN,			// MAP_MAN,
	GFX_BOULDER,		// MAP_BOULDER_FALLING,
	GFX_DIAMOND_1,		// MAP_DIAMOND_FALLING,
	GFX_BLANK,			// MAP_BASE_MAX,

	GFX_SQUARE_1,		// MAP_SQUARE_NOT_MOVED,
	GFX_MAN,			// MAP_BUTTERFLY_NOT_MOVED,
	GFX_EDGE,			// MAP_START_1,
	GFX_BOX,			// MAP_START_2,
	GFX_DIAMOND_1,		// MAP_DIAMOND_1,
	GFX_DIAMOND_2,		// MAP_DIAMOND_2,
	GFX_DIAMOND_3,		// MAP_DIAMOND_3,
	GFX_DIAMOND_4,		// MAP_DIAMOND_4,
	GFX_DIAMOND_5,		// MAP_DIAMOND_5,
	GFX_DIAMOND_6,		// MAP_DIAMOND_6,
	GFX_DIAMOND_7,		// MAP_DIAMOND_7,
	GFX_DIAMOND_8,		// MAP_DIAMOND_8,
	GFX_DEATH_1,		// MAP_DEATH_1,
	GFX_DEATH_2,		// MAP_DEATH_2,
	GFX_DEATH_3,		// MAP_DEATH_3,
	GFX_DEATH_4,		// MAP_DEATH_4,
	GFX_DEATH_5,		// MAP_DEATH_5,
	GFX_BFLY_DEATH_1,	// MAP_BFLY_DEATH_1,
	GFX_BFLY_DEATH_1,	// MAP_BFLY_DEATH_2,
	GFX_BFLY_DEATH_2,	// MAP_BFLY_DEATH_3,
	GFX_BFLY_DEATH_3,	// MAP_BFLY_DEATH_4,
	GFX_BFLY_DEATH_4,	// MAP_BFLY_DEATH_5,
	GFX_BUTTERFLY_1,	// MAP_BUTTERFLY_1,	
	GFX_BUTTERFLY_2,	// MAP_BUTTERFLY_2,
	GFX_BUTTERFLY_3,	// MAP_BUTTERFLY_3,
	GFX_BUTTERFLY_4,	// MAP_BUTTERFLY_4,
	GFX_BUTTERFLY_5,	// MAP_BUTTERFLY_5,
	GFX_BUTTERFLY_6,	// MAP_BUTTERFLY_6,
	GFX_BUTTERFLY_7,	// MAP_BUTTERFLY_7,
	GFX_BUTTERFLY_8,	// MAP_BUTTERFLY_8,
	GFX_SQUARE_1,		// MAP_SQUARE_1,
	GFX_SQUARE_2,		// MAP_SQUARE_2,
	GFX_SQUARE_3,		// MAP_SQUARE_3,
	GFX_SQUARE_4,		// MAP_SQUARE_4,
	GFX_GREEN_1,		// MAP_GREEN_1,
	GFX_GREEN_2,		// MAP_GREEN_2,
	GFX_GREEN_3,		// MAP_GREEN_3,
	GFX_GREEN_4,		// MAP_GREEN_4
	GFX_DWALL_1,		// MAP_DWALL_1,
	GFX_DWALL_2,		// MAP_DWALL_2,
	GFX_DWALL_3,		// MAP_DWALL_3,
	GFX_DWALL_4,		// MAP_DWALL_4,
	GFX_WHITE,			// MAP_WHITE,
	GFX_BOULDER,		// MAP_DWALL_BOULDER,
	GFX_DIAMOND_1		// MAP_DWALL_DIAMOND,
};

static 	u16		Map_Tile[MAP_TYPES_MAX*4];
static	u16		Map_RenderMod[MAP_BASE_MAX];

//----------------------------------------------------------------------------

enum
{
	MAP_DIR_RIGHT,
	MAP_DIR_UP,
	MAP_DIR_LEFT,
	MAP_DIR_DOWN,

	MAP_DIR_MAX,
};

const	int		nMapDirDeltaX[MAP_DIR_MAX] = { -1,  0,  1,  0};
const	int		nMapDirDeltaY[MAP_DIR_MAX] = {  0, -1,  0,  1};

#define	MAP_DIRECTION_SHIFT	(8)

//----------------------------------------------------------------------------

static uint			uMapUpdateTimer;
static const uint	uMapUpdateDelay = 10;

static uint 		uMapGfxTimer;
static uint			uMapGfxCount;
static const uint	uMapGfxTimerLen = 1;

static BOOL			boMapFlashWhite;
static BOOL			nMapFlashWhiteCount;

static BOOL			boMapTransition;
static u8			nMapTransitionRnd[MAP_MAX_X][MAP_MAX_Y];
static int			nMapTransitionCount;
static int			nMapTransitionStep;
static const uint 	uMapTransitionLength = 140;

static u16			*pMap_DrawDestStart;

//----------------------------------------------------------------------------

enum
{
	MAP_DWALL_WAITING,	
	MAP_DWALL_GOING,	
	MAP_DWALL_DONE	
};

static uint 		uMapDWallTimeLength;
static uint			uMapDWallStatus;
static uint			uMapDWallTimer;

static uint 		uMapGreenTimeLength;
static uint			uMapGreenTimer;
static BOOL			boMapGreenHasChance;
static BOOL			boMapGreenTrapped;
static uint 		nMapGreenGrowthChance;
static uint 		nMapGreenCount;
static BOOL			boMapGreenTooBig;
static uint			uMapGfxGreenTimer;
static uint			uMapGfxGreenCount;

//----------------------------------------------------------------------------

void	Map_Init(void)
{
	int	nGraphic;
	int	nX;
	int	nY;

	// get indexed tiles from graphics
	for (nGraphic = 0; nGraphic < MAP_TYPES_MAX; nGraphic++)
	{
		Map_Tile[nGraphic * 4 + 0] = Background_TileFromGraphic(Map_Graphic[nGraphic]);
		Map_Tile[nGraphic * 4 + 1] = Background_TileFromGraphic(Map_Graphic[nGraphic] + 1);
		Map_Tile[nGraphic * 4 + 2] = Background_TileFromGraphic(Map_Graphic[nGraphic] + 40);
		Map_Tile[nGraphic * 4 + 3] = Background_TileFromGraphic(Map_Graphic[nGraphic] + 41);
	}

	for (nY = 0; nY < MAP_MAX_Y; nY++)
	{
		for (nX = 0; nX < MAP_MAX_X; nX++)
		{
			nMapTransitionRnd[nX][nY] = Rnd(uMapTransitionLength);
		}
	}

	for (nGraphic = 0; nGraphic < MAP_BASE_MAX; nGraphic++)
	{
		Map_RenderMod[nGraphic] = nGraphic;
	}
}

//----------------------------------------------------------------------------

void	Map_Begin(uint uLevel)
{
	uchar 	*pSrc;
	int	  	nX;
	int	  	nY;
	int	  	nTile;
	int	  	nRun;
	int	  	nLoop;

	// load up map 
	nX=0;
	nY=0;
	pSrc = pMapData[uLevel];

	Stats_DiamondRequiredSet(*pSrc);
	pSrc++;
	Stats_TimerSet(*pSrc);
	pSrc++;
	uMapDWallTimeLength = (*pSrc) * 60;
	uMapGreenTimeLength = uMapDWallTimeLength;
	pSrc++;

	while (nY < MAP_MAX_Y)
	{
		nRun = *pSrc >> 4;
		nTile = *pSrc & 0xf;
		pSrc++;
		for (nLoop=0; nLoop<=nRun; nLoop++)
		{
			uMap[nX][nY] = nTile;
			nX++;
			if (nX >= MAP_MAX_X)
			{
				nX = 0;
				nY++;
			}
		}
	}

	VBlank_TimerSet(&uMapUpdateTimer, 0);

	uMapGfxTimer = 0;
	uMapGfxCount = 0;
	uMapGfxGreenTimer = 0;
	uMapGfxGreenCount = 0;

	boMapFlashWhite = FALSE;
	uMapDWallStatus = MAP_DWALL_WAITING;
	boMapGreenTrapped = FALSE;
	uMapGreenTimer = 0;
	nMapGreenGrowthChance = 1;
	boMapGreenTooBig = FALSE;

	Map_TransitionBegin(1);
}

//----------------------------------------------------------------------------

void	Map_UpdateTimerClear(void)
{
	VBlank_TimerSet(&uMapUpdateTimer, 0);
}	

//----------------------------------------------------------------------------

void	Map_Update(void)
{
	if (VBlank_TimerMature(&uMapUpdateTimer))
	{
		boMapGreenHasChance = FALSE;
		nMapGreenCount = 0;

		nMapGreenGrowthChance = 97;

		if (uMapGreenTimer > (102 * uMapGreenTimeLength / 256))
		{
			nMapGreenGrowthChance = 94;
		}
		if (uMapGreenTimer >= uMapGreenTimeLength)
		{
			nMapGreenGrowthChance = 30;
		}

		__FarProcedure(Map_Process1);
		Profile_Point("Map Process1");
		__FarProcedure(Map_Process2);
		Profile_Point("Map Process2");

		if (!boMapGreenHasChance)
		{
			boMapGreenTrapped = TRUE;
		}
		if (nMapGreenCount > 180)
		{
			boMapGreenTooBig = TRUE;
		}

		VBlank_TimerSet(&uMapUpdateTimer, uMapUpdateDelay);
	}
	else
	{
		Profile_Point("Map Process1");
		Profile_Point("Map Process2");
	}

	uMapGfxTimer++;
	if (uMapGfxTimer >= uMapGfxTimerLen)
	{
		uMapGfxTimer = 0;
		uMapGfxCount++;
		uMapGfxGreenTimer++;
		if (uMapGfxGreenTimer > 5)
		{
			uMapGfxGreenTimer = 0;
			uMapGfxGreenCount++;
		}
	}

	if (boMapFlashWhite)
	{
		if (nMapFlashWhiteCount > 0)
		{
			nMapFlashWhiteCount--;
		}
		else
		{
			boMapFlashWhite = FALSE;
		}
	}

	if (uMapDWallStatus == MAP_DWALL_GOING)
	{
		uMapDWallTimer++;
		if (uMapDWallTimer >= uMapDWallTimeLength)
		uMapDWallStatus = MAP_DWALL_DONE;
	}

	if (uMapGreenTimer < uMapGreenTimeLength)
	{
		uMapGreenTimer++;
	}
}

//----------------------------------------------------------------------------

// need pFuncAddr for __FarProcedure call

void	Map_Process1(u32 *pFuncAddr)
{
	int		nLine;
	int		nCol;
	int		nTile;
	int		nDirection;

	for (nLine = 1; nLine < MAP_MAX_Y-1; nLine++)
	{
		for (nCol = 1; nCol < MAP_MAX_X-1; nCol++)
		{
			nTile = uMap[nCol][nLine] & MAP_TILE_MASK;
			switch (nTile)
			{
				case MAP_BOULDER_FALLING :
				{
					uMap[nCol][nLine] = MAP_BOULDER + (MAP_DIR_DOWN << MAP_DIRECTION_SHIFT);
					break;
				}
				case MAP_DIAMOND_FALLING :
				{
					uMap[nCol][nLine] = MAP_DIAMOND + (MAP_DIR_DOWN << MAP_DIRECTION_SHIFT);
					break;
				}
				case MAP_SQUARE :
				{
					nDirection = (uMap[nCol][nLine] >> MAP_DIRECTION_SHIFT);
					uMap[nCol][nLine] = MAP_SQUARE_NOT_MOVED + (nDirection << MAP_DIRECTION_SHIFT);
					break;
				}
				case MAP_BUTTERFLY :
				{
					nDirection = (uMap[nCol][nLine] >> MAP_DIRECTION_SHIFT);
					uMap[nCol][nLine] = MAP_BUTTERFLY_NOT_MOVED + (nDirection << MAP_DIRECTION_SHIFT);
					break;
				}
				case MAP_BFLY_DEATH_1 :
				{
					uMap[nCol][nLine] = MAP_BFLY_DEATH_2;
					break;
				}
				case MAP_DWALL:
				{
					Map_ProcessDWall( nCol, nLine); 
					break;
				}
			}
		}
	}
}

//----------------------------------------------------------------------------

void	Map_Process2(u32 *pFuncAddr)
{
	int		nLine;
	int		nCol;
	int		nTile;

	for (nLine = 1; nLine < MAP_MAX_Y-1; nLine++)
	{
		for (nCol = 1; nCol < MAP_MAX_X-1; nCol++)
		{
			nTile = uMap[nCol][nLine] & MAP_TILE_MASK;
			switch (nTile)
			{
				case MAP_BOULDER :
				{
					Map_ProcessDrop(nCol, nLine, MAP_BOULDER_FALLING);
					break;
				}
				case MAP_DIAMOND :
				{
					Map_ProcessDrop(nCol, nLine, MAP_DIAMOND_FALLING);
					break;
				}
				case MAP_SQUARE_NOT_MOVED :
				{
					Map_ProcessMove(nCol, nLine, MAP_SQUARE);
					break;
				}
				case MAP_BUTTERFLY_NOT_MOVED :
				{
					Map_ProcessMove(nCol, nLine, MAP_BUTTERFLY);
					break;
				}
				case MAP_DEATH_1 :
				case MAP_DEATH_2 :
				case MAP_DEATH_3 :
				case MAP_DEATH_4 :
				{
					uMap[nCol][nLine] = nTile + 1;
					break;
				}
				case MAP_DEATH_5 :
				{
					uMap[nCol][nLine] = MAP_BLANK;
					break;
				}
				case MAP_BFLY_DEATH_2 :
				case MAP_BFLY_DEATH_3 :
				case MAP_BFLY_DEATH_4 :
				{
					uMap[nCol][nLine] = nTile + 1;
					break;
				}
				case MAP_BFLY_DEATH_5 :
				{
					uMap[nCol][nLine] = MAP_DIAMOND;
					break;
				}
				case MAP_DWALL_DIAMOND :
				{
					uMap[nCol][nLine] = MAP_DIAMOND;
					break;
				}
				case MAP_DWALL_BOULDER :
				{
					uMap[nCol][nLine] = MAP_BOULDER;
					break;
				}
				case MAP_GREEN :
				{
					Map_ProcessGreen(nCol, nLine);
					break;
				}
			}
		}
	}
}

//----------------------------------------------------------------------------

void	Map_ProcessDrop(int nCol, int nLine, int nTarget)
{
	BOOL	boMoved;
	int		nTileDown;
	int		nTileLeft;
	int		nTileLeftDown;
	int		nTileRight;
	int		nTileRightDown;
	int		nDirection;

	boMoved = FALSE;
	nTileDown =  uMap[nCol][nLine+1];
	if (nTileDown == MAP_BLANK)
	{
		uMap[nCol][nLine+1] = nTarget;
		boMoved = TRUE;
	}

	if (nTileDown == MAP_BOULDER		// fails if boulder falling
 	 || nTileDown == MAP_DIAMOND
	 || nTileDown == MAP_WALL)
	{
		if (!boMoved)
		{
			nTileLeft =  uMap[nCol-1][nLine];
			nTileLeftDown =  uMap[nCol-1][nLine+1];
			if (nTileLeft == MAP_BLANK && nTileLeftDown == MAP_BLANK)
			{
				uMap[nCol-1][nLine] = nTarget;
				boMoved = TRUE;
			}
		}
		if (!boMoved)
		{
			nTileRight =  uMap[nCol+1][nLine];
			nTileRightDown =  uMap[nCol+1][nLine+1];
			if (nTileRight == MAP_BLANK && nTileRightDown == MAP_BLANK)
			{
				uMap[nCol+1][nLine] = nTarget;
				boMoved = TRUE;
			}
		}
	}

	if (boMoved)
	{
		uMap[nCol][nLine] = MAP_BLANK;
	}

	if (!boMoved)
	{
		nDirection = (uMap[nCol][nLine] >> MAP_DIRECTION_SHIFT);
		if (nDirection == MAP_DIR_DOWN)
		{
			nTileDown = nTileDown & MAP_TILE_MASK;
			if ((nTileDown == MAP_SQUARE)
			 || (nTileDown == MAP_SQUARE_NOT_MOVED))
			{
				Map_TileExplode_IWRAM(nCol, nLine+1, MAP_DEATH_1);
			}
			if ((nTileDown == MAP_BUTTERFLY)
			 || (nTileDown == MAP_BUTTERFLY_NOT_MOVED))
			{
				Map_TileExplode_IWRAM(nCol, nLine+1, MAP_BFLY_DEATH_1);
			}
			uMap[nCol][nLine] = uMap[nCol][nLine] & MAP_TILE_MASK;
		}
	}
}	

//----------------------------------------------------------------------------

void	Map_ProcessMove(int nCol, int nLine, int nTarget)
{
	int		nNextTile;
	int		nNextLine;
	int		nNextCol;
	int		nDirection;

	nDirection = (uMap[nCol][nLine] >> MAP_DIRECTION_SHIFT);
	if (nTarget == MAP_SQUARE)
	{
		nDirection = (nDirection + MAP_DIR_MAX - 1) % MAP_DIR_MAX;
	}
	else // MAP_BUTTERFLY
	{
		nDirection = (nDirection + 1) % MAP_DIR_MAX;
	}
	nNextCol = nCol + nMapDirDeltaX[nDirection];
	nNextLine = nLine + nMapDirDeltaY[nDirection];
	nNextTile = uMap[nNextCol][nNextLine];
	if (nNextTile == MAP_BLANK)
	{
		uMap[nNextCol][nNextLine] = nTarget + (nDirection << MAP_DIRECTION_SHIFT);
		uMap[nCol][nLine] = MAP_BLANK;
	}
	else
	{
		nDirection = (uMap[nCol][nLine] >> MAP_DIRECTION_SHIFT);
		nNextCol = nCol + nMapDirDeltaX[nDirection];
		nNextLine = nLine + nMapDirDeltaY[nDirection];
		nNextTile = uMap[nNextCol][nNextLine];

		if (nNextTile == MAP_BLANK)
		{
			uMap[nNextCol][nNextLine] = nTarget + (nDirection << MAP_DIRECTION_SHIFT);
			uMap[nCol][nLine] = MAP_BLANK;
		}
		else
		{
			if (nTarget == MAP_SQUARE)
			{
				nDirection = (nDirection + 1) % MAP_DIR_MAX;
			}
			else // MAP_BUTTERFLY
			{
				nDirection = (nDirection + MAP_DIR_MAX - 1) % MAP_DIR_MAX;
			}
			uMap[nCol][nLine] = nTarget + (nDirection << MAP_DIRECTION_SHIFT);
		}
	}
}

//----------------------------------------------------------------------------

void	Map_ProcessDWall(int nCol, int nLine) 
{
	int	nTileUp;
	int	nDirection;

	nTileUp =  uMap[nCol][nLine-1];
	nDirection = nTileUp >> MAP_DIRECTION_SHIFT; 
	nTileUp =  nTileUp & MAP_TILE_MASK;
	if ((nTileUp == MAP_BOULDER || nTileUp == MAP_DIAMOND)
	 && (nDirection == MAP_DIR_DOWN))
	{
		if (uMapDWallStatus == MAP_DWALL_WAITING)
		{
			uMapDWallStatus = MAP_DWALL_GOING;
			uMapDWallTimer = 0;
		}
		uMap[nCol][nLine-1] = MAP_BLANK;

		if (uMapDWallStatus != MAP_DWALL_DONE)
		{
			if (uMap[nCol][nLine+1] == MAP_BLANK)
			{
				if (nTileUp == MAP_BOULDER)
				{
					uMap[nCol][nLine+1] = MAP_DWALL_DIAMOND;
				}
				else	// MAP_DIAMOND
				{
					uMap[nCol][nLine+1] = MAP_DWALL_BOULDER;
				}
			}
		}

	}
}	

//----------------------------------------------------------------------------

void	Map_ProcessGreen(int nCol, int nLine)
{
	int		nDirection;
	int		nTile;
	int		nX;
	int		nY;
	BOOL	boDone;

	boDone = FALSE;
	nMapGreenCount++;

	if (!boDone && boMapGreenTrapped)
	{
		uMap[nCol][nLine] = MAP_DIAMOND;
		boDone = TRUE;
	}
	if (!boDone && boMapGreenTooBig)
	{
		uMap[nCol][nLine] = MAP_BOULDER;
		boDone = TRUE;
	}
	if (!boDone)
	{
		for (nDirection = 0; nDirection < MAP_DIR_MAX; nDirection++ )
		{
			nX = nCol + nMapDirDeltaX[nDirection];
			nY = nLine + nMapDirDeltaY[nDirection];
			nTile = uMap[nX][nY] & MAP_TILE_MASK;
			if (nTile == MAP_SQUARE || nTile == MAP_SQUARE_NOT_MOVED)
			{
				Map_TileExplode_IWRAM(nX, nY, MAP_DEATH_1);
			}
			if (nTile == MAP_BUTTERFLY || nTile == MAP_BUTTERFLY_NOT_MOVED)
			{
				Map_TileExplode_IWRAM(nX, nY, MAP_BFLY_DEATH_1);
			}
			if (nTile == MAP_EARTH || nTile == MAP_BLANK)
			{
				// growth
				if (Rnd_IWRAM(nMapGreenGrowthChance) < 1)
				{
					uMap[nX][nY] = MAP_GREEN;
				}
				boMapGreenHasChance = TRUE;
			}
		}
	}
}	
	
//----------------------------------------------------------------------------

void	Map_TileExplode(int nX, int nY, int nTile)
{
	int	nLine;
	int	nCol;

	for (nLine=0; nLine<3; nLine++)
	{
		for (nCol=0; nCol<3; nCol++)
		{
			if (uMap[nX - 1 + nCol][nY - 1 + nLine] != MAP_EDGE)
			{
				uMap[nX - 1 + nCol][nY - 1 + nLine] = nTile;
			}
		}
	}
}	

//----------------------------------------------------------------------------

void	Map_TileExplode_IWRAM(int nX, int nY, int nTile)
{
	int	nLine;
	int	nCol;

	for (nLine=0; nLine<3; nLine++)
	{
		for (nCol=0; nCol<3; nCol++)
		{
			if (uMap[nX - 1 + nCol][nY - 1 + nLine] != MAP_EDGE)
			{
				uMap[nX - 1 + nCol][nY - 1 + nLine] = nTile;
			}
		}
	}
}	

//----------------------------------------------------------------------------

void	Map_Render(void)
{
	Map_DrawPrepare ();

	__FarProcedure( Map_Draw, Scroll_GetX(), Scroll_GetY() );

	if (boMapTransition)
	{
		nMapTransitionCount += nMapTransitionStep;
		if (nMapTransitionCount < 0)
		{
			nMapTransitionCount = 0;
		}
		if (nMapTransitionCount >= uMapTransitionLength)
		{
			boMapTransition = FALSE;
		}
	}
}

//----------------------------------------------------------------------------

void	Map_DrawPrepare(void)
{
	Map_RenderMod[MAP_START] = MAP_START_1 + (uMapGfxCount % 32) / 16;
	Map_RenderMod[MAP_DIAMOND] = MAP_DIAMOND_1 + (uMapGfxCount % 16) / 2;
	Map_RenderMod[MAP_DIAMOND_FALLING] = MAP_DIAMOND_1 + (uMapGfxCount % 16) / 2;
	Map_RenderMod[MAP_SQUARE] = MAP_SQUARE_1 + (uMapGfxCount % 16) / 4;
	Map_RenderMod[MAP_BUTTERFLY] = MAP_BUTTERFLY_1 + (uMapGfxCount % 16) / 2;
	Map_RenderMod[MAP_GREEN] = MAP_GREEN_1 + (uMapGfxGreenCount % 4);
	Map_RenderMod[MAP_HOME] = MAP_START_1;
	Map_RenderMod[MAP_DWALL] = MAP_DWALL;
	if (Stats_DiamondGotEnough())
	{
		Map_RenderMod[MAP_HOME] += (uMapGfxCount % 32) / 16;
	}
	if (uMapDWallStatus == MAP_DWALL_GOING)
	{
		Map_RenderMod[MAP_DWALL] = MAP_DWALL_1 + (uMapGfxCount % 8) / 2;
	}

	pMap_DrawDestStart = Background_SbbPtr(BACKGROUND_MAP);
}

//----------------------------------------------------------------------------

// need pFuncAddr for __FarProcedure call

void	Map_Draw(u32 *pFuncAddr, int nX, int nY)
{
	int		nLine;
	int		nCol;
	u16		nTileIndex;
	u16		nTile;
	u16		*pDest;
	u16		*pSrc;

	if (boMapFlashWhite)
	{
		nTileIndex = MAP_WHITE;
		nTileIndex *= 4;
		nTile = Map_Tile[nTileIndex];

		pDest = pMap_DrawDestStart;
		for (nLine=0; nLine< GFX_SCREEN_TILE_HEIGHT + 2; nLine++)
		{
			for (nCol=0; nCol< GFX_TILE_MAP_WIDTH; nCol++)
			{
				*pDest++ = nTile;
			}
		}
	}
	else
	{
		for (nLine=0; nLine< (GFX_SCREEN_TILE_HEIGHT/2) + 1; nLine++)
		{
			for (nCol=0; nCol< (GFX_SCREEN_TILE_WIDTH/2) + 1; nCol++)
			{
				if (boMapTransition && nMapTransitionRnd[nCol+nX][nLine+nY] > nMapTransitionCount)
				{
					nTileIndex = MAP_EDGE;
				}
				else
				{
					nTileIndex = uMap[nCol+nX][nLine+nY] & MAP_TILE_MASK;
					if (nTileIndex < MAP_BASE_MAX)
					{
						nTileIndex = Map_RenderMod[nTileIndex];
					}
				}

				pDest = pMap_DrawDestStart + (nLine << 6) + (nCol << 1);
				pSrc = (u16 *) &Map_Tile[nTileIndex * 4];
				*pDest = *pSrc++;
				*(pDest + 1) = *pSrc++;
				*(pDest + GFX_TILE_MAP_WIDTH) = *pSrc++;
				*(pDest + GFX_TILE_MAP_WIDTH + 1) = *pSrc++;
			}
		}
	}
}

//----------------------------------------------------------------------------

void	Map_SetupFE(void)
{
	int		nLine;
	int		nCol;

	for (nLine = 0; nLine < MAP_MAX_Y; nLine++)
	{
		for (nCol = 0; nCol < MAP_MAX_X; nCol++)
		{
			uMap[nCol][nLine] = MAP_EDGE;		
		}
	}
}	

//----------------------------------------------------------------------------

void	Map_FlashWhite(void)
{
	boMapFlashWhite = TRUE;
	nMapFlashWhiteCount = 5;
}	

//----------------------------------------------------------------------------

BOOL	Map_FlashingWhite(void)
{
	return(boMapFlashWhite);
}	

//----------------------------------------------------------------------------

void	Map_TransitionBegin(int nStep)
{
	boMapTransition = TRUE;
	nMapTransitionStep = nStep;
	if (nStep > 0)
	{
		nMapTransitionCount = 0;
	}
	else
	{
		nMapTransitionCount = uMapTransitionLength;
	}
}	

//----------------------------------------------------------------------------
