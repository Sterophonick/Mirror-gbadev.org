//------------------------------------------------------------------------------------

// button
// Rich Heasman April 2002

//------------------------------------------------------------------------------------

#include "mygba.h"	  
#include "button.h"

static	u16		uButtonsLastFrame;
static	u16		uButtonsPreviousFrame;

//------------------------------------------------------------------------------------

void	Button_Init(void)
{
	uButtonsLastFrame = 0;
	uButtonsPreviousFrame = 0;
}

//------------------------------------------------------------------------------------

void	Button_Update(void)
{
	uButtonsPreviousFrame = uButtonsLastFrame;
	uButtonsLastFrame = ~R_CTRLINPUT;
}

//------------------------------------------------------------------------------------

BOOL	Button_Pressed(uint uButton)
{
	BOOL	boPressed;

	boPressed = FALSE;
	if (uButtonsLastFrame & (1 << uButton))
	{
		boPressed = TRUE;
	}

	return (boPressed);
}

//------------------------------------------------------------------------------------

BOOL	Button_PressedDebounced(uint uButton)
{
	BOOL	boPressed;

	boPressed = FALSE;
	if (uButtonsLastFrame & (1 << uButton))
	{
		if (!(uButtonsPreviousFrame & (1 << uButton)))
		{
			boPressed = TRUE;
		}
	}

	return (boPressed);
}

//------------------------------------------------------------------------------------
