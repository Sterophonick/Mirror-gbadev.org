//------------------------------------------------------------------------------------

// profile
// Rich Heasman April 2002

//------------------------------------------------------------------------------------

#include	"mygba.h"
#include	"profile.h"

#include	"gfx.h"
#include	"vblank.h"
#include	"button.h"
#include	"background.h"
#include	"string.h"
#include	"debug.h"

//------------------------------------------------------------------------------------

// This module serves a purpose but it is not a quality profiler
// it is only useful for high level general profiling 
// as points must be set that get called once and only once per frame

//------------------------------------------------------------------------------------

#define	PROFILE_LIST_ENABLED		FALSE
#define	PROFILE_TOTAL_ENABLED		FALSE

#define	PROFILE_MARK_MAX			14
#define	PROFILE_SET_MAX				10			// number of frames maximum is calculated

#define	PROFILE_HBL_PER_FRAME		227			// horizontal blanks per frame
#define	PROFILE_HBL_FOR_VBLANK 		160			// line at which vblank occurs

#define	PROFILE_VALUE_SCALER		(2<<16)
#define	PROFILE_VALUE_SCALED		((100 * PROFILE_VALUE_SCALER)/PROFILE_HBL_PER_FRAME)

typedef struct
{
	char	*szMessage;
	uint	uFrameTime;
} PROFILE_MARK;

static PROFILE_MARK	ProfileMark[PROFILE_MARK_MAX+1];
static uint			ProfilePast[PROFILE_MARK_MAX+2][PROFILE_SET_MAX];

static uint			uProfileMarkCount;
static uint			uProfileSetCount;

//------------------------------------------------------------------------------------

void	Profile_Init(void)
{
	uProfileMarkCount = 0;
	uProfileSetCount = 0;
}

//------------------------------------------------------------------------------------

// renders and restarts profile for next frame

void	Profile_Render(void)
{
	char	szMessage[STRING_LEN_MAX];
	char	szNumber[STRING_LEN_MAX];
	uint	uFrameTimeLast;
	int		nFramePercentage;
	int		nFramePercentageMax;
	int		nFramePercentagePast;
	int		nProfile;
	int		nPast;

	uFrameTimeLast = ProfileMark[0].uFrameTime;
	if (PROFILE_LIST_ENABLED)
	{
		for (nProfile = 1; nProfile < uProfileMarkCount; nProfile++)
		{
			nFramePercentageMax = 0;
			for (nPast = 0; nPast < PROFILE_SET_MAX; nPast++)
			{
				nFramePercentagePast = ProfilePast[nProfile][nPast];
				if (nFramePercentageMax < nFramePercentagePast)
				{
					nFramePercentageMax = nFramePercentagePast;
				}
			}

			nFramePercentage = ProfileMark[nProfile].uFrameTime - uFrameTimeLast;
			nFramePercentage = nFramePercentage * PROFILE_VALUE_SCALED / PROFILE_VALUE_SCALER;
			String_Copy(szMessage, ProfileMark[nProfile].szMessage);
		    Background_Font1Print( 10, 17 - uProfileMarkCount + nProfile, szMessage);
			String_Copy(szMessage, " ");
			String_FromInt(szNumber, nFramePercentage);
			String_Cat(szMessage, szNumber);
			String_Cat(szMessage, "%");
		    Background_Font1Print( 22, 17 - uProfileMarkCount + nProfile, szMessage);
			String_Copy(szMessage, " ");
			String_FromInt(szNumber, nFramePercentageMax);
			String_Cat(szMessage, szNumber);
			String_Cat(szMessage, "%");
		    Background_Font1Print( 26, 17 - uProfileMarkCount + nProfile, szMessage);
			ProfilePast[nProfile][uProfileSetCount] = nFramePercentage;
			uFrameTimeLast = ProfileMark[nProfile].uFrameTime;
		}
	}

	Profile_Mark("Frame Time");
	if (PROFILE_LIST_ENABLED)
	{
		nFramePercentageMax = 0;
		for (nPast = 0; nPast < PROFILE_SET_MAX; nPast++)
		{
			nFramePercentagePast = ProfilePast[uProfileMarkCount-1][nPast];
			if (nFramePercentageMax < nFramePercentagePast)
			{
				nFramePercentageMax = nFramePercentagePast;
			}
		}

		nFramePercentage = ProfileMark[uProfileMarkCount-1].uFrameTime - ProfileMark[uProfileMarkCount-2].uFrameTime;
		nFramePercentage = nFramePercentage * PROFILE_VALUE_SCALED / PROFILE_VALUE_SCALER;
		String_Copy(szMessage, "Profile");
	    Background_Font1Print( 10, 17, szMessage);
		String_Copy(szMessage, " ");
		String_FromInt(szNumber, nFramePercentage);
		String_Cat(szMessage, szNumber);
		String_Cat(szMessage, "%");
	    Background_Font1Print( 22, 17, szMessage);
		String_Copy(szMessage, " ");
		String_FromInt(szNumber, nFramePercentageMax);
		String_Cat(szMessage, szNumber);
		String_Cat(szMessage, "%");
	    Background_Font1Print( 26, 17, szMessage);
		ProfilePast[uProfileMarkCount-1][uProfileSetCount] = nFramePercentage;
	}

	if (PROFILE_TOTAL_ENABLED)
	{
		nFramePercentageMax = 0;
		for (nPast = 0; nPast < PROFILE_SET_MAX; nPast++)
		{
			nFramePercentagePast = ProfilePast[uProfileMarkCount][nPast];
			if (nFramePercentageMax < nFramePercentagePast)
			{
				nFramePercentageMax = nFramePercentagePast;
			}
		}

		nFramePercentage = ProfileMark[uProfileMarkCount-1].uFrameTime - ProfileMark[0].uFrameTime;
		nFramePercentage = nFramePercentage * PROFILE_VALUE_SCALED / PROFILE_VALUE_SCALER;
		String_Copy(szMessage, ProfileMark[uProfileMarkCount-1].szMessage);
	    Background_Font1Print( 10, 19, szMessage);
		String_Copy(szMessage, " ");
		String_FromInt(szNumber, nFramePercentage);
		String_Cat(szMessage, szNumber);
		String_Cat(szMessage, "%");
	    Background_Font1Print( 22, 19, szMessage);
		String_Copy(szMessage, " ");
		String_FromInt(szNumber, nFramePercentageMax);
		String_Cat(szMessage, szNumber);
		String_Cat(szMessage, "%");
	    Background_Font1Print( 26, 19, szMessage);
		ProfilePast[uProfileMarkCount][uProfileSetCount] = nFramePercentage;
	}

	uProfileMarkCount = 0;
	uProfileSetCount++;
	if (uProfileSetCount >= PROFILE_SET_MAX)
	{
		uProfileSetCount = 0;
	}
}

//------------------------------------------------------------------------------------

void	Profile_Point(char *szMessage)
{
	if (uProfileMarkCount < PROFILE_MARK_MAX)
	{
		Profile_Mark(szMessage);
	}
}

//------------------------------------------------------------------------------------

void	Profile_Mark(char *szMessage)
{
	uint 	uFrameTime;
	uint 	uScanLine;

	ProfileMark[uProfileMarkCount].szMessage = szMessage;
	uFrameTime = VBlank_FrameCounterGet() * PROFILE_HBL_PER_FRAME;
	uScanLine = F_VCNT_CURRENT_SCANLINE;
	uFrameTime += uScanLine;
	if (uScanLine >= PROFILE_HBL_FOR_VBLANK)
	{
		uFrameTime -= PROFILE_HBL_PER_FRAME;
	}
	ProfileMark[uProfileMarkCount].uFrameTime = uFrameTime;
	uProfileMarkCount++;
}

//------------------------------------------------------------------------------------

