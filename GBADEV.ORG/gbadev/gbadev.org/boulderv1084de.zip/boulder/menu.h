//------------------------------------------------------------------------------------

// menu
// Rich Heasman April 2002

//------------------------------------------------------------------------------------

void	Menu_Init(void);
void	Menu_Update(void);
void	Menu_Render(void);
void	Menu_RenderLevel(void);
uint	Menu_LevelGet(void);
void	Menu_LevelIncrement(void);

//------------------------------------------------------------------------------------

