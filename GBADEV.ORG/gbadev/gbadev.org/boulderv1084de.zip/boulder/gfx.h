//------------------------------------------------------------------------------------

// graphics
// Rich Heasman April 2002

//------------------------------------------------------------------------------------

#include	"agbtypes.h"

#define	GFX_SCREEN_PIXEL_WIDTH		240
#define	GFX_SCREEN_PIXEL_HEIGHT		160
#define	GFX_SCREEN_TILE_WIDTH		(GFX_SCREEN_PIXEL_WIDTH/8)
#define	GFX_SCREEN_TILE_HEIGHT		(GFX_SCREEN_PIXEL_HEIGHT/8)
#define	GFX_TILE_MAP_WIDTH			32

//------------------------------------------------------------------------------------

void		Gfx_Init(void);
void		Gfx_Update(void);

//------------------------------------------------------------------------------------
