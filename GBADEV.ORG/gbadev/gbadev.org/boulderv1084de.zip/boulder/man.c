//----------------------------------------------------------------------------

// man
// Rich Heasman April 2002

//----------------------------------------------------------------------------

#include	"agbtypes.h"
#include	"man.h"

#include	"gfx.h"
#include 	"gfxdata1.h"
#include 	"rnd.h"
#include 	"button.h"
#include 	"scroll.h"
#include 	"map.h"
#include 	"vblank.h"
#include 	"stats.h"
#include 	"debug.h"
#include	"background.h"
#include	"main.h"

//----------------------------------------------------------------------------

// man types
enum
{
	MAN_NORMAL,
	MAN_BLINK1,
	MAN_BLINK2,
	MAN_TAP1,
	MAN_TAP2,	
	MAN_LEFT1,	
	MAN_LEFT2,	
	MAN_LEFT3,	
	MAN_LEFT4,	
	MAN_RIGHT1,
	MAN_RIGHT2,
	MAN_RIGHT3,
	MAN_RIGHT4,
	MAN_BIRTH_1,
	MAN_BIRTH_2,
	MAN_BIRTH_3,

	MAN_TYPES_MAX
};

// man move types
enum
{
	MAN_CANNOT_MOVE,
	MAN_MOVE,
	MAN_PUSH_BOULDER
};

#define	MAN_WALK_ANIMS		4

//----------------------------------------------------------------------------

static const u16	Man_Graphic[MAN_TYPES_MAX] = {
	GFX_MAN, 
	GFX_MAN_BLINK1, 
	GFX_MAN_BLINK2, 
	GFX_MAN_TAP1, 
	GFX_MAN_TAP2,
	GFX_MAN_LEFT1, 
	GFX_MAN_LEFT2, 
	GFX_MAN_LEFT3, 
	GFX_MAN_LEFT4,	
	GFX_MAN_RIGHT1, 
	GFX_MAN_RIGHT2, 
	GFX_MAN_RIGHT3, 
	GFX_MAN_RIGHT4,
	GFX_DEATH_1,
	GFX_DEATH_2,
	GFX_DEATH_3,
};

static u16			Man_Tile[MAP_TYPES_MAX*4];

//----------------------------------------------------------------------------

static int			nManX;
static int			nManY;
static BOOL			boManHome;
static BOOL			boManAlive;
static BOOL			boManGrab;
static BOOL			boManStarted;
static BOOL			boManBorn;
static uint			uManMoveType;

static uint			uManGfxCount;
static int			nManRequestX;
static int			nManRequestY;
static int			nManRequestPrevX;
static int			nManRequestPrevY;
static int			nManLastDirection;
static int			nManSpecial;

static uint			uManControlTimer;
static const uint	uManControlDelay = 10;
static uint			uManBornTimer;
static const uint	uManBornDelay = 216;
static const uint	uManBirthDelay = 8;

//----------------------------------------------------------------------------

void 	Man_Init(void)
{
	int	nGraphic;

	// get indexed tiles from graphics
	for (nGraphic = 0; nGraphic < MAN_TYPES_MAX; nGraphic++)
	{
		Man_Tile[nGraphic * 4 + 0] = Background_TileFromGraphic(Man_Graphic[nGraphic]);
		Man_Tile[nGraphic * 4 + 1] = Background_TileFromGraphic(Man_Graphic[nGraphic] + 1);
		Man_Tile[nGraphic * 4 + 2] = Background_TileFromGraphic(Man_Graphic[nGraphic] + 40);
		Man_Tile[nGraphic * 4 + 3] = Background_TileFromGraphic(Man_Graphic[nGraphic] + 41);
	}
}

//----------------------------------------------------------------------------

void 	Man_Begin(void)
{
	int	nLine;
	int	nCol;

	for (nLine=0; nLine < MAP_MAX_Y; nLine++)
	{
		for (nCol=0; nCol < MAP_MAX_X; nCol++)
		{
			if (uMap[nCol][nLine] == MAP_START)
			{
				nManX = nCol; 
				nManY = nLine;
			}
		}
	}

	boManHome = FALSE;
	boManAlive = TRUE;
	boManStarted = FALSE;
	boManBorn = FALSE;

	uManGfxCount = 0;
	nManRequestX = 0;
	nManRequestY = 0;
	nManLastDirection = MAN_LEFT1;
	nManSpecial = MAN_NORMAL;

   	VBlank_TimerSet(&uManControlTimer, 0);
   	VBlank_TimerSet(&uManBornTimer, uManBornDelay);
}

//----------------------------------------------------------------------------

void 	Man_Render(void)
{
	int		nTileIndex;						  
	int		nWalkCount;
	
	nTileIndex = MAN_NORMAL;

	if (boManStarted && boManAlive)
	{
		if (nManRequestX == nManRequestPrevX && nManRequestY == nManRequestPrevY)
		{
			uManGfxCount++;
		}
		else
		{
			nManSpecial = MAN_NORMAL;
			uManGfxCount = 0;
		}

		if (nManRequestX > 0) 	nTileIndex = MAN_RIGHT1;
		if (nManRequestX < 0) 	nTileIndex = MAN_LEFT1;
		if (nManRequestY > 0)	nTileIndex = nManLastDirection;
		if (nManRequestY < 0)	nTileIndex = nManLastDirection;

		if (nTileIndex != MAN_NORMAL)
		{
			nManLastDirection = nTileIndex;
			nWalkCount = (uManGfxCount % (MAN_WALK_ANIMS * 2))/2;

			// cycle the walk anim
			if (nWalkCount >= MAN_WALK_ANIMS) 
				nTileIndex += MAN_WALK_ANIMS*2 - 1 - nWalkCount;
			else
				nTileIndex += nWalkCount;
		}
		else // man not moving
		{
			if (nManSpecial == MAN_NORMAL)
			{
				uManGfxCount = 0;
				if (Rnd(100)<1)		nManSpecial = MAN_TAP1;
				if (Rnd(100)<1)		nManSpecial = MAN_BLINK1;
			}
			if (nManSpecial == MAN_BLINK1)
			{
				nTileIndex = MAN_BLINK1 + (uManGfxCount % 4) / 2;
				if ((uManGfxCount % 4) == 3)
				{
					nManSpecial = MAN_NORMAL;
				}
			}

			if (nManSpecial == MAN_TAP1)
			{
				nTileIndex = MAN_TAP1 + (uManGfxCount % 16) / 8;
				if (Rnd(100)<2) 
				{
					nManSpecial = MAN_NORMAL;
				}
			}
		}

		nManRequestPrevX = nManRequestX;
		nManRequestPrevY = nManRequestY;
	}

	if (boManBorn && boManAlive && !Map_FlashingWhite())
	{
		if (nManSpecial >= MAN_BIRTH_1 && nManSpecial <= MAN_BIRTH_3)
		{
			nTileIndex = nManSpecial;
		}

		Man_TileDraw( nManX - Scroll_GetX(), nManY - Scroll_GetY(), nTileIndex);
	}
}

//----------------------------------------------------------------------------

void 	Man_Update1(void)
{
	int		nDX;
	int		nDY;
	int		nTileLeft;
	int		nTileRight;
	int		nTileUp;
	int		nTileDown;

	nDX = 0;
	nDY = 0;

	if (boManStarted && boManAlive)
	{
		if (Button_Pressed(BUTTON_UP)) 		nDY = -1;
		if (Button_Pressed(BUTTON_DOWN)) 	nDY = 1;
		if (Button_Pressed(BUTTON_LEFT)) 	nDX = -1;
		if (Button_Pressed(BUTTON_RIGHT))	nDX = 1;

		// don't allow diagonals
		if (nDY != 0)	nDX = 0; 

		if (VBlank_TimerMature(&uManControlTimer))
		{
			nManRequestX = nDX;
			nManRequestY = nDY;

			// check for death by square or butterfly
			nTileLeft = uMap[nManX - 1][nManY] & MAP_TILE_MASK;
			nTileRight = uMap[nManX + 1][nManY] & MAP_TILE_MASK;
			nTileUp = uMap[nManX][nManY - 1] & MAP_TILE_MASK;
			nTileDown = uMap[nManX][nManY + 1] & MAP_TILE_MASK;
			if ((nTileLeft == MAP_SQUARE)
			 || (nTileRight == MAP_SQUARE)
			 || (nTileUp == MAP_SQUARE)
			 || (nTileDown == MAP_SQUARE))
			{
				Map_TileExplode( nManX, nManY, MAP_DEATH_1);
				boManAlive = FALSE;
			}
			if ((nTileLeft == MAP_BUTTERFLY)
			 || (nTileRight == MAP_BUTTERFLY)
			 || (nTileUp == MAP_BUTTERFLY)
			 || (nTileDown == MAP_BUTTERFLY))
			{
				Map_TileExplode( nManX, nManY, MAP_BFLY_DEATH_1);
				boManAlive = FALSE;
			}
		}
	}
}

//----------------------------------------------------------------------------

void 	Man_Update2(void)
{
	int		nTileAbove;

	if (boManStarted && boManAlive)
	{
		if (VBlank_TimerMature(&uManControlTimer))
		{
			// check if caught in an explosion
			if (uMap[nManX][nManY] != MAP_MAN)
			{
				boManAlive = FALSE;
			}

			// move him
			if ((boManAlive)
			 && (nManRequestX != 0 || nManRequestY != 0))
			{
				boManGrab = FALSE;
				if (Button_Pressed(BUTTON_A))
				{
					boManGrab = TRUE;
				}

				uManMoveType = Man_CanMove(nManRequestX, nManRequestY);	
				if (uManMoveType != MAN_CANNOT_MOVE)
				{
					Man_Move(nManRequestX, nManRequestY);
				}
			}

			// check for death by getting hit on the head
			nTileAbove = uMap[nManX][nManY-1];
			if (nTileAbove == MAP_BOULDER_FALLING 
			 || nTileAbove == MAP_DIAMOND_FALLING)
			{
				Map_TileExplode( nManX, nManY, MAP_DEATH_1);
				boManAlive = FALSE;
			}

	       	VBlank_TimerSet(&uManControlTimer, uManControlDelay);
		}
	}

	if (boManBorn && !boManStarted)
	{
		if (VBlank_TimerMature(&uManBornTimer))
		{
			if (nManSpecial >= MAN_BIRTH_3)
			{
				Stats_TimerStart();
		       	VBlank_TimerSet(&uManControlTimer, 0);
				Map_UpdateTimerClear();						// sync map and man timers
				boManStarted = TRUE;
				nManSpecial = MAN_NORMAL;
				uMap[nManX][nManY] = MAP_MAN;
			}
			else
			{
		       	VBlank_TimerSet(&uManBornTimer, uManBirthDelay);
				nManSpecial++;
			}
		}
	}

	if (!boManBorn)
	{
		if (VBlank_TimerMature(&uManBornTimer))
		{
	       	VBlank_TimerSet(&uManBornTimer, uManBirthDelay);
			nManSpecial = MAN_BIRTH_1;
			boManBorn = TRUE;
		}
	}
}

//----------------------------------------------------------------------------

void 	Man_TileDraw(int nX, int nY, int nTileIndex)
{
	u16		*pDestStart;
	u16		*pDest;

	nX *= 2;
	nY *= 2;

	if ((nX >= 0 && nX < GFX_TILE_MAP_WIDTH)
	 && (nY >= 0 && nY < (GFX_SCREEN_TILE_HEIGHT + 2)))
	{
		pDestStart = Background_SbbPtr(BACKGROUND_MAP);
		pDest = pDestStart + ((nY&31)<<5) + ((nX&31));
		nTileIndex *= 4;

		*pDest = Man_Tile[nTileIndex];
		*(pDest + 1) = Man_Tile[nTileIndex + 1];
		*(pDest + GFX_TILE_MAP_WIDTH) = Man_Tile[nTileIndex + 2];
		*(pDest + GFX_TILE_MAP_WIDTH + 1) = Man_Tile[nTileIndex + 3];
	}
}

//----------------------------------------------------------------------------

uint  	Man_CanMove(int nDX, int nDY)
{
	uint 	uMoveType;
	int		nManNewX;
	int		nManNewY;
	int		nManTarget;
	int		nBoulderTarget;

	nManNewX = nManX + nDX;
	nManNewY = nManY + nDY;
	nManTarget = uMap[nManNewX][nManNewY];

	uMoveType = MAN_CANNOT_MOVE;

	if (nManTarget == MAP_BLANK
	 || nManTarget == MAP_EARTH
	 || nManTarget == MAP_DIAMOND)
	{
		uMoveType = MAN_MOVE;
	}

	if (nManTarget == MAP_HOME)
//	 &&	Stats_DiamondGotEnough())
	{
		uMoveType = MAN_MOVE;
	}

	if (nManTarget == MAP_BOULDER)
	{
		nBoulderTarget = uMap[nManNewX+nDX][nManNewY+nDY];
		if (nDY == 0 && nBoulderTarget == MAP_BLANK)
		{
			if (Rnd(100)<23)
			{
				uMoveType = MAN_PUSH_BOULDER;
			}
		}
	}

	return(uMoveType);
}

//----------------------------------------------------------------------------

void 	Man_Move(int nDX, int nDY)
{
	int		nManTarget;
	int		nNewX;
	int		nNewY;

	if (uManMoveType != MAN_CANNOT_MOVE)
	{
		nNewX = nManX + nDX;
		nNewY = nManY + nDY;
		nManTarget = uMap[nNewX][nNewY];
		if (!boManGrab)
		{
			uMap[nManX][nManY] = MAP_BLANK;
			nManX = nNewX;
			nManY = nNewY;
			uMap[nManX][nManY] = MAP_MAN;
		}
		else
		{
			uMap[nNewX][nNewY] = MAP_BLANK;
		}

		if (uManMoveType == MAN_PUSH_BOULDER)
		{
			uMap[nNewX + nDX][nNewY + nDY] = MAP_BOULDER;
		}

		if (nManTarget == MAP_DIAMOND)
		{
			Stats_DiamondGot();
		}

		if (nManTarget == MAP_HOME)
		{
			boManHome = TRUE;
		}

	}
}

//----------------------------------------------------------------------------

int		Man_GetX(void)
{
	return(nManX);
}

//----------------------------------------------------------------------------

int		Man_GetY(void)
{
	return(nManY);
}

//----------------------------------------------------------------------------

BOOL	Man_Home(void)
{
	return(boManHome);
}

//----------------------------------------------------------------------------

void	Man_Remove(void)
{
	boManAlive = FALSE;
}

//----------------------------------------------------------------------------

BOOL	Man_Alive(void)
{
	return(boManAlive);
}	

//----------------------------------------------------------------------------

BOOL	Man_Born(void)
{
	return(boManBorn);
}	

//----------------------------------------------------------------------------
