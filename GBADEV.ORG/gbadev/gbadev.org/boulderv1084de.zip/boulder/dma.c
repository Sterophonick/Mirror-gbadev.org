//------------------------------------------------------------------------

// dma
// Rich Heasman May 2002

//------------------------------------------------------------------------

#include	"mygba.h"
#include	"dma.h"

//-----------------------------------------------------------------------

void	Dma_Set(uint uChannel, DMA_TYPE *pDma)
{
	u32	*pDest;
	u32 *pSrc;

	pDma->uRepeat = 0;			// disable these options for now
	pDma->uInterupt = 0;
	pDma->uEnable = 1;

	pSrc = (u32 *) pDma;
	pDest = (u32 *) (MEM_DMABASE + ( uChannel * 0x0C));
	*pDest++ = *pSrc++;
	*pDest++ = *pSrc++;
	*pDest++ = *pSrc++;
}	

//-----------------------------------------------------------------------
