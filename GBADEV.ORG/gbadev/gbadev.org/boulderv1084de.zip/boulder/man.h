//----------------------------------------------------------------------------

// man
// Rich Heasman April 2002

//----------------------------------------------------------------------------

#include	"agbtypes.h"

void	Man_Init(void);
void	Man_Begin(void);

void	Man_Render(void);
void	Man_Update1(void);
void	Man_Update2(void);
void	Man_TileDraw(int nX, int nY, int nTileIndex);

uint	Man_CanMove(int nDX, int nDY);
void	Man_Move(int nDX, int nDY);

int		Man_GetX(void);
int		Man_GetY(void);

BOOL	Man_Home(void);
void	Man_Remove(void);
BOOL	Man_Alive(void);
BOOL	Man_Born(void);

//----------------------------------------------------------------------------
