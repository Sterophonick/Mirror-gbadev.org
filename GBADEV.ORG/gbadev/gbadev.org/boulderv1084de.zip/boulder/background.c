//------------------------------------------------------------------------------------

// background
// Rich Heasman May 2002

//------------------------------------------------------------------------------------

#include 	"mygba.h"  
#include 	"background.h"

#include 	"gfx.h"
#include 	"gfxdata1.h"
#include 	"gfxdata2.h"
#include 	"vblank.h"
#include 	"profile.h"
#include 	"palette.h"
#include	"string.h"
#include	"mem.h"
#include	"main.h"
#include	"dma.h"

//------------------------------------------------------------------------------------

static BACKGROUND_TYPE	Background_Info[BACKGROUND_MAX];

static const uint 	uBackground_MapLength[4] = { 1024, 2048, 2048, 4096 };

//------------------------------------------------------------------------------------

void	Background_Init(void)
{
	Mem_Set((u32 *) MEM_BG_MODE0_PTR, 0x00, MEM_BG_SIZE);	// clear background memory
									   
	M_DISCNT_BGMODE_SET(0)							// set background display mode

	// set up vram
	Background_LoadVram();

	// text layer

	Background_Info[BACKGROUND_TEXT].uPriority = 0;		// on top
	Background_Info[BACKGROUND_TEXT].uCbb = 0;
	Background_Info[BACKGROUND_TEXT].uSbbBase = 10;
	Background_Info[BACKGROUND_TEXT].uColmode = 1;
	Background_Info[BACKGROUND_TEXT].uMapsize = C_BGXCNT_SCRSIZE_256X256;
	Background_Setup(BACKGROUND_TEXT);
	Background_FlipBufferWrite(BACKGROUND_TEXT);			// get text buffers out of sync

	// logo

	Background_Info[BACKGROUND_DISPLAY].uPriority = 1;		// middle
	Background_Info[BACKGROUND_DISPLAY].uCbb = 2;
	Background_Info[BACKGROUND_DISPLAY].uSbbBase = 12;
	Background_Info[BACKGROUND_DISPLAY].uColmode = 1;
	Background_Info[BACKGROUND_DISPLAY].uMapsize = C_BGXCNT_SCRSIZE_256X256;
	Background_Setup(BACKGROUND_DISPLAY);

	// main tile layer

	Background_Info[BACKGROUND_MAP].uPriority = 3;		// bottom
	Background_Info[BACKGROUND_MAP].uCbb = 0;
	Background_Info[BACKGROUND_MAP].uSbbBase = 14;
	Background_Info[BACKGROUND_MAP].uColmode = 1;
	Background_Info[BACKGROUND_MAP].uMapsize = C_BGXCNT_SCRSIZE_256X256;
	Background_Setup(BACKGROUND_MAP);
}

//------------------------------------------------------------------------------------

void 	Background_Setup(uint uBackground)
{
	BACKGROUND_TYPE	*pBg;

	pBg = &Background_Info[uBackground];

	pBg->uActive = 1;
	pBg->uMapLength = uBackground_MapLength[pBg->uMapsize];

	pBg->uBufferView = 0;
	pBg->uBufferWrite = 0;
	pBg->uSbb =	pBg->uSbbBase;
	pBg->boFlipView = FALSE;

    M_DISCNT_BGX_SET(uBackground, pBg->uActive)
    M_BGXCNT_PRIO_SET(uBackground, pBg->uPriority)
    M_BGXCNT_CHRBB_SET(uBackground, pBg->uCbb)
    M_BGXCNT_SCRBB_SET(uBackground, pBg->uSbbBase)
    M_BGXCNT_COLMODE_SET(uBackground, pBg->uColmode)
    M_BGXCNT_SCRSIZE_SET(uBackground, pBg->uMapsize)
}

//------------------------------------------------------------------------------------ 

void	Background_Update(uint uBackground)
{
	BACKGROUND_TYPE	*pBg;
	uint		uSbb;

	pBg = &Background_Info[uBackground];

	R_BGXSCRLX(uBackground) = pBg->nScrollX;
	R_BGXSCRLY(uBackground) = pBg->nScrollY;

	if (pBg->boFlipView)
	{
	    pBg->uBufferView = 1 - pBg->uBufferView;
		uSbb = pBg->uSbbBase + (pBg->uMapLength>>10) * pBg->uBufferView;
	    M_BGXCNT_SCRBB_SET(uBackground, uSbb);
		pBg->boFlipView = FALSE;
	}
}

//------------------------------------------------------------------------------------ 

void 	Background_FlipBufferWrite(uint uBackground)
{
	BACKGROUND_TYPE	*pBg;

	pBg = &Background_Info[uBackground];

    pBg->uBufferWrite = 1 - pBg->uBufferWrite;
	pBg->uSbb = pBg->uSbbBase + (pBg->uMapLength>>10) * pBg->uBufferWrite;
}

//------------------------------------------------------------------------------------ 

void 	Background_FlipBufferView(uint uBackground)
{
	BACKGROUND_TYPE	*pBg;

	pBg = &Background_Info[uBackground];
	pBg->boFlipView = TRUE;
}

//------------------------------------------------------------------------------------ 

void	Background_SetAll(uint uBackground, u16 nTileIndex)
{
	BACKGROUND_TYPE	*pBg;
	uint 		uCount;
	u16			*pDest;
	u16			nTile;

	pBg = &Background_Info[uBackground];

	nTile = Background_TileFromGraphic(nTileIndex);
	pDest = MEM_SCR_BB_PTR(pBg->uSbb);
	uCount = (pBg->uMapLength);
	while (uCount > 0)
	{
		*pDest++ = (u16) nTile;
		uCount--;
	}
}

//------------------------------------------------------------------------------------ 

void 	Background_ScrollSet(uint uBackground, int nX, int nY)
{
	BACKGROUND_TYPE	*pBg;
	
	pBg = &Background_Info[uBackground];
	pBg->nScrollX = nX;
	pBg->nScrollY = nY;
}
	
//------------------------------------------------------------------------------------ 

void		Background_SetScreen(uint uBackground, u16 nTileIndex)
{
	BACKGROUND_TYPE	*pBg;
	uint 		uCount;
	u32			*pDest;
	u16			nTile;
	u32			nTileComposite;

	pBg = &Background_Info[uBackground];

	nTile = Background_TileFromGraphic(nTileIndex);
	pDest = (u32 *) MEM_SCR_BB_PTR(pBg->uSbb);
	uCount = ((GFX_TILE_MAP_WIDTH * GFX_SCREEN_TILE_HEIGHT) / 2);
	nTileComposite = nTile + (nTile << 16);
	while (uCount > 0)
	{
		*pDest++ = nTileComposite;
		uCount--;
	}
}

//------------------------------------------------------------------------------------ 

void		Background_ScreenClear(uint uBackground)		
{						    
	BACKGROUND_TYPE	*pBg;
	uint 		uCount;
	u32			nTileComposite;
	DMA_TYPE	Dma;

	pBg = &Background_Info[uBackground];
	uCount = (GFX_TILE_MAP_WIDTH * GFX_SCREEN_TILE_HEIGHT) / 2;
	nTileComposite = 0 + (0 << 16);		// clear 2 entries each write

	Dma.uSrc = (uint) &nTileComposite;
	Dma.uDest = (uint) MEM_SCR_BB_PTR(pBg->uSbb);
	Dma.uCount = uCount;
	Dma.uDestInc = DMA_INC;
	Dma.uSrcInc = DMA_LEAVE;
	Dma.uSize = DMA_32_BIT;
	Dma.uMode = DMA_NOW;

	Dma_Set(3,&Dma);

// non-dma version (if done non-dma then this function should be in IWRAM)
//	while (uCount > 0)
//	{
//		*pDest++ = nTileComposite;
//		uCount--;
//	}
}	

//------------------------------------------------------------------------------------ 

u16		*Background_SbbPtr(uint uBackground)
{
	BACKGROUND_TYPE	*pBg;
	u16	   		*pDest;
	
	pBg = &Background_Info[uBackground];
	pDest = MEM_SCR_BB_PTR(pBg->uSbb);

	return(pDest);
}

//------------------------------------------------------------------------------------ 

void	Background_LoadVram(void)
{
    Mem_Copy((u32 *) MEM_PAL_BG_PTR, (u32 *) gfxdata1_Palette, GFXDATA1_PALETTE_SIZE);
	Palette_Copy( COLOUR_TRANSPARENT, COLOUR_BLACK);
    Mem_Copy((u32 *) MEM_CHR_BB_PTR(0), (u32 *) gfxdata1_Tiles, GFXDATA1_TILE_SIZE);
    Mem_Copy((u32 *) MEM_CHR_BB_PTR(2), (u32 *) gfxdata2_Tiles, GFXDATA2_TILE_SIZE);
}

//------------------------------------------------------------------------------------ 

u16	 	Background_TileFromGraphic(u16 nGraphic)
{
	return(gfxdata1_Map[nGraphic]);
}

//------------------------------------------------------------------------------------ 

void	Background_Font1Print(int nXCo, int nYCo, char *szMessage)
{
	BACKGROUND_TYPE	*pBg;
	u8				*pSrc;
	u16				*pDest;
	u16				uGfxIndex;

	pBg = &Background_Info[BACKGROUND_TEXT];

	pDest = MEM_SCR_BB_PTR(pBg->uSbb) + (nYCo<<5) + nXCo;
	pSrc = szMessage;
	while (*pSrc != STRING_TERMINATOR)
	{
		uGfxIndex = (*pSrc) - GFX_FONT_1_START_CHAR + GFX_FONT_1;
		*pDest++ = gfxdata1_Map[uGfxIndex];
		pSrc++;
	}
}

//------------------------------------------------------------------------------------ 

void	Background_Font2Print(int nXCo, int nYCo, char *szMessage)
{
	BACKGROUND_TYPE	*pBg;
	u8				*pSrc;
	u16				*pDestText;
	u16				uGfxIndex;

	pBg = &Background_Info[BACKGROUND_TEXT];
	pDestText = MEM_SCR_BB_PTR(pBg->uSbb) + (nYCo<<5) + nXCo;
	pSrc = szMessage;

	while (*pSrc != STRING_TERMINATOR)
	{
		uGfxIndex = ((*pSrc - GFX_FONT_2_START_CHAR) * 2) + GFX_FONT_2;
		*pDestText++ = gfxdata1_Map[uGfxIndex];
		*pDestText++ = gfxdata1_Map[uGfxIndex+1];
		pSrc++;
	}
}

//------------------------------------------------------------------------------------ 

void		Background_SetupFE(void)
{
	BACKGROUND_TYPE	*pBg;
	int				nLine;
	int				nCol;
	u16				*pDestStart;
	u16				*pDest;
	u16				*pSrc;

	Background_ScreenClear(BACKGROUND_DISPLAY);

	pBg = &Background_Info[BACKGROUND_DISPLAY];
	pDestStart = MEM_SCR_BB_PTR(pBg->uSbb);

	pSrc = (u16 *) &gfxdata2_Map[GFXDATA2_MAP_TILE_WIDTH];

	for (nLine = 0; nLine < GFXDATA2_MAP_TILE_HEIGHT; nLine++)
	{
		pDest = pDestStart + (nLine + 3) * GFX_TILE_MAP_WIDTH + (GFX_SCREEN_TILE_WIDTH - GFXDATA2_MAP_TILE_WIDTH)/2;
		for (nCol = 0; nCol < GFXDATA2_MAP_TILE_WIDTH; nCol++)
		{
			*pDest++ = *pSrc++;
		}
	}
}	

//------------------------------------------------------------------------------------ 
