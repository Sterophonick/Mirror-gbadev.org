
--------------------
Boulder Dash Advance
--------------------

v1.0 15 May 2002 - First Version

A conversion of the c64 game Boulder Dash
by Rich Heasman (richardheasman@hotmail.com)

This game is freeware and is an unoffical conversion which is not endorsed by First Star Software

---------------------------

What? Collect enough diamonds, get home
How? Dpad - Move; A + Dpad - grab; Start - Pause, Select + Start - dev menu

---------------------------

Thanks to:

First Star Software     : for Boulder Dash (by Peter Liepa with Chris Grey)
Tubooboo                : for HAM (v1.40)
Jeff Frohwein           : for MultiBoot, crt0, lnkscript, FAQ
Gollum                  : for BoycottAdvance
Tom Happ                : for Cowbite spec
Markus                  : for Gfx2Gba
gbadev.org              : for various info
VICE team               : for VICE c64 emulation
cia.c64.org             : for c64 bins

---------------------------




