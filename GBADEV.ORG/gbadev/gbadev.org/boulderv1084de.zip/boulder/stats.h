//------------------------------------------------------------------------

// stats
// Rich Heasman April 2002

//------------------------------------------------------------------------

void	Stats_Begin(void);
void	Stats_Update(void);
void	Stats_Render(void);

void	Stats_DiamondGot(void);
void	Stats_DiamondRequiredSet(uint uDiamonds);
BOOL	Stats_DiamondGotEnough(void);

void	Stats_TimerSet(uint uTimer);
BOOL	Stats_TimerMature(void);
void	Stats_TimerStart(void);

//-----------------------------------------------------------------------

