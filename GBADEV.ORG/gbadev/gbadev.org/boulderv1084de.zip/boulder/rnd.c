//------------------------------------------------------------------------

// rnd
// Rich Heasman April 2002

//------------------------------------------------------------------------

#include	"mygba.h"
#include 	"rnd.h"

//------------------------------------------------------------------------

#define	RND_MAX_SEED	2097152

static	uint	uRndSeed;

//------------------------------------------------------------------------

void	Rnd_Init(void)
{
	uRndSeed = 0;
}

//------------------------------------------------------------------------

void	Rnd_SeedSet(uint uSeed)
{
	uRndSeed=uSeed;
}

//------------------------------------------------------------------------

uint	Rnd(uint uRange)
{
	uint	uRandomVal;

	uRndSeed = (uRndSeed*1021+1) % RND_MAX_SEED;
	uRandomVal= (uRndSeed*uRange)/RND_MAX_SEED;

	return(uRandomVal);
}

//------------------------------------------------------------------------

uint	Rnd_IWRAM(uint uRange)
{
	uint	uRandomVal;

	uRndSeed = (uRndSeed*1021+1) % RND_MAX_SEED;
	uRandomVal= (uRndSeed*uRange)/RND_MAX_SEED;

	return(uRandomVal);
}

//------------------------------------------------------------------------
