//------------------------------------------------------------------------

// mem
// Rich Heasman May 2002

//------------------------------------------------------------------------

#include	"agbtypes.h"
#include	"mem.h"

#include	"dma.h"

//------------------------------------------------------------------------

// writes dwords (upto 3 bytes over)

//------------------------------------------------------------------------

void	Mem_Copy(u32 *pDest, u32 *pSrc, uint uSize)
{
	DMA_TYPE	Dma;
	uint		uCount;

	uCount = (uSize + 3) / 4;

	Dma.uSrc = (uint) pSrc;
	Dma.uDest = (uint) pDest;
	Dma.uCount = uCount;
	Dma.uDestInc = DMA_INC;
	Dma.uSrcInc = DMA_INC;
	Dma.uSize = DMA_32_BIT;
	Dma.uMode = DMA_NOW;

	Dma_Set(3,&Dma);

// non-dma version
//	while (uCount > 0)
//	{
//		*pDest++ = *pSrc++;
//		uCount--;
//	}

}	

//------------------------------------------------------------------------

void	Mem_Set(u32 *pDest, u8 uValue, uint uSize)
{
	DMA_TYPE	Dma;
	uint 		uCount;
	uint 		uValueCombined;

	uCount = (uSize + 3) / 4;
	uValueCombined = uValue + (uValue << 8) + (uValue << 16) + (uValue << 24);

	Dma.uSrc = (uint) &uValueCombined;
	Dma.uDest = (uint) pDest;
	Dma.uCount = uCount;
	Dma.uDestInc = DMA_INC;
	Dma.uSrcInc = DMA_LEAVE;
	Dma.uSize = DMA_32_BIT;
	Dma.uMode = DMA_NOW;

	Dma_Set(3,&Dma);

// non-dma version
//	while (uCount > 0)
//	{
//		*pDest++ = uValueCombined;
//		uCount--;
//	}

}	

//-----------------------------------------------------------------------
