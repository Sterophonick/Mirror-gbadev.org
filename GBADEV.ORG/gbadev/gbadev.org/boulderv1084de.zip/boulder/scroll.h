//------------------------------------------------------------------------

// scroll
// Rich Heasman April 2002

//------------------------------------------------------------------------

void	Scroll_Init(void);
void	Scroll_Begin(void);
void	Scroll_Update(void);
void	Scroll_Render(void);
int		Scroll_GetX(void);
int		Scroll_GetY(void);
void	Scroll_UpdateFE(void);

//-----------------------------------------------------------------------

