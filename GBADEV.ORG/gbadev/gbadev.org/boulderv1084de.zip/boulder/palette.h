//------------------------------------------------------------------------

// palette
// Rich Heasman May 2002

//------------------------------------------------------------------------

#include	"agbtypes.h"

//-----------------------------------------------------------------------

enum
{
	COLOUR_TRANSPARENT,
	COLOUR_DIAMOND_BLACK,
	COLOUR_HEAD,
	COLOUR_LEGS,
	COLOUR_FEET,
	COLOUR_LETTERS,
	COLOUR_BLACK,

	COLOUR_DGREY = 16,
	COLOUR_BROWN,
	COLOUR_WHITE,
	COLOUR_PURPLE,
	COLOUR_PINK,
	COLOUR_DBROWN,
	COLOUR_LBLUE,
	COLOUR_LGREEN,
	COLOUR_DRED,
	COLOUR_BLUE,
	COLOUR_GREY,
};

//-----------------------------------------------------------------------

void	Palette_Begin(int nLevel);
void	Palette_Copy(int nDest,int nSrc);

//-----------------------------------------------------------------------

