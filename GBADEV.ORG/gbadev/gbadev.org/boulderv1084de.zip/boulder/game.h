//------------------------------------------------------------------------------------

// Game
// Rich Heasman April 2002

//------------------------------------------------------------------------------------

enum
{
	GAME_DORMANT,
	GAME_PAUSE,
	GAME_INGAME_INIT,
	GAME_INGAME,
	GAME_DONE_INIT,
	GAME_DONE_WAIT,
	GAME_EXPIRED_WAIT,
	GAME_DEAD_WAIT,
	GAME_WIPE_INIT,
	GAME_WIPE_WAIT
};

//------------------------------------------------------------------------------------

void	Game_Init(void);
void	Game_Update(void);
void	Game_Render(void);
void	Game_StateSet(uint uState);
uint	Game_StateGet(void);
void	Game_StateSetAfterWipe(uint uState);
void	Game_FromFE(void);

//------------------------------------------------------------------------------------

