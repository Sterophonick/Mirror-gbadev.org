//------------------------------------------------------------------------

// scroll
// Rich Heasman April 2002

//------------------------------------------------------------------------

#include	"mygba.h"
#include	"scroll.h"

#include	"gfx.h"
#include	"map.h"
#include	"man.h"
#include	"background.h"
#include	"debug.h"

//------------------------------------------------------------------------

static int			nScrollPosX;
static int			nScrollPosY;

static BOOL			boScrolling;
static int			nScrollFECount;

static int			nScrollPixelMinX;
static int			nScrollPixelMinY;
static int			nScrollPixelMaxX;
static int			nScrollPixelMaxY;

static const int 	nScrollScreenMidX 	= GFX_SCREEN_PIXEL_WIDTH/2;
static const int 	nScrollScreenMidY 	= GFX_SCREEN_PIXEL_HEIGHT/2;
static const int 	nScrollStartMinX 	= GFX_SCREEN_PIXEL_WIDTH/3;
static const int 	nScrollStartMinY 	= GFX_SCREEN_PIXEL_HEIGHT/3;
static const int 	nScrollStartMaxX 	= 2 * GFX_SCREEN_PIXEL_WIDTH/3;
static const int 	nScrollStartMaxY 	= 2 * GFX_SCREEN_PIXEL_HEIGHT/3;
static const int 	nScrollCentreRate 	= 2;

//------------------------------------------------------------------------

void	Scroll_Init(void)
{
	nScrollPosX = nScrollScreenMidX;
	nScrollPosY = nScrollScreenMidY;
	boScrolling = FALSE;
}	

//------------------------------------------------------------------------

void	Scroll_Begin(void)
{
	int	nLine;
	int	nCol;
	int	nMinX;
	int	nMinY;
	int	nMaxX;
	int	nMaxY;
	int	nTile;

	// find edges
	nMinX = MAP_MAX_X-1;
	nMaxX = 0;
	nMinY = MAP_MAX_Y-1;
	nMaxY = 0;
	for (nLine=0; nLine<MAP_MAX_Y; nLine++)
	{
		for (nCol=0; nCol<MAP_MAX_X; nCol++)
		{
			nTile = uMap[nCol][nLine];
			if (nTile != MAP_EDGE && nTile != MAP_HOME)
			{
				if (nCol < nMinX) nMinX = nCol;
				if (nCol > nMaxX) nMaxX = nCol;
				if (nLine < nMinY) nMinY = nLine;
				if (nLine > nMaxY) nMaxY = nLine;
			}
		}
	} 

	nScrollPixelMinX = (nMinX - 1) * 8 * 2;
	nScrollPixelMaxX = (nMaxX + 2) * 8 * 2;
	nScrollPixelMinY = (nMinY - 1) * 8 * 2;
	nScrollPixelMaxY = (nMaxY + 2) * 8 * 2;
}

//------------------------------------------------------------------------

void	Scroll_Update(void)
{
	int		nManPixelPosX;
	int		nManPixelPosY;
	int		nDeltaX;
	int		nDeltaY;

	nManPixelPosX = Man_GetX() * 2 * 8 + 8 - nScrollPosX;
	nManPixelPosY = Man_GetY() * 2 * 8 + 8 - nScrollPosY;
	nDeltaX = 0;
	nDeltaY = 0;

	if (!boScrolling)
	{
		if ((nManPixelPosX > nScrollStartMaxX + nScrollCentreRate) 
		 && (GFX_SCREEN_PIXEL_WIDTH + nScrollPosX < nScrollPixelMaxX))
		{
			boScrolling = TRUE;
		}

		if ((nManPixelPosX < nScrollStartMinX - nScrollCentreRate)
		 && (nScrollPosX > nScrollPixelMinX))
		{
			boScrolling = TRUE;
		}

		if ((nManPixelPosY > nScrollStartMaxY + nScrollCentreRate) 
		 && (GFX_SCREEN_PIXEL_HEIGHT + nScrollPosY < nScrollPixelMaxY))
		{
			boScrolling = TRUE;
		}

		if ((nManPixelPosY < nScrollStartMinY - nScrollCentreRate) 
		 && (nScrollPosY > nScrollPixelMinY))
		{
			boScrolling = TRUE;
		}
	}

	if (boScrolling)
	{
		if ((nManPixelPosX > nScrollScreenMidX + nScrollCentreRate) 
		 && (GFX_SCREEN_PIXEL_WIDTH + nScrollPosX < nScrollPixelMaxX))
		{
			nDeltaX = nScrollCentreRate;
		}

		if ((nManPixelPosX < nScrollScreenMidX - nScrollCentreRate) 
		 && (nScrollPosX > nScrollPixelMinX))
		{
			nDeltaX = -nScrollCentreRate;
		}

		if ((nManPixelPosY > nScrollScreenMidY + nScrollCentreRate) 
		 && (GFX_SCREEN_PIXEL_HEIGHT + nScrollPosY < nScrollPixelMaxY))
		{
			nDeltaY = nScrollCentreRate;
		}

		if ((nManPixelPosY < nScrollScreenMidY - nScrollCentreRate) 
		 && (nScrollPosY > nScrollPixelMinY))
		{
			nDeltaY = -nScrollCentreRate;
		}
		nScrollPosX += nDeltaX;
		nScrollPosY += nDeltaY;

		if (nDeltaX == 0 && nDeltaY == 0)
		{
			boScrolling = FALSE;
		}
	}
}

//------------------------------------------------------------------------

void	Scroll_Render(void)
{
	Background_ScrollSet(BACKGROUND_MAP, nScrollPosX % 16, nScrollPosY % 16);
}

//------------------------------------------------------------------------

int		Scroll_GetX(void)
{
	return(nScrollPosX/16);
}

//------------------------------------------------------------------------

int		Scroll_GetY(void)
{
	return(nScrollPosY/16);
}

//------------------------------------------------------------------------

void	Scroll_UpdateFE(void)
{
	nScrollFECount++;
	if (nScrollFECount > 0)
	{
		nScrollFECount = 0;
		nScrollPosY = (nScrollPosY + 1) % 16;
		nScrollPosX = (nScrollPosX + 16 - 1) % 16;
	}
}	

//------------------------------------------------------------------------
