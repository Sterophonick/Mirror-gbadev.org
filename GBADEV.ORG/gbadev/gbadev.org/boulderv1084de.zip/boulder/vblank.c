//------------------------------------------------------------------------------------

// vblank
// Rich Heasman April 2002

//------------------------------------------------------------------------------------

#include "mygba.h"
#include "vblank.h"

#include "interrupt.h"

//------------------------------------------------------------------------------------

static volatile	uint	uFrameCounter;

//------------------------------------------------------------------------------------

void	VBlank_Init(void)
{
	uFrameCounter = 0;
    Interrupt_HandlerSet(INT_TYPE_VBL, VBlank_Handler);

    M_DISSTAT_VBLIRQR_ON
    M_INTENA_VBL_ENABLE
}

//------------------------------------------------------------------------------------

// VBL IRQ handler : is invoked by the system on every VBLIRQ
void 	VBlank_Handler(void)
{
	uFrameCounter++;
}

//------------------------------------------------------------------------------------

void 	VBlank_Wait(void)
{
	uint	uFrameCounterPrevious;

	uFrameCounterPrevious =	uFrameCounter;
	while (	uFrameCounterPrevious == uFrameCounter);
}

//------------------------------------------------------------------------------------

uint	VBlank_FrameCounterGet(void)
{
	return(uFrameCounter);
}

//------------------------------------------------------------------------------------

void	VBlank_TimerSet(uint *uTimer, uint uLength)
{
	*uTimer = (uFrameCounter + uLength);
}

//------------------------------------------------------------------------------------

BOOL	VBlank_TimerMature(uint *uTimer)
{
	BOOL	boMature;

	boMature = FALSE;
	if (uFrameCounter >= *uTimer)
	{
		boMature = TRUE;
	}

	return(boMature);
}

//------------------------------------------------------------------------------------
