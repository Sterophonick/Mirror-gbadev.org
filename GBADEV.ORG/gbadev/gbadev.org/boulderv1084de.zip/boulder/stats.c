//------------------------------------------------------------------------

// stats
// Rich Heasman April 2002

//------------------------------------------------------------------------

#include	"mygba.h"
#include 	"stats.h"

#include	"gfx.h"
#include	"map.h"
#include	"background.h"
#include	"button.h"
#include	"string.h"
#include	"profile.h"

//------------------------------------------------------------------------

#define 	STATS_TIMER_DIVIDE_SCALER	(2<<16)

//------------------------------------------------------------------------

static uint		uStatsDiamondsGot;
static uint		uStatsDiamondsRequired;
static BOOL		boStatsDiamondsGotEnough;

static BOOL		boStatsTimerStarted;
static uint		uStatsTimer;

//------------------------------------------------------------------------

void	Stats_Begin(void)
{
	uStatsDiamondsGot = 0;
	boStatsDiamondsGotEnough = FALSE;
	boStatsTimerStarted = FALSE;
}

//------------------------------------------------------------------------

void	Stats_Update(void)
{
	if (boStatsTimerStarted && uStatsTimer > 0)
	{
		uStatsTimer--;		// based on number of updates not on real time 
	}
}	

//------------------------------------------------------------------------

void	Stats_Render(void)
{
	char	szMessage[STRING_LEN_MAX];
	char	szNumber[STRING_LEN_MAX];

	String_FromInt(szNumber, uStatsDiamondsGot);
	String_Copy(szMessage, szNumber);
	String_Cat(szMessage, "/");
	String_FromInt(szNumber, uStatsDiamondsRequired);
	String_Cat(szMessage, szNumber);
    Background_Font2Print( 1, 1, szMessage);
	String_FromInt(szNumber, (((uStatsTimer + 59) * (STATS_TIMER_DIVIDE_SCALER / 60)) / STATS_TIMER_DIVIDE_SCALER));
	String_Copy(szMessage, szNumber);
    Background_Font2Print( 23, 1, szMessage);
}

//------------------------------------------------------------------------

void	Stats_DiamondGot(void)
{
	uStatsDiamondsGot++;
	if (uStatsDiamondsGot == uStatsDiamondsRequired)
	{
		Map_FlashWhite();
		boStatsDiamondsGotEnough = TRUE;
	}
}

//------------------------------------------------------------------------

void	Stats_DiamondRequiredSet(uint uDiamonds)
{
	uStatsDiamondsRequired = uDiamonds;
}

//-----------------------------------------------------------------------

BOOL	Stats_DiamondGotEnough(void)
{
	return(boStatsDiamondsGotEnough);
}

//-----------------------------------------------------------------------

void	Stats_TimerSet(uint uTimer)
{
	uStatsTimer = uTimer * 60;
}	

//-----------------------------------------------------------------------

BOOL	Stats_TimerMature(void)
{
	BOOL	boMature;

	boMature = FALSE;
	if (uStatsTimer == 0)
	{
		boMature = TRUE;
	}

	return(boMature);
}	

//-----------------------------------------------------------------------

void	Stats_TimerStart(void)
{
	boStatsTimerStarted = TRUE;
}	

//-----------------------------------------------------------------------
