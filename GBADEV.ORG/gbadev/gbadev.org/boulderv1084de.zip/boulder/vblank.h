//------------------------------------------------------------------------------------

// vblank
// Rich Heasman April 2002

//------------------------------------------------------------------------------------

#include	"agbtypes.h"

void 	VBlank_Init(void);
void 	VBlank_Handler(void);
void 	VBlank_Wait(void);
uint	VBlank_FrameCounterGet(void);
void 	VBlank_TimerSet(uint *uTimer, uint uLength);
BOOL 	VBlank_TimerMature(uint *uTimer);

//------------------------------------------------------------------------------------
