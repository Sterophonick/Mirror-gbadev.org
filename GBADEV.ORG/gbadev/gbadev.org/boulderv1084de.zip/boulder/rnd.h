//------------------------------------------------------------------------

// rnd
// Rich Heasman April 2002

//------------------------------------------------------------------------

#include	"mygba.h"

void	Rnd_Init(void);
void	Rnd_SeedSet(uint uSeed);
uint	Rnd(uint uRange);
uint	Rnd_IWRAM(uint uRange) CODE_IN_IWRAM;

//-----------------------------------------------------------------------

