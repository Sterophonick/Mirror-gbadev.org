gbagradient.exe - a quick hack to do cool things
Written by Stephen Stair (sgstair)

Directions:
When you open the program, the interface is pretty self-explanatory.  There is a list of colors that is used to create the gradient that is shown in the preview.  To add colors, change the red, blue, and green values and hit 'Add item', to remove a color, just select one and hit 'remove selected item'. 'Generate Array' is used to make a C-style array in the text box at the bottom, so you can actually incorperate some of the cool color effects into your program :)  The number of steps specifies how many samples will be in your gradient (Also the number of elements in the array to be output

This outputs in GBA format colors, so no extra processing is required, however note that the actual gradients are designed in 24bit rgb space (so colors go from 0-255)

There is little error checking at the moment, so you can make it do wierd things by typing text in for numbers in the color boxes, but it is usable.

Have fun, happy gradienting :)

-Stephen

If you find any bugs, or have comments, you can contact me at sgstair@interspecialty.com, and my website is at www.interspecialty.com/sgstair